# CIEN notes — 0000936395-23-000044


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000936395-23-000044:notes:1]
Part III of the Form 10-K incorporates by reference certain portions of the registrant’s definitive proxy statement for its 2024 Annual Meeting of Stockholders to be filed with the Commission not later than 120 days after the end of the fiscal year covered by this report.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000936395-23-000044:notes:2]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES
Description of Business

[0000936395-23-000044:notes:3]
Ciena Corporation (“Ciena” or the “Company”) is a network platform, software, and services company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. Ciena provides hardware, software and services that support the delivery of video, data and voice traffic over core, metro, aggregation and access communications networks. Ciena’s solutions are used globally by communications service providers, cable and multiservice operators, cloud providers, submarine network operators, governments, and enterprises across multiple industry verticals.

[0000936395-23-000044:notes:4]
Ciena’s portfolio is designed to enable the Adaptive Network™, Ciena’s vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that is informed by network analytics and intelligence. By transforming network infrastructures into dynamic, programmable environments driven by automation and analytics, network operators can realize greater business agility, adapt dynamically to changing end-user service demands and rapidly introduce new revenue-generating services. They can also gain valuable real-time network insights, allowing them to optimize network performance and maximize the return on their network infrastructure investment.

[0000936395-23-000044:notes:5]
Ciena’s solutions include Networking Platforms, including its Optical Networking portfolio and Routing and Switching portfolio, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. Ciena’s Optical Networking portfolio, which was previously referred to as Ciena’s Converged Packet Optical portfolio, includes products that support long haul and regional networks, submarine and data center interconnect networks, and metro and edge networks. Ciena’s Routing and Switching portfolio includes products and solutions that enable efficient internet protocol (“IP”) transport in next-generation metro, core, aggregation, and access networks, including in enterprise edge and broadband access applications.

[0000936395-23-000044:notes:6]
To complement its Networking Platforms, Ciena offers Platform Software, which includes its Manage, Control and Plan (“MCP”) applications that deliver advanced multi-layer domain control and operations. Ciena, through its Blue Planet® Software, also enables complete service lifecycle management automation with productized operational support systems (“OSS”), which include inventory, orchestration and assurance solutions that help its customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-23-000044:notes:7]
In addition to its systems and software, Ciena also offers a broad range of services that help its customers build, operate and improve their networks and associated operational environments. These include network transformation, consulting, implementation, systems integration, maintenance, network operations center (“NOC”) management, learning, and optimization services.

[0000936395-23-000044:notes:8]
Basis of Presentation

[0000936395-23-000044:notes:9]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000936395-23-000044:notes:10]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October in each year (October 28, 2023, October 29, 2022, and October 30, 2021, for the periods reported). Fiscal 2023, fiscal 2022 and fiscal 2021 each consisted of a 52-week fiscal year.

[0000936395-23-000044:notes:11]
Business Combinations

[0000936395-23-000044:notes:12]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed, in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Ciena’s estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and

[0000936395-23-000044:notes:13]
estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-23-000044:notes:14]
Use of Estimates

[0000936395-23-000044:notes:15]
The preparation of the financial statements and related disclosures in conformity with Generally Accepted Accounting Principles (“GAAP”) requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-23-000044:notes:16]
Cash and Cash Equivalents

[0000936395-23-000044:notes:17]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending on the duration of the restriction.

[0000936395-23-000044:notes:18]
Investments

[0000936395-23-000044:notes:19]
Ciena’s investments in debt securities are classified as available-for-sale and reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive loss. Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena’s cost basis, and Ciena’s intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

[0000936395-23-000044:notes:20]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of October 28, 2023, the combined carrying value of these investments was minimal. Ciena elects to estimate the fair value at cost minus impairment, if any, plus or minus observable price changes in orderly transactions for identical or similar investments of the same issuer. Ciena evaluates these investments for impairment or observable price changes quarterly and records adjustments to interest and other income (loss), net on the Consolidated Statements of Operations.

[0000936395-23-000044:notes:21]
Inventories

[0000936395-23-000044:notes:22]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0000936395-23-000044:notes:23]
Segment Reporting

[0000936395-23-000044:notes:24]
Ciena’s chief operating decision maker, its chief executive officer, evaluates the Company’s performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 25 below.

[0000936395-23-000044:notes:25]
Goodwill

[0000936395-23-000044:notes:26]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-23-000044:notes:27]
Annually, Ciena tests goodwill impairment qualitatively, or quantitatively by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-23-000044:notes:28]
Long-lived Assets

[0000936395-23-000044:notes:29]
Long-lived assets include equipment, building, furniture and fixtures, operating right-of-use (“ROU”) assets, finite-lived intangible assets and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset’s carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena’s long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.

[0000936395-23-000044:notes:30]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0000936395-23-000044:notes:31]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method, generally over useful lives of three years to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

[0000936395-23-000044:notes:32]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two years to five years.

[0000936395-23-000044:notes:33]
Leases

[0000936395-23-000044:notes:34]
At the inception of a contract, Ciena must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts follows the assessment of whether there is a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating ROU assets, Operating lease liabilities and Long-term operating lease liabilities in the Consolidated Balance Sheets. Finance leases are included in Equipment, building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations in the Consolidated Balance Sheets.

[0000936395-23-000044:notes:35]
Ciena has operating and finance leases that primarily relate to real property. Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Ciena has elected not to separate lease and non-lease components of operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass-through operating expenses like common area maintenance and utilities.

[0000936395-23-000044:notes:36]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight-line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Consolidated Statements of Operations.

[0000936395-23-000044:notes:37]
Intangible Assets

[0000936395-23-000044:notes:38]
Ciena has recorded finite-lived intangible assets as a result of several acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

[0000936395-23-000044:notes:39]
Cloud Computing Arrangements

[0000936395-23-000044:notes:40]
Ciena capitalizes certain costs related to hosting arrangements that are service contracts (cloud computing arrangements). Capitalized costs are included in Other long-term assets in the Consolidated Balance Sheets and are amortized on a straight-line basis over the estimated useful life.

[0000936395-23-000044:notes:41]
Maintenance Spares

[0000936395-23-000044:notes:42]
Maintenance spares are recorded at cost. Ciena depreciates spares ratably over four years.

[0000936395-23-000044:notes:43]
Concentrations

[0000936395-23-000044:notes:44]
Substantially all of Ciena’s cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena’s cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-23-000044:notes:45]
Historically, a significant percentage of Ciena’s revenue has been concentrated among sales to a small number of large communications service providers and cloud providers. Consolidation among Ciena’s customers has increased this concentration. Consequently, Ciena’s accounts receivable are concentrated among these customers. See Note 2 below.

[0000936395-23-000044:notes:46]
Additionally, Ciena’s access to certain materials or components is dependent on sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena’s supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena’s business and results of operations may suffer.

[0000936395-23-000044:notes:47]
Revenue Recognition

[0000936395-23-000044:notes:48]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which Ciena expects to be entitled in exchange for those products or services.

[0000936395-23-000044:notes:49]
Ciena determines revenue recognition by applying the following five-step approach:

[0000936395-23-000044:notes:50]
•identification of the contract, or contracts, with a customer;

[0000936395-23-000044:notes:51]
•identification of the performance obligations in the contract;

[0000936395-23-000044:notes:52]
•determination of the transaction price;

[0000936395-23-000044:notes:53]
•allocation of the transaction price to the performance obligations in the contract; and

[0000936395-23-000044:notes:54]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

[0000936395-23-000044:notes:55]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of Ciena’s products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

[0000936395-23-000044:notes:56]
Purchase orders are invoiced based on the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and

[0000936395-23-000044:notes:57]
software subscription services are invoiced quarterly or annually in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers. As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing component as it expects, at contract inception, that the period between Ciena’s transfer of the products or services to the customer and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

[0000936395-23-000044:notes:58]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

[0000936395-23-000044:notes:59]
Significant Judgments

[0000936395-23-000044:notes:60]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

[0000936395-23-000044:notes:61]
Ciena applies judgment in determining the transaction price, as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-23-000044:notes:62]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-23-000044:notes:63]
Capitalized Contract Acquisition Costs

[0000936395-23-000044:notes:64]
Ciena has considered the impact of the guidance in Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

[0000936395-23-000044:notes:65]
For the additional disclosures on capitalized contract acquisition costs, see Note 2 below.

[0000936395-23-000044:notes:66]
Warranty Accruals

[0000936395-23-000044:notes:67]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty

[0000936395-23-000044:notes:68]
is included in cost of goods sold and is determined based on actual warranty cost experience, estimates of component failure rates and management’s industry experience. Ciena’s sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

[0000936395-23-000044:notes:69]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0000936395-23-000044:notes:70]
Ciena estimates its allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, Ciena determines collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the probability that the asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.

[0000936395-23-000044:notes:71]
Probability of default rates are published by third-party credit rating agencies. Adjustments to Ciena’s exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000936395-23-000044:notes:72]
Accounts Receivable Factoring

[0000936395-23-000044:notes:73]
Ciena has entered into factoring agreements to sell certain receivables to unrelated third-party financial institution on a non-recourse basis. These transactions are accounted for in accordance with ASC Topic 860, “Transfers and Servicing” and result in a reduction in accounts receivable because the agreements transfer effective control over, and risk related to, the receivables to the buyers. Ciena's factoring agreements do not allow for recourse in the event of uncollectability, and Ciena does not retain any interest in the underlying accounts receivable once sold. Trade accounts receivables balances sold are removed from the consolidated balance sheets and cash received is reflected as cash provided by (used in) operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest and other income (loss), net on the Consolidated Statements of Operations. See Note 9 below.

[0000936395-23-000044:notes:74]
Research and Development

[0000936395-23-000044:notes:75]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third-party services, depreciation, facility costs and information technology.

[0000936395-23-000044:notes:76]
Government Grants

[0000936395-23-000044:notes:77]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statement of Operations to which the grant activity relates. See Notes 3 below.

[0000936395-23-000044:notes:78]
Advertising Costs

[0000936395-23-000044:notes:79]
Ciena expenses all advertising costs as incurred.

[0000936395-23-000044:notes:80]
Legal Costs

[0000936395-23-000044:notes:81]
Ciena expenses legal costs associated with litigation as incurred.

[0000936395-23-000044:notes:82]
Share-Based Compensation Expense

[0000936395-23-000044:notes:83]
Ciena measures and recognizes compensation expense for share-based awards and employee stock purchases related to its Amended and Restated 2003 Employee Stock Purchase Plan (the “ESPP”) based on estimated fair values on the date of grant. Ciena estimates the fair value of employee stock purchases related to the ESPP using the Black-Scholes option-pricing model. Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. In each case, Ciena only recognizes expense in its Consolidated Statements of Operations for those restricted stock units that ultimately vest. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total stockholder return as compared to an index of peer companies, in whole or in part. Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total stockholder return by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Ciena recognizes the estimated fair value of performance based awards subject to total stockholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model on the date of grant. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. See Note 24 below.

[0000936395-23-000044:notes:84]
Stock Repurchase Program

[0000936395-23-000044:notes:85]
Shares repurchased pursuant to Ciena’s stock repurchase program are immediately retired upon purchase. Repurchased common stock is reflected as a reduction of stockholders’ equity. Ciena’s accounting policy related to its share repurchases is to reduce its common stock based on the par value of the shares and to reduce its capital surplus for the excess of the repurchase price over the par value. Since the inception of its stock repurchase programs, Ciena has had an accumulated deficit balance; therefore, the excess over the par value has been applied to additional paid-in capital. Once Ciena has retained earnings, the excess will be charged entirely to retained earnings.

[0000936395-23-000044:notes:86]
Income Taxes

[0000936395-23-000044:notes:87]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities (“DTA”) for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based on the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-23-000044:notes:88]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2018 through 2021, in Canada for 2014, and in the United Kingdom for 2016 through 2021. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2020), United Kingdom (2016), Canada (2014), and India (2018). Limited adjustments can be made to federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-23-000044:notes:89]
Ciena is required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-23-000044:notes:90]
The Tax Cuts and Jobs Act (the “Tax Act”) includes provisions that affected Ciena starting in fiscal 2019, including a provision designed to tax global intangible low-taxed income (“GILTI”). An accounting policy choice is allowed to either treat taxes due on future U.S. inclusions related to GILTI in taxable income as a current-period expense when incurred (the “period cost method”) or factor such amounts into the measurement of deferred taxes (the “deferred method”). The calculation of the deferred balance with respect to the GILTI tax provisions will depend, in part, on analyzing global income to determine whether future U.S. inclusions in taxable income are expected related to GILTI and, if so, what the impact is expected to be. Ciena is electing to use the period cost method for future GILTI inclusions. Additionally, Ciena is electing to use the incremental cash tax savings approach when determining whether a valuation allowance needs to be recorded against the U.S. net operating loss (“NOL”) due to the GILTI inclusions.

[0000936395-23-000044:notes:91]
The Tax Act also introduced an alternative tax known as the base erosion and anti-abuse tax (“BEAT”). An accounting policy choice has been made to consider BEAT as a period cost when incurred.

[0000936395-23-000044:notes:92]
Loss Contingencies

[0000936395-23-000044:notes:93]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena’s ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.

[0000936395-23-000044:notes:94]
Fair Value of Financial Instruments

[0000936395-23-000044:notes:95]
The carrying value of Ciena’s cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena’s short-term and long-term debt, see Note 19 below.

[0000936395-23-000044:notes:96]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000936395-23-000044:notes:97]
•Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities;

[0000936395-23-000044:notes:98]
•Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0000936395-23-000044:notes:99]
•Level 3 inputs are unobservable inputs based on Ciena’s assumptions used to measure assets and liabilities at fair value. The fair values are determined based on model-based techniques using inputs Ciena could not corroborated with market data.

[0000936395-23-000044:notes:100]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-23-000044:notes:101]
Restructuring

[0000936395-23-000044:notes:102]
From time to time, Ciena takes actions to align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions and redesign business processes. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 5 below.

[0000936395-23-000044:notes:103]
Foreign Currency

[0000936395-23-000044:notes:104]
Certain of Ciena’s foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders’ equity. Where the monetary assets and liabilities are transacted in a currency other than the entity’s functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statements of Operations. See Note 6 below.

[0000936395-23-000044:notes:105]
Derivatives

[0000936395-23-000044:notes:106]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 24 months or less. Ciena also has interest rate swap arrangements to reduce variability in certain forecasted interest expense associated with its term loans. All of these derivatives are designated as cash flow hedges. Ciena also uses foreign currency forward contracts to minimize the effect of foreign exchange rate movements on is net investments in foreign operations. Generally, these derivatives have maturities of 24 months or less. These derivatives are designated as net investment hedges. At the inception of these hedges, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes attributable to the hedged risk during the hedging period. The derivative’s net gain or loss is initially reported as a component of accumulated other comprehensive loss, and upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statements of Operations to which the hedged transaction relates.

[0000936395-23-000044:notes:107]
Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

[0000936395-23-000044:notes:108]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet foreign exchange exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Consolidated Statements of Operations.

[0000936395-23-000044:notes:109]
See Notes 8 and 16 below.

[0000936395-23-000044:notes:110]
Computation of Net Income per Share

[0000936395-23-000044:notes:111]
Ciena calculates basic net income per common share (“Basic EPS”) by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted net income per potential common share (“Diluted EPS”) includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of Basic EPS and Diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the Basic EPS and Diluted EPS computations is set forth in Note 21 below.

[0000936395-23-000044:notes:112]
Software Development Costs

[0000936395-23-000044:notes:113]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized using the straight-line method over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-23-000044:notes:114]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-23-000044:notes:115]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena does not expect adoption of ASU 2021-08 to have a material impact on its consolidated financial statements and related disclosures.

[0000936395-23-000044:notes:116]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures. 
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.


## us-gaap:InventoryPolicyTextBlock

[0000936395-23-000044:notes:117]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-23-000044:notes:118]
REVENUE
Disaggregation of Revenue

[0000936395-23-000044:notes:119]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category. Effective as of the fourth quarter of fiscal 2023, Ciena renamed its “Converged Packet Optical” product line to “Optical Networking.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. However, references to prior reported “Converged Packet Optical” product line have been changed herein to “Optical Networking.”

[0000936395-23-000044:notes:120]
The tables below set forth Ciena’s disaggregated revenue for the respective period (in thousands):

[0000936395-23-000044:notes:121]
|  | Year Ended October 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,987,245 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,987,245 |  |
| Routing and Switching | 506,247 |  |  | — |  |  | — |  |  | — |  |  | 506,247 |  |
| Platform Software and Services | — |  |  | 303,873 |  |  | — |  |  | — |  |  | 303,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 69,170 |  |  | — |  |  | 69,170 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 288,334 |  |  | 288,334 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 180,951 |  |  | 180,951 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 50,729 |  |  | 50,729 |  |
| Total revenue by product line | $ | 3,493,492 |  |  | $ | 303,873 |  |  | $ | 69,170 |  |  | $ | 520,014 |  |  | $ | 4,386,549 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 3,493,492 |  |  | $ | 67,013 |  |  | $ | 21,842 |  |  | $ | 55,036 |  |  | $ | 3,637,383 |  |
| Products and services transferred over time | — |  |  | 236,860 |  |  | 47,328 |  |  | 464,978 |  |  | 749,166 |  |
| Total revenue by timing of revenue recognition | $ | 3,493,492 |  |  | $ | 303,873 |  |  | $ | 69,170 |  |  | $ | 520,014 |  |  | $ | 4,386,549 |  |

[0000936395-23-000044:notes:122]
|  | Year Ended October 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,379,931 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,379,931 |  |
| Routing and Switching | 398,439 |  |  | — |  |  | — |  |  | — |  |  | 398,439 |  |
| Platform Software and Services | — |  |  | 277,191 |  |  | — |  |  | — |  |  | 277,191 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 76,567 |  |  | — |  |  | 76,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 292,375 |  |  | 292,375 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 157,443 |  |  | 157,443 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 50,715 |  |  | 50,715 |  |
| Total revenue by product line | $ | 2,778,370 |  |  | $ | 277,191 |  |  | $ | 76,567 |  |  | $ | 500,533 |  |  | $ | 3,632,661 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,778,370 |  |  | $ | 85,691 |  |  | $ | 25,540 |  |  | $ | 44,091 |  |  | $ | 2,933,692 |  |
| Products and services transferred over time | — |  |  | 191,500 |  |  | 51,027 |  |  | 456,442 |  |  | 698,969 |  |
| Total revenue by timing of revenue recognition | $ | 2,778,370 |  |  | $ | 277,191 |  |  | $ | 76,567 |  |  | $ | 500,533 |  |  | $ | 3,632,661 |  |

[0000936395-23-000044:notes:123]
|  | Year Ended October 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,553,509 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,553,509 |  |
| Routing and Switching | 271,796 |  |  | — |  |  | — |  |  | — |  |  | 271,796 |  |
| Platform Software and Services | — |  |  | 229,588 |  |  | — |  |  | — |  |  | 229,588 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 77,247 |  |  | — |  |  | 77,247 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 283,350 |  |  | 283,350 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 171,489 |  |  | 171,489 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 33,705 |  |  | 33,705 |  |
| Total revenue by product line | $ | 2,825,305 |  |  | $ | 229,588 |  |  | $ | 77,247 |  |  | $ | 488,544 |  |  | $ | 3,620,684 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,825,305 |  |  | $ | 80,359 |  |  | $ | 27,621 |  |  | $ | 14,923 |  |  | $ | 2,948,208 |  |
| Products and services transferred over time | — |  |  | 149,229 |  |  | 49,626 |  |  | 473,621 |  |  | 672,476 |  |
| Total revenue by timing of revenue recognition | $ | 2,825,305 |  |  | $ | 229,588 |  |  | $ | 77,247 |  |  | $ | 488,544 |  |  | $ | 3,620,684 |  |

[0000936395-23-000044:notes:124]
Ciena reports its sales geographically around the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-23-000044:notes:125]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-23-000044:notes:126]
|  | Year Ended |
|  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Geographic distribution: |  |  |  |  |  |
| Americas | $ | 3,110,347 |  |  | $ | 2,636,840 |  |  | $ | 2,525,619 |  |
| EMEA | 643,142 |  |  | 555,215 |  |  | 670,462 |  |
| APAC | 633,060 |  |  | 440,606 |  |  | 424,603 |  |
| Total revenue by geographic distribution | $ | 4,386,549 |  |  | $ | 3,632,661 |  |  | $ | 3,620,684 |  |

[0000936395-23-000044:notes:127]
Ciena’s revenue includes United States revenue of $2.8 billion for fiscal 2023, $2.4 billion for fiscal 2022 and $2.3 billion for fiscal 2021. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-23-000044:notes:128]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-23-000044:notes:129]
|  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Cloud Provider | $ | 561,397 |  |  | n/a |  | n/a |
| AT&T | 464,662 |  |  | $ | 433,418 |  |  | $ | 447,403 |  |
| Verizon | n/a |  | 402,787 |  |  | n/a |
| Total | $ | 1,026,059 |  |  | $ | 836,205 |  |  | $ | 447,403 |  |

[0000936395-23-000044:notes:130]
________________________________

[0000936395-23-000044:notes:131]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

[0000936395-23-000044:notes:132]
The cloud provider noted in the above table purchased products from each of Ciena’s operating segments, excluding Blue Planet® Automation Software and Services, for each of the periods presented. The other customers identified above purchased products and services from each of Ciena’s operating segments for each of the periods presented.

[0000936395-23-000044:notes:133]
While Ciena has benefited from the diversification of its business and customer base, its ten largest customers contributed 53.7% of fiscal 2023 revenue, 56.3% of fiscal 2022 revenue and 55.5% of fiscal 2021 revenue.

[0000936395-23-000044:notes:134]
◦Networking Platforms revenue reflects sales of Ciena’s Optical Networking and Routing and Switching product lines.

[0000936395-23-000044:notes:135]
▪Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line also includes the WaveLogic 5 Nano (WL5n) 100G-400G coherent pluggable transceivers.

[0000936395-23-000044:notes:136]
▪Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and virtualization software. This product line also includes SD-Edge software and our microplug Optical Line Terminal (OLT) transceiver, from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023. This product line also includes Ciena’s WaveRouterTM product, which was introduced during the second quarter of fiscal 2023, for which there have been no sales to date.

[0000936395-23-000044:notes:137]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-23-000044:notes:138]
◦Platform Software and Services offerings provide domain control management, analytics, data and planning tools and applications to assist customers in managing their networks, including by creating more efficient operations and more proactive visibility into their networks. Ciena’s platform software includes its MCP domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services

[0000936395-23-000044:notes:139]
revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-23-000044:notes:140]
◦Blue Planet® Automation Software and Services is a comprehensive, cloud native, and standards-based software portfolio, together with related services, that enables customers to realize digital transformation through the automation of the services lifecycle. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), multi-cloud orchestration (MCO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-23-000044:notes:141]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-23-000044:notes:142]
◦Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-23-000044:notes:143]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-23-000044:notes:144]
Contract Balances

[0000936395-23-000044:notes:145]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-23-000044:notes:146]
|  |  | Balance at October 28, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 1,003,876 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 150,312 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 228,460 |  |  | $ | 200,235 |  |

[0000936395-23-000044:notes:147]
Ciena’s contract assets represent unbilled accounts receivable, net, where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Consolidated Balance Sheets. See Note 11 below.

[0000936395-23-000044:notes:148]
Contract liabilities consist of deferred revenue and represent advanced payments received from customers against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $135.5 million and $111.3 million of revenue during fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance at October 28, 2023 and October 29, 2022, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during fiscal 2023 and 2022.

[0000936395-23-000044:notes:149]
Capitalized contract acquisition costs consist of deferred sales commissions and were $30.2 million and $39.7 million as of October 28, 2023 and October 29, 2022, respectively, and are included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $34.2 million and $27.3 million during fiscal 2023 and fiscal 2022, respectively, and are included in selling and marketing expense on the Consolidated Statements of Operations.

[0000936395-23-000044:notes:150]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of October 28, 2023, the aggregate amount of RPO was $1.8 billion. As of October 28, 2023, Ciena expects approximately 81% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-23-000044:notes:151]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-23-000044:notes:152]
|  | October 28, 2023 |  | October 29, 2022 |
| Products | $ | 28,353 |  |  | $ | 19,814 |  |
| Services | 200,107 |  |  | 180,421 |  |
| Total deferred revenue | 228,460 |  |  | 200,235 |  |
| Less current portion | (154,419) |  |  | (137,899) |  |
| Long-term deferred revenue | $ | 74,041 |  |  | $ | 62,336 |  |


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0000936395-23-000044:notes:153]
CANADIAN EMERGENCY WAGE SUBSIDY
In April 2020, the Canadian government introduced the Canada Emergency Wage Subsidy (“CEWS”) to help employers offset a portion of their employee wages for a limited period in response to the COVID-19 outbreak, retroactive to March 15, 2020. The CEWS program expired in October 2021. The subsidy covered employers of all sizes and across all sectors.

[0000936395-23-000044:notes:154]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statements of Operations to which the grant activity relates. Amounts from the CEWS program positively impacted Ciena’s operating expense and measures of profit in the year ended October 30, 2021. For the fiscal year ended October 30, 2021, Ciena recorded a CAD$52.2 million ($41.3 million) benefit, net of certain fees, related to CEWS for claim periods beginning March 15, 2020, including CAD$43.9 million ($35.4 million) related to employee wages during fiscal 2020. There was no CEWS activity in fiscal 2023 or 2022.

[0000936395-23-000044:notes:155]
The following table summarizes CEWS for the period indicated (in thousands):

[0000936395-23-000044:notes:156]
|  |  |  | Year Ended October 30, 2021 |  |  |
| Product |  |  | $ | 4,283 |  |  |  |
| Service |  |  | 2,667 |  |  |  |
| CEWS benefit in cost of goods sold |  |  | 6,950 |  |  |  |
| Research and development |  |  | 29,519 |  |  |  |
| Sales and marketing |  |  | 2,604 |  |  |  |
| General and administrative |  |  | 2,207 |  |  |  |
| CEWS benefit in operating expense |  |  | 34,330 |  |  |  |
| Total CEWS benefit |  |  | $ | 41,280 |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-23-000044:notes:157]
BUSINESS COMBINATIONS
Fiscal 2023 Acquisitions: Benu and Tibit

[0000936395-23-000044:notes:158]
On November 17, 2022, Ciena acquired Benu, a portfolio of cloud-native software solutions, including a virtual Broadband Network Gateway ((v)BNG), that complements Ciena’s existing portfolio of broadband access solutions. On December 30, 2022, Ciena acquired Tibit, a provider and developer of passive optical network (“PON”)-specific hardware and operating software that can be integrated into a carrier-grade Ethernet switch and will strengthen Ciena’s portfolio of next-generation PON solutions that support residential, enterprise, and mobility use cases. These businesses were acquired for an aggregate of approximately $291.7 million, of which $244.7 million was paid in cash, and $47.0 million represents the fair value of Ciena’s previously held cost method equity investment in Tibit. The acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million. Each of these transactions has been accounted for as the acquisition of a business.

[0000936395-23-000044:notes:159]
Ciena incurred approximately $3.4 million in acquisition-related costs associated with these acquisitions. These costs and expenses primarily include fees associated with financial, legal, and accounting advisors and employment-related costs. These costs were recorded in acquisition and integration costs on the Consolidated Statements of Operations.

[0000936395-23-000044:notes:160]
The following table summarizes the final purchase price allocation related to the acquisitions based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-23-000044:notes:161]
|  | Amount |
| Cash and cash equivalents | $ | 14,634 |  |
| Accounts receivable, net | 443 |  |
| Inventories, net | 1,406 |  |
| Prepaid expenses and other | 810 |  |
| Equipment, furniture and fixtures | 1,090 |  |
| Goodwill | 116,644 |  |
| Developed technology | 75,400 |  |
| In-process technology | 89,100 |  |
| Customer relationships and contracts | 18,400 |  |
| Order backlog | 2,480 |  |
| Deferred tax asset, net | (26,429) |  |
| Accounts payable | (420) |  |
| Accrued liabilities and other short-term obligations | (874) |  |
| Deferred revenue | (851) |  |
| Other long-term obligations | (144) |  |
| Total purchase consideration | $ | 291,689 |  |

[0000936395-23-000044:notes:162]
Developed technology represents purchased technology that has reached technological feasibility and for which the acquired companies had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight-line basis over its estimated useful life of five years.

[0000936395-23-000044:notes:163]
In-process technology represents purchased technology that had not reached technological feasibility as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the in-process technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Upon completion of the in-process technology, it will be amortized on a straight line basis over its estimated useful life, which will be determined on that date.

[0000936395-23-000044:notes:164]
Customer relationships and contracts represent agreements with existing Tibit customers and have an estimated useful life of three years. Order backlog is amortized over the fulfillment period.

[0000936395-23-000044:notes:165]
The goodwill generated from these acquisitions is primarily related to expected economic synergies. The total goodwill amount was recorded in the Networking Platforms segment. The goodwill is not deductible for income tax purposes.

[0000936395-23-000044:notes:166]
Pro forma disclosures have not been included due to immateriality. The amounts of revenue and earnings for these acquisitions since the acquisition dates, which are included on the Consolidated Statements of Operations for the reporting period, are immaterial.

[0000936395-23-000044:notes:167]
Fiscal 2022 Acquisitions: Vyatta and Xelic

[0000936395-23-000044:notes:168]
On November 1, 2021, Ciena acquired AT&T’s Vyatta Software Technology (“Vyatta”), a provider of software-based virtual routing and switching technology. AT&T is a customer of Ciena; see Note 2 above. On March 9, 2022, Ciena acquired Xelic, Inc., a provider and developer of field programmable gate array (FPGA) and application-specific integrated circuit (ASIC) technology and optical networking IP cores. These businesses were acquired for an aggregate of approximately $64.1 million, of which $63.3 million was paid in cash and $0.8 million represents a future payable arrangement. These transactions have each been accounted for as the acquisition of a business.

[0000936395-23-000044:notes:169]
Ciena incurred approximately $1.7 million in acquisition-related costs associated with these acquisitions. These costs and expenses primarily include fees associated with financial, legal and accounting advisors. These costs were recorded in acquisition and integration costs in the Consolidated Statements of Operations.

[0000936395-23-000044:notes:170]
|  | Amount |
| Cash and cash equivalents | $ | 201 |  |
| Prepaid expenses and other | 1,614 |  |
| Equipment, furniture and fixtures | 694 |  |
| Customer relationships and contracts | 15,800 |  |
| Developed technology | 32,491 |  |
| Goodwill | 17,698 |  |
| Accrued liabilities | (4,434) |  |
| Total purchase consideration | $ | 64,064 |  |

[0000936395-23-000044:notes:171]
Customer relationships and contracts represent agreements with existing Vyatta customers and have an estimated useful life of two years.

[0000936395-23-000044:notes:172]
The goodwill generated from these acquisitions are primarily related to expected economic synergies. The total goodwill amount was recorded in the Networking Platforms segment. The goodwill is not deductible for income tax purposes.

[0000936395-23-000044:notes:173]
Pro forma disclosures have not been included due to immateriality. The amounts of revenue and earnings for these acquisitions since the acquisition dates, which are included in the Consolidated Statements of Operations for the reporting period, are immaterial.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-23-000044:notes:174]
SIGNIFICANT ASSET IMPAIRMENT AND RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on Ciena’s Consolidated Balance Sheets, for the fiscal years indicated (in thousands):

[0000936395-23-000044:notes:175]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 31, 2020 | $ | 2,915 |  |  | $ | — |  |  | $ | 2,915 |  |
| Charges | 5,938 |  | (1) | 23,627 |  | (2) | 29,565 |  |
| Cash payments | (8,072) |  |  | (23,627) |  |  | (31,699) |  |
| Balance at October 30, 2021 | 781 |  |  | — |  |  | 781 |  |
| Charges | 3,156 |  | (1) | 26,814 |  | (2) | 29,970 |  |
| Cash payments | (2,722) |  |  | (22,194) |  |  | (24,916) |  |
| Balance at October 29, 2022 | 1,215 |  |  | 4,620 |  |  | 5,835 |  |
| Charges | 6,885 |  | (1) | 16,949 |  | (2) | 23,834 |  |
| Cash payments | (6,187) |  |  | (21,569) |  |  | (27,756) |  |
| Balance at October 28, 2023 | $ | 1,913 |  |  | $ | — |  |  | $ | 1,913 |  |
| Current restructuring liabilities | $ | 1,913 |  |  | $ | — |  |  | $ | 1,913 |  |

[0000936395-23-000044:notes:176]
_________________________________

[0000936395-23-000044:notes:177]
(1) Reflects employee costs associated with workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-23-000044:notes:178]
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization and costs related to restructured real estate facilities.

[0000936395-23-000044:notes:179]
Significant Asset Impairments

[0000936395-23-000044:notes:180]
In February 2022, armed conflict escalated between Russia and Ukraine. The United States and certain other countries have imposed sanctions on Russia and could impose further sanctions. On March 7, 2022, Ciena announced its decision to suspend its business operations in Russia immediately. As a result, Ciena recorded impairment charges of approximately $3.8 million of which $1.8 million was a provision for credit losses.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-23-000044:notes:181]
INTEREST AND OTHER INCOME (LOSS), NET
The components of interest and other income (loss), net, were as follows (in thousands):

[0000936395-23-000044:notes:182]
|  |  | Year Ended |
|  |  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Interest income |  | $ | 45,011 |  |  | $ | 10,060 |  |  | $ | 2,051 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts |  | (3,896) |  |  | (4,018) |  |  | 11,172 |  |
| Foreign currency exchange gains (losses) |  | (427) |  |  | 2,501 |  |  | (14,622) |  |
| Gain on cost method equity investments, net |  | 26,368 |  |  | 4,120 |  |  | 164 |  |
| Other |  | (5,048) |  |  | (5,916) |  |  | (533) |  |
| Interest and other income (loss), net |  | $ | 62,008 |  |  | $ | 6,747 |  |  | $ | (1,768) |  |

[0000936395-23-000044:notes:183]
During the first quarter of fiscal 2023, the acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million. See Note 4 above. During fiscal 2023 and fiscal 2022, Ciena recorded a net gain of $26.4 million and $4.1 million, respectively, on its cost method equity investments.
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During fiscal 2023 and 2021, Ciena recorded $0.4 million and $14.6 million, respectively, in exchange rate losses as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency. During fiscal 2022, Ciena recorded $2.5 million in exchange rate gains as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency. The related remeasurement adjustments were recorded in interest and other income (loss), net on the Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge certain of these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is also reported in interest and other income (loss), net on the Consolidated Statements of Operations. During fiscal 2023 and 2022, Ciena recorded losses of $3.9 million and $4.0 million, respectively, from non-hedge designated foreign currency forward contracts. During fiscal 2021, Ciena recorded a gain of $11.2 million from non-hedge designated foreign currency forward contracts.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-23-000044:notes:184]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0000936395-23-000044:notes:185]
|  | October 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 170,260 |  |  | $ | 28 |  |  | $ | (379) |  |  | $ | 169,909 |  |
| Corporate debt securities | 59,683 |  |  | 1 |  |  | (115) |  |  | 59,569 |  |
| Time deposits | 138,830 |  |  | 4 |  |  | (5) |  |  | 138,829 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |
| Included in cash equivalents | $ | 129,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 129,276 |  |
| Included in short-term investments | 105,042 |  |  | 4 |  |  | (293) |  |  | 104,753 |  |
| Included in long-term investments | 134,455 |  |  | 29 |  |  | (206) |  |  | 134,278 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |

[0000936395-23-000044:notes:186]
|  | October 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 137,963 |  |  | $ | — |  |  | $ | (3,379) |  |  | $ | 134,584 |  |
| Corporate debt securities | 54,899 |  |  | 1 |  |  | (405) |  |  | 54,495 |  |
| Time deposits | 55,889 |  |  | — |  |  | (64) |  |  | 55,825 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |
| Included in cash equivalents | $ | 55,530 |  |  | $ | — |  |  | $ | — |  |  | $ | 55,530 |  |
| Included in short-term investments | 156,430 |  |  | 1 |  |  | (2,442) |  |  | 153,989 |  |
| Included in long-term investments | 36,791 |  |  | — |  |  | (1,406) |  |  | 35,385 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |

[0000936395-23-000044:notes:187]
The following table summarizes the legal maturities of debt investments at October 28, 2023 (in thousands):

[0000936395-23-000044:notes:188]
|  | October 28, 2023 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 234,318 |  |  | $ | 234,029 |  |
| Due in 1-2 years | 134,455 |  |  | 134,278 |  |
|  | $ | 368,773 |  |  | $ | 368,307 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-23-000044:notes:189]
FAIR VALUE MEASUREMENTS
As of the dates indicated, the following tables summarize the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0000936395-23-000044:notes:190]
|  | October 28, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 661,101 |  |  | $ | — |  |  | $ | — |  |  | $ | 661,101 |  |
| Bond mutual fund | 104,171 |  |  | — |  |  | — |  |  | 104,171 |  |
| Time deposits | 138,829 |  |  | — |  |  | — |  |  | 138,829 |  |
| Deferred compensation plan assets | 11,456 |  |  | — |  |  | — |  |  | 11,456 |  |
| U.S. government obligations | — |  |  | 169,909 |  |  | — |  |  | 169,909 |  |
| Corporate debt securities | — |  |  | 59,569 |  |  | — |  |  | 59,569 |  |
| Foreign currency forward contracts | — |  |  | 1,119 |  |  | — |  |  | 1,119 |  |
| Interest rate swaps | — |  |  | 24,953 |  |  | — |  |  | 24,953 |  |
| Total assets measured at fair value | $ | 915,557 |  |  | $ | 255,550 |  |  | $ | — |  |  | $ | 1,171,107 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |

[0000936395-23-000044:notes:191]
|  | October 29, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 639,024 |  |  | $ | — |  |  | $ | — |  |  | $ | 639,024 |  |
| Bond mutual fund | 71,145 |  |  | — |  |  | — |  |  | 71,145 |  |
| Time deposits | 55,825 |  |  | — |  |  | — |  |  | 55,825 |  |
| Deferred compensation plan assets | 12,751 |  |  | — |  |  | — |  |  | 12,751 |  |
| U.S. government obligations | — |  |  | 134,584 |  |  | — |  |  | 134,584 |  |
| Commercial paper | — |  |  | 54,495 |  |  | — |  |  | 54,495 |  |
| Foreign currency forward contracts | — |  |  | 251 |  |  | — |  |  | 251 |  |
| Interest rate swaps | — |  |  | 12,306 |  |  | — |  |  | 12,306 |  |
| Total assets measured at fair value | $ | 778,745 |  |  | $ | 201,636 |  |  | $ | — |  |  | $ | 980,381 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |

[0000936395-23-000044:notes:192]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheets as follows (in thousands):

[0000936395-23-000044:notes:193]
|  | October 28, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 891,788 |  |  | $ | 2,760 |  |  | $ | — |  |  | $ | 894,548 |  |
| Short-term investments | 12,313 |  |  | 92,440 |  |  | — |  |  | 104,753 |  |
| Prepaid expenses and other | — |  |  | 1,119 |  |  | — |  |  | 1,119 |  |
| Long-term investments | — |  |  | 134,278 |  |  | — |  |  | 134,278 |  |
| Other long-term assets | 11,456 |  |  | 24,953 |  |  | — |  |  | 36,409 |  |
| Total assets measured at fair value | $ | 915,557 |  |  | $ | 255,550 |  |  | $ | — |  |  | $ | 1,171,107 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |

[0000936395-23-000044:notes:194]
|  | October 29, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 757,725 |  |  | $ | 7,974 |  |  | $ | — |  |  | $ | 765,699 |  |
| Short-term investments | 8,269 |  |  | 145,720 |  |  | — |  |  | 153,989 |  |
| Prepaid expenses and other | — |  |  | 251 |  |  | — |  |  | 251 |  |
| Long-term investments | — |  |  | 35,385 |  |  | — |  |  | 35,385 |  |
| Other long-term assets | 12,751 |  |  | 12,306 |  |  | — |  |  | 25,057 |  |
| Total assets measured at fair value | $ | 778,745 |  |  | $ | 201,636 |  |  | $ | — |  |  | $ | 980,381 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |

[0000936395-23-000044:notes:195]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-23-000044:notes:196]
ACCOUNTS RECEIVABLE
As of October 28, 2023, two customers accounted for 11.0% and 10.0% of net accounts receivable, respectively. As of October 29, 2022, two customers accounted for 13.0% and 11.0% of net accounts receivable, respectively. Ciena has not historically experienced a significant amount of bad debt expense. The following table summarizes the activity in Ciena’s allowance for credit losses for the fiscal years indicated (in thousands):

[0000936395-23-000044:notes:197]
| Year Ended |  | Beginning Balance |  | Effect of adoption of new accounting standard |  | Provisions |  | Net Deductions |  | Ending Balance |
| October 30, 2021 |  | $ | 10,598 |  |  | $ | 2,206 |  |  | $ | 2,346 |  |  | $ | 4,238 |  |  | $ | 10,912 |  |
| October 29, 2022(1) |  | $ | 10,912 |  |  | $ | — |  |  | $ | 4,199 |  |  | $ | 4,153 |  |  | $ | 10,958 |  |
| October 28, 2023 |  | $ | 10,958 |  |  | $ | — |  |  | $ | 5,718 |  |  | $ | 5,022 |  |  | $ | 11,654 |  |

[0000936395-23-000044:notes:198]
(1) On March 7, 2022, Ciena announced its decision to suspend its business operations in Russia immediately. As a result, Ciena’s allowance for doubtful accounts includes a provision for a significant asset impairment of $1.8 million for a trade receivable related to this decision.

[0000936395-23-000044:notes:199]
Accounts Receivable Factoring
During fiscal 2023 and 2022, the gross amount of trade accounts receivables sold totaled approximately $60.3 million and $11.8 million, respectively. Prior to the start of fiscal 2022, Ciena had not entered into any factoring arrangements. Factoring related expense recorded to interest and other income (loss), net was $3.1 million and $0.6 million for fiscal 2023 and fiscal 2022, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-23-000044:notes:200]
INVENTORIES
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-23-000044:notes:201]
|  | October 28, 2023 |  | October 29, 2022 |
| Raw materials | $ | 664,797 |  |  | $ | 664,916 |  |
| Work-in-process | 55,242 |  |  | 18,232 |  |
| Finished goods | 314,168 |  |  | 258,584 |  |
| Deferred cost of goods sold | 66,634 |  |  | 41,084 |  |
| Gross inventories | 1,100,841 |  |  | 982,816 |  |
| Reserve for excess and obsolescence | (50,003) |  |  | (36,086) |  |
| Inventories, net | $ | 1,050,838 |  |  | $ | 946,730 |  |

[0000936395-23-000044:notes:202]
Ciena has been expanding its manufacturing capacity and accumulating raw materials inventory of components that are available, in some cases with expanded lead times, in an effort to prepare Ciena to produce finished goods more quickly when supply constraints ease for certain common components, including integrated circuit components, for which delivery continues to be delayed. Raw materials inventory is related to the steps Ciena has taken to mitigate the impact of supply chain constraints on its business and customers in recent prior periods and the global market shortage of semiconductor parts. The increase in finished goods inventories resulted primarily from planned fulfillment of customer advance orders for which some deliveries have been rescheduled outside of fiscal 2023.

[0000936395-23-000044:notes:203]
Ciena makes estimates about future customer demand for its products when establishing the appropriate reserve for excess and obsolete inventory. For fiscal 2023, future demand was calculated using both customer backlog and future forecasted sales. For fiscal 2022, future demand was calculated primarily based on customer backlog. Generally, Ciena’s customers may cancel or change their orders with limited advance notice, or they may decide not to accept its products and services, although instances of both cancellation and non-acceptance are rare. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products,

[0000936395-23-000044:notes:204]
and general market conditions. During fiscal 2023, fiscal 2022 and fiscal 2021, Ciena recorded a provision for excess and obsolescence of $29.5 million, $16.2 million, and $17.9 million, respectively, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to the sale of previously reserved items and disposal activities.

[0000936395-23-000044:notes:205]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0000936395-23-000044:notes:206]
| Year Ended |  | Beginning Balance |  | Provisions |  | Disposals |  | Ending Balance |
| October 30, 2021 |  | $ | 39,637 |  |  | $ | 17,850 |  |  | $ | 20,528 |  |  | $ | 36,959 |  |
| October 29, 2022 |  | $ | 36,959 |  |  | $ | 16,184 |  |  | $ | 17,057 |  |  | $ | 36,086 |  |
| October 28, 2023 |  | $ | 36,086 |  |  | $ | 29,464 |  |  | $ | 15,547 |  |  | $ | 50,003 |  |


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-23-000044:notes:207]
PREPAID EXPENSES AND OTHER
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-23-000044:notes:208]
|  | October 28, 2023 |  | October 29, 2022 |
| Contract assets for unbilled accounts receivable, net | $ | 150,312 |  |  | $ | 156,039 |  |
| Prepaid VAT and other taxes | 96,724 |  |  | 63,975 |  |
| Prepaid expenses | 58,954 |  |  | 55,440 |  |
| Product demonstration equipment, net | 40,682 |  |  | 35,929 |  |
| Capitalized contract acquisition costs | 23,326 |  |  | 33,516 |  |
| Other non-trade receivables | 33,408 |  |  | 24,026 |  |
| Deferred deployment expense | 1,170 |  |  | 877 |  |
| Derivative assets | 1,118 |  |  | 251 |  |
|  | $ | 405,694 |  |  | $ | 370,053 |  |

[0000936395-23-000044:notes:209]
Depreciation of product demonstration equipment was $8.0 million, $8.7 million and $9.8 million for fiscal 2023, 2022 and 2021, respectively.

[0000936395-23-000044:notes:210]
For further discussion on contract assets and capitalized contract acquisition costs, see Note 2 above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-23-000044:notes:211]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0000936395-23-000044:notes:212]
|  | October 28, 2023 |  | October 29, 2022 |
| Equipment, furniture and fixtures | $ | 676,485 |  |  | $ | 619,160 |  |
| Building subject to finance lease | 67,904 |  |  | 69,247 |  |
| Leasehold improvements | 74,391 |  |  | 80,415 |  |
| Equipment, building, furniture and fixtures | 818,780 |  |  | 768,822 |  |
| Accumulated depreciation and amortization | (538,633) |  |  | (501,043) |  |
| Equipment, building, furniture and fixtures, net | $ | 280,147 |  |  | $ | 267,779 |  |

[0000936395-23-000044:notes:213]
During fiscal 2023, fiscal 2022 and fiscal 2021, Ciena recorded depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements of $84.6 million, $87.2 million and $86.5 million, respectively.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-23-000044:notes:214]
INTANGIBLE ASSETS
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-23-000044:notes:215]
|  | October 28, 2023 |  | October 29, 2022 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 503,618 |  |  | $ | (414,941) |  |  | $ | 88,677 |  |  | $ | 428,218 |  |  | $ | (386,300) |  |  | $ | 41,918 |  |
| In-process research and development | 89,100 |  |  | — |  |  | 89,100 |  |  | — |  |  | — |  |  | — |  |
| Patents and licenses | 8,795 |  |  | (5,203) |  |  | 3,592 |  |  | 8,415 |  |  | (4,228) |  |  | 4,187 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 410,983 |  |  | (386,725) |  |  | 24,258 |  |  | 390,271 |  |  | (366,859) |  |  | 23,412 |  |
| Total intangible assets | $ | 1,012,496 |  |  | $ | (806,869) |  |  | $ | 205,627 |  |  | $ | 826,904 |  |  | $ | (757,387) |  |  | $ | 69,517 |  |

[0000936395-23-000044:notes:216]
The aggregate amortization expense of intangible assets was $49.6 million, $44.3 million and $36.0 million for fiscal 2023, fiscal 2022 and fiscal 2021, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-23-000044:notes:217]
| Fiscal Year | Amount |  |  |
| 2024 | $ | 40,601 |  |  |  |
| 2025 | 34,582 |  |  |  |
| 2026 | 23,348 |  |  |  |
| 2027 | 15,843 |  |  |  |
| 2028 | 1,991 |  |  |  |
| Thereafter | 162 |  | (1) |  |
|  | $ | 116,527 |  |  |  |

[0000936395-23-000044:notes:218]
(1) Does not include amortization of in-process technology, as estimation of the timing of future amortization expense would be impractical.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-23-000044:notes:219]
GOODWILL
The following table presents the goodwill allocated to Ciena’s operating segments as of October 28, 2023 and October 29, 2022, as well as the changes to goodwill during fiscal 2023 (in thousands):

[0000936395-23-000044:notes:220]
|  | Balance at October 29, 2022 |  | Acquisitions |  |  |  | Translation |  | Balance at October 28, 2023 |
| Platform Software and Services | $ | 156,191 |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | 156,191 |  |
| Blue Planet Automation Software and Services | 89,049 |  |  | — |  |  |  |  | — |  |  | 89,049 |  |
| Networking Platforms | 83,082 |  |  | 116,644 |  |  |  |  | (201) |  |  | 199,525 |  |
| Total | $ | 328,322 |  |  | $ | 116,644 |  |  |  |  | $ | (201) |  |  | $ | 444,765 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-23-000044:notes:221]
OTHER BALANCE SHEET DETAILS
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-23-000044:notes:222]
|  | October 28, 2023 |  | October 29, 2022 |
| Maintenance spares inventory, net | $ | 54,042 |  |  | $ | 44,815 |  |
| Interest rate swaps | 24,953 |  |  | 12,306 |  |
| Deferred compensation plan assets | 11,456 |  |  | 12,751 |  |
| Cloud computing arrangements(1) | 8,589 |  |  | 6,050 |  |
| Capitalized contract acquisition costs | 6,879 |  |  | 6,151 |  |
| Deferred debt issuance costs, net(2) | 1,956 |  |  | 781 |  |
| Restricted cash | 168 |  |  | 26 |  |
| Cost method equity investments(3) | 48 |  |  | 20,698 |  |
| Other | 8,362 |  |  | 10,039 |  |
|  | $ | 116,453 |  |  | $ | 113,617 |  |

[0000936395-23-000044:notes:223]
(1) During fiscal 2023, fiscal 2022 and fiscal 2021, Ciena recorded amortization of cloud computing arrangements of $2.6 million, $2.8 million and $2.4 million, respectively.

[0000936395-23-000044:notes:224]
(2) Deferred debt issuance costs relate to Ciena’s senior secured revolving credit facility (the “Revolving Credit Facility”) entered into during fiscal 2023 and its predecessor asset-backed credit facility (described in Note 20 below). The amortization of deferred debt issuance costs for the Revolving Credit Facility and its predecessor is included in interest expense, and was $0.4 million for fiscal 2023, fiscal 2022 and fiscal 2021.

[0000936395-23-000044:notes:225]
(3) During the first quarter of fiscal 2023, Ciena acquired its previously held cost method equity investment in Tibit in a business combination, see Note 4 above.

[0000936395-23-000044:notes:226]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-23-000044:notes:227]
|  | October 28, 2023 |  | October 29, 2022 |
| Compensation, payroll related tax and benefits (1) | $ | 159,530 |  |  | $ | 126,338 |  |
| Warranty | 57,089 |  |  | 45,503 |  |
| Vacation | 29,503 |  |  | 26,396 |  |
| Income taxes payable | 16,341 |  |  | 11,472 |  |
| Foreign currency forward contracts | 14,509 |  |  | 15,604 |  |
| Interest payable | 4,514 |  |  | 4,793 |  |
| Finance lease liabilities | 3,953 |  |  | 3,758 |  |
| Other | 145,980 |  |  | 126,918 |  |
|  | $ | 431,419 |  |  | $ | 360,782 |  |

[0000936395-23-000044:notes:228]
(1) Increase is primarily due to a higher accrual rate related to Ciena’s 2023 annual cash incentive compensation plan.

[0000936395-23-000044:notes:229]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years indicated (in thousands):

[0000936395-23-000044:notes:230]
| Year Ended |  | Beginning Balance |  |  |  | Current Year Provisions |  |  |  | Settlements |  | Ending Balance |
| October 30, 2021 |  | $ | 49,868 |  |  |  |  | $ | 17,093 |  |  |  |  | $ | (18,942) |  |  | $ | 48,019 |  |
| October 29, 2022 |  | $ | 48,019 |  |  |  |  | $ | 17,440 |  |  |  |  | $ | (19,956) |  |  | $ | 45,503 |  |
| October 28, 2023 |  | $ | 45,503 |  |  |  |  | $ | 31,742 |  |  |  |  | $ | (20,156) |  |  | $ | 57,089 |  |

[0000936395-23-000044:notes:231]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-23-000044:notes:232]
|  | October 28, 2023 |  | October 29, 2022 |
| Finance lease liabilities | $ | 48,192 |  |  | $ | 53,176 |  |
| Income tax liability | 98,259 |  |  | 72,644 |  |
| Deferred compensation plan liability | 11,444 |  |  | 12,535 |  |
| Other | 12,512 |  |  | 11,980 |  |
|  | $ | 170,407 |  |  | $ | 150,335 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-23-000044:notes:233]
DERIVATIVE INSTRUMENTS
Foreign Currency Derivatives

[0000936395-23-000044:notes:234]
Ciena conducts business globally in many currencies, and thus is exposed to adverse foreign currency exchange rate changes. To limit this exposure, Ciena entered into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-23-000044:notes:235]
As of October 28, 2023 and October 29, 2022, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability that is principally related to research and development activities. The notional amount of these contracts was approximately $367.3 million and $272.2 million as of October 28, 2023 and October 29, 2022, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-23-000044:notes:236]
In May 2023, Ciena entered into forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. The notional amount of these contracts was approximately $48.0 million as of October 28, 2023. These foreign exchange contracts have maturities of 24 months or less and have been designated as net investment hedges.

[0000936395-23-000044:notes:237]
As of October 28, 2023 and October 29, 2022, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $226.3 million and $108.0 million as of October 28, 2023 and October 29, 2022, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-23-000044:notes:238]
Interest Rate Derivatives

[0000936395-23-000044:notes:239]
Ciena is exposed to floating rates of interest on its term loan borrowings (see Note 19 below) and has hedged such risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”).

[0000936395-23-000044:notes:240]
Prior to amending our term loan due September 28, 2025 (the “2025 Term Loan”) in January 2023, to replace LIBOR with the Secured Overnight Financing Rate (“SOFR”), Ciena was exposed to floating rates of LIBOR interest on its 2025 Term Loan borrowings. In October 2018, Ciena hedged this risk by entering into interest rate swaps to fix the LIBOR rate for the first $350.0 million of its floating rate debt at 2.957% through September 2023. In January 2023, Ciena entered into a LIBOR to SOFR basis swap (“basis swap”) to hedge its exposure to SOFR rate. The basis swap offset the LIBOR exposure risk of the interest rate swaps and effectively fixed the SOFR rate for the first $350.0 million of its floating rate debt at 2.883% through September 2023. These swaps expired in September 2023. In April 2022, Ciena entered into forward starting interest rate swaps to fix the SOFR rate for the first $350.0 million its floating rate debt at 2.968% from September 2023 through September 2025 (“2025 interest rate swaps”). The total notional amount of the 2025 interest swaps was $350.0 million as of October 28, 2023.

[0000936395-23-000044:notes:241]
In January 2023, Ciena entered into interest rate swaps to fix the SOFR rate for an additional $350.0 million of its floating rate debt at 3.47% through January 2028 (“2028 interest rate swaps”). The total notional amount of the 2028 interest rate swaps in effect as of October 28, 2023 was $350.0 million.

[0000936395-23-000044:notes:242]
Ciena expects the variable rate payments to be received under the terms interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amount of the 2030 New Term Loan (as defined in Note 19 below). These derivative contracts have been designated as cash flow hedges.

[0000936395-23-000044:notes:243]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Notes 6 and 8 above.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-23-000044:notes:244]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax (in thousands):

[0000936395-23-000044:notes:245]
|  |  | Unrealized Gain (Loss) on |  |  |  |  |
|  |  | Available-for-Sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 31, 2020 |  | $ | 45 |  |  | $ | (219) |  |  | $ | (21,535) |  |  | $ | (13,649) |  |  | $ | (35,358) |  |
| Other comprehensive gain (loss) before reclassifications |  | (209) |  |  | 16,856 |  |  | (261) |  |  | 20,215 |  |  | 36,601 |  |
| Amounts reclassified from AOCI |  | — |  |  | (10,421) |  |  | 9,617 |  |  | — |  |  | (804) |  |
| Balance at October 30, 2021 |  | (164) |  |  | 6,216 |  |  | (12,179) |  |  | 6,566 |  |  | 439 |  |
| Other comprehensive gain (loss) before reclassifications |  | (2,801) |  |  | (16,299) |  |  | 14,512 |  |  | (49,446) |  |  | (54,034) |  |
| Amounts reclassified from AOCI |  | — |  |  | (114) |  |  | 7,064 |  |  | — |  |  | 6,950 |  |
| Balance at October 29, 2022 |  | (2,965) |  |  | (10,197) |  |  | 9,397 |  |  | (42,880) |  |  | (46,645) |  |
| Other comprehensive gain (loss) before reclassifications |  | 2,593 |  |  | (8,455) |  |  | 19,600 |  |  | (5,321) |  |  | 8,417 |  |
| Amounts reclassified from AOCI |  | — |  |  | 10,496 |  |  | (10,035) |  |  | — |  |  | 461 |  |
| Balance at October 28, 2023 |  | $ | (372) |  |  | $ | (8,156) |  |  | $ | 18,962 |  |  | $ | (48,201) |  |  | $ | (37,767) |  |

[0000936395-23-000044:notes:246]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense on the Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Consolidated Statements of Operations.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000936395-23-000044:notes:247]
LEASES
Ciena leases over 1.1 million square feet of facilities globally. Ciena’s corporate headquarters are located in Hanover, Maryland. Ciena’s largest facilities are research and development centers located in Ottawa, Canada and Gurgaon, India. Ciena also leases smaller engineering facilities in the United States, Canada, and Europe. In addition, Ciena leases various smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. Ciena's current leases have remaining terms that vary up to 9 years. Certain leases provide for options to extend up to 10 years and/or options to terminate within 4 years.

[0000936395-23-000044:notes:248]
Leases included in the Consolidated Balance Sheets for the fiscal periods indicated were as follows (in thousands):

[0000936395-23-000044:notes:249]
|  | Classification |  | Balance at October 28, 2023 |  | Balance at October 29, 2022 |
| Operating leases: |  |  |  |  |  |
| Operating ROU Assets | Operating right-of-use assets |  | $ | 35,140 |  |  | $ | 45,108 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | $ | 49,914 |  |  | $ | 61,317 |  |
| Finance leases: |  |  |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 67,904 |  |  | $ | 69,247 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (30,079) |  |  | (26,266) |  |
| Buildings, net |  |  | $ | 37,825 |  |  | $ | 42,981 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 52,145 |  |  | $ | 56,934 |  |

[0000936395-23-000044:notes:250]
ROU assets that involve subleased or vacant space aggregate $7.5 million as of October 28, 2023. Finance lease buildings, net, that involve subleased or vacant space aggregate $6.0 million as of October 28, 2023. These assets may become impaired if tenants are unable to service their obligations under the sublease, and/or if the estimates as to occupancy are not realized.

[0000936395-23-000044:notes:251]
For the periods indicated, the components of lease expense included in the Consolidated Statements of Operations were as follows (in thousands):

[0000936395-23-000044:notes:252]
|  |  |  | Year Ended |  | Year Ended |  | Year Ended |
|  | Classification |  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Operating lease costs | Operating expense |  | $ | 16,080 |  |  | $ | 17,966 |  |  | $ | 16,602 |  |
| Finance lease cost: |  |  |  |  |  |  |  |
| Amortization of finance ROU asset | Operating expense |  | 4,448 |  |  | 4,592 |  |  | 4,773 |  |
| Interest on finance lease liabilities | Interest expense |  | 4,069 |  |  | 4,601 |  |  | 4,882 |  |
| Total finance lease cost |  |  | 8,517 |  |  | 9,193 |  |  | 9,655 |  |
| Non-capitalized lease cost | Operating expense |  | 910 |  |  | 917 |  |  | 1,152 |  |
| Variable lease cost(1) | Operating expense |  | 3,421 |  |  | 5,898 |  |  | 5,690 |  |
| Net lease cost(2) |  |  | $ | 28,928 |  |  | $ | 33,974 |  |  | $ | 33,099 |  |

[0000936395-23-000044:notes:253]
(1) Variable lease costs include expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0000936395-23-000044:notes:254]
(2) Excludes other operating expense of $6.5 million, $12.8 million, and $8.8 million for the fiscal years ended October 28, 2023, October 29, 2022, and October 30, 2021, respectively, related to amortization of leasehold improvements.

[0000936395-23-000044:notes:255]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of October 28, 2023 were as follows (in thousands):

[0000936395-23-000044:notes:256]
|  | Operating Leases |  | Finance Leases |  | Total |
| 2024 | $ | 18,126 |  |  | $ | 7,640 |  |  | $ | 25,766 |  |
| 2025 | 13,568 |  |  | 7,793 |  |  | 21,361 |  |
| 2026 | 9,951 |  |  | 7,824 |  |  | 17,775 |  |
| 2027 | 5,563 |  |  | 8,095 |  |  | 13,658 |  |
| 2028 | 1,516 |  |  | 8,367 |  |  | 9,883 |  |
| Thereafter | 5,796 |  |  | 31,435 |  |  | 37,231 |  |
| Total lease payments | 54,520 |  |  | 71,154 |  |  | 125,674 |  |
| Less: Imputed interest | (4,606) |  |  | (19,009) |  |  | (23,615) |  |
| Present value of lease liabilities | 49,914 |  |  | 52,145 |  |  | 102,059 |  |
| Less: Current portion of present value of minimum lease payments | 16,655 |  |  | 3,953 |  |  | 20,608 |  |
| Long-term portion of present value of minimum lease payments | $ | 33,259 |  |  | $ | 48,192 |  |  | $ | 81,451 |  |

[0000936395-23-000044:notes:257]
The weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows (in thousands):

[0000936395-23-000044:notes:258]
| Weighted-average remaining lease term in years: | As of October 28, 2023 |  | As of October 29, 2022 |
| Operating leases | 4.07 |  | 3.85 |
| Finance leases | 8.71 |  | 9.71 |
| Weighted-average discount rates: |  |  |  |
| Operating leases | 3.88 | % |  | 2.97 | % |
| Finance leases | 7.56 | % |  | 7.56 | % |


## us-gaap:DebtDisclosureTextBlock

[0000936395-23-000044:notes:259]
SHORT-TERM AND LONG-TERM DEBT
2030 New Term Loan

[0000936395-23-000044:notes:260]
On October 24, 2023, Ciena, together with certain of its domestic subsidiaries as guarantors, entered into an Incremental Amendment Agreement (the “Amendment”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, certain of its subsidiaries, the lenders party thereto, and Bank of America, N.A., as administrative agent (“Bank of America”), to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $1.2 billion (the “2030 New Term Loan”) and a new senior secured revolving credit facility of $300 million (the “Revolving Credit Facility” as defined in Note 20 below).

[0000936395-23-000044:notes:261]
The proceeds of the 2030 New Term Loan, net of original issuance discount, replaced, in full, $668.7 million of outstanding principal of the 2025 Term Loan and $497.5 million of outstanding principal of the 2030 Term Loan (as defined below) (“Refinanced Term Loans”), including accrued interest, and pay transaction fees and expenses, resulting in proceeds of $0.8 million. The 2030 New Term Loan requires Ciena to make installment payments of $2.9 million on a quarterly basis.

[0000936395-23-000044:notes:262]
Based on the continuation of existing lenders and the addition of new lenders, this arrangement was primarily accounted for as a modification of debt and, as such, $6.0 million of debt issuance costs associated with the 2030 New Term Loan were expensed. The aggregate balance of approximately $4.4 million of debt issuance costs and approximately $2.2 million of original discount from the 2025 Term Loan and 2030 Term Loan, $0.1 million of debt issuance costs associated with new lenders for the 2030 New Term Loan, and approximately $2.9 million of original discount from the 2030 New Term Loan, were included in the carrying value of the 2030 New Term Loan.

[0000936395-23-000044:notes:263]
The Amendment amends the Credit Agreement and provides that the 2030 New Term Loan will, among other things:

[0000936395-23-000044:notes:264]
•mature on October 24, 2030;

[0000936395-23-000044:notes:265]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2030 New Term Loan as of January 19, 2023, or $2.9 million, or $11.7 million annually, with the balance payable at maturity;

[0000936395-23-000044:notes:266]
•be subject to mandatory prepayment upon the occurrence of certain specified events substantially similar to the Refinanced Term Loans, including upon the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-23-000044:notes:267]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 2.00%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.00%; and

[0000936395-23-000044:notes:268]
•be repayable at any time at Ciena’s election, provided that repayment of the 2030 New Term Loan with proceeds of certain indebtedness prior to April 24, 2024 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.

[0000936395-23-000044:notes:269]
Among other things, the Amendment also amends the Credit Agreement by (i) modifying the “accordion” feature to provide for incremental term loan facilities (the “Incremental Term Loans”) in an aggregate amount not to exceed the sum of (A) the greater of (1) $640 million and (2) an amount equal to consolidated EBITDA on a pro forma basis for the most recently ended four-quarter period and (B) an amount (1) in the case of secured incremental term facilities that rank pari passu with or junior to the 2030 New Term Loan, such that the Total Secured Net Leverage Ratio (as defined in the Credit Agreement) would not be greater than 3.00 to 1.00 at the time of incurrence and (2) in the case of unsecured incremental term facilities, such that the Interest Coverage Ratio (as defined in the Credit Agreement) would not be less than 2.00 to 1.00 at the time of incurrence, subject to certain conditions, including obtaining commitments from any one or more lenders, whether or not currently party to the Credit Agreement, to provide such increased amounts and (ii) amending certain negative covenants.

[0000936395-23-000044:notes:270]
The net carrying value of the 2030 New Term Loan was comprised of the following as of the date indicated (in thousands):

[0000936395-23-000044:notes:271]
|  |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 New Term Loan |  | $ | 1,170,000 |  |  | $ | (5,122) |  |  | $ | (5,507) |  |  | $ | 1,159,371 |  |  |  |

[0000936395-23-000044:notes:272]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 New Term Loan totaled $5.5 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 New Term Loan. The amortization of deferred debt issuance costs for the 2030 New Term Loan is included in interest expense, and was $0.1 million during fiscal 2023.

[0000936395-23-000044:notes:273]
As of October 28, 2023, the estimated fair value of the 2030 New Term Loan was $1.2 billion. The 2030 New Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 New Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-23-000044:notes:274]
Refinanced Term Loans

[0000936395-23-000044:notes:275]
The proceeds of the 2030 New Term Loan, net of original issuance discount, was used to repay in full $1.2 billion of outstanding principal of the Refinanced Term Loans, including accrued interest.

[0000936395-23-000044:notes:276]
2025 Term Loan

[0000936395-23-000044:notes:277]
On January 19, 2023, in connection with the Incremental Agreement (as defined below) to the Credit Agreement (as defined below), the Credit Agreement was amended to replace LIBOR with SOFR for the 2025 Term Loan in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform. The net carrying value of the 2025 Term Loan as of October 29, 2022 was $673.0 million. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.6 million for fiscal 2023 and fiscal 2022.

[0000936395-23-000044:notes:278]
2030 Term Loan

[0000936395-23-000044:notes:279]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended, by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan were intended to be used for general corporate purposes.

[0000936395-23-000044:notes:280]
The Incremental Agreement amended the Credit Agreement and provided that the 2030 Term Loan would, among other things:

[0000936395-23-000044:notes:281]
•mature on January 19, 2030;

[0000936395-23-000044:notes:282]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2030 Term Loan as of January 19, 2023, or $1.25 million, with the balance payable at maturity;

[0000936395-23-000044:notes:283]
•be subject to mandatory prepayment on the same basis as the 2025 Term Loan, including on the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-23-000044:notes:284]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.50%; and

[0000936395-23-000044:notes:285]
•be repayable at any time at Ciena’s election, provided that repayment of the 2030 Term Loan with proceeds of certain indebtedness prior to July 19, 2023 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.

[0000936395-23-000044:notes:286]
Except as amended by the Incremental Agreement, the remaining terms of the Credit Agreement remained in full force and effect.

[0000936395-23-000044:notes:287]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was $0.5 million for fiscal 2023.

[0000936395-23-000044:notes:288]
2030 Notes

[0000936395-23-000044:notes:289]
On January 18, 2022, Ciena entered into an Indenture (the “Indenture”) among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors (collectively, the “Guarantors”), and U.S. Bank National Association, as trustee (the “Trustee”), pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0000936395-23-000044:notes:290]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):

[0000936395-23-000044:notes:291]
|  |  | October 28, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,265) |  |  | $ | 395,735 |  |  | $ | 395,045 |  |  |  |

[0000936395-23-000044:notes:292]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.3 million as of October 28, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.7 million during fiscal 2023 and $0.5 million during fiscal 2022.

[0000936395-23-000044:notes:293]
As of October 28, 2023, the estimated fair value of the 2030 Notes was $330.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
REVOLVING CREDIT FACILITY
On February 10, 2023, pursuant to an ABL Credit Agreement dated October 28, 2019, as amended (the “ABL Credit Agreement”), by and among Ciena, certain of its subsidiaries, the lenders party thereto (the “ABL Lenders”), and Bank of America, as administrative agent, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provided for a total commitment of $300.0 million to extend its maturity date to September 28, 2025.

[0000936395-23-000044:notes:294]
On October 24, 2023 (the “Closing Date”), pursuant to the Incremental Amendment Agreement to the Credit Agreement (as defined in Note 19 above), Ciena incurred a new senior secured revolving credit facility of $300.0 million (the “Revolving Credit Facility”), which replaced the ABL Credit Facility. Ciena has the option to increase the total revolving commitments under the Revolving Credit Facility to $450.0 million, subject to certain conditions, including obtaining commitments from one or more lenders. The Credit Agreement provides that $200.0 million of the Revolving Credit Facility is available for issuances

[0000936395-23-000044:notes:295]
of letters of credit and allows for swingline loans in an amount not to exceed $50.0 million. On or about the Closing Date, Ciena transferred to the Revolving Credit Facility certain outstanding letters of credit initially issued under the ABL Credit Facility with an undrawn amount of approximately $65.1 million. There were no borrowings outstanding under the ABL Credit Facility as of the Closing Date. Ciena expects to use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and for general corporate purposes.

[0000936395-23-000044:notes:296]
The Credit Agreement provides that the Revolving Credit Facility will, among other things:

[0000936395-23-000044:notes:297]
•mature on October 24, 2028;

[0000936395-23-000044:notes:298]
•bear interest on outstanding borrowings, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus a credit spread adjustment of 0.10% plus an applicable margin ranging from 1.375% to 2.00%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin ranging from 0.375% to 1.00%, in each case, with the actual margin determined according to the Total Net Leverage Ratio (as defined in the Credit Agreement above);

[0000936395-23-000044:notes:299]
•have a commitment fee payable on the unused portion of the Revolving Credit Facility at a per annum rate ranging from 0.225% to 0.300%, with the actual rate determined according to the Total Net Leverage Ratio; and

[0000936395-23-000044:notes:300]
•include a restriction on the aggregate amount of Incremental Term Loans and certain other indebtedness that can be incurred in the future equal to an amount that would not result in the Total Net Leverage Ratio exceeding 5.00 to 1.00 at the time of incurrence.

[0000936395-23-000044:notes:301]
The obligations under the Revolving Credit Facility are guaranteed by all of Ciena’s subsidiaries that currently, or in the future are required to, guarantee the obligations of the 2030 New Term Loan, including, as of the Closing Date, Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., and are secured on a pari passu basis with the 2030 New Term Loan by a pledge of substantially all of the assets of Ciena and the guarantors. Upon the occurrence of certain events related to the improvement of Ciena’s credit rating and repayment of all secured term loans (“Investment Grade Events”), all collateral securing the obligations under the Revolving Credit Facility will be released at Ciena’s election.

[0000936395-23-000044:notes:302]
Under the Revolving Credit Facility, Ciena is also required to maintain certain financial maintenance covenants, including:

[0000936395-23-000044:notes:303]
•prior to an Investment Grade Event, a maximum Total Secured Net Leverage Ratio of no greater than 3.50 to 1.00 as of the end of any period of four fiscal quarters (provided, that in the event Ciena consummates a qualifying acquisition, Ciena can elect to increase the maximum Total Secured Net Leverage Ratio level to 4.00 to 1.00 for the fiscal quarter in which such qualifying acquisition is consummated and for the next five consecutive fiscal quarters);

[0000936395-23-000044:notes:304]
•on or after an Investment Grade Event, a maximum Total Net Leverage Ratio of no greater than 4.00 to 1.00 as of the end of any period of four fiscal quarters; and

[0000936395-23-000044:notes:305]
•a minimum Interest Coverage Ratio of no less than 3.00 to 1.00 as of the end of any period of four fiscal quarters.

[0000936395-23-000044:notes:306]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.

[0000936395-23-000044:notes:307]
As of October 28, 2023, Ciena was in compliance with the above financial maintenance covenants. As of October 28, 2023, letters of credit totaling $72.5 million were issued under our Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of October 28, 2023.


## us-gaap:EarningsPerShareTextBlock

[0000936395-23-000044:notes:308]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-23-000044:notes:309]
The following table presents the calculation of Basic and Diluted EPS (in thousands except per share amounts):

[0000936395-23-000044:notes:310]
|  | Year Ended |
|  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Net income | $ | 254,827 |  |  | $ | 152,902 |  |  | $ | 500,196 |  |
| Basic weighted average shares outstanding | 148,971 |  |  | 151,208 |  |  | 155,279 |  |
| Effect of dilutive potential common shares | 409 |  |  | 985 |  |  | 1,464 |  |
| Diluted weighted average shares outstanding | 149,380 |  |  | 152,193 |  |  | 156,743 |  |
| Basic EPS | $ | 1.71 |  |  | $ | 1.01 |  |  | $ | 3.22 |  |
| Diluted EPS | $ | 1.71 |  |  | $ | 1.00 |  |  | $ | 3.19 |  |
| Antidilutive employee share-based awards, excluded | 2,675 |  | 1,370 |  | 110 |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-23-000044:notes:311]
STOCKHOLDERS’ EQUITY
Stock Repurchase Program and Accelerated Share Repurchase Agreement

[0000936395-23-000044:notes:312]
On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of Ciena’s common stock. During fiscal 2021, Ciena repurchased 1.7 million shares of its common stock, for an aggregate purchase price of $92.1 million at an average price of $54.27 per share. Under this program, Ciena repurchased a total of 7.4 million shares of its common stock, for an aggregate purchase price of $316.7 million at an average price of $42.75 per share.

[0000936395-23-000044:notes:313]
On December 9, 2021, Ciena announced that its Board of Directors replaced its previously authorized program, as described above, with a program to repurchase up to $1.0 billion of its common stock. On December 13, 2021, Ciena entered into an accelerated share repurchase agreement (the “ASR Agreement”) with Goldman, Sachs & Co. LLC (“Goldman”) to repurchase $250.0 million (the “Repurchase Price”) of its common stock as part of the repurchase program. Under the terms of the ASR Agreement, Ciena paid the Repurchase Price to Goldman, and received approximately 3.6 million shares of its common stock from Goldman, calculated based on the average of the volume-weighted average prices of Ciena’s common stock of $69.78 for the period from December 14, 2021 to February 11, 2022, less a discount, which completed the repurchases contemplated by the ASR Agreement. Shares repurchased pursuant to the ASR Agreement were immediately retired upon receipt. During the remainder of fiscal 2022, Ciena repurchased an additional 4.8 million shares of its common stock, for an aggregate purchase price of $250.0 million at an average price of $51.53 per share.

[0000936395-23-000044:notes:314]
During fiscal 2023, Ciena repurchased an additional 5.7 million shares of its common stock, for an aggregate purchase price of $250.0 million at an average price of $44.08 per share. As of October 28, 2023, Ciena has repurchased an aggregate of 14.1 million shares for an aggregate purchase price of $750.0 million at an average price of $53.17 per share and has an aggregate of $250.0 million of authorized funds remaining under its stock repurchase program.

[0000936395-23-000044:notes:315]
The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-23-000044:notes:316]
Impact of Inflation Reduction Act 1% Excise Tax on Share Repurchases

[0000936395-23-000044:notes:317]
Beginning fiscal 2023, a 1% excise tax on the market value of shares repurchased offset by 1% of the market value of shares issued was implemented. During fiscal 2023, a net excise tax of $1.5 million was recorded to additional paid-in capital on the Consolidated Balance Sheets.

[0000936395-23-000044:notes:318]
Stock Repurchases Related to Restricted Stock Unit Tax Withholdings

[0000936395-23-000044:notes:319]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The related purchase price of $38.5 million for the shares of Ciena’s stock repurchased during fiscal 2023 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-23-000044:notes:320]
INCOME TAXES
For the periods indicated, the provision (benefit) for income taxes consists of the following (in thousands):

[0000936395-23-000044:notes:321]
|  | Year Ended |
|  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Provision (benefit) for income taxes: |  |  |  |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | 36,537 |  |  | $ | 27,479 |  |  | $ | 72,603 |  |
| State | 18,860 |  |  | 10,289 |  |  | 21,400 |  |
| Foreign | 28,281 |  |  | 19,337 |  |  | 25,021 |  |
| Total current | 83,678 |  |  | 57,105 |  |  | 119,024 |  |
| Deferred: |  |  |  |  |  |
| Federal | (8,010) |  |  | (30,032) |  |  | (21,942) |  |
| State | (17,354) |  |  | 520 |  |  | (11,546) |  |
| Foreign | 10,512 |  |  | 2,010 |  |  | (122,981) |  |
| Total deferred | (14,852) |  |  | (27,502) |  |  | (156,469) |  |
| Provision (benefit) for income taxes | $ | 68,826 |  |  | $ | 29,603 |  |  | $ | (37,445) |  |

[0000936395-23-000044:notes:322]
For the periods indicated, income before provision (benefit) for income taxes consists of the following (in thousands):

[0000936395-23-000044:notes:323]
|  | Year Ended |
|  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| United States | $ | 93,682 |  |  | $ | 28,784 |  |  | $ | 298,514 |  |
| Foreign | 229,971 |  |  | 153,721 |  |  | 164,237 |  |
| Total | $ | 323,653 |  |  | $ | 182,505 |  |  | $ | 462,751 |  |

[0000936395-23-000044:notes:324]
Ciena’s foreign income tax as a percentage of foreign income may appear disproportionate compared to the expected tax based on the U.S. federal statutory rate and is dependent on the mix of earnings and tax rates in foreign jurisdictions.

[0000936395-23-000044:notes:325]
For the periods indicated, the tax provision reconciles to the amount computed by multiplying income before income taxes by the U.S. federal statutory rate of 21% for fiscal 2023, fiscal 2022 and fiscal 2021 as follows:

[0000936395-23-000044:notes:326]
|  | Year Ended |
|  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Provision at statutory rate | 21.00 | % |  | 21.00 | % |  | 21.00 | % |
| Intercompany IP Restructuring Transaction | — | % |  | — | % |  | (25.85) | % |
| State taxes | 1.65 | % |  | 2.31 | % |  | 3.73 | % |
| Withholding and other foreign taxes | (0.09) | % |  | (1.37) | % |  | 2.76 | % |
| Research and development credit | (16.78) | % |  | (23.66) | % |  | (7.99) | % |
| Non-deductible compensation | 5.29 | % |  | 5.26 | % |  | 1.68 | % |
| Foreign derived intangible income | — | % |  | — | % |  | (1.82) | % |
| US Taxation on foreign activity | 5.08 | % |  | 1.73 | % |  | — | % |
| Foreign Nontaxable interest | (1.06) | % |  | (1.90) | % |  | — | % |
| Taxation on foreign inflation | 1.34 | % |  | 1.41 | % |  | 0.16 | % |
| Rate change | (3.71) | % |  | 1.27 | % |  | (4.33) | % |
| Valuation allowance | 9.44 | % |  | 8.35 | % |  | 1.77 | % |
| Loss on equity transactions | (1.72) | % |  | — | % |  | — | % |
| Uncertain tax positions | 1.72 | % |  | 1.62 | % |  | 0.63 | % |
| Other | (0.89) | % |  | 0.20 | % |  | 0.17 | % |
| Effective income tax rate | 21.27 | % |  | 16.22 | % |  | (8.09) | % |

[0000936395-23-000044:notes:327]
Our future income tax provisions and deferred tax balances may be affected by the amount of pre-tax income, the jurisdictions where it is earned, the existence and ability to utilize tax attributes and changes in tax laws and business reorganizations.

[0000936395-23-000044:notes:328]
In fiscal 2021, Ciena began implementation of a plan to reorganize its global supply chain and distribution structure more substantially, which included a legal entity reorganization and related system upgrade. Ciena completed the first phase of this plan in fiscal 2021, and substantially completed the reorganization during fiscal 2022. As part of this reorganization, Ciena completed an internal transfer of certain of its non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $119.3 million deferred tax asset with a corresponding tax benefit. The impact of this transfer is reflected in Ciena’s effective tax rate for the year ended October 30, 2021, which had a significant, one-time impact on its net income for the period.

[0000936395-23-000044:notes:329]
Ciena is also required to make accounting policy elections as a result of the Tax Act. These include whether a valuation allowance is recorded for the estimated effect of the application of GILTI and BEAT or if these will be treated as period costs when incurred. Ciena had made the incremental cash tax cost policy election with respect to analyzing the impact of GILTI on the assessment of the realizability of net operating losses. The realizability of U.S. tax carryforwards is not impacted by the BEAT, and the BEAT is a period cost when incurred. Ciena is also required to elect to treat taxes due on future GILTI inclusions in U.S. taxable income either as a current period expense when incurred or reflect such portion of the future GILTI inclusions in U.S. taxable income that relate to existing basis differences in Ciena’s current measurement of deferred taxes. Ciena’s accounting policy election is to treat the taxes due on future U.S. inclusions in taxable income under GILTI as a period cost when incurred.

[0000936395-23-000044:notes:330]
The significant components of deferred tax assets are as follows (in thousands):

[0000936395-23-000044:notes:331]
|  | Year Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 82,160 |  |  | $ | 76,839 |  |
| Depreciation and amortization | 712,098 |  |  | 690,636 |  |
| NOL and credit carry forward | 197,984 |  |  | 154,707 |  |
| Other | 6,934 |  |  | 63,902 |  |
| Gross deferred tax assets | 999,176 |  |  | 986,084 |  |
| Valuation allowance | (189,870) |  |  | (162,076) |  |
| Deferred tax asset, net of valuation allowance | $ | 809,306 |  |  | $ | 824,008 |  |

[0000936395-23-000044:notes:332]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0000936395-23-000044:notes:333]
|  | Amount |
| Unrecognized tax benefits at October 31, 2020 | $ | 95,748 |  |
| Decrease related to positions taken in prior period | (22,854) |  |
| Reductions related to settlements with taxing authorities | (654) |  |
| Increase related to positions taken in current period | 5,510 |  |
| Reductions related to expiration of statute of limitations | (659) |  |
| Unrecognized tax benefits at October 30, 2021 | 77,091 |  |
| Increase related to positions taken in prior period | 4,732 |  |
| Reductions related to settlements with taxing authorities | (3,229) |  |
| Increase related to positions taken in current period | 2,959 |  |
| Reductions related to expiration of statute of limitations | (1,039) |  |
| Unrecognized tax benefits at October 29, 2022 | 80,514 |  |
| Increase related to positions taken in prior period | 9,940 |  |
| Reductions related to settlements with taxing authorities | (625) |  |
| Increase related to positions taken in current period | 4,960 |  |
| Reductions related to expiration of statute of limitations | (869) |  |
| Unrecognized tax benefits at October 28, 2023 | $ | 93,920 |  |

[0000936395-23-000044:notes:334]
As of October 28, 2023 and October 29, 2022, Ciena had accrued $7.9 million and $5.2 million of interest and penalties, respectively, related to unrecognized tax benefits included in other long-term obligations in the Consolidated Balance Sheets. Interest and penalties of $2.7 million and $1.7 million were recorded as a net expense to the provision for income taxes during fiscal 2023 and 2022, respectively. During fiscal 2021, Ciena recorded a net benefit to the provision for interest and penalties in its provision for income taxes of $0.1 million. If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate. Over the next 12 months, Ciena does not estimate any material changes in unrecognized income tax benefits.

[0000936395-23-000044:notes:335]
During the fourth quarter of fiscal 2023, Ciena evaluated the undistributed earnings of its foreign subsidiaries and identified approximately $222.0 million in earnings that are no longer considered to be indefinitely reinvested. Ciena recorded a provision of $2.5 million that reflects the income tax effects of the repatriation of these earnings. No additional income tax expense has been provided for any remaining undistributed foreign earnings, or any additional outside basis difference from investments in the foreign subsidiaries, as these amounts continue to be indefinitely reinvested. If the remaining undistributed foreign earnings and profits of $381.0 million were repatriated to the U.S., the provisional amount of unrecognized deferred tax liability, which is primarily related to foreign withholding taxes, is an estimated $30.0 million; however, the amount may be lower depending on Ciena’s ability to utilize tax credits associated with the distribution. Additionally, there are no other significant temporary differences for which a deferred tax liability or asset has not been recognized.

[0000936395-23-000044:notes:336]
As of October 28, 2023, Ciena continues to maintain a valuation allowance of $189.9 million against its gross deferred tax assets primarily. The valuation allowance is primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use.

[0000936395-23-000044:notes:337]
The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0000936395-23-000044:notes:338]
| Year Ended |  | Beginning Balance |  | Additions |  | Deductions |  | Ending Balance |
| October 30, 2021 |  | $ | 151,427 |  |  | $ | 17,897 |  |  | $ | 9,690 |  |  | $ | 159,634 |  |
| October 29, 2022 |  | $ | 159,634 |  |  | $ | 15,245 |  |  | $ | 12,803 |  |  | $ | 162,076 |  |
| October 28, 2023 |  | $ | 162,076 |  |  | $ | 28,746 |  |  | $ | 952 |  |  | $ | 189,870 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-23-000044:notes:339]
SHARE-BASED COMPENSATION EXPENSE
Ciena has outstanding equity awards issued under its 2017 Omnibus Incentive Plan (the “2017 Plan”), its 2008 Omnibus Incentive Plan, and certain legacy equity plans and equity plans assumed as a result of previous acquisitions. All equity awards granted on or after March 23, 2017 are made exclusively from the 2017 Plan. Ciena also makes shares of its common stock available for purchase under the ESPP. Each of the 2017 Plan and the ESPP are described below.

[0000936395-23-000044:notes:340]
2017 Plan

[0000936395-23-000044:notes:341]
The 2017 Plan has a ten-year term and authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2017 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2017 Plan to vest, unless the awards are continued or substituted for in connection with the transaction.

[0000936395-23-000044:notes:342]
The 2017 Plan authorizes and reserves 21.1 million shares for issuance. The number of shares available under the 2017 Plan are also increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena’s prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition of another company. As of October 28, 2023, the total number of shares authorized for issuance under the 2017 Plan was 21.1 million and approximately 5.6 million shares remained available for issuance thereunder.

[0000936395-23-000044:notes:343]
Stock Options

[0000936395-23-000044:notes:344]
There were no stock options granted by Ciena during fiscal 2023, fiscal 2022 or fiscal 2021. Outstanding stock option awards granted to employees in prior periods are generally subject to service-based vesting conditions and vest over a four-year period. The following table is a summary of Ciena’s stock option activity for the periods indicated (shares in thousands):

[0000936395-23-000044:notes:345]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 29, 2022 | 32 |  |  | $ | 30.98 |  |
| Granted | — |  |  | — |  |
| Exercised | (22) |  |  | $ | 33.98 |  |
| Canceled | (3) |  |  | $ | 45.32 |  |
| Balance at October 28, 2023 | 7 |  |  | $ | 16.94 |  |

[0000936395-23-000044:notes:346]
The total intrinsic value of options exercised during fiscal 2023, fiscal 2022 and fiscal 2021 was $0.3 million, $1.6 million and $0.5 million, respectively.

[0000936395-23-000044:notes:347]
The following table summarizes information with respect to stock options outstanding at October 28, 2023, based on Ciena’s closing stock price on the last trading day of Ciena’s fiscal 2023 (shares and intrinsic value in thousands):

[0000936395-23-000044:notes:348]
|  |  |  |  |  |  | Options Outstanding and Vested at |  |  |
|  |  |  |  |  |  | October 28, 2023 |  |  |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  |  |  |  |  |  |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  |  |  |  |  |  |  |  |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  |  |  |  |  |  |  |  |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  |  |  |  |  |  |  |  |
| $ | 14.38 |  |  | — |  |  | $ | 18.22 |  |  | 7 |  |  | 0.36 |  | $ | 16.94 |  |  | $ | 178 |  |  |  |  |  |  |  |  |  |

[0000936395-23-000044:notes:349]
Assumptions for Option-Based Awards

[0000936395-23-000044:notes:350]
Ciena recognizes the fair value of stock options as share-based compensation expense on a straight-line basis over the requisite service period. Ciena did not grant any option-based awards during fiscal 2023, fiscal 2022 or fiscal 2021.

[0000936395-23-000044:notes:351]
Restricted Stock Units

[0000936395-23-000044:notes:352]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena’s outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period.

[0000936395-23-000044:notes:353]
However, the 2017 Plan permits Ciena to grant service-based stock awards with a minimum one-year vesting period. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total stockholder return as compared to an index of peer companies, in whole or in part.

[0000936395-23-000044:notes:354]
During fiscal 2023, Ciena introduced a benefit pursuant to which, upon completion of ten years of service and reaching age 60, executive officers who are residents of the United States, the United Kingdom, or Canada and who provide 12 months’ notice of their retirement will receive continued vesting of all of their granted but unvested restricted stock unit (“RSU”) awards and a pro-rated amount of their performance stock unit awards and market stock unit awards. Other employees in these countries will be subject to the same eligibility and notice requirements, but will receive acceleration of their granted but unvested RSU awards upon retirement. This program accelerates the recognition of share-based compensation expense.

[0000936395-23-000044:notes:355]
Assumptions for Restricted Stock Unit Awards

[0000936395-23-000044:notes:356]
Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. Share-based expense for service-based restricted stock unit awards is recognized ratably over the vesting period on a straight-line basis.

[0000936395-23-000044:notes:357]
Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total stockholder return, by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Share-based compensation expense is recognized over the performance period, using graded vesting, which considers each performance period or tranche separately, based on Ciena’s determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-23-000044:notes:358]
Share-based compensation expense for restricted stock units subject only to service-based vesting conditions and restricted stock units subject to performance-based vesting conditions other than total stockholder return, is recognized only for those awards that ultimately vest. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of Ciena’s share-based compensation.

[0000936395-23-000044:notes:359]
Ciena recognizes the estimated fair value of performance based awards subject to total stockholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model. Ciena reverses share-based compensation expense on performance based awards subject to total shareholder return only when the requisite service period is not reached. Assumptions for awards granted during fiscal 2023, fiscal 2022 and fiscal 2021 included the following:

[0000936395-23-000044:notes:360]
|  | Year Ended |
|  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Expected volatility of Ciena common stock, which is a weighted average of implied volatility and historical volatility | 40.37% |  | 38.27% |  | 41.00% |
| Historical volatility of Ciena common stock | 43.11% |  | 42.17% |  | 42.80% |
| Historical volatility of S&P Networking Index | 30.93% |  | 27.22% |  | 27.30% |
| Correlation coefficient | 0.7781 |  | 0.7049 |  | 0.6800 |
| Expected life in years | 2.89 |  | 2.89 |  | 2.87 |
| Risk-free interest rate | 3.95% |  | 0.94% |  | 0.17% |
| Expected dividend yield | 0.0% |  | 0.0% |  | 0.0% |

[0000936395-23-000044:notes:361]
The following table is a summary of Ciena’s restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena’s closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-23-000044:notes:362]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance at October 29, 2022 | 4,103 |  |  | $ | 55.16 |  |  | $ | 197,960 |  |
| Granted | 3,301 |  |  |  |  |  |
| Vested | (2,067) |  |  |  |  |  |
| Canceled or forfeited | (415) |  |  |  |  |  |
| Balance at October 28, 2023 | 4,922 |  |  | $ | 53.42 |  |  | $ | 201,916 |  |

[0000936395-23-000044:notes:363]
As of October 28, 2023 and October 29, 2022, 0.3 million of the total restricted stock units outstanding are performance based awards subject to total stockholder return. The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2023, fiscal 2022 and fiscal 2021 was $98.2 million, $119.0 million and $110.0 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2023, fiscal 2022 and fiscal 2021 was $50.48, $67.03 and $48.70, respectively.

[0000936395-23-000044:notes:364]
Amended and Restated ESPP

[0000936395-23-000044:notes:365]
Ciena makes shares of its common stock available for purchase under the ESPP, under which eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Unless earlier terminated, the ESPP will terminate on April 1, 2031.

[0000936395-23-000044:notes:366]
During fiscal 2023, Ciena issued 0.8 million shares and during both fiscal 2022 and fiscal 2021, Ciena issued 0.7 million shares, respectively, under the ESPP. At October 28, 2023, 11.3 million shares remained available for issuance under the ESPP.

[0000936395-23-000044:notes:367]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-23-000044:notes:368]
|  | Year Ended |
|  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Products | $ | 4,518 |  |  | $ | 3,867 |  |  | $ | 3,408 |  |
| Services | 10,470 |  |  | 7,533 |  |  | 5,181 |  |
| Share-based compensation expense included in cost of goods sold | 14,988 |  |  | 11,400 |  |  | 8,589 |  |
| Research and development | 42,331 |  |  | 31,879 |  |  | 21,863 |  |
| Sales and marketing | 35,136 |  |  | 31,280 |  |  | 25,152 |  |
| General and administrative | 37,587 |  |  | 30,435 |  |  | 28,804 |  |
| Share-based compensation expense included in operating expense | 115,054 |  |  | 93,594 |  |  | 75,819 |  |
| Share-based compensation expense capitalized in inventory, net | 413 |  |  | 137 |  |  | (72) |  |
| Total share-based compensation | $ | 130,455 |  |  | $ | 105,131 |  |  | $ | 84,336 |  |

[0000936395-23-000044:notes:369]
As of October 28, 2023, total unrecognized share-based compensation expense was $201.0 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.39 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-23-000044:notes:370]
SEGMENT AND ENTITY WIDE DISCLOSURES
Segment Reporting

[0000936395-23-000044:notes:371]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services.

[0000936395-23-000044:notes:372]
Ciena’s long-lived assets, including equipment, building, furniture and fixtures, operating ROU assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena’s chief operating decision maker for purposes of evaluating performance and allocating resources. As of October 28, 2023, equipment, building, furniture and fixtures, net,

[0000936395-23-000044:notes:373]
totaled $280.1 million, and operating ROU assets totaled $35.1 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of October 28, 2023, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-23-000044:notes:374]
|  | October 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 188,383 |  |  | $ | — |  |  | $ | 17,244 |  |  | $ | — |  |  | $ | 205,627 |  |
| Goodwill | $ | 199,525 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 444,765 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 54,042 |  |  | $ | 54,042 |  |

[0000936395-23-000044:notes:375]
Segment Profit (Loss)

[0000936395-23-000044:notes:376]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; acquisition and integration costs; interest and other income (loss), net; interest expense; loss on extinguishment and modification of debt and provision (benefit) for income taxes.

[0000936395-23-000044:notes:377]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income for the respective periods indicated (in thousands):

[0000936395-23-000044:notes:378]
|  | Year Ended |
|  | October 28, 2023 |  | October 29, 2022 |  | October 30, 2021 |
| Segment profit (loss): |  |  |  |  |  |
| Networking Platforms | $ | 778,641 |  |  | $ | 572,305 |  |  | $ | 850,901 |  |
| Platform Software and Services | 186,945 |  |  | 175,108 |  |  | 136,602 |  |
| Blue Planet Automation Software and Services | (33,669) |  |  | (22,388) |  |  | (711) |  |
| Global Services | 196,375 |  |  | 210,663 |  |  | 198,521 |  |
| Total segment profit | 1,128,292 |  |  | 935,688 |  |  | 1,185,313 |  |
| Less: non-performance operating expenses |  |  |  |  |  |
| Selling and marketing | 490,804 |  |  | 466,565 |  |  | 452,214 |  |
| General and administrative | 215,284 |  |  | 179,382 |  |  | 181,874 |  |
| Significant asset impairments and restructuring costs | 23,834 |  |  | 33,824 |  |  | 29,565 |  |
| Amortization of intangible assets | 37,351 |  |  | 32,511 |  |  | 23,732 |  |
| Acquisition and integration costs | 3,474 |  |  | 598 |  |  | 2,572 |  |
| Add: other non-performance financial items |  |  |  |  |  |
| Interest and other income (loss), net | 62,008 |  |  | 6,747 |  |  | (1,768) |  |
| Interest expense | (88,026) |  |  | (47,050) |  |  | (30,837) |  |
| Loss on extinguishment and modification of debt | (7,874) |  |  | — |  |  | — |  |
| Less: Provision (benefit) for income taxes | 68,826 |  |  | 29,603 |  |  | (37,445) |  |
| Consolidated net income | $ | 254,827 |  |  | $ | 152,902 |  |  | $ | 500,196 |  |

[0000936395-23-000044:notes:379]
Entity Wide Reporting

[0000936395-23-000044:notes:380]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, and operating ROU assets specifically identified. Equipment, building, furniture and fixtures, net, and operating ROU assets attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets was as follows (in thousands):

[0000936395-23-000044:notes:381]
|  | October 28, 2023 |  | October 29, 2022 |  |  |
| Canada | $ | 229,707 |  |  | $ | 226,451 |  |  |  |
| United States | 46,933 |  |  | 47,515 |  |  |  |
| Other International | 38,647 |  |  | 38,921 |  |  |  |
| Total | $ | 315,287 |  |  | $ | 312,887 |  |  |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000936395-23-000044:notes:382]
OTHER EMPLOYEE BENEFIT PLANS
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. The plan covers all Canada-based employees who are not part of an excluded group. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual dollar limit of CAD$31,560 (approximately $25,748 for 2023). This plan includes a required employer contribution of 1% for all participants and an employer matching contribution equal to 50% of the first 6% an employee contributes each pay period. During fiscal 2023, 2022 and 2021, Ciena made matching contributions of approximately CAD$10.6 million (approximately $7.6 million), CAD$10.1 million (approximately $7.3 million) and CAD$8.3 million (approximately $6.0 million), respectively.

[0000936395-23-000044:notes:383]
Ciena has a 401(k) defined contribution profit sharing plan that covers a majority of its United States-based employees. Participants may contribute up to 60% of base pay through pre-tax or Roth contributions, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 8% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2023, 2022 and 2021, Ciena made matching contributions of approximately $10.4 million, $9.2 million and $8.4 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-23-000044:notes:384]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-23-000044:notes:385]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-23-000044:notes:386]
Litigation

[0000936395-23-000044:notes:387]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

[0000936395-23-000044:notes:388]
Purchase Order Obligations

[0000936395-23-000044:notes:389]
Ciena has certain advanced orders for supply of certain long lead time components. As of October 28, 2023, Ciena had $1.7 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000936395-23-000044:notes:390]
The following table describes, for the quarter ended October 28, 2023, each trading arrangement for the sale or purchase of our securities adopted, terminated or for which the amount, pricing or timing provisions were modified by our directors and officers

[0000936395-23-000044:notes:391]
(as defined in Rule 16a-1(f) of the Exchange Act) that is either (1) a contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) (a “Rule 10b5-1 trading arrangement”) or (2) a “non-Rule 10b5-1 trading arrangement” (as defined in Item 408(c) of Regulation S-K):

[0000936395-23-000044:notes:392]
| Name(Title) | Action Taken (Date of Action) | Type of Trading Arrangement | Nature of Trading Arrangement | Duration of Trading Arrangement | Aggregate Number of Securities to be Purchased or Sold |
| David Rothenstein (Senior Vice President, Chief Strategy Officer and Secretary) | Adoption (September 22, 2023) | Rule 10b5-1 trading arrangement | Sales | Until January 14, 2025, or such earlier date upon which all transactions are completed or expire without execution | Up to 42,000 shares of common stock |
| Scott McFeely (former Senior Vice President, Global Products and Services) | Adoption (October 12, 2023) | Rule 10b5-1 trading arrangement | Sales | Until December 31, 2024, or such earlier date upon which all transactions are completed or expire without execution | Up to 38,500 shares of common stock |
