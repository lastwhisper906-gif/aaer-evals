# CIEN MD&A — 0000936395-23-000044


## mdna

[0000936395-23-000044:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-23-000044:mdna:2]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-23-000044:mdna:3]
Overview

[0000936395-23-000044:mdna:4]
We are a network platform, software, and services company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software, and services that support the delivery of video, data, and voice traffic over core, metro, aggregation, and access communications networks. Our solutions are used globally by communications service providers, cable and multiservice operators, cloud providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that is informed by analytics and intelligence. Our solutions include Networking Platforms, including our Optical Networking and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our Manage, Control and Plan (“MCP”) applications that deliver advanced multi-layer domain control and operations. Through our Blue Planet Software, we also enable complete service lifecycle management automation with productized operational support systems (OSS), which include inventory, orchestration and assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-23-000044:mdna:5]
Order Volumes

[0000936395-23-000044:mdna:6]
From the second quarter of fiscal 2021 through the third quarter of fiscal 2022, we received an unprecedented volume of orders for our products and services. Our quarterly order volumes during this period significantly exceeded our revenue and historical order volumes, with concentration of orders among certain existing cloud provider and North America-based service provider customers. We believe some portion of these orders reflected customer acceleration of future orders due to lengthened lead times or the implementation of security of supply strategies to address the supply constraints described below. We also believe some portion of these orders reflected pre-pandemic design wins for which orders were delayed due to the dynamics of the COVID-19 pandemic. Our order volumes began to moderate in the fourth quarter of fiscal 2022. We continued to experience levels of orders lower than revenue during fiscal 2023, with order volumes slightly increasing in the fourth quarter of fiscal 2023 as compared to the third quarter of fiscal 2023. We believe this reduction in orders relative to revenue has been in part due to customers no longer needing to place significant advanced orders, because supply chain conditions and lead times have improved. However, over the longer term, we continue to believe that certain trends and shifts in business and consumer behaviors, including enterprise and consumer cloud network adoption, 5G, high-definition video, generative AI, and network operator focus on resilience and automation, represent positive, long-term drivers of demand and opportunities for our business.

[0000936395-23-000044:mdna:7]
Backlog and Order Delivery Timing

[0000936395-23-000044:mdna:8]
Historically, a meaningful portion of our quarterly revenue was generated from customer orders received during that same quarter (which we refer to as “book to revenue”) and was therefore less predictable and subject to fluctuation. As a result of elevated order volumes during portions of fiscal 2021 and fiscal 2022, and the supply chain constraints described below, however, we generated a significant backlog of customer orders. Accordingly, our revenue has been more recently impacted by factors including availability of supply and customer delivery deferrals of existing backlog. Our backlog grew from $1.2 billion at the end of fiscal 2020 to $4.2 billion at the end of fiscal 2022. As supply chain conditions have improved and we have been able to increase shipment volumes and reduce lead times, our backlog decreased to $2.6 billion as of the end of fiscal 2023. We expect our backlog to continue to reduce during fiscal 2024 as supply chain conditions continue to improve and customers place fewer advanced orders. As that happens, we expect that our reliance upon securing quarterly book to revenue orders will grow and that those orders will represent a more typical composition of our quarterly revenue and to be a critical element of future revenue growth.

[0000936395-23-000044:mdna:9]
The timing with which, and degree to which, we fulfill our backlog will have a significant impact on our rate of revenue growth and can be affected by factors outside of our control, including supply chain conditions and availability of components described below, and customer readiness and willingness to receive shipment against existing orders. During fiscal 2023, certain customers, including communications service providers and cable and multiservice operators in North America and cloud providers, that had earlier placed significant advanced orders, rescheduled deliveries for a portion of such orders,

[0000936395-23-000044:mdna:10]
including in some cases until after the end of fiscal 2023. We believe that this was the result of a number of factors, including these customers’ significant order levels during a period of supply chain constraints, the recent, rapid improvement in our delivery lead times, and their capital expenditure and inventory levels. Accordingly, our results for a particular period can be difficult to predict. As a result of these and other factors, the timing of our fulfillment of backlog could cause some volatility in our results of operations and our backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period. See the risk factors captioned “Our backlog may not be an accurate indicator of our level and timing of future revenues.” and “Our revenue, gross margin, and operating results can fluctuate significantly and unpredictably from quarter to quarter.” in Item 1A of Part I of this report for further discussion of risks related to our backlog and order delivery timing.

[0000936395-23-000044:mdna:11]
Supply Chain Constraints

[0000936395-23-000044:mdna:12]
In the face of demand across a range of industries, global supply for certain raw materials and components, including, in particular, semiconductor, integrated circuits, and other electronic components used in most of our products, experienced substantial constraint and disruption in recent prior periods. As a result, we experienced significant component shortages, extended lead times, increased costs, and unexpected cancellation or delay of previously committed supply of key components across our supplier base. During the second half of fiscal 2023, lead times, costs, and predictability of supply for semiconductors, integrated circuits, and other electronic components began to stabilize and the majority of our suppliers have been able to deliver by their promised, though extended, lead times. However, we expect that extended lead times for components and elevated component costs will persist at least through the first half of fiscal 2024. Supply constrained conditions have impacted our revenue and will continue to impact our costs of goods sold in the near term and our ability to continue to reduce the cost to produce our products in a manner consistent with prior periods. It is unclear when the supply environment will fully stabilize and what impacts it will have on our business and results of operations in future periods.

[0000936395-23-000044:mdna:13]
To mitigate the impact of these supply conditions on our business and customers, we have placed and continue to place advanced orders for inventory and have been accumulating components. We also expanded our manufacturing capacity to prepare us to be able to produce finished goods more quickly. As a result of this strategy, our inventory increased from $374.3 million at the end of fiscal 2021 to $1.1 billion at the end of fiscal 2023. Together with increased costs of supply, these mitigation strategies have impacted, and we expect them to continue to impact, our result of operations and cash from operations.

[0000936395-23-000044:mdna:14]
Market Opportunity

[0000936395-23-000044:mdna:15]
The market in which we sell our communications networking solutions is dynamic and characterized by a high rate of change, including rapid growth in bandwidth demand and network traffic, the proliferation of cloud-based services and new approaches, or “consumption models,” for designing and procuring networking solutions. Emerging services and applications, including 5G mobile communications, fiber-based access networks and the Internet of Things, are further impacting or expected to impact wireline network infrastructures, particularly at the edge of networks, where increased capacity, computing power and automation are required to provide the quality of experience demanded by end users. Many network operators are under pressure to constrain their capital expenditure budgets, as they cannot grow their network spending at the rate of bandwidth growth. To address these growing service demands and manage network cost, many network operators are looking to adopt next-generation infrastructures that are more programmable and better capable of leveraging data for network insight, analytics and automation. Other network operators are pursuing a diverse range of consumption models in their design and procurement of network infrastructure solutions. Our Adaptive Network vision and our business strategy to capitalize on these changing market dynamics include the initiatives set forth in the “Strategy” section of the description of our business in Item 1 of Part I of this annual report.

[0000936395-23-000044:mdna:16]
Strategic and Financial Initiatives

[0000936395-23-000044:mdna:17]
Acquisitions. On November 17, 2022, we acquired Benu Networks, Inc. (“Benu”) and its portfolio of cloud-native software solutions, including a virtual Broadband Network Gateway ((v)BNG), which complement our existing portfolio of broadband access solutions. On December 30, 2022, we acquired Tibit Communications, Inc. (“Tibit”), a provider of passive optical network solutions. See Note 4 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on these acquisitions.

[0000936395-23-000044:mdna:18]
Credit Facility Refinancings. On October 24, 2023, we entered into an Incremental Amendment Agreement to our existing Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), pursuant to which we incurred a new single tranche of senior secured term loans in an aggregate principal amount of $1.2 billion, maturing on October 24, 2030 (the “2030 New Term Loan”). The proceeds of the 2030 New Term Loan, together with cash on hand, were used to repay in full (i) our existing senior secured term loan with an outstanding aggregate principal amount of approximately $668.7 million and

[0000936395-23-000044:mdna:19]
maturing on September 28, 2025 (the “2025 Term Loan”), and (ii) our existing senior secured term loan with an outstanding aggregate principal amount of approximately $497.5 million and maturing on January 19, 2030 (the “2030 Term Loan”), including accrued interest, and pay transaction fees and expenses. See Note 19 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on our term loans.

[0000936395-23-000044:mdna:20]
On October 24, 2023, pursuant to the above Incremental Amendment Agreement to the Credit Agreement, we entered into a new senior secured revolving credit facility of $300 million (the “Revolving Credit Facility”), maturing on October 24, 2028, which replaces a predecessor senior secured asset-based revolving credit facility of up to $300 million, maturing on September 25, 2025 (the “ABL Credit Facility”) under our ABL Credit Agreement, dated October 28, 2019, as amended (the “ABL Credit Agreement”). Concurrent with entering into the Revolving Credit Facility, the ABL Credit Agreement was terminated. We intend to use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. See Note 20 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on our revolving credit facilities.

[0000936395-23-000044:mdna:21]
Fiscal Year-End Backlog

[0000936395-23-000044:mdna:22]
Generally, we make sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These agreements do not obligate customers to purchase any minimum or guaranteed order quantities. In calculating backlog, we only include (i) customer purchase orders for products that have not been shipped and for services that have not yet been performed; and (ii) customer orders relating to products that have been delivered and services that have been performed, but are awaiting customer acceptance under the applicable contract terms. Generally, our customers may cancel, delay or change their orders with limited advance notice, or they may decide not to accept our products and services, although instances of both cancellation and non-acceptance are rare. Backlog may be fulfilled several quarters following receipt of a purchase order, or in the case of certain service obligations, may relate to multi-year support period. As a result, backlog should not necessarily be viewed as an accurate indicator of future revenue for any particular period.

[0000936395-23-000044:mdna:23]
Our backlog was $2.6 billion as of October 28, 2023, as compared to $4.2 billion as of October 29, 2022. Backlog includes product and service orders from commercial and government customers combined, and our significant annual growth reflects the demand dynamics described above. Backlog at October 28, 2023 includes approximately $336.2 million primarily related to orders for products and maintenance and support services that are not expected to be filled or performed within fiscal 2024. Because backlog can be defined in different ways by different companies, our presentation of backlog may not be comparable with figures presented by other companies in our industry.

[0000936395-23-000044:mdna:24]
Consolidated Results of Operations

[0000936395-23-000044:mdna:25]
A discussion regarding our financial condition and results of operations for fiscal 2023 compared to fiscal 2022 is presented below. A discussion of fiscal 2022 compared to fiscal 2021 can be found under Item 7 of Part II of our Annual Report on Form 10-K for the fiscal year ended October 29, 2022, filed with the SEC on December 16, 2022, which is available free of charge on the SEC’s website at www.sec.gov and our Investor Relations website at investor.ciena.com.

[0000936395-23-000044:mdna:26]
Operating Segments

[0000936395-23-000044:mdna:27]
Our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. Effective the fourth quarter of fiscal 2023, we renamed our “Converged Packet Optical” product line “Optical Networking.” This change was made on a prospective basis and does not impact comparability of previous financial results or the composition of this product line. However, references to our “Converged Packet Optical” product line in prior periods have been changed to “Optical Networking” in this report. See Notes 2 and 25 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information on our segment reporting.

[0000936395-23-000044:mdna:28]
Fiscal 2023 Compared to Fiscal 2022

[0000936395-23-000044:mdna:29]
Revenue

[0000936395-23-000044:mdna:30]
Currency Fluctuations

[0000936395-23-000044:mdna:31]
During fiscal 2023, approximately 14.9% of our revenue was non-U.S. Dollar denominated, primarily including sales in Euros, Canadian Dollars and British Pounds. During fiscal 2023, as compared to fiscal 2022, the U.S. Dollar primarily strengthened against these and other currencies. Consequently, our revenue reported in U.S. Dollars was adversely impacted by approximately $4.7 million, or 0.1%, as compared to fiscal 2022.

[0000936395-23-000044:mdna:32]
Operating Segment Revenue

[0000936395-23-000044:mdna:33]
See Notes 2 and 25 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information on our segment reporting. The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-23-000044:mdna:34]
|  | Fiscal Year |  |  |  |  |
|  | 2023 |  | %* |  | 2022 |  | %* |  | Increase (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,987,245 |  |  | 68.1 |  | $ | 2,379,931 |  |  | 65.5 |  | $ | 607,314 |  |  | 25.5 |
| Routing and Switching | 506,247 |  |  | 11.5 |  | 398,439 |  |  | 11.0 |  | 107,808 |  |  | 27.1 |
| Total Networking Platforms | 3,493,492 |  |  | 79.6 |  | 2,778,370 |  |  | 76.5 |  | 715,122 |  |  | 25.7 |
| Platform Software and Services | 303,873 |  |  | 6.9 |  | 277,191 |  |  | 7.6 |  | 26,682 |  |  | 9.6 |
| Blue Planet Automation Software and Services | 69,170 |  |  | 1.6 |  | 76,567 |  |  | 2.1 |  | (7,397) |  |  | (9.7) |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 288,334 |  |  | 6.6 |  | 292,375 |  |  | 8.1 |  | (4,041) |  |  | (1.4) |
| Installation and Deployment | 180,951 |  |  | 4.1 |  | 157,443 |  |  | 4.3 |  | 23,508 |  |  | 14.9 |
| Consulting and Network Design | 50,729 |  |  | 1.2 |  | 50,715 |  |  | 1.4 |  | 14 |  |  | — |
| Total Global Services | 520,014 |  |  | 11.9 |  | 500,533 |  |  | 13.8 |  | 19,481 |  |  | 3.9 |
| Consolidated revenue | $ | 4,386,549 |  |  | 100.0 |  | $ | 3,632,661 |  |  | 100.0 |  | $ | 753,888 |  |  | 20.8 |

[0000936395-23-000044:mdna:35]
_________________________________

[0000936395-23-000044:mdna:36]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2022 to 2023 |

[0000936395-23-000044:mdna:37]
•Networking Platforms segment revenue increased by $715.1 million, reflecting product line sales increases of $607.3 million of our Optical Networking products and $107.8 million of our Routing and Switching products.

[0000936395-23-000044:mdna:38]
◦Optical Networking sales increased, primarily reflecting sales increases of $374.3 million of our 6500 RLS products, primarily to cloud providers, and $131.3 million of our 6500 Packet-Optical Platform, primarily to communications service providers and enterprise customers, and a sales increase of $101.9 million of our Waveserver® modular interconnect system, primarily to cloud providers.

[0000936395-23-000044:mdna:39]
◦Routing and Switching sales increased, primarily reflecting a sales increase of $81.1 million of our 3000 and 5000 families of service delivery and aggregation switches, including initial sales of our microplug OLT transceivers that are integrated in our aggregation switches or sold on a stand-alone basis, primarily to communications service providers, cable and multiservice operators and enterprise customers. Routing and Switching sales also includes an increase of $25.3 million of our 8100 Coherent IP networking platforms to communications service providers.

[0000936395-23-000044:mdna:40]
•Platform Software and Services segment revenue increased by $26.7 million, reflecting a sales increase of $45.8 million in software maintenance services, offset by a decrease of $19.1 million in sales of software platforms. The increase in our software maintenance services was primarily for our MCP software platform, sold to communications service providers. The decrease in software sales was primarily from decreased sales of our MCP software platform to communication service providers.

[0000936395-23-000044:mdna:41]
•Blue Planet Automation Software and Services segment revenue decreased by $7.4 million, reflecting deceases of $3.8 million in software platform sales, primarily to cable and multiservice operators, and $3.6 million in professional software services, primarily to communication service providers.

[0000936395-23-000044:mdna:42]
•Global Services segment revenue increased by $19.5 million, primarily reflecting a sales increase of $23.5 million of our installation and deployment service, partially offset by a decrease of $4.0 million of our maintenance support and training. Improved reliability of the previously constrained supply environment has benefited installation and deployment services, as described in more detail in “Overview” above.

[0000936395-23-000044:mdna:43]
Revenue by Geographic Region

[0000936395-23-000044:mdna:44]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our Americas region revenue for fiscal 2023 was primarily driven by increased sales in the United States. The increase in our APAC region revenue for fiscal 2023 was primarily driven by increased sales in India, Australia and Singapore. The increase in our EMEA region revenue for fiscal 2023 was primarily driven by increased sales in the Netherlands. The following table reflects our geographic distribution of revenue, which is principally based on the relevant location for the delivery of our products and performance of services. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-23-000044:mdna:45]
|  | Fiscal Year |  |  |  |  |
|  | 2023 |  | %* |  | 2022 |  | %* |  | Increase(decrease) |  | %** |
| Americas | $ | 3,110,347 |  |  | 70.9 |  | $ | 2,636,840 |  |  | 72.6 |  | $ | 473,507 |  |  | 18.0 |
| EMEA | 643,142 |  |  | 14.7 |  | 555,215 |  |  | 15.3 |  | 87,927 |  |  | 15.8 |
| APAC | 633,060 |  |  | 14.4 |  | 440,606 |  |  | 12.1 |  | 192,454 |  |  | 43.7 |
| Total | $ | 4,386,549 |  |  | 100.0 |  | $ | 3,632,661 |  |  | 100.0 |  | $ | 753,888 |  |  | 20.8 |

[0000936395-23-000044:mdna:46]
_________________________________

[0000936395-23-000044:mdna:47]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2022 to 2023 |

[0000936395-23-000044:mdna:48]
•Americas revenue increased by $473.5 million, reflecting sales increases of $460.4 million within our Networking Platforms segment, $17.2 million within our Platform Software and Services segment and $5.1 million within our Global Services segment, partially offset by a sales decrease of $9.2 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue increase reflects product line sales increases of $395.2 million of our Optical Networking products and $65.2 million of our Routing and Switching products. The increase within our Optical Networking revenue primarily reflects sales increases of $286.4 million of our 6500 RLS products and $75.9 million of our Waveserver® modular interconnect system, both primarily to cloud providers, and $35.7 million of our 6500 Packet-Optical Platform, primarily to communication service providers and enterprise customers, partially offset by decreased sales to cable and multiservice operators. The increase within our Routing and Switching product line primarily reflects sales increases of $40.3 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators and enterprise customers, and $21.4 million of our 8100 Coherent IP networking platforms, primarily to communications service providers.

[0000936395-23-000044:mdna:49]
•EMEA revenue increased by $87.9 million, reflecting sales increases of $68.0 million within our Networking Platforms segment, $9.2 million within our Global Services segment, $6.4 million within our Blue Planet Automation Software and Services segment and $4.3 million within our Platform Software and Services segment. Our Networking Platforms segment revenue increase primarily reflects product line sales increases of $35.1 million of our Optical Networking products and $32.9 million of our Routing and Switching products. The increase within our Optical Networking revenue primarily reflects a sales increase of $62.0 million of our 6500 RLS products, primarily to cloud providers, partially offset by sales decreases of $15.0 million of our 6500 Packet-Optical Platform and $12.3 million of our Waveserver® modular interconnect system, both primarily to cloud providers. The increase within our Routing and Switching revenue primarily reflects a sales increase of $27.0 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to communication service providers.

[0000936395-23-000044:mdna:50]
•APAC revenue increased by $192.5 million, reflecting sales increases of $186.7 million within our Networking Platforms segment, $5.2 million within our Platform Software and Services segment, and $5.1 million of our Global Services segment, partially offset by a sales decrease of $4.5 million within our Blue Planet Automation Software and

[0000936395-23-000044:mdna:51]
Services segment. Our Networking Platforms segment revenue increase reflects a product line sales increase of $177.0 million of our Optical Networking products, primarily reflecting a sales increase of $110.6 million of our 6500 Packet-Optical Platform, primarily to communication service providers and enterprise customers

[0000936395-23-000044:mdna:52]
In fiscal 2023 and fiscal 2022, our top ten customers contributed 53.7% and 56.3% of our revenue, respectively. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can be significantly affected by market, industry or competitive dynamics affecting the businesses of those customers. Our reliance on a relatively small number of customers increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations, and our results of operations can fluctuate quarterly depending on sales volumes and purchasing priorities with these large customers. Sales to one of our cloud provider customers were $561.4 million, or 12.8% of total revenue, in fiscal 2023. Sales to AT&T were $464.7 million, or 10.6% of total revenue, in fiscal 2023, and $433.4 million, or 11.9% of total revenue, in fiscal 2022. Verizon accounted for $402.8 million, or 11.1% of total revenue, in fiscal 2022. No other customer accounted for greater than 10% of our revenue in fiscal 2023 or fiscal 2022.

[0000936395-23-000044:mdna:53]
While drivers of bandwidth growth and network evolution remain strong, many of our network operator customers are under pressure to constrain their capital expenditure budgets, and their businesses cannot grow their network spending at the rate of bandwidth growth. As a result, as we innovate and introduce new and more robust solutions that increase capacity or add features, there is a market expectation for solutions that are more cost-effective than existing or competing solutions and that new products consistently deliver lower price per bit performance. The combination of this regular technology-driven price compression, price competition in our markets and ongoing customer efforts to manage network costs can impact our growth rates and requires that we increase our volume of product shipments to maintain and grow revenue.

[0000936395-23-000044:mdna:54]
Cost of Goods Sold and Gross Profit

[0000936395-23-000044:mdna:55]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-23-000044:mdna:56]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities, and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-23-000044:mdna:57]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending on our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive annual product cost reductions relative to the price erosion that we regularly encounter in our markets. This can be challenging, particularly within the current constrained supply environment. Moreover, we are often required to compete with aggressive pricing and commercial terms, and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Success in taking share and winning new business can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers as they add capacity and need to monitor their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-23-000044:mdna:58]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-23-000044:mdna:59]
The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-23-000044:mdna:60]
|  | Fiscal Year |  |  |  |  |
|  | 2023 |  | %* |  | 2022 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 4,386,549 |  |  | 100.0 |  | $ | 3,632,661 |  |  | 100.0 |  | $ | 753,888 |  |  | 20.8 |
| Total cost of goods sold | 2,507,698 |  |  | 57.2 |  | 2,072,317 |  |  | 57.0 |  | 435,381 |  |  | 21.0 |
| Gross profit | $ | 1,878,851 |  |  | 42.8 |  | $ | 1,560,344 |  |  | 43.0 |  | $ | 318,507 |  |  | 20.4 |

[0000936395-23-000044:mdna:61]
_________________________________

[0000936395-23-000044:mdna:62]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2022 to 2023 |

[0000936395-23-000044:mdna:63]
|  | Fiscal Year |  |  |  |  |
|  | 2023 |  | %* |  | 2022 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 3,581,039 |  |  | 100.0 |  | $ | 2,888,848 |  |  | 100.0 |  | $ | 692,191 |  |  | 24.0 |
| Product cost of goods sold | 2,088,440 |  |  | 58.3 |  | 1,699,631 |  |  | 58.8 |  | 388,809 |  |  | 22.9 |
| Product gross profit | $ | 1,492,599 |  |  | 41.7 |  | $ | 1,189,217 |  |  | 41.2 |  | $ | 303,382 |  |  | 25.5 |

[0000936395-23-000044:mdna:64]
_________________________________

[0000936395-23-000044:mdna:65]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2022 to 2023 |

[0000936395-23-000044:mdna:66]
|  | Fiscal Year |  |  |  |  |
|  | 2023 |  | %* |  | 2022 |  | %* |  | Increase(decrease) |  | %** |
| Services revenue | $ | 805,510 |  |  | 100.0 |  | $ | 743,813 |  |  | 100.0 |  | $ | 61,697 |  |  | 8.3 |
| Services cost of goods sold | 419,258 |  |  | 52.0 |  | 372,686 |  |  | 50.1 |  | 46,572 |  |  | 12.5 |
| Services gross profit | $ | 386,252 |  |  | 48.0 |  | $ | 371,127 |  |  | 49.9 |  | $ | 15,125 |  |  | 4.1 |

[0000936395-23-000044:mdna:67]
_________________________________

[0000936395-23-000044:mdna:68]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2022 to 2023 |

[0000936395-23-000044:mdna:69]
•Gross profit increased by $318.5 million. Gross margin decreased by 20 basis points, primarily due to lower margin on services partially offset by improved margin on products.

[0000936395-23-000044:mdna:70]
•Gross profit on products increased by $303.4 million. Product gross margin increased by 50 basis points, primarily due to improved manufacturing efficiencies and lower product costs, partially offset by a higher concentration of lower margin ”common” equipment and photonics sales, as described above.

[0000936395-23-000044:mdna:71]
•Gross profit on services increased by $15.1 million. Service gross margin decreased by 190 basis points, primarily due to higher incremental costs on maintenance related support and losses incurred on certain Blue Planet software service projects and lower margin on certain consulting projects. These decreases were partially offset by increased Platform Software services revenue.

[0000936395-23-000044:mdna:72]
Operating Expense

[0000936395-23-000044:mdna:73]
Currency Fluctuations

[0000936395-23-000044:mdna:74]
During fiscal 2023, approximately 49.4% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars, Indian Rupees, and Euros. During fiscal 2023 as compared to fiscal 2022, the U.S. Dollar primarily strengthened against these and other currencies. Consequently, our operating expense reported in U.S. Dollars decreased by approximately $23.3 million, or 1.5%, net of hedging.

[0000936395-23-000044:mdna:75]
Operating expense increased in fiscal 2023 from the level reported for fiscal 2022, primarily due to increases in employee headcount and variable compensation costs associated with our annual cash incentive compensation plan and increases in professional services. We have also experienced, and are continuing to experience, increases in the cost of labor and other costs of doing business due to inflation, and continued inflationary pressures could have an adverse impact on our profitability. We

[0000936395-23-000044:mdna:76]
expect operating expense to continue to increase from the level reported in fiscal 2023 primarily due to planned investment in research and development to advance our strategy and higher employee compensation costs.

[0000936395-23-000044:mdna:77]
Operating expense consists of the component elements described below.

[0000936395-23-000044:mdna:78]
•Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense, and third-party consulting costs.

[0000936395-23-000044:mdna:79]
•Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs.

[0000936395-23-000044:mdna:80]
•General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services.

[0000936395-23-000044:mdna:81]
•Significant asset impairments and restructuring costs primarily reflect actions we have taken to improve the alignment of our workforce, facilities and operating costs with perceived market opportunities, business strategies, changes in market and business conditions, the redesign of certain business processes and significant impairments of assets.

[0000936395-23-000044:mdna:82]
•Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions.

[0000936395-23-000044:mdna:83]
•Acquisition and integration costs primarily consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition activity. For more information on our acquisitions, see Note 4 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-23-000044:mdna:84]
The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-23-000044:mdna:85]
|  | Fiscal Year |  |  |  |  |
|  | 2023 |  | %* |  | 2022 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 750,559 |  |  | 17.1 |  | $ | 624,656 |  |  | 17.2 |  | $ | 125,903 |  |  | 20.2 |
| Selling and marketing | 490,804 |  |  | 11.2 |  | 466,565 |  |  | 12.9 |  | 24,239 |  |  | 5.2 |
| General and administrative | 215,284 |  |  | 4.9 |  | 179,382 |  |  | 4.9 |  | 35,902 |  |  | 20.0 |
| Significant asset impairments and restructuring costs | 23,834 |  |  | 0.5 |  | 33,824 |  |  | 0.9 |  | (9,990) |  |  | (29.5) |
| Amortization of intangible assets | 37,351 |  |  | 0.9 |  | 32,511 |  |  | 0.9 |  | 4,840 |  |  | 14.9 |
| Acquisition and integration costs | 3,474 |  |  | 0.1 |  | 598 |  |  | — |  | 2,876 |  |  | 480.9 |
| Total operating expenses | $ | 1,521,306 |  |  | 34.7 |  | $ | 1,337,536 |  |  | 36.8 |  | $ | 183,770 |  |  | 13.7 |

[0000936395-23-000044:mdna:86]
_________________________________

[0000936395-23-000044:mdna:87]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2022 to 2023 |

[0000936395-23-000044:mdna:88]
•Research and development expense benefited from $16.3 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $125.9 million. This increase primarily reflects increases in employee headcount and related compensation costs including variable compensation costs associated with our annual cash incentive compensation plan, and professional services related to design engineering, fabrication and production of ASIC chips. The increase in employee headcount was partially due to our acquisitions of Benu and Tibit.

[0000936395-23-000044:mdna:89]
•Selling and marketing expense benefited from $5.4 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and the Euro. Including the effect of foreign exchange rates, sales and marketing expense increased by $24.2 million. This increase primarily reflects increases in travel and entertainment costs, professional services and employee-related compensation costs primarily related to higher costs associated with our annual cash incentive compensation plan.

[0000936395-23-000044:mdna:90]
•General and administrative expense benefited from $1.6 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, general and administrative expense increased by $35.9 million. This increase primarily reflects increases in employee-related compensation costs primarily related to higher costs associated with our annual cash incentive compensation plan, costs incurred as a result of the settlement of certain patent infringement claims and the resolution of related legal proceedings, and professional services.

[0000936395-23-000044:mdna:91]
•Significant asset impairments and restructuring costs decreased by $10.0 million. This decrease primarily reflects the effect of a $3.8 million impairment charge due to our suspended operations in Russia recorded in fiscal 2022 and lower costs on actions that we have taken with respect to our operations, global workforce, and facilities as part of a business optimization strategy to improve gross margin, constrain operating expense, redesign certain business processes, and restructure real estate facilities.

[0000936395-23-000044:mdna:92]
•Amortization of intangible assets increased by $4.8 million reflecting additional intangibles acquired in connection with our acquisitions of Benu and Tibit during the first quarter of fiscal 2023, partially offset by certain intangible assets having reached the end of their economic lives.

[0000936395-23-000044:mdna:93]
•Acquisition and integration costs increased by $2.9 million and primarily reflect financial, legal, and accounting advisors and employee-related costs related to our acquisitions of Benu and Tibit.

[0000936395-23-000044:mdna:94]
Other Items

[0000936395-23-000044:mdna:95]
The table below sets forth the changes in other items for the periods indicated (in thousands, except percentage data):

[0000936395-23-000044:mdna:96]
|  | Fiscal Year |  |  |  |  |
|  | 2023 |  | %* |  | 2022 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | 62,008 |  |  | 1.4 |  | $ | 6,747 |  |  | 0.2 |  | $ | 55,261 |  |  | 819.0 |
| Interest expense | $ | (88,026) |  |  | (2.0) |  | $ | (47,050) |  |  | (1.3) |  | $ | 40,976 |  |  | 87.1 |
| Loss on extinguishment and modification of debt | $ | (7,874) |  |  | (0.2) |  | $ | — |  |  | — |  | $ | 7,874 |  |  | 100.0 |
| Provision (benefit) for income taxes | $ | 68,826 |  |  | 1.6 |  | $ | 29,603 |  |  | 0.8 |  | $ | 39,223 |  |  | 132.5 |

[0000936395-23-000044:mdna:97]
_________________________________

[0000936395-23-000044:mdna:98]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2022 to 2023 |

[0000936395-23-000044:mdna:99]
•Interest and other income (loss), net increased by $55.3 million, primarily resulting from higher interest income on our investments and the remeasurement of our previously held investment in Tibit to fair value, which resulted in a gain on our cost method equity investment of $26.5 million. These increases were partially offset by foreign currency exchange gains (losses), net of foreign currency hedging impact. For more information on our acquisition of Tibit, see Note 4 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-23-000044:mdna:100]
•Interest expense increased, primarily due to additional indebtedness, including the 2030 Term Loan entered into during the first quarter of fiscal 2023, and increased interest on the unhedged portion of the 2025 Term Loan, 2030 Term Loan and 2030 New Term Loan (as defined below), primarily due to higher interest rates. For more information on our short-term and long-term debt, see Note 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-23-000044:mdna:101]
•Loss on extinguishment and modification of debt primarily reflects $1.9 million of extinguishment of debt costs and $6.0 million in debt modification costs, both related to our term loan refinancing which occurred in the fourth quarter of fiscal 2023. For more information, see Note 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-23-000044:mdna:102]
•Provision (benefit) for income taxes increased by $39.2 million, primarily due to the increase in pre-tax income in fiscal 2023. The effective tax rate for fiscal 2023 was higher than the effective tax rate for fiscal 2022, primarily due to the mandatory capitalization of research and development expenses in fiscal 2023.

[0000936395-23-000044:mdna:103]
Segment Profit (Loss)

[0000936395-23-000044:mdna:104]
The table below sets forth the changes in our segment profit (loss) for the respective periods (in thousands, except percentage data):

[0000936395-23-000044:mdna:105]
|  | Fiscal Year |  |  |
|  | 2023 |  | 2022 |  | Increase(decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 778,641 |  |  | $ | 572,305 |  |  | $ | 206,336 |  |  | 36.1 |
| Platform Software and Services | $ | 186,945 |  |  | $ | 175,108 |  |  | $ | 11,837 |  |  | 6.8 |
| Blue Planet Automation Software and Services | $ | (33,669) |  |  | $ | (22,388) |  |  | $ | (11,281) |  |  | (50.4) |
| Global Services | $ | 196,375 |  |  | $ | 210,663 |  |  | $ | (14,288) |  |  | (6.8) |

[0000936395-23-000044:mdna:106]
_________________________________

[0000936395-23-000044:mdna:107]
| * | Denotes % change from 2022 to 2023 |

[0000936395-23-000044:mdna:108]
•Networking Platforms segment profit increased by $206.3 million, primarily due to higher sales volume as described above, and higher gross margin, partially offset by increased research and development costs.

[0000936395-23-000044:mdna:109]
•Platform Software and Services segment profit increased by $11.8 million, primarily due to higher software-related services sales volume as described above, partially offset by lower software sales volume, increased research and development costs, and lower gross margin on software-related services.

[0000936395-23-000044:mdna:110]
•Blue Planet Automation Software and Services segment loss increased by $11.3 million, primarily due to lower sales volume, increased research and development costs and lower gross margin on software-related services, as described above.

[0000936395-23-000044:mdna:111]
•Global Services segment profit decreased by $14.3 million, primarily due to higher incremental costs on maintenance related support and lower maintenance support and training revenue, as described above.

[0000936395-23-000044:mdna:112]
Liquidity and Capital Resources

[0000936395-23-000044:mdna:113]
Overview. For the fiscal year ended October 28, 2023, we generated $168.3 million of cash from operations, as our net income (adjusted for non-cash charges) of $565.1 million exceeded our working capital requirements of $396.8 million. For additional details on our cash used in operating activities, see the discussion below under the caption “Cash Provided by Operating Activities.”

[0000936395-23-000044:mdna:114]
Cash, cash equivalents and investments increased by $65.9 million during fiscal 2023. Cash from operations was partially offset by the following: (i) cash used for stock repurchases under our stock repurchase program of $242.2 million; (ii) cash used for the acquisition of businesses of $230.0 million, net of cash acquired; (iii) cash used to fund our investing activities for capital expenditures totaling $106.2 million; (iv) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $38.5 million; and (v) cash used for payments on our term loans of $9.4 million. In addition to cash provided by operations, the following items also contributed to the increase in cash: (i) proceeds from the issuance of the 2030 Term Loan, which provided $492.5 million in cash, net of paid debt issuance costs; and (ii) issuance of equity under our employee stock purchase plans which provided $31.4 million in cash during fiscal 2023.

[0000936395-23-000044:mdna:115]
See Notes 4, 19, and 22 to our Consolidated Financial Statements included in Item 8 of Part II of this report for information relating to these transactions.

[0000936395-23-000044:mdna:116]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-23-000044:mdna:117]
|  | October 28, 2023 |  | October 29, 2022 |  | Increase (decrease) |
| Cash and cash equivalents | $ | 1,010,618 |  |  | $ | 994,352 |  |  | $ | 16,266 |  |
| Short-term investments in marketable debt securities | 104,753 |  |  | 153,989 |  |  | (49,236) |  |
| Long-term investments in marketable debt securities | 134,278 |  |  | 35,385 |  |  | 98,893 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,249,649 |  |  | $ | 1,183,726 |  |  | $ | 65,923 |  |

[0000936395-23-000044:mdna:118]
Principal Sources of Liquidity. Our principal sources of liquidity include our cash, cash equivalents and investments, which as of October 28, 2023 totaled $1.2 billion, as well as the unused portion of the Revolving Credit Facility. The Revolving Credit Facility, which we and certain of our subsidiaries entered into on October 24, 2023, replaced the ABL Credit Facility and provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general

[0000936395-23-000044:mdna:119]
corporate purposes. As of October 28, 2023, letters of credit totaling $72.5 million were outstanding under our Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of October 28, 2023.

[0000936395-23-000044:mdna:120]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $308.0 million as of October 28, 2023. During the fourth quarter of fiscal 2023, we evaluated the undistributed earnings of the foreign subsidiaries and identified approximately $222.0 million in earnings that we no longer consider to be indefinitely reinvested. We have recorded a provision of $2.5 million that reflects the income tax effects of the repatriation of these earnings. No additional income tax expense has been provided for any remaining undistributed foreign earnings, or any additional outside basis difference inherent in our foreign subsidiaries, as these amounts continue to be indefinitely reinvested. See Note 23 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-23-000044:mdna:121]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. During fiscal 2023, we repurchased an additional $250.0 million of our common stock under the stock repurchase program, and we had $250.0 million remaining under the current repurchase authorization as of October 28, 2023. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-23-000044:mdna:122]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our Revolving Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We have historically been successful in our ability to secure such sources of financing; however, our access to these sources of capital could be materially and adversely impacted, and we may not be able to receive terms as favorable as we have historically received, whether due to inflation or other factors. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-23-000044:mdna:123]
Cash Provided by Operating Activities

[0000936395-23-000044:mdna:124]
The following sections set forth the components of our $168.3 million of cash provided by operating activities for fiscal 2023:

[0000936395-23-000044:mdna:125]
Net Income (adjusted for non-cash charges)

[0000936395-23-000044:mdna:126]
The following table sets forth our net income (adjusted for non-cash charges) during fiscal 2023 (in thousands):

[0000936395-23-000044:mdna:127]
|  | Year Ended |
|  | October 28, 2023 |
| Net income | $ | 254,827 |  |
| Adjustments for non-cash charges: |  |
| Loss on extinguishment of debt | 1,864 |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 92,564 |  |
| Share-based compensation costs | 130,455 |  |
| Amortization of intangible assets | 49,616 |  |
| Deferred taxes | (14,852) |  |
| Provision for inventory excess and obsolescence | 29,464 |  |
| Provision for warranty | 31,742 |  |
| Gain on cost method equity investments, net | (26,368) |  |
| Other | 15,771 |  |
| Net income (adjusted for non-cash charges) | $ | 565,083 |  |

[0000936395-23-000044:mdna:128]
Working Capital

[0000936395-23-000044:mdna:129]
We used $396.8 million of cash for working capital during fiscal 2023. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-23-000044:mdna:130]
|  | Year Ended |
|  | October 28, 2023 |
| Cash used in accounts receivable | $ | (94,565) |  |
| Cash used in inventories | (132,497) |  |
| Cash used in prepaid expenses and other | (51,965) |  |
| Cash used in accounts payable, accruals and other obligations | (138,469) |  |
| Cash provided by deferred revenue | 27,412 |  |
| Cash used in operating lease assets and liabilities, net | (6,667) |  |
| Total cash used for working capital | $ | (396,751) |  |

[0000936395-23-000044:mdna:131]
As compared to the end of fiscal 2022:

[0000936395-23-000044:mdna:132]
•The $94.6 million of cash used in accounts receivable during fiscal 2023 primarily reflects increased sales volume in the fourth quarter of fiscal 2023;

[0000936395-23-000044:mdna:133]
•The $132.5 million of cash used in inventory during fiscal 2023 related to increases in finished goods inventories from planned fulfillment of customer advance orders for which some deliveries have since been rescheduled as described in “Overview” above;

[0000936395-23-000044:mdna:134]
•The $52.0 million of cash used in prepaid expenses and other during fiscal 2023 primarily reflects increases in prepaid value added taxes;

[0000936395-23-000044:mdna:135]
•The $138.5 million of cash used in accounts payable, accruals and other obligations during fiscal 2023 primarily reflects the timing of payments to suppliers, partially offset by a higher accrual rate related to Ciena’s 2023 annual cash incentive compensation plan;

[0000936395-23-000044:mdna:136]
•The $27.4 million of cash provided by deferred revenue during fiscal 2023 represents an increase in advanced payments received on multi-year maintenance contracts from customers prior to revenue recognition; and

[0000936395-23-000044:mdna:137]
•The $6.7 million of cash used in operating lease assets and liabilities, net, during fiscal 2023 represents cash paid for operating lease payments in excess of operating lease costs. For more details, see Note 18 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-23-000044:mdna:138]
Our days sales outstanding (“DSOs”) were 95 for fiscal 2023, as compared to 107 for fiscal 2022. The calculation of DSOs includes accounts receivable, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns slightly increased from 1.8 during fiscal 2022 to 2.0 during fiscal 2023 due to the supply chain beginning to stabilize as described above.

[0000936395-23-000044:mdna:139]
Cash Paid for Interest, Net

[0000936395-23-000044:mdna:140]
The following table sets forth the cash paid for interest, net during fiscal 2023 (in thousands):

[0000936395-23-000044:mdna:141]
|  | Year Ended |
|  | October 28, 2023 |
| 2025 Term Loan due September 28, 2025(1) | $ | 43,961 |  |
| 2030 Term Loan due January 19, 2030(2) | 28,364 |  |
| 2030 New Term Loan due October 28, 2030(3) | — |  |
| 2030 Senior Notes due January 31, 2030(4) | 16,000 |  |
| Interest rate swaps(5) | (10,035) |  |
| Revolving Credit Facilities(6) | 2,097 |  |
| Finance leases | 4,078 |  |
| Cash paid during period | $ | 84,465 |  |

[0000936395-23-000044:mdna:142]
(1) The 2025 Term Loan bore interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00% prior to its amendment on January 19, 2023, and then bore interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. The 2025 Term Loan was terminated on October 24, 2023.

[0000936395-23-000044:mdna:143]
(2) The 2030 Term Loan bore interest at SOFR for the chosen borrowing period plus a spread of 2.50% subject to a minimum SOFR rate of 0.00%. The 2030 Term Loan was terminated on October 24, 2023.

[0000936395-23-000044:mdna:144]
(3) Interest on the 2030 New Term Loan is payable periodically based on the interest period selected for borrowing. The 2030 New Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 2.00% subject to a minimum SOFR rate of 0.00%. At the end of fiscal 2023, the interest rate on the 2030 New Term Loan was 7.33%.

[0000936395-23-000044:mdna:145]
(4) The 2030 Senior Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest on the 2030 Notes is payable semiannually on January 31 and July 31 of each year.

[0000936395-23-000044:mdna:146]
(5) Our interest rate swaps fix the SOFR rate for $350.0 million of our Term Loans at 3.47% through January 2028 and another $350.0 million of our Term Loans at 2.968% through September 2025. In January 2023, we entered into a LIBOR to SOFR basis swap (“basis swap”). The basis swap and our LIBOR interest rate swaps, which matured in September 2023, fixed the SOFR rate for $350.0 million of our Term Loans at 2.883% from January to September 2023.

[0000936395-23-000044:mdna:147]
(6) During fiscal 2023, we issued certain standby letters of credit under the Revolving Credit Facility and its predecessor, the ABL Credit Facility and paid $2.1 million in commitment fees, interest expense and other administrative charges primarily relating to the ABL Credit Facility. The ABL Credit Facility was terminated on October 24, 2023.

[0000936395-23-000044:mdna:148]
For additional information about our short-term and long-term debt, revolving credit facilities and derivative instruments, see Notes 16, 19 and 20 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-23-000044:mdna:149]
Contractual Obligations

[0000936395-23-000044:mdna:150]
Debt. As of October 28, 2023, we had $1.2 billion outstanding principal associated with our 2030 New Term Loan, with $8.8 million maturing within 12 months. Interest payments on the 2030 New Term Loan and payments to be received under the interest rate swaps are variable and are calculated using the interest rate in effect as of the October 28, 2023. Future interest payments associated with the 2030 New Term Loan totaled $589.7 million, with $87.2 million payable within 12 months. As of October 28, 2023, we had $400.0 million outstanding principal associated with the 2030 Notes payable January 31, 2030. Future interest payments associated with the 2030 Notes totaled $104.0 million, with $16.0 million payable within 12 months. Future interest payments to be received net of payments under the interest rate swaps totaled $44.4 million, with $15.1 million to be received within 12 months. For additional information about our short-term and long-term debt and interest rate swaps, see Notes 16 and 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-23-000044:mdna:151]
Purchase Order Obligations. As of October 28, 2023, we had $1.7 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.

[0000936395-23-000044:mdna:152]
Leases. We have lease arrangements for facilities including research and development centers, engineering facilities and smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. As of October 28, 2023, we had fixed lease payment obligations of $125.7 million, with $25.8 million payable within 12 months. See Note 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-23-000044:mdna:153]
Off-Balance Sheet Arrangements

[0000936395-23-000044:mdna:154]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-23-000044:mdna:155]
Critical Accounting Policies and Estimates

[0000936395-23-000044:mdna:156]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report describes the significant accounting

[0000936395-23-000044:mdna:157]
policies and methods used in the preparation of the Consolidated Financial Statements. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-23-000044:mdna:158]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-23-000044:mdna:159]
Revenue Recognition

[0000936395-23-000044:mdna:160]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which we would expect to sell that product or service on a stand-alone basis at contract inception and that we would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when we sell the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000936395-23-000044:mdna:161]
We apply judgment in determining the transaction price, as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. We also consider any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-23-000044:mdna:162]
When transfer of control is judged to be over time for installation and professional service arrangements, we apply the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, we recognize revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-23-000044:mdna:163]
Our total deferred revenue for products was $28.4 million and $19.8 million as of October 28, 2023 and October 29, 2022, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $200.1 million and $180.4 million as of October 28, 2023 and October 29, 2022, respectively.

[0000936395-23-000044:mdna:164]
Business Combinations

[0000936395-23-000044:mdna:165]
We record acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur that may affect the accuracy or validity of such estimates. During fiscal 2022, we completed the acquisitions of AT&T’s Vyatta Software Technology (“Vyatta”) and Xelic, Inc. (“Xelic”) for an aggregate purchase price of $64.1 million. During fiscal 2023, we completed the acquisitions of Benu and Tibit for an aggregate purchase price of $291.7 million. See Note 4 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information regarding these transactions.

[0000936395-23-000044:mdna:166]
Share-Based Compensation

[0000936395-23-000044:mdna:167]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based on our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-23-000044:mdna:168]
Share-based compensation expense is taken into account based on awards granted. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of our share-based compensation. See Note 24 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of October 28, 2023, total unrecognized compensation expense was $201.0 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.39 years.

[0000936395-23-000044:mdna:169]
We are required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-23-000044:mdna:170]
Reserve for Inventory Obsolescence

[0000936395-23-000044:mdna:171]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. For fiscal 2023, future demand was calculated using both customer backlog and future forecasted sales. For fiscal 2022, future demand was calculated primarily based on customer backlog. Generally, our customers may cancel or change their orders with limited advance notice, or they may decide not to accept our products and services, although instances of both cancellation and non-acceptance are rare. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in our strategic direction, discontinuance of a product or introduction of newer versions of our products, declines in the sales of or forecasted demand for certain products, and general market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. Beginning in the second half of fiscal 2021, we started placing significant, advanced orders for supply of certain long lead time components to address our expected customer demand for fiscal 2022 and the then-emerging supply chain challenges. During the second half of fiscal 2023, supply for certain long lead time components began to stabilize and the need to place advance orders decreased for these components. As of October 28, 2023 and October 29, 2022, we had $1.7 billion and $2.6 billion, respectively, in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted.

[0000936395-23-000044:mdna:172]
We recorded charges for excess and obsolete inventory of $29.5 million, $16.2 million and $17.9 million in fiscal 2023, 2022 and 2021, respectively. Our inventory, net of allowance for excess and obsolescence, was $1.1 billion and $946.7 million as of October 28, 2023 and October 29, 2022, respectively.

[0000936395-23-000044:mdna:173]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0000936395-23-000044:mdna:174]
We estimate our allowances for credit losses using relevant available information from internal and external sources. This information is related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine

[0000936395-23-000044:mdna:175]
collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the probability that the asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.

[0000936395-23-000044:mdna:176]
Probability of default rates is published by third-party credit rating agencies. Adjustments to our exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000936395-23-000044:mdna:177]
Our accounts receivable, net of allowance for credit losses, was $1.0 billion and $920.8 million as of October 28, 2023 and October 29, 2022, respectively. Our allowance for credit losses was $11.7 million and $11.0 million as of October 28, 2023 and October 29, 2022, respectively.

[0000936395-23-000044:mdna:178]
Our contract assets for unbilled accounts receivable, net of allowance for credit losses, was $150.3 million and $156.0 million as of October 28, 2023 and October 29, 2022, respectively. Our allowance for credit losses was $0.1 million and $0.2 million as of October 28, 2023 and October 29, 2022, respectively.

[0000936395-23-000044:mdna:179]
Goodwill

[0000936395-23-000044:mdna:180]
Our goodwill was generated from the acquisitions of (i) Cyan, Inc. during fiscal 2015, (ii) the high-speed photonics components assets of TeraXion, Inc. during fiscal 2016, (iii) Packet Design, LLC and DonRiver Holdings, LLC during fiscal 2019, (iv) Centina Systems, Inc. during fiscal 2020, (v) Vyatta and Xelic during fiscal 2022 and (vi) Benu and Tibit during fiscal 2023. The goodwill from these acquisitions is primarily related to expected economic synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be as of the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-23-000044:mdna:181]
We test goodwill impairment by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. Goodwill is allocated to reporting units based on relative fair value using a discounted cash flow model. If this test indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of October 28, 2023 and October 29, 2022, the goodwill balance was $444.8 million and $328.3 million, respectively. There were no goodwill impairments resulting from our fiscal 2023 and 2022 impairment tests and no reporting unit was determined to be at risk of failing the goodwill impairment test. See Note 14 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-23-000044:mdna:182]
Long-lived Assets

[0000936395-23-000044:mdna:183]
Our long-lived assets include equipment, building, furniture and fixtures, operating right-of-use assets, finite-lived intangible assets and maintenance spares. As of October 28, 2023 and October 29, 2022, these assets totaled $575.0 million and $427.2 million, net, respectively. We test long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the assets’ carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-23-000044:mdna:184]
Deferred Tax Assets

[0000936395-23-000044:mdna:185]
Pursuant to ASC Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-23-000044:mdna:186]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. The valuation allowance balances at October 28, 2023 and October 29, 2022 were $189.9 million and $162.1 million, respectively. The corresponding net deferred tax assets were $809.3 million and $824.0 million, respectively. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending on our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy.

[0000936395-23-000044:mdna:187]
During fiscal 2021, we completed an internal transfer of certain of our non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $119.3 million deferred tax asset with a corresponding tax benefit. The recognition of the deferred tax asset from the internal transfer of the non-U.S. intangible assets requires management to make estimates and assumptions to determine the fair value of the intangible assets transferred and significant judgments in evaluating the application of tax laws in the applicable jurisdictions, including where the deferred tax asset will be recovered. Estimates in valuing the intangible assets include, but are not limited to, internal revenue and expense forecasts, the estimated life of the intangible assets, and discount rates, which are affected by expectations about future market or economic conditions. Although we believe the assumptions and estimates that we have made are reasonable and appropriate, they are based, in part, on historical experience and are inherently uncertain.

[0000936395-23-000044:mdna:188]
For further discussion, see Note 23 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-23-000044:mdna:189]
Warranty

[0000936395-23-000044:mdna:190]
Our liability for product warranties, included in accrued liabilities and other short-term obligations, was $57.1 million and $45.5 million as of October 28, 2023 and October 29, 2022, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily on historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily on historical trends and the cost to support customer repairs within the warranty period. The provision for product warranties, net of adjustments for previous years’ provisions, was $31.7 million, $17.4 million and $17.1 million for fiscal 2023, 2022 and 2021, respectively. The provision for warranty claims may fluctuate on a quarterly basis depending on the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. See Note 15 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-23-000044:mdna:191]
Effects of Recent Accounting Pronouncements

[0000936395-23-000044:mdna:192]
See Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to our discussion of the effects of recent accounting pronouncements.
