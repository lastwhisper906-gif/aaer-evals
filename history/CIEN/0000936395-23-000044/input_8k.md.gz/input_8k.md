# CIEN 8-K — 0000936395-23-000041 filed 2023-12-07

## item codes, every 8-K on or before 2023-12-15

- 2023-12-07 0000936395-23-000041 — 2.02, 9.01
- 2023-10-25 0001193125-23-263172 — 1.01, 1.02, 2.03, 9.01
- 2023-10-03 0000936395-23-000037 — 5.02, 7.01, 9.01
- 2023-08-31 0000936395-23-000030 — 2.02, 5.02, 9.01
- 2023-06-06 0000936395-23-000024 — 2.02, 9.01
- 2023-04-06 0001193125-23-093438 — 7.01, 9.01
- 2023-04-03 0000936395-23-000018 — 5.07
- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2023-12-15

- none on or before 2023-12-15

## item 2.02 — earnings release, exhibit 99.1

[0000936395-23-000041:8k_2_02:1]
EX-99.1
2
ex9912023q4earningspressre.htm
EX-99.1

[0000936395-23-000041:8k_2_02:2]
Document

[0000936395-23-000041:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-23-000041:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2023 Financial Results

[0000936395-23-000041:8k_2_02:5]
Annual revenue increased 21%

[0000936395-23-000041:8k_2_02:6]
HANOVER, Md. - December 7, 2023 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal fourth quarter ended October 28, 2023.

[0000936395-23-000041:8k_2_02:7]
•Q4 Revenue: $1.13 billion

[0000936395-23-000041:8k_2_02:8]
•Q4 Net Income per Share: $0.62 GAAP; $0.75 adjusted (non-GAAP)

[0000936395-23-000041:8k_2_02:9]
•Share Repurchases: Repurchased approximately 4.2 million shares of common stock for an aggregate price of $188.8 million during the quarter

[0000936395-23-000041:8k_2_02:10]
"Today we reported strong fiscal fourth quarter results, driven by positive demand dynamics, particularly with cloud provider customers. We delivered an outstanding fiscal year with 21% growth in revenue, gaining significant market share and further advancing our industry leadership position," said Gary Smith, president and CEO, Ciena. "Looking ahead, as we execute on our strategy to extend our market leadership in optical while expanding our opportunities in routing and switching, we expect to continue to grow revenue faster than the market and take share."

[0000936395-23-000041:8k_2_02:11]
For fiscal fourth quarter 2023, Ciena reported revenue of $1.13 billion as compared to $971.0 million for the fiscal fourth quarter 2022. For fiscal year 2023, Ciena reported revenue of $4.39 billion, as compared to $3.63 billion for fiscal year 2022.

[0000936395-23-000041:8k_2_02:12]
Ciena's GAAP net income for the fiscal fourth quarter 2023 was $91.2 million, or $0.62 per diluted common share, which compares to a GAAP net income of $57.6 million, or $0.39 per diluted common share, for the fiscal fourth quarter 2022. For fiscal year 2023, Ciena's GAAP net income was $254.8 million, or $1.71 per diluted common share, as compared to GAAP net income of $152.9 million, or $1.00 per diluted common share, for fiscal year 2022.

[0000936395-23-000041:8k_2_02:13]
Ciena's adjusted (non-GAAP) net income for the fiscal fourth quarter 2023 was $111.2 million, or $0.75 per diluted common share, which compares to an adjusted (non-GAAP) net income of $90.9 million, or $0.61 per diluted common share, for the fiscal fourth quarter 2022. For fiscal year 2023, Ciena's adjusted (non-GAAP) net income was $406.3, or $2.72 per diluted common share, as compared to adjusted (non-GAAP) net income of $288.9, or $1.90 per diluted common share, for fiscal year 2022.

[0000936395-23-000041:8k_2_02:14]
Performance Summary For Fiscal Fourth Quarter and Year Ended October 28, 2023

[0000936395-23-000041:8k_2_02:15]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly and annual results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-23-000041:8k_2_02:16]
|  |  | GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Year Ended |  | Period |
|  |  | October 28, |  | October 29, |  | Change |  | October 28, |  | October 29, |  | Change |
|  |  | 2023 |  | 2022 |  | Y-T-Y* |  | 2023 |  | 2022 |  | Y-T-Y* |
| Revenue |  | $ | 1,129.5 |  |  | $ | 971.0 |  |  | 16.3 | % |  | $ | 4,386.5 |  |  | $ | 3,632.7 |  |  | 20.8 | % |
| Gross margin |  | 43.1 | % |  | 44.7 | % |  | (1.6) | % |  | 42.8 | % |  | 43.0 | % |  | (0.2) | % |
| Operating expense |  | $ | 395.0 |  |  | $ | 356.3 |  |  | 10.9 | % |  | $ | 1,521.3 |  |  | $ | 1,337.5 |  |  | 13.7 | % |
| Operating margin |  | 8.1 | % |  | 8.0 | % |  | 0.1 | % |  | 8.2 | % |  | 6.1 | % |  | 2.1 | % |

[0000936395-23-000041:8k_2_02:17]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Year Ended |  | Period |
|  |  | October 28, |  | October 29, |  | Change |  | October 28, |  | October 29, |  | Change |
|  |  | 2023 |  | 2022 |  | Y-T-Y* |  | 2023 |  | 2022 |  | Y-T-Y* |
| Revenue |  | $ | 1,129.5 |  |  | $ | 971.0 |  |  | 16.3 | % |  | $ | 4,386.5 |  |  | $ | 3,632.7 |  |  | 20.8 | % |
| Adj. gross margin |  | 43.7 | % |  | 45.2 | % |  | (1.5) | % |  | 43.5 | % |  | 43.6 | % |  | (0.1) | % |
| Adj. operating expense |  | $ | 337.6 |  |  | $ | 312.8 |  |  | 7.9 | % |  | $ | 1,332.8 |  |  | $ | 1,177.0 |  |  | 13.2 | % |
| Adj. operating margin |  | 13.8 | % |  | 13.0 | % |  | 0.8 | % |  | 13.1 | % |  | 11.2 | % |  | 1.9 | % |
| Adj. EBITDA |  | $ | 178.8 |  |  | $ | 153.5 |  |  | 16.5 | % |  | $ | 665.8 |  |  | $ | 502.4 |  |  | 32.5 | % |

[0000936395-23-000041:8k_2_02:18]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-23-000041:8k_2_02:19]
|  |  | Revenue by Segment (unaudited) |
|  |  | Quarter Ended |
|  |  | October 28, 2023 |  | October 29, 2022 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking 1 |  | $ | 748.0 |  |  | 66.2 |  |  | $ | 649.9 |  |  | 66.9 |  |
| Routing and Switching |  | 128.9 |  |  | 11.4 |  |  | 102.8 |  |  | 10.6 |  |
| Total Networking Platforms |  | 876.9 |  |  | 77.6 |  |  | 752.7 |  |  | 77.5 |  |
| Platform Software and Services |  | 82.1 |  |  | 7.3 |  |  | 71.6 |  |  | 7.4 |  |
| Blue Planet Automation Software and Services |  | 20.0 |  |  | 1.8 |  |  | 21.2 |  |  | 2.2 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 74.4 |  |  | 6.6 |  |  | 73.1 |  |  | 7.5 |  |
| Installation and Deployment |  | 60.1 |  |  | 5.3 |  |  | 36.9 |  |  | 3.8 |  |
| Consulting and Network Design |  | 16.0 |  |  | 1.4 |  |  | 15.5 |  |  | 1.6 |  |
| Total Global Services |  | 150.5 |  |  | 13.3 |  |  | 125.5 |  |  | 12.9 |  |
| Total |  | $ | 1,129.5 |  |  | 100.0 |  |  | $ | 971.0 |  |  | 100.0 |  |

[0000936395-23-000041:8k_2_02:20]
2

[0000936395-23-000041:8k_2_02:21]
|  |  | Revenue by Segment (unaudited) |
|  |  | Year Ended |
|  |  | October 28, 2023 |  | October 29, 2022 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking 1 |  | $ | 2,987.3 |  |  | 68.1 |  |  | $ | 2,380.0 |  |  | 65.5 |  |
| Routing and Switching |  | 506.2 |  |  | 11.5 |  |  | 398.4 |  |  | 11.0 |  |
| Total Networking Platforms |  | 3,493.5 |  |  | 79.6 |  |  | 2,778.4 |  |  | 76.5 |  |
| Platform Software and Services |  | 303.9 |  |  | 6.9 |  |  | 277.2 |  |  | 7.6 |  |
| Blue Planet Automation Software and Services |  | 69.1 |  |  | 1.6 |  |  | 76.6 |  |  | 2.1 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 288.3 |  |  | 6.6 |  |  | 292.4 |  |  | 8.1 |  |
| Installation and Deployment |  | 181.0 |  |  | 4.1 |  |  | 157.4 |  |  | 4.3 |  |
| Consulting and Network Design |  | 50.7 |  |  | 1.2 |  |  | 50.7 |  |  | 1.4 |  |
| Total Global Services |  | 520.0 |  |  | 11.9 |  |  | 500.5 |  |  | 13.8 |  |
| Total |  | $ | 4,386.5 |  |  | 100.0 |  |  | $ | 3,632.7 |  |  | 100.0 |  |

[0000936395-23-000041:8k_2_02:22]
**  Denotes %  of total revenue

[0000936395-23-000041:8k_2_02:23]
1  Ciena renamed its former “Converged Packet Optical” product line “Optical Networking” effective as of the fourth quarter of fiscal 2023. This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results or the composition of this product category.

[0000936395-23-000041:8k_2_02:24]
Additional Performance Metrics for Fiscal Fourth Quarter and Year Ended October 28, 2023

[0000936395-23-000041:8k_2_02:25]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Quarter Ended |
|  |  | October 28, 2023 |  | October 29, 2022 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 801.4 |  |  | 71.0 |  |  | $ | 723.5 |  |  | 74.5 |  |
| Europe, Middle East and Africa |  | 164.1 |  |  | 14.5 |  |  | 135.1 |  |  | 13.9 |  |
| Asia Pacific |  | 164.0 |  |  | 14.5 |  |  | 112.4 |  |  | 11.6 |  |
| Total |  | $ | 1,129.5 |  |  | 100.0 |  |  | $ | 971.0 |  |  | 100.0 |  |

[0000936395-23-000041:8k_2_02:26]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Year Ended |
|  |  | October 28, 2023 |  | October 29, 2022 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 3,110.3 |  |  | 70.9 |  |  | $ | 2,636.9 |  |  | 72.6 |  |
| Europe, Middle East and Africa |  | 643.1 |  |  | 14.7 |  |  | 555.2 |  |  | 15.3 |  |
| Asia Pacific |  | 633.1 |  |  | 14.4 |  |  | 440.6 |  |  | 12.1 |  |
| Total |  | $ | 4,386.5 |  |  | 100.0 |  |  | $ | 3,632.7 |  |  | 100.0 |  |

[0000936395-23-000041:8k_2_02:27]
**  Denotes %  of total revenue

[0000936395-23-000041:8k_2_02:28]
•Two customers represented 10%-plus of revenue for the fiscal fourth quarter 2023, combining for a total of 29.7% of revenue. Two customers represented 10%-plus of revenue for the fiscal year 2023, combining for a total of 23.4% of revenue.

[0000936395-23-000041:8k_2_02:29]
•Cash and investments at the end of fiscal year 2023 totaled $1.25 billion

[0000936395-23-000041:8k_2_02:30]
•Cash flow from operations totaled $195.5 million and $168.3 million for the fiscal fourth quarter and the fiscal year 2023, respectively

[0000936395-23-000041:8k_2_02:31]
•Average days' sales outstanding (DSOs) were 92 and 95 for the fiscal fourth quarter and the fiscal year 2023, respectively

[0000936395-23-000041:8k_2_02:32]
•Accounts receivable, net balance was $1.00 billion

[0000936395-23-000041:8k_2_02:33]
•Unbilled contract assets, net balance was $150.3 million

[0000936395-23-000041:8k_2_02:34]
•Inventories totaled $1.05 billion, including:

[0000936395-23-000041:8k_2_02:35]
◦Raw materials: $664.8 million

[0000936395-23-000041:8k_2_02:36]
◦Work in process: $55.2 million

[0000936395-23-000041:8k_2_02:37]
◦Finished goods: $314.2 million

[0000936395-23-000041:8k_2_02:38]
◦Deferred cost of sales: $66.6 million

[0000936395-23-000041:8k_2_02:39]
◦Reserve for excess and obsolescence: $(50.0) million

[0000936395-23-000041:8k_2_02:40]
•Product inventory turns were 2.0 for both the fiscal fourth quarter and the fiscal year 2023.

[0000936395-23-000041:8k_2_02:41]
•Headcount totaled 8,483 at the end of fiscal year 2023

[0000936395-23-000041:8k_2_02:42]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2023 Results

[0000936395-23-000041:8k_2_02:43]
Today, Thursday, December 7, 2023, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal fourth quarter 2023 results.

[0000936395-23-000041:8k_2_02:44]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-23-000041:8k_2_02:45]
Notes to Investors

[0000936395-23-000041:8k_2_02:46]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "Today we reported strong fiscal fourth quarter results, driven by positive demand dynamics, particularly with cloud provider customers"; "We delivered an outstanding fiscal year with 21% growth in revenue, gaining significant market share and further advancing our industry leadership position"; "Looking ahead, as we execute on our

[0000936395-23-000041:8k_2_02:47]
strategy to extend our market leadership in optical while expanding our opportunities in routing and switching, we expect to continue to grow revenue faster than the market and take share."

[0000936395-23-000041:8k_2_02:48]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers, their spending and their businesses and markets; our ability to execute our business and growth strategies; the impact of macroeconomic conditions and global supply chain constraints or disruptions including increased supply costs and lead times; the impact of the introduction of new technologies by us or our competitors; seasonality and the timing and size of customer orders, their delivery dates and our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical tensions or events, including but not limited to the ongoing conflicts between Ukraine and Russia, and Israel and Hamas, and public health emergencies or epidemics, including the COVID-19 pandemic; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; cyberattacks, data breaches or other security incidents involving our enterprise network environment or our products; regulatory changes, litigation involving our intellectual property or government investigations; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including Ciena's Quarterly Report on Form 10-Q filed with the SEC on September 6, 2023 and its Annual Report on Form 10-K to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-23-000041:8k_2_02:49]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-23-000041:8k_2_02:50]
About Ciena. Ciena (NYSE: CIEN) is a global leader in networking systems, services, and software. We build the most adaptive networks in the industry, enabling customers to anticipate and meet ever-increasing digital demands. For three-plus decades, Ciena has brought our humanity to our relentless pursuit of innovation. Prioritizing collaborative relationships with our customers, partners, and communities, we create flexible, open, and sustainable networks that better serve all users—today and into the future. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-23-000041:8k_2_02:51]
5

[0000936395-23-000041:8k_2_02:52]
CIENA CORPORATION

[0000936395-23-000041:8k_2_02:53]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-23-000041:8k_2_02:54]
(in thousands, except per share data)

[0000936395-23-000041:8k_2_02:55]
(unaudited)

[0000936395-23-000041:8k_2_02:56]
|  | Quarter Ended |  | Year Ended |
|  | October 28, |  | October 29, |  | October 28, |  | October 29, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 902,797 |  |  | $ | 779,609 |  |  | $ | 3,581,039 |  |  | $ | 2,888,848 |  |
| Services | 226,690 |  |  | 191,401 |  |  | 805,510 |  |  | 743,813 |  |
| Total revenue | 1,129,487 |  |  | 971,010 |  |  | 4,386,549 |  |  | 3,632,661 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 529,320 |  |  | 440,253 |  |  | 2,088,440 |  |  | 1,699,631 |  |
| Services | 113,886 |  |  | 97,160 |  |  | 419,258 |  |  | 372,686 |  |
| Total cost of goods sold | 643,206 |  |  | 537,413 |  |  | 2,507,698 |  |  | 2,072,317 |  |
| Gross profit | 486,281 |  |  | 433,597 |  |  | 1,878,851 |  |  | 1,560,344 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 189,444 |  |  | 166,898 |  |  | 750,559 |  |  | 624,656 |  |
| Selling and marketing | 123,648 |  |  | 121,865 |  |  | 490,804 |  |  | 466,565 |  |
| General and administrative | 64,100 |  |  | 48,191 |  |  | 215,284 |  |  | 179,382 |  |
| Significant asset impairments and restructuring costs | 7,209 |  |  | 13,621 |  |  | 23,834 |  |  | 33,824 |  |
| Amortization of intangible assets | 10,578 |  |  | 5,754 |  |  | 37,351 |  |  | 32,511 |  |
| Acquisition and integration costs | — |  |  | — |  |  | 3,474 |  |  | 598 |  |
| Total operating expenses | 394,979 |  |  | 356,329 |  |  | 1,521,306 |  |  | 1,337,536 |  |
| Income from operations | 91,302 |  |  | 77,268 |  |  | 357,545 |  |  | 222,808 |  |
| Interest and other income, net | 11,297 |  |  | 1,887 |  |  | 62,008 |  |  | 6,747 |  |
| Interest expense | (24,207) |  |  | (13,775) |  |  | (88,026) |  |  | (47,050) |  |
| Loss on extinguishment and modification of debt | (7,874) |  |  | — |  |  | (7,874) |  |  | — |  |
| Income before income taxes | 70,518 |  |  | 65,380 |  |  | 323,653 |  |  | 182,505 |  |
| Provision (benefit) for income taxes1 | (20,681) |  |  | 7,735 |  |  | 68,826 |  |  | 29,603 |  |
| Net income | $ | 91,199 |  |  | $ | 57,645 |  |  | $ | 254,827 |  |  | $ | 152,902 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.62 |  |  | $ | 0.39 |  |  | $ | 1.71 |  |  | $ | 1.01 |  |
| Diluted net income per potential common share | $ | 0.62 |  |  | $ | 0.39 |  |  | $ | 1.71 |  |  | $ | 1.00 |  |
| Weighted average basic common shares outstanding | 147,437 |  |  | 148,548 |  |  | 148,971 |  |  | 151,208 |  |
| Weighted average dilutive potential common shares outstanding 2 | 147,891 |  |  | 149,111 |  |  | 149,380 |  |  | 152,193 |  |

[0000936395-23-000041:8k_2_02:57]
1 For the fourth quarter and year ended fiscal 2023, reflects a tax benefit resulting, in part, from guidance in Notice 2023-63 issued by the IRS addressing capitalization and amortization of specified research or experimental expenditures under Section 174 in accordance with the Tax Cuts and Jobs Act.

[0000936395-23-000041:8k_2_02:58]
2 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 0.5 million and 0.4 million shares for the fourth quarter and year ended fiscal 2023, respectively; and (ii) 0.6 million and 1.0 million shares for the fourth quarter and year ended fiscal 2022, respectively.

[0000936395-23-000041:8k_2_02:59]
CIENA CORPORATION

[0000936395-23-000041:8k_2_02:60]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-23-000041:8k_2_02:61]
(in thousands, except share data)

[0000936395-23-000041:8k_2_02:62]
(unaudited)

[0000936395-23-000041:8k_2_02:63]
|  | October 28,2023 |  | October 29,2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,010,618 |  |  | $ | 994,352 |  |
| Short-term investments | 104,753 |  |  | 153,989 |  |
| Accounts receivable, net | 1,003,876 |  |  | 920,772 |  |
| Inventories, net | 1,050,838 |  |  | 946,730 |  |
| Prepaid expenses and other | 405,694 |  |  | 370,053 |  |
| Total current assets | 3,575,779 |  |  | 3,385,896 |  |
| Long-term investments | 134,278 |  |  | 35,385 |  |
| Equipment, building, furniture and fixtures, net | 280,147 |  |  | 267,779 |  |
| Operating lease right-of-use assets | 35,140 |  |  | 45,108 |  |
| Goodwill | 444,765 |  |  | 328,322 |  |
| Other intangible assets, net | 205,627 |  |  | 69,517 |  |
| Deferred tax asset, net | 809,306 |  |  | 824,008 |  |
| Other long-term assets | 116,453 |  |  | 113,617 |  |
| Total assets | $ | 5,601,495 |  |  | $ | 5,069,632 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 317,828 |  |  | $ | 516,047 |  |
| Accrued liabilities and other short-term obligations | 431,419 |  |  | 360,782 |  |
| Deferred revenue | 154,419 |  |  | 137,899 |  |
| Operating lease liabilities | 16,655 |  |  | 18,925 |  |
| Current portion of long-term debt | 11,700 |  |  | 6,930 |  |
| Total current liabilities | 932,021 |  |  | 1,040,583 |  |
| Long-term deferred revenue | 74,041 |  |  | 62,336 |  |
| Other long-term obligations | 170,407 |  |  | 150,335 |  |
| Long-term operating lease liabilities | 33,259 |  |  | 42,392 |  |
| Long-term debt, net | 1,543,406 |  |  | 1,061,125 |  |
| Total liabilities | 2,753,134 |  |  | 2,356,771 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 144,829,938 and 148,412,943 shares issued and outstanding | 1,448 |  |  | 1,484 |  |
| Additional paid-in capital | 6,262,083 |  |  | 6,390,252 |  |
| Accumulated other comprehensive loss | (37,767) |  |  | (46,645) |  |
| Accumulated deficit | (3,377,403) |  |  | (3,632,230) |  |
| Total stockholders’ equity | 2,848,361 |  |  | 2,712,861 |  |
| Total liabilities and stockholders’ equity | $ | 5,601,495 |  |  | $ | 5,069,632 |  |

[0000936395-23-000041:8k_2_02:64]
7

[0000936395-23-000041:8k_2_02:65]
CIENA CORPORATION

[0000936395-23-000041:8k_2_02:66]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-23-000041:8k_2_02:67]
(in thousands) (unaudited)

[0000936395-23-000041:8k_2_02:68]
|  | Year Ended |
|  | October 28, |  | October 29, |
|  | 2023 |  | 2022 |
| Cash flows used in operating activities: |  |  |  |
| Net income | $ | 254,827 |  |  | $ | 152,902 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |
| Loss on extinguishment of debt | 1,864 |  |  | — |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 92,564 |  |  | 95,922 |  |
| Share-based compensation expense | 130,455 |  |  | 105,131 |  |
| Amortization of intangible assets | 49,616 |  |  | 44,281 |  |
| Deferred taxes | (14,852) |  |  | (27,502) |  |
| Provision for inventory excess and obsolescence | 29,464 |  |  | 16,184 |  |
| Provision for warranty | 31,742 |  |  | 17,440 |  |
| Gain on cost method equity investments, net | (26,368) |  |  | (4,120) |  |
| Other | 15,771 |  |  | 4,120 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (94,565) |  |  | (47,069) |  |
| Inventories | (132,497) |  |  | (589,113) |  |
| Prepaid expenses and other | (51,965) |  |  | (58,996) |  |
| Operating lease right-of-use assets | 14,190 |  |  | 16,453 |  |
| Accounts payable, accruals and other obligations | (138,469) |  |  | 100,327 |  |
| Deferred revenue | 27,412 |  |  | 26,380 |  |
| Short and long-term operating lease liabilities | (20,857) |  |  | (20,096) |  |
| Net cash used in operating activities | 168,332 |  |  | (167,756) |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (106,197) |  |  | (90,818) |  |
| Purchases of investments | (252,329) |  |  | (647,526) |  |
| Proceeds from sales and maturities of investments | 208,104 |  |  | 702,197 |  |
| Settlement of foreign currency forward contracts, net | (2,984) |  |  | 4,942 |  |
| Purchase of cost method equity investments | — |  |  | (8,000) |  |
| Acquisition of business, net of cash acquired | (230,048) |  |  | (62,043) |  |
| Net cash used in investing activities | (383,454) |  |  | (101,248) |  |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Proceeds from issuance of senior notes | — |  |  | 400,000 |  |
| Proceeds from issuance of term loan, net | 497,500 |  |  | — |  |
| Payment of long term debt | (9,430) |  |  | (5,197) |  |
| Proceeds for modification of term loan | 830 |  |  | — |  |
| Payment of debt issuance costs | (6,379) |  |  | (5,484) |  |
| Payment of finance lease obligations | (3,791) |  |  | (3,468) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (38,506) |  |  | (48,454) |  |
| Repurchases of common stock - repurchase program | (242,201) |  |  | (500,800) |  |
| Proceeds from issuance of common stock | 31,357 |  |  | 30,348 |  |
| Net cash provided by (used in) financing activities | 229,380 |  |  | (133,055) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 2,150 |  |  | (26,167) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 16,408 |  |  | (428,226) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 994,378 |  |  | 1,422,604 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,010,786 |  |  | $ | 994,378 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 84,465 |  |  | $ | 42,812 |  |
| Cash paid during the period for income taxes, net | $ | 78,242 |  |  | $ | 34,967 |  |
| Operating lease payments | $ | 22,782 |  |  | $ | 21,661 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 6,990 |  |  | $ | 12,373 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 9,310 |  |  | $ | — |  |
| Operating right-of-use assets subject to lease liability | $ | 10,236 |  |  | $ | 23,242 |  |
| Gain on cost method equity investments, net | $ | 26,368 |  |  | $ | 4,120 |  |

[0000936395-23-000041:8k_2_02:69]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 28, |  | October 29, |  | October 28, |  | October 29, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 486,281 |  |  | $ | 433,597 |  |  | $ | 1,878,851 |  |  | $ | 1,560,344 |  |
| Share-based compensation-products |  | 1,194 |  |  | 907 |  |  | 4,518 |  |  | 3,867 |  |
| Share-based compensation-services |  | 2,827 |  |  | 2,066 |  |  | 10,470 |  |  | 7,533 |  |
| Amortization of intangible assets |  | 2,763 |  |  | 2,005 |  |  | 12,264 |  |  | 11,770 |  |
| Total adjustments related to gross profit |  | 6,784 |  |  | 4,978 |  |  | 27,252 |  |  | 23,170 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 493,065 |  |  | $ | 438,575 |  |  | $ | 1,906,103 |  |  | $ | 1,583,514 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.7 | % |  | 45.2 | % |  | 43.5 | % |  | 43.6 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 394,979 |  |  | $ | 356,329 |  |  | $ | 1,521,306 |  |  | $ | 1,337,536 |  |
| Share-based compensation-research and development |  | 11,412 |  |  | 8,507 |  |  | 42,331 |  |  | 31,879 |  |
| Share-based compensation-sales and marketing |  | 9,187 |  |  | 8,084 |  |  | 35,136 |  |  | 31,280 |  |
| Share-based compensation-general and administrative |  | 10,274 |  |  | 7,610 |  |  | 37,587 |  |  | 30,435 |  |
| Significant asset impairments and restructuring costs |  | 7,209 |  |  | 13,621 |  |  | 23,834 |  |  | 33,824 |  |
| Amortization of intangible assets |  | 10,578 |  |  | 5,754 |  |  | 37,351 |  |  | 32,511 |  |
| Acquisition and integration costs |  | — |  |  | — |  |  | 3,474 |  |  | 598 |  |
| Legal settlement |  | 8,750 |  |  | — |  |  | 8,750 |  |  | — |  |
| Total adjustments related to operating expense |  | 57,410 |  |  | 43,576 |  |  | 188,463 |  |  | 160,527 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 337,569 |  |  | $ | 312,753 |  |  | $ | 1,332,843 |  |  | $ | 1,177,009 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 91,302 |  |  | $ | 77,268 |  |  | $ | 357,545 |  |  | $ | 222,808 |  |
| Total adjustments related to gross profit |  | 6,784 |  |  | 4,978 |  |  | 27,252 |  |  | 23,170 |  |
| Total adjustments related to operating expense |  | 57,410 |  |  | 43,576 |  |  | 188,463 |  |  | 160,527 |  |
| Total adjustments related to income from operations |  | 64,194 |  |  | 48,554 |  |  | 215,715 |  |  | 183,697 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 155,496 |  |  | $ | 125,822 |  |  | $ | 573,260 |  |  | $ | 406,505 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 13.8 | % |  | 13.0 | % |  | 13.1 | % |  | 11.2 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 91,199 |  |  | $ | 57,645 |  |  | $ | 254,827 |  |  | $ | 152,902 |  |
| Exclude GAAP provision for income taxes |  | (20,681) |  |  | 7,735 |  |  | 68,826 |  |  | 29,603 |  |
| Income before income taxes |  | 70,518 |  |  | 65,380 |  |  | 323,653 |  |  | 182,505 |  |
| Total adjustments related to income from operations |  | 64,194 |  |  | 48,554 |  |  | 215,715 |  |  | 183,697 |  |
| Loss on extinguishment and modification of debt |  | 7,874 |  |  | — |  |  | 7,874 |  |  | — |  |
| Gain on cost method equity investments, net |  | — |  |  | — |  |  | (26,368) |  |  | (4,120) |  |
| Adjusted income before income taxes |  | 142,586 |  |  | 113,934 |  |  | 520,874 |  |  | 362,082 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 31,369 |  |  | 23,015 |  |  | 114,592 |  |  | 73,141 |  |
| Adjusted (non-GAAP) net income |  | $ | 111,217 |  |  | $ | 90,919 |  |  | $ | 406,282 |  |  | $ | 288,941 |  |

[0000936395-23-000041:8k_2_02:70]
9

[0000936395-23-000041:8k_2_02:71]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 28, |  | October 29, |  | October 28, |  | October 29, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Weighted average basic common shares outstanding |  | 147,437 |  | 148,548 |  | 148,971 |  | 151,208 |
| Weighted average dilutive potential common shares outstanding 1 |  | 147,891 |  | 149,111 |  | 149,380 |  | 152,193 |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.62 |  |  | $ | 0.39 |  |  | $ | 1.71 |  |  | $ | 1.00 |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.75 |  |  | $ | 0.61 |  |  | $ | 2.72 |  |  | $ | 1.90 |  |

[0000936395-23-000041:8k_2_02:72]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 0.5 million and 0.4 million for the fourth quarter and year ended fiscal 2023, respectively; and (ii) 0.6 million and 1.0 million for the fourth quarter and year ended fiscal 2022, respectively.

[0000936395-23-000041:8k_2_02:73]
10

[0000936395-23-000041:8k_2_02:74]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 28, |  | October 29, |  | October 28, |  | October 29, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 91,199 |  |  | $ | 57,645 |  |  | $ | 254,827 |  |  | $ | 152,902 |  |
| Add: Interest expense |  | 24,207 |  |  | 13,775 |  |  | 88,026 |  |  | 47,050 |  |
| Less: Interest and other income, net |  | 11,297 |  |  | 1,887 |  |  | 62,008 |  |  | 6,747 |  |
| Add: Loss on extinguishment and modification of debt |  | 7,874 |  |  | — |  |  | 7,874 |  |  | — |  |
| Add: Provision (benefit) for income taxes |  | (20,681) |  |  | 7,735 |  |  | 68,826 |  |  | 29,603 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 23,351 |  |  | 27,642 |  |  | 92,564 |  |  | 95,922 |  |
| Add: Amortization of intangible assets |  | 13,342 |  |  | 7,759 |  |  | 49,616 |  |  | 44,281 |  |
| EBITDA |  | $ | 127,995 |  |  | $ | 112,669 |  |  | $ | 499,725 |  |  | $ | 363,011 |  |
| Add: Share-based compensation cost |  | 34,894 |  |  | 27,174 |  |  | 130,042 |  |  | 104,994 |  |
| Add: Significant asset impairments and restructuring costs |  | 7,209 |  |  | 13,621 |  |  | 23,834 |  |  | 33,824 |  |
| Add: Acquisition and integration costs |  | — |  |  | — |  |  | 3,474 |  |  | 598 |  |
| Add: Legal settlement |  | 8,750 |  |  | — |  |  | 8,750 |  |  | — |  |
| Adjusted EBITDA |  | $ | 178,848 |  |  | $ | 153,464 |  |  | $ | 665,825 |  |  | $ | 502,427 |  |

[0000936395-23-000041:8k_2_02:75]
* * *

[0000936395-23-000041:8k_2_02:76]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-23-000041:8k_2_02:77]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-23-000041:8k_2_02:78]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities, and the redesign of business processes including restructuring certain real estate facilities.

[0000936395-23-000041:8k_2_02:79]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over an expected useful life.

[0000936395-23-000041:8k_2_02:80]
•Acquisition and integration costs - primarily consist of financial, legal and accounting advisors' costs and employment-related costs related to Ciena's acquisitions in fiscal 2022 and fiscal 2023.

[0000936395-23-000041:8k_2_02:81]
•Loss on extinguishment and modification of debt - reflects extinguishment and debt modification expenses related to refinancing our then existing term loans which occurred during the fourth quarter of fiscal 2023.

[0000936395-23-000041:8k_2_02:82]
•Gain on cost method equity investments, net - reflects changes in the carrying value of certain cost method equity investments due to triggering events.

[0000936395-23-000041:8k_2_02:83]
•Legal settlements - costs incurred as a result of the settlement of certain patent infringement claims and the resolution of related legal proceedings during the fourth quarter of fiscal 2023.

[0000936395-23-000041:8k_2_02:84]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 22.0% for the fiscal fourth quarter and fiscal year 2023 and 20.2% for the fiscal fourth quarter and fiscal year 2022. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
