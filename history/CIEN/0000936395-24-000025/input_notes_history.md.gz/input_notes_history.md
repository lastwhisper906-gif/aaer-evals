# CIEN note change history — 0000936395-24-000008 → 0000936395-24-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-06-06):
[0000936395-24-000025:note_history:1]
Ciena has certain advanced orders for supply of certain long lead time components. As of April 27, 2024, Ciena had $1.6 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.
  (was, 2024-03-07, similarity 0.9857):
[0000936395-24-000008:note_history:1]
Ciena has certain advanced orders for supply of certain long lead time components. As of January 27, 2024, Ciena had $1.9 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-06-06):
[0000936395-24-000025:note_history:2]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 was effective for Ciena beginning in the first quarter of fiscal 2024 without any material impact on its consolidated financial position, results of operations and related disclosures.
  (was, 2024-03-07, similarity 0.9209):
[0000936395-24-000008:note_history:2]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 was effective for Ciena beginning in the first quarter of fiscal 2024 without any material impact on its consolidated financial position, results of operations and related disclosures.

- changed (2024-06-06):
[0000936395-24-000025:note_history:3]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.
  (was, 2024-03-07, similarity 0.9737):
[0000936395-24-000008:note_history:3]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.

- changed (2024-06-06):
[0000936395-24-000025:note_history:4]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for
  (was, 2024-03-07, similarity 0.7603):
[0000936395-24-000008:note_history:4]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for 
adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.

- added (2024-06-06):
[0000936395-24-000025:note_history:5]
adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

- added (2024-06-06):
[0000936395-24-000025:note_history:6]
In March 2024, the SEC adopted final rules under SEC Release No. 33-11275, The Enhancement and Standardization of Climate Related Disclosures for Investors, which requires registrants to provide certain climate-related information in their registration statements and annual reports. The rules require information about a registrant's climate-related risks that are reasonably likely to have a material impact on its business, results of operations, or financial condition. The required information about climate-related risks will also include disclosure of a registrant's greenhouse gas emissions. In addition, the rules will require registrants to present certain climate-related financial metrics in their audited financial statements. Disclosures would be required prospectively, with information for prior periods required only to the extent it was previously disclosed in an SEC filing. Ciena is currently evaluating the impact of these final rules on its consolidated financial statements and related disclosures. On April 12, 2024, the final rules were indefinitely delayed pending the completion of judicial review in consolidated proceedings in the U.S. Court of Appeals, Eighth Circuit.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-06-06):
[0000936395-24-000025:note_history:7]
|  |  | April 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,167,075 |  |  | $ | (4,747) |  |  | $ | (6,071) |  |  | $ | 1,156,257 |  |  | $ | 1,159,371 |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:8]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 New Term Loan totaled $6.1 million as of April 27, 2024 and $5.5 million at October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 New Term Loan. The amortization of deferred debt issuance costs for the 2030 New Term Loan is included in interest expense and was approximately $0.5 million during the first six months of fiscal 2024.
  (was, 2024-03-07, similarity 0.9444):
[0000936395-24-000008:note_history:8]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 New Term Loan totaled $6.2 million as of January 27, 2024 and $5.5 million at October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 New Term Loan. The amortization of deferred debt issuance costs for the 2030 New Term Loan is included in interest expense and was approximately $0.2 million during the first three months of fiscal 2024.

- changed (2024-06-06):
[0000936395-24-000025:note_history:9]
As of April 27, 2024, the estimated fair value of the 2030 New Term Loan was $1.2 billion. The 2030 New Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 New Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2024-03-07, similarity 0.9818):
[0000936395-24-000008:note_history:9]
As of January 27, 2024, the estimated fair value of the 2030 New Term Loan was $1.2 billion. The 2030 New Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 New Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- changed (2024-06-06):
[0000936395-24-000025:note_history:10]
On January 19, 2023, pursuant to the Incremental Agreement (as defined below) to the Credit Agreement, the Credit Agreement was amended to replace the London Interbank Offered Rate (LIBOR) with SOFR for Ciena’s senior secured term loan maturing on September 28, 2025 (the “2025 Term Loan”) in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million for the first six months of fiscal 2023.
  (was, 2024-03-07, similarity 0.9355):
[0000936395-24-000008:note_history:10]
On January 19, 2023, pursuant to the Incremental Agreement (as defined below) to the Credit Agreement, the Credit Agreement was amended to replace LIBOR with SOFR for Ciena’s senior secured term loan maturing on September 28, 2025 (the “2025 Term Loan”) in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million for the first three months of fiscal 2023.

- changed (2024-06-06):
[0000936395-24-000025:note_history:11]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended, by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan were used for general corporate purposes. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense, and was $0.2 million for the first six months of fiscal 2023.
  (was, 2024-03-07, similarity 0.9495):
[0000936395-24-000008:note_history:11]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended, by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan were used for general corporate purposes. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense, and was nominal for the first three months of fiscal 2023.

- changed (2024-06-06):
[0000936395-24-000025:note_history:12]
|  |  | April 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,918) |  |  | $ | 396,082 |  |  | $ | 395,735 |  |  |  |
  (was, 2024-03-07, similarity 0.6808):
[0000936395-24-000008:note_history:12]
|  |  | January 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (4,091) |  |  | $ | 395,909 |  |  | $ | 395,735 |  |  |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:13]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $3.9 million as of April 27, 2024 and $4.3 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.3 million during both the first six months of fiscal 2024 and fiscal 2023.
  (was, 2024-03-07, similarity 0.9192):
[0000936395-24-000008:note_history:13]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.1 million as of January 27, 2024 and $4.3 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.2 million during both the first three months of fiscal 2024 and fiscal 2023.

- changed (2024-06-06):
[0000936395-24-000025:note_history:14]
As of April 27, 2024, the estimated fair value of the 2030 Notes was $349.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2024-03-07, similarity 0.9805):
[0000936395-24-000008:note_history:14]
As of January 27, 2024, the estimated fair value of the 2030 Notes was $363.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2024-06-06):
[0000936395-24-000008:note_history:15]
|  |  | January 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,170,000 |  |  | $ | (4,934) |  |  | $ | (6,157) |  |  | $ | 1,158,909 |  |  | $ | 1,159,371 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-06-06):
[0000936395-24-000025:note_history:16]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):
  (was, 2024-03-07, similarity 0.8939):
[0000936395-24-000008:note_history:16]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

- added (2024-06-06):
[0000936395-24-000025:note_history:17]
|  | April 27, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 261,150 |  |  | $ | — |  |  | $ | (776) |  |  | $ | 260,374 |  |
| Corporate debt securities | 59,692 |  |  | 5 |  |  | (77) |  |  | 59,620 |  |
| Time deposits | 164,198 |  |  | 11 |  |  | (1) |  |  | 164,208 |  |
|  | $ | 485,040 |  |  | $ | 16 |  |  | $ | (854) |  |  | $ | 484,202 |  |
| Included in cash equivalents | $ | 152,622 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,622 |  |
| Included in short-term investments | 165,821 |  |  | 14 |  |  | (215) |  |  | 165,620 |  |
| Included in long-term investments | 166,597 |  |  | 2 |  |  | (639) |  |  | 165,960 |  |
|  | $ | 485,040 |  |  | $ | 16 |  |  | $ | (854) |  |  | $ | 484,202 |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:18]
The following table summarizes the final legal maturities of debt investments as of April 27, 2024 (in thousands):
  (was, 2024-03-07, similarity 0.9636):
[0000936395-24-000008:note_history:18]
The following table summarizes the final legal maturities of debt investments as of January 27, 2024 (in thousands):

- removed (2024-06-06):
[0000936395-24-000008:note_history:19]
|  | January 27, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 141,947 |  |  | $ | 759 |  |  | $ | (82) |  |  | $ | 142,624 |  |
| Corporate debt securities | 57,604 |  |  | 40 |  |  | (25) |  |  | 57,619 |  |
| Time deposits | 144,106 |  |  | 20 |  |  | — |  |  | 144,126 |  |
|  | $ | 343,657 |  |  | $ | 819 |  |  | $ | (107) |  |  | $ | 344,369 |  |
| Included in cash equivalents | $ | 133,829 |  |  | $ | — |  |  | $ | — |  |  | $ | 133,829 |  |
| Included in short-term investments | 106,603 |  |  | 143 |  |  | (68) |  |  | 106,678 |  |
| Included in long-term investments | 103,225 |  |  | 676 |  |  | (39) |  |  | 103,862 |  |
|  | $ | 343,657 |  |  | $ | 819 |  |  | $ | (107) |  |  | $ | 344,369 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-06-06):
[0000936395-24-000025:note_history:20]
|  |  | April 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,167,075 |  |  | $ | (4,747) |  |  | $ | (6,071) |  |  | $ | 1,156,257 |  |  | $ | 1,159,371 |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:21]
|  |  | April 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,918) |  |  | $ | 396,082 |  |  | $ | 395,735 |  |  |  |
  (was, 2024-03-07, similarity 0.6808):
[0000936395-24-000008:note_history:21]
|  |  | January 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (4,091) |  |  | $ | 395,909 |  |  | $ | 395,735 |  |  |  |

- removed (2024-06-06):
[0000936395-24-000008:note_history:22]
|  |  | January 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,170,000 |  |  | $ | (4,934) |  |  | $ | (6,157) |  |  | $ | 1,158,909 |  |  | $ | 1,159,371 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-06-06):
[0000936395-24-000025:note_history:23]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):
  (was, 2024-03-07, similarity 0.8934):
[0000936395-24-000008:note_history:23]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

- changed (2024-06-06):
[0000936395-24-000025:note_history:24]
|  | Quarter Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 560,224 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 560,224 |  |
| Routing and Switching | 116,034 |  |  | — |  |  | — |  |  | — |  |  | 116,034 |  |
| Platform Software and Services | — |  |  | 85,445 |  |  | — |  |  | — |  |  | 85,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,434 |  |  | — |  |  | 14,434 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 77,410 |  |  | 77,410 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 43,785 |  |  | 43,785 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,494 |  |  | 13,494 |  |
| Total revenue by product line | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 676,258 |  |  | $ | 22,689 |  |  | $ | 2,848 |  |  | $ | 10,432 |  |  | $ | 712,227 |  |
| Services transferred over time | — |  |  | 62,756 |  |  | 11,586 |  |  | 124,257 |  |  | 198,599 |  |
| Total revenue by timing of revenue recognition | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
  (was, 2024-03-07, similarity 0.9948):
[0000936395-24-000008:note_history:24]
|  | Quarter Ended January 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:25]
|  | Quarter Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 784,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 784,549 |  |
| Routing and Switching | 130,310 |  |  | — |  |  | — |  |  | — |  |  | 130,310 |  |
| Platform Software and Services | — |  |  | 69,443 |  |  | — |  |  | — |  |  | 69,443 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,567 |  |  | — |  |  | 20,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 73,160 |  |  | 73,160 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,486 |  |  | 39,486 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 15,140 |  |  | 15,140 |  |
| Total revenue by product line | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 914,859 |  |  | $ | 13,447 |  |  | $ | 7,329 |  |  | $ | 15,412 |  |  | $ | 951,047 |  |
| Services transferred over time | — |  |  | 55,996 |  |  | 13,238 |  |  | 112,374 |  |  | 181,608 |  |
| Total revenue by timing of revenue recognition | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
  (was, 2024-03-07, similarity 0.9948):
[0000936395-24-000008:note_history:25]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |

- added (2024-06-06):
[0000936395-24-000025:note_history:26]
|  | Six Months Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,256,072 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,256,072 |  |
| Routing and Switching | 227,421 |  |  | — |  |  | — |  |  | — |  |  | 227,421 |  |
| Platform Software and Services | — |  |  | 175,190 |  |  | — |  |  | — |  |  | 175,190 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 28,376 |  |  | — |  |  | 28,376 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 151,525 |  |  | 151,525 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 86,509 |  |  | 86,509 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 23,442 |  |  | 23,442 |  |
| Total revenue by product line | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,483,493 |  |  | $ | 50,383 |  |  | $ | 3,916 |  |  | $ | 20,071 |  |  | $ | 1,557,863 |  |
| Services transferred over time | — |  |  | 124,807 |  |  | 24,460 |  |  | 241,405 |  |  | 390,672 |  |
| Total revenue by timing of revenue recognition | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |

- added (2024-06-06):
[0000936395-24-000025:note_history:27]
|  | Six months ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,520,183 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,520,183 |  |
| Routing and Switching | 249,814 |  |  | — |  |  | — |  |  | — |  |  | 249,814 |  |
| Platform Software and Services | — |  |  | 142,888 |  |  | — |  |  | — |  |  | 142,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 35,973 |  |  | — |  |  | 35,973 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 141,051 |  |  | 141,051 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 74,061 |  |  | 74,061 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,206 |  |  | 25,206 |  |
| Total revenue by product line | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,769,997 |  |  | $ | 32,311 |  |  | $ | 11,312 |  |  | $ | 24,667 |  |  | $ | 1,838,287 |  |
| Services transferred over time | — |  |  | 110,577 |  |  | 24,661 |  |  | 215,651 |  |  | 350,889 |  |
| Total revenue by timing of revenue recognition | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:28]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2024-03-07, similarity 0.9388):
[0000936395-24-000008:note_history:28]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2024-06-06):
[0000936395-24-000025:note_history:29]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 662,877 |  |  | $ | 794,359 |  |  | $ | 1,381,075 |  |  | $ | 1,559,455 |  |
| EMEA |  | 155,791 |  |  | 173,414 |  |  | 363,203 |  |  | 326,218 |  |
| APAC |  | 92,158 |  |  | 164,882 |  |  | 204,257 |  |  | 303,503 |  |
| Total revenue by geographic distribution |  | $ | 910,826 |  |  | $ | 1,132,655 |  |  | $ | 1,948,535 |  |  | $ | 2,189,176 |  |
  (was, 2024-03-07, similarity 0.6924):
[0000936395-24-000008:note_history:29]
|  |  | Quarter Ended |  |  |
|  |  | January 27, |  | January 28, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 718,198 |  |  | $ | 765,096 |  |  |  |  |  |
| EMEA |  | 207,413 |  |  | 152,804 |  |  |  |  |  |
| APAC |  | 112,098 |  |  | 138,621 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,037,709 |  |  | $ | 1,056,521 |  |  |  |  |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:30]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2024-03-07, similarity 0.952):
[0000936395-24-000008:note_history:30]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2024-06-06):
[0000936395-24-000025:note_history:31]
|  | Quarter Ended |  | Six Months Ended |
|  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| AT&T | $ | 125,493 |  |  | n/a |  | $ | 211,705 |  |  | $ | 251,329 |  |
| Cloud Provider | n/a |  | $ | 123,452 |  |  | n/a |  | 244,779 |  |
| Total | $ | 125,493 |  |  | $ | 123,452 |  |  | $ | 211,705 |  |  | $ | 496,108 |  |

- removed (2024-06-06):
[0000936395-24-000008:note_history:32]
|  | Quarter Ended |  |  |
|  | January 27, |  | January 28, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Cloud provider A | $ | 166,008 |  |  | n/a |  |  |  |  |
| Cloud provider B | 109,098 |  |  | 121,327 |  |  |  |  |  |
| AT&T | n/a |  | 149,981 |  |  |  |  |  |
| Total | $ | 275,106 |  |  | $ | 271,308 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-06-06):
[0000936395-24-000025:note_history:33]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue for similar groupings of Ciena’s products and services. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ across Ciena’s product lines, resulting in different economic risk profiles for each line.
  (was, 2024-03-07, similarity 0.8345):
[0000936395-24-000008:note_history:33]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

- changed (2024-06-06):
[0000936395-24-000025:note_history:34]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):
  (was, 2024-03-07, similarity 0.8934):
[0000936395-24-000008:note_history:34]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

- changed (2024-06-06):
[0000936395-24-000025:note_history:35]
|  | Quarter Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 560,224 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 560,224 |  |
| Routing and Switching | 116,034 |  |  | — |  |  | — |  |  | — |  |  | 116,034 |  |
| Platform Software and Services | — |  |  | 85,445 |  |  | — |  |  | — |  |  | 85,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,434 |  |  | — |  |  | 14,434 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 77,410 |  |  | 77,410 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 43,785 |  |  | 43,785 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,494 |  |  | 13,494 |  |
| Total revenue by product line | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 676,258 |  |  | $ | 22,689 |  |  | $ | 2,848 |  |  | $ | 10,432 |  |  | $ | 712,227 |  |
| Services transferred over time | — |  |  | 62,756 |  |  | 11,586 |  |  | 124,257 |  |  | 198,599 |  |
| Total revenue by timing of revenue recognition | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
  (was, 2024-03-07, similarity 0.9948):
[0000936395-24-000008:note_history:35]
|  | Quarter Ended January 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:36]
|  | Quarter Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 784,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 784,549 |  |
| Routing and Switching | 130,310 |  |  | — |  |  | — |  |  | — |  |  | 130,310 |  |
| Platform Software and Services | — |  |  | 69,443 |  |  | — |  |  | — |  |  | 69,443 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,567 |  |  | — |  |  | 20,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 73,160 |  |  | 73,160 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,486 |  |  | 39,486 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 15,140 |  |  | 15,140 |  |
| Total revenue by product line | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 914,859 |  |  | $ | 13,447 |  |  | $ | 7,329 |  |  | $ | 15,412 |  |  | $ | 951,047 |  |
| Services transferred over time | — |  |  | 55,996 |  |  | 13,238 |  |  | 112,374 |  |  | 181,608 |  |
| Total revenue by timing of revenue recognition | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
  (was, 2024-03-07, similarity 0.9948):
[0000936395-24-000008:note_history:36]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |

- added (2024-06-06):
[0000936395-24-000025:note_history:37]
|  | Six Months Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,256,072 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,256,072 |  |
| Routing and Switching | 227,421 |  |  | — |  |  | — |  |  | — |  |  | 227,421 |  |
| Platform Software and Services | — |  |  | 175,190 |  |  | — |  |  | — |  |  | 175,190 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 28,376 |  |  | — |  |  | 28,376 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 151,525 |  |  | 151,525 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 86,509 |  |  | 86,509 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 23,442 |  |  | 23,442 |  |
| Total revenue by product line | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,483,493 |  |  | $ | 50,383 |  |  | $ | 3,916 |  |  | $ | 20,071 |  |  | $ | 1,557,863 |  |
| Services transferred over time | — |  |  | 124,807 |  |  | 24,460 |  |  | 241,405 |  |  | 390,672 |  |
| Total revenue by timing of revenue recognition | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |

- added (2024-06-06):
[0000936395-24-000025:note_history:38]
|  | Six months ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,520,183 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,520,183 |  |
| Routing and Switching | 249,814 |  |  | — |  |  | — |  |  | — |  |  | 249,814 |  |
| Platform Software and Services | — |  |  | 142,888 |  |  | — |  |  | — |  |  | 142,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 35,973 |  |  | — |  |  | 35,973 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 141,051 |  |  | 141,051 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 74,061 |  |  | 74,061 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,206 |  |  | 25,206 |  |
| Total revenue by product line | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,769,997 |  |  | $ | 32,311 |  |  | $ | 11,312 |  |  | $ | 24,667 |  |  | $ | 1,838,287 |  |
| Services transferred over time | — |  |  | 110,577 |  |  | 24,661 |  |  | 215,651 |  |  | 350,889 |  |
| Total revenue by timing of revenue recognition | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:39]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.
  (was, 2024-03-07, similarity 0.9993):
[0000936395-24-000008:note_history:39]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2024-06-06):
[0000936395-24-000025:note_history:40]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2024-03-07, similarity 0.9388):
[0000936395-24-000008:note_history:40]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2024-06-06):
[0000936395-24-000025:note_history:41]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 662,877 |  |  | $ | 794,359 |  |  | $ | 1,381,075 |  |  | $ | 1,559,455 |  |
| EMEA |  | 155,791 |  |  | 173,414 |  |  | 363,203 |  |  | 326,218 |  |
| APAC |  | 92,158 |  |  | 164,882 |  |  | 204,257 |  |  | 303,503 |  |
| Total revenue by geographic distribution |  | $ | 910,826 |  |  | $ | 1,132,655 |  |  | $ | 1,948,535 |  |  | $ | 2,189,176 |  |
  (was, 2024-03-07, similarity 0.6924):
[0000936395-24-000008:note_history:41]
|  |  | Quarter Ended |  |  |
|  |  | January 27, |  | January 28, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 718,198 |  |  | $ | 765,096 |  |  |  |  |  |
| EMEA |  | 207,413 |  |  | 152,804 |  |  |  |  |  |
| APAC |  | 112,098 |  |  | 138,621 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,037,709 |  |  | $ | 1,056,521 |  |  |  |  |  |

- added (2024-06-06):
[0000936395-24-000025:note_history:42]
Ciena’s revenue includes $618.8 million and $722.6 million of United States revenue for the second quarter of fiscal 2024 and 2023, respectively. For the six months ended April 27, 2024 and April 29, 2023, United States revenue was $1.3 billion and $1.4 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

- changed (2024-06-06):
[0000936395-24-000025:note_history:43]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2024-03-07, similarity 0.952):
[0000936395-24-000008:note_history:43]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2024-06-06):
[0000936395-24-000025:note_history:44]
|  | Quarter Ended |  | Six Months Ended |
|  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| AT&T | $ | 125,493 |  |  | n/a |  | $ | 211,705 |  |  | $ | 251,329 |  |
| Cloud Provider | n/a |  | $ | 123,452 |  |  | n/a |  | 244,779 |  |
| Total | $ | 125,493 |  |  | $ | 123,452 |  |  | $ | 211,705 |  |  | $ | 496,108 |  |

- added (2024-06-06):
[0000936395-24-000025:note_history:45]
AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented. The cloud provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services for each of the periods presented.

- added (2024-06-06):
[0000936395-24-000025:note_history:46]
A description of each of Ciena’s operating segments is set forth below:

- changed (2024-06-06):
[0000936395-24-000025:note_history:47]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, virtualization software and Ciena’s WaveRouter® product. This product line also includes SD-Edge software and passive optical network (PON) routing and switching portfolio products.
  (was, 2024-03-07, similarity 0.6637):
[0000936395-24-000008:note_history:47]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and virtualization software. This product line also includes SD-Edge software and our microplug Optical Line Terminal (OLT) transceiver. This product line also includes Ciena’s WaveRouterTM product, which was introduced during fiscal 2023, for which there have been no material sales to date.

- changed (2024-06-06):
[0000936395-24-000025:note_history:48]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools and applications to assist customers in managing their networks, including by creating more efficient operations and providing more visibility into their networks. Ciena’s platform software includes its Navigator Network Control SuiteTM (“Navigator NCS”) domain controller solution, its suite of Navigator NCS applications, previously referred to as “Manage, Control and Plan (MCP),” its OneControl Unified Management System, and planning tools and legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2024-03-07, similarity 0.9856):
[0000936395-24-000008:note_history:48]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools and applications to assist customers in managing their networks, including by creating more efficient operations and providing more proactive visibility into their networks. Ciena’s platform software includes its Navigator Network Control SuiteTM (“Navigator NCS”) domain controller solution, its suite of Navigator NCS applications, which was previously referred to as “Manage, Control and Plan (MCP),” and its OneControl Unified Management System, as well as planning tools and legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- added (2024-06-06):
[0000936395-24-000025:note_history:49]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

- changed (2024-06-06):
[0000936395-24-000025:note_history:50]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):
  (was, 2024-03-07, similarity 0.9244):
[0000936395-24-000008:note_history:50]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):

- changed (2024-06-06):
[0000936395-24-000025:note_history:51]
|  |  | Balance at April 27, 2024 |  | Balance at October 28, 2023 |
| Accounts receivable, net |  | $ | 840,131 |  |  | $ | 1,003,876 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 151,896 |  |  | $ | 150,312 |  |
| Deferred revenue |  | $ | 277,354 |  |  | $ | 228,460 |  |
  (was, 2024-03-07, similarity 0.9746):
[0000936395-24-000008:note_history:51]
|  |  | Balance at January 27, 2024 |  | Balance at October 28, 2023 |
| Accounts receivable, net |  | $ | 865,239 |  |  | $ | 1,003,876 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 151,572 |  |  | $ | 150,312 |  |
| Deferred revenue |  | $ | 243,270 |  |  | $ | 228,460 |  |

- changed (2024-06-06):
[0000936395-24-000025:note_history:52]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 10 below.
  (was, 2024-03-07, similarity 0.9981):
[0000936395-24-000008:note_history:52]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets. See Note 10 below.

- changed (2024-06-06):
[0000936395-24-000025:note_history:53]
Deferred revenue represents contract liabilities and consists of advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $105.3 million and $100.1 million of revenue during the first six months of fiscal 2024 and 2023, respectively, that was included in the deferred revenue balance as of October 28, 2023 and October 29, 2022, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended April 27, 2024 and April 29, 2023.
  (was, 2024-03-07, similarity 0.8453):
[0000936395-24-000008:note_history:53]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $70.6 million and $67.9 million of revenue during the first three months of fiscal 2024 and 2023, respectively, that was included in the deferred revenue balance at October 28, 2023 and October 29, 2022, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 27, 2024 and January 28, 2023.

- changed (2024-06-06):
[0000936395-24-000025:note_history:54]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $26.7 million and $30.2 million as of April 27, 2024 and October 28, 2023, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $14.9 million and $16.2 million during the first six months of fiscal 2024 and 2023, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2024-03-07, similarity 0.9402):
[0000936395-24-000008:note_history:54]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $27.8 million and $30.2 million as of January 27, 2024 and October 28, 2023, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets on the Condensed Consolidated Balance Sheets. The amortization expense associated with these costs was $7.7 million and $7.2 million during the first three months of fiscal 2024 and 2023, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

- changed (2024-06-06):
[0000936395-24-000025:note_history:55]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 27, 2024, the aggregate amount of RPO was $1.5 billion. As of April 27, 2024, Ciena expects approximately 78% of the RPO balance to be recognized as revenue within the next 12 months.
  (was, 2024-03-07, similarity 0.9601):
[0000936395-24-000008:note_history:55]
Remaining performance obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 27, 2024, the aggregate amount of RPO was $1.7 billion. As of January 27, 2024, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next 12 months.

- removed (2024-06-06):
[0000936395-24-000008:note_history:56]
Ciena’s revenue includes $677.6 million and $693.6 million of United States revenue for the first quarter of fiscal 2024 and 2023, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- removed (2024-06-06):
[0000936395-24-000008:note_history:57]
|  | Quarter Ended |  |  |
|  | January 27, |  | January 28, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Cloud provider A | $ | 166,008 |  |  | n/a |  |  |  |  |
| Cloud provider B | 109,098 |  |  | 121,327 |  |  |  |  |  |
| AT&T | n/a |  | 149,981 |  |  |  |  |  |
| Total | $ | 275,106 |  |  | $ | 271,308 |  |  |  |  |  |

- removed (2024-06-06):
[0000936395-24-000008:note_history:58]
The cloud providers noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. AT&T purchased products and services from each of Ciena’s operating segments for the period presented.

- removed (2024-06-06):
[0000936395-24-000008:note_history:59]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- removed (2024-06-06):
[0000936395-24-000008:note_history:60]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-06-06):
[0000936395-24-000025:note_history:61]
SUBSEQUENT EVENTS
Stock Repurchase Program
From the end of the second quarter of fiscal 2024 through May 31, 2024, Ciena repurchased an additional 0.5 million shares of its common stock for an aggregate purchase price of $24.0 million at an average price of $48.54 per share, inclusive of repurchases pending settlement. As of May 31, 2024, Ciena has repurchased an aggregate of 16.4 million shares and has an aggregate of $137.0 million of authorized funds remaining under its stock repurchase program.
  (was, 2024-03-07, similarity 0.9799):
[0000936395-24-000008:note_history:61]
SUBSEQUENT EVENTS
Stock Repurchase Program
From the end of the first quarter of fiscal 2024 through March 1, 2024, Ciena repurchased an additional 0.3 million shares of its common stock for an aggregate purchase price of $19.2 million at an average price of $55.44 per share, inclusive of repurchases pending settlement. As of March 1, 2024, Ciena has repurchased an aggregate of 15.1 million shares and has an aggregate of $198.8 million of authorized funds remaining under its stock repurchase program.
