# CIEN notes — 0000936395-24-000025


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-24-000025:notes:1]
[same as prior period, unchanged from 0000936395-24-000008:notes:1]

[0000936395-24-000025:notes:2]
[same as prior period, unchanged from 0000936395-24-000008:notes:2]

[0000936395-24-000025:notes:3]
[same as prior period, unchanged from 0000936395-24-000008:notes:3]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-24-000025:notes:4]
[same as prior period, unchanged from 0000936395-24-000008:notes:4]

[0000936395-24-000025:notes:5]
[same as prior period, unchanged from 0000936395-24-000008:notes:5]

[0000936395-24-000025:notes:6]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 was effective for Ciena beginning in the first quarter of fiscal 2024 without any material impact on its consolidated financial position, results of operations and related disclosures.

[0000936395-24-000025:notes:7]
[same as prior period, unchanged from 0000936395-24-000008:notes:7]

[0000936395-24-000025:notes:8]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0000936395-24-000025:notes:9]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for

[0000936395-24-000025:notes:10]
adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0000936395-24-000025:notes:11]
In March 2024, the SEC adopted final rules under SEC Release No. 33-11275, The Enhancement and Standardization of Climate Related Disclosures for Investors, which requires registrants to provide certain climate-related information in their registration statements and annual reports. The rules require information about a registrant's climate-related risks that are reasonably likely to have a material impact on its business, results of operations, or financial condition. The required information about climate-related risks will also include disclosure of a registrant's greenhouse gas emissions. In addition, the rules will require registrants to present certain climate-related financial metrics in their audited financial statements. Disclosures would be required prospectively, with information for prior periods required only to the extent it was previously disclosed in an SEC filing. Ciena is currently evaluating the impact of these final rules on its consolidated financial statements and related disclosures. On April 12, 2024, the final rules were indefinitely delayed pending the completion of judicial review in consolidated proceedings in the U.S. Court of Appeals, Eighth Circuit.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-24-000025:notes:12]
[same as prior period, unchanged from 0000936395-24-000008:notes:10]

[0000936395-24-000025:notes:13]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue for similar groupings of Ciena’s products and services. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ across Ciena’s product lines, resulting in different economic risk profiles for each line.

[0000936395-24-000025:notes:14]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

[0000936395-24-000025:notes:15]
|  | Quarter Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 560,224 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 560,224 |  |
| Routing and Switching | 116,034 |  |  | — |  |  | — |  |  | — |  |  | 116,034 |  |
| Platform Software and Services | — |  |  | 85,445 |  |  | — |  |  | — |  |  | 85,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,434 |  |  | — |  |  | 14,434 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 77,410 |  |  | 77,410 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 43,785 |  |  | 43,785 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,494 |  |  | 13,494 |  |
| Total revenue by product line | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 676,258 |  |  | $ | 22,689 |  |  | $ | 2,848 |  |  | $ | 10,432 |  |  | $ | 712,227 |  |
| Services transferred over time | — |  |  | 62,756 |  |  | 11,586 |  |  | 124,257 |  |  | 198,599 |  |
| Total revenue by timing of revenue recognition | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |

[0000936395-24-000025:notes:16]
|  | Quarter Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 784,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 784,549 |  |
| Routing and Switching | 130,310 |  |  | — |  |  | — |  |  | — |  |  | 130,310 |  |
| Platform Software and Services | — |  |  | 69,443 |  |  | — |  |  | — |  |  | 69,443 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,567 |  |  | — |  |  | 20,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 73,160 |  |  | 73,160 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,486 |  |  | 39,486 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 15,140 |  |  | 15,140 |  |
| Total revenue by product line | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 914,859 |  |  | $ | 13,447 |  |  | $ | 7,329 |  |  | $ | 15,412 |  |  | $ | 951,047 |  |
| Services transferred over time | — |  |  | 55,996 |  |  | 13,238 |  |  | 112,374 |  |  | 181,608 |  |
| Total revenue by timing of revenue recognition | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |

[0000936395-24-000025:notes:17]
|  | Six Months Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,256,072 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,256,072 |  |
| Routing and Switching | 227,421 |  |  | — |  |  | — |  |  | — |  |  | 227,421 |  |
| Platform Software and Services | — |  |  | 175,190 |  |  | — |  |  | — |  |  | 175,190 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 28,376 |  |  | — |  |  | 28,376 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 151,525 |  |  | 151,525 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 86,509 |  |  | 86,509 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 23,442 |  |  | 23,442 |  |
| Total revenue by product line | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,483,493 |  |  | $ | 50,383 |  |  | $ | 3,916 |  |  | $ | 20,071 |  |  | $ | 1,557,863 |  |
| Services transferred over time | — |  |  | 124,807 |  |  | 24,460 |  |  | 241,405 |  |  | 390,672 |  |
| Total revenue by timing of revenue recognition | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |

[0000936395-24-000025:notes:18]
|  | Six months ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,520,183 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,520,183 |  |
| Routing and Switching | 249,814 |  |  | — |  |  | — |  |  | — |  |  | 249,814 |  |
| Platform Software and Services | — |  |  | 142,888 |  |  | — |  |  | — |  |  | 142,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 35,973 |  |  | — |  |  | 35,973 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 141,051 |  |  | 141,051 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 74,061 |  |  | 74,061 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,206 |  |  | 25,206 |  |
| Total revenue by product line | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,769,997 |  |  | $ | 32,311 |  |  | $ | 11,312 |  |  | $ | 24,667 |  |  | $ | 1,838,287 |  |
| Services transferred over time | — |  |  | 110,577 |  |  | 24,661 |  |  | 215,651 |  |  | 350,889 |  |
| Total revenue by timing of revenue recognition | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |

[0000936395-24-000025:notes:19]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-24-000025:notes:20]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-24-000025:notes:21]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 662,877 |  |  | $ | 794,359 |  |  | $ | 1,381,075 |  |  | $ | 1,559,455 |  |
| EMEA |  | 155,791 |  |  | 173,414 |  |  | 363,203 |  |  | 326,218 |  |
| APAC |  | 92,158 |  |  | 164,882 |  |  | 204,257 |  |  | 303,503 |  |
| Total revenue by geographic distribution |  | $ | 910,826 |  |  | $ | 1,132,655 |  |  | $ | 1,948,535 |  |  | $ | 2,189,176 |  |

[0000936395-24-000025:notes:22]
Ciena’s revenue includes $618.8 million and $722.6 million of United States revenue for the second quarter of fiscal 2024 and 2023, respectively. For the six months ended April 27, 2024 and April 29, 2023, United States revenue was $1.3 billion and $1.4 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

[0000936395-24-000025:notes:23]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-24-000025:notes:24]
|  | Quarter Ended |  | Six Months Ended |
|  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| AT&T | $ | 125,493 |  |  | n/a |  | $ | 211,705 |  |  | $ | 251,329 |  |
| Cloud Provider | n/a |  | $ | 123,452 |  |  | n/a |  | 244,779 |  |
| Total | $ | 125,493 |  |  | $ | 123,452 |  |  | $ | 211,705 |  |  | $ | 496,108 |  |

[0000936395-24-000025:notes:25]
[same as prior period, unchanged from 0000936395-24-000008:notes:21]

[0000936395-24-000025:notes:26]
[same as prior period, unchanged from 0000936395-24-000008:notes:22]

[0000936395-24-000025:notes:27]
AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented. The cloud provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services for each of the periods presented.

[0000936395-24-000025:notes:28]
A description of each of Ciena’s operating segments is set forth below:

[0000936395-24-000025:notes:29]
[same as prior period, unchanged from 0000936395-24-000008:notes:24]

[0000936395-24-000025:notes:30]
[same as prior period, unchanged from 0000936395-24-000008:notes:25]

[0000936395-24-000025:notes:31]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, virtualization software and Ciena’s WaveRouter® product. This product line also includes SD-Edge software and passive optical network (PON) routing and switching portfolio products.

[0000936395-24-000025:notes:32]
[same as prior period, unchanged from 0000936395-24-000008:notes:27]

[0000936395-24-000025:notes:33]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools and applications to assist customers in managing their networks, including by creating more efficient operations and providing more visibility into their networks. Ciena’s platform software includes its Navigator Network Control SuiteTM (“Navigator NCS”) domain controller solution, its suite of Navigator NCS applications, previously referred to as “Manage, Control and Plan (MCP),” its OneControl Unified Management System, and planning tools and legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-24-000025:notes:34]
[same as prior period, unchanged from 0000936395-24-000008:notes:29]

[0000936395-24-000025:notes:35]
[same as prior period, unchanged from 0000936395-24-000008:notes:30]

[0000936395-24-000025:notes:36]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-24-000025:notes:37]
[same as prior period, unchanged from 0000936395-24-000008:notes:33]

[0000936395-24-000025:notes:38]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):

[0000936395-24-000025:notes:39]
|  |  | Balance at April 27, 2024 |  | Balance at October 28, 2023 |
| Accounts receivable, net |  | $ | 840,131 |  |  | $ | 1,003,876 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 151,896 |  |  | $ | 150,312 |  |
| Deferred revenue |  | $ | 277,354 |  |  | $ | 228,460 |  |

[0000936395-24-000025:notes:40]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 10 below.

[0000936395-24-000025:notes:41]
Deferred revenue represents contract liabilities and consists of advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $105.3 million and $100.1 million of revenue during the first six months of fiscal 2024 and 2023, respectively, that was included in the deferred revenue balance as of October 28, 2023 and October 29, 2022, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended April 27, 2024 and April 29, 2023.

[0000936395-24-000025:notes:42]
[same as prior period, unchanged from 0000936395-24-000008:notes:38]

[0000936395-24-000025:notes:43]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $26.7 million and $30.2 million as of April 27, 2024 and October 28, 2023, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $14.9 million and $16.2 million during the first six months of fiscal 2024 and 2023, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0000936395-24-000025:notes:44]
[same as prior period, unchanged from 0000936395-24-000008:notes:40]

[0000936395-24-000025:notes:45]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 27, 2024, the aggregate amount of RPO was $1.5 billion. As of April 27, 2024, Ciena expects approximately 78% of the RPO balance to be recognized as revenue within the next 12 months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-24-000025:notes:46]
[same as prior period, unchanged from 0000936395-24-000008:notes:42]

[0000936395-24-000025:notes:47]
|  | April 27,2024 |  | October 28,2023 |
| Products | $ | 22,583 |  |  | $ | 28,353 |  |
| Services | 254,771 |  |  | 200,107 |  |
| Total deferred revenue | 277,354 |  |  | 228,460 |  |
| Less current portion | (196,989) |  |  | (154,419) |  |
| Long-term deferred revenue | $ | 80,365 |  |  | $ | 74,041 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-24-000025:notes:48]
[same as prior period, unchanged from 0000936395-24-000008:notes:44]

[0000936395-24-000025:notes:49]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development, and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets, for the six months ended April 27, 2024 (in thousands):

[0000936395-24-000025:notes:50]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 28, 2023 | $ | 1,913 |  |  | $ | — |  |  | $ | 1,913 |  |
| Charges | 13,984 |  | (1) | 6,642 |  | (2) | 20,626 |  |
| Cash payments | (7,147) |  |  | (6,642) |  |  | (13,789) |  |
| Balance at April 27, 2024 | $ | 8,750 |  |  | $ | — |  |  | $ | 8,750 |  |
| Current restructuring liabilities | $ | 8,750 |  |  | $ | — |  |  | $ | 8,750 |  |

[0000936395-24-000025:notes:51]
(1) Reflects a global workforce reduction of approximately 360 employees during the six months ended April 27, 2024 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-24-000025:notes:52]
[same as prior period, unchanged from 0000936395-24-000008:notes:48]

[0000936395-24-000025:notes:53]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the six months ended April 29, 2023 (in thousands):

[0000936395-24-000025:notes:54]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 29, 2022 | $ | 1,215 |  |  | $ | 4,620 |  |  | $ | 5,835 |  |
| Charges | 2,863 |  | (1) | 9,588 |  | (2) | 12,451 |  |
| Cash payments | (1,783) |  |  | (14,208) |  |  | (15,991) |  |
| Balance at April 29, 2023 | $ | 2,295 |  |  | $ | — |  |  | $ | 2,295 |  |
| Current restructuring liabilities | $ | 2,295 |  |  | $ | — |  |  | $ | 2,295 |  |

[0000936395-24-000025:notes:55]
(1) Reflects employee costs associated with workforce reductions during the six months ended April 29, 2023 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-24-000025:notes:56]
[same as prior period, unchanged from 0000936395-24-000008:notes:53]

[0000936395-24-000025:notes:57]
|  | Quarter Ended |  | Six Months Ended |
|  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest income | $ | 15,255 |  |  | $ | 10,416 |  |  | $ | 30,433 |  |  | $ | 17,530 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | (1,114) |  |  | (2,795) |  |  | 1,998 |  |  | (4,564) |  |
| Foreign currency exchange gains (losses) | (411) |  |  | 2,987 |  |  | (9,604) |  |  | 1,104 |  |
| Gain on equity investments, net | — |  |  | — |  |  | — |  |  | 26,455 |  |
| Other | (1,933) |  |  | (2,057) |  |  | (380) |  |  | (1) |  |
| Interest and other income, net | $ | 11,797 |  |  | $ | 8,551 |  |  | $ | 22,447 |  |  | $ | 40,524 |  |

[0000936395-24-000025:notes:58]
During the first quarter of fiscal 2023, the acquisition of Tibit Communications, Inc. (“Tibit”) by Ciena triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its equity investment of $26.5 million.

[0000936395-24-000025:notes:59]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. During the first six months of fiscal 2024, Ciena recorded $9.6 million in foreign currency exchange rate losses as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. During the first six months fiscal 2023, Ciena recorded $1.1 
million in foreign currency exchange rate gains as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income, net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Condensed Consolidated Statements of Operations. During the first six months of fiscal 2024, Ciena recorded gains of $2.0 million from non-hedge designated foreign currency forward contracts. During the first six months of fiscal 2023, Ciena recorded losses of $4.6 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-24-000025:notes:60]
INCOME TAXES
The effective tax rate for the quarter ended April 27, 2024 was lower than the effective tax rate for the quarter ended April 29, 2023, primarily due to a decrease in pre-tax book income for the quarter.

[0000936395-24-000025:notes:61]
The effective tax rate for the six months ended April 27, 2024 was higher than the effective tax rate for the six months ended April 29, 2023, primarily due to a reduction in pre-tax book income in lower tax jurisdictions.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-24-000025:notes:62]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0000936395-24-000025:notes:63]
|  | April 27, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 261,150 |  |  | $ | — |  |  | $ | (776) |  |  | $ | 260,374 |  |
| Corporate debt securities | 59,692 |  |  | 5 |  |  | (77) |  |  | 59,620 |  |
| Time deposits | 164,198 |  |  | 11 |  |  | (1) |  |  | 164,208 |  |
|  | $ | 485,040 |  |  | $ | 16 |  |  | $ | (854) |  |  | $ | 484,202 |  |
| Included in cash equivalents | $ | 152,622 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,622 |  |
| Included in short-term investments | 165,821 |  |  | 14 |  |  | (215) |  |  | 165,620 |  |
| Included in long-term investments | 166,597 |  |  | 2 |  |  | (639) |  |  | 165,960 |  |
|  | $ | 485,040 |  |  | $ | 16 |  |  | $ | (854) |  |  | $ | 484,202 |  |

[0000936395-24-000025:notes:64]
|  | October 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 170,260 |  |  | $ | 28 |  |  | $ | (379) |  |  | $ | 169,909 |  |
| Corporate debt securities | 59,683 |  |  | 1 |  |  | (115) |  |  | 59,569 |  |
| Time deposits | 138,830 |  |  | 4 |  |  | (5) |  |  | 138,829 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |
| Included in cash equivalents | $ | 129,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 129,276 |  |
| Included in short-term investments | 105,042 |  |  | 4 |  |  | (293) |  |  | 104,753 |  |
| Included in long-term investments | 134,455 |  |  | 29 |  |  | (206) |  |  | 134,278 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |

[0000936395-24-000025:notes:65]
The following table summarizes the final legal maturities of debt investments as of April 27, 2024 (in thousands):

[0000936395-24-000025:notes:66]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 318,443 |  |  | $ | 318,242 |  |
| Due in 1-2 years | 166,597 |  |  | 165,960 |  |
|  | $ | 485,040 |  |  | $ | 484,202 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-24-000025:notes:67]
[same as prior period, unchanged from 0000936395-24-000008:notes:63]

[0000936395-24-000025:notes:68]
|  | April 27, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 700,930 |  |  | $ | — |  |  | $ | — |  |  | $ | 700,930 |  |
| Bond mutual fund | 158,297 |  |  | — |  |  | — |  |  | 158,297 |  |
| Time deposits | 164,208 |  |  | — |  |  | — |  |  | 164,208 |  |
| Deferred compensation plan assets | 14,479 |  |  | — |  |  | — |  |  | 14,479 |  |
| U.S. government obligations | — |  |  | 260,374 |  |  | — |  |  | 260,374 |  |
| Corporate debt securities | — |  |  | 59,620 |  |  | — |  |  | 59,620 |  |
| Foreign currency forward contracts | — |  |  | 1,341 |  |  | — |  |  | 1,341 |  |
| Interest rate swaps | — |  |  | 30,296 |  |  | — |  |  | 30,296 |  |
| Total assets measured at fair value | $ | 1,037,914 |  |  | $ | 351,631 |  |  | $ | — |  |  | $ | 1,389,545 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 6,173 |  |  | $ | — |  |  | $ | 6,173 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,173 |  |  | $ | — |  |  | $ | 6,173 |  |

[0000936395-24-000025:notes:69]
[same as prior period, unchanged from 0000936395-24-000008:notes:65]

[0000936395-24-000025:notes:70]
[same as prior period, unchanged from 0000936395-24-000008:notes:66]

[0000936395-24-000025:notes:71]
|  | April 27, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,007,962 |  |  | $ | 3,887 |  |  | $ | — |  |  | $ | 1,011,849 |  |
| Short-term investments | 15,473 |  |  | 150,147 |  |  | — |  |  | 165,620 |  |
| Prepaid expenses and other | — |  |  | 1,341 |  |  | — |  |  | 1,341 |  |
| Long-term investments | — |  |  | 165,960 |  |  | — |  |  | 165,960 |  |
| Other long-term assets | 14,479 |  |  | 30,296 |  |  | — |  |  | 44,775 |  |
| Total assets measured at fair value | $ | 1,037,914 |  |  | $ | 351,631 |  |  | $ | — |  |  | $ | 1,389,545 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 6,173 |  |  | $ | — |  |  | $ | 6,173 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,173 |  |  | $ | — |  |  | $ | 6,173 |  |

[0000936395-24-000025:notes:72]
[same as prior period, unchanged from 0000936395-24-000008:notes:68]

[0000936395-24-000025:notes:73]
[same as prior period, unchanged from 0000936395-24-000008:notes:69]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-24-000025:notes:74]
[same as prior period, unchanged from 0000936395-24-000008:notes:70]

[0000936395-24-000025:notes:75]
|  | April 27,2024 |  | October 28,2023 |
| Raw materials | $ | 638,920 |  |  | $ | 664,797 |  |
| Work-in-process | 68,182 |  |  | 55,242 |  |
| Finished goods | 331,317 |  |  | 314,168 |  |
| Deferred cost of goods sold | 43,692 |  |  | 66,634 |  |
| Gross inventories | 1,082,111 |  |  | 1,100,841 |  |
| Reserve for inventory excess and obsolescence | (59,496) |  |  | (50,003) |  |
| Inventories, net | $ | 1,022,615 |  |  | $ | 1,050,838 |  |

[0000936395-24-000025:notes:76]
Ciena has been expanding its manufacturing capacity and had been accumulating raw materials inventory of components that are available, in some cases with expanded lead times, in an effort to prepare Ciena to produce finished goods more quickly upon the easing of supply constraints for certain common components. During the first half of fiscal 2024 Ciena reduced its raw materials inventory of components due to the consumption of raw materials in excess of purchases. The increase in finished goods and work-in-process inventories resulted primarily from planned fulfillment of customer advance orders for which some deliveries were rescheduled outside of the second quarter of fiscal 2024.

[0000936395-24-000025:notes:77]
Ciena makes estimates about future customer demand for its products when establishing the appropriate reserve for excess and obsolete inventory. For the periods presented, future demand was calculated using both customer backlog and future forecasted sales. Generally, Ciena’s customers may cancel or change their orders with limited advance notice, or they may decide not to accept its products and services, although instances of both cancellation and non-acceptance are rare. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first six months of fiscal 2024, Ciena recorded a provision for inventory excess and obsolescence of $23.2 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-24-000025:notes:78]
[same as prior period, unchanged from 0000936395-24-000008:notes:74]

[0000936395-24-000025:notes:79]
|  | April 27,2024 |  | October 28,2023 |
| Contract assets for unbilled accounts receivable, net | $ | 151,897 |  |  | $ | 150,312 |  |
| Prepaid VAT and other taxes | 96,803 |  |  | 96,724 |  |
| Prepaid expenses | 71,600 |  |  | 58,954 |  |
| Product demonstration equipment, net | 41,031 |  |  | 40,682 |  |
| Other non-trade receivables | 38,999 |  |  | 33,408 |  |
| Capitalized contract acquisition costs | 19,245 |  |  | 23,326 |  |
| Derivative Assets | 1,341 |  |  | 1,118 |  |
| Deferred deployment expense | 776 |  |  | 1,170 |  |
|  | $ | 421,692 |  |  | $ | 405,694 |  |

[0000936395-24-000025:notes:80]
Depreciation of product demonstration equipment was $3.9 million during the first six months of fiscal 2024 and $3.8 million during the first six months of fiscal 2023.

[0000936395-24-000025:notes:81]
[same as prior period, unchanged from 0000936395-24-000008:notes:77]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-24-000025:notes:82]
OTHER BALANCE SHEET DETAILS
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-24-000025:notes:83]
|  | April 27,2024 |  | October 28,2023 |
| Maintenance spares inventory, net | $ | 62,331 |  |  | $ | 54,042 |  |
| Forward starting interest rate swaps | 30,296 |  |  | 24,953 |  |
| Equity investments(1) | 16,304 |  |  | 48 |  |
| Deferred compensation plan assets | 14,479 |  |  | 11,456 |  |
| Capitalized contract acquisition costs | 7,471 |  |  | 6,879 |  |
| Cloud computing arrangements(2) | 7,265 |  |  | 8,589 |  |
| Deferred debt issuance costs, net | 1,879 |  |  | 1,956 |  |
| Restricted cash | 166 |  |  | 168 |  |
| Other | 11,005 |  |  | 8,362 |  |
|  | $ | 151,196 |  |  | $ | 116,453 |  |

[0000936395-24-000025:notes:84]
(1) Increase is due to an equity investment in a privately held technology company during the second quarter of fiscal 2024.

[0000936395-24-000025:notes:85]
(2) Amortization of cloud computing arrangements was $2.4 million and $1.2 million during the first six months of fiscal 2024 and fiscal 2023, respectively.

[0000936395-24-000025:notes:86]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-24-000025:notes:87]
|  | April 27,2024 |  | October 28,2023 |
| Compensation, payroll related tax and benefits | $ | 130,308 |  |  | $ | 159,530 |  |
| Warranty | 49,896 |  |  | 57,089 |  |
| Vacation | 31,687 |  |  | 29,503 |  |
| Income taxes payable | 7,438 |  |  | 16,341 |  |
| Foreign currency forward contracts | 6,173 |  |  | 14,509 |  |
| Interest payable | 4,807 |  |  | 4,514 |  |
| Finance lease liabilities | 4,234 |  |  | 3,953 |  |
| Other | 120,715 |  |  | 145,980 |  |
|  | $ | 355,258 |  |  | $ | 431,419 |  |

[0000936395-24-000025:notes:88]
[same as prior period, unchanged from 0000936395-24-000008:notes:80]

[0000936395-24-000025:notes:89]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Six Months Ended April 29, 2023 |  | $ | 45,503 |  |  |  |  | 13,577 |  |  | (9,893) |  |  | $ | 49,187 |  |
| Six Months Ended April 27, 2024 |  | $ | 57,089 |  |  |  |  | 8,629 |  |  | (15,822) |  |  | $ | 49,896 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-24-000025:notes:90]
[same as prior period, unchanged from 0000936395-24-000008:notes:82]

[0000936395-24-000025:notes:91]
[same as prior period, unchanged from 0000936395-24-000008:notes:83]

[0000936395-24-000025:notes:92]
As of April 27, 2024 and October 28, 2023, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $316.9 million and $367.3 million as of April 27, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-24-000025:notes:93]
As of April 27, 2024 and October 28, 2023, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. In April 2024, Ciena terminated its existing net investment hedges for a cash loss of $0.6 million, which was recorded to Other Comprehensive Income (Loss). Ciena replaced its terminated net investment hedges with new net investment hedges. The notional amount of these contracts was approximately $65.9 million and $48.0 million as of April 27, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 36 months or less and have been designated as net investment hedges as of April 27, 2024.

[0000936395-24-000025:notes:94]
As of April 27, 2024 and October 28, 2023, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was

[0000936395-24-000025:notes:95]
approximately $239.1 million and $226.3 million as of April 27, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-24-000025:notes:96]
[same as prior period, unchanged from 0000936395-24-000008:notes:87]

[0000936395-24-000025:notes:97]
[same as prior period, unchanged from 0000936395-24-000008:notes:88]

[0000936395-24-000025:notes:98]
In April 2022, Ciena entered into forward starting interest rate swaps to fix the Secured Overnight Financing Rate (“SOFR”) for the first $350.0 million of its floating rate debt at 2.968% from September 2023 through September 2025 (“2025 interest rate swaps”). The total notional amount of the 2025 interest swaps was $350.0 million as of April 27, 2024 and October 28, 2023.

[0000936395-24-000025:notes:99]
In January 2023, Ciena entered into interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.47% through January 2028 (“2028 interest rate swaps”). The total notional amount of these interest rate swaps in effect as of April 27, 2024 and October 28, 2023 was $350.0 million.

[0000936395-24-000025:notes:100]
In December 2023, Ciena entered into forward starting interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.287% from September 2025 through December 2028 (“2028 forward starting interest rate swaps”). The total notional amount of the 2028 forward starting interest rate swaps effective September 2025 was $350.0 million as of April 27, 2024.

[0000936395-24-000025:notes:101]
[same as prior period, unchanged from 0000936395-24-000008:notes:92]

[0000936395-24-000025:notes:102]
[same as prior period, unchanged from 0000936395-24-000008:notes:93]


## us-gaap:DebtDisclosureTextBlock

[0000936395-24-000025:notes:103]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loan Payable

[0000936395-24-000025:notes:104]
2030 New Term Loan

[0000936395-24-000025:notes:105]
On October 24, 2023, Ciena entered into an Incremental Amendment Agreement to its Credit Agreement to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $1.2 billion maturing on October 24, 2030 (the “2030 New Term Loan”) and a new senior secured revolving credit facility of $300.0 million (the “Revolving Credit Facility”). The 2030 New Term Loan requires Ciena to make installment payments of $2.9 million quarterly, or $11.7 million annually, with the remaining balance payable at maturity.

[0000936395-24-000025:notes:106]
The net carrying value of the 2030 New Term Loan was comprised of the following as of the date indicated (in thousands):

[0000936395-24-000025:notes:107]
|  |  | April 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,167,075 |  |  | $ | (4,747) |  |  | $ | (6,071) |  |  | $ | 1,156,257 |  |  | $ | 1,159,371 |  |

[0000936395-24-000025:notes:108]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 New Term Loan totaled $6.1 million as of April 27, 2024 and $5.5 million at October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 New Term Loan. The amortization of deferred debt issuance costs for the 2030 New Term Loan is included in interest expense and was approximately $0.5 million during the first six months of fiscal 2024.

[0000936395-24-000025:notes:109]
As of April 27, 2024, the estimated fair value of the 2030 New Term Loan was $1.2 billion. The 2030 New Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 New Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-24-000025:notes:110]
Refinanced Term Loans

[0000936395-24-000025:notes:111]
The proceeds of the 2030 New Term Loan, net of original issuance discount, was used to repay in full $1.2 billion of outstanding principal of the 2025 Term Loan (as defined below) and the 2030 Term Loan (as defined below), together the Refinanced Term Loans, including accrued interest.

[0000936395-24-000025:notes:112]
2025 Term Loan

[0000936395-24-000025:notes:113]
On January 19, 2023, pursuant to the Incremental Agreement (as defined below) to the Credit Agreement, the Credit Agreement was amended to replace the London Interbank Offered Rate (LIBOR) with SOFR for Ciena’s senior secured term loan maturing on September 28, 2025 (the “2025 Term Loan”) in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million for the first six months of fiscal 2023.

[0000936395-24-000025:notes:114]
2030 Term Loan

[0000936395-24-000025:notes:115]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended, by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan were used for general corporate purposes. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense, and was $0.2 million for the first six months of fiscal 2023.

[0000936395-24-000025:notes:116]
Outstanding Senior Notes Payable

[0000936395-24-000025:notes:117]
2030 Notes

[0000936395-24-000025:notes:118]
On January 18, 2022, Ciena entered into an indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% fixed-rate senior notes due 2030 (the “2030 Notes”).

[0000936395-24-000025:notes:119]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0000936395-24-000025:notes:120]
|  |  | April 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,918) |  |  | $ | 396,082 |  |  | $ | 395,735 |  |  |  |

[0000936395-24-000025:notes:121]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $3.9 million as of April 27, 2024 and $4.3 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.3 million during both the first six months of fiscal 2024 and fiscal 2023.

[0000936395-24-000025:notes:122]
As of April 27, 2024, the estimated fair value of the 2030 Notes was $349.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-24-000025:notes:123]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the six months ended April 27, 2024 (in thousands):

[0000936395-24-000025:notes:124]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  |  |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 28, 2023 | $ | (372) |  |  | $ | (8,156) |  |  |  |  | $ | 18,962 |  |  | $ | (48,201) |  |  | $ | (37,767) |  |
| Other comprehensive gain (loss) before reclassifications | (282) |  |  | 2,812 |  |  |  |  | 11,681 |  |  | 7,647 |  |  | 21,858 |  |
| Amounts reclassified from AOCI | — |  |  | 1,796 |  |  |  |  | (7,616) |  |  | — |  |  | (5,820) |  |
| Balance at April 27, 2024 | $ | (654) |  |  | $ | (3,548) |  |  |  |  | $ | 23,027 |  |  | $ | (40,554) |  |  | $ | (21,729) |  |

[0000936395-24-000025:notes:125]
The following table summarizes the changes in AOCI, net of tax, for the six months ended April 29, 2023 (in thousands):

[0000936395-24-000025:notes:126]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 29, 2022 | $ | (2,965) |  |  | $ | (10,197) |  |  | $ | 9,397 |  |  | $ | (42,880) |  |  | $ | (46,645) |  |
| Other comprehensive gain (loss) before reclassifications | 1,698 |  |  | 9,871 |  |  | (3,848) |  |  | 7,829 |  |  | 15,550 |  |
| Amounts reclassified from AOCI | — |  |  | (5,680) |  |  | (2,979) |  |  | — |  |  | (8,659) |  |
| Balance at April 29, 2023 | $ | (1,267) |  |  | $ | (6,006) |  |  | $ | 2,570 |  |  | $ | (35,051) |  |  | $ | (39,754) |  |

[0000936395-24-000025:notes:127]
[same as prior period, unchanged from 0000936395-24-000008:notes:118]


## us-gaap:EarningsPerShareTextBlock

[0000936395-24-000025:notes:128]
EARNINGS (LOSS) PER SHARE CALCULATION
Basic net income (loss) per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income (loss) per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent that the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-24-000025:notes:129]
[same as prior period, unchanged from 0000936395-24-000008:notes:120]

[0000936395-24-000025:notes:130]
|  | Quarter Ended |  | Six Months Ended |
|  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income (loss) | $ | (16,849) |  |  | $ | 57,654 |  |  | $ | 32,698 |  |  | $ | 133,895 |  |
| Basic weighted average shares outstanding | 144,914 |  |  | 149,616 |  |  | 145,104 |  |  | 149,351 |  |
| Effect of dilutive potential common shares | — |  |  | 531 |  |  | 955 |  |  | 501 |  |
| Diluted weighted average shares | 144,914 |  |  | 150,147 |  |  | 146,059 |  |  | 149,852 |  |
| Basic EPS | $ | (0.12) |  |  | $ | 0.39 |  |  | $ | 0.23 |  |  | $ | 0.90 |  |
| Diluted EPS | $ | (0.12) |  |  | $ | 0.38 |  |  | $ | 0.22 |  |  | $ | 0.89 |  |
| Antidilutive employee share-based awards, excluded | 2,030 |  |  | 1,550 |  |  | 1,584 |  |  | 2,159 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-24-000025:notes:131]
[same as prior period, unchanged from 0000936395-24-000008:notes:122]

[0000936395-24-000025:notes:132]
[same as prior period, unchanged from 0000936395-24-000008:notes:123]

[0000936395-24-000025:notes:133]
During the first six months of fiscal 2024, Ciena repurchased an additional 1.8 million shares of its common stock for an aggregate purchase price of $89.0 million at an average price of $49.00 per share. As of April 27, 2024, Ciena (i) has repurchased 15.9 million shares for an aggregate purchase price of $839.0 million at an average price of $52.69 per share and (ii) has an aggregate of $161.0 million authorized and remaining under its stock repurchase program.

[0000936395-24-000025:notes:134]
[same as prior period, unchanged from 0000936395-24-000008:notes:125]

[0000936395-24-000025:notes:135]
[same as prior period, unchanged from 0000936395-24-000008:notes:126]

[0000936395-24-000025:notes:136]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $22.4 million for the shares of Ciena’s stock repurchased during the first six months of fiscal 2024 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-24-000025:notes:137]
SHARE-BASED COMPENSATION EXPENSE
At Ciena’s 2024 Annual Meeting of Stockholders on March 21, 2024, Ciena’s stockholders approved an amendment to the Ciena Corporation 2017 Omnibus Incentive Plan (the “2017 Plan”), effective as of such date, to (i) increase the number of shares available for issuance thereunder by 10.1 million shares, and (ii) increase the recoupment period for misconduct relating to accounting restatements from 12 months to three years. As of April 27, 2024, the total number of shares authorized for issuance under the 2017 Plan is 31.2 million and approximately 10.8 million shares remained available for issuance thereunder.

[0000936395-24-000025:notes:138]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-24-000025:notes:139]
|  | Quarter Ended |  | Six Months Ended |
|  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Products | $ | 1,760 |  |  | $ | 1,155 |  |  | $ | 3,078 |  |  | $ | 2,206 |  |
| Services | 3,344 |  |  | 2,659 |  |  | 6,364 |  |  | 4,956 |  |
| Share-based compensation expense included in cost of goods sold | 5,104 |  |  | 3,814 |  |  | 9,442 |  |  | 7,162 |  |
| Research and development | 14,066 |  |  | 10,731 |  |  | 26,946 |  |  | 19,965 |  |
| Selling and marketing | 11,166 |  |  | 8,755 |  |  | 21,471 |  |  | 17,179 |  |
| General and administrative | 9,875 |  |  | 8,468 |  |  | 19,954 |  |  | 17,936 |  |
| Share-based compensation expense included in operating expense | 35,107 |  |  | 27,954 |  |  | 68,371 |  |  | 55,080 |  |
| Share-based compensation expense capitalized in inventory, net | 37 |  |  | 92 |  |  | 262 |  |  | 130 |  |
| Total share-based compensation expense | $ | 40,248 |  |  | $ | 31,860 |  |  | $ | 78,075 |  |  | $ | 62,372 |  |

[0000936395-24-000025:notes:140]
As of April 27, 2024, total unrecognized share-based compensation expense was approximately $291.3 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.48 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-24-000025:notes:141]
[same as prior period, unchanged from 0000936395-24-000008:notes:131]

[0000936395-24-000025:notes:142]
[same as prior period, unchanged from 0000936395-24-000008:notes:132]

[0000936395-24-000025:notes:143]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, right-of-use (“ROU”) assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of April 27, 2024, equipment, building, furniture and fixtures, net, totaled $274.4 million, and operating ROU assets totaled $30.2 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of April 27, 2024, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-24-000025:notes:144]
|  | April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 173,232 |  |  | — |  |  | 11,709 |  |  | — |  |  | $ | 184,941 |  |
| Goodwill | $ | 199,677 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 444,917 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 62,331 |  |  | $ | 62,331 |  |

[0000936395-24-000025:notes:145]
[same as prior period, unchanged from 0000936395-24-000008:notes:135]

[0000936395-24-000025:notes:146]
[same as prior period, unchanged from 0000936395-24-000008:notes:136]

[0000936395-24-000025:notes:147]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to net income (loss) for the periods indicated (in thousands):

[0000936395-24-000025:notes:148]
|  | Quarter Ended |  | Six Months Ended |
|  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 96,566 |  |  | $ | 214,754 |  |  | $ | 280,341 |  |  | $ | 416,901 |  |
| Platform Software and Services | 54,037 |  |  | 40,687 |  |  | 112,041 |  |  | 86,337 |  |
| Blue Planet Automation Software and Services | (7,763) |  |  | (6,912) |  |  | (14,832) |  |  | (17,971) |  |
| Global Services | 50,441 |  |  | 49,161 |  |  | 95,424 |  |  | 86,639 |  |
| Total segment profit | 193,281 |  |  | 297,690 |  |  | 472,974 |  |  | 571,906 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 124,071 |  |  | 125,083 |  |  | 252,229 |  |  | 248,890 |  |
| General and administrative | 49,573 |  |  | 50,939 |  |  | 104,256 |  |  | 101,835 |  |
| Significant asset impairments and restructuring costs | 15,655 |  |  | 8,153 |  |  | 20,626 |  |  | 12,451 |  |
| Amortization of intangible assets | 7,947 |  |  | 9,845 |  |  | 15,199 |  |  | 17,286 |  |
| Acquisition and integration costs | — |  |  | 857 |  |  | — |  |  | 3,415 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest and other income, net | 11,797 |  |  | 8,551 |  |  | 22,447 |  |  | 40,524 |  |
| Interest expense | (23,861) |  |  | (23,889) |  |  | (47,637) |  |  | (39,759) |  |
| Less: Provision for income taxes | 820 |  |  | 29,821 |  |  | 22,776 |  |  | 54,899 |  |
| Net income (loss) | $ | (16,849) |  |  | $ | 57,654 |  |  | $ | 32,698 |  |  | $ | 133,895 |  |

[0000936395-24-000025:notes:149]
[same as prior period, unchanged from 0000936395-24-000008:notes:139]

[0000936395-24-000025:notes:150]
[same as prior period, unchanged from 0000936395-24-000008:notes:140]

[0000936395-24-000025:notes:151]
|  | April 27,2024 |  | October 28,2023 |
| Canada | $ | 224,826 |  |  | $ | 229,707 |  |
| United States | 46,288 |  |  | 46,933 |  |
| Other International | 33,449 |  |  | 38,647 |  |
| Total | $ | 304,563 |  |  | $ | 315,287 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-24-000025:notes:152]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-24-000025:notes:153]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-24-000025:notes:154]
Litigation

[0000936395-24-000025:notes:155]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-24-000025:notes:156]
Purchase Order Obligations

[0000936395-24-000025:notes:157]
Ciena has certain advanced orders for supply of certain long lead time components. As of April 27, 2024, Ciena had $1.6 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:SubsequentEventsTextBlock

[0000936395-24-000025:notes:158]
SUBSEQUENT EVENTS
Stock Repurchase Program
From the end of the second quarter of fiscal 2024 through May 31, 2024, Ciena repurchased an additional 0.5 million shares of its common stock for an aggregate purchase price of $24.0 million at an average price of $48.54 per share, inclusive of repurchases pending settlement. As of May 31, 2024, Ciena has repurchased an aggregate of 16.4 million shares and has an aggregate of $137.0 million of authorized funds remaining under its stock repurchase program.
