# CIEN MD&A — 0000936395-24-000025


## mdna

[0000936395-24-000025:mdna:1]
[same as prior period, unchanged from 0000936395-24-000008:mdna:1]

[0000936395-24-000025:mdna:2]
[same as prior period, unchanged from 0000936395-24-000008:mdna:2]

[0000936395-24-000025:mdna:3]
[same as prior period, unchanged from 0000936395-24-000008:mdna:3]

[0000936395-24-000025:mdna:4]
For a discussion identifying some of the important factors that could cause actual results to vary materially from those anticipated in the forward-looking statements, see “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” in this report. For a more complete understanding of the risks associated with an

[0000936395-24-000025:mdna:5]
[same as prior period, unchanged from 0000936395-24-000008:mdna:4]

[0000936395-24-000025:mdna:6]
[same as prior period, unchanged from 0000936395-24-000008:mdna:5]

[0000936395-24-000025:mdna:7]
We are a network platform, software, and services company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software, and services that support the delivery of video, data, and voice traffic over core, metro, aggregation, and access communications networks. Our solutions are used globally by communications service providers, cable and multiservice operators, cloud providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that is informed by analytics and intelligence. Our solutions include Networking Platforms, including our Optical Networking and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our Navigator Network Control SuiteTM (“Navigator NCS”), which we previously referred to as Manage, Control, and Plan (MCP), and applications that deliver advanced multi-layer domain control and operations. Through our Blue Planet Software, we also enable complete service lifecycle management automation with productized operational support systems (OSS), which include inventory, orchestration and assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-24-000025:mdna:8]
[same as prior period, unchanged from 0000936395-24-000008:mdna:8]

[0000936395-24-000025:mdna:9]
For large portions of fiscal 2021 and fiscal 2022, we received an unprecedented volume of orders for our products and services, which significantly exceeded our revenue and historical order volumes. We believe some portion of these orders reflected customer acceleration of future orders due to a constrained supply environment, as well as orders that were delayed due to the dynamics of the COVID-19 pandemic. Our order volumes began to moderate in the fourth quarter of fiscal 2022, and we experienced order levels below revenue during fiscal 2023 and the first half of fiscal 2024, particularly from our communications service provider customers. Our expected return to more typical order patterns with our communications service provider customers is taking longer than anticipated. We believe this is, in part, due to communications service providers in North America working through relatively high levels of inventory previously acquired, which has been made more difficult due to challenges installing and deploying equipment, including site readiness and access to fiber or other resources. In addition, in certain international geographies, we believe that caution driven by macroeconomic concerns and market-specific issues are contributing to lower-than-expected order volumes from communications service providers. We expect these dynamics with our communications service provider customers to persist during fiscal 2024 and anticipate that any future improvements to these dynamics will be gradual. Notwithstanding these near-term impacts, we continue to believe that certain trends and shifts in business and consumer behaviors, including enterprise and consumer cloud network adoption, 5G, high-definition video, generative AI, and network operator focus on resilience and automation, represent positive, long-term drivers of bandwidth demand and long-term opportunities for our business.

[0000936395-24-000025:mdna:10]
[same as prior period, unchanged from 0000936395-24-000008:mdna:10]

[0000936395-24-000025:mdna:11]
Historically, a meaningful portion of our quarterly revenue was generated from customer orders received during that same quarter (which we refer to as “book to revenue”) and was therefore less predictable and subject to fluctuation. As a result of elevated order volumes during portions of fiscal 2021 and fiscal 2022, however, our backlog grew from $1.2 billion at the end of fiscal 2020 to $4.2 billion at the end of fiscal 2022. Accordingly, our revenue in recent fiscal years has been more significantly impacted by factors including availability of supply and customer delivery deferrals, as we converted our existing backlog to revenue. As supply chain conditions have improved, and we have been able to increase shipment volumes and reduce lead times, our backlog decreased to $1.9 billion as of the end of the second quarter of fiscal 2024. As backlog consumption reduces and represents a relatively smaller portion of our quarterly revenue, we expect that our reliance upon securing quarterly book to revenue orders will grow, and that increased orders and a return to a more typical composition of our quarterly revenue will be a critical element of any future revenue growth.

[0000936395-24-000025:mdna:12]
The timing, pace, and degree to which we fulfill our backlog will have a significant impact on our revenue and can be affected by factors outside of our control, including customer readiness and willingness to receive shipment against existing orders. During fiscal 2023 and the first half of fiscal 2024, certain customers, including communications service providers and cable and multiservice operators in North America, that had earlier placed significant advanced orders, rescheduled deliveries for a portion of such orders. We believe that this was the result of a number of factors, including the rapid improvement in our delivery lead times as supply chain conditions improved and their capital expenditure and inventory levels. Accordingly, our results for a particular period can be difficult to predict. As a result of these and other factors, the timing of our fulfillment of backlog could cause some volatility in our results of operations and our backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period.

[0000936395-24-000025:mdna:13]
[same as prior period, unchanged from 0000936395-24-000008:mdna:13]

[0000936395-24-000025:mdna:14]
[same as prior period, unchanged from 0000936395-24-000008:mdna:14]

[0000936395-24-000025:mdna:15]
[same as prior period, unchanged from 0000936395-24-000008:mdna:15]

[0000936395-24-000025:mdna:16]
[same as prior period, unchanged from 0000936395-24-000008:mdna:16]

[0000936395-24-000025:mdna:17]
[same as prior period, unchanged from 0000936395-24-000008:mdna:17]

[0000936395-24-000025:mdna:18]
[same as prior period, unchanged from 0000936395-24-000008:mdna:18]

[0000936395-24-000025:mdna:19]
As a result of the factors impacting order volumes and order delivery timing described under “Overview” above, our revenue declined by 19.6% in the second quarter of fiscal 2024 as compared to the second quarter of fiscal 2023, and 11.0% in the first six months of fiscal 2024 as compared to the first six months of fiscal 2023. In addition, during the second quarter and first six months of fiscal 2024, approximately 15.0% of our revenue was non-U.S. Dollar-denominated primarily including sales in Euros, Canadian Dollars, and Indian Rupees. During the second quarter of fiscal 2024 as compared to the second quarter of fiscal 2023, and during the first six months of fiscal 2024 as compared to the first six months of fiscal 2023, the U.S. Dollar fluctuated against these currencies. As a result of these currency fluctuations, our revenue reported in U.S. Dollars was adversely impacted by approximately $0.6 million, or 0.1%, as compared to the second quarter of fiscal 2023, and increased by approximately $5.5 million, or 0.3% as compared to the first six months of fiscal 2023.

[0000936395-24-000025:mdna:20]
[same as prior period, unchanged from 0000936395-24-000008:mdna:20]

[0000936395-24-000025:mdna:21]
[same as prior period, unchanged from 0000936395-24-000008:mdna:21]

[0000936395-24-000025:mdna:22]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 560,224 |  |  | $ | 784,549 |  |  |  |  | (28.6) | % |  | $ | 1,256,072 |  |  | $ | 1,520,183 |  |  |  |  | (17.4) | % |
| %** | 61.5 | % |  | 69.3 | % |  |  |  |  |  | 64.4 | % |  | 69.4 | % |  |  |  |  |
| Routing and Switching | 116,034 |  |  | 130,310 |  |  |  |  | (11.0) | % |  | 227,421 |  |  | 249,814 |  |  |  |  | (9.0) | % |
| %** | 12.7 | % |  | 11.5 | % |  |  |  |  |  | 11.7 | % |  | 11.4 | % |  |  |  |  |
| Total Networking Platforms | 676,258 |  |  | 914,859 |  |  |  |  | (26.1) | % |  | 1,483,493 |  |  | 1,769,997 |  |  |  |  | (16.2) | % |
| %** | 74.2 | % |  | 80.8 | % |  |  |  |  |  | 76.1 | % |  | 80.8 | % |  |  |  |  |
| Platform Software and Services | 85,445 |  |  | 69,443 |  |  |  |  | 23.0 | % |  | 175,190 |  |  | 142,888 |  |  |  |  | 22.6 | % |
| %** | 9.4 | % |  | 6.1 | % |  |  |  |  |  | 9.0 | % |  | 6.6 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 14,434 |  |  | 20,567 |  |  |  |  | (29.8) | % |  | 28,376 |  |  | 35,973 |  |  |  |  | (21.1) | % |
| %** | 1.6 | % |  | 1.8 | % |  |  |  |  |  | 1.5 | % |  | 1.6 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 77,410 |  |  | 73,160 |  |  |  |  | 5.8 | % |  | 151,525 |  |  | 141,051 |  |  |  |  | 7.4 | % |
| %** | 8.5 | % |  | 6.5 | % |  |  |  |  |  | 7.8 | % |  | 6.4 | % |  |  |  |  |
| Installation and Deployment | 43,785 |  |  | 39,486 |  |  |  |  | 10.9 | % |  | 86,509 |  |  | 74,061 |  |  |  |  | 16.8 | % |
| %** | 4.8 | % |  | 3.5 | % |  |  |  |  |  | 4.4 | % |  | 3.4 | % |  |  |  |  |
| Consulting and Network Design | 13,494 |  |  | 15,140 |  |  |  |  | (10.9) | % |  | 23,442 |  |  | 25,206 |  |  |  |  | (7.0) | % |
| %** | 1.5 | % |  | 1.3 | % |  |  |  |  |  | 1.2 | % |  | 1.2 | % |  |  |  |  |
| Total Global Services | 134,689 |  |  | 127,786 |  |  |  |  | 5.4 | % |  | 261,476 |  |  | 240,318 |  |  |  |  | 8.8 | % |
| %** | 14.8 | % |  | 11.3 | % |  |  |  |  |  | 13.4 | % |  | 11.0 | % |  |  |  |  |
| Total revenue | $ | 910,826 |  |  | $ | 1,132,655 |  |  |  |  | (19.6) | % |  | $ | 1,948,535 |  |  | $ | 2,189,176 |  |  |  |  | (11.0) | % |

[0000936395-24-000025:mdna:23]
[same as prior period, unchanged from 0000936395-24-000008:mdna:23]

[0000936395-24-000025:mdna:24]
[same as prior period, unchanged from 0000936395-24-000008:mdna:24]

[0000936395-24-000025:mdna:25]
[same as prior period, unchanged from 0000936395-24-000008:mdna:25]

[0000936395-24-000025:mdna:26]
Quarter ended April 27, 2024 as compared to the quarter ended April 29, 2023

[0000936395-24-000025:mdna:27]
•Networking Platforms segment revenue decreased by $238.6 million, reflecting product line sales decreases of $224.3 million of our Optical Networking products and $14.3 million of our Routing and Switching products.

[0000936395-24-000025:mdna:28]
◦Optical Networking sales decreased, primarily reflecting sales decreases of $188.1 million of our 6500 Packet-Optical Platform, primarily to communications service providers and enterprise customers, $40.0 million of our Waveserver® modular interconnect system, primarily to cloud providers, and $10.5 million of our 5400 family of Packet-Optical Platforms primarily to communications service providers. These sales decreases were partially offset by a sales increase of $13.2 million of our 6500 Reconfigurable Line System (RLS) products, primarily to enterprise customers and cloud providers partially offset by decreased sales to communications service providers.

[0000936395-24-000025:mdna:29]
◦Routing and Switching sales decreased, primarily reflecting sales decreases of $7.9 million of our 3000 and 5000 families of service delivery and aggregation switches and $4.4 million of our virtualization software, primarily to communications service providers.

[0000936395-24-000025:mdna:30]
•Platform Software and Services segment revenue increased by $16.0 million, reflecting sales increases of $9.3 million of our software platforms and $6.7 million in our software maintenance services, both primarily for our Navigator NCS software platform.

[0000936395-24-000025:mdna:31]
•Blue Planet Automation Software and Services segment revenue decreased by $6.1 million reflecting sales decreases of $4.7 million in software platforms and $1.4 million in professional software services, both primarily to communications service providers.

[0000936395-24-000025:mdna:32]
•Global Services segment revenue increased by $6.9 million, primarily reflecting sales increases of $4.3 million of our installation and deployment services and $4.2 million of our maintenance support and training, partially offset by a sales decrease of $1.6 million of our consulting and network design services.

[0000936395-24-000025:mdna:33]
Six months ended April 27, 2024 as compared to the six months ended April 29, 2023

[0000936395-24-000025:mdna:34]
•Networking Platforms segment revenue decreased by $286.5 million, reflecting product line sales decreases of $264.1 million of our Optical Networking products and $22.4 million of our Routing and Switching products.

[0000936395-24-000025:mdna:35]
◦Optical Networking sales decreased, primarily reflecting sales decreases of $366.7 million of our 6500

[0000936395-24-000025:mdna:36]
Packet-Optical Platform, primarily to communications service providers, enterprise customers, cloud providers and cable and multiservice operators, and $14.3 million of our 5400 family of Packet-Optical Platforms, primarily to communications service providers. These sales decreases were partially offset by sales increases of $86.7 million of our 6500 RLS products, primarily to cloud providers, enterprise customers and cable and multiservice operators, and $24.5 million of our Waveserver® products, primarily to cloud providers and cable and multiservice operators.

[0000936395-24-000025:mdna:37]
◦Routing and Switching sales decreased, primarily reflecting a sales decrease of $34.3 million of our virtualization software, primarily to communications service providers. This sales decrease was partially offset by sales increases of $7.1 million of our 8100 Coherent IP networking platforms, primarily to communications service providers and enterprise customers, and $4.6 million of our platform independent software, primarily to communications service providers.

[0000936395-24-000025:mdna:38]
•Platform Software and Services segment revenue increased by $32.3 million, primarily reflecting sales increases of $18.1 million in sales of software platforms and $14.2 million in sales of our software maintenance services, both primarily for our Navigator NCS software platform.

[0000936395-24-000025:mdna:39]
•Blue Planet Automation Software and Services segment revenue decreased by $7.6 million, primarily reflecting a sales decrease in software platforms to communications service providers.

[0000936395-24-000025:mdna:40]
•Global Services segment revenue increased by $21.2 million, primarily reflecting sales increases of $12.4 million of our installation and deployment services and $10.5 million of our maintenance support and training, partially offset by a sales decrease of $1.7 million of our consulting and network design services.

[0000936395-24-000025:mdna:41]
[same as prior period, unchanged from 0000936395-24-000008:mdna:33]

[0000936395-24-000025:mdna:42]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The decrease in our Americas region revenue for the quarter and six months ended April 27, 2024 was primarily driven by decreased sales in the United States and Canada. The decrease in our APAC region revenue for the quarter and six months ended April 27, 2024 was primarily driven by decreased sales in India and Australia. The decrease in our EMEA region revenue for the quarter April 27, 2024 was primarily driven by decreased sales in France and the Great Britain. The increase in our EMEA region revenue for the six months ended April 27, 2024 was primarily driven by increased sales in the Netherlands.

[0000936395-24-000025:mdna:43]
[same as prior period, unchanged from 0000936395-24-000008:mdna:35]

[0000936395-24-000025:mdna:44]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |
| Americas | $ | 662,877 |  |  | $ | 794,359 |  |  |  |  | (16.6) | % |  | $ | 1,381,075 |  |  | $ | 1,559,455 |  |  |  |  | (11.4) | % |
| %** | 72.8 | % |  | 70.1 | % |  |  |  |  |  | 70.9 | % |  | 71.2 | % |  |  |  |  |
| EMEA | 155,791 |  |  | 173,414 |  |  |  |  | (10.2) | % |  | 363,203 |  |  | 326,218 |  |  |  |  | 11.3 | % |
| %** | 17.1 | % |  | 15.3 | % |  |  |  |  |  | 18.6 | % |  | 14.9 | % |  |  |  |  |
| APAC | 92,158 |  |  | 164,882 |  |  |  |  | (44.1) | % |  | 204,257 |  |  | 303,503 |  |  |  |  | (32.7) | % |
| %** | 10.1 | % |  | 14.6 | % |  |  |  |  |  | 10.5 | % |  | 13.9 | % |  |  |  |  |
| Total | $ | 910,826 |  |  | $ | 1,132,655 |  |  |  |  | (19.6) | % |  | $ | 1,948,535 |  |  | $ | 2,189,176 |  |  |  |  | (11.0) | % |

[0000936395-24-000025:mdna:45]
[same as prior period, unchanged from 0000936395-24-000008:mdna:37]

[0000936395-24-000025:mdna:46]
[same as prior period, unchanged from 0000936395-24-000008:mdna:38]

[0000936395-24-000025:mdna:47]
[same as prior period, unchanged from 0000936395-24-000008:mdna:39]

[0000936395-24-000025:mdna:48]
Quarter ended April 27, 2024 as compared to the quarter ended April 29, 2023

[0000936395-24-000025:mdna:49]
•Americas revenue decreased by $131.5 million, primarily reflecting sales decreases of $143.7 million within our Networking Platforms segment and $1.0 million within our Blue Planet Automation Software and Services segment, partially offset by a sales increase of $13.4 million within our Platform Software and Services. The decrease within our Networking Platforms segment reflects product line sales decreases of $133.8 million of our Optical Networking products and $9.9 million of our Routing and Switching products. The decrease within our Optical Networking product line was primarily related to sales decreases of $99.2 million of our 6500 Packet-Optical Platform, primarily to communications service providers, and $23.0 million of our Waveserver® modular interconnect system, primarily to cloud providers. The decrease within our Routing and Switching product line primarily reflects sales decreases of $5.1 million of our 3000 and 5000 families of service delivery and aggregation switches to enterprise customers and cable and multiservice operators, and $4.4 million of our virtualization software, primarily to communications service providers.

[0000936395-24-000025:mdna:50]
•EMEA revenue decreased by $17.6 million, reflecting sales decreases of $17.3 million within our Networking Platforms segment, $5.0 million within our Blue Planet Software and Services segment and $1.1 million within our Platform Software and Services segment, offset by a sales increase of $5.7 million within our Global Services segment. The decrease within our Networking Platforms segment primarily reflects product line sales decreases of $11.6 million of our Optical Networking product line and $5.7 million of our Routing and Switching products. The decrease within our Optical Networking product line was primarily related to a sales decrease of $21.2 million of our 6500 Packet-Optical Platform, primarily to communications service providers and cable and multiservice operators, and $7.6 million of our Waveserver® products, primarily to communications service providers, partially offset by a sales increase of $17.3 million of our 6500 RLS products, primarily to cloud providers.

[0000936395-24-000025:mdna:51]
•APAC revenue decreased by $72.7 million, primarily reflecting a sales decrease of $77.6 million within our Networking Platforms segment, partially offset by increased sales of $3.7 million within our Platform Software and Services segment and $1.3 million within our Global Services segment. The decrease within our Networking Platforms segment primarily reflects a product line sales decrease of $78.9 million of Optical Networking products, which primarily reflects a sales decrease of $67.8 million of our 6500 Packet-Optical Platform, primarily to communications service providers.

[0000936395-24-000025:mdna:52]
Six months ended April 27, 2024 as compared to the six months ended April 29, 2023

[0000936395-24-000025:mdna:53]
•Americas revenue decreased by $178.4 million, reflecting sales decreases of $203.4 million within our Networking Platforms segment and $2.4 million within our Blue Planet Automation Software and Services segment. These sales decreases were partially offset by sales increases of $22.2 million within our Platform Software and Services segment and $5.2 million within our Global Services segment. Our Networking Platforms segment revenue decrease reflects product line sales decreases of $176.1 million of Optical Networking products and $27.3 million of Routing and Switching products. Our Optical Networking revenue primarily reflects a sales decrease of $235.3 million of our 6500 Packet-Optical Platform, primarily to communications service providers and cloud providers, partially offset by sales increases of $50.9 million of our 6500 RLS products, primarily to cloud providers and enterprise customers, and $16.7 million of our Waveserver® modular interconnect system, primarily to communications service providers. Routing and Switching product line sales primarily reflect a sales decrease of $34.3 million of our virtualization software primarily to communications service providers, partially offset by a sales increase of $7.1 million of our 8100 Coherent IP networking platforms, primarily to communications service providers.

[0000936395-24-000025:mdna:54]
•EMEA revenue increased by $37.0 million, reflecting sales increases of $25.2 million within our Networking Platforms segment, $12.8 million within our Global Services segment and $4.3 million within our Platform Software and Services segment. These sales increases were offset by a sales decrease of $5.3 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue increase primarily reflects a product line sales increase of $25.2 million of Optical Networking products. Optical Networking revenue primarily reflects sales increases of $30.8 million of our 6500 RLS products primarily to cloud providers and $17.2 million of our Waveserver® products, primarily to cloud providers partially offset by a sales decreases to communication services providers. These sales increases were partially offset by a sales decrease of $23.2 million of our 6500 Packet-Optical Platform, primarily to communications service providers.

[0000936395-24-000025:mdna:55]
•APAC revenue decreased by $99.2 million, primarily reflecting a sales decrease of $108.3 million within our Networking Platforms segment. This sales decrease was partially offset by sales increases of $5.8 million within our Platform Software and Services segment and $3.1 million within our Global Services segment. Our Networking Platforms segment revenue decrease primarily reflects a product line sales decrease of $113.2 million of Optical Networking products, including a sales decrease of $108.2 million of our 6500 Packet-Optical Platform, primarily to communications service providers and enterprise customers.

[0000936395-24-000025:mdna:56]
[same as prior period, unchanged from 0000936395-24-000008:mdna:47]

[0000936395-24-000025:mdna:57]
[same as prior period, unchanged from 0000936395-24-000008:mdna:48]

[0000936395-24-000025:mdna:58]
[same as prior period, unchanged from 0000936395-24-000008:mdna:49]

[0000936395-24-000025:mdna:59]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |
| Total revenue | $ | 910,826 |  |  | $ | 1,132,655 |  |  |  |  | (19.6) | % |  | $ | 1,948,535 |  |  | $ | 2,189,176 |  |  |  |  | (11.0) | % |
| Total cost of goods sold | 522,165 |  |  | 644,972 |  |  |  |  | (19.0) | % |  | 1,092,912 |  |  | 1,245,547 |  |  |  |  | (12.3) | % |
| Gross profit | $ | 388,661 |  |  | $ | 487,683 |  |  |  |  | (20.3) | % |  | $ | 855,623 |  |  | $ | 943,629 |  |  |  |  | (9.3) | % |
| %** | 42.7 | % |  | 43.1 | % |  |  |  |  |  | 43.9 | % |  | 43.1 | % |  |  |  |  |

[0000936395-24-000025:mdna:60]
[same as prior period, unchanged from 0000936395-24-000008:mdna:51]

[0000936395-24-000025:mdna:61]
[same as prior period, unchanged from 0000936395-24-000008:mdna:52]

[0000936395-24-000025:mdna:62]
[same as prior period, unchanged from 0000936395-24-000008:mdna:53]

[0000936395-24-000025:mdna:63]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |
| Product revenue | $ | 701,316 |  |  | $ | 935,330 |  |  |  |  | (25.0) | % |  | $ | 1,537,093 |  |  | $ | 1,813,045 |  |  |  |  | (15.2) | % |
| Product cost of goods sold | 415,732 |  |  | 541,883 |  |  |  |  | (23.3) | % |  | 882,204 |  |  | 1,042,220 |  |  |  |  | (15.4) | % |
| Product gross profit | $ | 285,584 |  |  | $ | 393,447 |  |  |  |  | (27.4) | % |  | $ | 654,889 |  |  | $ | 770,825 |  |  |  |  | (15.0) | % |
| %** | 40.7 | % |  | 42.1 | % |  |  |  |  |  | 42.6 | % |  | 42.5 | % |  |  |  |  |

[0000936395-24-000025:mdna:64]
[same as prior period, unchanged from 0000936395-24-000008:mdna:55]

[0000936395-24-000025:mdna:65]
[same as prior period, unchanged from 0000936395-24-000008:mdna:56]

[0000936395-24-000025:mdna:66]
[same as prior period, unchanged from 0000936395-24-000008:mdna:57]

[0000936395-24-000025:mdna:67]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |
| Services revenue | $ | 209,510 |  |  | $ | 197,325 |  |  |  |  | 6.2 | % |  | $ | 411,442 |  |  | $ | 376,131 |  |  |  |  | 9.4 | % |
| Services cost of goods sold | 106,433 |  |  | 103,089 |  |  |  |  | 3.2 | % |  | 210,708 |  |  | 203,327 |  |  |  |  | 3.6 | % |
| Services gross profit | $ | 103,077 |  |  | $ | 94,236 |  |  |  |  | 9.4 | % |  | $ | 200,734 |  |  | $ | 172,804 |  |  |  |  | 16.2 | % |
| % ** | 49.2 | % |  | 47.8 | % |  |  |  |  |  | 48.8 | % |  | 45.9 | % |  |  |  |  |

[0000936395-24-000025:mdna:68]
[same as prior period, unchanged from 0000936395-24-000008:mdna:59]

[0000936395-24-000025:mdna:69]
[same as prior period, unchanged from 0000936395-24-000008:mdna:60]

[0000936395-24-000025:mdna:70]
[same as prior period, unchanged from 0000936395-24-000008:mdna:61]

[0000936395-24-000025:mdna:71]
Quarter ended April 27, 2024 as compared to the quarter ended April 29, 2023

[0000936395-24-000025:mdna:72]
•Gross profit decreased by $99.0 million. Gross margin decreased by 40 basis points, primarily due to lower manufacturing efficiencies and higher inventory excess and obsolescence costs, partially offset by improved margins on Platform and Blue Planet software services and product cost reductions.

[0000936395-24-000025:mdna:73]
•Gross profit on products decreased by $107.9 million. Product gross margin decreased by 140 basis points, primarily due to lower manufacturing efficiencies and higher inventory excess and obsolescence costs, partially offset by product cost reductions.

[0000936395-24-000025:mdna:74]
•Gross profit on services increased by $8.8 million. Gross margin increased by 140 basis points, primarily due to increased revenue for Platform software subscription services and higher margins on Blue Planet software services due to improved efficiencies on delivery.

[0000936395-24-000025:mdna:75]
Six months ended April 27, 2024 as compared to the six months ended April 29, 2023

[0000936395-24-000025:mdna:76]
•Gross profit decreased by $88.0 million. Gross margin increased by 80 basis points, primarily due to reduced component costs and improved margins on Blue Planet software, partially offset by higher inventory excess and obsolescence costs and lower manufacturing efficiencies.

[0000936395-24-000025:mdna:77]
•Gross profit on products decreased by $115.9 million. Product gross margin slightly increased by 10 basis points, primarily due to reduced component costs and higher software revenue, partially offset by higher inventory excess and obsolescence costs and lower manufacturing efficiencies.

[0000936395-24-000025:mdna:78]
•Gross profit on services increased by $27.9 million. Services gross margin increased by 290 basis points, primarily due to higher margins on Blue Planet software services due to improved efficiencies on delivery. Additionally, margins on deployment services increased due to increased revenue and efficiencies reducing costs.

[0000936395-24-000025:mdna:79]
[same as prior period, unchanged from 0000936395-24-000008:mdna:66]

[0000936395-24-000025:mdna:80]
[same as prior period, unchanged from 0000936395-24-000008:mdna:67]

[0000936395-24-000025:mdna:81]
Approximately 50.3% and 49.1% of our operating expense was non-U.S. Dollar-denominated during the second quarter and first six months of fiscal 2024, respectively, including expenses in Canadian Dollars, Indian Rupees, and Euros. During the second quarter of fiscal 2024, as compared to the second quarter of fiscal 2023, and during the first six months of fiscal 2024, as compared to the first six months of fiscal 2023, the U.S. Dollar fluctuated against these currencies. As a result of these currency fluctuations, our operating expense, net of hedging, reported in U.S. Dollars, was adversely affected by approximately $0.6 million, or 0.1% and $1.5 million, or 0.2%, respectively.

[0000936395-24-000025:mdna:82]
[same as prior period, unchanged from 0000936395-24-000008:mdna:69]

[0000936395-24-000025:mdna:83]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |
| Research and development | $ | 195,380 |  |  | $ | 189,993 |  |  |  |  | 2.8 | % |  | $ | 382,649 |  |  | $ | 371,723 |  |  |  |  | 2.9 | % |
| %** | 21.5 | % |  | 16.8 | % |  |  |  |  |  | 19.6 | % |  | 17.0 | % |  |  |  |  |
| Selling and marketing | 124,071 |  |  | 125,083 |  |  |  |  | (0.8) | % |  | 252,229 |  |  | 248,890 |  |  |  |  | 1.3 | % |
| %** | 13.6 | % |  | 11.0 | % |  |  |  |  |  | 12.9 | % |  | 11.4 | % |  |  |  |  |
| General and administrative | 49,573 |  |  | 50,939 |  |  |  |  | (2.7) | % |  | 104,256 |  |  | 101,835 |  |  |  |  | 2.4 | % |
| %** | 5.4 | % |  | 4.5 | % |  |  |  |  |  | 5.4 | % |  | 4.6 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 15,655 |  |  | 8,153 |  |  |  |  | 92.0 | % |  | 20,626 |  |  | 12,451 |  |  |  |  | 65.7 | % |
| %** | 1.7 | % |  | 0.7 | % |  |  |  |  |  | 1.1 | % |  | 0.6 | % |  |  |  |  |
| Amortization of intangible assets | 7,947 |  |  | 9,845 |  |  |  |  | (19.3) | % |  | 15,199 |  |  | 17,286 |  |  |  |  | (12.1) | % |
| %** | 0.9 | % |  | 0.9 | % |  |  |  |  |  | 0.8 | % |  | 0.8 | % |  |  |  |  |
| Acquisition and integration costs | — |  |  | 857 |  |  |  |  | (100.0) | % |  | — |  |  | 3,415 |  |  |  |  | (100.0) | % |
| %** | — | % |  | 0.1 | % |  |  |  |  |  | — | % |  | 0.1 | % |  |  |  |  |
| Total operating expenses | $ | 392,626 |  |  | $ | 384,870 |  |  |  |  | 2.0 | % |  | $ | 774,959 |  |  | $ | 755,600 |  |  |  |  | 2.6 | % |
| %** | 43.1 | % |  | 34.0 | % |  |  |  |  |  | 39.8 | % |  | 34.5 | % |  |  |  |  |

[0000936395-24-000025:mdna:84]
[same as prior period, unchanged from 0000936395-24-000008:mdna:71]

[0000936395-24-000025:mdna:85]
[same as prior period, unchanged from 0000936395-24-000008:mdna:72]

[0000936395-24-000025:mdna:86]
[same as prior period, unchanged from 0000936395-24-000008:mdna:73]

[0000936395-24-000025:mdna:87]
Quarter ended April 27, 2024 as compared to the quarter ended April 29, 2023

[0000936395-24-000025:mdna:88]
•Research and development expense increased by $5.4 million, net of hedging. This increase primarily reflects increases in employee-related compensation costs, net of a lower provision associated with our annual cash incentive compensation plan, and facility and information technology costs.

[0000936395-24-000025:mdna:89]
•Selling and marketing expense decreased by $1.0 million. This decrease primarily reflects decreases in employee-related compensation costs primarily due to lower commission expense and lower provisions associated with our annual cash incentive compensation plan, partially offset by an increase in travel and entertainment costs.

[0000936395-24-000025:mdna:90]
•General and administrative expense decreased by $1.4 million. This decrease primarily reflects a decrease in costs for professional services partially offset by an increase in employee-related compensation costs, net of a lower provision associated with our annual cash incentive compensation plan.

[0000936395-24-000025:mdna:91]
•Significant asset impairments and restructuring costs reflects actions that we have taken with respect to our operations, global workforce, and facilities as part of a business optimization strategy to improve gross margin, constrain operating expense, redesign certain business processes, and restructure real estate facilities. For more information on our restructuring costs, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-24-000025:mdna:92]
•Amortization of intangible assets decreased by $1.9 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0000936395-24-000025:mdna:93]
•Acquisition and integration costs in fiscal 2023 reflect financial, legal, and accounting advisors and employee-related costs related to our acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) during the first quarter of fiscal 2023.

[0000936395-24-000025:mdna:94]
Six months ended April 27, 2024 as compared to the six months ended April 29, 2023

[0000936395-24-000025:mdna:95]
•Research and development expense increased by $10.9 million, net of hedging. This increase primarily reflects increases in employee-related compensation costs, net of a lower provision associated with our annual cash incentive compensation plan, facility and information technology costs and higher technology related costs, partially offset by decreased professional services.

[0000936395-24-000025:mdna:96]
•Selling and marketing expense increased by $3.3 million. This increase primarily reflects increases in employee-related compensation costs, net of lower commission expense and lower provisions associated with our annual cash

[0000936395-24-000025:mdna:97]
incentive compensation plan, and increases in travel and entertainment costs, partially offset by decreased selling and marketing costs.

[0000936395-24-000025:mdna:98]
•General and administrative expense increased by $2.4 million. This increase primarily reflects an increase in employee-related compensation costs, net of a lower provision associated with our annual cash incentive compensation plan and bad debt expense partially offset by a decrease in costs for professional services.

[0000936395-24-000025:mdna:99]
•Significant asset impairments and restructuring costs reflects actions that we have taken with respect to our operations, global workforce, and facilities as part of a business optimization strategy to improve gross margin, constrain operating expense, redesign certain business processes, and restructure real estate facilities. For more information on our restructuring costs, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-24-000025:mdna:100]
•Amortization of intangible assets decreased by $2.1 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0000936395-24-000025:mdna:101]
•Acquisition and integration costs in fiscal 2023 reflect financial, legal, and accounting advisors and employee-related costs related to our acquisitions of Benu and Tibit during the first quarter of fiscal 2023.

[0000936395-24-000025:mdna:102]
[same as prior period, unchanged from 0000936395-24-000008:mdna:81]

[0000936395-24-000025:mdna:103]
[same as prior period, unchanged from 0000936395-24-000008:mdna:82]

[0000936395-24-000025:mdna:104]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |
| Interest and other income, net | $ | 11,797 |  |  | $ | 8,551 |  |  |  |  | 38.0 | % |  | $ | 22,447 |  |  | $ | 40,524 |  |  |  |  | (44.6) | % |
| %** | 1.3 | % |  | 0.8 | % |  |  |  |  |  | 1.2 | % |  | 1.9 | % |  |  |  |  |
| Interest expense | $ | 23,861 |  |  | $ | 23,889 |  |  |  |  | (0.1) | % |  | $ | 47,637 |  |  | $ | 39,759 |  |  |  |  | 19.8 | % |
| %** | 2.6 | % |  | 2.1 | % |  |  |  |  |  | 2.4 | % |  | 1.8 | % |  |  |  |  |
| Provision for income taxes | $ | 820 |  |  | $ | 29,821 |  |  |  |  | (97.3) | % |  | $ | 22,776 |  |  | $ | 54,899 |  |  |  |  | (58.5) | % |
| %** | 0.1 | % |  | 2.6 | % |  |  |  |  |  | 1.2 | % |  | 2.5 | % |  |  |  |  |

[0000936395-24-000025:mdna:105]
[same as prior period, unchanged from 0000936395-24-000008:mdna:84]

[0000936395-24-000025:mdna:106]
[same as prior period, unchanged from 0000936395-24-000008:mdna:85]

[0000936395-24-000025:mdna:107]
[same as prior period, unchanged from 0000936395-24-000008:mdna:86]

[0000936395-24-000025:mdna:108]
Quarter ended April 27, 2024 as compared to the quarter ended April 29, 2023

[0000936395-24-000025:mdna:109]
•Interest and other income, net increased by $3.2 million, primarily resulting from higher interest income on our investments partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-24-000025:mdna:110]
•Interest expense remained relatively unchanged. For more information on our short-term and long-term debt, see Note 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-24-000025:mdna:111]
•Provision for income taxes decreased by $29.0 million, and the effective tax rate for the second quarter of fiscal 2024 was lower than the effective tax rate for the second quarter of fiscal 2023, both primarily due to the decrease in pre-tax book income for the quarter.

[0000936395-24-000025:mdna:112]
Six months ended April 27, 2024 as compared to the six months ended April 29, 2023

[0000936395-24-000025:mdna:113]
•Interest and other income, net decreased by $18.1 million, primarily resulting from the remeasurement of our previously held investment in Tibit to fair value, in fiscal 2023, which resulted in a gain on our equity investment of $26.5 million and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. These decreases were partially offset by higher interest income on our investments.

[0000936395-24-000025:mdna:114]
•Interest expense increased by $7.9 million, primarily due to higher interest rates on our floating rate debt, net of hedging activity, and additional outstanding indebtedness, including the 2030 Term Loan incurred in the first quarter of fiscal 2023. For more information on our short-term and long-term debt, see Note 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-24-000025:mdna:115]
•Provision for income taxes decreased by $32.1 million, primarily due to the decrease in pre-tax book income for the first six months. The effective tax rate for the first six months of fiscal 2024 was higher than the effective tax rate for the first six months of fiscal 2023, primarily due to a reduction in pre-tax book income in lower tax jurisdictions.

[0000936395-24-000025:mdna:116]
[same as prior period, unchanged from 0000936395-24-000008:mdna:91]

[0000936395-24-000025:mdna:117]
[same as prior period, unchanged from 0000936395-24-000008:mdna:92]

[0000936395-24-000025:mdna:118]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |  | April 27, 2024 |  | April 29, 2023 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 96,566 |  |  | $ | 214,754 |  |  |  |  | (55.0) | % |  | $ | 280,341 |  |  | $ | 416,901 |  |  |  |  | (32.8) | % |
| Platform Software and Services | $ | 54,037 |  |  | $ | 40,687 |  |  |  |  | 32.8 | % |  | $ | 112,041 |  |  | $ | 86,337 |  |  |  |  | 29.8 | % |
| Blue Planet Automation Software and Services | $ | (7,763) |  |  | $ | (6,912) |  |  |  |  | (12.3) | % |  | $ | (14,832) |  |  | $ | (17,971) |  |  |  |  | 17.5 | % |
| Global Services | $ | 50,441 |  |  | $ | 49,161 |  |  |  |  | 2.6 | % |  | $ | 95,424 |  |  | $ | 86,639 |  |  |  |  | 10.1 | % |

[0000936395-24-000025:mdna:119]
[same as prior period, unchanged from 0000936395-24-000008:mdna:94]

[0000936395-24-000025:mdna:120]
[same as prior period, unchanged from 0000936395-24-000008:mdna:95]

[0000936395-24-000025:mdna:121]
Quarter ended April 27, 2024 as compared to the quarter ended April 29, 2023

[0000936395-24-000025:mdna:122]
•Networking Platforms segment profit decreased by $118.2 million, primarily due to lower product sales volume and lower gross margin as described above, and increased research and development costs.

[0000936395-24-000025:mdna:123]
•Platform Software and Services segment profit increased by $13.4 million, primarily due to higher sales volume as described above.

[0000936395-24-000025:mdna:124]
•Blue Planet Automation Software and Services segment loss slightly increased, primarily due to lower sales volume, partially offset by improved margins on software services as described above and decreased research and development costs.

[0000936395-24-000025:mdna:125]
•Global Services segment profit increased by $1.3 million, primarily due to higher sales volume.

[0000936395-24-000025:mdna:126]
Six months ended April 27, 2024 as compared to the six months ended April 29, 2023

[0000936395-24-000025:mdna:127]
•Networking Platforms segment profit decreased by $136.6 million, primarily due to lower sales volume and increased research and development costs.

[0000936395-24-000025:mdna:128]
•Platform Software and Services segment profit increased by $25.7 million, primarily due to higher sales volume partially offset by increased research and development costs.

[0000936395-24-000025:mdna:129]
•Blue Planet Automation Software and Services segment loss decreased by $3.1 million, primarily due to higher gross margin on software-related services and decreased research and development costs, partially offset by lower sales volume.

[0000936395-24-000025:mdna:130]
•Global Services segment profit increased by $8.8 million, primarily due to higher sales volume and improved gross margin on deployment services as described above.

[0000936395-24-000025:mdna:131]
[same as prior period, unchanged from 0000936395-24-000008:mdna:101]

[0000936395-24-000025:mdna:132]
Overview. For the six months ended April 27, 2024, we generated $324.5 million of cash in operating activities. Net income (adjusted for non-cash charges) provided approximately $211.8 million of cash and working capital provided approximately $112.7 million of cash. For additional details, see “Cash Provided By Operating Activities” below.

[0000936395-24-000025:mdna:133]
Cash, cash equivalents and investments increased by $173.2 million during the first six months of fiscal 2024. Cash from operations was partially offset by the following: (i) cash used for stock repurchases under our stock repurchase program of $94.8 million; (ii) cash used to fund our investing activities for capital expenditures totaling $33.5 million; (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $22.4 million; and (iv) cash used for our purchase of an equity investment in a privately held technology company of $16.3 million. In addition to cash provided

[0000936395-24-000025:mdna:134]
by operating activities, proceeds from the issuance of equity under our employee stock purchase plan provided $16.9 million in cash during the six months ended April 27, 2024.

[0000936395-24-000025:mdna:135]
See Notes 11 and 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for information relating to these transactions.

[0000936395-24-000025:mdna:136]
[same as prior period, unchanged from 0000936395-24-000008:mdna:104]

[0000936395-24-000025:mdna:137]
|  | April 27,2024 |  | October 28,2023 |  | Increase |
| Cash and cash equivalents | $ | 1,091,289 |  |  | $ | 1,010,618 |  |  | $ | 80,671 |  |
| Short-term investments in marketable debt securities | 165,620 |  |  | 104,753 |  |  | 60,867 |  |
| Long-term investments in marketable debt securities | 165,960 |  |  | 134,278 |  |  | 31,682 |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,422,869 |  |  | $ | 1,249,649 |  |  | $ | 173,220 |  |

[0000936395-24-000025:mdna:138]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of April 27, 2024, totaled $1.4 billion, as well as the unused portion of the Revolving Credit Facility, to which we and certain of our subsidiaries are parties. The Revolving Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of April 27, 2024, letters of credit totaling $70.5 million were issued under the Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of April 27, 2024.

[0000936395-24-000025:mdna:139]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $216.8 million as of April 27, 2024. Approximately $93.0 million of future cash generated from these foreign subsidiaries is expected to be repatriated, with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability related to the expected repatriation amount was accrued in fiscal 2023. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized.

[0000936395-24-000025:mdna:140]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. During the first six months of fiscal 2024, we repurchased an additional $89.0 million of our common stock under the stock repurchase program, and $161.0 million remained under the current repurchase authorization as of April 27, 2024. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report as well as Item 2 of Part II of this report.

[0000936395-24-000025:mdna:141]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our Revolving Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-24-000025:mdna:142]
[same as prior period, unchanged from 0000936395-24-000008:mdna:111]

[0000936395-24-000025:mdna:143]
The following sections set forth the components of our $324.5 million of cash provided by operating activities during the first six months of fiscal 2024:

[0000936395-24-000025:mdna:144]
[same as prior period, unchanged from 0000936395-24-000008:mdna:113]

[0000936395-24-000025:mdna:145]
[same as prior period, unchanged from 0000936395-24-000008:mdna:114]

[0000936395-24-000025:mdna:146]
|  | Six Months Ended |
|  | April 27, 2024 |
| Net income | $ | 32,698 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 46,016 |  |
| Share-based compensation expense | 78,075 |  |
| Amortization of intangible assets | 20,726 |  |
| Deferred taxes | (8,946) |  |
| Provision for inventory excess and obsolescence | 23,152 |  |
| Provision for warranty | 8,629 |  |
| Other | 11,509 |  |
| Net income (adjusted for non-cash charges) | $ | 211,859 |  |

[0000936395-24-000025:mdna:147]
[same as prior period, unchanged from 0000936395-24-000008:mdna:116]

[0000936395-24-000025:mdna:148]
Working capital provided $112.7 million of cash during the period. The following table sets forth the major components of the cash provided by working capital (in thousands):

[0000936395-24-000025:mdna:149]
|  | Six Months Ended |
|  | April 27, 2024 |
| Cash provided by accounts receivable | $ | 155,107 |  |
| Cash provided by inventories | 5,346 |  |
| Cash used in prepaid expenses and other | (37,441) |  |
| Cash used in accounts payable, accruals, and other obligations | (56,064) |  |
| Cash provided by deferred revenue | 48,641 |  |
| Cash used in operating lease assets and liabilities, net | (2,899) |  |
| Total cash provided by working capital | $ | 112,690 |  |

[0000936395-24-000025:mdna:150]
[same as prior period, unchanged from 0000936395-24-000008:mdna:119]

[0000936395-24-000025:mdna:151]
•The $155.1 million of cash provided by accounts receivable during the first six months of fiscal 2024 primarily reflects increased cash collections and lower sales volume during the first half of fiscal 2024;

[0000936395-24-000025:mdna:152]
•The $5.3 million of cash provided by inventories during the first six months of fiscal 2024 primarily reflects the consumption of raw materials in excess of purchases, partially offset by increases in finished goods and work-in-process inventories from planned fulfillment of customer advance orders for which some deliveries have since been rescheduled as described in “Overview” above;

[0000936395-24-000025:mdna:153]
•The $37.4 million of cash used in prepaid expense and other during the first six months of fiscal 2024 primarily reflects increased prepaid supplier costs, higher maintenance spares, and increased non-trade receivables;

[0000936395-24-000025:mdna:154]
•The $56.1 million of cash used in accounts payable, accruals, and other obligations during the first six months of fiscal 2024 primarily reflects the timing of payments to employees under our annual cash incentive compensation plans;

[0000936395-24-000025:mdna:155]
•The $48.6 million of cash provided by deferred revenue during the first six months of fiscal 2024 represents an increase in advanced payments received on multi-year maintenance contracts from customers prior to revenue recognition; and

[0000936395-24-000025:mdna:156]
•The $2.9 million of cash used in operating lease assets and liabilities, net, during the first six months of fiscal 2024 represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-24-000025:mdna:157]
Our days sales outstanding (“DSOs”) decreased from 100 for the first six months of fiscal 2023 to 92 for the first six months of fiscal 2024. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns decreased from 1.9 for the first six months of fiscal 2023 to 1.7 for the first six months of fiscal 2024.

[0000936395-24-000025:mdna:158]
[same as prior period, unchanged from 0000936395-24-000008:mdna:127]

[0000936395-24-000025:mdna:159]
[same as prior period, unchanged from 0000936395-24-000008:mdna:128]

[0000936395-24-000025:mdna:160]
|  | Six Months Ended |
|  | April 27, 2024 |
| 2030 New Term Loan due October 28, 2030(1) | $ | 43,092 |  |
| 2030 Senior Notes due January 31, 2030(2) | 8,000 |  |
| Interest rate swaps(3) | (7,616) |  |
| Revolving Credit Facility(4) | 374 |  |
| Finance leases | 1,932 |  |
| Cash paid during period | $ | 45,782 |  |

[0000936395-24-000025:mdna:161]
(1) Interest on the 2030 New Term Loan is payable periodically based on the interest period selected for borrowing. The 2030 New Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 2.00% subject to a minimum SOFR rate of 0.00%. At the end of the second quarter of fiscal 2024, the interest rate on the 2030 New Term Loan was 7.32%.

[0000936395-24-000025:mdna:162]
[same as prior period, unchanged from 0000936395-24-000008:mdna:131]

[0000936395-24-000025:mdna:163]
[same as prior period, unchanged from 0000936395-24-000008:mdna:132]

[0000936395-24-000025:mdna:164]
(4) During the first six months of fiscal 2024, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility.

[0000936395-24-000025:mdna:165]
[same as prior period, unchanged from 0000936395-24-000008:mdna:134]

[0000936395-24-000025:mdna:166]
[same as prior period, unchanged from 0000936395-24-000008:mdna:135]

[0000936395-24-000025:mdna:167]
[same as prior period, unchanged from 0000936395-24-000008:mdna:136]

[0000936395-24-000025:mdna:168]
Purchase Order Obligations. As of April 27, 2024, we had $1.6 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule, or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable, and unconditional obligations.

[0000936395-24-000025:mdna:169]
[same as prior period, unchanged from 0000936395-24-000008:mdna:138]

[0000936395-24-000025:mdna:170]
[same as prior period, unchanged from 0000936395-24-000008:mdna:139]

[0000936395-24-000025:mdna:171]
[same as prior period, unchanged from 0000936395-24-000008:mdna:140]

[0000936395-24-000025:mdna:172]
[same as prior period, unchanged from 0000936395-24-000008:mdna:141]
