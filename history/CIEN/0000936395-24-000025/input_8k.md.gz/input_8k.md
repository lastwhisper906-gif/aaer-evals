# CIEN 8-K — 0000936395-24-000022 filed 2024-06-06

## item codes, every 8-K on or before 2024-06-06

- 2024-06-06 0000936395-24-000022 — 2.02, 9.01
- 2024-04-23 0000936395-24-000014 — 5.02
- 2024-03-26 0000936395-24-000012 — 5.01, 5.02, 9.01
- 2024-03-07 0000936395-24-000006 — 2.02, 9.01
- 2023-12-07 0000936395-23-000041 — 2.02, 9.01
- 2023-10-25 0001193125-23-263172 — 1.01, 1.02, 2.03, 9.01
- 2023-10-03 0000936395-23-000037 — 5.02, 7.01, 9.01
- 2023-08-31 0000936395-23-000030 — 2.02, 5.02, 9.01
- 2023-06-06 0000936395-23-000024 — 2.02, 9.01
- 2023-04-06 0001193125-23-093438 — 7.01, 9.01
- 2023-04-03 0000936395-23-000018 — 5.07
- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2024-06-06

- none on or before 2024-06-06

## item 2.02 — earnings release, exhibit 99.1

[0000936395-24-000022:8k_2_02:1]
EX-99.1
2
ex9912024q2earningspressre.htm
EX-99.1

[0000936395-24-000022:8k_2_02:2]
Document

[0000936395-24-000022:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-24-000022:8k_2_02:4]
Ciena Reports Fiscal Second Quarter 2024 Financial Results

[0000936395-24-000022:8k_2_02:5]
HANOVER, Md. - June 6, 2024 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal second quarter ended April 27, 2024.

[0000936395-24-000022:8k_2_02:6]
•Q2 Revenue: $910.8 million

[0000936395-24-000022:8k_2_02:7]
•Q2 Net Income (Loss) per Share: $(0.12) GAAP; $0.27 adjusted (non-GAAP)

[0000936395-24-000022:8k_2_02:8]
•Share Repurchases: Repurchased approximately 1.1 million shares of common stock for an aggregate price of $57.0 million during the quarter

[0000936395-24-000022:8k_2_02:9]
"Our fiscal second quarter performance underscores the strength in our business amid a challenging near-term environment as service providers continue to work through existing inventory," said Gary Smith, president and CEO, Ciena. “With continued robust growth in bandwidth demand, we remain focused on extending our leadership in optical as a foundation for expanding our addressable market.”

[0000936395-24-000022:8k_2_02:10]
For the fiscal second quarter 2024, Ciena reported revenue of $910.8 million as compared to $1.13 billion for the fiscal second quarter 2023.

[0000936395-24-000022:8k_2_02:11]
Ciena's GAAP net loss for the fiscal second quarter 2024 was $(16.8) million, or $(0.12) per diluted common share, which compares to a GAAP net income of $57.7 million, or $0.38 per diluted common share, for the fiscal second quarter 2023.

[0000936395-24-000022:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal second quarter 2024 was $39.4 million, or $0.27 per diluted common share, which compares to an adjusted (non-GAAP) net income of $110.4 million, or $0.74 per diluted common share, for the fiscal second quarter 2023.

[0000936395-24-000022:8k_2_02:13]
Fiscal Second Quarter 2024 Performance Summary

[0000936395-24-000022:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-24-000022:8k_2_02:15]
|  |  | GAAP Results (unaudited) |
|  |  | Q2 |  | Q2 |  | Period Change |  |  |  |  |
|  |  | FY 2024 |  | FY 2023 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 910.8 |  |  | $ | 1,132.7 |  |  | (19.6) | % |  |  |  |  |  |  |
| Gross margin |  | 42.7 | % |  | 43.1 | % |  | (0.4) | % |  |  |  |  |  |  |
| Operating expense |  | $ | 392.6 |  |  | $ | 384.9 |  |  | 2.0 | % |  |  |  |  |  |  |
| Operating margin |  | (0.4) | % |  | 9.1 | % |  | (9.5) | % |  |  |  |  |  |  |

[0000936395-24-000022:8k_2_02:16]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q2 |  | Q2 |  | Period Change |  |  |  |  |
|  |  | FY 2024 |  | FY 2023 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 910.8 |  |  | $ | 1,132.7 |  |  | (19.6) | % |  |  |  |  |  |  |
| Adj. gross margin |  | 43.5 | % |  | 43.7 | % |  | (0.2) | % |  |  |  |  |  |  |
| Adj. operating expense |  | $ | 333.9 |  |  | $ | 338.1 |  |  | (1.2) | % |  |  |  |  |  |  |
| Adj. operating margin |  | 6.8 | % |  | 13.8 | % |  | (7.0) | % |  |  |  |  |  |  |
| Adj. EBITDA |  | $ | 85.8 |  |  | $ | 180.6 |  |  | (52.5) | % |  |  |  |  |  |  |

[0000936395-24-000022:8k_2_02:17]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-24-000022:8k_2_02:18]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q2 FY 2024 |  | Q2 FY 2023 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking |  | $ | 560.2 |  |  | 61.5 |  |  | $ | 784.5 |  |  | 69.3 |  |
| Routing and Switching |  | 116.1 |  |  | 12.7 |  |  | 130.4 |  |  | 11.5 |  |
| Total Networking Platforms |  | 676.3 |  |  | 74.2 |  |  | 914.9 |  |  | 80.8 |  |
| Platform Software and Services |  | 85.4 |  |  | 9.4 |  |  | 69.4 |  |  | 6.1 |  |
| Blue Planet Automation Software and Services |  | 14.4 |  |  | 1.6 |  |  | 20.6 |  |  | 1.8 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 77.4 |  |  | 8.5 |  |  | 73.2 |  |  | 6.5 |  |
| Installation and Deployment |  | 43.8 |  |  | 4.8 |  |  | 39.5 |  |  | 3.5 |  |
| Consulting and Network Design |  | 13.5 |  |  | 1.5 |  |  | 15.1 |  |  | 1.3 |  |
| Total Global Services |  | 134.7 |  |  | 14.8 |  |  | 127.8 |  |  | 11.3 |  |
| Total |  | $ | 910.8 |  |  | 100.0 |  |  | $ | 1,132.7 |  |  | 100.0 |  |

[0000936395-24-000022:8k_2_02:19]
**  Denotes %  of total revenue

[0000936395-24-000022:8k_2_02:20]
Additional Performance Metrics for Fiscal Second Quarter 2024

[0000936395-24-000022:8k_2_02:21]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q2 FY 2024 |  | Q2 FY 2023 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 662.9 |  |  | 72.8 |  |  | $ | 794.4 |  |  | 70.1 |  |
| Europe, Middle East and Africa |  | 155.8 |  |  | 17.1 |  |  | 173.4 |  |  | 15.3 |  |
| Asia Pacific |  | 92.1 |  |  | 10.1 |  |  | 164.9 |  |  | 14.6 |  |
| Total |  | $ | 910.8 |  |  | 100.0 |  |  | $ | 1,132.7 |  |  | 100.0 |  |

[0000936395-24-000022:8k_2_02:22]
**  Denotes %  of total revenue

[0000936395-24-000022:8k_2_02:23]
•One 10%-plus customer represented a total 13.8% of revenue

[0000936395-24-000022:8k_2_02:24]
•Cash and investments totaled $1.42 billion

[0000936395-24-000022:8k_2_02:25]
•Cash flow from operations totaled $58.5 million

[0000936395-24-000022:8k_2_02:26]
•Average days' sales outstanding (DSOs) were 98

[0000936395-24-000022:8k_2_02:27]
•Accounts receivable, net balance was $840.1 million

[0000936395-24-000022:8k_2_02:28]
•Unbilled contract asset, net balance was $151.9 million

[0000936395-24-000022:8k_2_02:29]
•Inventories totaled $1.02 billion, including:

[0000936395-24-000022:8k_2_02:30]
◦Raw materials: $638.9 million

[0000936395-24-000022:8k_2_02:31]
◦Work in process: $68.2 million

[0000936395-24-000022:8k_2_02:32]
◦Finished goods: $331.3 million

[0000936395-24-000022:8k_2_02:33]
◦Deferred cost of sales: $43.7 million

[0000936395-24-000022:8k_2_02:34]
◦Reserve for excess and obsolescence: $(59.5) million

[0000936395-24-000022:8k_2_02:35]
•Product inventory turns were 1.6

[0000936395-24-000022:8k_2_02:36]
•Headcount totaled 8,627

[0000936395-24-000022:8k_2_02:37]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Second Quarter 2024 Results

[0000936395-24-000022:8k_2_02:38]
Today, Thursday, June 6, 2024, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal second quarter 2024 results.

[0000936395-24-000022:8k_2_02:39]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-24-000022:8k_2_02:40]
Notes to Investors

[0000936395-24-000022:8k_2_02:41]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "Our fiscal second quarter performance underscores the strength in our business amid a challenging near-term environment as service providers continue to work through existing inventory. With continued robust growth in bandwidth demand, we remain focused on extending our leadership in optical as a foundation for expanding our addressable market.”

[0000936395-24-000022:8k_2_02:42]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers, their spending and their businesses and markets; our ability to execute our business and growth strategies; the impact of macroeconomic conditions and global supply chain constraints or disruptions including increased supply costs and lead times; the impact of the introduction of new technologies by us or our competitors; seasonality and the timing and size of customer orders, their delivery dates and our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical tensions or events, including but not limited to the ongoing conflicts between Ukraine and Russia, and Israel and Hamas, and public health emergencies or epidemics, including the COVID-19 pandemic; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; cyberattacks, data breaches or other security incidents involving our enterprise network environment or

[0000936395-24-000022:8k_2_02:43]
our products; regulatory changes, litigation involving our intellectual property or government investigations; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including its Annual Report on Form 10-K filed with the SEC on December 15, 2023 and included in its Quarterly Report on Form 10-Q for the second quarter of fiscal 2024 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-24-000022:8k_2_02:44]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-24-000022:8k_2_02:45]
About Ciena. Ciena (NYSE: CIEN) is a global leader in networking systems, services, and software. We build the most adaptive networks in the industry, enabling customers to anticipate and meet ever-increasing digital demands. For three-plus decades, Ciena has brought our humanity to our relentless pursuit of innovation. Prioritizing collaborative relationships with our customers, partners, and communities, we create flexible, open, and sustainable networks that better serve all users—today and into the future. For updates on Ciena, follow us on LinkedIn, X, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-24-000022:8k_2_02:46]
4

[0000936395-24-000022:8k_2_02:47]
CIENA CORPORATION

[0000936395-24-000022:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-24-000022:8k_2_02:49]
(in thousands, except per share data)

[0000936395-24-000022:8k_2_02:50]
(unaudited)

[0000936395-24-000022:8k_2_02:51]
|  | Quarter Ended |  | Year Ended |
|  | April 27, |  | April 29, |  | April 27, |  | April 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 701,316 |  |  | $ | 935,330 |  |  | $ | 1,537,093 |  |  | $ | 1,813,045 |  |
| Services | 209,510 |  |  | 197,325 |  |  | 411,442 |  |  | 376,131 |  |
| Total revenue | 910,826 |  |  | 1,132,655 |  |  | 1,948,535 |  |  | 2,189,176 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 415,732 |  |  | 541,883 |  |  | 882,204 |  |  | 1,042,220 |  |
| Services | 106,433 |  |  | 103,089 |  |  | 210,708 |  |  | 203,327 |  |
| Total cost of goods sold | 522,165 |  |  | 644,972 |  |  | 1,092,912 |  |  | 1,245,547 |  |
| Gross profit | 388,661 |  |  | 487,683 |  |  | 855,623 |  |  | 943,629 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 195,380 |  |  | 189,993 |  |  | 382,649 |  |  | 371,723 |  |
| Selling and marketing | 124,071 |  |  | 125,083 |  |  | 252,229 |  |  | 248,890 |  |
| General and administrative | 49,573 |  |  | 50,939 |  |  | 104,256 |  |  | 101,835 |  |
| Significant asset impairments and restructuring costs | 15,655 |  |  | 8,153 |  |  | 20,626 |  |  | 12,451 |  |
| Amortization of intangible assets | 7,947 |  |  | 9,845 |  |  | 15,199 |  |  | 17,286 |  |
| Acquisition and integration costs | — |  |  | 857 |  |  | — |  |  | 3,415 |  |
| Total operating expenses | 392,626 |  |  | 384,870 |  |  | 774,959 |  |  | 755,600 |  |
| Income (loss) from operations | (3,965) |  |  | 102,813 |  |  | 80,664 |  |  | 188,029 |  |
| Interest and other income, net | 11,797 |  |  | 8,551 |  |  | 22,447 |  |  | 40,524 |  |
| Interest expense | (23,861) |  |  | (23,889) |  |  | (47,637) |  |  | (39,759) |  |
| Income (loss) before income taxes | (16,029) |  |  | 87,475 |  |  | 55,474 |  |  | 188,794 |  |
| Provision for income taxes | 820 |  |  | 29,821 |  |  | 22,776 |  |  | 54,899 |  |
| Net income (loss) | $ | (16,849) |  |  | $ | 57,654 |  |  | $ | 32,698 |  |  | $ | 133,895 |  |
| Net Income (Loss) per Common Share |  |  |  |  |  |  |  |
| Basic net income (loss) per common share | $ | (0.12) |  |  | $ | 0.39 |  |  | $ | 0.23 |  |  | $ | 0.90 |  |
| Diluted net income (loss) per potential common share | $ | (0.12) |  |  | $ | 0.38 |  |  | $ | 0.22 |  |  | $ | 0.89 |  |
| Weighted average basic common shares outstanding | 144,914 |  |  | 149,616 |  |  | 145,104 |  |  | 149,351 |  |
| Weighted average dilutive potential common shares outstanding 1 | 144,914 |  |  | 150,147 |  |  | 146,059 |  |  | 149,852 |  |

[0000936395-24-000022:8k_2_02:52]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 1.0 million for the first six months of fiscal 2024, and (ii) 0.5 million for both the second quarter and first six months of fiscal 2023.

[0000936395-24-000022:8k_2_02:53]
CIENA CORPORATION

[0000936395-24-000022:8k_2_02:54]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-24-000022:8k_2_02:55]
(in thousands, except share data)

[0000936395-24-000022:8k_2_02:56]
(unaudited)

[0000936395-24-000022:8k_2_02:57]
|  | April 27,2024 |  | October 28,2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,091,289 |  |  | $ | 1,010,618 |  |
| Short-term investments | 165,620 |  |  | 104,753 |  |
| Accounts receivable, net | 840,131 |  |  | 1,003,876 |  |
| Inventories, net | 1,022,615 |  |  | 1,050,838 |  |
| Prepaid expenses and other | 421,692 |  |  | 405,694 |  |
| Total current assets | 3,541,347 |  |  | 3,575,779 |  |
| Long-term investments | 165,960 |  |  | 134,278 |  |
| Equipment, building, furniture and fixtures, net | 274,353 |  |  | 280,147 |  |
| Operating lease right-of-use assets | 30,210 |  |  | 35,140 |  |
| Goodwill | 444,917 |  |  | 444,765 |  |
| Other intangible assets, net | 184,941 |  |  | 205,627 |  |
| Deferred tax asset, net | 821,879 |  |  | 809,306 |  |
| Other long-term assets | 151,196 |  |  | 116,453 |  |
| Total assets | $ | 5,614,803 |  |  | $ | 5,601,495 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 332,106 |  |  | $ | 317,828 |  |
| Accrued liabilities and other short-term obligations | 355,258 |  |  | 431,419 |  |
| Deferred revenue | 196,989 |  |  | 154,419 |  |
| Operating lease liabilities | 16,138 |  |  | 16,655 |  |
| Current portion of long-term debt | 11,700 |  |  | 11,700 |  |
| Total current liabilities | 912,191 |  |  | 932,021 |  |
| Long-term deferred revenue | 80,365 |  |  | 74,041 |  |
| Other long-term obligations | 172,839 |  |  | 170,407 |  |
| Long-term operating lease liabilities | 28,513 |  |  | 33,259 |  |
| Long-term debt, net | 1,540,639 |  |  | 1,543,406 |  |
| Total liabilities | 2,734,547 |  |  | 2,753,134 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 144,199,201 and 144,829,938 shares issued and outstanding | 1,442 |  |  | 1,448 |  |
| Additional paid-in capital | 6,245,248 |  |  | 6,262,083 |  |
| Accumulated other comprehensive loss | (21,729) |  |  | (37,767) |  |
| Accumulated deficit | (3,344,705) |  |  | (3,377,403) |  |
| Total stockholders’ equity | 2,880,256 |  |  | 2,848,361 |  |
| Total liabilities and stockholders’ equity | $ | 5,614,803 |  |  | $ | 5,601,495 |  |

[0000936395-24-000022:8k_2_02:58]
6

[0000936395-24-000022:8k_2_02:59]
CIENA CORPORATION

[0000936395-24-000022:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-24-000022:8k_2_02:61]
(in thousands) (unaudited)

[0000936395-24-000022:8k_2_02:62]
|  | Six Months Ended |
|  | April 27, |  | April 29, |
|  | 2024 |  | 2023 |
| Cash flows provided by (used in) operating activities: |  |  |  |
| Net income | $ | 32,698 |  |  | $ | 133,895 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 46,016 |  |  | 45,903 |  |
| Share-based compensation expense | 78,075 |  |  | 62,372 |  |
| Amortization of intangible assets | 20,726 |  |  | 23,600 |  |
| Deferred taxes | (8,946) |  |  | (2,134) |  |
| Provision for inventory excess and obsolescence | 23,152 |  |  | 12,691 |  |
| Provision for warranty | 8,629 |  |  | 13,577 |  |
| Gain on equity investments, net | — |  |  | (26,455) |  |
| Other | 11,509 |  |  | 11,331 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 155,107 |  |  | (116,914) |  |
| Inventories | 5,346 |  |  | (162,143) |  |
| Prepaid expenses and other | (37,441) |  |  | (41,511) |  |
| Operating lease right-of-use assets | 6,111 |  |  | 7,644 |  |
| Accounts payable, accruals and other obligations | (56,064) |  |  | (55,754) |  |
| Deferred revenue | 48,641 |  |  | 68,818 |  |
| Short and long-term operating lease liabilities | (9,010) |  |  | (10,748) |  |
| Net cash provided by (used in) operating activities | 324,549 |  |  | (35,828) |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (33,500) |  |  | (58,034) |  |
| Purchases of investments | (171,131) |  |  | (106,245) |  |
| Proceeds from sales and maturities of investments | 83,013 |  |  | 123,251 |  |
| Settlement of foreign currency forward contracts, net | (828) |  |  | (6,194) |  |
| Purchase of equity investments | (16,256) |  |  | — |  |
| Acquisition of business, net of cash acquired | — |  |  | (230,048) |  |
| Net cash used in investing activities | (138,702) |  |  | (277,270) |  |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Proceeds from issuance of term loan, net | — |  |  | 497,500 |  |
| Payment of long term debt | (2,925) |  |  | (3,465) |  |
| Payment of debt issuance costs | (2,554) |  |  | (5,230) |  |
| Payment of finance lease obligations | (1,989) |  |  | (1,864) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (22,428) |  |  | (22,022) |  |
| Repurchases of common stock - repurchase program, net | (94,817) |  |  | — |  |
| Proceeds from issuance of common stock | 16,876 |  |  | 14,656 |  |
| Net cash provided by (used in) financing activities | (107,837) |  |  | 479,575 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 2,659 |  |  | 6,867 |  |
| Net increase in cash, cash equivalents and restricted cash | 80,669 |  |  | 173,344 |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,010,786 |  |  | 994,378 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,091,455 |  |  | $ | 1,167,722 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest, net | $ | 45,782 |  |  | $ | 37,514 |  |
| Cash paid during the period for income taxes, net | $ | 29,193 |  |  | $ | 24,218 |  |
| Operating lease payments | $ | 9,964 |  |  | $ | 11,689 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 6,365 |  |  | $ | 4,618 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 3,859 |  |  | $ | — |  |
| Operating right-of-use assets subject to lease liability | $ | 3,639 |  |  | $ | 6,177 |  |
| Gain on equity investments, net | $ | — |  |  | $ | 26,455 |  |

[0000936395-24-000022:8k_2_02:63]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | April 27, |  | April 29, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 388,661 |  |  | $ | 487,683 |  |  |  |  |  |
| Share-based compensation-products |  | 1,760 |  |  | 1,155 |  |  |  |  |  |
| Share-based compensation-services |  | 3,344 |  |  | 2,659 |  |  |  |  |  |
| Amortization of intangible assets |  | 2,763 |  |  | 3,431 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 7,867 |  |  | 7,245 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit |  | $ | 396,528 |  |  | $ | 494,928 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.5 | % |  | 43.7 | % |  |  |  |  |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 392,626 |  |  | $ | 384,870 |  |  |  |  |  |
| Share-based compensation-research and development |  | 14,066 |  |  | 10,731 |  |  |  |  |  |
| Share-based compensation-sales and marketing |  | 11,166 |  |  | 8,755 |  |  |  |  |  |
| Share-based compensation-general and administrative |  | 9,875 |  |  | 8,468 |  |  |  |  |  |
| Significant asset impairments and restructuring costs |  | 15,655 |  |  | 8,153 |  |  |  |  |  |
| Amortization of intangible assets |  | 7,947 |  |  | 9,845 |  |  |  |  |  |
| Acquisition and integration costs |  | — |  |  | 857 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 58,709 |  |  | 46,809 |  |  |  |  |  |
| Adjusted (non-GAAP) operating expense |  | $ | 333,917 |  |  | $ | 338,061 |  |  |  |  |  |
| Income (Loss) from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income (loss) from operations |  | $ | (3,965) |  |  | $ | 102,813 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 7,867 |  |  | 7,245 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 58,709 |  |  | 46,809 |  |  |  |  |  |
| Total adjustments related to income (loss) from operations |  | 66,576 |  |  | 54,054 |  |  |  |  |  |
| Adjusted (non-GAAP) income from operations |  | $ | 62,611 |  |  | $ | 156,867 |  |  |  |  |  |
| Adjusted (non-GAAP) operating margin percentage |  | 6.8 | % |  | 13.8 | % |  |  |  |  |
| Net Income (Loss) Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | (16,849) |  |  | $ | 57,654 |  |  |  |  |  |
| Exclude GAAP provision for income taxes |  | 820 |  |  | 29,821 |  |  |  |  |  |
| Income (loss) before income taxes |  | (16,029) |  |  | 87,475 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 66,576 |  |  | 54,054 |  |  |  |  |  |
| Adjusted income before income taxes |  | 50,547 |  |  | 141,529 |  |  |  |  |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 11,120 |  |  | 31,136 |  |  |  |  |  |
| Adjusted (non-GAAP) net income |  | $ | 39,427 |  |  | $ | 110,393 |  |  |  |  |  |
| Weighted average basic common shares outstanding |  | 144,914 |  | 149,616 |  |  |  |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 146,268 |  | 150,147 |  |  |  |  |

[0000936395-24-000022:8k_2_02:64]
8

[0000936395-24-000022:8k_2_02:65]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | April 27, |  | April 29, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Net Income (Loss) per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income (loss) per potential common share |  | $ | (0.12) |  |  | $ | 0.38 |  |  |  |  |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.27 |  |  | $ | 0.74 |  |  |  |  |  |

[0000936395-24-000022:8k_2_02:66]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 1.4 million and 1.0 million for the second quarter and first six months of fiscal 2024, respectively; and (ii) 0.5 million for both the second quarter and first six months of fiscal 2023.

[0000936395-24-000022:8k_2_02:67]
9

[0000936395-24-000022:8k_2_02:68]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | April 27, |  | April 29, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (loss) (GAAP) |  | $ | (16,849) |  |  | $ | 57,654 |  |  |  |  |  |
| Add: Interest expense |  | 23,861 |  |  | 23,889 |  |  |  |  |  |
| Less: Interest and other income, net |  | 11,797 |  |  | 8,551 |  |  |  |  |  |
| Add: Provision for income taxes |  | 820 |  |  | 29,821 |  |  |  |  |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 23,208 |  |  | 23,695 |  |  |  |  |  |
| Add: Amortization of intangible assets |  | 10,710 |  |  | 13,275 |  |  |  |  |  |
| EBITDA |  | $ | 29,953 |  |  | $ | 139,783 |  |  |  |  |  |
| Add: Share-based compensation expense |  | 40,211 |  |  | 31,768 |  |  |  |  |  |
| Add: Significant asset impairments and restructuring costs |  | 15,655 |  |  | 8,153 |  |  |  |  |  |
| Add: Acquisition and integration costs |  | — |  |  | 857 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 85,819 |  |  | $ | 180,561 |  |  |  |  |  |

[0000936395-24-000022:8k_2_02:69]
* * *

[0000936395-24-000022:8k_2_02:70]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-24-000022:8k_2_02:71]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-24-000022:8k_2_02:72]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities, the redesign of business processes and restructuring certain real estate facilities.

[0000936395-24-000022:8k_2_02:73]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over an expected useful life.

[0000936395-24-000022:8k_2_02:74]
•Acquisition and integration costs - primarily consist of financial, legal and accounting advisors' costs and employment-related costs related to Ciena's acquisitions in fiscal 2023.

[0000936395-24-000022:8k_2_02:75]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 22.0% for both the fiscal second quarter 2024 and the fiscal second quarter 2023. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
