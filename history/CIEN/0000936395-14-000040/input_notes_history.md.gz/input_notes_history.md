# CIEN note change history — 0000936395-14-000021 → 0000936395-14-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-06-11):
[0000936395-14-000040:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of C$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Ciena anticipates receiving disbursements, approximating C$5.0 million per fiscal year, over the period above. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of April 30, 2014, Ciena has recorded a C$20.0 million benefit to date as a reduction in research and development expenses, of which C$3.6 million was recorded in the first six months of fiscal 2014. As of April 30, 2014, amounts receivable from this grant were C$3.6 million.
  (was, 2014-03-07, similarity 0.9521):
[0000936395-14-000021:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of C$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Ciena anticipates receiving disbursements, approximating C$5.0 million per fiscal year, over the period above. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2014, Ciena has recorded a C$17.8 million benefit to date as a reduction in research and development expenses, of which C$1.4 million was recorded in the first three months of fiscal 2014.  As of January 31, 2014, amounts receivable from this grant were C$1.4 million.

- changed (2014-06-11):
[0000936395-14-000040:note_history:2]
As of October 31, 2013 and April 30, 2014, Ciena had accrued liabilities of $0.4 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 related to income taxes. This contingency has been reported as a component of other long-term liabilities. During February 2014, Ciena received a final audit assessment notice from the India tax authorities with respect to this matter. Ciena has filed an appeal citing deficiencies in this assessment. Although Ciena estimates that it could be exposed to possible losses of up to $2.9 million, it has not accrued a liability of such amount as of April 30, 2014. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to this assessment. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.
  (was, 2014-03-07, similarity 0.9781):
[0000936395-14-000021:note_history:2]
As of October 31, 2013 and January 31, 2014, Ciena had accrued liabilities of $0.4 million and $0.4 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 related to income taxes. This contingency has been reported as a component of other long-term liabilities. During February 2014, Ciena received a final audit assessment notice from the India tax authorities with respect to this matter. Ciena has filed an appeal citing deficiencies in this assessment. Although Ciena estimates that it could be exposed to possible losses of up to $3.5 million, it has not accrued a liability of such amount as of January 31, 2014. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to this assessment. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-06-11):
[0000936395-14-000040:note_history:3]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October of each year. Fiscal 2014 and 2013 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.
  (was, 2014-03-07, similarity 0.9796):
[0000936395-14-000021:note_history:3]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October of each year. Fiscal 2014 and 2013 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and each fiscal quarter is described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-06-11):
[0000936395-14-000040:note_history:4]
accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, share-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.
  (was, 2014-03-07, similarity 0.9993):
[0000936395-14-000021:note_history:4]
accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

- changed (2014-06-11):
[0000936395-14-000040:note_history:5]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and its intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.
  (was, 2014-03-07, similarity 0.9683):
[0000936395-14-000021:note_history:5]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses when it determines that declines in the fair value of its investments, below their cost basis, are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and its intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments.  All others are considered long-term investments.

- changed (2014-06-11):
[0000936395-14-000040:note_history:6]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment, furniture and fixtures, and the shorter of useful life or lease term for leasehold improvements.
  (was, 2014-03-07, similarity 0.9982):
[0000936395-14-000021:note_history:6]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment, furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

- changed (2014-06-11):
[0000936395-14-000040:note_history:7]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are ultimately expected to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon its determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 16 below.
  (was, 2014-03-07, similarity 0.9997):
[0000936395-14-000021:note_history:7]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are ultimately expected to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon its determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. Ciena uses the straight-line method to record expense for shared-based awards with only service-based vesting. See Note 16 below.

- added (2014-06-11):
[0000936395-14-000040:note_history:8]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and will be used to fund foreign operations, capital expenditures and any expansion requirements.

- changed (2014-06-11):
[0000936395-14-000040:note_history:9]
Some of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects a net loss on foreign currency re-measurement and exchange rate changes of $3.0 million for the six months ended April 30, 2013 and a net gain of $5.3 million for the six months ended April 30, 2014.
  (was, 2014-03-07, similarity 0.9381):
[0000936395-14-000021:note_history:9]
Some of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects a net loss on foreign currency re-measurement and exchange rate changes of $0.2 million and $5.9 million for the three months ended January 31, 2013 and 2014, respectively.

- changed (2014-06-11):
[0000936395-14-000040:note_history:10]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") include a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature is recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects an increase in fair value of $0.4 million for the six months ended April 30, 2013 and a reduction in fair value of $2.6 million for the six months ended April 30, 2014.
  (was, 2014-03-07, similarity 0.9076):
[0000936395-14-000021:note_history:10]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") include a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature is recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations.  Interest and other income (loss), net reflects an increase in fair value of $0.3 million for the three months ended January 31, 2013 and a reduction in fair value of $1.1 million for the three months ended January 31, 2014.

- changed (2014-06-11):
[0000936395-14-000040:note_history:11]
From time to time, Ciena uses foreign currency forwards to hedge certain balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects losses of $0.1 million and $10.2 million related to foreign currency forward contracts for the six months ended April 30, 2013 and 2014, respectively. See Note 12 below.
  (was, 2014-03-07, similarity 0.9373):
[0000936395-14-000021:note_history:11]
From time to time, Ciena uses foreign currency forwards to hedge certain balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects a loss of $0.2 million and a gain of $1.4 million related to foreign currency forward contracts for the three months ended January 31, 2013 and 2014, respectively. See Note 12 below.

- added (2014-06-11):
[0000936395-14-000040:note_history:12]
Ciena records derivative instruments in the Condensed Consolidated Statement of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

- changed (2014-06-11):
[0000936395-14-000040:note_history:13]
In February 2013, the Financial Accounting Standards Board ("FASB") issued an accounting standard update to require reclassification adjustments from other comprehensive income to be presented either in the financial statements or in the notes to the financial statements. This accounting standard update was effective for Ciena beginning in the first quarter of fiscal 2014. Ciena has determined that reclassifications from other comprehensive income to net income are immaterial for separate financial statement presentation.
  (was, 2014-03-07, similarity 0.999):
[0000936395-14-000021:note_history:13]
In February 2013, the Financial Accounting Standards Board ("FASB") issued an accounting standards update to require reclassification adjustments from other comprehensive income to be presented either in the financial statements or in the notes to the financial statements. This accounting standard update was effective for Ciena beginning in the first quarter of fiscal 2014. Ciena has determined that reclassifications from other comprehensive income to net income are immaterial for separate financial statement presentation.

- added (2014-06-11):
[0000936395-14-000040:note_history:14]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606) which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its condensed consolidated financial statements.

- removed (2014-06-11):
[0000936395-14-000021:note_history:15]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S. and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and will be used to fund foreign operations, capital expenditures and any expansion requirements.


## cien:ConvertibleNotesPayableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-06-11):
[0000936395-14-000040:note_history:16]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 Notes ("2020 Notes") were as follows as of April 30, 2014:
  (was, 2014-03-07, similarity 0.9499):
[0000936395-14-000021:note_history:16]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 Notes ("2020 Notes") were as follows as of January 31, 2014

- changed (2014-06-11):
[0000936395-14-000040:note_history:17]
|  |  | April 30, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | 187,647 |  |  | 214,805 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 448,875 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 176,641 |  |  | 246,797 |  |
|  |  | $ | 1,214,288 |  |  | $ | 1,404,852 |  |
  (was, 2014-03-07, similarity 0.9368):
[0000936395-14-000021:note_history:17]
|  |  | January 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | 187,690 |  |  | 241,055 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 511,250 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 499,406 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 175,456 |  |  | 271,941 |  |
|  |  | $ | 1,213,146 |  |  | $ | 1,523,652 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-06-11):
[0000936395-14-000040:note_history:18]
|  | April 30, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 60,042 |  |  | $ | 16 |  |  | — |  |  | $ | 60,058 |  |
| Included in long-term investments | 14,997 |  |  | 45 |  |  | — |  |  | 15,042 |  |
|  | $ | 75,039 |  |  | $ | 61 |  |  | $ | — |  |  | $ | 75,100 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,991 |  |  | — |  |  | — |  |  | 29,991 |  |
|  | $ | 29,991 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,991 |  |
  (was, 2014-03-07, similarity 0.9883):
[0000936395-14-000021:note_history:18]
|  | January 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 59,993 |  |  | $ | 9 |  |  | — |  |  | $ | 60,002 |  |
| Included in long-term investments | 14,997 |  |  | 41 |  |  | — |  |  | 15,038 |  |
|  | $ | 74,990 |  |  | $ | 50 |  |  | $ | — |  |  | $ | 75,040 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 34,991 |  |  | — |  |  | — |  |  | 34,991 |  |
|  | $ | 34,991 |  |  | $ | — |  |  | $ | — |  |  | $ | 34,991 |  |

- changed (2014-06-11):
[0000936395-14-000040:note_history:19]
The following table summarizes final legal maturities of debt investments at April 30, 2014 (in thousands):
  (was, 2014-03-07, similarity 0.9612):
[0000936395-14-000021:note_history:19]
The following table summarizes final legal maturities of debt investments at January 31, 2014 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-06-11):
[0000936395-14-000040:note_history:20]
|  |  | April 30, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | 187,647 |  |  | 214,805 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 448,875 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 176,641 |  |  | 246,797 |  |
|  |  | $ | 1,214,288 |  |  | $ | 1,404,852 |  |
  (was, 2014-03-07, similarity 0.9368):
[0000936395-14-000021:note_history:20]
|  |  | January 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | 187,690 |  |  | 241,055 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 511,250 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 499,406 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 175,456 |  |  | 271,941 |  |
|  |  | $ | 1,213,146 |  |  | $ | 1,523,652 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-06-11):
[0000936395-14-000040:note_history:21]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 Notes ("2020 Notes") were as follows as of April 30, 2014:
  (was, 2014-03-07, similarity 0.9499):
[0000936395-14-000021:note_history:21]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 Notes ("2020 Notes") were as follows as of January 31, 2014
