# CIEN notes — 0000936395-14-000040


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-14-000040:notes:1]
[same as prior period, unchanged from 0000936395-14-000021:notes:1]

[0000936395-14-000040:notes:2]
[same as prior period, unchanged from 0000936395-14-000021:notes:2]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-14-000040:notes:3]
[same as prior period, unchanged from 0000936395-14-000021:notes:3]

[0000936395-14-000040:notes:4]
[same as prior period, unchanged from 0000936395-14-000021:notes:4]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-14-000040:notes:5]
COMMITMENTS AND CONTINGENCIES

[0000936395-14-000040:notes:6]
Ontario Grant

[0000936395-14-000040:notes:7]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of C$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Ciena anticipates receiving disbursements, approximating C$5.0 million per fiscal year, over the period above. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of April 30, 2014, Ciena has recorded a C$20.0 million benefit to date as a reduction in research and development expenses, of which C$3.6 million was recorded in the first six months of fiscal 2014. As of April 30, 2014, amounts receivable from this grant were C$3.6 million.

[0000936395-14-000040:notes:8]
Foreign Tax Contingencies

[0000936395-14-000040:notes:9]
As of October 31, 2013 and April 30, 2014, Ciena had accrued liabilities of $0.4 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 related to income taxes. This contingency has been reported as a component of other long-term liabilities. During February 2014, Ciena received a final audit assessment notice from the India tax authorities with respect to this matter. Ciena has filed an appeal citing deficiencies in this assessment. Although Ciena estimates that it could be exposed to possible losses of up to $2.9 million, it has not accrued a liability of such amount as of April 30, 2014. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to this assessment. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.

[0000936395-14-000040:notes:10]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-14-000040:notes:11]
Litigation

[0000936395-14-000040:notes:12]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-14-000040:notes:13]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-14-000040:notes:14]
Loss Contingencies

[0000936395-14-000040:notes:15]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-14-000040:notes:16]
[same as prior period, unchanged from 0000936395-14-000021:notes:16]

[0000936395-14-000040:notes:17]
[same as prior period, unchanged from 0000936395-14-000021:notes:17]


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-14-000040:notes:18]
[same as prior period, unchanged from 0000936395-14-000021:notes:18]

[0000936395-14-000040:notes:19]
|  | October 31, 2013 |  | April 30, 2014 |
| Products | $ | 36,671 |  |  | $ | 64,326 |  |
| Services | 75,499 |  |  | 77,967 |  |
|  | 112,170 |  |  | 142,293 |  |
| Less current portion | (88,550 | ) |  | (118,473 | ) |
| Long-term deferred revenue | $ | 23,620 |  |  | $ | 23,820 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-14-000040:notes:20]
[same as prior period, unchanged from 0000936395-14-000021:notes:20]

[0000936395-14-000040:notes:21]
As of April 30, 2014, Ciena had forward contracts to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which expense principally relates to research and development activities. These derivative contracts have been designated as cash flow hedges. During the first six months of fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell Brazilian Real and buy an equivalent U.S. Dollar amount and forward contracts to sell U.S. Dollars and buy an equivalent amount of Canadian Dollars. These derivative contracts have not been designated as hedges. Ciena's foreign currency forward contracts are immaterial for separate financial statement presentation.


## us-gaap:DerivativesPolicyTextBlock

[0000936395-14-000040:notes:22]
[same as prior period, unchanged from 0000936395-14-000021:notes:22]

[0000936395-14-000040:notes:23]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") include a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature is recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects an increase in fair value of $0.4 million for the six months ended April 30, 2013 and a reduction in fair value of $2.6 million for the six months ended April 30, 2014.

[0000936395-14-000040:notes:24]
[same as prior period, unchanged from 0000936395-14-000021:notes:24]

[0000936395-14-000040:notes:25]
From time to time, Ciena uses foreign currency forwards to hedge certain balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-14-000040:notes:26]
[same as prior period, unchanged from 0000936395-14-000021:notes:26]

[0000936395-14-000040:notes:27]
[same as prior period, unchanged from 0000936395-14-000021:notes:27]

[0000936395-14-000040:notes:28]
[same as prior period, unchanged from 0000936395-14-000021:notes:28]

[0000936395-14-000040:notes:29]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors, and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. Pursuant to Board and stockholder approval, effective April 10, 2014, Ciena amended its 2008 Plan to increase the number of shares available for issuance by 6.6 million shares. The total number of shares authorized for issuance under the 2008 Plan is 25.1 million shares. As of April 30, 2014, approximately 9.2 million shares remained available for issuance under the 2008 Plan.

[0000936395-14-000040:notes:30]
[same as prior period, unchanged from 0000936395-14-000021:notes:30]

[0000936395-14-000040:notes:31]
Outstanding stock option awards to employees are generally subject to service-based vesting restrictions and vest incrementally over a four-year period. As of April 30, 2014, all outstanding options have completed their service-based vesting conditions and are fully vested. The following table is a summary of Ciena’s stock option activity for the period indicated (shares in thousands):

[0000936395-14-000040:notes:32]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2013 | 2,102 |  |  | $ | 27.46 |  |
| Exercised | (108 | ) |  | 17.82 |  |
| Canceled | (379 | ) |  | 42.39 |  |
| Balance at April 30, 2014 | 1,615 |  |  | $ | 24.60 |  |

[0000936395-14-000040:notes:33]
The total intrinsic value of options exercised during the first six months of fiscal 2013 and fiscal 2014 was $0.3 million and $0.7 million, respectively. Ciena did not grant any stock options during the first six months of fiscal 2013 or fiscal 2014.

[0000936395-14-000040:notes:34]
The following table summarizes information with respect to stock options outstanding at April 30, 2014, based on Ciena’s closing stock price on the last trading day of Ciena’s second fiscal quarter of 2014 (shares and intrinsic value in thousands):

[0000936395-14-000040:notes:35]
|  |  |  |  |  |  | Options Outstanding and Vested at |
|  |  |  |  |  |  | April 30, 2014 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 0.94 |  |  | — |  |  | $ | 16.31 |  |  | 174 |  |  | 3.66 |  | $ | 8.25 |  |  | $ | 1,929 |  |
| $ | 16.52 |  |  | — |  |  | $ | 17.29 |  |  | 264 |  |  | 1.17 |  | 16.64 |  |  | 710 |  |
| $ | 17.43 |  |  | — |  |  | $ | 24.50 |  |  | 353 |  |  | 1.02 |  | 20.45 |  |  | 242 |  |
| $ | 24.69 |  |  | — |  |  | $ | 28.28 |  |  | 335 |  |  | 2.50 |  | 27.01 |  |  | — |  |
| $ | 28.61 |  |  | — |  |  | $ | 31.43 |  |  | 103 |  |  | 3.30 |  | 29.80 |  |  | — |  |
| $ | 31.71 |  |  | — |  |  | $ | 32.55 |  |  | 21 |  |  | 3.22 |  | 31.92 |  |  | — |  |
| $ | 33.00 |  |  | — |  |  | $ | 37.10 |  |  | 249 |  |  | 3.55 |  | 35.23 |  |  | — |  |
| $ | 37.45 |  |  | — |  |  | $ | 46.44 |  |  | 116 |  |  | 3.28 |  | 44.30 |  |  | — |  |
| $ | 0.94 |  |  | — |  |  | $ | 46.44 |  |  | 1,615 |  |  | 2.36 |  | $ | 24.60 |  |  | $ | 2,881 |  |

[0000936395-14-000040:notes:36]
[same as prior period, unchanged from 0000936395-14-000021:notes:36]

[0000936395-14-000040:notes:37]
[same as prior period, unchanged from 0000936395-14-000021:notes:37]

[0000936395-14-000040:notes:38]
[same as prior period, unchanged from 0000936395-14-000021:notes:38]

[0000936395-14-000040:notes:39]
[same as prior period, unchanged from 0000936395-14-000021:notes:39]

[0000936395-14-000040:notes:40]
[same as prior period, unchanged from 0000936395-14-000021:notes:40]

[0000936395-14-000040:notes:41]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2013 | 4,419 |  |  | $ | 15.33 |  |  | $ | 102,745 |  |
| Granted | 1,745 |  |  |  |  |  |
| Vested | (1,252 | ) |  |  |  |  |
| Canceled or forfeited | (99 | ) |  |  |  |  |
| Balance at April 30, 2014 | 4,813 |  |  | $ | 17.67 |  |  | $ | 93,052 |  |

[0000936395-14-000040:notes:42]
The total fair value of restricted stock units that vested and were converted into common stock during the first six months of fiscal 2013 and fiscal 2014 was $15.9 million and $29.1 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first six months of fiscal 2013 and fiscal 2014 was $15.75 and $21.95 respectively.

[0000936395-14-000040:notes:43]
[same as prior period, unchanged from 0000936395-14-000021:notes:43]

[0000936395-14-000040:notes:44]
[same as prior period, unchanged from 0000936395-14-000021:notes:44]

[0000936395-14-000040:notes:45]
Share-based expense for performance-based restricted stock unit awards, net of estimated forfeitures, is recognized ratably over the performance period based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal, and, to the extent previously recognized, compensation cost is reversed.

[0000936395-14-000040:notes:46]
[same as prior period, unchanged from 0000936395-14-000021:notes:46]

[0000936395-14-000040:notes:47]
[same as prior period, unchanged from 0000936395-14-000021:notes:47]

[0000936395-14-000040:notes:48]
[same as prior period, unchanged from 0000936395-14-000021:notes:48]

[0000936395-14-000040:notes:49]
During the first six months of fiscal 2014, Ciena issued 0.5 million shares under the ESPP. At April 30, 2014, 7.3 million shares remained available for issuance under the ESPP.

[0000936395-14-000040:notes:50]
[same as prior period, unchanged from 0000936395-14-000021:notes:50]

[0000936395-14-000040:notes:51]
[same as prior period, unchanged from 0000936395-14-000021:notes:51]

[0000936395-14-000040:notes:52]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Product costs | $ | 686 |  |  | $ | 741 |  |  | $ | 1,247 |  |  | $ | 1,247 |  |
| Service costs | 435 |  |  | 568 |  |  | 862 |  |  | 1,148 |  |
| Share-based compensation expense included in cost of sales | 1,121 |  |  | 1,309 |  |  | 2,109 |  |  | 2,395 |  |
| Research and development | 2,204 |  |  | 2,782 |  |  | 4,237 |  |  | 5,354 |  |
| Sales and marketing | 3,382 |  |  | 4,246 |  |  | 6,125 |  |  | 8,309 |  |
| General and administrative | 3,144 |  |  | 3,661 |  |  | 5,700 |  |  | 7,167 |  |
| Share-based compensation expense included in operating expense | 8,730 |  |  | 10,689 |  |  | 16,062 |  |  | 20,830 |  |
| Share-based compensation expense capitalized in inventory, net | (24 | ) |  | 53 |  |  | (24 | ) |  | 218 |  |
| Total share-based compensation | $ | 9,827 |  |  | $ | 12,051 |  |  | $ | 18,147 |  |  | $ | 23,443 |  |

[0000936395-14-000040:notes:53]
As of April 30, 2014, total unrecognized share-based compensation expense related to unvested restricted stock units,was $72.4 million, and this expense is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-14-000040:notes:54]
[same as prior period, unchanged from 0000936395-14-000021:notes:54]

[0000936395-14-000040:notes:55]
[same as prior period, unchanged from 0000936395-14-000021:notes:55]


## us-gaap:EarningsPerShareTextBlock

[0000936395-14-000040:notes:56]
[same as prior period, unchanged from 0000936395-14-000021:notes:56]

[0000936395-14-000040:notes:57]
[same as prior period, unchanged from 0000936395-14-000021:notes:57]

[0000936395-14-000040:notes:58]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Numerator | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Net loss | $ | (27,079 | ) |  | $ | (10,158 | ) |  | $ | (74,403 | ) |  | $ | (26,094 | ) |

[0000936395-14-000040:notes:59]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Denominator | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Weighted average basic common shares outstanding | 101,913 |  |  | 105,451 |  |  | 101,560 |  |  | 104,977 |  |
| Weighted average dilutive potential common shares outstanding | 101,913 |  |  | 105,451 |  |  | 101,560 |  |  | 104,977 |  |

[0000936395-14-000040:notes:60]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| EPS | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Basic EPS | $ | (0.27 | ) |  | $ | (0.10 | ) |  | $ | (0.73 | ) |  | $ | (0.25 | ) |
| Diluted EPS | $ | (0.27 | ) |  | $ | (0.10 | ) |  | $ | (0.73 | ) |  | $ | (0.25 | ) |

[0000936395-14-000040:notes:61]
[same as prior period, unchanged from 0000936395-14-000021:notes:61]

[0000936395-14-000040:notes:62]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Shares underlying stock options and restricted stock units | 4,267 |  |  | 3,256 |  |  | 4,366 |  |  | 3,430 |  |
| 0.25% Convertible Senior Notes due May 1, 2013 | 5,288 |  |  | — |  |  | 5,379 |  |  | — |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | 9,198 |  |  | 9,198 |  |  | 11,891 |  |  | 9,198 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | 13,108 |  |  | 13,108 |  |  | 13,108 |  |  | 13,108 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,356 |  |  | 17,356 |  |  | 17,356 |  |  | 17,356 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |  | 6,505 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 58,415 |  |  | 52,116 |  |  | 58,605 |  |  | 52,290 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-14-000040:notes:63]
[same as prior period, unchanged from 0000936395-14-000021:notes:63]

[0000936395-14-000040:notes:64]
|  | April 30, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 226,925 |  |  | $ | — |  |  | $ | — |  |  | $ | 226,925 |  |
| U.S. government obligations | — |  |  | 75,100 |  |  | — |  |  | 75,100 |  |
| Commercial paper | — |  |  | 49,989 |  |  | — |  |  | 49,989 |  |
| Foreign currency forward contracts | — |  |  | 296 |  |  | — |  |  | 296 |  |
| Embedded redemption feature | — |  |  | — |  |  | 190 |  |  | 190 |  |
| Total assets measured at fair value | $ | 226,925 |  |  | $ | 125,385 |  |  | $ | 190 |  |  | $ | 352,500 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,548 |  |  | $ | — |  |  | $ | 3,548 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 3,548 |  |  | $ | — |  |  | $ | 3,548 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0000936395-14-000040:notes:65]
[same as prior period, unchanged from 0000936395-14-000021:notes:65]

[0000936395-14-000040:notes:66]
|  | Level 3 |
| Balance at October 31, 2013 | $ | 2,740 |  |
| Issuances | — |  |
| Settlements | — |  |
| Changes in unrealized gain (loss) | (2,550 | ) |
| Transfers into Level 3 | — |  |
| Transfers out of Level 3 | — |  |
| Balance at April 30, 2014 | $ | 190 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-14-000040:notes:67]
[same as prior period, unchanged from 0000936395-14-000021:notes:67]

[0000936395-14-000040:notes:68]
|  | April 30, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 226,782 |  |  | $ | 19,998 |  |  | $ | — |  |  | $ | 246,780 |  |
| Short-term investments | — |  |  | 90,049 |  |  | — |  |  | 90,049 |  |
| Prepaid expenses and other | 52 |  |  | 296 |  |  | 190 |  |  | 538 |  |
| Long-term investments | — |  |  | 15,042 |  |  | — |  |  | 15,042 |  |
| Other long-term assets | 91 |  |  | — |  |  | — |  |  | 91 |  |
| Total assets measured at fair value | $ | 226,925 |  |  | $ | 125,385 |  |  | $ | 190 |  |  | $ | 352,500 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 3,548 |  |  | $ | — |  |  | $ | 3,548 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 3,548 |  |  | $ | — |  |  | $ | 3,548 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-14-000040:notes:69]
[same as prior period, unchanged from 0000936395-14-000021:notes:69]

[0000936395-14-000040:notes:70]
[same as prior period, unchanged from 0000936395-14-000021:notes:70]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-14-000040:notes:71]
[same as prior period, unchanged from 0000936395-14-000021:notes:71]

[0000936395-14-000040:notes:72]
Some of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-14-000040:notes:73]
[same as prior period, unchanged from 0000936395-14-000021:notes:73]

[0000936395-14-000040:notes:74]
[same as prior period, unchanged from 0000936395-14-000021:notes:74]


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-14-000040:notes:75]
[same as prior period, unchanged from 0000936395-14-000021:notes:75]

[0000936395-14-000040:notes:76]
[same as prior period, unchanged from 0000936395-14-000021:notes:76]

[0000936395-14-000040:notes:77]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2008 through 2012 and in Canada for 2010 through 2012. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2010), United Kingdom (2012), Canada (2009) and India (2008). However, limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense. All of the uncertain tax positions, if recognized, would decrease the effective income tax rate.

[0000936395-14-000040:notes:78]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and will be used to fund foreign operations, capital expenditures and any expansion requirements.

[0000936395-14-000040:notes:79]
[same as prior period, unchanged from 0000936395-14-000021:notes:79]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-14-000040:notes:80]
[same as prior period, unchanged from 0000936395-14-000021:notes:80]

[0000936395-14-000040:notes:81]
[same as prior period, unchanged from 0000936395-14-000021:notes:81]

[0000936395-14-000040:notes:82]
|  | October 31, 2013 |  | April 30, 2014 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 417,833 |  |  | $ | (321,645 | ) |  | $ | 96,188 |  |  | $ | 417,833 |  |  | $ | (338,428 | ) |  | $ | 79,405 |  |
| Patents and licenses | 46,538 |  |  | (45,744 | ) |  | 794 |  |  | 46,538 |  |  | (45,826 | ) |  | 712 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 323,573 |  |  | (234,727 | ) |  | 88,846 |  |  | 323,573 |  |  | (248,573 | ) |  | 75,000 |  |
| Total other intangible assets | $ | 787,944 |  |  | $ | (602,116 | ) |  | $ | 185,828 |  |  | $ | 787,944 |  |  | $ | (632,827 | ) |  | $ | 155,117 |  |

[0000936395-14-000040:notes:83]
The amortization of finite-lived other intangible assets was $35.7 million and $30.7 million for the first six months of fiscal 2013 and 2014, respectively. Expected future amortization of finite-lived other intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-14-000040:notes:84]
| Period ended October 31, |  |
| 2014 (remaining six months) | $ | 26,439 |  |
| 2015 | 52,879 |  |
| 2016 | 52,879 |  |
| 2017 | 22,783 |  |
| 2018 | 137 |  |
|  | $ | 155,117 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-14-000040:notes:85]
[same as prior period, unchanged from 0000936395-14-000021:notes:85]

[0000936395-14-000040:notes:86]
[same as prior period, unchanged from 0000936395-14-000021:notes:86]

[0000936395-14-000040:notes:87]
|  | October 31, 2013 |  | April 30, 2014 |
| Raw materials | $ | 53,274 |  |  | $ | 56,689 |  |
| Work-in-process | 7,773 |  |  | 7,919 |  |
| Finished goods | 153,855 |  |  | 181,020 |  |
| Deferred cost of goods sold | 75,764 |  |  | 95,783 |  |
|  | 290,666 |  |  | 341,411 |  |
| Provision for excess and obsolescence | (41,563 | ) |  | (47,459 | ) |
|  | $ | 249,103 |  |  | $ | 293,952 |  |

[0000936395-14-000040:notes:88]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first six months of fiscal 2014, Ciena recorded a provision for excess and obsolescence of $13.0 million, primarily related to engineering design changes and the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform, and Converged Packet Optical products. Deductions from the provision for excess and obsolete inventory relate to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-14-000040:notes:89]
[same as prior period, unchanged from 0000936395-14-000021:notes:89]

[0000936395-14-000040:notes:90]
[same as prior period, unchanged from 0000936395-14-000021:notes:90]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-14-000040:notes:91]
[same as prior period, unchanged from 0000936395-14-000021:notes:91]

[0000936395-14-000040:notes:92]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and its intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-14-000040:notes:93]
The following table summarizes final legal maturities of debt investments at April 30, 2014 (in thousands):

[0000936395-14-000040:notes:94]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 90,033 |  |  | $ | 90,049 |  |
| Due in 1-2 years | 14,997 |  |  | 15,042 |  |
|  | $ | 105,030 |  |  | $ | 105,091 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-14-000040:notes:95]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-14-000040:notes:96]
As of the dates indicated, short-term and long-term investments are comprised of the following (in thousands):

[0000936395-14-000040:notes:97]
|  | April 30, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 60,042 |  |  | $ | 16 |  |  | — |  |  | $ | 60,058 |  |
| Included in long-term investments | 14,997 |  |  | 45 |  |  | — |  |  | 15,042 |  |
|  | $ | 75,039 |  |  | $ | 61 |  |  | $ | — |  |  | $ | 75,100 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,991 |  |  | — |  |  | — |  |  | 29,991 |  |
|  | $ | 29,991 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,991 |  |

[0000936395-14-000040:notes:98]
|  | October 31, 2013 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 99,974 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 99,985 |  |
| Included in long-term investments | 14,996 |  |  | 35 |  |  | — |  |  | 15,031 |  |
|  | $ | 114,970 |  |  | $ | 46 |  |  | $ | — |  |  | $ | 115,016 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 24,994 |  |  | — |  |  | — |  |  | 24,994 |  |
|  | $ | 24,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,994 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-14-000040:notes:99]
[same as prior period, unchanged from 0000936395-14-000021:notes:99]

[0000936395-14-000040:notes:100]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-14-000040:notes:101]
[same as prior period, unchanged from 0000936395-14-000021:notes:101]

[0000936395-14-000040:notes:102]
As of October 31, 2013, two customers each accounted for greater than 10% of net accounts receivable and in the aggregate accounted for 22.5% of net accounts receivable. As of April 30, 2014, two customers each accounted for greater than 10% of net accounts receivable, and in the aggregate accounted for 22.8% of net accounts receivable. Allowance for doubtful accounts was $2.0 million and $1.7 million as of October 31, 2013 and April 30, 2014, respectively. Ciena has not historically experienced a significant amount of bad debt expense.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-14-000040:notes:103]
Newly Issued Accounting Standards

[0000936395-14-000040:notes:104]
In February 2013, the Financial Accounting Standards Board ("FASB") issued an accounting standard update to require reclassification adjustments from other comprehensive income to be presented either in the financial statements or in the notes to the financial statements. This accounting standard update was effective for Ciena beginning in the first quarter of fiscal 2014. Ciena has determined that reclassifications from other comprehensive income to net income are immaterial for separate financial statement presentation.

[0000936395-14-000040:notes:105]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606) which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its condensed consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-14-000040:notes:106]
[same as prior period, unchanged from 0000936395-14-000021:notes:105]

[0000936395-14-000040:notes:107]
[same as prior period, unchanged from 0000936395-14-000021:notes:106]

[0000936395-14-000040:notes:108]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October of each year. Fiscal 2014 and 2013 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-14-000040:notes:109]
[same as prior period, unchanged from 0000936395-14-000021:notes:108]

[0000936395-14-000040:notes:110]
[same as prior period, unchanged from 0000936395-14-000021:notes:109]

[0000936395-14-000040:notes:111]
|  | October 31, 2013 |  | April 30, 2014 |
| Equipment, furniture and fixtures | $ | 364,574 |  |  | $ | 379,569 |  |
| Leasehold improvements | 46,247 |  |  | 46,442 |  |
|  | 410,821 |  |  | 426,011 |  |
| Accumulated depreciation and amortization | (291,092 | ) |  | (306,135 | ) |
|  | $ | 119,729 |  |  | $ | 119,876 |  |

[0000936395-14-000040:notes:112]
The total of depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements, was $25.4 million and  $22.9 million for the first six months of fiscal 2013 and 2014, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-14-000040:notes:113]
[same as prior period, unchanged from 0000936395-14-000021:notes:112]

[0000936395-14-000040:notes:114]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment, furniture and fixtures, and the shorter of useful life or lease term for leasehold improvements.


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-14-000040:notes:115]
[same as prior period, unchanged from 0000936395-14-000021:notes:114]

[0000936395-14-000040:notes:116]
[same as prior period, unchanged from 0000936395-14-000021:notes:115]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-14-000040:notes:117]
[same as prior period, unchanged from 0000936395-14-000021:notes:116]

[0000936395-14-000040:notes:118]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 57,528 |  |  | $ | 96,581 |  |  | $ | 104,646 |  |  | $ | 175,279 |  |
| Packet Networking | 2,556 |  |  | 8,196 |  |  | 7,639 |  |  | 8,581 |  |
| Optical Transport | 21,413 |  |  | 4,709 |  |  | 42,000 |  |  | 20,359 |  |
| Software and Services | 27,229 |  |  | 24,713 |  |  | 61,111 |  |  | 54,334 |  |
| Total segment profit | 108,726 |  |  | 134,199 |  |  | 215,396 |  |  | 258,553 |  |
| Less: non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 74,475 |  |  | 83,662 |  |  | 141,063 |  |  | 162,010 |  |
| General and administrative | 30,883 |  |  | 31,882 |  |  | 59,091 |  |  | 61,979 |  |
| Amortization of intangible assets | 12,439 |  |  | 11,493 |  |  | 24,892 |  |  | 23,932 |  |
| Restructuring costs | 1,509 |  |  | — |  |  | 6,539 |  |  | 115 |  |
| Add: other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (14,108 | ) |  | (12,925 | ) |  | (24,977 | ) |  | (29,951 | ) |
| Loss on extinguishment of debt | — |  |  | — |  |  | (28,630 | ) |  | — |  |
| Less: Provision for income taxes | 2,391 |  |  | 4,395 |  |  | 4,607 |  |  | 6,660 |  |
| Consolidated net loss | $ | (27,079 | ) |  | $ | (10,158 | ) |  | $ | (74,403 | ) |  | $ | (26,094 | ) |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-14-000040:notes:119]
[same as prior period, unchanged from 0000936395-14-000021:notes:118]

[0000936395-14-000040:notes:120]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 294,325 |  |  | $ | 356,840 |  |  | $ | 534,285 |  |  | $ | 690,241 |  |
| Packet Networking | 54,190 |  |  | 66,526 |  |  | 100,027 |  |  | 118,235 |  |
| Optical Transport | 57,371 |  |  | 29,616 |  |  | 114,968 |  |  | 69,713 |  |
| Software and Services | 101,826 |  |  | 107,079 |  |  | 211,525 |  |  | 215,575 |  |
| Consolidated revenue | $ | 507,712 |  |  | $ | 560,061 |  |  | $ | 960,805 |  |  | $ | 1,093,764 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-14-000040:notes:121]
[same as prior period, unchanged from 0000936395-14-000021:notes:121]

[0000936395-14-000040:notes:122]
[same as prior period, unchanged from 0000936395-14-000021:notes:122]

[0000936395-14-000040:notes:123]
[same as prior period, unchanged from 0000936395-14-000021:notes:120]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-14-000040:notes:124]
[same as prior period, unchanged from 0000936395-14-000021:notes:123]

[0000936395-14-000040:notes:125]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2014 (in thousands):

[0000936395-14-000040:notes:126]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2013 | $ | 80 |  |  | $ | 1,936 |  |  | $ | 2,016 |  |
| Additional liability recorded | 106 |  |  | 9 |  |  | 115 |  |
| Cash payments | (136 | ) |  | (178 | ) |  | (314 | ) |
| Balance at April 30, 2014 | $ | 50 |  |  | $ | 1,767 |  |  | $ | 1,817 |  |
| Current restructuring liabilities | $ | 50 |  |  | $ | 627 |  |  | $ | 677 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,140 |  |  | $ | 1,140 |  |

[0000936395-14-000040:notes:127]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2013 (in thousands):

[0000936395-14-000040:notes:128]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2012 | $ | 1,449 |  |  | $ | 3,600 |  |  | $ | 5,049 |  |
| Additional liability recorded | 4,916 |  |  | 1,623 |  |  | 6,539 |  |
| Non-cash disposal | — |  |  | (735 | ) |  | (735 | ) |
| Cash payments | (5,733 | ) |  | (2,153 | ) |  | (7,886 | ) |
| Balance at April 30, 2013 | $ | 632 |  |  | $ | 2,335 |  |  | $ | 2,967 |  |
| Current restructuring liabilities | $ | 632 |  |  | $ | 1,606 |  |  | $ | 2,238 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 729 |  |  | $ | 729 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-14-000040:notes:129]
[same as prior period, unchanged from 0000936395-14-000021:notes:128]

[0000936395-14-000040:notes:130]
[same as prior period, unchanged from 0000936395-14-000021:notes:129]

[0000936395-14-000040:notes:131]
[same as prior period, unchanged from 0000936395-14-000021:notes:130]

[0000936395-14-000040:notes:132]
[same as prior period, unchanged from 0000936395-14-000021:notes:131]

[0000936395-14-000040:notes:133]
[same as prior period, unchanged from 0000936395-14-000021:notes:132]

[0000936395-14-000040:notes:134]
[same as prior period, unchanged from 0000936395-14-000021:notes:133]

[0000936395-14-000040:notes:135]
[same as prior period, unchanged from 0000936395-14-000021:notes:134]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-14-000040:notes:136]
[same as prior period, unchanged from 0000936395-14-000021:notes:135]

[0000936395-14-000040:notes:137]
|  | October 31, 2013 |  | April 30, 2014 |
| Warranty | $ | 56,303 |  |  | $ | 56,167 |  |
| Compensation, payroll related tax and benefits | 98,770 |  |  | 64,113 |  |
| Vacation | 32,118 |  |  | 34,503 |  |
| Current restructuring liabilities | 674 |  |  | 677 |  |
| Interest payable | 6,186 |  |  | 6,179 |  |
| Other | 77,605 |  |  | 92,797 |  |
|  | $ | 271,656 |  |  | $ | 254,436 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-14-000040:notes:138]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding convertible notes:

[0000936395-14-000040:notes:139]
|  |  | April 30, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | 187,647 |  |  | 214,805 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 448,875 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 176,641 |  |  | 246,797 |  |
|  |  | $ | 1,214,288 |  |  | $ | 1,404,852 |  |

[0000936395-14-000040:notes:140]
| (1) | Includes unamortized bond premium related to embedded redemption feature. |

[0000936395-14-000040:notes:141]
| (2) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-14-000040:notes:142]
| (3) | Includes unamortized discount and accretion of principal. |


## us-gaap:ScheduleOfDebtTableTextBlock

[0000936395-14-000040:notes:143]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 Notes ("2020 Notes") were as follows as of April 30, 2014:

[0000936395-14-000040:notes:144]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 192,216 |  |  | $ | 15,575 |  |  | $ | 176,641 |  |  | $ | 43,131 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-14-000040:notes:145]
[same as prior period, unchanged from 0000936395-14-000021:notes:144]

[0000936395-14-000040:notes:146]
|  | October 31, 2013 |  | April 30, 2014 |
| Maintenance spares inventory, net | $ | 61,305 |  |  | $ | 56,090 |  |
| Deferred debt issuance costs, net | 15,677 |  |  | 13,302 |  |
| Embedded redemption feature | 2,740 |  |  | — |  |
| Restricted cash | 2,053 |  |  | 141 |  |
| Other | 4,605 |  |  | 4,560 |  |
|  | $ | 86,380 |  |  | $ | 74,093 |  |


## us-gaap:ScheduleOfOtherAssetsTableTextBlock

[0000936395-14-000040:notes:147]
[same as prior period, unchanged from 0000936395-14-000021:notes:146]

[0000936395-14-000040:notes:148]
|  | October 31, 2013 |  | April 30, 2014 |
| Prepaid VAT and other taxes | $ | 101,072 |  |  | $ | 106,790 |  |
| Deferred deployment expense | 23,190 |  |  | 25,123 |  |
| Product demonstration equipment, net | 33,382 |  |  | 43,184 |  |
| Prepaid expenses | 16,963 |  |  | 15,244 |  |
| Embedded redemption feature | — |  |  | 190 |  |
| Other non-trade receivables | 11,996 |  |  | 16,696 |  |
| Restricted cash | 52 |  |  | 52 |  |
|  | $ | 186,655 |  |  | $ | 207,279 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-14-000040:notes:149]
[same as prior period, unchanged from 0000936395-14-000021:notes:148]

[0000936395-14-000040:notes:150]
|  |  |  |  |  |  |  | Balance at |
| Six months ended | Beginning |  |  |  |  |  | end of |
| April 30, | Balance |  | Provisions |  | Settlements |  | period |
| 2013 | $ | 55,132 |  |  | 11,060 |  |  | (11,463 | ) |  | $ | 54,729 |  |
| 2014 | $ | 56,303 |  |  | 12,424 |  |  | (12,560 | ) |  | $ | 56,167 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-14-000040:notes:151]
[same as prior period, unchanged from 0000936395-14-000021:notes:150]

[0000936395-14-000040:notes:152]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Company A | $ | 101,531 |  |  | $ | 120,582 |  |  | $ | 173,210 |  |  | $ | 221,044 |  |
| Company B | 57,293 |  |  | n/a |  |  | 105,356 |  |  | n/a |  |
| Total | $ | 158,824 |  |  | $ | 120,582 |  |  | $ | 278,566 |  |  | $ | 221,044 |  |

[0000936395-14-000040:notes:153]
[same as prior period, unchanged from 0000936395-14-000021:notes:152]

[0000936395-14-000040:notes:154]
[same as prior period, unchanged from 0000936395-14-000021:notes:153]


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-14-000040:notes:155]
[same as prior period, unchanged from 0000936395-14-000021:notes:154]

[0000936395-14-000040:notes:156]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| United States | $ | 287,572 |  |  | $ | 323,927 |  |  | $ | 551,807 |  |  | $ | 641,377 |  |
| International | 220,140 |  |  | 236,134 |  |  | 408,998 |  |  | 452,387 |  |
| Total | $ | 507,712 |  |  | $ | 560,061 |  |  | $ | 960,805 |  |  | $ | 1,093,764 |  |

[0000936395-14-000040:notes:157]
[same as prior period, unchanged from 0000936395-14-000021:notes:156]

[0000936395-14-000040:notes:158]
|  | October 31, 2013 |  | April 30, 2014 |
| United States | $ | 64,132 |  |  | $ | 64,415 |  |
| Canada | 43,772 |  |  | 42,978 |  |
| Other International | 11,825 |  |  | 12,483 |  |
| Total | $ | 119,729 |  |  | $ | 119,876 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-14-000040:notes:159]
[same as prior period, unchanged from 0000936395-14-000021:notes:158]

[0000936395-14-000040:notes:160]
[same as prior period, unchanged from 0000936395-14-000021:notes:159]

[0000936395-14-000040:notes:161]
[same as prior period, unchanged from 0000936395-14-000021:notes:160]

[0000936395-14-000040:notes:162]
[same as prior period, unchanged from 0000936395-14-000021:notes:161]

[0000936395-14-000040:notes:163]
[same as prior period, unchanged from 0000936395-14-000021:notes:162]

[0000936395-14-000040:notes:164]
[same as prior period, unchanged from 0000936395-14-000021:notes:163]

[0000936395-14-000040:notes:165]
[same as prior period, unchanged from 0000936395-14-000021:notes:164]

[0000936395-14-000040:notes:166]
Asset information for reportable segments is not disclosed because it is not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources.

[0000936395-14-000040:notes:167]
[same as prior period, unchanged from 0000936395-14-000021:notes:166]

[0000936395-14-000040:notes:168]
[same as prior period, unchanged from 0000936395-14-000021:notes:167]

[0000936395-14-000040:notes:169]
[same as prior period, unchanged from 0000936395-14-000021:notes:168]

[0000936395-14-000040:notes:170]
[same as prior period, unchanged from 0000936395-14-000021:notes:169]

[0000936395-14-000040:notes:171]
[same as prior period, unchanged from 0000936395-14-000021:notes:170]

[0000936395-14-000040:notes:172]
[same as prior period, unchanged from 0000936395-14-000021:notes:171]

[0000936395-14-000040:notes:173]
[same as prior period, unchanged from 0000936395-14-000021:notes:172]


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-14-000040:notes:174]
[same as prior period, unchanged from 0000936395-14-000021:notes:173]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-14-000040:notes:175]
[same as prior period, unchanged from 0000936395-14-000021:notes:174]

[0000936395-14-000040:notes:176]
[same as prior period, unchanged from 0000936395-14-000021:notes:175]

[0000936395-14-000040:notes:177]
[same as prior period, unchanged from 0000936395-14-000021:notes:176]

[0000936395-14-000040:notes:178]
accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, share-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-14-000040:notes:179]
[same as prior period, unchanged from 0000936395-14-000021:notes:178]

[0000936395-14-000040:notes:180]
[same as prior period, unchanged from 0000936395-14-000021:notes:179]

[0000936395-14-000040:notes:181]
[same as prior period, unchanged from 0000936395-14-000021:notes:180]

[0000936395-14-000040:notes:182]
[same as prior period, unchanged from 0000936395-14-000021:notes:181]

[0000936395-14-000040:notes:183]
[same as prior period, unchanged from 0000936395-14-000021:notes:182]

[0000936395-14-000040:notes:184]
[same as prior period, unchanged from 0000936395-14-000021:notes:183]

[0000936395-14-000040:notes:185]
[same as prior period, unchanged from 0000936395-14-000021:notes:184]

[0000936395-14-000040:notes:186]
[same as prior period, unchanged from 0000936395-14-000021:notes:185]

[0000936395-14-000040:notes:187]
[same as prior period, unchanged from 0000936395-14-000021:notes:186]

[0000936395-14-000040:notes:188]
[same as prior period, unchanged from 0000936395-14-000021:notes:187]

[0000936395-14-000040:notes:189]
[same as prior period, unchanged from 0000936395-14-000021:notes:188]

[0000936395-14-000040:notes:190]
[same as prior period, unchanged from 0000936395-14-000021:notes:189]

[0000936395-14-000040:notes:191]
[same as prior period, unchanged from 0000936395-14-000021:notes:190]

[0000936395-14-000040:notes:192]
[same as prior period, unchanged from 0000936395-14-000021:notes:191]

[0000936395-14-000040:notes:193]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are ultimately expected to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon its determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 16 below.

[0000936395-14-000040:notes:194]
[same as prior period, unchanged from 0000936395-14-000021:notes:193]

[0000936395-14-000040:notes:195]
[same as prior period, unchanged from 0000936395-14-000021:notes:194]

[0000936395-14-000040:notes:196]
[same as prior period, unchanged from 0000936395-14-000021:notes:195]

[0000936395-14-000040:notes:197]
[same as prior period, unchanged from 0000936395-14-000021:notes:196]

[0000936395-14-000040:notes:198]
[same as prior period, unchanged from 0000936395-14-000021:notes:197]

[0000936395-14-000040:notes:199]
[same as prior period, unchanged from 0000936395-14-000021:notes:198]

[0000936395-14-000040:notes:200]
[same as prior period, unchanged from 0000936395-14-000021:notes:199]

[0000936395-14-000040:notes:201]
[same as prior period, unchanged from 0000936395-14-000021:notes:200]

[0000936395-14-000040:notes:202]
Some of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects a net loss on foreign currency re-measurement and exchange rate changes of $3.0 million for the six months ended April 30, 2013 and a net gain of $5.3 million for the six months ended April 30, 2014.

[0000936395-14-000040:notes:203]
From time to time, Ciena uses foreign currency forwards to hedge certain balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects losses of $0.1 million and $10.2 million related to foreign currency forward contracts for the six months ended April 30, 2013 and 2014, respectively. See Note 12 below.

[0000936395-14-000040:notes:204]
Ciena records derivative instruments in the Condensed Consolidated Statement of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

[0000936395-14-000040:notes:205]
[same as prior period, unchanged from 0000936395-14-000021:notes:202]

[0000936395-14-000040:notes:206]
[same as prior period, unchanged from 0000936395-14-000021:notes:203]

[0000936395-14-000040:notes:207]
[same as prior period, unchanged from 0000936395-14-000021:notes:204]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-14-000040:notes:208]
[same as prior period, unchanged from 0000936395-14-000021:notes:205]

[0000936395-14-000040:notes:209]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the related debt. Amortization of debt issuance costs related to our convertible notes payable and the Credit Facility (described in Note 14 below), which is included in interest expense, was $3.0 million and $2.4 million during the first six months of fiscal 2013 and fiscal 2014, respectively.


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-14-000040:notes:210]
CREDIT FACILITY

[0000936395-14-000040:notes:211]
During fiscal 2012, Ciena entered into a $150.0 million senior secured asset-based revolving credit facility (the “Credit Facility”). The Credit Facility matures on August 13, 2015, provided that it will mature early on December 15, 2014, if any of Ciena's 4.0% senior convertible notes due March 15, 2015 are then outstanding. Ciena principally uses and expects to continue to use the Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of April 30, 2014, letters of credit totaling $58.7 million were collateralized by the Credit Facility. There were no borrowings outstanding under the Credit Facility as of April 30, 2014.


## cien:ConvertibleNotesPayableTextBlock

[0000936395-14-000040:notes:212]
CONVERTIBLE NOTES PAYABLE


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-14-000040:notes:213]
[same as prior period, unchanged from 0000936395-14-000021:notes:210]

[0000936395-14-000040:notes:214]
Depreciation of product demonstration equipment was $3.5 million and $4.2 million for the first six months of fiscal 2013 and 2014, respectively.
