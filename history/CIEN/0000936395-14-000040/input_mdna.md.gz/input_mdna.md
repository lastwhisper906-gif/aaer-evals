# CIEN MD&A — 0000936395-14-000040


## mdna

[0000936395-14-000040:mdna:1]
[same as prior period, unchanged from 0000936395-14-000021:mdna:1]

[0000936395-14-000040:mdna:2]
[same as prior period, unchanged from 0000936395-14-000021:mdna:2]

[0000936395-14-000040:mdna:3]
[same as prior period, unchanged from 0000936395-14-000021:mdna:3]

[0000936395-14-000040:mdna:4]
[same as prior period, unchanged from 0000936395-14-000021:mdna:4]

[0000936395-14-000040:mdna:5]
[same as prior period, unchanged from 0000936395-14-000021:mdna:5]

[0000936395-14-000040:mdna:6]
Rapid proliferation of, and reliance by end users upon, communications services and devices, together with increased mobility and growth in cloud-based services, have fundamentally affected the demands placed upon communications networks and how they are designed. Network operators face a challenging and rapidly changing environment that requires that their network infrastructures be robust enough to address increasing capacity needs and be flexible enough to adapt to new application and service offerings. Network operators are competing to distinguish their service offerings to end users and generate revenue, while managing the costs required to implement and maintain their networks. To address these business, infrastructure and service delivery challenges, we believe network operators need a flexible infrastructure that can be adapted to support a variety of applications and controlled through the use of software.

[0000936395-14-000040:mdna:7]
Our OPn Architecture is designed to meet these challenges by providing increased scalability and programmability, as well as network-level software applications to control and configure the network dynamically. Through this network approach, we seek to enable high-capacity, configurable infrastructures that can adapt to the changing needs of end-users and the applications that they require, while providing flexible interfaces for the integration of computing, storage and network resources. By increasing network flexibility for service delivery, reducing required network elements and enabling increased scale at reduced cost, our solutions optimize networks. At the same time, our approach facilitates introduction of new service offerings, creating business and operational value for our customers. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in  “Market Opportunity and Strategy” below.

[0000936395-14-000040:mdna:8]
Our quarterly reports on Form 10-Q, annual reports on Form 10-K, and current reports on Form 8-K filed with the SEC are available through the SEC's website at www.sec.gov or free of charge on our website as soon as reasonably practicable after we file these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the "Investors" section of our website at www.ciena.com. Investors are

[0000936395-14-000040:mdna:9]
encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-14-000040:mdna:10]
[same as prior period, unchanged from 0000936395-14-000021:mdna:10]

[0000936395-14-000040:mdna:11]
We believe that the shift that is underway in network architectures to next-generation, converged infrastructures represents significant, long-term opportunities for Ciena. We believe that dynamics, including the proliferation of devices running mobile web applications, the prevalence of video applications, the increase in machine-to-machine connections, and the shift of enterprise and consumer applications to cloud-based or virtualized network environments are representative of the magnitude of changing demands being placed upon network architectures. At the same time, bandwidth requirements and the use and dependence by consumers and enterprises upon a  variety of communications applications, services and devices continues to grow. We expect that these drivers will require existing and emerging network operators to invest in converged next-generation network infrastructures that are more automated, open and software programmable.

[0000936395-14-000040:mdna:12]
[same as prior period, unchanged from 0000936395-14-000021:mdna:12]

[0000936395-14-000040:mdna:13]
Promotion of our OPn Architecture for Next-Generation Networks. The services and applications running on communications networks require that more of the traffic on these networks be packet-oriented. The traditional approach to this problem has been to add IP routing capability at many points of intersection in the network. As capacity needs grow, this approach becomes unnecessarily complex and costly. We reduce the cost and complexity of growing networks with a programmable infrastructure that brings together the reliability and capacity of optical networking with the flexibility and economics of packet networking technologies. Combining these attributes with network level applications creates an approach we call our OPn Architecture. Our OPn Architecture leverages the convergence of optical and packet networking to enable network scale, applies advanced control plane software for network programmability, and enables cloud-level applications to integrate and optimize network resources — along with computing and storage resources — in a virtualized environment. The software-driven aspects of this architecture become increasingly important as network operators increasingly seek to leverage an open ecosystem of virtualized resources to enable the real-time analytics and network agility required for on-demand, next-generation network architectures. Our OPn Architecture  offers network operators scalability, programmability, flexibility and cost-effectiveness, and we see opportunities in offering a portfolio of solutions that facilitate the transition to next-generation networks that are optimized to create new services rapidly and to meet end user demands.

[0000936395-14-000040:mdna:14]
Alignment of Research and Development Investment with Growth Opportunities. We seek to ensure that our product development initiatives are closely aligned with changing dynamics in our markets, network operator and end user demands, and growth opportunities for Ciena. We are investing in our OPn Architecture with current development efforts focused on expanding packet capabilities in our Packet Networking and Converged Packet Optical products for metro and service aggregation applications. We are also focused on optimizing our existing core networking solutions for application in metro networks. Our research and development efforts seek to extend and converge our existing technologies, including our WaveLogic coherent optical processor for 40G and 100G optical transport, and to introduce 400G and greater transmission speeds. In the packet area, we are increasing the scale and capability of our packet offerings and integrating standards-based open control interfaces. In the software area, we are enhancing our network management and planning applications. We are also focusing on initiatives to increase software-defined programmability and control of networks, including through our joint development initiative with Ericsson, and working to develop network-level software applications that configure networks and support new service introduction.

[0000936395-14-000040:mdna:15]
[same as prior period, unchanged from 0000936395-14-000021:mdna:15]

[0000936395-14-000040:mdna:16]
Coverage. Our coverage model is focused on selling into key customer segments, penetrating high-growth geographic markets and addressing additional network applications with our solutions. To complement our existing service provider customers, we intend to continue to seek opportunities to diversify our customer base into key market segments. We are expanding our sales efforts to capture opportunities arising from enterprise migration to cloud-based services, and promoting our reputation with government agencies and research and educational institutions as a trusted network equipment supplier. We are also focused on further penetrating significant Web 2.0 players, including Internet content providers and other emerging network operators who are changing the ways in which information is accessed and shared. To expand the geographic reach of our direct sales resources, and to broaden the role our solutions play in communications networks, we intend to pursue selling initiatives with third parties and foster strategic channel opportunities, including through our service provider customers, systems integrators and value-added resellers. Through our recently announced packet optical distribution relationship with Ericsson we are seeking to expand our geographic reach as well as the

[0000936395-14-000040:mdna:17]
28

[0000936395-14-000040:mdna:18]
applications for our products. Our direct and indirect selling efforts are focused on the sale of our solutions into additional applications, including metro aggregation and submarine networks, and in support of cloud-based services, business Ethernet services and mobile backhaul.

[0000936395-14-000040:mdna:19]
[same as prior period, unchanged from 0000936395-14-000021:mdna:17]

[0000936395-14-000040:mdna:20]
Business optimization to yield operating leverage. We seek to improve the operational efficiencies in our business and gain additional operating leverage. We are focused on the transformation and redesign of certain business processes, systems, and resources. These initiatives include additional investments, re-engineering and automation of certain key business processes, including the engagement of strategic partners or resources to assist with select business functions. In addition, we are focused on optimizing our supply chain, including efforts to reduce our material and overhead costs in an effort to increase efficiency and reduce the cost to produce our product solutions. These initiatives include portfolio and process optimization, reducing our fulfillment, shipping and logistics expense, and identifying ways to drive improved efficiencies in the design and development of our solutions. We seek to leverage these opportunities to promote the profitable growth of our business and drive additional operating leverage.

[0000936395-14-000040:mdna:21]
Competitive Landscape

[0000936395-14-000040:mdna:22]
We continue to encounter a highly competitive marketplace, particularly for our Converged Packet Optical and Packet Networking products. Our sales of Converged Packet Optical solutions reflect an intense and fragmented competitive environment, as we and our competitors introduce and enhance new, high-capacity, high-speed network solutions and  aggressively seek to capture market share and maintain incumbency with large service provider customers. Our sales of Packet Networking solutions also face a competitive marketplace as we seek to promote the benefits of our OPn Architecture, as compared to alternative approaches, and secure network operator adoption. We expect the current competitive landscape to remain challenging and dynamic. As networking technologies become more software-driven, and network features and layers continue to converge, our competitive landscape continues to broaden beyond traditional competitors. As a result, we are competing with, and expect to compete increasingly with, additional vendors focused on IP routing, information technology and software.

[0000936395-14-000040:mdna:23]
Securing new opportunities for our Converged Packet Optical and Packet Networking products in this competitive landscape, particularly in international markets, often requires that we agree to aggressive pricing or unfavorable commercial terms. These terms can elongate our revenue recognition or cash collection cycles, add startup costs to initial sales or deployment of our solutions,  require financial commitments or performance bonds that place cash resources at risk, and include onerous contractual commitments that place a disproportionate allocation of risk upon the vendor. These terms can adversely affect our results of operations and contribute to fluctuations in our results.

[0000936395-14-000040:mdna:24]
[same as prior period, unchanged from 0000936395-14-000021:mdna:23]

[0000936395-14-000040:mdna:25]
Revenue for the second quarter of fiscal 2014 was $560.1 million, representing a sequential increase of 4.9% from $533.7 million in the first quarter of fiscal 2014. Revenue-related details reflecting sequential changes from the first quarter of fiscal 2014 include:

[0000936395-14-000040:mdna:26]
| • | Product revenue for the second quarter of fiscal 2014 increased by $27.9 million, reflecting increased sales of $23.4 million in Converged Packet Optical and $14.8 million in Packet Networking. These increases were partially offset by decreased sales of $10.5 million in Optical Transport. |

[0000936395-14-000040:mdna:27]
| • | Service revenue for the second quarter of fiscal 2014 decreased by $1.5 million. |

[0000936395-14-000040:mdna:28]
| • | Revenue from the United States for the second quarter of fiscal 2014 was $324.0 million, an increase from $317.4 million in the first quarter of fiscal 2014. |

[0000936395-14-000040:mdna:29]
| • | International revenue for the second quarter of fiscal 2014 was $236.1 million, an increase from $216.3 million in the first quarter of fiscal 2014. |

[0000936395-14-000040:mdna:30]
| • | As a percentage of revenue, international revenue was 42.2% during the second quarter of fiscal 2014, an increase from 40.5% during the first quarter of fiscal 2014. |

[0000936395-14-000040:mdna:31]
| • | For the second quarter of fiscal 2014, one customer accounted for 21.5% of total revenue. This compares to one customer that accounted for 18.8% of total revenue in the first quarter of fiscal 2014. |

[0000936395-14-000040:mdna:32]
Gross margin for the second quarter of fiscal 2014 was 42.4%, an increase from 42.3% in the first quarter of fiscal 2014.

[0000936395-14-000040:mdna:33]
Operating expense was $230.5 million for the second quarter of fiscal 2014, an increase from $222.5 million in the first quarter of fiscal 2014. Second quarter fiscal 2014 operating expense reflects increases of $5.3 million in selling and marketing expense, $2.0 million in research and development expense and $1.8 million in general and administrative expense. These increases were partially offset by a decrease of $1.0 million in amortization expense for intangibles.

[0000936395-14-000040:mdna:34]
Reflecting the revenue and margin improvement above, income from operations for the second quarter of fiscal 2014 was $7.2 million, compared to income from operations of $3.4 million during the first quarter of fiscal 2014. Our net loss for the second quarter of fiscal 2014 was $10.2 million, or $0.10 per share. This compares to a net loss of $15.9 million or $0.15 per share, for the first quarter of fiscal 2014.

[0000936395-14-000040:mdna:35]
We generated cash from operations of $2.0 million during the second quarter of fiscal 2014, consisting of $49.5 million in cash provided by net losses adjusted for non-cash charges, offset by a $47.5 million use of cash related to changes in working capital. This compares with $37.2 million of cash used by operations during the first quarter of fiscal 2014, consisting of $41.3 million in cash provided by net losses adjusted for non-cash charges offset by a $78.5 million use of cash related to changes in working capital.

[0000936395-14-000040:mdna:36]
As of April 30, 2014, we had $325.1 million in cash and cash equivalents, $90.1 million of short-term investments in U.S. treasury securities and commercial paper, and $15.0 million of long-term investments in U.S. treasury securities. This compares to $356.5 million in cash and cash equivalents and $100.0 million of short-term investments in U.S. treasury securities, at April 30, 2013, and $346.5 million in cash and cash equivalents, $125.0 million of short-term investments in U.S. treasury securities and commercial paper, and $15.0 million of long-term investments in U.S. treasury securities at October 31, 2013.

[0000936395-14-000040:mdna:37]
As of April 30, 2014, we had 4,998 employees, an increase from 4,754 at October 31, 2013 and an increase from 4,546 at April 30, 2013.

[0000936395-14-000040:mdna:38]
[same as prior period, unchanged from 0000936395-14-000021:mdna:37]

[0000936395-14-000040:mdna:39]
[same as prior period, unchanged from 0000936395-14-000021:mdna:38]

[0000936395-14-000040:mdna:40]
[same as prior period, unchanged from 0000936395-14-000021:mdna:39]

[0000936395-14-000040:mdna:41]
| • | Converged Packet Optical — includes networking solutions optimized for the convergence of coherent optical transport, OTN switching and packet switching. These platforms enable automated packet-optical infrastructures that create and efficiently allocate high-capacity bandwidth for the delivery of a wide variety of enterprise and consumer-oriented network services. Products in this segment include the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. These products include multiservice, multi-protocol switching systems that consolidate the functionality of an add/drop multiplexer, digital cross-connect and packet switch into a single, high-capacity intelligent switching system. These products address both the core and metro segments of communications networks and support key managed services, Ethernet/TDM Private Line, Triple Play and IP services. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-14-000040:mdna:42]
| • | Packet Networking — principally includes Ciena's 3000 family of service delivery switches and service aggregation switches, the 5000 series of service aggregation switches, and its Ethernet packet configuration for the 5410 Service Aggregation Switch. These products support the access and aggregation tiers of communications networks and have |

[0000936395-14-000040:mdna:43]
principally been deployed to support wireless backhaul infrastructures and business data services. Employing sophisticated, carrier-grade Ethernet switching technology, these products deliver quality of service capabilities, virtual local area networking and switching functions, and carrier-grade operations, administration, and maintenance features. This segment includes stand-alone broadband products that transition voice networks to support Internet-based (IP) telephony, video services and DSL. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations.

[0000936395-14-000040:mdna:44]
| • | Optical Transport — includes optical transport solutions that add capacity to core, regional and metro networks and enable cost-effective and efficient transport of voice, video and data traffic at high transmission speeds. Ciena's principal products in this segment include the 4200 Advanced Services Platform, Corestream® Agility Optical Transport System, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL), and 6100 Multiservice Optical Platform. This segment includes sales from SONET/SDH, transport and data networking products, as well as certain enterprise-oriented transport solutions that support storage and LAN extension, interconnection of data centers, and virtual private networks. This segment also includes operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-14-000040:mdna:45]
| • | Software and Services — includes Ciena's network software suite, including the OneControl Unified Management System, an integrated network and service management software designed to automate and simplify network management, operation and service delivery. These software solutions can track individual services across multiple product suites, facilitating planned network maintenance, outage detection and identification of customers or services affected by network performance. This segment includes the ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and network level applications. This segment includes a broad range of consulting, network design and support services from Ciena's Network Transformation Solutions offering. This segment also includes installation and deployment, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-14-000040:mdna:46]
Quarter ended April 30, 2013 compared to the quarter ended April 30, 2014

[0000936395-14-000040:mdna:47]
[same as prior period, unchanged from 0000936395-14-000021:mdna:45]

[0000936395-14-000040:mdna:48]
[same as prior period, unchanged from 0000936395-14-000021:mdna:47]

[0000936395-14-000040:mdna:49]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 294,325 |  |  | 57.9 |  | $ | 356,840 |  |  | 63.7 |  | $ | 62,515 |  |  | 21.2 |  |
| Packet Networking | 54,190 |  |  | 10.7 |  | 66,526 |  |  | 11.9 |  | 12,336 |  |  | 22.8 |  |
| Optical Transport | 57,371 |  |  | 11.3 |  | 29,616 |  |  | 5.3 |  | (27,755 | ) |  | (48.4 | ) |
| Software and Services | 101,826 |  |  | 20.1 |  | 107,079 |  |  | 19.1 |  | 5,253 |  |  | 5.2 |  |
| Consolidated revenue | $ | 507,712 |  |  | 100.0 |  | $ | 560,061 |  |  | 100.0 |  | $ | 52,349 |  |  | 10.3 |  |

[0000936395-14-000040:mdna:50]
[same as prior period, unchanged from 0000936395-14-000021:mdna:49]

[0000936395-14-000040:mdna:51]
[same as prior period, unchanged from 0000936395-14-000021:mdna:50]

[0000936395-14-000040:mdna:52]
[same as prior period, unchanged from 0000936395-14-000021:mdna:51]

[0000936395-14-000040:mdna:53]
| • | Converged Packet Optical revenue increased, reflecting a $64.4 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. In addition, sales of the OTN configuration for the 5410 Reconfigurable Switching System increased by $5.7 million. These increases were slightly offset by decreases of $4.7 million in sales of our CoreDirector® Multiservice Optical Switches and $2.9 million in sales of our 5430 Reconfigurable Switching System. The strong performance of this segment, particularly as compared to the expected declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the |

[0000936395-14-000040:mdna:54]
convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality.

[0000936395-14-000040:mdna:55]
| • | Packet Networking revenue increased, reflecting a $14.6 million increase in sales of our 3000 and 5000 families of service delivery and aggregation switches. This increase was partially offset by a $1.8 million decrease in sales of our 5410 Service Aggregation Switch. Segment revenue benefited from the expansion of Ethernet business services by our North American service provider customers and sales of service delivery and aggregation products in support of their packet-related network initiatives. |

[0000936395-14-000040:mdna:56]
| • | Optical Transport revenue decreased, reflecting a $10.1 million decrease of our 5100/5200 Advanced Services Platform, a $10.9 million decrease in sales of other stand-alone transport products and a $6.7 million decrease in sales of our 4200 Advanced Services Platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in revenue in recent years. We expect this to continue, reflecting network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-14-000040:mdna:57]
| • | Software and Services revenue increased, reflecting increases of $2.5 million in maintenance and support services revenue and $1.8 million in installation and deployment services revenue. |

[0000936395-14-000040:mdna:58]
[same as prior period, unchanged from 0000936395-14-000021:mdna:56]

[0000936395-14-000040:mdna:59]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| United States | $ | 287,572 |  |  | 56.6 |  | $ | 323,927 |  |  | 57.8 |  | $ | 36,355 |  |  | 12.6 |
| International | 220,140 |  |  | 43.4 |  | 236,134 |  |  | 42.2 |  | 15,994 |  |  | 7.3 |
| Total | $ | 507,712 |  |  | 100.0 |  | $ | 560,061 |  |  | 100.0 |  | $ | 52,349 |  |  | 10.3 |

[0000936395-14-000040:mdna:60]
[same as prior period, unchanged from 0000936395-14-000021:mdna:58]

[0000936395-14-000040:mdna:61]
[same as prior period, unchanged from 0000936395-14-000021:mdna:59]

[0000936395-14-000040:mdna:62]
[same as prior period, unchanged from 0000936395-14-000021:mdna:60]

[0000936395-14-000040:mdna:63]
| • | United States revenue reflects increases of $32.7 million in Converged Packet Optical sales, $12.1 million in Packet Networking sales and $6.5 million in Software and Services revenue. These increases were partially offset by a $15.0 million decrease in Optical Transport sales. Increased revenues reflect adoption by network operators in the United States of converged network architectures that align well with our OPn Architecture and solutions offering. |

[0000936395-14-000040:mdna:64]
| • | International revenue reflects increases of $29.8 million in Converged Packet Optical sales, partially offset by decreases of $12.8 million in Optical Transport sales and $1.3 million in Software and Services revenue. |

[0000936395-14-000040:mdna:65]
A sizable portion of our revenue continues to come from sales to a small number of service providers. As a result, our financial results are significantly affected by, and can fluctuate depending upon, spending levels and the business opportunities and challenges encountered by our largest service provider customers. For the second quarter of fiscal 2014, one customer accounted for 21.5% of total revenue. This compares to two customers that together accounted for 31.3% of total revenue in the second quarter of fiscal 2013.

[0000936395-14-000040:mdna:66]
[same as prior period, unchanged from 0000936395-14-000021:mdna:65]

[0000936395-14-000040:mdna:67]
[same as prior period, unchanged from 0000936395-14-000021:mdna:66]

[0000936395-14-000040:mdna:68]
[same as prior period, unchanged from 0000936395-14-000021:mdna:67]

[0000936395-14-000040:mdna:69]
While we have experienced recent periods in which our gross profit as a percentage of revenue, or “gross margin,” has been more consistent, it remains susceptible to fluctuation in any quarter due to a number of factors impacting our business.

[0000936395-14-000040:mdna:70]
Gross margin can be adversely affected by the level of pricing pressure and competition that we encounter in the market, particularly in our efforts to compete to obtain business with new customers or to maintain business with existing customers. In an effort to penetrate additional markets, secure new business or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders, particularly associated with initial sales or deployment projects. Similarly, to maintain incumbency with key customers for existing and future business opportunities, we may be required to offer discounted pricing, provide commitments with respect to future technology development, or offer less favorable commercial terms as compared to our historical business arrangements with these customers. Some of our large existing customers are pursuing purchasing strategies or adopting procurement approaches intended to drive further pricing reductions, seek additional commercial concessions and consolidate their number of direct suppliers of networking technology. The impact of significant new wins or commercial concessions to significant customers can adversely affect our gross margin during the relevant periods and result in fluctuation in our results of operations.

[0000936395-14-000040:mdna:71]
Our product gross margin can also vary significantly depending upon the mix and concentration of revenue by segment, product line within a particular segment, geography and customers. Within our Converged Packet Optical segment, gross margin can be affected by our mix of lower margin "commons" equipment sales and higher margin channel cards and software content. We also expect that gross margins will be subject to fluctuation based on our introduction of new products, changes in expense for excess and obsolete inventory and warranty obligations, as well as our degree of success in driving product cost reductions and other effort to optimize our operations. Service gross margin can be affected by customer and geographic mix, and the mix between lower margin deployment services as compared to maintenance and other service offerings. These market dynamics and factors may adversely affect our gross margins and results of operations in certain periods.

[0000936395-14-000040:mdna:72]
[same as prior period, unchanged from 0000936395-14-000021:mdna:70]

[0000936395-14-000040:mdna:73]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 507,712 |  |  | 100.0 |  | $ | 560,061 |  |  | 100.0 |  | $ | 52,349 |  |  | 10.3 |
| Total cost of goods sold | 298,199 |  |  | 58.7 |  | 322,370 |  |  | 57.6 |  | 24,171 |  |  | 8.1 |
| Gross profit | $ | 209,513 |  |  | 41.3 |  | $ | 237,691 |  |  | 42.4 |  | $ | 28,178 |  |  | 13.4 |

[0000936395-14-000040:mdna:74]
[same as prior period, unchanged from 0000936395-14-000021:mdna:72]

[0000936395-14-000040:mdna:75]
[same as prior period, unchanged from 0000936395-14-000021:mdna:73]

[0000936395-14-000040:mdna:76]
[same as prior period, unchanged from 0000936395-14-000021:mdna:74]

[0000936395-14-000040:mdna:77]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 413,217 |  |  | 100.0 |  | $ | 460,821 |  |  | 100.0 |  | $ | 47,604 |  |  | 11.5 |
| Product cost of goods sold | 239,441 |  |  | 57.9 |  | 257,632 |  |  | 55.9 |  | 18,191 |  |  | 7.6 |
| Product gross profit | $ | 173,776 |  |  | 42.1 |  | $ | 203,189 |  |  | 44.1 |  | $ | 29,413 |  |  | 16.9 |

[0000936395-14-000040:mdna:78]
[same as prior period, unchanged from 0000936395-14-000021:mdna:76]

[0000936395-14-000040:mdna:79]
[same as prior period, unchanged from 0000936395-14-000021:mdna:77]

[0000936395-14-000040:mdna:80]
[same as prior period, unchanged from 0000936395-14-000021:mdna:78]

[0000936395-14-000040:mdna:81]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 94,495 |  |  | 100.0 |  | $ | 99,240 |  |  | 100.0 |  | $ | 4,745 |  |  | 5.0 |  |
| Service cost of goods sold | 58,758 |  |  | 62.2 |  | 64,738 |  |  | 65.2 |  | 5,980 |  |  | 10.2 |  |
| Service gross profit | $ | 35,737 |  |  | 37.8 |  | $ | 34,502 |  |  | 34.8 |  | $ | (1,235 | ) |  | (3.5 | ) |

[0000936395-14-000040:mdna:82]
[same as prior period, unchanged from 0000936395-14-000021:mdna:80]

[0000936395-14-000040:mdna:83]
[same as prior period, unchanged from 0000936395-14-000021:mdna:81]

[0000936395-14-000040:mdna:84]
[same as prior period, unchanged from 0000936395-14-000021:mdna:82]

[0000936395-14-000040:mdna:85]
| • | Gross profit as a percentage of revenue increased as a result of the factors described below. |

[0000936395-14-000040:mdna:86]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to a greater mix of higher margin channel card revenue within our Converged Packet Optical segment, lower provisions for warranty expense and greater leverage from efforts to streamline and optimize our supply chain activities. These increases were partially offset by higher inventory excess and obsolescence costs. |

[0000936395-14-000040:mdna:87]
| • | Gross profit on services as a percentage of services revenue decreased, primarily due to higher shipping and warehousing costs for our maintenance services. These higher costs are largely due to the expansion of our international activities. |

[0000936395-14-000040:mdna:88]
[same as prior period, unchanged from 0000936395-14-000021:mdna:86]

[0000936395-14-000040:mdna:89]
We expect operating expense to increase in fiscal 2014 from the level reported for fiscal 2013 to support the growth of our business and fund our research and development initiatives. However, we expect fiscal 2014 operating expense as a percentage of revenue to decline as compared to fiscal 2013. Operating expense consists of the component elements described below.

[0000936395-14-000040:mdna:90]
[same as prior period, unchanged from 0000936395-14-000021:mdna:88]

[0000936395-14-000040:mdna:91]
[same as prior period, unchanged from 0000936395-14-000021:mdna:89]

[0000936395-14-000040:mdna:92]
[same as prior period, unchanged from 0000936395-14-000021:mdna:90]

[0000936395-14-000040:mdna:93]
Amortization of intangible assets primarily consists of the amortization of purchased technology and customer relationships from our acquisitions.

[0000936395-14-000040:mdna:94]
[same as prior period, unchanged from 0000936395-14-000021:mdna:92]

[0000936395-14-000040:mdna:95]
[same as prior period, unchanged from 0000936395-14-000021:mdna:93]

[0000936395-14-000040:mdna:96]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 100,787 |  |  | 19.9 |  | $ | 103,492 |  |  | 18.5 |  | $ | 2,705 |  |  | 2.7 |  |
| Selling and marketing | 74,475 |  |  | 14.6 |  | 83,662 |  |  | 14.9 |  | 9,187 |  |  | 12.3 |  |
| General and administrative | 30,883 |  |  | 6.1 |  | 31,882 |  |  | 5.7 |  | 999 |  |  | 3.2 |  |
| Amortization of intangible assets | 12,439 |  |  | 2.4 |  | 11,493 |  |  | 2.1 |  | (946 | ) |  | (7.6 | ) |
| Restructuring costs | 1,509 |  |  | 0.3 |  | — |  |  | 0.0 |  | (1,509 | ) |  | (100.0 | ) |
| Total operating expenses | $ | 220,093 |  |  | 43.3 |  | $ | 230,529 |  |  | 41.2 |  | $ | 10,436 |  |  | 4.7 |  |

[0000936395-14-000040:mdna:97]
[same as prior period, unchanged from 0000936395-14-000021:mdna:95]

[0000936395-14-000040:mdna:98]
[same as prior period, unchanged from 0000936395-14-000021:mdna:96]

[0000936395-14-000040:mdna:99]
[same as prior period, unchanged from 0000936395-14-000021:mdna:97]

[0000936395-14-000040:mdna:100]
| • | Research and development expense benefited by $5.0 million as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Canadian Dollar. The $2.7 million increase in research and development expense consisted of a $2.2 million increase in employee compensation and related costs and a $1.7 million increase in professional services expense. These increases were partially offset by a $1.2 million decrease in prototype expense. Our prioritization of expense reflects the research and development strategy described in "Market Opportunity and Strategy" above. |

[0000936395-14-000040:mdna:101]
| • | Selling and marketing expense increased by $9.2 million, primarily reflecting increases of $7.9 million in employee compensation and related costs and $1.6 million in travel and related costs. These increases were partially offset by a $1.0 million decrease in customer demonstration equipment expense. |

[0000936395-14-000040:mdna:102]
| • | General and administrative expense increased by $1.0 million, reflecting a $2.0 million patent litigation settlement, partially offset by a $1.0 million decrease in employee compensation and related costs. |

[0000936395-14-000040:mdna:103]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-14-000040:mdna:104]
| • | Restructuring costs for fiscal 2013 primarily reflect certain severance and related expense associated with |

[0000936395-14-000040:mdna:105]
[same as prior period, unchanged from 0000936395-14-000021:mdna:103]

[0000936395-14-000040:mdna:106]
research and development initiatives. Restructuring costs for fiscal 2013 also include the consolidation of certain facilities located within Maryland associated with the transition of our headquarters facility.

[0000936395-14-000040:mdna:107]
[same as prior period, unchanged from 0000936395-14-000021:mdna:105]

[0000936395-14-000040:mdna:108]
[same as prior period, unchanged from 0000936395-14-000021:mdna:106]

[0000936395-14-000040:mdna:109]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (2,716 | ) |  | (0.5 | ) |  | $ | (1,905 | ) |  | (0.3 | ) |  | $ | 811 |  |  | (29.9 | ) |
| Interest expense | $ | 11,392 |  |  | 2.2 |  |  | $ | 11,020 |  |  | 2.0 |  |  | $ | (372 | ) |  | (3.3 | ) |
| Provision for income taxes | $ | 2,391 |  |  | 0.5 |  |  | $ | 4,395 |  |  | 0.8 |  |  | $ | 2,004 |  |  | 83.8 |  |

[0000936395-14-000040:mdna:110]
[same as prior period, unchanged from 0000936395-14-000021:mdna:108]

[0000936395-14-000040:mdna:111]
[same as prior period, unchanged from 0000936395-14-000021:mdna:109]

[0000936395-14-000040:mdna:112]
[same as prior period, unchanged from 0000936395-14-000021:mdna:110]

[0000936395-14-000040:mdna:113]
| • | Interest and other income (loss), net reflects a $2.4 million gain in foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, partially offset by a $1.6 million non-cash loss related to the change in fair value of the embedded redemption feature associated with our 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes"). |

[0000936395-14-000040:mdna:114]
[same as prior period, unchanged from 0000936395-14-000021:mdna:112]

[0000936395-14-000040:mdna:115]
| • | Provision for income taxes increased primarily due to foreign tax expense, which is largely a result of higher income from our Brazilian operations. |

[0000936395-14-000040:mdna:116]
Six months ended April 30, 2013 compared to the six months ended April 30, 2014

[0000936395-14-000040:mdna:117]
Revenue

[0000936395-14-000040:mdna:118]
The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-14-000040:mdna:119]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 534,285 |  |  | 55.6 |  | $ | 690,241 |  |  | 63.1 |  | $ | 155,956 |  |  | 29.2 |  |
| Packet Networking | 100,027 |  |  | 10.4 |  | 118,235 |  |  | 10.8 |  | 18,208 |  |  | 18.2 |  |
| Optical Transport | 114,968 |  |  | 12.0 |  | 69,713 |  |  | 6.4 |  | (45,255 | ) |  | (39.4 | ) |
| Software and Services | 211,525 |  |  | 22.0 |  | 215,575 |  |  | 19.7 |  | 4,050 |  |  | 1.9 |  |
| Consolidated revenue | $ | 960,805 |  |  | 100.0 |  | $ | 1,093,764 |  |  | 100.0 |  | $ | 132,959 |  |  | 13.8 |  |

[0000936395-14-000040:mdna:120]
_____________________________

[0000936395-14-000040:mdna:121]
*    Denotes % of total revenue

[0000936395-14-000040:mdna:122]
**    Denotes % change from 2013 to 2014

[0000936395-14-000040:mdna:123]
| • | Converged Packet Optical revenue increased significantly, reflecting a $132.6 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. In addition, sales of our 5430 reconfigurable switching system and the OTN configuration for the 5410 Reconfigurable Switching System increased by $24.1 million and $3.7 million respectively. These increases were partially offset by a $4.4 million decrease in sales of our CoreDirector® Multiservice Optical Switches. The strong performance of this segment, particularly as compared to the expected declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-14-000040:mdna:124]
| • | Packet Networking revenue increased, reflecting an increase of $25.5 million in sales of our 3000 and 5000 families of service delivery and aggregation switches. This increase was partially offset by decreases of $5.8 million in sales of our 5410 Service Aggregation Switch and $1.1 million in sales of our older, stand-alone broadband products. Segment revenue benefited from the expansion of Ethernet business services by our North American service provider customers and sales of service delivery and aggregation products in support of their related network initiatives. |

[0000936395-14-000040:mdna:125]
| • | Optical Transport revenue decreased, reflecting sales decreases of $14.5 million in our 4200 Advanced Services Platform, $20.8 million in other stand-alone transport products and $10.0 million of 5100/5200 Advanced Services Platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-14-000040:mdna:126]
| • | Software and Services revenue increased, reflecting increases of $2.8 million for installation and deployment services revenue and $2.8 million for maintenance and support services revenue. These increases were partially offset by a $1.4 million decrease in software sales. |

[0000936395-14-000040:mdna:127]
Revenue from sales to customers outside of the United States is reflected as International in the geographic distribution of revenue below. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-14-000040:mdna:128]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| United States | $ | 551,807 |  |  | 57.4 |  | $ | 641,377 |  |  | 58.6 |  | $ | 89,570 |  |  | 16.2 |
| International | 408,998 |  |  | 42.6 |  | 452,387 |  |  | 41.4 |  | 43,389 |  |  | 10.6 |
| Total | $ | 960,805 |  |  | 100.0 |  | $ | 1,093,764 |  |  | 100.0 |  | $ | 132,959 |  |  | 13.8 |

[0000936395-14-000040:mdna:129]
[same as prior period, unchanged from 0000936395-14-000021:mdna:119]

[0000936395-14-000040:mdna:130]
*    Denotes % of total revenue

[0000936395-14-000040:mdna:131]
**    Denotes % change from 2013 to 2014

[0000936395-14-000040:mdna:132]
| • | United States revenue reflects increases of $92.9 million in Converged Packet Optical sales, $17.9 million in Packet Networking sales and $9.5 million in Services and Software sales. In particular, during the first half of fiscal 2014, we benefited from the spending patterns and decisions of our largest service provider customers as they adopted converged, next generation network architectures that align well with our OPn Architecture and solutions offering. These increases were partially offset by a $30.7 million decrease in Optical Transport sales. |

[0000936395-14-000040:mdna:133]
| • | International revenue reflects an increase of $63.1 million in Converged Packet Optical sales. This increase was partially offset by decreases of $14.6 million in Optical Transport sales and $5.5 million in Software and Services revenue. |

[0000936395-14-000040:mdna:134]
Cost of Goods Sold and Gross Profit

[0000936395-14-000040:mdna:135]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-14-000040:mdna:136]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 960,805 |  |  | 100.0 |  | $ | 1,093,764 |  |  | 100.0 |  | $ | 132,959 |  |  | 13.8 |
| Total cost of goods sold | 555,497 |  |  | 57.8 |  | 630,222 |  |  | 57.6 |  | 74,725 |  |  | 13.5 |
| Gross profit | $ | 405,308 |  |  | 42.2 |  | $ | 463,542 |  |  | 42.4 |  | $ | 58,234 |  |  | 14.4 |

[0000936395-14-000040:mdna:137]
[same as prior period, unchanged from 0000936395-14-000021:mdna:168]

[0000936395-14-000040:mdna:138]
*    Denotes % of total revenue

[0000936395-14-000040:mdna:139]
**    Denotes % change from 2013 to 2014

[0000936395-14-000040:mdna:140]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 766,274 |  |  | 100.0 |  | $ | 893,762 |  |  | 100.0 |  | $ | 127,488 |  |  | 16.6 |
| Product cost of goods sold | 435,962 |  |  | 56.9 |  | 502,848 |  |  | 56.3 |  | 66,886 |  |  | 15.3 |
| Product gross profit | $ | 330,312 |  |  | 43.1 |  | $ | 390,914 |  |  | 43.7 |  | $ | 60,602 |  |  | 18.3 |

[0000936395-14-000040:mdna:141]
_____________________________________

[0000936395-14-000040:mdna:142]
*    Denotes % of product revenue

[0000936395-14-000040:mdna:143]
**    Denotes % change from 2013 to 2014

[0000936395-14-000040:mdna:144]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 194,531 |  |  | 100.0 |  | $ | 200,002 |  |  | 100.0 |  | $ | 5,471 |  |  | 2.8 |  |
| Service cost of goods sold | 119,535 |  |  | 61.4 |  | 127,374 |  |  | 63.7 |  | 7,839 |  |  | 6.6 |  |
| Service gross profit | $ | 74,996 |  |  | 38.6 |  | $ | 72,628 |  |  | 36.3 |  | $ | (2,368 | ) |  | (3.2 | ) |

[0000936395-14-000040:mdna:145]
_____________________________________

[0000936395-14-000040:mdna:146]
*    Denotes % of services revenue

[0000936395-14-000040:mdna:147]
**    Denotes % change from 2013 to 2014

[0000936395-14-000040:mdna:148]
| • | Gross profit as a percentage of revenue increased as a result of the factors described below. |

[0000936395-14-000040:mdna:149]
| • | Gross profit on products as a percentage of product revenue increased primarily due to improved mix of higher-margin packet platforms with software content within our Packet Networking and Converged Packet Optical segments, and greater leverage from efforts to streamline and optimize our supply chain activities. |

[0000936395-14-000040:mdna:150]
| • | Gross profit on services as a percentage of services revenue decreased primarily due to higher spares usage costs in support of our maintenance contracts. |

[0000936395-14-000040:mdna:151]
Operating Expense

[0000936395-14-000040:mdna:152]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-14-000040:mdna:153]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 189,912 |  |  | 19.8 |  | $ | 204,989 |  |  | 18.7 |  | $ | 15,077 |  |  | 7.9 |  |
| Selling and marketing | 141,063 |  |  | 14.7 |  | 162,010 |  |  | 14.8 |  | $ | 20,947 |  |  | 14.8 |  |
| General and administrative | 59,091 |  |  | 6.2 |  | 61,979 |  |  | 5.7 |  | $ | 2,888 |  |  | 4.9 |  |
| Amortization of intangible assets | 24,892 |  |  | 2.6 |  | 23,932 |  |  | 2.2 |  | (960 | ) |  | (3.9 | ) |
| Restructuring costs | 6,539 |  |  | 0.7 |  | 115 |  |  | — |  | (6,424 | ) |  | (98.2 | ) |
| Total operating expenses | $ | 421,497 |  |  | 44.0 |  | $ | 453,025 |  |  | 41.4 |  | $ | 31,528 |  |  | 7.5 |  |

[0000936395-14-000040:mdna:154]
_____________________________________

[0000936395-14-000040:mdna:155]
*    Denotes % of total revenue

[0000936395-14-000040:mdna:156]
**    Denotes % change from 2013 to 2014

[0000936395-14-000040:mdna:157]
| • | Research and development expense benefited by $9.6 million, as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Canadian Dollar. The increase of $15.1 million primarily reflects increases of $6.8 million in professional services expense, $4.3 million in prototype expense and $3.8 million in employee compensation and related costs. |

[0000936395-14-000040:mdna:158]
| • | Selling and marketing expense increased $20.9 million, primarily reflecting increases of $18.9 million in employee compensation and related costs and $3.0 million of travel and related costs. These increases were partially offset by a $1.0 million decrease in customer demonstration equipment expense. |

[0000936395-14-000040:mdna:159]
| • | General and administrative expense increased $2.9 million, reflecting a $2.0 million patent litigation settlement and a $1.0 million increase in employee compensation and related costs. |

[0000936395-14-000040:mdna:160]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-14-000040:mdna:161]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and restructuring activities to align our workforce and resources with market opportunities and research and development initiatives. Restructuring costs for fiscal 2013 also include the consolidation of certain facilities located within Maryland associated with the transition of our headquarters facility. |

[0000936395-14-000040:mdna:162]
Other items

[0000936395-14-000040:mdna:163]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-14-000040:mdna:164]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (2,853 | ) |  | (0.3 | ) |  | $ | (7,903 | ) |  | (0.7 | ) |  | $ | (5,050 | ) |  | 177.0 |  |
| Interest expense | $ | 22,124 |  |  | 2.3 |  |  | $ | 22,048 |  |  | 2.0 |  |  | $ | (76 | ) |  | (0.3 | ) |
| Loss on extinguishment of debt | $ | 28,630 |  |  | 3.0 |  |  | $ | — |  |  | 0.0 |  |  | $ | (28,630 | ) |  | (100.0 | ) |
| Provision for income taxes | $ | 4,607 |  |  | 0.5 |  |  | $ | 6,660 |  |  | 0.6 |  |  | $ | 2,053 |  |  | 44.6 |  |

[0000936395-14-000040:mdna:165]
_____________________________________

[0000936395-14-000040:mdna:166]
*    Denotes % of total revenue

[0000936395-14-000040:mdna:167]
**    Denotes % change from 2013 to 2014

[0000936395-14-000040:mdna:168]
| • | Interest and other income (loss), net reflects a $3.0 million non-cash loss related to the change in fair value of the embedded redemption feature associated with our 2015 Notes and a $1.8 million loss related to foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-14-000040:mdna:169]
| • | Interest expense remained relatively unchanged. |

[0000936395-14-000040:mdna:170]
| • | Loss on extinguishment of debt for fiscal 2013 reflects a non-cash loss of $28.6 million relating to the exchange transactions during the first quarter of fiscal 2013. Upon issuance, the 4.0% convertible senior notes due December 15, 2020 (the "2020 Notes") were recorded at a fair value of $213.6 million. The exchange transactions resulted in the retirement of outstanding 2015 Notes with a carrying value of $187.9 million and the write-off of unamortized debt issuance costs of $2.3 million and $0.6 million relating to the redemption feature on the 2015 Notes, which was accounted for as a separate embedded derivative. |

[0000936395-14-000040:mdna:171]
| • | Provision for income taxes increased primarily due to foreign tax expense, which is largely a result of higher income from our Brazilian operations. |

[0000936395-14-000040:mdna:172]
[same as prior period, unchanged from 0000936395-14-000021:mdna:116]

[0000936395-14-000040:mdna:173]
[same as prior period, unchanged from 0000936395-14-000021:mdna:117]

[0000936395-14-000040:mdna:174]
|  | Quarter Ended April 30, |  |  |  |
|  | 2013 |  | 2014 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 57,528 |  |  | $ | 96,581 |  |  | $ | 39,053 |  |  | 67.9 |  |
| Packet Networking | $ | 2,556 |  |  | $ | 8,196 |  |  | $ | 5,640 |  |  | 220.7 |  |
| Optical Transport | $ | 21,413 |  |  | $ | 4,709 |  |  | $ | (16,704 | ) |  | (78.0 | ) |
| Software and Services | $ | 27,229 |  |  | $ | 24,713 |  |  | $ | (2,516 | ) |  | (9.2 | ) |

[0000936395-14-000040:mdna:175]
_____________________________________

[0000936395-14-000040:mdna:176]
[same as prior period, unchanged from 0000936395-14-000021:mdna:120]

[0000936395-14-000040:mdna:177]
| • | Converged Packet Optical segment profit increased, primarily due to increased sales volume and improved gross margin, partially offset by increased research and development expense. The increased sales volume is largely driven by service provider demand for convergence of high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. The improved gross margin is primarily due to sales reflecting a greater mix of higher-margin packet platforms with software content within the segment. |

[0000936395-14-000040:mdna:178]
| • | Packet Networking segment profit increased slightly due to increased sales volume and improved gross margin, partially offset by increased research and development expense. Packet Networking revenue benefited from the expansion of Ethernet business services by our North American service provider customers and sales of service delivery and aggregation products in support of their related network initiatives. Gross margin improved due to sales reflecting a greater mix of higher-margin platforms with software content within the segment. |

[0000936395-14-000040:mdna:179]
| • | Optical Transport segment profit decreased, primarily due to reduced sales volume and lower gross margin. The decrease in gross margin is primarily due to an increase in obsolete and excess inventory expense for the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-14-000040:mdna:180]
| • | Software and Services segment profit decreased primarily due to higher shipping and warehousing costs for our maintenance services. These higher costs are largely due to the expansion of our international activities. |

[0000936395-14-000040:mdna:181]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-14-000040:mdna:182]
|  | Six Months Ended April 30, |  |  |  |
|  | 2013 |  | 2014 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 104,646 |  |  | $ | 175,279 |  |  | $ | 70,633 |  |  | 67.5 |  |
| Packet Networking | $ | 7,639 |  |  | $ | 8,581 |  |  | $ | 942 |  |  | 12.3 |  |
| Optical Transport | $ | 42,000 |  |  | $ | 20,359 |  |  | $ | (21,641 | ) |  | (51.5 | ) |
| Software and Services | $ | 61,111 |  |  | $ | 54,334 |  |  | $ | (6,777 | ) |  | (11.1 | ) |

[0000936395-14-000040:mdna:183]
_____________________________________

[0000936395-14-000040:mdna:184]
*    Denotes % change from 2013 to 2014

[0000936395-14-000040:mdna:185]
| • | Converged Packet Optical segment profit increased, primarily due to increased sales volume and improved gross margin, partially offset by increased research and development expense. The increased sales volume is largely driven by service provider demand for convergence of high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. The improved gross margin is primarily due to sales reflecting a greater mix of higher-margin packet platforms with software content within the segment. |

[0000936395-14-000040:mdna:186]
| • | Packet Networking segment profit increased slightly due to increased sales volume and improved gross margin, partially offset by increased research and development expense. Packet Networking revenue benefited from the |

[0000936395-14-000040:mdna:187]
39

[0000936395-14-000040:mdna:188]
expansion of Ethernet business services by our North American service provider customers and sales of service delivery and aggregation products in support of their related network initiatives. Gross margin improved due to sales reflecting a greater mix of higher-margin platforms with software content within the segment.

[0000936395-14-000040:mdna:189]
| • | Optical Transport segment profit decreased, primarily due to reduced sales volume and lower gross margin, partially offset by lower research and development expense. The decrease in gross margin is primarily due to an increase in obsolete and excess inventory expense for the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-14-000040:mdna:190]
| • | Software and Services segment profit decreased, primarily due to due to higher shipping and warehousing costs for our maintenance services. These higher costs are largely due the expansion of our international activities. |

[0000936395-14-000040:mdna:191]
[same as prior period, unchanged from 0000936395-14-000021:mdna:125]

[0000936395-14-000040:mdna:192]
At April 30, 2014, our principal sources of liquidity were cash and cash equivalents, short-term investments and long-term investments in marketable debt securities, representing U.S. treasuries and commercial paper. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-14-000040:mdna:193]
|  | October 31, 2013 |  | April 30, 2014 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 346,487 |  |  | $ | 325,083 |  |  | $ | (21,404 | ) |
| Short-term investments in marketable debt securities | 124,979 |  |  | 90,049 |  |  | (34,930 | ) |
| Long-term investments in marketable debt securities | 15,031 |  |  | 15,042 |  |  | 11 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 486,497 |  |  | $ | 430,174 |  |  | $ | (56,323 | ) |

[0000936395-14-000040:mdna:194]
The change in total cash and cash equivalents and investments in marketable debt securities during the first six months of fiscal 2014 was primarily related to the following:

[0000936395-14-000040:mdna:195]
| • | $35.2 million cash used in operations, consisting of $90.8 million provided by net loss (adjusted for non-cash charges) and $126.0 million used in working capital; |

[0000936395-14-000040:mdna:196]
| • | $26.5 million used for purchases of equipment, furniture, and fixtures and intellectual property; |

[0000936395-14-000040:mdna:197]
| • | $4.0 million used in settlement of foreign currency forward contracts, net; |

[0000936395-14-000040:mdna:198]
| • | $1.5 million used in relation to payment of capital lease obligations; and |

[0000936395-14-000040:mdna:199]
| • | $9.0 million provided by stock issuances under our employee stock purchase plan and exercise of stock options. |

[0000936395-14-000040:mdna:200]
As of April 30, 2014, letters of credit totaling $58.7 million were collateralized by our senior secured asset-based revolving credit facility (the “Credit Facility”). There were no borrowings outstanding under the Credit Facility as of April 30, 2014. See "Asset-Backed Credit Facility" below for additional information.

[0000936395-14-000040:mdna:201]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our Credit Facility, will satisfy the working capital needs, capital expenditures, the repayment of our outstanding 4.0% convertible senior notes due March 15, 2015 and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-14-000040:mdna:202]
The following sections set forth the components of our $35.2 million of cash used in by operating activities during the first six months of fiscal 2014:

[0000936395-14-000040:mdna:203]
[same as prior period, unchanged from 0000936395-14-000021:mdna:136]

[0000936395-14-000040:mdna:204]
[same as prior period, unchanged from 0000936395-14-000021:mdna:137]

[0000936395-14-000040:mdna:205]
|  | Six months ended |
|  | April 30, 2014 |
| Net loss | $ | (26,094 | ) |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 27,143 |  |
| Share-based compensation costs | 23,443 |  |
| Amortization of intangible assets | 30,712 |  |
| Provision for inventory excess and obsolescence | 12,972 |  |
| Provision for warranty | 12,424 |  |
| Other | 10,164 |  |
| Net loss (adjusted for non-cash charges) | $ | 90,764 |  |

[0000936395-14-000040:mdna:206]
[same as prior period, unchanged from 0000936395-14-000021:mdna:139]

[0000936395-14-000040:mdna:207]
[same as prior period, unchanged from 0000936395-14-000021:mdna:140]

[0000936395-14-000040:mdna:208]
Cash used by an increase in accounts receivable during the first six months of fiscal 2014, net of a $1.2 million provision for doubtful accounts, was $27.6 million. This reflects both increases in our revenues and days sales outstanding (DSOs). Our DSOs increased from 79 days for the first six months of fiscal 2013 to 85 days for the first six months of fiscal 2014. The increase in DSOs primarily reflects growth in certain new international customers whose contracts have longer payment terms.

[0000936395-14-000040:mdna:209]
The following table sets forth (in thousands) changes to our accounts receivable, net of allowance for doubtful accounts, from the end of fiscal 2013 through the end of the second quarter of fiscal 2014:

[0000936395-14-000040:mdna:210]
|  | October 31, 2013 |  | April 30, 2014 |  | Increase(decrease) |
| Accounts receivable, net | $ | 488,578 |  |  | $ | 514,973 |  |  | $ | 26,395 |  |

[0000936395-14-000040:mdna:211]
[same as prior period, unchanged from 0000936395-14-000021:mdna:144]

[0000936395-14-000040:mdna:212]
Cash used by an increase in inventory during the first six months of fiscal 2014 was $57.8 million. The increase in inventory reflects our decision to carry more finished goods inventory for our Converged Packet Optical products to reduce our lead times for shipments to customers and  higher deferred cost of goods sold for shipments awaiting acceptance. Our inventory turns decreased from 3.5 turns during the first six months of fiscal 2013 to 3.4 turns during the first six months of fiscal 2014. During the first six months of fiscal 2014 the net increase in inventory was $44.8 million which reflects a $13.0 million non-cash provision taken for excess and obsolescence. The following table sets forth (in thousands) changes to the components of our inventory from the end of fiscal 2013 through the end of the second quarter of fiscal 2014:

[0000936395-14-000040:mdna:213]
|  | October 31, 2013 |  | April 30, 2014 |  | Increase(decrease) |
| Raw materials | $ | 53,274 |  |  | $ | 56,689 |  |  | $ | 3,415 |  |
| Work-in-process | 7,773 |  |  | 7,919 |  |  | 146 |  |
| Finished goods | 153,855 |  |  | 181,020 |  |  | 27,165 |  |
| Deferred cost of goods sold | 75,764 |  |  | 95,783 |  |  | 20,019 |  |
| Gross inventory | 290,666 |  |  | 341,411 |  |  | 50,745 |  |
| Provision for inventory excess and obsolescence | (41,563 | ) |  | (47,459 | ) |  | (5,896 | ) |
| Inventory | $ | 249,103 |  |  | $ | 293,952 |  |  | $ | 44,849 |  |

[0000936395-14-000040:mdna:214]
[same as prior period, unchanged from 0000936395-14-000021:mdna:148]

[0000936395-14-000040:mdna:215]
Cash used by an increase in prepaid expense and other during the first six months of fiscal 2014 was $19.1 million primarily related to higher product demonstration equipment, other non-trade receivables and prepaid value added tax.

[0000936395-14-000040:mdna:216]
[same as prior period, unchanged from 0000936395-14-000021:mdna:150]

[0000936395-14-000040:mdna:217]
Utilization of cash resources for accounts payable, accruals and other obligations during the first six months of fiscal 2014 was $51.6 million, reflecting, among other things, the timing of the annual payment under our cash incentive compensation plan to employees with respect to amounts earned for fiscal 2013. Changes in accrued liabilities reflect a $12.4 million non-cash provision related to warranties. Changes in accounts payable reflect a decrease of $1.4 million for investing activities related to equipment purchases.

[0000936395-14-000040:mdna:218]
The following table sets forth (in thousands) changes in our accounts payable, accruals and other obligations from the end of fiscal 2013 through the end of the second quarter of fiscal 2014:

[0000936395-14-000040:mdna:219]
|  | October 31, 2013 |  | April 30, 2014 |  | Increase(decrease) |
| Accounts payable | $ | 254,849 |  |  | $ | 229,498 |  |  | $ | (25,351 | ) |
| Accrued liabilities | 271,656 |  |  | 254,436 |  |  | (17,220 | ) |
| Other long-term obligations | 34,753 |  |  | 35,789 |  |  | 1,036 |  |
| Accounts payable, accruals and other obligations | $ | 561,258 |  |  | $ | 519,723 |  |  | $ | (41,535 | ) |

[0000936395-14-000040:mdna:220]
Interest Paid on Convertible Notes and Credit Facility

[0000936395-14-000040:mdna:221]
Interest on our outstanding 4.0% convertible senior notes, due March 15, 2015, is payable on March 15 and September 15 of each year. We paid $3.8 million in interest on these convertible notes during the first six months of fiscal 2014.

[0000936395-14-000040:mdna:222]
Interest on our outstanding 0.875% convertible senior notes, due June 15, 2017, is payable on June 15 and December 15 of each year. We paid $2.2 million in interest on these convertible notes during the first six months of fiscal 2014.

[0000936395-14-000040:mdna:223]
Interest on our outstanding 3.75% convertible senior notes, due October 15, 2018, is payable on April 15 and October 15 of each year. We paid $6.6 million in interest on these convertible notes during the first six months of fiscal 2014.

[0000936395-14-000040:mdna:224]
Interest on our outstanding 4.0% convertible senior notes, due December 15, 2020, is payable on June 15 and December 15 of each year. We paid $3.8 million in interest on these convertible notes during the first six months of fiscal 2014.

[0000936395-14-000040:mdna:225]
During the first six months of fiscal 2014, we utilized the Credit Facility to collateralize certain standby letters of credit. We paid $0.8 million in commitment fees, interest expense and other administrative charges relating to the Credit Facility during the first six months of fiscal 2014.

[0000936395-14-000040:mdna:226]
[same as prior period, unchanged from 0000936395-14-000021:mdna:160]

[0000936395-14-000040:mdna:227]
Deferred revenue increased by $30.1 million during the first six months of fiscal 2014. Product deferred revenue represents either payments received in advance of shipment or payments received after shipment but before revenue recognition. Services deferred revenue is related to payment for service contracts for which revenue will be recognized over the contract term. The following table reflects (in thousands) the balance of deferred revenue and the change in this balance from the end of fiscal 2013 through the first six months of fiscal 2014:

[0000936395-14-000040:mdna:228]
|  | October 31, 2013 |  | April 30, 2014 |  | Increase(decrease) |
| Products | $ | 36,671 |  |  | $ | 64,326 |  |  | $ | 27,655 |  |
| Services | 75,499 |  |  | 77,967 |  |  | 2,468 |  |
| Total deferred revenue | $ | 112,170 |  |  | $ | 142,293 |  |  | $ | 30,123 |  |

[0000936395-14-000040:mdna:229]
Asset-Backed Credit Facility

[0000936395-14-000040:mdna:230]
During fiscal 2012, we entered into a $150.0 million senior secured asset-based revolving credit facility (the “Credit Facility”). The Credit Facility matures on August 13, 2015, provided that it will mature early on December 15, 2014, if any of Ciena's 2015 Notes are then outstanding. Ciena principally uses and expects to continue to use the Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to

[0000936395-14-000040:mdna:231]
collateralize these instruments. As of April 30, 2014, letters of credit totaling $58.7 million were collateralized by the Credit Facility. There were no borrowings outstanding under the Credit Facility as of April 30, 2014.

[0000936395-14-000040:mdna:232]
[same as prior period, unchanged from 0000936395-14-000021:mdna:165]

[0000936395-14-000040:mdna:233]
The following is a summary of our future minimum payments under contractual obligations as of April 30, 2014 (in thousands):

[0000936395-14-000040:mdna:234]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 1,254,627 |  |  | $ | 187,500 |  |  | $ | — |  |  | $ | 850,000 |  |  | $ | 217,127 |  |
| Interest due on convertible notes | 134,375 |  |  | 32,500 |  |  | 50,000 |  |  | 36,875 |  |  | 15,000 |  |
| Operating leases (2) | 156,672 |  |  | 32,159 |  |  | 53,904 |  |  | 22,699 |  |  | 47,910 |  |
| Purchase obligations (3) | 258,617 |  |  | 258,617 |  |  | — |  |  | — |  |  | — |  |
| Capital leases | 3,663 |  |  | 2,554 |  |  | 1,081 |  |  | 28 |  |  | — |  |
| Other obligations | 6,190 |  |  | 3,042 |  |  | 3,140 |  |  | 8 |  |  | — |  |
| Total (4) | $ | 1,814,144 |  |  | $ | 516,372 |  |  | $ | 108,125 |  |  | $ | 909,610 |  |  | $ | 280,037 |  |

[0000936395-14-000040:mdna:235]
_____________________________________

[0000936395-14-000040:mdna:236]
[same as prior period, unchanged from 0000936395-14-000021:mdna:169]

[0000936395-14-000040:mdna:237]
[same as prior period, unchanged from 0000936395-14-000021:mdna:170]

[0000936395-14-000040:mdna:238]
[same as prior period, unchanged from 0000936395-14-000021:mdna:171]

[0000936395-14-000040:mdna:239]
| (4) | As of April 30, 2014, we also had approximately $10.3 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-14-000040:mdna:240]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our Credit Facility or restricted cash.  Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of April 30, 2014 (in thousands):

[0000936395-14-000040:mdna:241]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years | Thereafter |
| Standby letters of credit | $ | 58,719 |  |  | $ | 29,758 |  |  | $ | 10,658 |  |  | $ | 4,375 |  | $ | 13,928 |  |

[0000936395-14-000040:mdna:242]
[same as prior period, unchanged from 0000936395-14-000021:mdna:176]

[0000936395-14-000040:mdna:243]
[same as prior period, unchanged from 0000936395-14-000021:mdna:177]

[0000936395-14-000040:mdna:244]
[same as prior period, unchanged from 0000936395-14-000021:mdna:178]

[0000936395-14-000040:mdna:245]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions.

[0000936395-14-000040:mdna:246]
To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-14-000040:mdna:247]
[same as prior period, unchanged from 0000936395-14-000021:mdna:180]

[0000936395-14-000040:mdna:248]
[same as prior period, unchanged from 0000936395-14-000021:mdna:181]

[0000936395-14-000040:mdna:249]
[same as prior period, unchanged from 0000936395-14-000021:mdna:182]

[0000936395-14-000040:mdna:250]
We apply the percentage-of-completion method to long-term arrangements where we are required to undertake significant production, customizations or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are accumulated in the contracts in progress account included in accounts receivable, net. Billings in excess of revenues recognized to date on these contracts are recorded within deferred revenue.

[0000936395-14-000040:mdna:251]
[same as prior period, unchanged from 0000936395-14-000021:mdna:184]

[0000936395-14-000040:mdna:252]
[same as prior period, unchanged from 0000936395-14-000021:mdna:185]

[0000936395-14-000040:mdna:253]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. We determine the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, we use vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, we use our best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-14-000040:mdna:254]
[same as prior period, unchanged from 0000936395-14-000021:mdna:188]

[0000936395-14-000040:mdna:255]
Our total deferred revenue for products was $36.7 million and $64.3 million as of October 31, 2013 and April 30, 2014, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $75.5 million and $78.0 million as of October 31, 2013 and April 30, 2014, respectively.

[0000936395-14-000040:mdna:256]
[same as prior period, unchanged from 0000936395-14-000021:mdna:190]

[0000936395-14-000040:mdna:257]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based

[0000936395-14-000040:mdna:258]
vesting conditions. We recognize the estimated fair value of service-based awards, net of estimated forfeitures, as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-14-000040:mdna:259]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 16 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of April 30, 2014, total unrecognized compensation expense was $72.4 million, which relates to unvested restricted stock units and this expense is expected to be recognized over a weighted-average period of 1.5 years.

[0000936395-14-000040:mdna:260]
[same as prior period, unchanged from 0000936395-14-000021:mdna:193]

[0000936395-14-000040:mdna:261]
[same as prior period, unchanged from 0000936395-14-000021:mdna:194]

[0000936395-14-000040:mdna:262]
[same as prior period, unchanged from 0000936395-14-000021:mdna:195]

[0000936395-14-000040:mdna:263]
For fiscal 2014, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2014. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for incentive compensation in any interim period in fiscal 2014 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are higher or lower than expected. We incurred an aggregate of $22.2 million of expense in the first six months of fiscal 2014 associated with our cash incentive bonus plan for fiscal 2014.

[0000936395-14-000040:mdna:264]
[same as prior period, unchanged from 0000936395-14-000021:mdna:197]

[0000936395-14-000040:mdna:265]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and

[0000936395-14-000040:mdna:266]
development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write-downs due to discontinuance of a product, changes in our strategic direction and declines in market conditions. We recorded charges for excess and obsolete inventory of $9.0 million and $13.0 million in the first six months of fiscal 2013 and 2014, respectively. The charges in fiscal 2014 primarily related to engineering design changes and the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform, and Converged Packet Optical products. Our inventory net of allowance for excess and obsolescence was $249.1 million and $294.0 million as of October 31, 2013 and April 30, 2014, respectively.

[0000936395-14-000040:mdna:267]
[same as prior period, unchanged from 0000936395-14-000021:mdna:199]

[0000936395-14-000040:mdna:268]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $488.6 million and $515.0 million as of October 31, 2013 and April 30, 2014, respectively. Our allowance for doubtful accounts was $2.0 million and $1.7 million as of October 31, 2013 and April 30, 2014, respectively.

[0000936395-14-000040:mdna:269]
[same as prior period, unchanged from 0000936395-14-000021:mdna:201]

[0000936395-14-000040:mdna:270]
Our long-lived assets include: equipment, furniture and fixtures, finite-lived intangible assets and maintenance spares. As of October 31, 2013 and April 30, 2014, these assets totaled $366.9 million and $331.1 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represents the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-14-000040:mdna:271]
[same as prior period, unchanged from 0000936395-14-000021:mdna:203]

[0000936395-14-000040:mdna:272]
As of April 30, 2014, we have recorded a valuation allowance offsetting substantially all our net deferred tax assets of $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to make judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies and tax planning strategies. The valuation allowance is reviewed quarterly and is maintained until sufficient positive evidence exists to support a reversal. Because evidence such as our operating results during the most recent three-year period is afforded more weight than forecasted results for future periods, our cumulative loss during this three-year period represents sufficient negative evidence regarding the need for nearly a full valuation allowance. We will release this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-14-000040:mdna:273]
[same as prior period, unchanged from 0000936395-14-000021:mdna:206]

[0000936395-14-000040:mdna:274]
Our liability for product warranties, included in other accrued liabilities, was $56.3 million and $56.2 million as of October 31, 2013 and April 30, 2014, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $11.1 million and $12.4 million for the first six months of fiscal 2013 and 2014, respectively. See Note 11 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to

[0000936395-14-000040:mdna:275]
the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
