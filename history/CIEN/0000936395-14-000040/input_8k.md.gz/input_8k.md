# CIEN 8-K — 0000936395-14-000037 filed 2014-06-05

## item codes, every 8-K on or before 2014-06-11

- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2014-06-11

- none on or before 2014-06-11

## item 2.02 — earnings release, exhibit 99.1

[0000936395-14-000037:8k_2_02:1]
EX-99.1
2
a2014q210qpressrelease.htm
EXHIBIT

[0000936395-14-000037:8k_2_02:2]
2014 Q2 10Q Press Release

[0000936395-14-000037:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-14-000037:8k_2_02:4]
Ciena Reports Fiscal Second Quarter 2014 Financial Results

[0000936395-14-000037:8k_2_02:5]
Delivers 10% year-over-year revenue growth and 6% adjusted operating margin

[0000936395-14-000037:8k_2_02:6]
Diversifying business drives continued growth and differentiated performance

[0000936395-14-000037:8k_2_02:7]
HANOVER, Md. - June 5, 2014 - Ciena® Corporation (NYSE:  CIEN), the network specialist, today announced unaudited financial results for its fiscal second quarter ended April 30, 2014.

[0000936395-14-000037:8k_2_02:8]
For the fiscal second quarter 2014, Ciena reported revenue of $560.0 million as compared to $507.7 million for the fiscal second quarter 2013.

[0000936395-14-000037:8k_2_02:9]
On the basis of generally accepted accounting principles (GAAP), Ciena's net loss for the fiscal second quarter 2014 was $(10.2) million, or $(0.10) per common share, which compares to a GAAP net loss of $(27.1) million, or $(0.27) per common share, for the fiscal second quarter 2013.

[0000936395-14-000037:8k_2_02:10]
Ciena's adjusted (non-GAAP) net income for the fiscal second quarter 2014 was $19.4 million, or $0.17 per diluted common share, which compares to an adjusted (non-GAAP) net income of $2.2 million, or $0.02 per diluted common share, for the fiscal second quarter 2013.

[0000936395-14-000037:8k_2_02:11]
“As a direct result of our expanding role and reach in the industry, we delivered strong financial results in both our second quarter and first half of fiscal 2014, including continued revenue growth and increased operating leverage,” said Gary B. Smith, president and CEO, Ciena. “As the shift continues toward on-demand networking models and as we continue to diversify our business, we expect to deliver steadily improving financial performance, including performance in the second half of the year that is stronger than the first half.”

[0000936395-14-000037:8k_2_02:12]
Fiscal Second Quarter 2014 Performance Summary

[0000936395-14-000037:8k_2_02:13]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarter and year-over-year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendix A.

[0000936395-14-000037:8k_2_02:14]
|  |  | GAAP Results |
|  |  | Q2 |  | Q1 |  | Q2 |  | Period Change |
|  |  | FY 2014 |  | FY 2014 |  | FY 2013 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 560.0 |  |  | $ | 533.7 |  |  | $ | 507.7 |  |  | 4.9 | % |  | 10.3 | % |
| Gross margin |  | 42.4 | % |  | 42.3 | % |  | 41.3 | % |  | 0.1 | % |  | 1.1 | % |
| Operating expense |  | $ | 230.5 |  |  | $ | 222.5 |  |  | $ | 220.1 |  |  | 3.6 | % |  | 4.7 | % |
| Operating margin |  | 1.3 | % |  | 0.6 | % |  | (2.1 | )% |  | 0.7 | % |  | 3.4 | % |

[0000936395-14-000037:8k_2_02:15]
|  |  | Non-GAAP Results |
|  |  | Q2 |  | Q1 |  | Q2 |  | Period Change |
|  |  | FY 2014 |  | FY 2014 |  | FY 2013 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 560.0 |  |  | $ | 533.7 |  |  | $ | 507.7 |  |  | 4.9 | % |  | 10.3 | % |
| Adj. gross margin |  | 43.1 | % |  | 43.4 | % |  | 42.5 | % |  | (0.3 | )% |  | 0.6 | % |
| Adj. operating expense |  | $ | 206.3 |  |  | $ | 199.8 |  |  | $ | 197.4 |  |  | 3.3 | % |  | 4.5 | % |
| Adj. operating margin |  | 6.2 | % |  | 5.9 | % |  | 3.7 | % |  | 0.3 | % |  | 2.5 | % |

[0000936395-14-000037:8k_2_02:16]
|  |  | Revenue by Segment |
|  |  | Q2 FY 2014 |  | Q1 FY 2014 |  | Q2 FY 2013 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| Converged Packet Optical |  | $ | 356.8 |  |  | 63.7 |  | $ | 333.4 |  |  | 62.5 |  | $ | 294.3 |  |  | 57.9 |
| Packet Networking |  | 66.5 |  |  | 11.9 |  | 51.7 |  |  | 9.7 |  | 54.2 |  |  | 10.7 |
| Optical Transport |  | 29.6 |  |  | 5.3 |  | 40.1 |  |  | 7.5 |  | 57.4 |  |  | 11.3 |
| Software and Services |  | 107.1 |  |  | 19.1 |  | 108.5 |  |  | 20.3 |  | 101.8 |  |  | 20.1 |
| Total |  | $ | 560.0 |  |  | 100.0 |  | $ | 533.7 |  |  | 100.0 |  | $ | 507.7 |  |  | 100.0 |

[0000936395-14-000037:8k_2_02:17]
| * Denotes % change, or in the case of margin, absolute change |  |  |  |  |  |  |

[0000936395-14-000037:8k_2_02:18]
Additional Performance Metrics for Fiscal Second Quarter 2014

[0000936395-14-000037:8k_2_02:19]
| • | Non-U.S. customers contributed 42% of total revenue |

[0000936395-14-000037:8k_2_02:20]
| • | One customer accounted for greater than 10% of revenue and represented 21.5% of total revenue |

[0000936395-14-000037:8k_2_02:21]
| • | Cash and investments totaled $430.2 million |

[0000936395-14-000037:8k_2_02:22]
| • | Cash flow from operations totaled $2.0 million |

[0000936395-14-000037:8k_2_02:23]
| • | Average days' sales outstanding (DSOs) were 83 |

[0000936395-14-000037:8k_2_02:24]
| • | Accounts receivable balance was $515.0 million |

[0000936395-14-000037:8k_2_02:25]
| • | Inventories totaled $294.0 million, including: |

[0000936395-14-000037:8k_2_02:26]
| ◦ | Raw materials: $56.7 million |

[0000936395-14-000037:8k_2_02:27]
| ◦ | Work in process: $7.9 million |

[0000936395-14-000037:8k_2_02:28]
| ◦ | Finished goods: $181.0 million |

[0000936395-14-000037:8k_2_02:29]
| ◦ | Deferred cost of sales: $95.9 million |

[0000936395-14-000037:8k_2_02:30]
| ◦ | Reserve for excess and obsolescence: $(47.5) million |

[0000936395-14-000037:8k_2_02:31]
| • | Product inventory turns were 3.5 |

[0000936395-14-000037:8k_2_02:32]
| • | Headcount totaled 4,998 |

[0000936395-14-000037:8k_2_02:33]
Business Outlook for Fiscal Third Quarter 2014

[0000936395-14-000037:8k_2_02:34]
Statements relating to business outlook are forward-looking in nature and actual results may differ materially. These statements should be read in the context of the Notes to Investors below.

[0000936395-14-000037:8k_2_02:35]
Ciena expects fiscal third quarter 2014 financial performance to include:

[0000936395-14-000037:8k_2_02:36]
| • | Revenue in the range of $585 to $615 million |

[0000936395-14-000037:8k_2_02:37]
| • | Adjusted (non-GAAP) gross margin in the low to mid 40s percent range |

[0000936395-14-000037:8k_2_02:38]
| • | Adjusted (non-GAAP) operating expense to be approximately $210 million range |

[0000936395-14-000037:8k_2_02:39]
Live Web Broadcast of Unaudited Fiscal Second Quarter 2014 Results

[0000936395-14-000037:8k_2_02:40]
Ciena will host a discussion of its unaudited fiscal second quarter 2014 results with investors and financial analysts today, Thursday, June 5, 2014 at 8:30 a.m. (Eastern). The live broadcast of the discussion will be available via Ciena's homepage at www.ciena.com. An archived transcript of the discussion will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at www.ciena.com/investors.

[0000936395-14-000037:8k_2_02:41]
To accompany its live broadcast, Ciena has posted to the Investor Relations page of its website at www.ciena.com/investors a presentation that includes certain highlighted information to be discussed on the call and certain historical results of operations.

[0000936395-14-000037:8k_2_02:42]
Notes to Investors

[0000936395-14-000037:8k_2_02:43]
Forward-looking statements. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include Ciena's "Business Outlook for Fiscal Third Quarter of 2014" as well as: "Diversifying business drives continued growth and differentiated performance"; “As a direct result of our expanding role and reach in the industry, we delivered strong financial results in both our second quarter and first half of fiscal 2014, including continued revenue growth and increased operating leverage.”; “As the shift continues toward on-demand networking models and as we continue to diversify our business, we expect to deliver steadily improving financial performance, including performance in the second half of the year that is stronger than the first half.”

[0000936395-14-000037:8k_2_02:44]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-Q, which Ciena filed with the Securities and Exchange Commission on March 7, 2014. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-14-000037:8k_2_02:45]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income (loss) from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not  expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release,

[0000936395-14-000037:8k_2_02:46]
Appendix A to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-14-000037:8k_2_02:47]
About Ciena.  Ciena (NYSE: CIEN) is the network specialist. We collaborate with customers worldwide to unlock the strategic potential of their networks and fundamentally change the way they perform and compete. Ciena leverages its deep expertise in packet and optical networking and distributed software automation to deliver solutions in alignment with its OPn architecture for next-generation networks. We enable a high-scale, programmable infrastructure that can be controlled and adapted by network-level applications, and provide open interfaces to coordinate computing, storage and network resources in a unified, virtualized environment. For updates on Ciena news, follow us on Twitter @Ciena or on LinkedIn at http://www.linkedin.com/company/ciena. Investors are encouraged to review the Investors section of our website at www.ciena.com/investors, where we routinely post press releases, SEC filings, recent news, financial results, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use.

[0000936395-14-000037:8k_2_02:48]
CIENA CORPORATION

[0000936395-14-000037:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-14-000037:8k_2_02:50]
(in thousands, except per share data)

[0000936395-14-000037:8k_2_02:51]
(unaudited)

[0000936395-14-000037:8k_2_02:52]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 413,217 |  |  | $ | 460,821 |  |  | $ | 766,274 |  |  | $ | 893,762 |  |
| Services | 94,495 |  |  | 99,240 |  |  | 194,531 |  |  | 200,002 |  |
| Total revenue | 507,712 |  |  | 560,061 |  |  | 960,805 |  |  | 1,093,764 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 239,441 |  |  | 257,632 |  |  | 435,962 |  |  | 502,848 |  |
| Services | 58,758 |  |  | 64,738 |  |  | 119,535 |  |  | 127,374 |  |
| Total cost of goods sold | 298,199 |  |  | 322,370 |  |  | 555,497 |  |  | 630,222 |  |
| Gross profit | 209,513 |  |  | 237,691 |  |  | 405,308 |  |  | 463,542 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 100,787 |  |  | 103,492 |  |  | 189,912 |  |  | 204,989 |  |
| Selling and marketing | 74,475 |  |  | 83,662 |  |  | 141,063 |  |  | 162,010 |  |
| General and administrative | 30,883 |  |  | 31,882 |  |  | 59,091 |  |  | 61,979 |  |
| Amortization of intangible assets | 12,439 |  |  | 11,493 |  |  | 24,892 |  |  | 23,932 |  |
| Restructuring costs | 1,509 |  |  | — |  |  | 6,539 |  |  | 115 |  |
| Total operating expenses | 220,093 |  |  | 230,529 |  |  | 421,497 |  |  | 453,025 |  |
| Income (loss) from operations | (10,580 | ) |  | 7,162 |  |  | (16,189 | ) |  | 10,517 |  |
| Interest and other income (loss), net | (2,716 | ) |  | (1,905 | ) |  | (2,853 | ) |  | (7,903 | ) |
| Interest expense | (11,392 | ) |  | (11,020 | ) |  | (22,124 | ) |  | (22,048 | ) |
| Loss on extinguishment of debt | — |  |  | — |  |  | (28,630 | ) |  | — |  |
| Loss before income taxes | (24,688 | ) |  | (5,763 | ) |  | (69,796 | ) |  | (19,434 | ) |
| Provision for income taxes | 2,391 |  |  | 4,395 |  |  | 4,607 |  |  | 6,660 |  |
| Net loss | $ | (27,079 | ) |  | $ | (10,158 | ) |  | $ | (74,403 | ) |  | $ | (26,094 | ) |
| Basic net loss per common share | $ | (0.27 | ) |  | $ | (0.10 | ) |  | $ | (0.73 | ) |  | $ | (0.25 | ) |
| Diluted net loss per potential common share | $ | (0.27 | ) |  | $ | (0.10 | ) |  | $ | (0.73 | ) |  | $ | (0.25 | ) |
| Weighted average basic common shares outstanding | 101,913 |  |  | 105,451 |  |  | 101,560 |  |  | 104,977 |  |
| Weighted average dilutive potential common shares outstanding | 101,913 |  |  | 105,451 |  |  | 101,560 |  |  | 104,977 |  |

[0000936395-14-000037:8k_2_02:53]
CIENA CORPORATION

[0000936395-14-000037:8k_2_02:54]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-14-000037:8k_2_02:55]
(in thousands, except share data)

[0000936395-14-000037:8k_2_02:56]
(unaudited)

[0000936395-14-000037:8k_2_02:57]
|  | October 31, 2013 |  | April 30, 2014 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 346,487 |  |  | $ | 325,083 |  |
| Short-term investments | 124,979 |  |  | 90,049 |  |
| Accounts receivable, net | 488,578 |  |  | 514,973 |  |
| Inventories | 249,103 |  |  | 293,952 |  |
| Prepaid expenses and other | 186,655 |  |  | 207,279 |  |
| Total current assets | 1,395,802 |  |  | 1,431,336 |  |
| Long-term investments | 15,031 |  |  | 15,042 |  |
| Equipment, furniture and fixtures, net | 119,729 |  |  | 119,876 |  |
| Other intangible assets, net | 185,828 |  |  | 155,117 |  |
| Other long-term assets | 86,380 |  |  | 74,093 |  |
| Total assets | $ | 1,802,770 |  |  | $ | 1,795,464 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 254,849 |  |  | $ | 229,498 |  |
| Accrued liabilities | 271,656 |  |  | 254,436 |  |
| Deferred revenue | 88,550 |  |  | 118,473 |  |
| Convertible notes payable | — |  |  | 187,647 |  |
| Total current liabilities | 615,055 |  |  | 790,054 |  |
| Long-term deferred revenue | 23,620 |  |  | 23,820 |  |
| Other long-term obligations | 34,753 |  |  | 35,789 |  |
| Long-term convertible notes payable | 1,212,019 |  |  | 1,026,641 |  |
| Total liabilities | $1,885,447 |  | $1,876,304 |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity (deficit): |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 103,705,709 and 105,584,958 shares issued and outstanding | 1,037 |  |  | 1,056 |  |
| Additional paid-in capital | 5,893,880 |  |  | 5,926,276 |  |
| Accumulated other comprehensive loss | (7,774 | ) |  | (12,258 | ) |
| Accumulated deficit | (5,969,820 | ) |  | (5,995,914 | ) |
| Total stockholders’ equity (deficit) | (82,677 | ) |  | (80,840 | ) |
| Total liabilities and stockholders’ equity (deficit) | $ | 1,802,770 |  |  | $ | 1,795,464 |  |

[0000936395-14-000037:8k_2_02:58]
CIENA CORPORATION

[0000936395-14-000037:8k_2_02:59]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-14-000037:8k_2_02:60]
(in thousands)

[0000936395-14-000037:8k_2_02:61]
(unaudited)

[0000936395-14-000037:8k_2_02:62]
|  | Six Months Ended April 30, |
|  | 2013 |  | 2014 |
| Cash flows used in operating activities: |  |  |  |
| Net loss | $ | (74,403 | ) |  | $ | (26,094 | ) |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Loss on extinguishment of debt | 28,630 |  |  | — |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 28,857 |  |  | 27,143 |  |
| Share-based compensation costs | 18,147 |  |  | 23,443 |  |
| Amortization of intangible assets | 35,661 |  |  | 30,712 |  |
| Provision for inventory excess and obsolescence | 9,027 |  |  | 12,972 |  |
| Provision for warranty | 11,060 |  |  | 12,424 |  |
| Other | 5,068 |  |  | 10,164 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (76,526 | ) |  | (27,548 | ) |
| Inventories | 2,975 |  |  | (57,821 | ) |
| Prepaid expenses and other | (33,969 | ) |  | (19,054 | ) |
| Accounts payable, accruals and other obligations | 24,805 |  |  | (51,631 | ) |
| Deferred revenue | 19,799 |  |  | 30,123 |  |
| Net cash used in operating activities | (869 | ) |  | (35,167 | ) |
| Cash flows provided by (used in) investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (21,496 | ) |  | (26,485 | ) |
| Restricted cash | 1,679 |  |  | 1,912 |  |
| Purchase of available for sale securities | (99,914 | ) |  | (95,033 | ) |
| Proceeds from maturities of available for sale securities | 50,000 |  |  | 130,000 |  |
| Settlement of foreign currency forward contracts, net | — |  |  | (4,029 | ) |
| Net cash provided by (used in) investing activities | (69,731 | ) |  | 6,365 |  |
| Cash flows from financing activities: |  |  |  |
| Payment of long term debt | (216,210 | ) |  | — |  |
| Payment for debt and equity issuance costs | (3,661 | ) |  | — |  |
| Payment of capital lease obligations | (1,427 | ) |  | (1,520 | ) |
| Proceeds from issuance of common stock | 5,955 |  |  | 8,970 |  |
| Net cash provided by (used in) financing activities | (215,343 | ) |  | 7,450 |  |
| Effect of exchange rate changes on cash and cash equivalents | (3 | ) |  | (52 | ) |
| Net decrease in cash and cash equivalents | (285,943 | ) |  | (21,352 | ) |
| Cash and cash equivalents at beginning of period | 642,444 |  |  | 346,487 |  |
| Cash and cash equivalents at end of period | $ | 356,498 |  |  | $ | 325,083 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 15,720 |  |  | $ | 17,047 |  |
| Cash paid during the period for income taxes, net | $ | 5,136 |  |  | $ | 7,221 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 3,006 |  |  | $ | 4,799 |  |
| Fixed assets acquired under capital leases | $ | 1,286 |  |  | $ | — |  |

[0000936395-14-000037:8k_2_02:63]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements |
|  |  | Quarter Ended |
|  |  | April 30, |
|  |  | 2013 |  | 2014 |
| Gross Profit Reconciliation |  |  |  |  |
| GAAP gross profit |  | $ | 209,513 |  |  | $ | 237,691 |  |
| Share-based compensation-products |  | 686 |  |  | 741 |  |
| Share-based compensation-services |  | 435 |  |  | 568 |  |
| Amortization of intangible assets |  | 5,384 |  |  | 2,328 |  |
| Total adjustments related to gross profit |  | 6,505 |  |  | 3,637 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 216,018 |  |  | $ | 241,328 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 42.5 | % |  | 43.1 | % |
| Operating Expense Reconciliation |  |  |  |  |
| GAAP operating expense |  | $ | 220,093 |  |  | $ | 230,529 |  |
| Share-based compensation-research and development |  | 2,204 |  |  | 2,782 |  |
| Share-based compensation-sales and marketing |  | 3,382 |  |  | 4,246 |  |
| Share-based compensation-general and administrative |  | 3,144 |  |  | 3,661 |  |
| Amortization of intangible assets |  | 12,439 |  |  | 11,493 |  |
| Restructuring costs |  | 1,509 |  |  | — |  |
| Settlement of patent litigation |  | — |  |  | 2,000 |  |
| Total adjustments related to operating expense |  | 22,678 |  |  | 24,182 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 197,415 |  |  | $ | 206,347 |  |
| Income (Loss) from Operations Reconciliation |  |  |  |  |
| GAAP income (loss) from operations |  | $ | (10,580 | ) |  | $ | 7,162 |  |
| Total adjustments related to gross profit |  | 6,505 |  |  | 3,637 |  |
| Total adjustments related to operating expense |  | 22,678 |  |  | 24,182 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 18,603 |  |  | 34,981 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 3.7 | % |  | 6.2 | % |
| Net Income (Loss) Reconciliation |  |  |  |  |
| GAAP net loss |  | $ | (27,079 | ) |  | $ | (10,158 | ) |
| Total adjustments related to gross profit |  | 6,505 |  |  | 3,637 |  |
| Total adjustments related to operating expense |  | 22,678 |  |  | 24,182 |  |
| Non-cash interest expense |  | 247 |  |  | 302 |  |
| Change in fair value of embedded redemption feature |  | (120 | ) |  | 1,460 |  |
| Adjusted (non-GAAP) net income |  | $ | 2,231 |  |  | $ | 19,423 |  |
| Weighted average basic common shares outstanding |  | 101,913 |  |  | 105,451 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 103,165 |  |  | 120,628 |  |
| Net Income (Loss) per Common Share |  |  |  |  |
| GAAP diluted net loss per common share |  | $ | (0.27 | ) |  | $ | (0.10 | ) |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.02 |  |  | $ | 0.17 |  |

[0000936395-14-000037:8k_2_02:64]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2013 includes 1.3 million shares underlying certain stock options and restricted stock units. |

[0000936395-14-000037:8k_2_02:65]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2014 includes 2.1 million shares underlying certain stock options and restricted stock units,  and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-14-000037:8k_2_02:66]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2014 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-14-000037:8k_2_02:67]
* * *

[0000936395-14-000037:8k_2_02:68]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-14-000037:8k_2_02:69]
| • | Share-based compensation expense - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-14-000037:8k_2_02:70]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-14-000037:8k_2_02:71]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-14-000037:8k_2_02:72]
| • | Settlement of patent litigation - included in general and administrative expense during the second quarter of fiscal 2014 is a $2.0 million patent litigation settlement. |

[0000936395-14-000037:8k_2_02:73]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-14-000037:8k_2_02:74]
| • | Change in fair value of embedded redemption feature - a non-cash unrealized gain or loss reflective of a mark to market fair value adjustment of an embedded derivative related to the redemption feature of Ciena's outstanding 4.0% senior convertible notes due March 15, 2015. |
