# CIEN note change history — 0000936395-22-000053 → 0000936395-23-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-03-08):
[0000936395-23-000014:note_history:1]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position, or cash flows.
  (was, 2022-09-07, similarity 0.998):
[0000936395-22-000053:note_history:1]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

- changed (2023-03-08):
[0000936395-23-000014:note_history:2]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.
  (was, 2022-09-07, similarity 0.7949):
[0000936395-22-000053:note_history:2]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-03-08):
[0000936395-23-000014:note_history:3]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected.
  (was, 2022-09-07, similarity 0.6878):
[0000936395-22-000053:note_history:3]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions, and estimates reflect, among other things, the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected. In addition, because the duration and severity of COVID-19 pandemic are uncertain, certain of these estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve, Ciena’s estimates may change materially in future periods.

- changed (2023-03-08):
[0000936395-23-000014:note_history:4]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 29, 2022 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2022 (the “2022 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2023 and 2022 are 52-week fiscal years.
  (was, 2022-09-07, similarity 0.9996):
[0000936395-22-000053:note_history:4]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 30, 2021 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2021 (the “2021 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2022 and 2021 are 52-week fiscal years.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-03-08):
[0000936395-23-000014:note_history:5]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2022 Annual Report.
  (was, 2022-09-07, similarity 0.8195):
[0000936395-22-000053:note_history:5]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1 above, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2021 Annual Report.

- changed (2023-03-08):
[0000936395-23-000014:note_history:6]
In October 2021, the  Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its condensed consolidated financial statements and related disclosures.
  (was, 2022-09-07, similarity 0.9252):
[0000936395-22-000053:note_history:6]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its condensed consolidated financial statements and related disclosures.

- removed (2023-03-08):
[0000936395-22-000053:note_history:7]
Newly Issued Accounting Standards - Effective

- removed (2023-03-08):
[0000936395-22-000053:note_history:8]
In December 2019, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. ASU 2019-12 was effective for Ciena beginning in the first quarter of fiscal 2022. Ciena adopted ASU 2019-12 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

- removed (2023-03-08):
[0000936395-22-000053:note_history:9]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 was effective for annual periods beginning after December 15, 2021. Early adoption was permitted. Ciena adopted ASU 2021-10 in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

- removed (2023-03-08):
[0000936395-22-000053:note_history:10]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract

- removed (2023-03-08):
[0000936395-22-000053:note_history:11]
modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU No. 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance and may be applied prospectively through December 31, 2022. Ciena adopted Topic 848 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-03-08):
[0000936395-23-000014:note_history:12]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loans Payable
  (was, 2022-09-07, similarity 0.7921):
[0000936395-22-000053:note_history:12]
SHORT-TERM AND LONG-TERM DEBT 
2025 Term Loan

- added (2023-03-08):
[0000936395-23-000014:note_history:13]
2025 Term Loan

- added (2023-03-08):
[0000936395-23-000014:note_history:14]
On January 19, 2023, in connection with the Incremental Agreement (as defined below) to the Credit Agreement (as defined below), the Credit Agreement was amended to replace LIBOR with SOFR for the 2025 Term Loan in response to pending impact of Accounting Standards Codification 848 Reference Rate Reform.

- changed (2023-03-08):
[0000936395-23-000014:note_history:15]
The net carrying value of the 2025 Term Loan was comprised of the following as of the dates indicated (in thousands):
  (was, 2022-09-07, similarity 0.8879):
[0000936395-22-000053:note_history:15]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):

- changed (2023-03-08):
[0000936395-23-000014:note_history:16]
|  |  | January 28, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 673,942 |  |  | $ | (847) |  |  | $ | (1,586) |  |  | $ | 671,509 |  |  | $ | 673,010 |  |
  (was, 2022-09-07, similarity 0.9856):
[0000936395-22-000053:note_history:16]
|  |  | July 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,008) |  |  | $ | (1,887) |  |  | $ | 674,512 |  |  | $ | 677,285 |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:17]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.6 million as of January 28, 2023 and $1.7 million at October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million during the first three months of each of fiscal 2023 and fiscal 2022. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2022-09-07, similarity 0.9887):
[0000936395-22-000053:note_history:17]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.9 million as of July 30, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.5 million during the first nine months of each of fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2023-03-08):
[0000936395-23-000014:note_history:18]
As of January 28, 2023, the estimated fair value of the 2025 Term Loan was $670.6 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2022-09-07, similarity 0.964):
[0000936395-22-000053:note_history:18]
As of July 30, 2022, the estimated fair value of the 2025 Term Loan was $674.1 million. The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- added (2023-03-08):
[0000936395-23-000014:note_history:19]
2030 Term Loan

- added (2023-03-08):
[0000936395-23-000014:note_history:20]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $493.5 million in proceeds from the 2030 Term Loan are intended to be used for general corporate purposes.

- added (2023-03-08):
[0000936395-23-000014:note_history:21]
The Incremental Agreement amends the Credit Agreement and provides that the 2030 Term Loan will, among other things:

- added (2023-03-08):
[0000936395-23-000014:note_history:22]
•mature on January 19, 2030;

- added (2023-03-08):
[0000936395-23-000014:note_history:23]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2030 Term Loan as of January 19, 2023, or $1.25 million, with the balance payable at maturity;

- added (2023-03-08):
[0000936395-23-000014:note_history:24]
•be subject to mandatory prepayment on the same basis as the 2025 Term Loan, including on the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

- added (2023-03-08):
[0000936395-23-000014:note_history:25]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.50%; and

- added (2023-03-08):
[0000936395-23-000014:note_history:26]
•be repayable at any time at Ciena’s election, provided that repayment of the 2030 Term Loan with proceeds of certain indebtedness prior to July 19, 2023 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.

- added (2023-03-08):
[0000936395-23-000014:note_history:27]
Except as amended by the Incremental Agreement, the remaining terms of the Credit Agreement remain in full force and effect.

- changed (2023-03-08):
[0000936395-23-000014:note_history:28]
|  |  | January 28, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,491) |  |  | $ | (4,810) |  |  | $ | 492,699 |  |  |  |
  (was, 2022-09-07, similarity 0.8165):
[0000936395-22-000053:note_history:28]
|  |  | July 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,129) |  |  | $ | 394,871 |  |  |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:29]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Term Loan totaled $4.8 million as of January 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was minimal during the first three months of fiscal 2023. The carrying value of the 2030 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2022-09-07, similarity 0.7709):
[0000936395-22-000053:note_history:29]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $5.1 million as of July 30, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.4 million during the first nine months of fiscal 2022.

- changed (2023-03-08):
[0000936395-23-000014:note_history:30]
As of January 28, 2023, the estimated fair value of the 2030 Term Loan was $499.4 million. Ciena’s 2030 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2022-09-07, similarity 0.8854):
[0000936395-22-000053:note_history:30]
As of July 30, 2022, the estimated fair value of the 2030 Notes was $368.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- added (2023-03-08):
[0000936395-23-000014:note_history:31]
Outstanding Senior Notes Payable

- changed (2023-03-08):
[0000936395-23-000014:note_history:32]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).
  (was, 2022-09-07, similarity 0.9213):
[0000936395-22-000053:note_history:32]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors (collectively, the “Guarantors”), and U.S. Bank National Association, as trustee (the “Trustee”), pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

- added (2023-03-08):
[0000936395-23-000014:note_history:33]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

- added (2023-03-08):
[0000936395-23-000014:note_history:34]
|  |  | January 28, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,783) |  |  | $ | 395,217 |  |  | $ | 395,045 |  |  |  |

- added (2023-03-08):
[0000936395-23-000014:note_history:35]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.8 million as of January 28, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.2 million during the first three months of fiscal 2023 and was minimal during the first three months of fiscal 2022.

- added (2023-03-08):
[0000936395-23-000014:note_history:36]
As of January 28, 2023, the estimated fair value of the 2030 Notes was $351.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2023-03-08):
[0000936395-22-000053:note_history:37]
Ciena’s obligations under the 2030 Notes and the Indenture are irrevocably and unconditionally guaranteed, jointly and severally, on an unsecured senior basis by each of its domestic subsidiaries that is a borrower under or guarantor with respect to the 2025 Term Loan and Ciena’s senior secured asset-based revolving credit facility (the “ABL Credit Facility”).

- removed (2023-03-08):
[0000936395-22-000053:note_history:38]
The net proceeds from the sale of the 2030 Notes, after deducting costs, were approximately $395.5 million. Ciena intends to use the net proceeds from the Offering for general corporate purposes.

- removed (2023-03-08):
[0000936395-22-000053:note_history:39]
The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022.

- removed (2023-03-08):
[0000936395-22-000053:note_history:40]
The 2030 Notes and related subsidiary guarantees are the general unsubordinated unsecured senior obligations of Ciena and the Guarantors, respectively, and (i) rank equally in right of payment with all other existing and future senior indebtedness of Ciena and the Guarantors; (ii) are effectively subordinated to all existing and future secured indebtedness of Ciena and the Guarantors, including indebtedness under the 2025 Term Loan and the ABL Credit Facility, to the extent of the value of the assets securing such indebtedness; (iii) are structurally subordinated to all existing and future obligations, including indebtedness, of Ciena’s subsidiaries that do not guarantee the 2030 Notes; and (iv) are senior in right of payment to all of Ciena’s existing and future unsecured indebtedness that is, by its terms, expressly subordinated in right of payment to the 2030 Notes.

- removed (2023-03-08):
[0000936395-22-000053:note_history:41]
The Indenture contains restrictive covenants that limit the ability of Ciena and the Restricted Subsidiaries (as defined in the Indenture) or the Guarantors, as applicable, to, among other things, create certain liens or consolidate or merge with or into, or sell, lease, transfer, convey or otherwise dispose of all or substantially all the assets of Ciena or Ciena and its subsidiaries taken as a whole. These covenants are subject to a number of important exceptions and qualifications as set forth in the Indenture.

- removed (2023-03-08):
[0000936395-22-000053:note_history:42]
The Indenture provides for events of default (subject in certain cases to customary grace and cure periods) that include, among others, nonpayment of principal or interest when due, breach of covenants or other agreements in the Indenture, defaults in payment of certain other indebtedness and certain events of bankruptcy or insolvency. Generally, if an event of default occurs, the Trustee or the holders of at least 25% in principal amount of the outstanding 2030 Notes may declare the principal amount of and accrued but unpaid interest on all of the 2030 Notes to be due and payable immediately, provided that such amounts become due and payable without any further action or notice in the case of an event of bankruptcy or insolvency that constitutes an event of default.

- removed (2023-03-08):
[0000936395-22-000053:note_history:43]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a redemption price equal to 102% of the principal amount of the notes to be redeemed, plus any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-03-08):
[0000936395-22-000053:note_history:44]
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

- removed (2023-03-08):
[0000936395-22-000053:note_history:45]
|  | July 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 361,659 |  |  | $ | 11 |  |  | $ | (2,945) |  |  | $ | 358,725 |  |
| Corporate debt securities | 33,969 |  |  | 5 |  |  | (100) |  |  | 33,874 |  |
| Time deposits | 121,913 |  |  | 1 |  |  | (26) |  |  | 121,888 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |
| Included in cash equivalents | $ | 114,941 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,941 |  |
| Included in short-term investments | 322,820 |  |  | 14 |  |  | (1,011) |  |  | 321,823 |  |
| Included in long-term investments | 79,780 |  |  | 3 |  |  | (2,060) |  |  | 77,723 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |

- removed (2023-03-08):
[0000936395-22-000053:note_history:46]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |
| Time deposits | 71,226 |  |  | — |  |  | — |  |  | 71,226 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |
| Included in cash equivalents | $ | 71,226 |  |  | $ | — |  |  | $ | — |  |  | $ | 71,226 |  |
| Included in short-term investments | 181,488 |  |  | 5 |  |  | (10) |  |  | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-03-08):
[0000936395-23-000014:note_history:47]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):
  (was, 2022-09-07, similarity 0.8939):
[0000936395-22-000053:note_history:47]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

- changed (2023-03-08):
[0000936395-23-000014:note_history:48]
|  | January 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 89,789 |  |  | $ | — |  |  | $ | (2,473) |  |  | $ | 87,316 |  |
| Corporate debt securities | 16,356 |  |  | 1 |  |  | (7) |  |  | 16,350 |  |
| Time deposits | 41,022 |  |  | — |  |  | — |  |  | 41,022 |  |
|  | $ | 147,167 |  |  | $ | 1 |  |  | $ | (2,480) |  |  | $ | 144,688 |  |
| Included in cash equivalents | $ | 41,022 |  |  | $ | — |  |  | $ | — |  |  | $ | 41,022 |  |
| Included in short-term investments | 102,900 |  |  | 1 |  |  | (2,477) |  |  | 100,424 |  |
| Included in long-term investments | 3,245 |  |  | — |  |  | (3) |  |  | 3,242 |  |
|  | $ | 147,167 |  |  | $ | 1 |  |  | $ | (2,480) |  |  | $ | 144,688 |  |
  (was, 2022-09-07, similarity 0.9753):
[0000936395-22-000053:note_history:48]
|  | July 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 361,659 |  |  | $ | 11 |  |  | $ | (2,945) |  |  | $ | 358,725 |  |
| Corporate debt securities | 33,969 |  |  | 5 |  |  | (100) |  |  | 33,874 |  |
| Time deposits | 121,913 |  |  | 1 |  |  | (26) |  |  | 121,888 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |
| Included in cash equivalents | $ | 114,941 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,941 |  |
| Included in short-term investments | 322,820 |  |  | 14 |  |  | (1,011) |  |  | 321,823 |  |
| Included in long-term investments | 79,780 |  |  | 3 |  |  | (2,060) |  |  | 77,723 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:49]
|  | October 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 137,963 |  |  | $ | — |  |  | $ | (3,379) |  |  | $ | 134,584 |  |
| Corporate debt securities | 54,899 |  |  | 1 |  |  | (405) |  |  | 54,495 |  |
| Time deposits | 55,889 |  |  | — |  |  | (64) |  |  | 55,825 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |
| Included in cash equivalents | $ | 55,530 |  |  | $ | — |  |  | $ | — |  |  | $ | 55,530 |  |
| Included in short-term investments | 156,430 |  |  | 1 |  |  | (2,442) |  |  | 153,989 |  |
| Included in long-term investments | 36,791 |  |  | — |  |  | (1,406) |  |  | 35,385 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |
  (was, 2022-09-07, similarity 0.8497):
[0000936395-22-000053:note_history:49]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |
| Time deposits | 71,226 |  |  | — |  |  | — |  |  | 71,226 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |
| Included in cash equivalents | $ | 71,226 |  |  | $ | — |  |  | $ | — |  |  | $ | 71,226 |  |
| Included in short-term investments | 181,488 |  |  | 5 |  |  | (10) |  |  | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:50]
The following table summarizes the final legal maturities of debt investments as of January 28, 2023 (in thousands):
  (was, 2022-09-07, similarity 0.9772):
[0000936395-22-000053:note_history:50]
The following table summarizes the final legal maturities of debt investments as of July 30, 2022 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-03-08):
[0000936395-23-000014:note_history:51]
The net carrying value of the 2025 Term Loan was comprised of the following as of the dates indicated (in thousands):

- changed (2023-03-08):
[0000936395-23-000014:note_history:52]
|  |  | January 28, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 673,942 |  |  | $ | (847) |  |  | $ | (1,586) |  |  | $ | 671,509 |  |  | $ | 673,010 |  |
  (was, 2022-09-07, similarity 0.9856):
[0000936395-22-000053:note_history:52]
|  |  | July 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,008) |  |  | $ | (1,887) |  |  | $ | 674,512 |  |  | $ | 677,285 |  |

- added (2023-03-08):
[0000936395-23-000014:note_history:53]
|  |  | January 28, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,491) |  |  | $ | (4,810) |  |  | $ | 492,699 |  |  |  |

- added (2023-03-08):
[0000936395-23-000014:note_history:54]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

- added (2023-03-08):
[0000936395-23-000014:note_history:55]
|  |  | January 28, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,783) |  |  | $ | 395,217 |  |  | $ | 395,045 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-03-08):
[0000936395-22-000053:note_history:56]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):

- removed (2023-03-08):
[0000936395-22-000053:note_history:57]
|  |  | July 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,129) |  |  | $ | 394,871 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-03-08):
[0000936395-23-000014:note_history:58]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
  (was, 2022-09-07, similarity 0.997):
[0000936395-22-000053:note_history:58]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:59]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | $ | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
  (was, 2022-09-07, similarity 0.997):
[0000936395-22-000053:note_history:59]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:60]
|  |  | Quarter Ended |  |  |
|  |  | January 28, |  | January 29, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 765,096 |  |  | $ | 595,144 |  |  |  |  |  |
| EMEA |  | 152,804 |  |  | 150,785 |  |  |  |  |  |
| APAC |  | 138,621 |  |  | 98,514 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,056,521 |  |  | $ | 844,443 |  |  |  |  |  |
  (was, 2022-09-07, similarity 0.7673):
[0000936395-22-000053:note_history:60]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 617,366 |  |  | $ | 692,853 |  |  | $ | 1,913,350 |  |  | $ | 1,776,939 |  |
| EMEA |  | 124,185 |  |  | 189,180 |  |  | 420,075 |  |  | 499,652 |  |
| APAC |  | 126,430 |  |  | 106,108 |  |  | 328,226 |  |  | 302,607 |  |
| Total revenue by geographic distribution |  | $ | 867,981 |  |  | $ | 988,141 |  |  | $ | 2,661,651 |  |  | $ | 2,579,198 |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:61]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2022-09-07, similarity 0.9185):
[0000936395-22-000053:note_history:61]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2023-03-08):
[0000936395-23-000014:note_history:62]
|  | Quarter Ended |  |  |
|  | January 28, |  | January 29, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| AT&T | $ | 149,981 |  |  | $ | 110,876 |  |  |  |  |  |
| Web-scale provider | 121,327 |  |  | n/a |  |  |  |  |
| Total | $ | 271,308 |  |  | $ | 110,876 |  |  |  |  |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:63]
_____________________________________
  (was, 2022-09-07, similarity 0.8788):
[0000936395-22-000053:note_history:63]
_____________________________

- changed (2023-03-08):
[0000936395-23-000014:note_history:64]
n/a    Denotes revenue representing less than 10% of total revenue for the period
  (was, 2022-09-07, similarity 0.9333):
[0000936395-22-000053:note_history:64]
n/a    Denotes revenue representing less than 10% of total revenue for the periods presented

- removed (2023-03-08):
[0000936395-22-000053:note_history:65]
|  | Nine Months Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |

- removed (2023-03-08):
[0000936395-22-000053:note_history:66]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |

- removed (2023-03-08):
[0000936395-22-000053:note_history:67]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Verizon | $ | 108,495 |  |  | $ | 131,892 |  |  | $ | 273,158 |  |  | n/a |
| AT&T | 100,293 |  |  | 119,199 |  |  | 314,358 |  |  | 313,140 |  |
| Web-scale provider | n/a |  | 119,728 |  |  | n/a |  | n/a |
| Total | $ | 208,788 |  |  | $ | 370,819 |  |  | $ | 587,516 |  |  | $ | 313,140 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-03-08):
[0000936395-23-000014:note_history:68]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
  (was, 2022-09-07, similarity 0.997):
[0000936395-22-000053:note_history:68]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:69]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | $ | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
  (was, 2022-09-07, similarity 0.997):
[0000936395-22-000053:note_history:69]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |

- added (2023-03-08):
[0000936395-23-000014:note_history:70]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2023-03-08):
[0000936395-23-000014:note_history:71]
|  |  | Quarter Ended |  |  |
|  |  | January 28, |  | January 29, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 765,096 |  |  | $ | 595,144 |  |  |  |  |  |
| EMEA |  | 152,804 |  |  | 150,785 |  |  |  |  |  |
| APAC |  | 138,621 |  |  | 98,514 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,056,521 |  |  | $ | 844,443 |  |  |  |  |  |
  (was, 2022-09-07, similarity 0.7673):
[0000936395-22-000053:note_history:71]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 617,366 |  |  | $ | 692,853 |  |  | $ | 1,913,350 |  |  | $ | 1,776,939 |  |
| EMEA |  | 124,185 |  |  | 189,180 |  |  | 420,075 |  |  | 499,652 |  |
| APAC |  | 126,430 |  |  | 106,108 |  |  | 328,226 |  |  | 302,607 |  |
| Total revenue by geographic distribution |  | $ | 867,981 |  |  | $ | 988,141 |  |  | $ | 2,661,651 |  |  | $ | 2,579,198 |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:72]
Ciena’s revenue includes $693.6 million and $543.5 million of United States revenue for the first quarter of fiscal 2023 and 2022, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.
  (was, 2022-09-07, similarity 0.7756):
[0000936395-22-000053:note_history:72]
Ciena’s revenue includes $574.3 million and $623.9 million of United States revenue for the third quarter of fiscal 2022 and 2021, respectively. For the nine months ended July 30, 2022 and July 31, 2021, United States revenue was $1.8 billion and $1.6 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- changed (2023-03-08):
[0000936395-23-000014:note_history:73]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2022-09-07, similarity 0.9185):
[0000936395-22-000053:note_history:73]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2023-03-08):
[0000936395-23-000014:note_history:74]
|  | Quarter Ended |  |  |
|  | January 28, |  | January 29, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| AT&T | $ | 149,981 |  |  | $ | 110,876 |  |  |  |  |  |
| Web-scale provider | 121,327 |  |  | n/a |  |  |  |  |
| Total | $ | 271,308 |  |  | $ | 110,876 |  |  |  |  |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:75]
_____________________________________
  (was, 2022-09-07, similarity 0.8788):
[0000936395-22-000053:note_history:75]
_____________________________

- changed (2023-03-08):
[0000936395-23-000014:note_history:76]
n/a    Denotes revenue representing less than 10% of total revenue for the period
  (was, 2022-09-07, similarity 0.9333):
[0000936395-22-000053:note_history:76]
n/a    Denotes revenue representing less than 10% of total revenue for the periods presented

- changed (2023-03-08):
[0000936395-23-000014:note_history:77]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented.
  (was, 2022-09-07, similarity 0.9313):
[0000936395-22-000053:note_history:77]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. The other customers identified above purchased products and services from each of Ciena’s operating segments for each of the periods presented.

- changed (2023-03-08):
[0000936395-23-000014:note_history:78]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line includes the WL5n 100G-400G
  (was, 2022-09-07, similarity 0.8019):
[0000936395-22-000053:note_history:78]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line also includes the Z-Series Packet-Optical Platform and Optical Microsystems products.

- added (2023-03-08):
[0000936395-23-000014:note_history:79]
coherent pluggable transceivers. This product line also includes the Z-Series Packet-Optical Platform and Optical Microsystems products.

- changed (2023-03-08):
[0000936395-23-000014:note_history:80]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and Vyatta virtual routing and switching products. This product line also includes SD-Edge software and passive optical network (“PON”) routing and switching portfolio (“RSP”) components from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023.
  (was, 2022-09-07, similarity 0.7159):
[0000936395-22-000053:note_history:80]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, and the 8700 Packetwave Platform. This product line also includes the Vyatta (as defined in Note 4 below) virtual routing and switching products acquired from AT&T during the first quarter of fiscal 2022.

- added (2023-03-08):
[0000936395-23-000014:note_history:81]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools, and applications to assist customers in managing their networks, including by creating more efficient operations and more proactive visibility into their networks. Ciena’s platform software includes its Manage, Control and Plan (“MCP”) domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions.

- changed (2023-03-08):
[0000936395-23-000014:note_history:82]
Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2022-09-07, similarity 0.7125):
[0000936395-22-000053:note_history:82]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines described above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2023-03-08):
[0000936395-23-000014:note_history:83]
•Blue Planet Automation Software and Services is a comprehensive, cloud native, and standards-based software portfolio, together with related services, that enables customers to realize digital transformation through the automation of the services lifecycle. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2022-09-07, similarity 0.8225):
[0000936395-22-000053:note_history:83]
•Blue Planet® Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led operations support system (OSS) transformations by transforming legacy networks into “service ready” networks, accelerating the creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- added (2023-03-08):
[0000936395-23-000014:note_history:84]
Ciena’s Global Services are considered a distinct performance obligation for which revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is also recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

- changed (2023-03-08):
[0000936395-23-000014:note_history:85]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):
  (was, 2022-09-07, similarity 0.997):
[0000936395-22-000053:note_history:85]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

- changed (2023-03-08):
[0000936395-23-000014:note_history:86]
|  |  | Balance at January 28, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 1,054,917 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 148,758 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 231,378 |  |  | $ | 200,235 |  |
  (was, 2022-09-07, similarity 0.9851):
[0000936395-22-000053:note_history:86]
|  |  | Balance at July 30, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 802,484 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 157,448 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 209,653 |  |  | $ | 175,464 |  |

- changed (2023-03-08):
[0000936395-23-000014:note_history:87]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets. See Note 11 below.
  (was, 2022-09-07, similarity 0.9981):
[0000936395-22-000053:note_history:87]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 12 below.

- changed (2023-03-08):
[0000936395-23-000014:note_history:88]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $67.9 million and $56.8 million of revenue during the first three months of fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance at October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 28, 2023 and January 29, 2022.
  (was, 2022-09-07, similarity 0.9636):
[0000936395-22-000053:note_history:88]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $98.9 million and $94.7 million of revenue during the first nine months of fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance as of October 30, 2021 and October 31, 2020, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 30, 2022 and July 31, 2021.

- changed (2023-03-08):
[0000936395-23-000014:note_history:89]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $38.2 million and $39.7 million as of January 28, 2023 and October 29, 2022, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $7.2 million and $7.0 million during the first three months of fiscal 2023 and 2022, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2022-09-07, similarity 0.9877):
[0000936395-22-000053:note_history:89]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $36.1 million and $27.6 million as of July 30, 2022 and October 30, 2021, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $20.5 million and $16.8 million during the first nine months of fiscal 2022 and 2021, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statement of Operations.

- changed (2023-03-08):
[0000936395-23-000014:note_history:90]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 28, 2023, the aggregate amount of RPO was $2.7 billion. As of January 28, 2023, Ciena expects approximately 90% of the RPO to be recognized as revenue within the next 12 months.
  (was, 2022-09-07, similarity 0.9823):
[0000936395-22-000053:note_history:90]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 30, 2022, the aggregate amount of RPO was $2.9 billion. As of July 30, 2022, Ciena expects approximately 91% of the RPO to be recognized as revenue within the next 12 months.

- removed (2023-03-08):
[0000936395-22-000053:note_history:91]
|  | Nine Months Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |

- removed (2023-03-08):
[0000936395-22-000053:note_history:92]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |

- removed (2023-03-08):
[0000936395-22-000053:note_history:93]
Ciena reports its sales geographically using the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- removed (2023-03-08):
[0000936395-22-000053:note_history:94]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Verizon | $ | 108,495 |  |  | $ | 131,892 |  |  | $ | 273,158 |  |  | n/a |
| AT&T | 100,293 |  |  | 119,199 |  |  | 314,358 |  |  | 313,140 |  |
| Web-scale provider | n/a |  | 119,728 |  |  | n/a |  | n/a |
| Total | $ | 208,788 |  |  | $ | 370,819 |  |  | $ | 587,516 |  |  | $ | 313,140 |  |

- removed (2023-03-08):
[0000936395-22-000053:note_history:95]
Ciena’s Global Services are considered a distinct performance obligation for which revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are

- removed (2023-03-08):
[0000936395-22-000053:note_history:96]
performed. Revenue from installation and deployment services and consulting and network design services is also recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-03-08):
[0000936395-23-000014:note_history:97]
SUBSEQUENT EVENTS
ABL Credit Facility

- added (2023-03-08):
[0000936395-23-000014:note_history:98]
On February 10, 2023, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provides for a total commitment of $300 million, to extend its maturity date to September 28, 2025. Other terms of the ABL Credit Facility remain unchanged.

- removed (2023-03-08):
[0000936395-22-000053:note_history:99]
SUBSEQUENT EVENTS
Stock Repurchase Program

- removed (2023-03-08):
[0000936395-22-000053:note_history:100]
From the end of the third quarter of fiscal 2022 through September 2, 2022, Ciena repurchased an additional 154,247 shares of its common stock, for an aggregate purchase price of $8.0 million at an average price of $51.91 per share, inclusive of repurchases pending settlement. As of September 2, 2022, Ciena has repurchased an aggregate of 8,433,957 shares and has $500.0 million of authorized funds remaining under its stock repurchase program.
