# CIEN notes — 0000936395-23-000014


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-23-000014:notes:1]
[same as prior period, unchanged from 0000936395-22-000053:notes:1]

[0000936395-23-000014:notes:2]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected.

[0000936395-23-000014:notes:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 29, 2022 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2022 (the “2022 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2023 and 2022 are 52-week fiscal years.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-23-000014:notes:4]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2022 Annual Report.

[0000936395-23-000014:notes:5]
[same as prior period, unchanged from 0000936395-22-000053:notes:10]

[0000936395-23-000014:notes:6]
In October 2021, the  Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its condensed consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-23-000014:notes:7]
[same as prior period, unchanged from 0000936395-22-000053:notes:12]

[0000936395-23-000014:notes:8]
[same as prior period, unchanged from 0000936395-22-000053:notes:13]

[0000936395-23-000014:notes:9]
[same as prior period, unchanged from 0000936395-22-000053:notes:14]

[0000936395-23-000014:notes:10]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |

[0000936395-23-000014:notes:11]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | $ | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |

[0000936395-23-000014:notes:12]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-23-000014:notes:13]
[same as prior period, unchanged from 0000936395-22-000053:notes:20]

[0000936395-23-000014:notes:14]
|  |  | Quarter Ended |  |  |
|  |  | January 28, |  | January 29, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 765,096 |  |  | $ | 595,144 |  |  |  |  |  |
| EMEA |  | 152,804 |  |  | 150,785 |  |  |  |  |  |
| APAC |  | 138,621 |  |  | 98,514 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,056,521 |  |  | $ | 844,443 |  |  |  |  |  |

[0000936395-23-000014:notes:15]
Ciena’s revenue includes $693.6 million and $543.5 million of United States revenue for the first quarter of fiscal 2023 and 2022, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-23-000014:notes:16]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-23-000014:notes:17]
|  | Quarter Ended |  |  |
|  | January 28, |  | January 29, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| AT&T | $ | 149,981 |  |  | $ | 110,876 |  |  |  |  |  |
| Web-scale provider | 121,327 |  |  | n/a |  |  |  |  |
| Total | $ | 271,308 |  |  | $ | 110,876 |  |  |  |  |  |

[0000936395-23-000014:notes:18]
_____________________________________

[0000936395-23-000014:notes:19]
n/a    Denotes revenue representing less than 10% of total revenue for the period

[0000936395-23-000014:notes:20]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented.

[0000936395-23-000014:notes:21]
[same as prior period, unchanged from 0000936395-22-000053:notes:28]

[0000936395-23-000014:notes:22]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line includes the WL5n 100G-400G

[0000936395-23-000014:notes:23]
coherent pluggable transceivers. This product line also includes the Z-Series Packet-Optical Platform and Optical Microsystems products.

[0000936395-23-000014:notes:24]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and Vyatta virtual routing and switching products. This product line also includes SD-Edge software and passive optical network (“PON”) routing and switching portfolio (“RSP”) components from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023.

[0000936395-23-000014:notes:25]
[same as prior period, unchanged from 0000936395-22-000053:notes:31]

[0000936395-23-000014:notes:26]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools, and applications to assist customers in managing their networks, including by creating more efficient operations and more proactive visibility into their networks. Ciena’s platform software includes its Manage, Control and Plan (“MCP”) domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions.

[0000936395-23-000014:notes:27]
Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-23-000014:notes:28]
•Blue Planet Automation Software and Services is a comprehensive, cloud native, and standards-based software portfolio, together with related services, that enables customers to realize digital transformation through the automation of the services lifecycle. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-23-000014:notes:29]
[same as prior period, unchanged from 0000936395-22-000053:notes:34]

[0000936395-23-000014:notes:30]
[same as prior period, unchanged from 0000936395-22-000053:notes:35]

[0000936395-23-000014:notes:31]
Ciena’s Global Services are considered a distinct performance obligation for which revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is also recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-23-000014:notes:32]
[same as prior period, unchanged from 0000936395-22-000053:notes:38]

[0000936395-23-000014:notes:33]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-23-000014:notes:34]
|  |  | Balance at January 28, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 1,054,917 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 148,758 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 231,378 |  |  | $ | 200,235 |  |

[0000936395-23-000014:notes:35]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets. See Note 11 below.

[0000936395-23-000014:notes:36]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $67.9 million and $56.8 million of revenue during the first three months of fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance at October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 28, 2023 and January 29, 2022.

[0000936395-23-000014:notes:37]
[same as prior period, unchanged from 0000936395-22-000053:notes:43]

[0000936395-23-000014:notes:38]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $38.2 million and $39.7 million as of January 28, 2023 and October 29, 2022, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $7.2 million and $7.0 million during the first three months of fiscal 2023 and 2022, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0000936395-23-000014:notes:39]
[same as prior period, unchanged from 0000936395-22-000053:notes:45]

[0000936395-23-000014:notes:40]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 28, 2023, the aggregate amount of RPO was $2.7 billion. As of January 28, 2023, Ciena expects approximately 90% of the RPO to be recognized as revenue within the next 12 months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-23-000014:notes:41]
[same as prior period, unchanged from 0000936395-22-000053:notes:47]

[0000936395-23-000014:notes:42]
|  | January 28,2023 |  | October 29,2022 |
| Products | $ | 38,315 |  |  | $ | 19,814 |  |
| Services | 193,063 |  |  | 180,421 |  |
| Total deferred revenue | 231,378 |  |  | 200,235 |  |
| Less current portion | (164,758) |  |  | (137,899) |  |
| Long-term deferred revenue | $ | 66,620 |  |  | $ | 62,336 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-23-000014:notes:43]
BUSINESS COMBINATIONS
Benu and Tibit Acquisitions

[0000936395-23-000014:notes:44]
On November 17, 2022, Ciena acquired Benu, a portfolio of cloud-native software solutions, including a virtual Broadband Network Gateway ((v)BNG), that complements Ciena’s existing portfolio of broadband access solutions. On December 30, 2022, Ciena acquired Tibit, a provider and developer of PON-specific hardware and operating software that can be integrated into a carrier-grade Ethernet switch and will strengthen Ciena’s portfolio of next-generation PON solutions that support residential, enterprise, and mobility use cases. These businesses were acquired for an aggregate of approximately $291.7 million, of which $244.7 million was paid in cash and $47.0 million represents the fair value of Ciena’s previously held cost method equity investment in Tibit. The acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million. Each of these transactions has been accounted for as the acquisition of a business.

[0000936395-23-000014:notes:45]
Ciena incurred approximately $2.5 million in acquisition-related costs associated with these acquisitions. These costs and expenses primarily include fees associated with financial, legal, and accounting advisors and employment-related costs. These costs were recorded in acquisition and integration costs on the Condensed Consolidated Statement of Operations.

[0000936395-23-000014:notes:46]
[same as prior period, unchanged from 0000936395-22-000053:notes:52]

[0000936395-23-000014:notes:47]
|  | Amount |
| Cash and cash equivalents | $ | 14,634 |  |
| Accounts receivable, net | 443 |  |
| Inventories, net | 1,406 |  |
| Prepaid expenses and other | 810 |  |
| Equipment, furniture and fixtures | 1,090 |  |
| Goodwill | 117,997 |  |
| Developed technology | 75,400 |  |
| In-process technology | 89,100 |  |
| Customer relationships and contracts | 18,400 |  |
| Order backlog | 2,480 |  |
| Deferred tax asset, net | (27,782) |  |
| Accounts payable | (420) |  |
| Accrued liabilities and other short-term obligations | (874) |  |
| Deferred revenue | (851) |  |
| Other long-term obligations | (144) |  |
| Total purchase consideration | $ | 291,689 |  |

[0000936395-23-000014:notes:48]
[same as prior period, unchanged from 0000936395-22-000053:notes:55]

[0000936395-23-000014:notes:49]
In-process technology represents purchased technology that had not reached technological feasibility as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the in-process technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Upon completion of the in-process technology, it will be amortized on a straight line basis over its estimated useful life, which will be determined on that date.

[0000936395-23-000014:notes:50]
Customer relationships and contracts represent agreements with existing Tibit customers and have an estimated useful life of three years. Order backlog is amortized over the fulfillment period.

[0000936395-23-000014:notes:51]
The goodwill generated from these acquisitions is primarily related to expected economic synergies. The total goodwill amount was recorded in the Networking Platforms segment. The goodwill is not deductible for income tax purposes.

[0000936395-23-000014:notes:52]
Pro forma disclosures have not been included due to immateriality. The amounts of revenue and earnings for these acquisitions since the acquisition dates, which are included on the Condensed Consolidated Statement of Operations for the reporting period are immaterial.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-23-000014:notes:53]
[same as prior period, unchanged from 0000936395-22-000053:notes:62]

[0000936395-23-000014:notes:54]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development, and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets, for the three months ended January 28, 2023 (in thousands):

[0000936395-23-000014:notes:55]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 29, 2022 | $ | 1,215 |  |  | $ | 4,620 |  |  | $ | 5,835 |  |
| Charges | 704 |  | (1) | 3,594 |  | (2) | 4,298 |  |
| Cash payments | (1,498) |  |  | (8,214) |  |  | (9,712) |  |
| Balance at January 28, 2023 | $ | 421 |  |  | $ | — |  |  | $ | 421 |  |
| Current restructuring liabilities | $ | 421 |  |  | $ | — |  |  | $ | 421 |  |

[0000936395-23-000014:notes:56]
(1) Reflects employee costs associated with workforce reductions during the three months ended January 28, 2023 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.

[0000936395-23-000014:notes:57]
[same as prior period, unchanged from 0000936395-22-000053:notes:66]

[0000936395-23-000014:notes:58]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the three months ended January 29, 2022 (in thousands):

[0000936395-23-000014:notes:59]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 30, 2021 | $ | 781 |  |  | $ | — |  |  | $ | 781 |  |
| Charges | 410 |  | (1) | 2,999 |  | (2) | 3,409 |  |
| Cash payments | (421) |  |  | (2,999) |  |  | (3,420) |  |
| Balance at January 29, 2022 | $ | 770 |  |  | $ | — |  |  | $ | 770 |  |
| Current restructuring liabilities | $ | 770 |  |  | $ | — |  |  | $ | 770 |  |

[0000936395-23-000014:notes:60]
(1) Reflects employee costs associated with workforce reductions during the three months ended January 29, 2022 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization and costs related to restructured real estate facilities.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-23-000014:notes:61]
INTEREST AND OTHER INCOME, NET
The components of interest and other income, net, are as follows for the periods indicated (in thousands):

[0000936395-23-000014:notes:62]
|  | Quarter Ended |  |  |  |
|  | January 28, |  | January 29, |  |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |  |
| Interest income | $ | 7,121 |  |  | $ | 754 |  |  |  |  |  |  |
| Losses on non-hedge designated foreign currency forward contracts | (1,769) |  |  | (4,259) |  |  |  |  |  |  |
| Foreign currency exchange gains (losses) | (1,889) |  |  | 4,766 |  |  |  |  |  |  |
| Gain on cost method equity investment | 26,455 |  |  | 4,120 |  |  |  |  |  |  |
| Other | 2,055 |  |  | (1,694) |  |  |  |  |  |  |
| Interest and other income, net | $ | 31,973 |  |  | $ | 3,686 |  |  |  |  |  |  |

[0000936395-23-000014:notes:63]
During the first quarter of fiscal 2023, the acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million. See Note 4 above. 
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $1.9 million in foreign currency exchange rate losses for the first three months of fiscal 2023 and during the first three months of fiscal 2022, Ciena recorded $4.8 million in foreign currency exchange rate gains, both as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income, net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Condensed Consolidated Statements of Operations. During the first three months of fiscal 2023, Ciena recorded losses of $1.8 million and during the first three months of fiscal 2022, Ciena recorded losses of $4.3 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-23-000014:notes:64]
INCOME TAXES
 The effective tax rate for the quarter and three months ended January 28, 2023 was higher than the effective tax rate for the

[0000936395-23-000014:notes:65]
quarter and three months ended January 29, 2022, primarily due to the mandatory capitalization of research and development expenses in the first quarter of fiscal 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-23-000014:notes:66]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-23-000014:notes:67]
|  | January 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 89,789 |  |  | $ | — |  |  | $ | (2,473) |  |  | $ | 87,316 |  |
| Corporate debt securities | 16,356 |  |  | 1 |  |  | (7) |  |  | 16,350 |  |
| Time deposits | 41,022 |  |  | — |  |  | — |  |  | 41,022 |  |
|  | $ | 147,167 |  |  | $ | 1 |  |  | $ | (2,480) |  |  | $ | 144,688 |  |
| Included in cash equivalents | $ | 41,022 |  |  | $ | — |  |  | $ | — |  |  | $ | 41,022 |  |
| Included in short-term investments | 102,900 |  |  | 1 |  |  | (2,477) |  |  | 100,424 |  |
| Included in long-term investments | 3,245 |  |  | — |  |  | (3) |  |  | 3,242 |  |
|  | $ | 147,167 |  |  | $ | 1 |  |  | $ | (2,480) |  |  | $ | 144,688 |  |

[0000936395-23-000014:notes:68]
|  | October 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 137,963 |  |  | $ | — |  |  | $ | (3,379) |  |  | $ | 134,584 |  |
| Corporate debt securities | 54,899 |  |  | 1 |  |  | (405) |  |  | 54,495 |  |
| Time deposits | 55,889 |  |  | — |  |  | (64) |  |  | 55,825 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |
| Included in cash equivalents | $ | 55,530 |  |  | $ | — |  |  | $ | — |  |  | $ | 55,530 |  |
| Included in short-term investments | 156,430 |  |  | 1 |  |  | (2,442) |  |  | 153,989 |  |
| Included in long-term investments | 36,791 |  |  | — |  |  | (1,406) |  |  | 35,385 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |

[0000936395-23-000014:notes:69]
The following table summarizes the final legal maturities of debt investments as of January 28, 2023 (in thousands):

[0000936395-23-000014:notes:70]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 143,922 |  |  | $ | 141,446 |  |
| Due in 1-2 years | 3,245 |  |  | 3,242 |  |
|  | $ | 147,167 |  |  | $ | 144,688 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-23-000014:notes:71]
FAIR VALUE MEASUREMENTS
    As of the dates indicated, the following tables summarize the assets and liabilities that are recorded at fair value on a recurring basis (in thousands):

[0000936395-23-000014:notes:72]
|  | January 28, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 706,940 |  |  | $ | — |  |  | $ | — |  |  | $ | 706,940 |  |
| Bond mutual fund | 100,152 |  |  | — |  |  | — |  |  | 100,152 |  |
| Time deposits | 41,022 |  |  | — |  |  | — |  |  | 41,022 |  |
| Deferred compensation plan assets | 14,330 |  |  | — |  |  | — |  |  | 14,330 |  |
| U.S. government obligations | — |  |  | 87,316 |  |  | — |  |  | 87,316 |  |
| Corporate debt securities | — |  |  | 16,350 |  |  | — |  |  | 16,350 |  |
| Foreign currency forward contracts | — |  |  | 2,985 |  |  | — |  |  | 2,985 |  |
| Forward starting interest rate swaps | — |  |  | 7,923 |  |  | — |  |  | 7,923 |  |
| Total assets measured at fair value | $ | 862,444 |  |  | $ | 114,574 |  |  | $ | — |  |  | $ | 977,018 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 8,191 |  |  | $ | — |  |  | $ | 8,191 |  |
| Forward starting interest rate swaps | — |  |  | 2,181 |  |  | — |  |  | 2,181 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 10,372 |  |  | $ | — |  |  | $ | 10,372 |  |

[0000936395-23-000014:notes:73]
|  | October 29, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 639,024 |  |  | $ | — |  |  | $ | — |  |  | $ | 639,024 |  |
| Bond mutual fund | 71,145 |  |  | — |  |  | — |  |  | 71,145 |  |
| Time deposits | 55,825 |  |  | — |  |  | — |  |  | 55,825 |  |
| Deferred compensation plan assets | 12,751 |  |  | — |  |  | — |  |  | 12,751 |  |
| U.S. government obligations | — |  |  | 134,584 |  |  | — |  |  | 134,584 |  |
| Corporate debt securities | — |  |  | 54,495 |  |  | — |  |  | 54,495 |  |
| Foreign currency forward contracts | — |  |  | 251 |  |  | — |  |  | 251 |  |
| Forward starting interest rate swaps | — |  |  | 12,306 |  |  | — |  |  | 12,306 |  |
| Total assets measured at fair value | $ | 778,745 |  |  | $ | 201,636 |  |  | $ | — |  |  | $ | 980,381 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |

[0000936395-23-000014:notes:74]
As of the dates indicated, the assets and liabilities above are presented on Ciena’s Condensed Consolidated Balance Sheets as follows (in thousands):

[0000936395-23-000014:notes:75]
|  | January 28, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 848,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 848,114 |  |
| Short-term investments | — |  |  | 100,424 |  |  | — |  |  | 100,424 |  |
| Prepaid expenses and other | — |  |  | 2,985 |  |  | — |  |  | 2,985 |  |
| Long-term investments | — |  |  | 3,242 |  |  | — |  |  | 3,242 |  |
| Other long-term assets | 14,330 |  |  | 7,923 |  |  | — |  |  | 22,253 |  |
| Total assets measured at fair value | $ | 862,444 |  |  | $ | 114,574 |  |  | $ | — |  |  | $ | 977,018 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 8,191 |  |  | $ | — |  |  | $ | 8,191 |  |
| Other long-term obligations | — |  |  | 2,181 |  |  | — |  |  | 2,181 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 10,372 |  |  | $ | — |  |  | $ | 10,372 |  |

[0000936395-23-000014:notes:76]
|  | October 29, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 757,725 |  |  | $ | 7,974 |  |  | $ | — |  |  | $ | 765,699 |  |
| Short-term investments | 8,269 |  |  | 145,720 |  |  | — |  |  | 153,989 |  |
| Prepaid expenses and other | — |  |  | 251 |  |  | — |  |  | 251 |  |
| Long-term investments | — |  |  | 35,385 |  |  | — |  |  | 35,385 |  |
| Other long-term assets | 12,751 |  |  | 12,306 |  |  | — |  |  | 25,057 |  |
| Total assets measured at fair value | $ | 778,745 |  |  | $ | 201,636 |  |  | $ | — |  |  | $ | 980,381 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |

[0000936395-23-000014:notes:77]
[same as prior period, unchanged from 0000936395-22-000053:notes:90]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-23-000014:notes:78]
[same as prior period, unchanged from 0000936395-22-000053:notes:91]

[0000936395-23-000014:notes:79]
|  | January 28,2023 |  | October 29,2022 |
| Raw materials | $ | 846,564 |  |  | $ | 664,916 |  |
| Work-in-process | 18,422 |  |  | 18,232 |  |
| Finished goods | 300,684 |  |  | 258,584 |  |
| Deferred cost of goods sold | 51,319 |  |  | 41,084 |  |
| Gross inventories | 1,216,989 |  |  | 982,816 |  |
| Reserve for inventory excess and obsolescence | (38,900) |  |  | (36,086) |  |
| Inventories, net | $ | 1,178,089 |  |  | $ | 946,730 |  |

[0000936395-23-000014:notes:80]
The increase in raw materials inventory is related to the steps Ciena is taking to mitigate the impact of current supply chain constraints in the context of the global market shortage of semiconductor components. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first three months of fiscal 2023, Ciena recorded a provision for inventory excess and obsolescence of $5.5 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-23-000014:notes:81]
[same as prior period, unchanged from 0000936395-22-000053:notes:94]

[0000936395-23-000014:notes:82]
|  | January 28,2023 |  | October 29,2022 |
| Contract assets for unbilled accounts receivable, net | $ | 148,758 |  |  | $ | 156,039 |  |
| Prepaid VAT and other taxes | 68,000 |  |  | 63,975 |  |
| Prepaid expenses | 60,809 |  |  | 55,440 |  |
| Product demonstration equipment, net | 37,754 |  |  | 35,929 |  |
| Capitalized contract acquisition costs | 31,561 |  |  | 33,516 |  |
| Other non-trade receivables | 24,263 |  |  | 24,026 |  |
| Derivative assets | 2,985 |  |  | 251 |  |
| Deferred deployment expense | 460 |  |  | 877 |  |
|  | $ | 374,590 |  |  | $ | 370,053 |  |

[0000936395-23-000014:notes:83]
Depreciation of product demonstration equipment was $1.9 million during the first three months of fiscal 2023 and $2.4 million during the first three months of fiscal 2022.

[0000936395-23-000014:notes:84]
[same as prior period, unchanged from 0000936395-22-000053:notes:97]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-23-000014:notes:85]
INTANGIBLE ASSETSAs of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-23-000014:notes:86]
|  | January 28, 2023 |  | October 29, 2022 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 503,618 |  |  | $ | (392,530) |  |  | $ | 111,088 |  |  | $ | 428,218 |  |  | $ | (386,300) |  |  | $ | 41,918 |  |
| In-process technology | 89,100 |  |  | — |  |  | 89,100 |  |  | — |  |  | — |  |  | — |  |
| Patents and licenses | 8,415 |  |  | (4,473) |  |  | 3,942 |  |  | 8,415 |  |  | (4,228) |  |  | 4,187 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 411,344 |  |  | (370,826) |  |  | 40,518 |  |  | 390,271 |  |  | (366,859) |  |  | 23,412 |  |
| Total intangible assets | $ | 1,012,477 |  |  | $ | (767,829) |  |  | $ | 244,648 |  |  | $ | 826,904 |  |  | $ | (757,387) |  |  | $ | 69,517 |  |

[0000936395-23-000014:notes:87]
The aggregate amortization expense of intangible assets was $10.3 million during the first three months of fiscal 2023 and $12.2 million during the first three months of fiscal 2022. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-23-000014:notes:88]
| Fiscal Year | Amount |  |  |
| Remaining fiscal 2023 | $ | 40,107 |  |  |  |
| 2024 | 39,776 |  |  |  |
| 2025 | 34,575 |  |  |  |
| 2026 | 23,293 |  |  |  |
| 2027 | 15,789 |  |  |  |
| Thereafter | 2,008 |  |  |  |
|  | $ | 155,548 |  | (1) |  |

[0000936395-23-000014:notes:89]
(1) Does not include amortization of in-process technology, as estimation of the timing of future amortization expense would be impractical.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-23-000014:notes:90]
GOODWILL
The following table presents the goodwill allocated to Ciena’s operating segments as of January 28, 2023 and October 29, 2022, as well as the changes to goodwill during first quarter of fiscal 2023 (in thousands):

[0000936395-23-000014:notes:91]
|  |  | Balance at October 29, 2022 |  | Acquisitions |  | Impairments |  | Translation |  | Balance at January 28, 2023 |
| Platform Software and Services |  | $ | 156,191 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 156,191 |  |
| Blue Planet Automation Software and Services |  | 89,049 |  |  | — |  |  | — |  |  | — |  |  | 89,049 |  |
| Networking Platforms |  | 83,082 |  |  | 117,997 |  |  | — |  |  | 229 |  |  | 201,308 |  |
| Total |  | $ | 328,322 |  |  | $ | 117,997 |  |  | $ | — |  |  | $ | 229 |  |  | $ | 446,548 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-23-000014:notes:92]
OTHER BALANCE SHEET DETAILSAs of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-23-000014:notes:93]
|  | January 28,2023 |  | October 29,2022 |
| Compensation, payroll related tax and benefits (1) | $ | 90,307 |  |  | $ | 126,338 |  |
| Warranty | 48,543 |  |  | 45,503 |  |
| Vacation | 27,590 |  |  | 26,396 |  |
| Income taxes payable | 26,971 |  |  | 11,472 |  |
| Interest payable | 9,599 |  |  | 4,793 |  |
| Foreign currency forward contracts | 8,191 |  |  | 15,604 |  |
| Finance lease liabilities | 3,912 |  |  | 3,758 |  |
| Other | 128,825 |  |  | 126,918 |  |
|  | $ | 343,938 |  |  | $ | 360,782 |  |

[0000936395-23-000014:notes:94]
(1) Reduction is primarily due to bonus payments to employees under Ciena’s 2023 annual cash incentive compensation plan in

[0000936395-23-000014:notes:95]
the first quarter of fiscal 2023.

[0000936395-23-000014:notes:96]
[same as prior period, unchanged from 0000936395-22-000053:notes:105]

[0000936395-23-000014:notes:97]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Three Months Ended January 29, 2022 |  | $ | 48,019 |  |  |  |  | 2,817 |  |  | (4,663) |  |  | $ | 46,173 |  |
| Three Months Ended January 28, 2023 |  | $ | 45,503 |  |  |  |  | 8,230 |  |  | (5,190) |  |  | $ | 48,543 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-23-000014:notes:98]
[same as prior period, unchanged from 0000936395-22-000053:notes:107]

[0000936395-23-000014:notes:99]
[same as prior period, unchanged from 0000936395-22-000053:notes:108]

[0000936395-23-000014:notes:100]
As of January 28, 2023 and October 29, 2022, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies that is principally related to research and development activities. The notional amount of these contracts was approximately $265.6 million and $272.2 million as of January 28, 2023 and October 29, 2022, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-23-000014:notes:101]
As of January 28, 2023 and October 29, 2022, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $150.0 million and $108.0 million as of January 28, 2023 and October 29, 2022, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-23-000014:notes:102]
[same as prior period, unchanged from 0000936395-22-000053:notes:111]

[0000936395-23-000014:notes:103]
Ciena is exposed to floating rates of interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating-to-fixed interest rate swap arrangements.

[0000936395-23-000014:notes:104]
Prior to amending the 2025 Term Loan (as defined in Note 16 below) to replace LIBOR with the Secured Overnight Financing Rate (“SOFR”) (see Note 16 below), Ciena was exposed to floating rates of LIBOR interest on its 2025 Term Loan borrowings. Ciena hedged this risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan at 2.957% through September 2023. In January 2023, Ciena entered into a LIBOR to SOFR basis swap (“basis swap”) to hedge its exposure to SOFR rate. The basis swap offsets the LIBOR exposure risk of the interest rate swaps and effectively fixes the SOFR rate for $350.0 million of the 2025 Term Loan at 2.883% through September 2023. The total notional amount of these swaps in effect was $350.0 million as of January 28, 2023 and October 29, 2022. In April 2022, Ciena entered into floating to fixed forward starting interest rate swap arrangements (“forward starting swaps”). The forward starting swaps fix the SOFR for $350.0 million of the 2025 Term Loan at 2.968% from September 2023 through the 2025 Term Loan maturity. The total notional amount of forward starting swaps effective September 2023 was $350 million as of January 28, 2023.

[0000936395-23-000014:notes:105]
In January 2023, Ciena entered into floating-to-fixed interest rate swap arrangements (“2028 interest rate swaps”). The 2028 interest rate swaps fix the SOFR rate of approximately $350.0 million of the principal amount of the 2030 Term Loan (as defined in Note 16 below) at 3.47% through January 2028. The total notional amount of these interest rate swaps in effect as of January 28, 2023 was $350.0 million.

[0000936395-23-000014:notes:106]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps, basis swap, forward starting swaps, and 2028 interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amounts of the 2025 Term Loan and 2030 Term Loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-23-000014:notes:107]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Note 6 and Note 9 above.


## us-gaap:DebtDisclosureTextBlock

[0000936395-23-000014:notes:108]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loans Payable

[0000936395-23-000014:notes:109]
2025 Term Loan

[0000936395-23-000014:notes:110]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-23-000014:notes:111]
On January 19, 2023, in connection with the Incremental Agreement (as defined below) to the Credit Agreement (as defined below), the Credit Agreement was amended to replace LIBOR with SOFR for the 2025 Term Loan in response to pending impact of Accounting Standards Codification 848 Reference Rate Reform.

[0000936395-23-000014:notes:112]
The net carrying value of the 2025 Term Loan was comprised of the following as of the dates indicated (in thousands):

[0000936395-23-000014:notes:113]
|  |  | January 28, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 673,942 |  |  | $ | (847) |  |  | $ | (1,586) |  |  | $ | 671,509 |  |  | $ | 673,010 |  |

[0000936395-23-000014:notes:114]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.6 million as of January 28, 2023 and $1.7 million at October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million during the first three months of each of fiscal 2023 and fiscal 2022. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-23-000014:notes:115]
As of January 28, 2023, the estimated fair value of the 2025 Term Loan was $670.6 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-23-000014:notes:116]
2030 Term Loan

[0000936395-23-000014:notes:117]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $493.5 million in proceeds from the 2030 Term Loan are intended to be used for general corporate purposes.

[0000936395-23-000014:notes:118]
The Incremental Agreement amends the Credit Agreement and provides that the 2030 Term Loan will, among other things:

[0000936395-23-000014:notes:119]
•mature on January 19, 2030;

[0000936395-23-000014:notes:120]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2030 Term Loan as of January 19, 2023, or $1.25 million, with the balance payable at maturity;

[0000936395-23-000014:notes:121]
•be subject to mandatory prepayment on the same basis as the 2025 Term Loan, including on the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-23-000014:notes:122]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.50%; and

[0000936395-23-000014:notes:123]
•be repayable at any time at Ciena’s election, provided that repayment of the 2030 Term Loan with proceeds of certain indebtedness prior to July 19, 2023 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.

[0000936395-23-000014:notes:124]
Except as amended by the Incremental Agreement, the remaining terms of the Credit Agreement remain in full force and effect.

[0000936395-23-000014:notes:125]
The net carrying value of the 2030 Term Loan was comprised of the following for the periods indicated (in thousands):

[0000936395-23-000014:notes:126]
|  |  | January 28, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,491) |  |  | $ | (4,810) |  |  | $ | 492,699 |  |  |  |

[0000936395-23-000014:notes:127]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Term Loan totaled $4.8 million as of January 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was minimal during the first three months of fiscal 2023. The carrying value of the 2030 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-23-000014:notes:128]
As of January 28, 2023, the estimated fair value of the 2030 Term Loan was $499.4 million. Ciena’s 2030 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-23-000014:notes:129]
Outstanding Senior Notes Payable

[0000936395-23-000014:notes:130]
2030 Notes

[0000936395-23-000014:notes:131]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0000936395-23-000014:notes:132]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0000936395-23-000014:notes:133]
|  |  | January 28, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,783) |  |  | $ | 395,217 |  |  | $ | 395,045 |  |  |  |

[0000936395-23-000014:notes:134]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.8 million as of January 28, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.2 million during the first three months of fiscal 2023 and was minimal during the first three months of fiscal 2022.

[0000936395-23-000014:notes:135]
As of January 28, 2023, the estimated fair value of the 2030 Notes was $351.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-23-000014:notes:136]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the three months ended January 28, 2023 (in thousands):

[0000936395-23-000014:notes:137]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 29, 2022 | $ | (2,965) |  |  | $ | (10,197) |  |  | $ | 9,397 |  |  | $ | (42,880) |  |  | $ | (46,645) |  |
| Other comprehensive gain (loss) before reclassifications | 1,050 |  |  | 7,630 |  |  | (4,226) |  |  | 15,979 |  |  | 20,433 |  |
| Amounts reclassified from AOCI | — |  |  | (2,288) |  |  | (799) |  |  | — |  |  | (3,087) |  |
| Balance at January 28, 2023 | $ | (1,915) |  |  | $ | (4,855) |  |  | $ | 4,372 |  |  | $ | (26,901) |  |  | $ | (29,299) |  |

[0000936395-23-000014:notes:138]
The following table summarizes the changes in AOCI, net of tax, for the three months ended January 29, 2022 (in thousands):

[0000936395-23-000014:notes:139]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 30, 2021 | $ | (164) |  |  | $ | 6,216 |  |  | $ | (12,179) |  |  | $ | 6,566 |  |  | $ | 439 |  |
| Other comprehensive gain (loss) before reclassifications | (774) |  |  | (4,477) |  |  | 1,364 |  |  | (13,157) |  |  | (17,044) |  |
| Amounts reclassified from AOCI | — |  |  | (862) |  |  | 2,562 |  |  | — |  |  | 1,700 |  |
| Balance at January 29, 2022 | $ | (938) |  |  | $ | 877 |  |  | $ | (8,253) |  |  | $ | (6,591) |  |  | $ | (14,905) |  |

[0000936395-23-000014:notes:140]
All amounts reclassified from AOCI, related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges, impacted research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI, related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges, impacted interest and other income, net, on the Condensed Consolidated Statements of Operations.


## us-gaap:EarningsPerShareTextBlock

[0000936395-23-000014:notes:141]
[same as prior period, unchanged from 0000936395-22-000053:notes:140]

[0000936395-23-000014:notes:142]
[same as prior period, unchanged from 0000936395-22-000053:notes:141]

[0000936395-23-000014:notes:143]
|  | Quarter Ended |  |  |
|  | January 28, |  | January 29, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Net income | $ | 76,241 |  |  | $ | 45,823 |  |  |  |  |  |
| Basic weighted average shares outstanding | 149,081 |  |  | 154,151 |  |  |  |  |  |
| Effect of dilutive potential common shares | 470 |  |  | 1,656 |  |  |  |  |  |
| Diluted weighted average shares | 149,551 |  |  | 155,807 |  |  |  |  |  |
| Basic EPS | $ | 0.51 |  |  | $ | 0.30 |  |  |  |  |  |
| Diluted EPS | $ | 0.51 |  |  | $ | 0.29 |  |  |  |  |  |
| Antidilutive employee share-based awards, excluded | 2,768 |  |  | 761 |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-23-000014:notes:144]
STOCKHOLDERS’ EQUITY
Stock Repurchase Program

[0000936395-23-000014:notes:145]
On December 9, 2021, Ciena announced that its Board of Directors authorized a program to repurchase up to $1.0 billion of its common stock.

[0000936395-23-000014:notes:146]
During the first three months of fiscal 2023, Ciena did not repurchase any additional shares of its common stock. As of January 28, 2023, Ciena has repurchased an aggregate of 8.4 million shares for an aggregate purchase price of $500.0 million at an average price of $59.28 per share and has an aggregate of $500.0 million of authorized funds remaining under its stock repurchase program. The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-23-000014:notes:147]
[same as prior period, unchanged from 0000936395-22-000053:notes:145]

[0000936395-23-000014:notes:148]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $13.0 million for the shares of Ciena’s stock repurchased during the first three months of fiscal 2023 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-23-000014:notes:149]
[same as prior period, unchanged from 0000936395-22-000053:notes:147]

[0000936395-23-000014:notes:150]
|  | Quarter Ended |  |  |
|  | January 28, |  | January 29, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Products | $ | 1,051 |  |  | $ | 900 |  |  |  |  |  |
| Services | 2,297 |  |  | 1,584 |  |  |  |  |  |
| Share-based compensation expense included in cost of goods sold | 3,348 |  |  | 2,484 |  |  |  |  |  |
| Research and development | 9,234 |  |  | 6,830 |  |  |  |  |  |
| Selling and marketing | 8,424 |  |  | 7,060 |  |  |  |  |  |
| General and administrative | 9,468 |  |  | 7,912 |  |  |  |  |  |
| Share-based compensation expense included in operating expense | 27,126 |  |  | 21,802 |  |  |  |  |  |
| Share-based compensation expense capitalized in inventory, net | 38 |  |  | 11 |  |  |  |  |  |
| Total share-based compensation expense | $ | 30,512 |  |  | $ | 24,297 |  |  |  |  |  |

[0000936395-23-000014:notes:151]
As of January 28, 2023, total unrecognized share-based compensation expense was approximately $292.6 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.6 years.

[0000936395-23-000014:notes:152]
Stock Unit Awards
Beginning in December 2022, Ciena introduced a benefit, under which, upon completion of ten years of service and reaching age 60, executive officers who are residents of the United States, United Kingdom, or Canada and who provide 12 months’ notice of their retirement will receive continued vesting of all of their granted but unvested restricted stock unit (“RSU”) awards and a pro-rated amount of their performance stock unit awards and market stock unit awards. Other employees in these countries will be subject to the same eligibility and notice requirements, but will receive acceleration of their granted but unvested RSU awards upon retirement. This program accelerates the recognition of share-based compensation expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-23-000014:notes:153]
[same as prior period, unchanged from 0000936395-22-000053:notes:150]

[0000936395-23-000014:notes:154]
[same as prior period, unchanged from 0000936395-22-000053:notes:151]

[0000936395-23-000014:notes:155]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, right-of-use (“ROU”) assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 28, 2023, equipment, building, furniture and fixtures, net, totaled $279.0 million, and operating ROU assets totaled $48.4 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of January 28, 2023, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-23-000014:notes:156]
|  | January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 217,102 |  |  | $ | — |  |  | $ | 27,546 |  |  | $ | — |  |  | $ | 244,648 |  |
| Goodwill | $ | 201,308 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 446,548 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 43,931 |  |  | $ | 43,931 |  |

[0000936395-23-000014:notes:157]
[same as prior period, unchanged from 0000936395-22-000053:notes:154]

[0000936395-23-000014:notes:158]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; acquisition and integration costs; interest and other income, net; interest expense; and provision for income taxes.

[0000936395-23-000014:notes:159]
[same as prior period, unchanged from 0000936395-22-000053:notes:156]

[0000936395-23-000014:notes:160]
|  | Quarter Ended |  |  |
|  | January 28, |  | January 29, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 202,147 |  |  | $ | 134,125 |  |  |  |  |  |
| Platform Software and Services | 45,650 |  |  | 49,496 |  |  |  |  |  |
| Blue Planet Automation Software and Services | (11,059) |  |  | (1,034) |  |  |  |  |  |
| Global Services | 37,478 |  |  | 53,191 |  |  |  |  |  |
| Total segment profit | 274,216 |  |  | 235,778 |  |  |  |  |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 123,807 |  |  | 118,881 |  |  |  |  |  |
| General and administrative | 50,896 |  |  | 44,498 |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 4,298 |  |  | 3,409 |  |  |  |  |  |
| Amortization of intangible assets | 7,441 |  |  | 8,918 |  |  |  |  |  |
| Acquisition and integration costs | 2,558 |  |  | 68 |  |  |  |  |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest and other income, net | 31,973 |  |  | 3,686 |  |  |  |  |  |
| Interest expense | (15,870) |  |  | (8,648) |  |  |  |  |  |
| Less: Provision for income taxes | 25,078 |  |  | 9,219 |  |  |  |  |  |
| Net income | $ | 76,241 |  |  | $ | 45,823 |  |  |  |  |  |

[0000936395-23-000014:notes:161]
[same as prior period, unchanged from 0000936395-22-000053:notes:158]

[0000936395-23-000014:notes:162]
[same as prior period, unchanged from 0000936395-22-000053:notes:159]

[0000936395-23-000014:notes:163]
|  | January 28,2023 |  | October 29,2022 |
| Canada | $ | 237,190 |  |  | $ | 226,451 |  |
| United States | 46,905 |  |  | 47,515 |  |
| Other International | 43,328 |  |  | 38,921 |  |
| Total | $ | 327,423 |  |  | $ | 312,887 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-23-000014:notes:164]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-23-000014:notes:165]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-23-000014:notes:166]
Litigation

[0000936395-23-000014:notes:167]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-23-000014:notes:168]
SUBSEQUENT EVENTS
ABL Credit Facility

[0000936395-23-000014:notes:169]
On February 10, 2023, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provides for a total commitment of $300 million, to extend its maturity date to September 28, 2025. Other terms of the ABL Credit Facility remain unchanged.
