# CIEN MD&A — 0000936395-23-000014


## mdna

[0000936395-23-000014:mdna:1]
[same as prior period, unchanged from 0000936395-22-000053:mdna:1]

[0000936395-23-000014:mdna:2]
[same as prior period, unchanged from 0000936395-22-000053:mdna:2]

[0000936395-23-000014:mdna:3]
This report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, operational matters including the expansion of manufacturing capacity and accumulation of inventory, business prospects and strategies and other “forward-looking” information. Forward-looking statements may appear throughout this report, including in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors.” In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “would,” “can,” “should,” “could,” “expects,” “future,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” “prepare,” or “continue” or the negative of those words and other comparable words. You should be aware that the forward-looking statements contained in this report are based on our current views and assumptions, and are subject to known and unknown risks, uncertainties and other factors that may cause actual events or results to differ materially.

[0000936395-23-000014:mdna:4]
[same as prior period, unchanged from 0000936395-22-000053:mdna:4]

[0000936395-23-000014:mdna:5]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations should be read in conjunction with our Condensed Consolidated Financial Statements and the accompanying notes thereto included in Item 1 of Part I of this report and in Item 8 of Part II of our 2022 Annual Report.

[0000936395-23-000014:mdna:6]
We are a networking systems, services, and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software, and services that support the delivery of video, data, and voice traffic over core, metro, aggregation, and access communications networks. Our solutions are used globally by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that are informed by analytics and intelligence. Our solutions include Networking Platforms, including our Converged Packet Optical and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our MCP applications that deliver advanced multi-layer domain control and operations. Through our Blue Planet Software we also enable complete service lifecycle management automation with productized open source software (OSS) and service assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-23-000014:mdna:7]
Order Volumes

[0000936395-23-000014:mdna:8]
From the second quarter of fiscal 2021 through the third quarter of fiscal 2022, we received unprecedented orders for our products and services. Our quarterly order volumes during this period significantly exceeded our revenue and historical order volumes, with some concentration of orders among certain existing Web-scale and North America-based service provider customers. We believe some portion of these orders reflected pre-pandemic design wins for which orders were delayed due to the dynamics of the COVID-19 pandemic. We also believe some portion of these orders reflected customer acceleration of future orders due to lengthened lead times or the implementation of security of supply strategies to address the supply constraints described below. Our order growth relative to revenue began to moderate in the fourth quarter of fiscal 2022. We expect order growth relative to revenue to continue to moderate, and we do not expect the very high level of orders we experienced during this period to continue. However, over the longer term, we continue to believe that certain trends and shifts in business and consumer behaviors, including 5G, enterprise and consumer cloud network adoption, increasing demands on the network edge, and network operator focus on resilience and automation, represent positive, long-term opportunities for our business.

[0000936395-23-000014:mdna:9]
Backlog

[0000936395-23-000014:mdna:10]
Historically, a significant portion of our quarterly revenue was generated from customer orders received during that same quarter (which we refer to as “book to revenue”) and therefore less predictable and subject to fluctuation. More recently, however, we have generated a significant backlog of customer orders, and our results can be more significantly impacted by availability of supply, as well as any order cancellations or customer delivery deferrals of existing backlog. As a result of recent demand dynamics and the supply chain constraints described below, our backlog grew from $1.2 billion at the end of fiscal 2020 to $4.2 billion at the end of fiscal 2022. As supply chain conditions improve and we are able to increase shipment volumes, we expect our backlog to reduce as fiscal 2023 progresses. The timing and degree to which we make shipments to fulfill our backlog will have a significant impact on our rate of revenue growth and could cause some volatility in our results of operations. As a result of these and other factors, our backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period. See the risk factor captioned “Our backlog may not be an accurate indicator of our level and timing of future revenues.” in Item 1A of Part II of this report for further discussion of risks related to our backlog.

[0000936395-23-000014:mdna:11]
[same as prior period, unchanged from 0000936395-22-000053:mdna:9]

[0000936395-23-000014:mdna:12]
In the face of demand across a range of industries, global supply for certain raw materials and components, including, in particular, semiconductor, integrated circuits, and other electronic components used in most of our products, experienced substantial constraint and disruption in recent periods. As a result, we experienced significant component shortages, extended lead times, increased costs, and unexpected cancellation or delay of previously committed supply of key components across our supplier base. While reliability of supply has begun to improve gradually, and the majority of our suppliers have been able to deliver by their promised, though extended, lead times, we continue to experience volatility from a small group of our suppliers of integrated circuit components that represent a small fraction of our overall materials, but which are essential for delivering finished products. This volatility can result in receiving fewer components than expected in a given period, which can adversely impact our revenue. It can also result in receiving more components than expected, as was the case in during the fourth quarter of fiscal 2022 and the first quarter of fiscal 2023, and which had a positive impact on our revenue. We expect supply chain challenges will continue at least through fiscal 2023 and expect that the extended lead times and elevated supply chain costs we have experienced will persist for the reasonably foreseeable future. We expect these supply conditions to continue to impact our costs of goods sold in the near term and to adversely impact our ability to continue to reduce the cost to produce our products in a manner consistent with prior periods. It is unclear when the supply environment will become less volatile and what impacts it will have on our business and results of operations in future periods.

[0000936395-23-000014:mdna:13]
To mitigate the impact of these supply conditions on our business and customers, we have been placing advance orders for inventory and accumulating components that are in available supply. We believe that this approach positions us to produce finished goods more quickly when supply constraints ease for those components in shorter supply. As a result, our inventory has increased from $946.7 million at the end of fiscal 2022 to $1.2 billion at the end of the first quarter fiscal 2023. We have also implemented additional mitigation strategies, including expanding manufacturing capacity, implementing multi-sourcing activities, qualifying alternative parts, and redesigning products, and expect, over time, to realize certain benefits of these activities. Together with increased costs of supply, these mitigation strategies have impacted, and we expect them to continue to impact, our result of operations and cash from operations. See “Risk Factors” in Item 1A of Part II of this report for further discussion of risks related to our supply chain and our mitigation activities.

[0000936395-23-000014:mdna:14]
[same as prior period, unchanged from 0000936395-22-000053:mdna:17]

[0000936395-23-000014:mdna:15]
Strategic Acquisitions. On November 17, 2022, we acquired Benu Networks, Inc. (“Benu”) and its portfolio of cloud-native software solutions, including a virtual Broadband Network Gateway ((v)BNG), which complement our existing portfolio of broadband access solutions. On December 30, 2022, we acquired Tibit Communications, Inc. (“Tibit”), a provider of passive optical network solutions. See Note 4 to our Consolidated Financial Statements included in Item 1 of Part I of this report for more information on these acquisitions.

[0000936395-23-000014:mdna:16]
Financial Initiatives. On January 19, 2023, we entered into an incremental amendment to our existing Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), pursuant to which we incurred a new tranche of senior secured term loans in an aggregate principal amount of $500 million, maturing on January 19, 2030 (the “2030 Term Loan”). We intend to use the net proceeds of the 2030 Term Loan borrowing for general corporate purposes. On February 10, 2023, we amended our existing ABL Credit Facility (as defined below) to, among other things, extend the maturity date of the ABL Credit Facility to September 28, 2025. See Notes 16 and 23 to our Consolidated Financial Statements included in Item 1 of Part I of this report for more information relating to these financial initiatives.

[0000936395-23-000014:mdna:17]
For additional information regarding our business, industry, market opportunity, competitive landscape, and strategy, see our 2022 Annual Report.

[0000936395-23-000014:mdna:18]
[same as prior period, unchanged from 0000936395-22-000053:mdna:20]

[0000936395-23-000014:mdna:19]
[same as prior period, unchanged from 0000936395-22-000053:mdna:21]

[0000936395-23-000014:mdna:20]
[same as prior period, unchanged from 0000936395-22-000053:mdna:22]

[0000936395-23-000014:mdna:21]
[same as prior period, unchanged from 0000936395-22-000053:mdna:23]

[0000936395-23-000014:mdna:22]
[same as prior period, unchanged from 0000936395-22-000053:mdna:24]

[0000936395-23-000014:mdna:23]
Approximately 14.7% of our revenue was non-U.S. Dollar-denominated during the first quarter of fiscal 2023, primarily including sales in Euros, Canadian Dollars, and British Pounds. During the first quarter of fiscal 2023, as compared to the first quarter of fiscal 2022, the U.S. Dollar primarily strengthened against these currencies. Consequently, our revenue for the first quarter of fiscal 2023 reported in U.S. Dollars was adversely impacted by approximately $10.5 million, or 1.0%.

[0000936395-23-000014:mdna:24]
[same as prior period, unchanged from 0000936395-22-000053:mdna:26]

[0000936395-23-000014:mdna:25]
[same as prior period, unchanged from 0000936395-22-000053:mdna:27]

[0000936395-23-000014:mdna:26]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 28, 2023 |  | January 29, 2022 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 735,634 |  |  | $ | 540,936 |  |  |  |  | 36.0 | % |  |  |  |  |  |  |  |  |
| %** | 69.6 | % |  | 64.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Routing and Switching | 119,505 |  |  | 85,710 |  |  |  |  | 39.4 | % |  |  |  |  |  |  |  |  |
| %** | 11.3 | % |  | 10.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Networking Platforms | 855,139 |  |  | 626,646 |  |  |  |  | 36.5 | % |  |  |  |  |  |  |  |  |
| %** | 80.9 | % |  | 74.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 73,445 |  |  | 72,917 |  |  |  |  | 0.7 | % |  |  |  |  |  |  |  |  |
| %** | 6.9 | % |  | 8.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | 15,405 |  |  | 21,110 |  |  |  |  | (27.0) | % |  |  |  |  |  |  |  |  |
| %** | 1.5 | % |  | 2.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 67,891 |  |  | 72,491 |  |  |  |  | (6.3) | % |  |  |  |  |  |  |  |  |
| %** | 6.4 | % |  | 8.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Installation and Deployment | 34,575 |  |  | 40,370 |  |  |  |  | (14.4) | % |  |  |  |  |  |  |  |  |
| %** | 3.3 | % |  | 4.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Consulting and Network Design | 10,066 |  |  | 10,909 |  |  |  |  | (7.7) | % |  |  |  |  |  |  |  |  |
| %** | 1.0 | % |  | 1.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Global Services | 112,532 |  |  | 123,770 |  |  |  |  | (9.1) | % |  |  |  |  |  |  |  |  |
| %** | 10.7 | % |  | 14.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total revenue | $ | 1,056,521 |  |  | $ | 844,443 |  |  |  |  | 25.1 | % |  |  |  |  |  |  |  |  |

[0000936395-23-000014:mdna:27]
[same as prior period, unchanged from 0000936395-22-000053:mdna:29]

[0000936395-23-000014:mdna:28]
*    Denotes % change from fiscal 2022 to fiscal 2023

[0000936395-23-000014:mdna:29]
[same as prior period, unchanged from 0000936395-22-000053:mdna:31]

[0000936395-23-000014:mdna:30]
Quarter ended January 28, 2023 as compared to the quarter ended January 29, 2022

[0000936395-23-000014:mdna:31]
•Networking Platforms segment revenue increased by $228.5 million, reflecting product line sales increases of $194.7 million of our Converged Packet Optical products and $33.8 million of our Routing and Switching products.

[0000936395-23-000014:mdna:32]
◦Converged Packet Optical sales increased, primarily reflecting sales increases of $76.8 million of our 6500

[0000936395-23-000014:mdna:33]
Packet-Optical Platform, primarily to communication service providers and enterprise customers, $75.9 million of our Waveserver® products, primarily to Web-scale providers and communication service providers, and $44.3 million of our 6500 Reconfigurable Line System (“RLS”) products, primarily to Web-scale providers.

[0000936395-23-000014:mdna:34]
•Routing and Switching sales increased, primarily reflecting sales increases of $29.9 million of our Virtualization Edge software and $6.6 million of our platform independent software to communication service providers.

[0000936395-23-000014:mdna:35]
•Platform Software and Services segment revenue increased by $0.5 million, reflecting sales increases of $11.3 million in our subscription software services, primarily to communication service providers, offset by a sales decrease of $10.8 million in sales of software platforms, primarily due to decreased sales of our MCP software platform.

[0000936395-23-000014:mdna:36]
•Blue Planet Automation Software and Services segment revenue decreased by $5.7 million, primarily reflecting a decrease of $5.0 million in software platforms sales.

[0000936395-23-000014:mdna:37]
•Global Services segment revenue decreased by $11.2 million, primarily reflecting sales decreases of $5.8 million of

[0000936395-23-000014:mdna:38]
our installation and deployment services and $4.6 million of our maintenance support and training services. Installation and deployment services were adversely impacted by the current constrained supply environment, which resulted in delayed delivery of certain products for which installation and deployment services were ordered by customers, as described in more detail in “Overview” above.

[0000936395-23-000014:mdna:39]
[same as prior period, unchanged from 0000936395-22-000053:mdna:46]

[0000936395-23-000014:mdna:40]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our Americas region revenue for the quarter ended January 28, 2023 was primarily driven by increased sales in the United States and Canada. The increase in our APAC region revenue for the quarter ended January 28, 2023 was primarily driven by increased sales in India. The increase in our EMEA region revenue for the quarter ended January 28, 2023 was primarily driven by increased sales in the Netherlands.

[0000936395-23-000014:mdna:41]
[same as prior period, unchanged from 0000936395-22-000053:mdna:49]

[0000936395-23-000014:mdna:42]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 28, 2023 |  | January 29, 2022 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Americas | $ | 765,096 |  |  | $ | 595,144 |  |  |  |  | 28.6 | % |  |  |  |  |  |  |  |  |
| %** | 72.4 | % |  | 70.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| EMEA | 152,804 |  |  | 150,785 |  |  |  |  | 1.3 | % |  |  |  |  |  |  |  |  |
| %** | 14.5 | % |  | 17.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| APAC | 138,621 |  |  | 98,514 |  |  |  |  | 40.7 | % |  |  |  |  |  |  |  |  |
| %** | 13.1 | % |  | 11.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,056,521 |  |  | $ | 844,443 |  |  |  |  | 25.1 | % |  |  |  |  |  |  |  |  |

[0000936395-23-000014:mdna:43]
[same as prior period, unchanged from 0000936395-22-000053:mdna:51]

[0000936395-23-000014:mdna:44]
*    Denotes % change from fiscal 2022 to fiscal 2023

[0000936395-23-000014:mdna:45]
[same as prior period, unchanged from 0000936395-22-000053:mdna:53]

[0000936395-23-000014:mdna:46]
Quarter ended January 28, 2023 as compared to the quarter ended January 29, 2022

[0000936395-23-000014:mdna:47]
•Americas revenue increased by $170.0 million, reflecting sales increases of $180.5 million within our Networking

[0000936395-23-000014:mdna:48]
Platforms segment and $1.7 million within our Platform Software and Services segment. These sales increases were partially offset by sales decreases of $7.3 million within our Global Services segment and $4.9 million within our Blue Planet Automation Software and Services segment. The increase within our Networking Platforms segment reflects product line sales increases of $147.2 million of our Converged Packet Optical products and $33.2 million of our Routing and Switching products. The increase within our Converged Packet Optical product line was primarily related to sales increases of $65.4 million of our Waveserver products, primarily to Web-scale providers and communication service providers, $45.5 million of our 6500 Packet-Optical Platform, primarily to communication service providers, and $35.8 million of our 6500 RLS products, primarily to Web-scale providers. The increase within our Routing and Switching product line was primarily related to sales increases of $29.9 million of our Virtualization Edge software and $6.6 million of our platform independent software, both primarily to communication service providers.

[0000936395-23-000014:mdna:49]
•EMEA revenue increased by $2.0 million, primarily reflecting a sales increase of $5.8 million within our

[0000936395-23-000014:mdna:50]
Networking Platforms segment, which was partially offset by sales decreases of $2.5 million within our Global Services segment and $1.5 million within our Platform Software and Services segment.

[0000936395-23-000014:mdna:51]
•APAC revenue increased by $40.1 million, primarily reflecting a sales increase of $42.2 million within our

[0000936395-23-000014:mdna:52]
Networking Platforms segment, partially offset by sales decreases of $1.4 within our Global Services segment and $1.0 million within our Blue Planet Automation Software and Services segment. The increase within our Networking Platforms segment primarily reflects product line sales increases of $41.3 million of Converged Packet Optical products, which includes sales increases of $38.8 million of our 6500 Packet-Optical Platform, primarily to communication service provider customers in India.

[0000936395-23-000014:mdna:53]
[same as prior period, unchanged from 0000936395-22-000053:mdna:63]

[0000936395-23-000014:mdna:54]
There are a number of important factors or conditions that can adversely affect or cause our gross profit as a percentage of product or service revenue, or “gross margin,” to fluctuate on a quarterly basis. For example, early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers as they add capacity. The component elements that comprise our product cost of goods sold and services costs of goods sold, and certain factors that can cause gross margin to fluctuate, are described in detail in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” sections of our 2022 Annual Report.

[0000936395-23-000014:mdna:55]
The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-23-000014:mdna:56]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 28, 2023 |  | January 29, 2022 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Total revenue | $ | 1,056,521 |  |  | $ | 844,443 |  |  |  |  | 25.1 | % |  |  |  |  |  |  |  |  |
| Total cost of goods sold | 600,575 |  |  | 460,256 |  |  |  |  | 30.5 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 455,946 |  |  | $ | 384,187 |  |  |  |  | 18.7 | % |  |  |  |  |  |  |  |  |
| %** | 43.2 | % |  | 45.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-23-000014:mdna:57]
[same as prior period, unchanged from 0000936395-22-000053:mdna:67]

[0000936395-23-000014:mdna:58]
*    Denotes % change from fiscal 2022 to fiscal 2023

[0000936395-23-000014:mdna:59]
[same as prior period, unchanged from 0000936395-22-000053:mdna:69]

[0000936395-23-000014:mdna:60]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 28, 2023 |  | January 29, 2022 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Product revenue | $ | 877,715 |  |  | $ | 665,007 |  |  |  |  | 32.0 | % |  |  |  |  |  |  |  |  |
| Product cost of goods sold | 500,337 |  |  | 372,565 |  |  |  |  | 34.3 | % |  |  |  |  |  |  |  |  |
| Product gross profit | $ | 377,378 |  |  | $ | 292,442 |  |  |  |  | 29.0 | % |  |  |  |  |  |  |  |  |
| %** | 43.0 | % |  | 44.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-23-000014:mdna:61]
[same as prior period, unchanged from 0000936395-22-000053:mdna:71]

[0000936395-23-000014:mdna:62]
*    Denotes % change from fiscal 2022 to fiscal 2023

[0000936395-23-000014:mdna:63]
[same as prior period, unchanged from 0000936395-22-000053:mdna:73]

[0000936395-23-000014:mdna:64]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 28, 2023 |  | January 29, 2022 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Services revenue | $ | 178,806 |  |  | $ | 179,436 |  |  |  |  | (0.4) | % |  |  |  |  |  |  |  |  |
| Services cost of goods sold | 100,238 |  |  | 87,691 |  |  |  |  | 14.3 | % |  |  |  |  |  |  |  |  |
| Services gross profit | $ | 78,568 |  |  | $ | 91,745 |  |  |  |  | (14.4) | % |  |  |  |  |  |  |  |  |
| % ** | 43.9 | % |  | 51.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-23-000014:mdna:65]
[same as prior period, unchanged from 0000936395-22-000053:mdna:75]

[0000936395-23-000014:mdna:66]
*    Denotes % change from fiscal 2022 to fiscal 2023

[0000936395-23-000014:mdna:67]
[same as prior period, unchanged from 0000936395-22-000053:mdna:77]

[0000936395-23-000014:mdna:68]
Quarter ended January 28, 2023 as compared to the quarter ended January 29, 2022

[0000936395-23-000014:mdna:69]
•Gross profit increased by $71.8 million. Gross margin decreased by 230 basis points, primarily due to lower services margins and increased costs of components resulting from global supply chain shortages. As supply conditions gradually improve, particularly for lower margin “common” equipment and photonics, we expect our gross margin to be adversely impacted during the remainder of fiscal 2023 as a result of a higher concentration of lower margin product mix. We also expect our gross margin to continue be adversely impacted due to the challenges and costs associated with the constrained supply environment described in “Overview” above.

[0000936395-23-000014:mdna:70]
•Gross profit on products increased by $84.9 million. Product gross margin decreased by 100 basis points, primarily due to increased costs of components resulting from global supply chain shortages, and lower sales of software platforms.

[0000936395-23-000014:mdna:71]
•Gross profit on services decreased by $13.2 million. Services gross margin decreased by 720 basis points, primarily due to lower maintenance support, higher deployment costs, and losses incurred on certain Blue Planet software service projects. These decreases were partially offset by an increase in Platform Software services revenue.

[0000936395-23-000014:mdna:72]
[same as prior period, unchanged from 0000936395-22-000053:mdna:86]

[0000936395-23-000014:mdna:73]
[same as prior period, unchanged from 0000936395-22-000053:mdna:87]

[0000936395-23-000014:mdna:74]
Approximately 49.6% of our operating expense was non-U.S. Dollar-denominated during the first quarter of fiscal 2023, including expenses in Canadian Dollars, Indian Rupees, and Euros. During the first quarter of fiscal 2023, as compared to the first quarter of fiscal 2022, the U.S. Dollar primarily strengthened against these currencies. Consequently, our operating expense, net of hedging, reported in U.S. Dollars slightly decreased by approximately $9.8 million, or 2.6%.

[0000936395-23-000014:mdna:75]
The component elements that comprise each of our operating expense categories in the table below are set forth in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our 2022 Annual Report. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-23-000014:mdna:76]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 28, 2023 |  | January 29, 2022 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Research and development | $ | 181,730 |  |  | $ | 148,409 |  |  |  |  | 22.5 | % |  |  |  |  |  |  |  |  |
| %** | 17.2 | % |  | 17.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing | 123,807 |  |  | 118,881 |  |  |  |  | 4.1 | % |  |  |  |  |  |  |  |  |
| %** | 11.7 | % |  | 14.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | 50,896 |  |  | 44,498 |  |  |  |  | 14.4 | % |  |  |  |  |  |  |  |  |
| %** | 4.8 | % |  | 5.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 4,298 |  |  | 3,409 |  |  |  |  | 26.1 | % |  |  |  |  |  |  |  |  |
| %** | 0.4 | % |  | 0.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets | 7,441 |  |  | 8,918 |  |  |  |  | (16.6) | % |  |  |  |  |  |  |  |  |
| %** | 0.7 | % |  | 1.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition and integration costs | 2,558 |  |  | 68 |  |  |  |  | n/m |  |  |  |  |  |  |  |  |
| %** | 0.2 | % |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 370,730 |  |  | $ | 324,183 |  |  |  |  | 14.4 | % |  |  |  |  |  |  |  |  |
| %** | 35.1 | % |  | 38.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-23-000014:mdna:77]
[same as prior period, unchanged from 0000936395-22-000053:mdna:94]

[0000936395-23-000014:mdna:78]
*    Denotes % change from fiscal 2022 to fiscal 2023

[0000936395-23-000014:mdna:79]
[same as prior period, unchanged from 0000936395-22-000053:mdna:96]

[0000936395-23-000014:mdna:80]
n/m    Denotes a non-meaningful metric for the period

[0000936395-23-000014:mdna:81]
Quarter ended January 28, 2023 as compared to the quarter ended January 29, 2022

[0000936395-23-000014:mdna:82]
•Research and development expense benefited from $6.4 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $33.3 million. This increase

[0000936395-23-000014:mdna:83]
primarily reflects increases in employee headcount and related compensation costs, professional services and prototype expense. The increase in employee headcount was partially due to our acquisitions of Benu and Tibit.

[0000936395-23-000014:mdna:84]
•Selling and marketing expense benefited from $2.7 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expense increased by $4.9 million. This increase primarily reflects an increase in professional services and travel and entertainment costs, partially offset by a decrease in employee-related compensation costs related to sales commissions.

[0000936395-23-000014:mdna:85]
•General and administrative expense increased by $6.4 million. This increase primarily reflects increases in employee headcount and related compensation costs, professional services and increased bad debt expense, partially offset by decreased legal settlement costs.

[0000936395-23-000014:mdna:86]
•Significant asset impairments and restructuring costs reflects actions that we have taken with respect to our operations, global workforce and facilities as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-23-000014:mdna:87]
•Amortization of intangible assets decreased by $1.5 million due to certain intangible assets having reached the end of their economic lives, partially offset by additional intangibles acquired in connection with our acquisitions of Benu and Tibit during the first quarter of fiscal 2023.

[0000936395-23-000014:mdna:88]
•Acquisition and integration costs increased by $2.5 million and primarily reflect financial, legal, and accounting advisors and employee-related costs related to our acquisitions of Benu and Tibit.

[0000936395-23-000014:mdna:89]
For more information on our acquisitions, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000014:mdna:90]
[same as prior period, unchanged from 0000936395-22-000053:mdna:113]

[0000936395-23-000014:mdna:91]
[same as prior period, unchanged from 0000936395-22-000053:mdna:114]

[0000936395-23-000014:mdna:92]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 28, 2023 |  | January 29, 2022 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Interest and other income, net | $ | 31,973 |  |  | $ | 3,686 |  |  |  |  | 767.4 | % |  |  |  |  |  |  |  |  |
| %** | 3.0 | % |  | 0.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | 15,870 |  |  | $ | 8,648 |  |  |  |  | 83.5 | % |  |  |  |  |  |  |  |  |
| %** | 1.5 | % |  | 1.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for income taxes | $ | 25,078 |  |  | $ | 9,219 |  |  |  |  | 172.0 | % |  |  |  |  |  |  |  |  |
| %** | 2.4 | % |  | 1.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-23-000014:mdna:93]
[same as prior period, unchanged from 0000936395-22-000053:mdna:116]

[0000936395-23-000014:mdna:94]
*    Denotes % change from fiscal 2022 to fiscal 2023

[0000936395-23-000014:mdna:95]
[same as prior period, unchanged from 0000936395-22-000053:mdna:118]

[0000936395-23-000014:mdna:96]
Quarter ended January 28, 2023 as compared to the quarter ended January 29, 2022

[0000936395-23-000014:mdna:97]
•Interest and other income, net increased by $28.3 million, primarily resulting from the remeasurement of our previously held investment in Tibit to fair value, which resulted in a gain on our cost method equity investment of $26.5 million, and higher interest income. These increases were partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. For more information on our acquisitions, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000014:mdna:98]
•Interest expense increased by $7.2 million, primarily due to higher interest rates on our floating rate debt, net of hedging activity, and additional outstanding indebtedness, including our 2030 Notes issued in the first quarter of fiscal 2022 and the 2030 Term Loan incurred in the first quarter of fiscal 2023. For more information on our short-term and long-term debt, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000014:mdna:99]
•Provision for income taxes increased by $15.9 million, primarily due to an increase in pre-tax income in the first quarter of fiscal 2023 as compared to the first quarter of fiscal 2022. The effective tax rate for the first quarter of fiscal 2023 was higher than the effective tax rate for the first quarter of fiscal 2022, primarily due to the mandatory capitalization of research and development expenses in the first quarter of fiscal 2023.

[0000936395-23-000014:mdna:100]
[same as prior period, unchanged from 0000936395-22-000053:mdna:127]

[0000936395-23-000014:mdna:101]
[same as prior period, unchanged from 0000936395-22-000053:mdna:128]

[0000936395-23-000014:mdna:102]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 28, 2023 |  | January 29, 2022 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 202,147 |  |  | $ | 134,125 |  |  |  |  | 50.7 | % |  |  |  |  |  |  |  |  |
| Platform Software and Services | $ | 45,650 |  |  | $ | 49,496 |  |  |  |  | (7.8) | % |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | $ | (11,059) |  |  | $ | (1,034) |  |  |  |  | n/m |  |  |  |  |  |  |  |  |
| Global Services | $ | 37,478 |  |  | $ | 53,191 |  |  |  |  | (29.5) | % |  |  |  |  |  |  |  |  |

[0000936395-23-000014:mdna:103]
[same as prior period, unchanged from 0000936395-22-000053:mdna:130]

[0000936395-23-000014:mdna:104]
*    Denotes % change from fiscal 2022 to fiscal 2023

[0000936395-23-000014:mdna:105]
n/m    Denotes a non-meaningful metric for the period

[0000936395-23-000014:mdna:106]
Quarter ended January 28, 2023 as compared to the quarter ended January 29, 2022

[0000936395-23-000014:mdna:107]
•Networking Platforms segment profit increased by $68.0 million, primarily due to higher sales volume and higher gross margin as described above, partially offset by higher research and development costs.

[0000936395-23-000014:mdna:108]
•Platform Software and Services segment profit decreased by $3.8 million, primarily due to lower software sales volume, as described above, lower gross margin on software-related services, and higher research and development costs.

[0000936395-23-000014:mdna:109]
•Blue Planet Automation Software and Services segment loss increased by $10.0 million, primarily due to lower gross margin and lower sales volume, as described above, and higher research and development costs.

[0000936395-23-000014:mdna:110]
•Global Services segment profit decreased by $15.7 million, primarily due to lower sales volume and lower

[0000936395-23-000014:mdna:111]
gross margin on services as described above.

[0000936395-23-000014:mdna:112]
[same as prior period, unchanged from 0000936395-22-000053:mdna:143]

[0000936395-23-000014:mdna:113]
Overview. For the three months ended January 28, 2023, we used $265.6 million of cash in operating activities as our working capital requirements of approximately $392.3 million exceeded our net income (adjusted for non-cash charges) of approximately $126.6 million. For additional details, see “Cash Used In Operating Activities” below.

[0000936395-23-000014:mdna:114]
Cash, cash equivalents, and investments decreased by $25.5 million during the first three months of fiscal 2023. In addition to the cash used in operations, the decrease in cash also included the following items: (i) cash used for the acquisition of businesses of $230.0 million; (ii) cash used to fund our investing activities for capital expenditures totaling $30.0 million; and (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $13.0 million. Proceeds from the issuance of the 2030 Term Loan provided $493.5 million in cash, net of paid debt issuance costs, and proceeds from the issuance of equity under our employee stock purchase plan provided $14.3 million in cash during the three months ended January 28, 2023.

[0000936395-23-000014:mdna:115]
See Notes 4, 16 and 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for additional information on these transactions.

[0000936395-23-000014:mdna:116]
[same as prior period, unchanged from 0000936395-22-000053:mdna:148]

[0000936395-23-000014:mdna:117]
|  | January 28,2023 |  | October 29,2022 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,054,549 |  |  | $ | 994,352 |  |  | $ | 60,197 |  |
| Short-term investments in marketable debt securities | 100,424 |  |  | 153,989 |  |  | (53,565) |  |
| Long-term investments in marketable debt securities | 3,242 |  |  | 35,385 |  |  | (32,143) |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,158,215 |  |  | $ | 1,183,726 |  |  | $ | (25,511) |  |

[0000936395-23-000014:mdna:118]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of January 28, 2023 totaled $1.2 billion, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300.0 million with a maturity date of September 28, 2025, as modified on February 10, 2023. See

[0000936395-23-000014:mdna:119]
Note 23 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of January 28, 2023, letters of credit totaling $86.1 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 28, 2023.

[0000936395-23-000014:mdna:120]
Foreign Liquidity. Cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $250.4 million as of January 28, 2023. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $34.0 million.

[0000936395-23-000014:mdna:121]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. During the first three months of fiscal 2023, we did not repurchase any additional common stock under the stock repurchase program, and $500.0 million remained under the current repurchase authorization as of January 28, 2023. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000014:mdna:122]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-23-000014:mdna:123]
[same as prior period, unchanged from 0000936395-22-000053:mdna:155]

[0000936395-23-000014:mdna:124]
The following sections set forth the components of our $265.6 million of cash used in operating activities during the first three months of fiscal 2023:

[0000936395-23-000014:mdna:125]
[same as prior period, unchanged from 0000936395-22-000053:mdna:157]

[0000936395-23-000014:mdna:126]
[same as prior period, unchanged from 0000936395-22-000053:mdna:158]

[0000936395-23-000014:mdna:127]
|  | Three Months Ended |
|  | January 28, 2023 |
| Net income | $ | 76,241 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 22,208 |  |
| Share-based compensation expenses | 30,512 |  |
| Amortization of intangible assets | 10,325 |  |
| Deferred taxes | (7,247) |  |
| Provision for inventory excess and obsolescence | 5,503 |  |
| Provision for warranty | 8,230 |  |
| Gain on cost method equity investment | (26,455) |  |
| Other | 7,325 |  |
| Net income (adjusted for non-cash charges) | $ | 126,642 |  |

[0000936395-23-000014:mdna:128]
[same as prior period, unchanged from 0000936395-22-000053:mdna:160]

[0000936395-23-000014:mdna:129]
We used $392.3 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-23-000014:mdna:130]
|  | Three Months Ended |
|  | January 28, 2023 |
| Cash used in accounts receivable | $ | (133,067) |  |
| Cash used in inventories | (235,059) |  |
| Cash provided by prepaid expenses and other | 4,667 |  |
| Cash used in accounts payable, accruals, and other obligations | (56,979) |  |
| Cash provided by deferred revenue | 29,459 |  |
| Cash used in operating lease assets and liabilities, net | (1,302) |  |
| Total cash used for working capital | $ | (392,281) |  |

[0000936395-23-000014:mdna:131]
As compared to the end of fiscal 2022:

[0000936395-23-000014:mdna:132]
•The $133.1 million of cash used in accounts receivable during the first three months of fiscal 2023 reflects increased sales volume at the end of the first quarter of fiscal 2023;

[0000936395-23-000014:mdna:133]
•The $235.1 million of cash used in inventories during the first three months of fiscal 2023 primarily reflects increases in raw materials inventory related to the steps that we are taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts described in “Overview” above;

[0000936395-23-000014:mdna:134]
•The $4.7 million of cash provided by prepaid expense and other during the first three months of fiscal 2023 primarily reflects decreases in contract assets, partially offset by increases in prepaid value-added tax (VAT) and other taxes and foreign currency forward contracts;

[0000936395-23-000014:mdna:135]
•The $57.0 million of cash used in accounts payable, accruals, and other obligations during the first three months of fiscal 2023 primarily reflects the timing of payments to employees under our annual cash incentive compensation plans and payments to suppliers;

[0000936395-23-000014:mdna:136]
•The $29.5 million of cash provided by deferred revenue during the first three months of fiscal 2023 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-23-000014:mdna:137]
•The $1.3 million of cash used in operating lease assets and liabilities, net, during the first three months of fiscal 2023 represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-23-000014:mdna:138]
Our days sales outstanding (“DSOs”) increased from 97 for first three months of fiscal 2022 to 103 for the first three months of fiscal 2023. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns decreased from 3.3 for the first three months of fiscal 2022 to 1.7 for the first three months of fiscal 2023 due to the increases in inventory as described in “Overview” above.

[0000936395-23-000014:mdna:139]
Cash Paid for Interest, Net

[0000936395-23-000014:mdna:140]
The following table sets forth the cash paid for interest, net, during the period (in thousands):

[0000936395-23-000014:mdna:141]
|  | Three Months Ended |
|  | January 28, 2023 |
| Term Loan due September 28, 2025(1) | $ | 9,769 |  |
| Term Loan due January 31, 2030(2) | — |  |
| Senior Notes due January 31, 2030(3) | — |  |
| Interest rate swaps(4) | (802) |  |
| ABL Credit Facility(5) | 516 |  |
| Finance leases | 1,053 |  |
| Cash paid during period | $ | 10,536 |  |

[0000936395-23-000014:mdna:142]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bore interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00% through its amendment on January 19, 2023. The 2025 Term loan now bears interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. At the end of the first quarter of fiscal 2023, the interest rate on the 2025 Term Loan was 6.24%.

[0000936395-23-000014:mdna:143]
(2) Interest on the 2030 Term Loan is payable periodically based on the interest period selected for borrowing. The 2030 Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 2.50% subject to a minimum SOFR rate of 0.00%. At the end of the first quarter of fiscal 2023, the interest rate on the 2030 Term Loan was 6.98%.

[0000936395-23-000014:mdna:144]
(3) The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022.

[0000936395-23-000014:mdna:145]
(4) The interest rate swaps and the basis swap fix the SOFR rate for $350.0 million of the 2025 Term Loan at 2.883% through September 2023. In addition, the 2028 interest rate swaps fix the SOFR rate for $350.0 million of the 2030 Term Loan at 3.47% through January 2028.

[0000936395-23-000014:mdna:146]
(5) During the first three months of fiscal 2023, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.5 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-23-000014:mdna:147]
For additional information about our debt, ABL Credit Facility and interest rate swaps, see Notes 15, 16 and 23 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000014:mdna:148]
[same as prior period, unchanged from 0000936395-22-000053:mdna:178]

[0000936395-23-000014:mdna:149]
Our contractual obligations have not changed materially since October 29, 2022, except for the items listed below. For a summary of our contractual obligations, see Item 7 of Part II of the 2022 Annual Report.

[0000936395-23-000014:mdna:150]
Purchase Order Obligations. As of January 28, 2023 we had $2.4 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule, or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable, and unconditional obligations.

[0000936395-23-000014:mdna:151]
Debt. As of January 28, 2023, we had $500.0 million outstanding principal associated with our 2030 Term Loan, with $5.0 million payable within 12 months. Interest on the 2030 Term Loan and payments due under the interest rate swaps are variable and calculated using the rate in effect on the balance sheet date. Future interest payments associated with the 2030 Term Loan total $234.4 million, with $33.1 million payable within 12 months. For additional information about the 2030 Term Loan, see Note 16 to our Condensed Consolidated Financial Statements included in Item I of Part I of this report.

[0000936395-23-000014:mdna:152]
[same as prior period, unchanged from 0000936395-22-000053:mdna:182]

[0000936395-23-000014:mdna:153]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-23-000014:mdna:154]
Our critical accounting policies and estimates have not changed materially since October 29, 2022. For a discussion of our critical accounting policies and estimates, see “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Item 7 of Part II of our 2022 Annual Report.

[0000936395-23-000014:mdna:155]
[same as prior period, unchanged from 0000936395-22-000053:mdna:185]

[0000936395-23-000014:mdna:156]
[same as prior period, unchanged from 0000936395-22-000053:mdna:186]
