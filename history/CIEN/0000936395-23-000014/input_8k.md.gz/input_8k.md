# CIEN 8-K — 0000936395-23-000009 filed 2023-03-06

## item codes, every 8-K on or before 2023-03-08

- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2023-03-08

- none on or before 2023-03-08

## item 2.02 — earnings release, exhibit 99.1

[0000936395-23-000009:8k_2_02:1]
EX-99.1
2
ex9912023q1earningspressre.htm
EX-99.1

[0000936395-23-000009:8k_2_02:2]
Document

[0000936395-23-000009:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-23-000009:8k_2_02:4]
Ciena Reports Fiscal First Quarter 2023 Financial Results

[0000936395-23-000009:8k_2_02:5]
Revenue increased 25% year-over-year

[0000936395-23-000009:8k_2_02:6]
HANOVER, Md. - March 6, 2023 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal first quarter ended January 28, 2023.

[0000936395-23-000009:8k_2_02:7]
•Q1 Revenue: $1.06 billion

[0000936395-23-000009:8k_2_02:8]
•Q1 Net Income per Share: $0.51 GAAP; $0.64 adjusted (non-GAAP)

[0000936395-23-000009:8k_2_02:9]
"We delivered record revenue in the first quarter, reflecting continued gradual improvement in the supply chain environment and strong customer demand for our market-leading technology," said Gary Smith, president and CEO of Ciena. "With strong momentum across our business, supported by robust fundamental drivers and visibility provided by our backlog, we remain confident in our ability to continue to take market share."

[0000936395-23-000009:8k_2_02:10]
For fiscal first quarter 2023, Ciena reported revenue of $1.06 billion as compared to $844.4 million for the fiscal first quarter 2022.

[0000936395-23-000009:8k_2_02:11]
Ciena's GAAP net income for the fiscal first quarter 2023 was $76.2 million, or $0.51 per diluted common share, which compares to a GAAP net income of $45.8 million, or $0.29 per diluted common share, for the fiscal first quarter 2022.

[0000936395-23-000009:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal first quarter 2023 was $95.6 million, or $0.64 per diluted common share, which compares to an adjusted (non-GAAP) net income of $72.6 million, or $0.47 per diluted common share, for the fiscal first quarter 2022.

[0000936395-23-000009:8k_2_02:13]
Fiscal First Quarter 2023 Performance Summary

[0000936395-23-000009:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-23-000009:8k_2_02:15]
|  |  | GAAP Results (unaudited) |
|  |  | Q1 |  | Q1 |  | Period Change |  |  |  |  |
|  |  | FY 2023 |  | FY 2022 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 1,056.5 |  |  | $ | 844.4 |  |  | 25.1 | % |  |  |  |  |  |  |
| Gross margin |  | 43.2 | % |  | 45.5 | % |  | (2.3) | % |  |  |  |  |  |  |
| Operating expense |  | $ | 370.7 |  |  | $ | 324.2 |  |  | 14.3 | % |  |  |  |  |  |  |
| Operating margin |  | 8.1 | % |  | 7.1 | % |  | 1.0 | % |  |  |  |  |  |  |

[0000936395-23-000009:8k_2_02:16]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q1 |  | Q1 |  | Period Change |  |  |  |  |
|  |  | FY 2023 |  | FY 2022 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 1,056.5 |  |  | $ | 844.4 |  |  | 25.1 | % |  |  |  |  |  |  |
| Adj. gross margin |  | 43.7 | % |  | 46.2 | % |  | (2.5) | % |  |  |  |  |  |  |
| Adj. operating expense |  | $ | 329.3 |  |  | $ | 290.0 |  |  | 13.6 | % |  |  |  |  |  |  |
| Adj. operating margin |  | 12.6 | % |  | 11.8 | % |  | 0.8 | % |  |  |  |  |  |  |
| Adj. EBITDA |  | $ | 155.1 |  |  | $ | 123.7 |  |  | 25.4 | % |  |  |  |  |  |  |

[0000936395-23-000009:8k_2_02:17]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-23-000009:8k_2_02:18]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q1 FY 2023 |  | Q1 FY 2022 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 735.6 |  |  | 69.6 |  |  | $ | 540.9 |  |  | 64.1 |  |
| Routing and Switching |  | 119.5 |  |  | 11.3 |  |  | 85.7 |  |  | 10.1 |  |
| Total Networking Platforms |  | 855.1 |  |  | 80.9 |  |  | 626.6 |  |  | 74.2 |  |
| Platform Software and Services |  | 73.4 |  |  | 6.9 |  |  | 72.9 |  |  | 8.6 |  |
| Blue Planet Automation Software and Services |  | 15.4 |  |  | 1.5 |  |  | 21.1 |  |  | 2.5 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 67.9 |  |  | 6.4 |  |  | 72.5 |  |  | 8.6 |  |
| Installation and Deployment |  | 34.6 |  |  | 3.3 |  |  | 40.4 |  |  | 4.8 |  |
| Consulting and Network Design |  | 10.1 |  |  | 1.0 |  |  | 10.9 |  |  | 1.3 |  |
| Total Global Services |  | 112.6 |  |  | 10.7 |  |  | 123.8 |  |  | 14.7 |  |
| Total |  | $ | 1,056.5 |  |  | 100.0 |  |  | $ | 844.4 |  |  | 100.0 |  |

[0000936395-23-000009:8k_2_02:19]
**  Denotes %  of total revenue

[0000936395-23-000009:8k_2_02:20]
Additional Performance Metrics for Fiscal First Quarter 2023

[0000936395-23-000009:8k_2_02:21]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q1 FY 2023 |  | Q1 FY 2022 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 765.1 |  |  | 72.4 |  |  | $ | 595.1 |  |  | 70.5 |  |
| Europe, Middle East and Africa |  | 152.8 |  |  | 14.5 |  |  | 150.8 |  |  | 17.8 |  |
| Asia Pacific |  | 138.6 |  |  | 13.1 |  |  | 98.5 |  |  | 11.7 |  |
| Total |  | $ | 1,056.5 |  |  | 100.0 |  |  | $ | 844.4 |  |  | 100.0 |  |

[0000936395-23-000009:8k_2_02:22]
**  Denotes %  of total revenue

[0000936395-23-000009:8k_2_02:23]
2

[0000936395-23-000009:8k_2_02:24]
•Two customers represented 10%-plus of revenue combining for a total of 25.7% of revenue

[0000936395-23-000009:8k_2_02:25]
•Cash and investments totaled $1.2 billion

[0000936395-23-000009:8k_2_02:26]
•Cash flow used in operations totaled $265.6 million

[0000936395-23-000009:8k_2_02:27]
•Average days' sales outstanding (DSOs) were 103

[0000936395-23-000009:8k_2_02:28]
•Accounts receivable, net balance was $1.05 billion

[0000936395-23-000009:8k_2_02:29]
•Unbilled contract asset, net balance was $148.8 million

[0000936395-23-000009:8k_2_02:30]
•Inventories totaled $1.18 billion, including:

[0000936395-23-000009:8k_2_02:31]
◦Raw materials: $846.6 million

[0000936395-23-000009:8k_2_02:32]
◦Work in process: $18.4 million

[0000936395-23-000009:8k_2_02:33]
◦Finished goods: $300.7 million

[0000936395-23-000009:8k_2_02:34]
◦Deferred cost of sales: $51.3 million

[0000936395-23-000009:8k_2_02:35]
◦Reserve for excess and obsolescence: $(38.9) million

[0000936395-23-000009:8k_2_02:36]
•Product inventory turns were 1.7

[0000936395-23-000009:8k_2_02:37]
•Headcount totaled 8,361

[0000936395-23-000009:8k_2_02:38]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal First Quarter 2023 Results

[0000936395-23-000009:8k_2_02:39]
Today, Monday, March 6, 2023, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal first quarter 2023 results.

[0000936395-23-000009:8k_2_02:40]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-23-000009:8k_2_02:41]
Notes to Investors

[0000936395-23-000009:8k_2_02:42]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered record revenue in the first quarter, reflecting continued gradual improvement in the supply chain environment and strong customer demand for our market-leading technology"; "With strong momentum across our business, supported by robust fundamental drivers and visibility provided by our backlog, we remain confident in our ability to continue to take market share."

[0000936395-23-000009:8k_2_02:43]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; our ability to execute our business and growth strategies; the impact of supply chain constraints or disruptions; the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our business operations, liquidity and financial results; changes in network spending or network strategy by our customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and

[0000936395-23-000009:8k_2_02:44]
geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical events, including but not limited to the ongoing conflict between Ukraine and Russia, and public health emergencies; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including its Annual Report on Form 10-K filed with the SEC on December 16, 2022 and included in its Quarterly Report on Form 10-Q for the first quarter of fiscal 2023 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-23-000009:8k_2_02:45]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-23-000009:8k_2_02:46]
About Ciena. Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our customers create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on LinkedIn, Twitter, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-23-000009:8k_2_02:47]
4

[0000936395-23-000009:8k_2_02:48]
CIENA CORPORATION

[0000936395-23-000009:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-23-000009:8k_2_02:50]
(in thousands, except per share data)

[0000936395-23-000009:8k_2_02:51]
(unaudited)

[0000936395-23-000009:8k_2_02:52]
|  | Quarter Ended |  |  |
|  | January 28, |  | January 29, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 877,715 |  |  | $ | 665,007 |  |  |  |  |  |
| Services | 178,806 |  |  | 179,436 |  |  |  |  |  |
| Total revenue | 1,056,521 |  |  | 844,443 |  |  |  |  |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 500,337 |  |  | 372,565 |  |  |  |  |  |
| Services | 100,238 |  |  | 87,691 |  |  |  |  |  |
| Total cost of goods sold | 600,575 |  |  | 460,256 |  |  |  |  |  |
| Gross profit | 455,946 |  |  | 384,187 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 181,730 |  |  | 148,409 |  |  |  |  |  |
| Selling and marketing | 123,807 |  |  | 118,881 |  |  |  |  |  |
| General and administrative | 50,896 |  |  | 44,498 |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 4,298 |  |  | 3,409 |  |  |  |  |  |
| Amortization of intangible assets | 7,441 |  |  | 8,918 |  |  |  |  |  |
| Acquisition and integration costs | 2,558 |  |  | 68 |  |  |  |  |  |
| Total operating expenses | 370,730 |  |  | 324,183 |  |  |  |  |  |
| Income from operations | 85,216 |  |  | 60,004 |  |  |  |  |  |
| Interest and other income, net | 31,973 |  |  | 3,686 |  |  |  |  |  |
| Interest expense | (15,870) |  |  | (8,648) |  |  |  |  |  |
| Income before income taxes | 101,319 |  |  | 55,042 |  |  |  |  |  |
| Provision for income taxes | 25,078 |  |  | 9,219 |  |  |  |  |  |
| Net income | $ | 76,241 |  |  | $ | 45,823 |  |  |  |  |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.51 |  |  | $ | 0.30 |  |  |  |  |  |
| Diluted net income per potential common share | $ | 0.51 |  |  | $ | 0.29 |  |  |  |  |  |
| Weighted average basic common shares outstanding | 149,081 |  |  | 154,151 |  |  |  |  |  |
| Weighted average dilutive potential common shares outstanding 1 | 149,551 |  |  | 155,807 |  |  |  |  |  |

[0000936395-23-000009:8k_2_02:53]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 0.5 million for the first quarter of fiscal 2023; and (ii) 1.7 million shares for the first quarter of fiscal 2022.

[0000936395-23-000009:8k_2_02:54]
CIENA CORPORATION

[0000936395-23-000009:8k_2_02:55]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-23-000009:8k_2_02:56]
(in thousands, except share data)

[0000936395-23-000009:8k_2_02:57]
(unaudited)

[0000936395-23-000009:8k_2_02:58]
|  | January 28,2023 |  | October 29,2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,054,549 |  |  | $ | 994,352 |  |
| Short-term investments | 100,424 |  |  | 153,989 |  |
| Accounts receivable, net | 1,054,917 |  |  | 920,772 |  |
| Inventories | 1,178,089 |  |  | 946,730 |  |
| Prepaid expenses and other | 374,590 |  |  | 370,053 |  |
| Total current assets | 3,762,569 |  |  | 3,385,896 |  |
| Long-term investments | 3,242 |  |  | 35,385 |  |
| Equipment, building, furniture and fixtures, net | 278,985 |  |  | 267,779 |  |
| Operating lease right-of-use assets | 48,438 |  |  | 45,108 |  |
| Goodwill | 446,548 |  |  | 328,322 |  |
| Other intangible assets, net | 244,648 |  |  | 69,517 |  |
| Deferred tax asset, net | 797,214 |  |  | 824,008 |  |
| Other long-term assets | 90,853 |  |  | 113,617 |  |
| Total assets | $ | 5,672,497 |  |  | $ | 5,069,632 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 478,486 |  |  | $ | 516,047 |  |
| Accrued liabilities and other short-term obligations | 343,938 |  |  | 360,782 |  |
| Deferred revenue | 164,758 |  |  | 137,899 |  |
| Operating lease liabilities | 19,098 |  |  | 18,925 |  |
| Current portion of long-term debt | 11,930 |  |  | 6,930 |  |
| Total current liabilities | 1,018,210 |  |  | 1,040,583 |  |
| Long-term deferred revenue | 66,620 |  |  | 62,336 |  |
| Other long-term obligations | 156,572 |  |  | 150,335 |  |
| Long-term operating lease liabilities | 45,305 |  |  | 42,392 |  |
| Long-term debt, net | 1,547,495 |  |  | 1,061,125 |  |
| Total liabilities | $ | 2,834,202 |  |  | $ | 2,356,771 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 149,157,588 and 148,412,943 shares issued and outstanding | 1,492 |  |  | 1,484 |  |
| Additional paid-in capital | 6,422,091 |  |  | 6,390,252 |  |
| Accumulated other comprehensive loss | (29,299) |  |  | (46,645) |  |
| Accumulated deficit | (3,555,989) |  |  | (3,632,230) |  |
| Total stockholders’ equity | 2,838,295 |  |  | 2,712,861 |  |
| Total liabilities and stockholders’ equity | $ | 5,672,497 |  |  | $ | 5,069,632 |  |

[0000936395-23-000009:8k_2_02:59]
6

[0000936395-23-000009:8k_2_02:60]
CIENA CORPORATION

[0000936395-23-000009:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-23-000009:8k_2_02:62]
(in thousands) (unaudited)

[0000936395-23-000009:8k_2_02:63]
|  | Three Months Ended |
|  | January 28, |  | January 29, |
|  | 2023 |  | 2022 |
| Cash flows used in operating activities: |  |  |  |
| Net income | $ | 76,241 |  |  | $ | 45,823 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 22,208 |  |  | 23,653 |  |
| Share-based compensation expense | 30,512 |  |  | 24,297 |  |
| Amortization of intangible assets | 10,325 |  |  | 12,230 |  |
| Deferred taxes | (7,247) |  |  | (766) |  |
| Provision for inventory excess and obsolescence | 5,503 |  |  | 3,799 |  |
| Provision for warranty | 8,230 |  |  | 2,817 |  |
| Gain on cost method equity investment | (26,455) |  |  | (4,120) |  |
| Other | 7,325 |  |  | (4,495) |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (133,067) |  |  | 87,223 |  |
| Inventories | (235,059) |  |  | (87,178) |  |
| Prepaid expenses and other | 4,667 |  |  | (14,134) |  |
| Operating lease right-of-use assets | 3,891 |  |  | 4,120 |  |
| Accounts payable, accruals and other obligations | (56,979) |  |  | (152,981) |  |
| Deferred revenue | 29,459 |  |  | 10,417 |  |
| Short and long-term operating lease liabilities | (5,193) |  |  | (5,116) |  |
| Net cash used in operating activities | (265,639) |  |  | (54,411) |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (30,030) |  |  | (25,804) |  |
| Purchases of investments | (35,411) |  |  | (350,465) |  |
| Proceeds from sales and maturities of investments | 123,249 |  |  | 50,000 |  |
| Settlement of foreign currency forward contracts, net | (4,001) |  |  | 1,346 |  |
| Acquisition of business, net of cash acquired | (230,048) |  |  | (56,036) |  |
| Net cash used in investing activities | (176,241) |  |  | (380,959) |  |
| Cash flows provided by financing activities: |  |  |  |
| Proceeds from issuance of senior notes | — |  |  | 400,000 |  |
| Proceeds from issuance of term loan, net | 497,500 |  |  | — |  |
| Payment of long term debt | (1,732) |  |  | — |  |
| Payment of debt issuance costs | (3,996) |  |  | (4,506) |  |
| Payment of finance lease obligations | (913) |  |  | (771) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (12,980) |  |  | (25,150) |  |
| Repurchases of common stock - repurchase program | — |  |  | (250,000) |  |
| Proceeds from issuance of common stock | 14,315 |  |  | 15,146 |  |
| Net cash provided by financing activities | 492,194 |  |  | 134,719 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 9,884 |  |  | (3,259) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 60,198 |  |  | (303,910) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 994,378 |  |  | 1,422,604 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,054,576 |  |  | $ | 1,118,694 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 10,536 |  |  | $ | 7,670 |  |
| Cash paid during the period for income taxes, net | $ | 8,383 |  |  | $ | 6,112 |  |
| Operating lease payments | $ | 5,638 |  |  | $ | 5,480 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 7,354 |  |  | $ | 2,972 |  |
| Operating right-of-use assets subject to lease liability | $ | 6,045 |  |  | $ | 3,376 |  |
| Gain on cost method equity investment | $ | 26,455 |  |  | $ | 4,120 |  |

[0000936395-23-000009:8k_2_02:64]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | January 28, |  | January 29, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 455,946 |  |  | $ | 384,187 |  |  |  |  |  |
| Share-based compensation-products |  | 1,051 |  |  | 900 |  |  |  |  |  |
| Share-based compensation-services |  | 2,297 |  |  | 1,584 |  |  |  |  |  |
| Amortization of intangible assets |  | 2,883 |  |  | 3,312 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 6,231 |  |  | 5,796 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit |  | $ | 462,177 |  |  | $ | 389,983 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.7 | % |  | 46.2 | % |  |  |  |  |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 370,730 |  |  | $ | 324,183 |  |  |  |  |  |
| Share-based compensation-research and development |  | 9,234 |  |  | 6,830 |  |  |  |  |  |
| Share-based compensation-sales and marketing |  | 8,424 |  |  | 7,060 |  |  |  |  |  |
| Share-based compensation-general and administrative |  | 9,468 |  |  | 7,912 |  |  |  |  |  |
| Significant asset impairments and restructuring costs |  | 4,298 |  |  | 3,409 |  |  |  |  |  |
| Amortization of intangible assets |  | 7,441 |  |  | 8,918 |  |  |  |  |  |
| Acquisition and integration costs |  | 2,558 |  |  | 68 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 41,423 |  |  | 34,197 |  |  |  |  |  |
| Adjusted (non-GAAP) operating expense |  | $ | 329,307 |  |  | $ | 289,986 |  |  |  |  |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 85,216 |  |  | $ | 60,004 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 6,231 |  |  | 5,796 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 41,423 |  |  | 34,197 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 47,654 |  |  | 39,993 |  |  |  |  |  |
| Adjusted (non-GAAP) income from operations |  | $ | 132,870 |  |  | $ | 99,997 |  |  |  |  |  |
| Adjusted (non-GAAP) operating margin percentage |  | 12.6 | % |  | 11.8 | % |  |  |  |  |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 76,241 |  |  | $ | 45,823 |  |  |  |  |  |
| Exclude GAAP provision for income taxes |  | 25,078 |  |  | 9,219 |  |  |  |  |  |
| Income before income taxes |  | 101,319 |  |  | 55,042 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 47,654 |  |  | 39,993 |  |  |  |  |  |
| Gain on cost method equity investment |  | (26,455) |  |  | (4,120) |  |  |  |  |  |
| Adjusted income before income taxes |  | 122,518 |  |  | 90,915 |  |  |  |  |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 26,954 |  |  | 18,365 |  |  |  |  |  |
| Adjusted (non-GAAP) net income |  | $ | 95,564 |  |  | $ | 72,550 |  |  |  |  |  |
| Weighted average basic common shares outstanding |  | 149,081 |  | 154,151 |  |  |  |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 149,551 |  | 155,807 |  |  |  |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.51 |  |  | $ | 0.29 |  |  |  |  |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.64 |  |  | $ | 0.47 |  |  |  |  |  |

[0000936395-23-000009:8k_2_02:65]
8

[0000936395-23-000009:8k_2_02:66]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 0.5 million for the first quarter of fiscal 2023; and (ii) 1.7 million for the first quarter of fiscal 2022.

[0000936395-23-000009:8k_2_02:67]
9

[0000936395-23-000009:8k_2_02:68]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | January 28, |  | January 29, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 76,241 |  |  | $ | 45,823 |  |  |  |  |  |
| Add: Interest expense |  | 15,870 |  |  | 8,648 |  |  |  |  |  |
| Less: Interest and other income, net |  | 31,973 |  |  | 3,686 |  |  |  |  |  |
| Add: Provision for income taxes |  | 25,078 |  |  | 9,219 |  |  |  |  |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 22,208 |  |  | 23,653 |  |  |  |  |  |
| Add: Amortization of intangible assets |  | 10,325 |  |  | 12,230 |  |  |  |  |  |
| EBITDA |  | $ | 117,749 |  |  | $ | 95,887 |  |  |  |  |  |
| Add: Share-based compensation cost |  | 30,474 |  |  | 24,297 |  |  |  |  |  |
| Add: Significant asset impairments and restructuring costs |  | 4,298 |  |  | 3,409 |  |  |  |  |  |
| Add: Acquisition and integration costs |  | 2,558 |  |  | 68 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 155,079 |  |  | $ | 123,661 |  |  |  |  |  |

[0000936395-23-000009:8k_2_02:69]
* * *

[0000936395-23-000009:8k_2_02:70]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-23-000009:8k_2_02:71]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-23-000009:8k_2_02:72]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities, the redesign of business processes.

[0000936395-23-000009:8k_2_02:73]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-23-000009:8k_2_02:74]
•Acquisition and integration costs  - primarily consist of financial, legal and accounting advisors' costs and employment-related costs related to Ciena's acquisitions in fiscal 2022 and fiscal 2023.

[0000936395-23-000009:8k_2_02:75]
•Gain on cost method equity investment - reflects changes in the carrying value of certain cost method equity investments due to triggering events. During the first quarter of fiscal 2023, the acquisition of Tibit triggered the remeasurement of our previously held investment in Tibit to fair value, which resulted in recognizing a gain on our cost method equity investment of $26.5 million.

[0000936395-23-000009:8k_2_02:76]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 22.0% for the first fiscal quarter of 2023 and 20.2% for the first fiscal quarter of 2022. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
