# CIEN MD&A — 0000936395-21-000010


## mdna

[0000936395-21-000010:mdna:1]
[same as prior period, unchanged from 0000936395-20-000036:mdna:1]

[0000936395-21-000010:mdna:2]
[same as prior period, unchanged from 0000936395-20-000036:mdna:2]

[0000936395-21-000010:mdna:3]
This report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. Forward-looking statements may appear throughout this report, including in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors.” In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “can,” “should,” “could,” “expects,” “future,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” or “continue” or the negative of those words and other comparable words. You should be aware that the forward-looking statements contained in this report are based on our current views and assumptions, and are subject to known and unknown risks, uncertainties and other factors that may cause actual events or results to differ materially.

[0000936395-21-000010:mdna:4]
[same as prior period, unchanged from 0000936395-20-000036:mdna:41]

[0000936395-21-000010:mdna:5]
The following Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided as a supplement to, and should be read in conjunction with, our 2020 Annual Report and our Condensed Consolidated Financial Statements and the accompanying notes thereto included in Item 1 of Part I of this report.

[0000936395-21-000010:mdna:6]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software and services that enable the transport, routing, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Our solutions include Networking Platforms, including our Converged Packet Optical and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. To complement these solutions, we offer Platform Software, which provides management, domain control and specialized applications that automate network lifecycle operations, including provisioning equipment and services, network data, analytics and policy-based assurance to achieve closed loop automation across multi-vendor and multi-domain network environments. Through our Blue Planet® Software suite, we enable customers to transform their business and operations support systems through software-based automation of their network and IT infrastructures. To complement our hardware and software products, we offer a broad range of services that help our customers build, operate and improve their networks and associated operational environments, including network optimization and migration offerings.

[0000936395-21-000010:mdna:7]
[same as prior period, unchanged from 0000936395-20-000036:mdna:46]

[0000936395-21-000010:mdna:8]
Demand for Products & Services. The demand environment continues to be adversely impacted by the COVID-19 pandemic, resulting in lower order volumes and revenue in the first quarter of fiscal 2021 as compared to the first quarter of fiscal 2020. We expect this more cautious spending environment to continue through at least the second quarter of fiscal 2021 and expect these conditions to adversely affect order volumes and revenue in the short term, as compared to our first half of fiscal 2020.

[0000936395-21-000010:mdna:9]
Services and Customer Fulfillment. We continue to experience some disruption in our ability to provide installation, professional and fulfillment services to customers due to site readiness and access limitations, limited customer availability, project delays or re-prioritization by customers, and travel bans or restrictions on movement or gatherings. We expect these conditions to persist in the short term and, as a result, to continue to adversely impact our revenue and results of operations.

[0000936395-21-000010:mdna:10]
Sales & Marketing. Restrictions on travel due to COVID-19 and limitations on interactions with customers, such as field and lab trials, have continued to negatively impact our ability to carry out certain sales and marketing activities, including our ability to secure new customers, to qualify and sell new products, and to grow sales with customers. Delays in customers operationalizing new network projects that we anticipated occurring on their original timelines continue to adversely affect our revenue. Conversely, our recent gross margin performance has benefited from these dynamics, with a larger percentage of our revenue comprised of existing business, as compared to new design wins and early in life projects, which tend to have lower margins.

[0000936395-21-000010:mdna:11]
Market Growth & Conditions. As a result of the impact of the COVID-19 pandemic on market dynamics, particularly in the enterprise business segments of our communications service provider customers, the growth rates in our addressable markets have been adversely impacted. We expect these market dynamics, including constrained customer spending and the decreased velocity of new business execution, to persist through at least the first half of fiscal 2021.

[0000936395-21-000010:mdna:12]
The COVID-19 pandemic and countermeasures taken to contain its spread have caused economic and financial disruptions globally. We continue to monitor the situation and actively assess further implications to our business, supply chain, fulfillment operations and customer demand. However, the COVID-19 situation remains dynamic, and the duration and severity of its impact on our business and results of operations in future periods remains uncertain. If the COVID-19 pandemic or its adverse effects become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our business or operations, or in economic activity and demand for our products and services generally, our business and results of operations in future periods could be materially adversely affected.

[0000936395-21-000010:mdna:13]
For additional information regarding our business, industry, market opportunity, competitive landscape, and strategy, see our 2020 Annual Report, including the discussion in that report of the impact of the COVID-19 pandemic on our business, supply chain, and market conditions.

[0000936395-21-000010:mdna:14]
[same as prior period, unchanged from 0000936395-20-000036:mdna:66]

[0000936395-21-000010:mdna:15]
[same as prior period, unchanged from 0000936395-20-000036:mdna:67]

[0000936395-21-000010:mdna:16]
Our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. Effective as of the beginning of fiscal 2021, we renamed our “Packet Networking” product line “Routing and Switching.” This change was made on a prospective basis and does not impact comparability of previous financial results or the composition of this product line. References to our “Packet Networking” product line in prior periods have been changed to “Routing and Switching” in this report. See Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000010:mdna:17]
Quarter ended January 30, 2021 as compared to the quarter ended February 1, 2020

[0000936395-21-000010:mdna:18]
[same as prior period, unchanged from 0000936395-20-000036:mdna:70]

[0000936395-21-000010:mdna:19]
During the first quarter of fiscal 2021, approximately 17.9% of our revenue was non-U.S. Dollar-denominated, primarily including sales in Euros, Canadian Dollars, Japanese Yen, British Pounds, and Brazilian Reais. During the first quarter of fiscal 2021, as compared to the first quarter of fiscal 2020, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars slightly increased by approximately $2.6 million, or 0.4%, as compared to the first quarter of fiscal 2020. The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-21-000010:mdna:20]
|  | Quarter Ended |  |  |  |  |
|  | January 30, 2021 |  | %* |  | February 1, 2020 |  | %* |  | Increase (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | 67.7 |  |  | $ | 591,549 |  |  | 71.0 |  |  | $ | (79,225) |  |  | (13.4) |  |
| Routing and Switching | 64,307 |  |  | 8.5 |  |  | 67,508 |  |  | 8.1 |  |  | (3,201) |  |  | (4.7) |  |
| Total Networking Platforms | 576,631 |  |  | 76.2 |  |  | 659,057 |  |  | 79.1 |  |  | (82,426) |  |  | (12.5) |  |
| Platform Software and Services | 49,839 |  |  | 6.6 |  |  | 51,888 |  |  | 6.2 |  |  | (2,049) |  |  | (3.9) |  |
| Blue Planet Automation Software and Services | 16,934 |  |  | 2.2 |  |  | 15,466 |  |  | 1.9 |  |  | 1,468 |  |  | 9.5 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 67,630 |  |  | 8.9 |  |  | 61,793 |  |  | 7.4 |  |  | 5,837 |  |  | 9.4 |  |
| Installation and Deployment | 39,611 |  |  | 5.2 |  |  | 34,954 |  |  | 4.2 |  |  | 4,657 |  |  | 13.3 |  |
| Consulting and Network Design | 6,485 |  |  | 0.9 |  |  | 9,754 |  |  | 1.2 |  |  | (3,269) |  |  | (33.5) |  |
| Total Global Services | 113,726 |  |  | 15.0 |  |  | 106,501 |  |  | 12.8 |  |  | 7,225 |  |  | 6.8 |  |
| Consolidated revenue | $ | 757,130 |  |  | 100.0 |  |  | $ | 832,912 |  |  | 100.0 |  |  | $ | (75,782) |  |  | (9.1) |  |

[0000936395-21-000010:mdna:21]
[same as prior period, unchanged from 0000936395-20-000036:mdna:73]

[0000936395-21-000010:mdna:22]
*    Denotes % of total revenue

[0000936395-21-000010:mdna:23]
**    Denotes % change from 2020 to 2021

[0000936395-21-000010:mdna:24]
•Networking Platforms segment revenue decreased, reflecting product line sales decreases of $79.2 million of our Converged Packet Optical products and $3.2 million of our Routing and Switching products.

[0000936395-21-000010:mdna:25]
◦Converged Packet Optical sales decreased, primarily reflecting sales decreases of $98.4 million of our 6500 Packet-Optical Platform, primarily to communications service providers and cable and multiservice operators, and $41.9 million of our 5400 family of Packet-Optical Platforms primarily to communication service providers. These sales decreases were partially offset by a sales increase of $53.8 million of our Waveserver® products, primarily to communications service providers and Web-scale providers.

[0000936395-21-000010:mdna:26]
◦Routing and Switching sales decreased, primarily reflecting sales decreases of $5.8 million of our 8700 Packetwave Platform to enterprise and government customers and $4.0 million of our 3000 and 5000 families of service delivery and aggregation switches to communication service providers. These decreases were offset by a sales increase of $7.3 million of our platform independent software to a communication service provider.

[0000936395-21-000010:mdna:27]
•Platform Software and Services segment revenue decreased, reflecting a decrease of $8.8 million in software sales. offset by an increase of $6.8 million related to services.

[0000936395-21-000010:mdna:28]
•Blue Planet Automation Software and Services segment revenue increased, primarily reflecting an increase of $1.2 million in sales of software platforms. Our entrance into the software automation market is in the early stages and, as such, revenue from our Blue Planet Automation Software platform has not been significant to date and may fluctuate.

[0000936395-21-000010:mdna:29]
•Global Services segment revenue increased, reflecting sales increases of $5.8 million of our maintenance support and training services and $4.7 million of our installation and deployment services, offset by a sales decrease of $3.3 million of our consulting and network design services, in part due to impacts of COVID-19 as described above.

[0000936395-21-000010:mdna:30]
Our operating segments engage in business and operations across three geographic regions: Americas; EMEA; and APAC. The increase in our EMEA region for the quarter ended January 30, 2021 was primarily driven by increased sales in the Netherlands and France. The decrease in our APAC region for the quarter ended January 30, 2021 was primarily driven by decreased sales in Japan. The decrease in our Americas region for the quarter ended January 30, 2021 was primarily driven by decreased sales in the United States.The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic

[0000936395-21-000010:mdna:31]
distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-21-000010:mdna:32]
|  | Quarter Ended |  |  |  |  |
|  | January 30, 2021 |  | %* |  | February 1, 2020 |  | %* |  | Increase (decrease) |  | %** |
| Americas | $ | 496,611 |  |  | 65.6 |  |  | $ | 574,004 |  |  | 68.9 |  |  | $ | (77,393) |  |  | (13.5) |  |
| EMEA | 155,418 |  |  | 20.5 |  |  | 129,965 |  |  | 15.6 |  |  | 25,453 |  |  | 19.6 |  |
| APAC | 105,101 |  |  | 13.9 |  |  | 128,943 |  |  | 15.5 |  |  | (23,842) |  |  | (18.5) |  |
| Total | $ | 757,130 |  |  | 100.0 |  |  | $ | 832,912 |  |  | 100.0 |  |  | $ | (75,782) |  |  | (9.1) |  |

[0000936395-21-000010:mdna:33]
[same as prior period, unchanged from 0000936395-20-000036:mdna:85]

[0000936395-21-000010:mdna:34]
*    Denotes % of total revenue

[0000936395-21-000010:mdna:35]
**    Denotes % change from 2020 to 2021

[0000936395-21-000010:mdna:36]
•Americas revenue decreased, primarily reflecting sales decreases of $78.5 million within our Networking Platforms segment and $5.7 million within our Platform Software and Services segment, offset by sales increases of $5.1 million within our Global Services segment and $1.7 million within our Blue Planet Automation Software and Services segment. The decrease within our Networking Platforms segment primarily reflects a product line sales decrease of $73.6 million of our Converged Packet Optical products, primarily related to a sales decrease of $77.3 million of our 6500 Packet-Optical Platform to communication service providers.

[0000936395-21-000010:mdna:37]
•EMEA revenue increased, primarily reflecting sales increases of $19.0 million within our Networking Platforms segment, $3.5 million within our Global Services segment and $2.2 million within our Platform Software and Services segment. The revenue increase within our Networking Platforms segment reflects a product line sales increase of $17.7 million of Converged Packet Optical products, primarily related to a sales increase of $19.9 million of our Waveserver products to communication service providers and Web-scale providers.

[0000936395-21-000010:mdna:38]
•APAC revenue decreased, primarily reflecting a sales decrease of $22.9 million within our Networking Platforms segment. Our Networking Platforms segment revenue decrease primarily reflects a decrease of $27.6 million in sales of our 6500 Packet-Optical Platform to communications service providers in Japan, partially offset by an increase of 7.6 million in sales of our Waveserver products, primarily to communication service providers.

[0000936395-21-000010:mdna:39]
[same as prior period, unchanged from 0000936395-20-000036:mdna:91]

[0000936395-21-000010:mdna:40]
The component elements that comprise our product cost of goods and services costs of goods sold are set forth in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our 2020 Annual Report. There are a number of important factors or conditions that can adversely affect or cause our gross profit as a percentage of product or service revenue, or “gross margin,” to fluctuate on a quarterly basis. These are similarly described in detail in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” sections of our 2020 Annual Report.

[0000936395-21-000010:mdna:41]
[same as prior period, unchanged from 0000936395-20-000036:mdna:97]

[0000936395-21-000010:mdna:42]
|  | Quarter Ended |  |  |  |  |
|  | January 30, 2021 |  | %* |  | February 1, 2020 |  | %* |  | Increase (decrease) |  | %** |
| Total revenue | $ | 757,130 |  |  | 100.0 |  |  | $ | 832,912 |  |  | 100.0 |  |  | $ | (75,782) |  |  | (9.1) |  |
| Total cost of goods sold | 399,239 |  |  | 52.7 |  |  | 462,377 |  |  | 55.5 |  |  | (63,138) |  |  | (13.7) |  |
| Gross profit | $ | 357,891 |  |  | 47.3 |  |  | $ | 370,535 |  |  | 44.5 |  |  | $ | (12,644) |  |  | (3.4) |  |

[0000936395-21-000010:mdna:43]
[same as prior period, unchanged from 0000936395-20-000036:mdna:99]

[0000936395-21-000010:mdna:44]
*    Denotes % of total revenue

[0000936395-21-000010:mdna:45]
**    Denotes % change from 2020 to 2021

[0000936395-21-000010:mdna:46]
|  | Quarter Ended |  |  |  |  |
|  | January 30, 2021 |  | %* |  | February 1, 2020 |  | %* |  | Increase (decrease) |  | %** |
| Product revenue | $ | 597,220 |  |  | 100.0 |  |  | $ | 687,215 |  |  | 100.0 |  |  | $ | (89,995) |  |  | (13.1) |  |
| Product cost of goods sold | 315,098 |  |  | 52.8 |  |  | 389,013 |  |  | 56.6 |  |  | (73,915) |  |  | (19.0) |  |
| Product gross profit | $ | 282,122 |  |  | 47.2 |  |  | $ | 298,202 |  |  | 43.4 |  |  | $ | (16,080) |  |  | (5.4) |  |

[0000936395-21-000010:mdna:47]
[same as prior period, unchanged from 0000936395-20-000036:mdna:103]

[0000936395-21-000010:mdna:48]
*    Denotes % of product revenue

[0000936395-21-000010:mdna:49]
**    Denotes % change from 2020 to 2021

[0000936395-21-000010:mdna:50]
|  | Quarter Ended |  |  |  |  |
|  | January 30, 2021 |  | %* |  | February 1, 2020 |  | %* |  | Increase (decrease) |  | %** |
| Service revenue | $ | 159,910 |  |  | 100.0 |  |  | $ | 145,697 |  |  | 100.0 |  |  | $ | 14,213 |  |  | 9.8 |  |
| Service cost of goods sold | 84,141 |  |  | 52.6 |  |  | 73,364 |  |  | 50.4 |  |  | 10,777 |  |  | 14.7 |  |
| Service gross profit | $ | 75,769 |  |  | 47.4 |  |  | $ | 72,333 |  |  | 49.6 |  |  | $ | 3,436 |  |  | 4.8 |  |

[0000936395-21-000010:mdna:51]
[same as prior period, unchanged from 0000936395-20-000036:mdna:107]

[0000936395-21-000010:mdna:52]
*    Denotes % of services revenue

[0000936395-21-000010:mdna:53]
**    Denotes % change from 2020 to 2021

[0000936395-21-000010:mdna:54]
•Gross profit as a percentage of revenue increased, as our gross margin benefited significantly from a favorable mix of customers and products that we believe to be a short-term effect due to COVID-19 related factors. Due to the impact of COVID-19 and related restrictions on sales and marketing activities described in “Overview” above, during the first quarter of fiscal 2021, a higher proportion of our revenue consisted of sales of existing technology offerings deployed in the networks of existing customers, as compared to sales to new customers, early stage network deployments for recent design wins, or the introduction of new platforms, which tend to carry lower margins. We expect our gross margins to reduce from these elevated short-term levels as the adverse impact of the pandemic on new business lessens and our overall revenue resumes a more typical composition of revenue from existing and new business.

[0000936395-21-000010:mdna:55]
•Gross profit on products as a percentage of product revenue increased, primarily due to a favorable mix of customers and products, as described above, and continued product cost reductions, partially offset by market-based price compression we encountered during the period.

[0000936395-21-000010:mdna:56]
•Gross profit on services as a percentage of services revenue decreased, primarily due to lower installation and deployment margins and a lower mix of higher margin consulting and network design services. The lower margins on installation and deployment services were primarily due to certain customer site readiness delays that caused cost inefficiencies. These lower margins were partially offset by increased higher margin maintenance revenues.

[0000936395-21-000010:mdna:57]
[same as prior period, unchanged from 0000936395-20-000036:mdna:114]

[0000936395-21-000010:mdna:58]
The component elements that comprise each of our operating expense categories in the table below are set forth in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our 2020 Annual Report.

[0000936395-21-000010:mdna:59]
During the first quarter of fiscal 2021, approximately 51.9% of our operating expense was non-U.S. Dollar-denominated, including expenses in Canadian Dollars, Indian Rupees and British Pounds. During the first quarter of fiscal 2021 as compared to the first quarter of fiscal 2020, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense reported in U.S. Dollars slightly increased by approximately $1.4 million, or 0.5%, as compared to the first quarter of fiscal 2020, due to fluctuations in foreign currency. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-21-000010:mdna:60]
|  | Quarter Ended |  |  |  |  |
|  | January 30, 2021 |  | %* |  | February 1, 2020 |  | %* |  | Increase (decrease) |  | %** |
| Research and development | $ | 132,741 |  |  | 17.5 |  |  | $ | 130,900 |  |  | 15.7 |  |  | $ | 1,841 |  |  | 1.4 |  |
| Selling and marketing | 97,278 |  |  | 12.8 |  |  | 107,066 |  |  | 12.9 |  |  | (9,788) |  |  | (9.1) |  |
| General and administrative | 39,993 |  |  | 5.3 |  |  | 42,468 |  |  | 5.1 |  |  | (2,475) |  |  | (5.8) |  |
| Amortization of intangible assets | 5,910 |  |  | 0.8 |  |  | 5,853 |  |  | 0.7 |  |  | 57 |  |  | 1.0 |  |
| Significant asset impairments and restructuring costs | 5,867 |  |  | 0.8 |  |  | 4,472 |  |  | 0.5 |  |  | 1,395 |  |  | 31.2 |  |
| Acquisition and integration costs | 307 |  |  | — |  |  | 1,819 |  |  | 0.2 |  |  | (1,512) |  |  | (83.1) |  |
| Total operating expenses | $ | 282,096 |  |  | 37.3 |  |  | $ | 292,578 |  |  | 35.1 |  |  | $ | (10,482) |  |  | (3.6) |  |

[0000936395-21-000010:mdna:61]
[same as prior period, unchanged from 0000936395-20-000036:mdna:124]

[0000936395-21-000010:mdna:62]
*    Denotes % of total revenue

[0000936395-21-000010:mdna:63]
**    Denotes % change from 2020 to 2021

[0000936395-21-000010:mdna:64]
•Research and development expense increased by $1.8 million. This increase primarily reflects increases in employee and compensation costs and technology-related costs, partially offset by decreases in professional services costs.

[0000936395-21-000010:mdna:65]
•Selling and marketing expense was adversely affected by $1.4 million as a result of foreign exchange rates, primarily due to fluctuations of the U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expenses decreased by $9.8 million. This decrease primarily reflects decreases in travel and entertainment costs due to restrictions on travel as a result of COVID-19, and professional services, partially offset by an increase in employee and compensation costs.

[0000936395-21-000010:mdna:66]
•General and administrative expense decreased by $2.5 million primarily as a result of the recovery of bad debt, partially offset by an increase in employee and compensation costs.

[0000936395-21-000010:mdna:67]
•Amortization of intangible assets remained relatively unchanged.

[0000936395-21-000010:mdna:68]
•Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin and constrain operating expense, and redesign of certain business processes.

[0000936395-21-000010:mdna:69]
•Acquisition and integration costs primarily reflect reduced acquisition compensation associated with a three-year earn-out arrangement related to the acquisition of DonRiver Holdings, LLC in fiscal 2018 and other fees related to the acquisition of Centina Systems, Inc. in the first quarter of fiscal 2020.

[0000936395-21-000010:mdna:70]
[same as prior period, unchanged from 0000936395-20-000036:mdna:133]

[0000936395-21-000010:mdna:71]
[same as prior period, unchanged from 0000936395-20-000036:mdna:134]

[0000936395-21-000010:mdna:72]
|  | Quarter Ended |  |  |  |  |
|  | January 30, 2021 |  | %* |  | February 1, 2020 |  | %* |  | Increase (decrease) |  | %** |
| Interest and other income (loss), net | $ | (1,121) |  |  | (0.1) |  |  | $ | 3,646 |  |  | 0.4 |  |  | $ | (4,767) |  |  | (130.7) |  |
| Interest expense | $ | 7,360 |  |  | 1.0 |  |  | $ | 8,815 |  |  | 1.1 |  |  | $ | (1,455) |  |  | (16.5) |  |
| Loss on extinguishment and modification of debt | $ | — |  |  | 0.0 |  |  | $ | 646 |  |  | 0.0 |  |  | $ | (646) |  |  | — |  |
| Provision for income taxes | $ | 11,966 |  |  | 1.6 |  |  | $ | 9,814 |  |  | 1.2 |  |  | $ | 2,152 |  |  | 21.9 |  |

[0000936395-21-000010:mdna:73]
[same as prior period, unchanged from 0000936395-20-000036:mdna:136]

[0000936395-21-000010:mdna:74]
*    Denotes % of total revenue

[0000936395-21-000010:mdna:75]
**    Denotes % change from 2020 to 2021

[0000936395-21-000010:mdna:76]
•Interest and other income (loss), net decreased, primarily reflecting lower interest income due to reduced interest rates on our investments and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-21-000010:mdna:77]
[same as prior period, unchanged from 0000936395-20-000036:mdna:200]

[0000936395-21-000010:mdna:78]
•Loss on extinguishment and modification of debt reflects the refinance of our 2025 Term Loan in the first quarter of fiscal 2020.

[0000936395-21-000010:mdna:79]
•Provision for income taxes increased, primarily due to the BEAT reduction in fiscal 2020 and the effect of the final regulations released on December 2, 2019. Consequently, the effective tax rate for the first quarter of fiscal 2021 increased as compared to the first quarter of fiscal 2020.

[0000936395-21-000010:mdna:80]
[same as prior period, unchanged from 0000936395-20-000036:mdna:203]

[0000936395-21-000010:mdna:81]
[same as prior period, unchanged from 0000936395-20-000036:mdna:204]

[0000936395-21-000010:mdna:82]
|  | Quarter Ended |  |  |  |  |
|  | January 30, 2021 |  | February 1, 2020 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 156,431 |  |  | $ | 168,270 |  |  | $ | (11,839) |  |  | (7.0) |  |
| Platform Software and Services | $ | 27,660 |  |  | $ | 28,951 |  |  | $ | (1,291) |  |  | (4.5) |  |
| Blue Planet Automation Software and Services | $ | (2,434) |  |  | $ | (3,113) |  |  | $ | 679 |  |  | (21.8) |  |
| Global Services | $ | 43,493 |  |  | $ | 45,527 |  |  | $ | (2,034) |  |  | (4.5) |  |

[0000936395-21-000010:mdna:83]
[same as prior period, unchanged from 0000936395-20-000036:mdna:158]

[0000936395-21-000010:mdna:84]
*    Denotes % change from 2020 to 2021

[0000936395-21-000010:mdna:85]
•Networking Platforms segment profit decreased, primarily due to lower sales volume as described above and higher research and development costs, offset by improved gross margin.

[0000936395-21-000010:mdna:86]
•Platform Software and Services segment profit decreased, primarily due to lower sales volume as described above, offset by lower research and development costs.

[0000936395-21-000010:mdna:87]
•Blue Planet Automation Software and Services segment loss decreased, primarily due to higher sales volume and lower research and development costs.

[0000936395-21-000010:mdna:88]
•Global Services segment profit decreased, primarily due to reduced gross margin, as described above.

[0000936395-21-000010:mdna:89]
[same as prior period, unchanged from 0000936395-20-000036:mdna:219]

[0000936395-21-000010:mdna:90]
Overview. For the three months ended January 30, 2021, we used $7.3 million of cash in operating activities, as our working capital requirements of $127.0 million exceeded our net income (adjusted for non-cash charges) of $119.7 million. For additional details, see “Cash Used In Operating Activities” below.

[0000936395-21-000010:mdna:91]
Cash, cash equivalents and investments decreased by $38.5 million during the first three months of fiscal 2021. In addition to the cash used in operations, the decrease in cash also included the following items: (i) cash used to fund our investing activities for capital expenditures totaling $20.9 million; (ii) cash used for stock repurchases under our stock repurchase program of $12.4 million; and (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $19.2 million. Partially offsetting these decreases in cash were proceeds from the issuance of equity under our employee stock purchase plan, which provided $13.4 million in cash during the three months ended January 30, 2021.

[0000936395-21-000010:mdna:92]
|  | January 30,2021 |  | October 31,2020 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,029,237 |  |  | $ | 1,088,624 |  |  | $ | (59,387) |  |
| Short-term investments in marketable debt securities | 151,434 |  |  | 150,667 |  |  | 767 |  |
| Long-term investments in marketable debt securities | 102,364 |  |  | 82,226 |  |  | 20,138 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,283,035 |  |  | $ | 1,321,517 |  |  | $ | (38,482) |  |

[0000936395-21-000010:mdna:93]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of January 30, 2021 totaled $1.3 billion, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash

[0000936395-21-000010:mdna:94]
required to collateralize these instruments. As of January 30, 2021, letters of credit totaling $81.7 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 30, 2021.

[0000936395-21-000010:mdna:95]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $94.8 million as of January 30, 2021. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical foreign earnings, the estimated amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $25.0 million.

[0000936395-21-000010:mdna:96]
Stock Repurchase Authorization. On December 13, 2018, we announced that the Board of Directors authorized a program to repurchase up to $500.0 million of its common stock. After temporarily suspending repurchases of our common stock during fiscal 2020, we reinstituted our stock repurchase program in the first quarter of 2021 and are currently targeting repurchases in the range of $150 million of our common stock during fiscal 2021. We repurchased $13.2 million under this program during the first three months of fiscal 2021, and had $262.2 million remaining under the current authorization as of January 30, 2021. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be reinstated, modified, suspended, or discontinued at any time.

[0000936395-21-000010:mdna:97]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to disruptions and volatility in capital markets and credit markets. The duration and severity of any further economic or market impact of the COVID-19 pandemic remains uncertain and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future.

[0000936395-21-000010:mdna:98]
Cash Used In Operating Activities

[0000936395-21-000010:mdna:99]
The following sections set forth the components of our $7.3 million of cash used in operating activities during the first three months of fiscal 2021:

[0000936395-21-000010:mdna:100]
[same as prior period, unchanged from 0000936395-20-000036:mdna:229]

[0000936395-21-000010:mdna:101]
[same as prior period, unchanged from 0000936395-20-000036:mdna:230]

[0000936395-21-000010:mdna:102]
|  | Three Months Ended |
|  | January 30, 2021 |
| Net income | $ | 55,348 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 23,188 |  |
| Share-based compensation costs | 18,964 |  |
| Amortization of intangible assets | 9,642 |  |
| Deferred taxes | (905) |  |
| Provision for inventory excess and obsolescence | 5,905 |  |
| Provision for warranty | 3,239 |  |
| Other | 4,277 |  |
| Net income (adjusted for non-cash charges) | $ | 119,658 |  |

[0000936395-21-000010:mdna:103]
[same as prior period, unchanged from 0000936395-20-000036:mdna:232]

[0000936395-21-000010:mdna:104]
We used $127.0 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-21-000010:mdna:105]
|  | Three Months Ended |
|  | January 30, 2021 |
| Cash provided by accounts receivable | $ | 18,862 |  |
| Cash used in inventories | (51,020) |  |
| Cash used in prepaid expenses and other | (13,835) |  |
| Cash used in accounts payable, accruals and other obligations | (112,170) |  |
| Cash provided by deferred revenue | 31,917 |  |
| Cash used in operating lease assets and liabilities, net | (731) |  |
| Total cash used for working capital | $ | (126,977) |  |

[0000936395-21-000010:mdna:106]
As compared to the end of fiscal 2020:

[0000936395-21-000010:mdna:107]
•The $18.9 million of cash provided by accounts receivable during the first three months of fiscal 2021 reflects increased cash collections;

[0000936395-21-000010:mdna:108]
•The $51.0 million of cash used in inventories during the first three months of fiscal 2021 primarily reflects increases in finished goods to meet customer delivery schedules and related to some of the actions that we have taken since early fiscal 2020 to mitigate the risk of adverse supply chain impact on our business and operations due to COVID-19 related disruptions;

[0000936395-21-000010:mdna:109]
•The $13.8 million of cash used in prepaid expense and other during the first three months of fiscal 2021 primarily reflects increases in foreign currency forward contracts and higher non-customer receivables;

[0000936395-21-000010:mdna:110]
•The $112.2 million of cash used in accounts payable, accruals and other obligations during the first three months of fiscal 2021 primarily reflects the payment to employees under our annual cash incentive compensation plan in the first quarter, as well as inventory purchases;

[0000936395-21-000010:mdna:111]
•The $31.9 million of cash provided by deferred revenue during the first three months of fiscal 2021 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-21-000010:mdna:112]
•The $0.7 million of cash used in operating lease assets and liabilities, net, during the first three months of fiscal 2021 represents cash paid for operating leases. For more details, see Note 14 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000010:mdna:113]
Our days sales outstanding (“DSOs”) for the first three months of fiscal 2021 were 93 days, and our inventory turns for the first three months of fiscal 2021 were 3.2. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other.

[0000936395-21-000010:mdna:114]
[same as prior period, unchanged from 0000936395-20-000036:mdna:243]

[0000936395-21-000010:mdna:115]
[same as prior period, unchanged from 0000936395-20-000036:mdna:244]

[0000936395-21-000010:mdna:116]
|  | Three Months Ended |
|  | January 30, 2021 |
| Term Loan due September 28, 2025(1) | 3,341 |  |
| Interest rate swaps(2) | 2,511 |  |
| ABL Credit Facility(3) | 494 |  |
| Finance leases | 1,220 |  |
| Cash paid during period | $ | 7,566 |  |

[0000936395-21-000010:mdna:117]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of the first quarter of fiscal 2021, the interest rate on the 2025 Term Loan was 1.88%.

[0000936395-21-000010:mdna:118]
(2) The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan at 2.957% through September 2023.

[0000936395-21-000010:mdna:119]
(3) During the first three months of fiscal 2021, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.5 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-21-000010:mdna:120]
[same as prior period, unchanged from 0000936395-20-000036:mdna:250]

[0000936395-21-000010:mdna:121]
There have been no material changes to our contractual obligations since October 31, 2020. For a summary of our contractual obligations, see Item 7 of Part II of our 2020 Annual Report.

[0000936395-21-000010:mdna:122]
[same as prior period, unchanged from 0000936395-20-000036:mdna:252]

[0000936395-21-000010:mdna:123]
[same as prior period, unchanged from 0000936395-20-000036:mdna:253]

[0000936395-21-000010:mdna:124]
[same as prior period, unchanged from 0000936395-20-000036:mdna:254]

[0000936395-21-000010:mdna:125]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition,  because the duration, severity, and impact of the COVID-19 pandemic remain uncertain, certain of our estimates could require further judgment or modification, and therefore carry a higher degree of variability and volatility. As events continue to evolve, our estimates may change materially in future periods.

[0000936395-21-000010:mdna:126]
Except for items listed below, our critical accounting policies and estimates have not changed materially since October 31, 2020. For a discussion of our critical accounting policies and estimates, see “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Item 7 of Part II of our 2020 Annual Report.

[0000936395-21-000010:mdna:127]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0000936395-21-000010:mdna:128]
See Note 2 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for information regarding the change in our allowance for credit losses for accounts receivable and contract assets accounting policies as a result of our adoption of ASU 2016-13, Financial Instruments - Credit Losses.

[0000936395-21-000010:mdna:129]
[same as prior period, unchanged from 0000936395-20-000036:mdna:259]

[0000936395-21-000010:mdna:130]
[same as prior period, unchanged from 0000936395-20-000036:mdna:260]
