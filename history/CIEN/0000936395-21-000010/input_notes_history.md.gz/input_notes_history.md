# CIEN note change history — 0000936395-20-000036 → 0000936395-21-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-03-10):
[0000936395-21-000010:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.1 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 30, 2021, Ciena has recorded CAD$44.2 million (approximately $34.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$3.6 million ($2.8 million) was recorded in the first three months of fiscal 2021. As of January 30, 2021, amounts receivable from this grant were CAD$3.2 million ($2.5 million).
  (was, 2020-09-09, similarity 0.9658):
[0000936395-20-000036:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $42.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of August 1, 2020, Ciena has recorded CAD$37.0 million (approximately $27.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$8.1 million ($6.0 million) was recorded in the first nine months of fiscal 2020. As of August 1, 2020, amounts receivable from this grant were CAD$7.0 million ($5.2 million).


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-03-10):
[0000936395-21-000010:note_history:2]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions, and estimates reflect, among other things, the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected. In addition, including because the duration and severity of COVID-19 pandemic are uncertain, certain of such estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve, Ciena’s estimates may change materially in future periods.
  (was, 2020-09-09, similarity 0.6791):
[0000936395-20-000036:note_history:2]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions and estimates reflected the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. The actual results that Ciena experiences may differ materially from such inputs into Ciena’s critical and significant accounting estimates. As the duration and severity of the COVID-19 pandemic are unclear, certain of such estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility as compared to prior periods. As events continue to evolve, Ciena’s estimates may change materially in future periods.

- changed (2021-03-10):
[0000936395-21-000010:note_history:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2020 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2020 (the “2020 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2021 and 2020 are 52-week fiscal years.
  (was, 2020-09-09, similarity 0.7765):
[0000936395-20-000036:note_history:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2019 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2019 (the “2019 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2020 and 2019 are 52-week fiscal years. Effective the second quarter of fiscal 2020, Ciena changed the presentation of reporting for its financial statements and notes thereto to reflect the actual dates on which fiscal years and quarterly periods ended. Because these dates can change from period to period, for consistency purposes, Ciena previously presented such information indicating that its quarters ended on January 31, April 30, July 31 and October 31. This change, affecting only the presentation of such information, was made on a prospective basis and it does not impact comparability of previous financial results. References to prior reported periods have been changed to reflect the actual period end dates of August 1, 2020, August 3, 2019, November 2, 2019 and November 3, 2018 for periods reported herein.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-03-10):
[0000936395-21-000010:note_history:4]
In June 2016, the Financial Accounting Standards Board (”FASB”) issued Accounting Standards Update No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. Ciena adopted ASU 2016-13 on a modified retrospective basis in the first quarter of fiscal year 2021 through a cumulative-effect adjustment at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts the value of Ciena’s accounts receivable, net and contract assets, net. Adoption of ASU 2016-13 did not have a material effect on Ciena’s financial position or results of operations.

- added (2021-03-10):
[0000936395-21-000010:note_history:5]
Ciena’s significant accounting policies updated as a result of adopting this standard are as follows:

- added (2021-03-10):
[0000936395-21-000010:note_history:6]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

- added (2021-03-10):
[0000936395-21-000010:note_history:7]
Ciena estimates its allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, Ciena determines collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default, the

- added (2021-03-10):
[0000936395-21-000010:note_history:8]
probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

- added (2021-03-10):
[0000936395-21-000010:note_history:9]
Probability of default rates are published by third-party credit rating agencies. Adjustments to Ciena’s exposure probability may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

- added (2021-03-10):
[0000936395-21-000010:note_history:10]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which enhances and simplifies various aspects related to accounting for income taxes by removing certain exceptions to the general principles in ASC 740.  The amendments also improve consistent application of and simplify U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022, and early adoption is permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.

- removed (2021-03-10):
[0000936395-20-000036:note_history:11]
Leases

- removed (2021-03-10):
[0000936395-20-000036:note_history:12]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Codification (“ASC”) 842, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Effective November 3, 2019, Ciena adopted ASC 842 which requires right-of-use ("ROU") assets and lease liabilities to be recorded on the balance sheet for leases. The guidance specifies that at the inception of a contract, an entity must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts followed the assessment of whether there was a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating right-of-use assets (“Operating ROU assets”), Operating lease liabilities and Long-term operating lease liabilities in the Condensed Consolidated Balance Sheets. Finance leases are included in Equipment,

- removed (2021-03-10):
[0000936395-20-000036:note_history:13]
building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations are included in the Condensed Consolidated Balance Sheets.

- removed (2021-03-10):
[0000936395-20-000036:note_history:14]
Ciena adopted the guidance on a modified retrospective basis as of November 3, 2019, such that related amounts in prior periods have not been restated. Ciena has operating and finance leases that primarily relate to real property. As a practical expedient for disclosure, Ciena has elected the “package of practical expedients” and, as a result, did not reassess existing lease identifications, lease classifications or initial direct costs. As a practical expedient, Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Also as a practical expedient, Ciena has elected not to separate lease and non-lease components of operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass-through operating expenses like common area maintenance and utilities.

- removed (2021-03-10):
[0000936395-20-000036:note_history:15]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Condensed Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Condensed Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight-line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Condensed Consolidated Statements of Operations.

- removed (2021-03-10):
[0000936395-20-000036:note_history:16]
Upon adoption, Ciena recorded Operating ROU assets of $53.3 million and lease liabilities of $76.0 million related to its operating leases. As of November 2, 2019, the restructuring reserve liability for vacated office space of $11.1 million was included in Accrued liabilities and other short-term obligations and Other long-term obligations on the Condensed Consolidated Balance Sheet under prior accounting guidance. Upon adoption of the updated guidance, the existing lease reserve liability was reclassified as a reduction to the Operating ROU assets. ROU assets will be tested for impairment when circumstances indicate that the carrying values may not be recoverable. The adoption of this guidance did not require a cumulative effect adjustment or have an impact on the Condensed Consolidated Statements of Income or Condensed Consolidated Statements of Cash Flows.

- removed (2021-03-10):
[0000936395-20-000036:note_history:17]
Opening Balance Adjustments

- removed (2021-03-10):
[0000936395-20-000036:note_history:18]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheet in connection with the adoption of ASC 842 (in thousands):

- removed (2021-03-10):
[0000936395-20-000036:note_history:19]
|  |  | Balance at November 2, 2019 |  | New Lease Accounting Standard |  |  | Adjusted Balance at November 3, 2019 |
| ASSETS: |  |  |  |  |  |  |  |
| Operating right-of-use assets |  | $ | — |  |  | $ | 53,334 |  | (1) |  | $ | 53,334 |  |
| Total assets |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations |  | $ | 382,740 |  |  | $ | (1,484) |  | (2) |  | $ | 381,256 |  |
| Short-term lease liabilities |  | $ | — |  |  | 20,498 |  | (3) |  | $ | 20,498 |  |
| Other long-term obligations |  | $ | 148,747 |  |  | (21,244) |  | (4) |  | $ | 127,503 |  |
| Long-term operating lease liabilities |  | $ | — |  |  | 55,564 |  | (5) |  | $ | 55,564 |  |
| Total liabilities and stockholders’ equity |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |

- removed (2021-03-10):
[0000936395-20-000036:note_history:20]
(1) Represents $76.0 million of operating leases recognized as Operating ROU assets upon adoption of ASC 842, less $5.4 million of deferred rent, $6.2 million of tenant improvement allowances, $1.5 million of short-term restructuring reserve liability and $9.6 million of long-term restructuring reserve liability all recognized as a reduction to ROU assets.

- removed (2021-03-10):
[0000936395-20-000036:note_history:21]
(2) Represents $1.5 million of short-term restructuring reserve liability recognized as a reduction to Operating ROU assets.

- removed (2021-03-10):
[0000936395-20-000036:note_history:22]
(3) Represents $20.5 million of lease liabilities for operating leases.

- removed (2021-03-10):
[0000936395-20-000036:note_history:23]
(4) Represents $9.6 million of long-term restructuring reserve liability, $5.4 million of deferred rent, and $6.2 million of tenant improvement allowances recognized as a reduction to ROU assets.

- removed (2021-03-10):
[0000936395-20-000036:note_history:24]
(5) Represents $55.6 million of lease liabilities for operating leases.

- removed (2021-03-10):
[0000936395-20-000036:note_history:25]
See Note 15 for additional information.

- removed (2021-03-10):
[0000936395-20-000036:note_history:26]
Fair Value Measurement

- removed (2021-03-10):
[0000936395-20-000036:note_history:27]
In August 2018, the FASB issued Accounting Standards Update (“ASU”) No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. Ciena adopted ASU 2018-13 beginning the first quarter of fiscal year 2020. Adoption of ASU 2018-13 did not have a material effect on Ciena’s financial position or results of operations.

- removed (2021-03-10):
[0000936395-20-000036:note_history:28]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021, and early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its Consolidated Financial Statements and related disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-03-10):
[0000936395-21-000010:note_history:29]
SHORT-TERM AND LONG-TERM DEBT 
2025 Term Loan
  (was, 2020-09-09, similarity 0.9535):
[0000936395-20-000036:note_history:29]
SHORT-TERM AND LONG-TERM DEBT 
New 2025 Term Loan

- changed (2021-03-10):
[0000936395-21-000010:note_history:30]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).
  (was, 2020-09-09, similarity 0.7077):
[0000936395-20-000036:note_history:30]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan with an outstanding aggregate principal amount of $693.0 million as of January 23, 2020 and maturing on September 28, 2025 (the “Old 2025 Term Loan”) and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “New 2025 Term Loan”).

- changed (2021-03-10):
[0000936395-21-000010:note_history:31]
The net carrying value of Ciena’s term loan was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2020-09-09, similarity 0.9719):
[0000936395-20-000036:note_history:31]
The net carrying values of Ciena’s term loans were comprised of the following for the fiscal periods indicated (in thousands):

- added (2021-03-10):
[0000936395-21-000010:note_history:32]
|  |  | January 30, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 686,070 |  |  | $ | (1,495) |  |  | $ | (2,789) |  |  | $ | 681,786 |  |  | $ | 683,286 |  |

- changed (2021-03-10):
[0000936395-21-000010:note_history:33]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loan totaled $2.8 million at January 30, 2021 and $2.9 million at October 31, 2020. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.2 million during the first three months of each of fiscal 2021 and fiscal 2020. The carrying value of the term loan listed above is also net of any unamortized debt discounts.
  (was, 2020-09-09, similarity 0.9525):
[0000936395-20-000036:note_history:33]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.1 million at August 1, 2020 and $3.6 million at November 2, 2019. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans is included in interest expense, and was $0.5 million during the first nine months of each of fiscal 2020 and fiscal 2019. The carrying value of the term loans listed above is also net of any unamortized debt discounts.

- changed (2021-03-10):
[0000936395-21-000010:note_history:34]
As of January 30, 2021, the estimated fair value of the 2025 Term Loan was $686.1 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2020-09-09, similarity 0.9735):
[0000936395-20-000036:note_history:34]
As of August 1, 2020, the estimated fair value of the New 2025 Term Loan was $685.2 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2021-03-10):
[0000936395-20-000036:note_history:35]
|  |  | August 1, 2020 |  |  |  |  |  |  |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 689,535 |  |  | $ | (1,659) |  |  | $ | (3,090) |  |  | $ | 684,786 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-03-10):
[0000936395-21-000010:note_history:36]
|  | January 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,420 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 151,434 |  |
| Included in long-term investments | 102,360 |  |  | 4 |  |  | — |  |  | 102,364 |  |
|  | $ | 253,780 |  |  | $ | 18 |  |  | $ | — |  |  | $ | 253,798 |  |
  (was, 2020-09-09, similarity 0.7791):
[0000936395-20-000036:note_history:36]
|  | November 2, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3) |  |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3) |  |  | $ | 119,954 |  |

- added (2021-03-10):
[0000936395-21-000010:note_history:37]
|  | October 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 150,559 |  |  | $ | 109 |  |  | $ | (1) |  |  | $ | 150,667 |  |
| Included in long-term investments | 82,252 |  |  | — |  |  | (26) |  |  | 82,226 |  |
|  | $ | 232,811 |  |  | $ | 109 |  |  | $ | (27) |  |  | $ | 232,893 |  |

- removed (2021-03-10):
[0000936395-20-000036:note_history:38]
|  | August 1, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 70,093 |  |  | $ | 311 |  |  | $ | — |  |  | $ | 70,404 |  |
|  | $ | 70,093 |  |  | $ | 311 |  |  | $ | — |  |  | $ | 70,404 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-03-10):
[0000936395-21-000010:note_history:39]
|  | January 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,420 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 151,434 |  |
| Included in long-term investments | 102,360 |  |  | 4 |  |  | — |  |  | 102,364 |  |
|  | $ | 253,780 |  |  | $ | 18 |  |  | $ | — |  |  | $ | 253,798 |  |
  (was, 2020-09-09, similarity 0.7791):
[0000936395-20-000036:note_history:39]
|  | November 2, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3) |  |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3) |  |  | $ | 119,954 |  |

- added (2021-03-10):
[0000936395-21-000010:note_history:40]
|  | October 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 150,559 |  |  | $ | 109 |  |  | $ | (1) |  |  | $ | 150,667 |  |
| Included in long-term investments | 82,252 |  |  | — |  |  | (26) |  |  | 82,226 |  |
|  | $ | 232,811 |  |  | $ | 109 |  |  | $ | (27) |  |  | $ | 232,893 |  |

- changed (2021-03-10):
[0000936395-21-000010:note_history:41]
The following table summarizes the final legal maturities of debt investments at January 30, 2021 (in thousands):
  (was, 2020-09-09, similarity 0.9581):
[0000936395-20-000036:note_history:41]
The following table summarizes the final legal maturities of debt investments at August 1, 2020 (in thousands):

- changed (2021-03-10):
[0000936395-21-000010:note_history:42]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 151,420 |  |  | $ | 151,434 |  |
| Due in 1-2 years | 102,360 |  |  | 102,364 |  |
|  | $ | 253,780 |  |  | $ | 253,798 |  |
  (was, 2020-09-09, similarity 0.7426):
[0000936395-20-000036:note_history:42]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 70,093 |  |  | $ | 70,404 |  |

- removed (2021-03-10):
[0000936395-20-000036:note_history:43]
|  | August 1, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 70,093 |  |  | $ | 311 |  |  | $ | — |  |  | $ | 70,404 |  |
|  | $ | 70,093 |  |  | $ | 311 |  |  | $ | — |  |  | $ | 70,404 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-03-10):
[0000936395-21-000010:note_history:44]
The net carrying value of Ciena’s term loan was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2020-09-09, similarity 0.9719):
[0000936395-20-000036:note_history:44]
The net carrying values of Ciena’s term loans were comprised of the following for the fiscal periods indicated (in thousands):

- added (2021-03-10):
[0000936395-21-000010:note_history:45]
|  |  | January 30, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 686,070 |  |  | $ | (1,495) |  |  | $ | (2,789) |  |  | $ | 681,786 |  |  | $ | 683,286 |  |

- removed (2021-03-10):
[0000936395-20-000036:note_history:46]
|  |  | August 1, 2020 |  |  |  |  |  |  |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 689,535 |  |  | $ | (1,659) |  |  | $ | (3,090) |  |  | $ | 684,786 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-03-10):
[0000936395-21-000010:note_history:47]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
  (was, 2020-09-09, similarity 0.9714):
[0000936395-20-000036:note_history:47]
|  | Quarter Ended August 1, 2020 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 722,512 |  |
| Packet Networking | 79,756 |  |  | — |  |  | — |  |  | — |  |  | 79,756 |  |
| Platform Software and Services | — |  |  | 46,422 |  |  | — |  |  | — |  |  | 46,422 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 11,297 |  |  | — |  |  | 11,297 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 69,099 |  |  | 69,099 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,798 |  |  | 39,798 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,828 |  |  | 7,828 |  |
| Total revenue by product line | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 802,268 |  |  | $ | 15,838 |  |  | $ | 410 |  |  | $ | 3,300 |  |  | $ | 821,816 |  |
| Services transferred over time | — |  |  | 30,584 |  |  | 10,887 |  |  | 113,425 |  |  | 154,896 |  |
| Total revenue by timing of revenue recognition | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |

- changed (2021-03-10):
[0000936395-21-000010:note_history:48]
|  | Quarter Ended February 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Routing and Switching | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
  (was, 2020-09-09, similarity 0.7468):
[0000936395-20-000036:note_history:48]
|  | Quarter Ended August 3, 2019 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 724,245 |  |
| Packet Networking | 71,823 |  |  | — |  |  | — |  |  | — |  |  | 71,823 |  |
| Platform Software and Services | — |  |  | 37,312 |  |  | — |  |  | — |  |  | 37,312 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 10,530 |  |  | — |  |  | 10,530 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 65,936 |  |  | 65,936 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,802 |  |  | 39,802 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,958 |  |  | 10,958 |  |
| Total revenue by product line | $ | 796,068 |  |  | $ | 37,312 |  |  | $ | 10,530 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 796,068 |  |  | $ | 12,657 |  |  | $ | 1,941 |  |  | $ | 4,804 |  |  | $ | 815,470 |  |
| Services transferred over time | — |  |  | 24,655 |  |  | 8,589 |  |  | 111,892 |  |  | 145,136 |  |
| Total revenue by timing of revenue recognition | $ | 796,068 |  |  | $ | 37,312 |  |  | $ | 10,530 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |

- changed (2021-03-10):
[0000936395-21-000010:note_history:49]
|  |  | Quarter Ended |  |  |
|  |  | January 30, |  | February 1, |  |  |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 496,611 |  |  | $ | 574,004 |  |  |  |  |  |
| EMEA |  | 155,418 |  |  | 129,965 |  |  |  |  |  |
| APAC |  | 105,101 |  |  | 128,943 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 757,130 |  |  | $ | 832,912 |  |  |  |  |  |
  (was, 2020-09-09, similarity 0.6939):
[0000936395-20-000036:note_history:49]
|  |  | Quarter Ended |  |  |  | Nine Months Ended |  |  |
|  |  | August 1, |  | August 3, |  | August 1, |  | August 3, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 713,340 |  |  | $ | 656,261 |  |  | $ | 1,937,725 |  |  | 1,788,234 |  |
| EMEA |  | 162,465 |  |  | 169,532 |  |  | 433,861 |  |  | 413,715 |  |
| APAC |  | 100,907 |  |  | 134,813 |  |  | 332,091 |  |  | 402,195 |  |
| Total revenue by geographic distribution |  | $ | 976,712 |  |  | $ | 960,606 |  |  | $ | 2,703,677 |  |  | $ | 2,604,144 |  |

- added (2021-03-10):
[0000936395-21-000010:note_history:50]
For the first quarter of fiscal 2021, there were no customers that accounted for at least 10% of Ciena’s revenue. The table below shows the customers that accounted for at least 10% of Ciena’s revenue for the first quarter of fiscal 2020: (in thousands):

- added (2021-03-10):
[0000936395-21-000010:note_history:51]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| AT&T | n/a |  | $ | 84,010 |  |  |  |  |  |
| Verizon | n/a |  | 114,548 |  |  |  |  |  |
| Total | n/a |  | $ | 198,558 |  |  |  |  |  |

- added (2021-03-10):
[0000936395-21-000010:note_history:52]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

- removed (2021-03-10):
[0000936395-20-000036:note_history:53]
|  | Nine Months Ended August 1, 2020 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | 1,968,355 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,968,355 |  |
| Packet Networking | 211,432 |  |  | — |  |  | — |  |  | — |  |  | 211,432 |  |
| Platform Software and Services | — |  |  | 143,295 |  |  | — |  |  | — |  |  | 143,295 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 41,779 |  |  | — |  |  | 41,779 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 202,370 |  |  | 202,370 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 108,994 |  |  | 108,994 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 27,452 |  |  | 27,452 |  |
| Total revenue by product line | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,179,787 |  |  | $ | 45,930 |  |  | $ | 8,891 |  |  | $ | 12,174 |  |  | $ | 2,246,782 |  |
| Services transferred over time | — |  |  | 97,365 |  |  | 32,888 |  |  | 326,642 |  |  | 456,895 |  |
| Total revenue by timing of revenue recognition | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |

- removed (2021-03-10):
[0000936395-20-000036:note_history:54]
|  | Nine Months Ended August 3, 2019 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,897,080 |  |
| Packet Networking | 216,529 |  |  | — |  |  | — |  |  | — |  |  | 216,529 |  |
| Platform Software and Services | — |  |  | 114,139 |  |  | — |  |  | — |  |  | 114,139 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,977 |  |  | — |  |  | 37,977 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 196,002 |  |  | 196,002 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 111,746 |  |  | 111,746 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 30,671 |  |  | 30,671 |  |
| Total revenue by product line | $ | 2,113,609 |  |  | $ | 114,139 |  |  | $ | 37,977 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,113,609 |  |  | $ | 39,801 |  |  | $ | 11,216 |  |  | $ | 13,945 |  |  | $ | 2,178,571 |  |
| Services transferred over time | — |  |  | 74,338 |  |  | 26,761 |  |  | 324,474 |  |  | 425,573 |  |
| Total revenue by timing of revenue recognition | $ | 2,113,609 |  |  | $ | 114,139 |  |  | $ | 37,977 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-03-10):
[0000936395-21-000010:note_history:55]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line. Effective as of the beginning of fiscal 2021, Ciena renamed its “Packet Networking” product line to “Routing and Switching.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. References to prior reported “Packet Networking” product line have been changed to“Routing and Switching” for this product line reported herein.
  (was, 2020-09-09, similarity 0.6035):
[0000936395-20-000036:note_history:55]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

- changed (2021-03-10):
[0000936395-21-000010:note_history:56]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
  (was, 2020-09-09, similarity 0.9714):
[0000936395-20-000036:note_history:56]
|  | Quarter Ended August 1, 2020 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 722,512 |  |
| Packet Networking | 79,756 |  |  | — |  |  | — |  |  | — |  |  | 79,756 |  |
| Platform Software and Services | — |  |  | 46,422 |  |  | — |  |  | — |  |  | 46,422 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 11,297 |  |  | — |  |  | 11,297 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 69,099 |  |  | 69,099 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,798 |  |  | 39,798 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,828 |  |  | 7,828 |  |
| Total revenue by product line | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 802,268 |  |  | $ | 15,838 |  |  | $ | 410 |  |  | $ | 3,300 |  |  | $ | 821,816 |  |
| Services transferred over time | — |  |  | 30,584 |  |  | 10,887 |  |  | 113,425 |  |  | 154,896 |  |
| Total revenue by timing of revenue recognition | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |

- changed (2021-03-10):
[0000936395-21-000010:note_history:57]
|  | Quarter Ended February 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Routing and Switching | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
  (was, 2020-09-09, similarity 0.7468):
[0000936395-20-000036:note_history:57]
|  | Quarter Ended August 3, 2019 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 724,245 |  |
| Packet Networking | 71,823 |  |  | — |  |  | — |  |  | — |  |  | 71,823 |  |
| Platform Software and Services | — |  |  | 37,312 |  |  | — |  |  | — |  |  | 37,312 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 10,530 |  |  | — |  |  | 10,530 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 65,936 |  |  | 65,936 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,802 |  |  | 39,802 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,958 |  |  | 10,958 |  |
| Total revenue by product line | $ | 796,068 |  |  | $ | 37,312 |  |  | $ | 10,530 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 796,068 |  |  | $ | 12,657 |  |  | $ | 1,941 |  |  | $ | 4,804 |  |  | $ | 815,470 |  |
| Services transferred over time | — |  |  | 24,655 |  |  | 8,589 |  |  | 111,892 |  |  | 145,136 |  |
| Total revenue by timing of revenue recognition | $ | 796,068 |  |  | $ | 37,312 |  |  | $ | 10,530 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |

- added (2021-03-10):
[0000936395-21-000010:note_history:58]
Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2021-03-10):
[0000936395-21-000010:note_history:59]
|  |  | Quarter Ended |  |  |
|  |  | January 30, |  | February 1, |  |  |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 496,611 |  |  | $ | 574,004 |  |  |  |  |  |
| EMEA |  | 155,418 |  |  | 129,965 |  |  |  |  |  |
| APAC |  | 105,101 |  |  | 128,943 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 757,130 |  |  | $ | 832,912 |  |  |  |  |  |
  (was, 2020-09-09, similarity 0.6939):
[0000936395-20-000036:note_history:59]
|  |  | Quarter Ended |  |  |  | Nine Months Ended |  |  |
|  |  | August 1, |  | August 3, |  | August 1, |  | August 3, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 713,340 |  |  | $ | 656,261 |  |  | $ | 1,937,725 |  |  | 1,788,234 |  |
| EMEA |  | 162,465 |  |  | 169,532 |  |  | 433,861 |  |  | 413,715 |  |
| APAC |  | 100,907 |  |  | 134,813 |  |  | 332,091 |  |  | 402,195 |  |
| Total revenue by geographic distribution |  | $ | 976,712 |  |  | $ | 960,606 |  |  | $ | 2,703,677 |  |  | $ | 2,604,144 |  |

- added (2021-03-10):
[0000936395-21-000010:note_history:60]
Ciena’s revenue includes $439.4 million and $524.3 million of United States revenue for the first quarter of fiscal 2021 and 2020, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- added (2021-03-10):
[0000936395-21-000010:note_history:61]
For the first quarter of fiscal 2021, there were no customers that accounted for at least 10% of Ciena’s revenue. The table below shows the customers that accounted for at least 10% of Ciena’s revenue for the first quarter of fiscal 2020: (in thousands):

- added (2021-03-10):
[0000936395-21-000010:note_history:62]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| AT&T | n/a |  | $ | 84,010 |  |  |  |  |  |
| Verizon | n/a |  | 114,548 |  |  |  |  |  |
| Total | n/a |  | $ | 198,558 |  |  |  |  |  |

- added (2021-03-10):
[0000936395-21-000010:note_history:63]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

- added (2021-03-10):
[0000936395-21-000010:note_history:64]
The customers identified above for the first quarter of fiscal 2020 purchased products and services from each of Ciena’s operating segments.

- changed (2021-03-10):
[0000936395-21-000010:note_history:65]
•Networking Platforms revenue reflects sales of Ciena’s Converged Packet Optical and Routing and Switching product lines.
  (was, 2020-09-09, similarity 0.8739):
[0000936395-20-000036:note_history:65]
•Networking Platforms revenue reflects sales of Ciena’s Converged Packet Optical and Packet Networking product lines.

- changed (2021-03-10):
[0000936395-21-000010:note_history:66]
◦Converged Packet Optical - includes the 6500 Packet-Optical Platform, Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS) and the 5400 family of Packet-Optical Platforms. This product line also includes sales of the Z-Series Packet-Optical Platform.
  (was, 2020-09-09, similarity 0.6557):
[0000936395-20-000036:note_history:66]
◦Converged Packet Optical - includes the 6500 Packet-Optical Platform, 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system (“Waveserver”), the family of CoreDirector® Multiservice Optical Switches and the Optical Transport Network (OTN) configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform.

- changed (2021-03-10):
[0000936395-21-000010:note_history:67]
◦Routing and Switching - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics.
  (was, 2020-09-09, similarity 0.9609):
[0000936395-20-000036:note_history:67]
◦Packet Networking - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics.

- changed (2021-03-10):
[0000936395-21-000010:note_history:68]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.
  (was, 2020-09-09, similarity 0.7851):
[0000936395-20-000036:note_history:68]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Operating system software and enhanced software features

- added (2021-03-10):
[0000936395-21-000010:note_history:69]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support our installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- added (2021-03-10):
[0000936395-21-000010:note_history:70]
•Blue Planet® Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led operations support system (OSS) transformations by transforming legacy networks into “service ready” networks, accelerating the

- added (2021-03-10):
[0000936395-21-000010:note_history:71]
creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2021-03-10):
[0000936395-21-000010:note_history:72]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.
  (was, 2020-09-09, similarity 0.9938):
[0000936395-20-000036:note_history:72]
Ciena’s software platform revenue typically reflects sales of either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- added (2021-03-10):
[0000936395-21-000010:note_history:73]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2021-03-10):
[0000936395-21-000010:note_history:74]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over     time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.
  (was, 2020-09-09, similarity 0.788):
[0000936395-20-000036:note_history:74]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

- changed (2021-03-10):
[0000936395-21-000010:note_history:75]
|  |  | Balance at January 30, 2021 |  | Balance at October 31, 2020 |
| Accounts receivable, net |  | $ | 700,025 |  |  | $ | 719,405 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 85,461 |  |  | $ | 85,843 |  |
| Deferred revenue |  | $ | 190,600 |  |  | $ | 158,363 |  |
  (was, 2020-09-09, similarity 0.8571):
[0000936395-20-000036:note_history:75]
|  |  | Balance at August 1, 2020 |  | Balance at November 2, 2019 |
| Accounts receivable, net |  | $ | 715,195 |  |  | $ | 724,854 |  |
| Contract assets for unbilled accounts receivable |  | $ | 97,373 |  |  | $ | 84,046 |  |
| Deferred revenue |  | $ | 136,870 |  |  | $ | 156,873 |  |

- added (2021-03-10):
[0000936395-21-000010:note_history:76]
Our contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. See Note 10 below.

- changed (2021-03-10):
[0000936395-21-000010:note_history:77]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $46.4 million and $49.0 million of revenue during the first three months of fiscal 2021 and 2020 that was included in the deferred revenue balance at October 31, 2020 and November 2, 2019, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 30, 2021 and February 1, 2020.
  (was, 2020-09-09, similarity 0.9085):
[0000936395-20-000036:note_history:77]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $91.8 million and $77.4 million of revenue during the first nine months of fiscal 2020 and 2019 that was included in the deferred revenue balance at November 2, 2019 and November 3, 2018, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended August 1, 2020 and August 3, 2019.

- added (2021-03-10):
[0000936395-21-000010:note_history:78]
Capitalized contract acquisition costs consist of deferred sales commissions, were $15.7 million and $15.3 million as of January 30, 2021 and October 31, 2020, respectively, and were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $5.5 million and $5.6 million during the first three months of fiscal 2021 and 2020, respectively, and was included in sales and marketing expense.

- added (2021-03-10):
[0000936395-21-000010:note_history:79]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 30, 2021, the aggregate amount of RPO was $1.1 billion. As of January 30, 2021, Ciena expects approximately 80% of the RPO to be recognized as revenue within the next twelve months.

- removed (2021-03-10):
[0000936395-20-000036:note_history:80]
|  | Nine Months Ended August 1, 2020 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | 1,968,355 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,968,355 |  |
| Packet Networking | 211,432 |  |  | — |  |  | — |  |  | — |  |  | 211,432 |  |
| Platform Software and Services | — |  |  | 143,295 |  |  | — |  |  | — |  |  | 143,295 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 41,779 |  |  | — |  |  | 41,779 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 202,370 |  |  | 202,370 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 108,994 |  |  | 108,994 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 27,452 |  |  | 27,452 |  |
| Total revenue by product line | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,179,787 |  |  | $ | 45,930 |  |  | $ | 8,891 |  |  | $ | 12,174 |  |  | $ | 2,246,782 |  |
| Services transferred over time | — |  |  | 97,365 |  |  | 32,888 |  |  | 326,642 |  |  | 456,895 |  |
| Total revenue by timing of revenue recognition | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |

- removed (2021-03-10):
[0000936395-20-000036:note_history:81]
|  | Nine Months Ended August 3, 2019 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,897,080 |  |
| Packet Networking | 216,529 |  |  | — |  |  | — |  |  | — |  |  | 216,529 |  |
| Platform Software and Services | — |  |  | 114,139 |  |  | — |  |  | — |  |  | 114,139 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,977 |  |  | — |  |  | 37,977 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 196,002 |  |  | 196,002 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 111,746 |  |  | 111,746 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 30,671 |  |  | 30,671 |  |
| Total revenue by product line | $ | 2,113,609 |  |  | $ | 114,139 |  |  | $ | 37,977 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,113,609 |  |  | $ | 39,801 |  |  | $ | 11,216 |  |  | $ | 13,945 |  |  | $ | 2,178,571 |  |
| Services transferred over time | — |  |  | 74,338 |  |  | 26,761 |  |  | 324,474 |  |  | 425,573 |  |
| Total revenue by timing of revenue recognition | $ | 2,113,609 |  |  | $ | 114,139 |  |  | $ | 37,977 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |

- removed (2021-03-10):
[0000936395-20-000036:note_history:82]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel.

- removed (2021-03-10):
[0000936395-20-000036:note_history:83]
embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

- removed (2021-03-10):
[0000936395-20-000036:note_history:84]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- removed (2021-03-10):
[0000936395-20-000036:note_history:85]
•Blue Planet® Automation Software and Services is a comprehensive, open software suite, together with related services, that allows customers to use enhanced knowledge about their networks to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management, unified assurance and analytics (UAA) and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- removed (2021-03-10):
[0000936395-20-000036:note_history:86]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets.

- removed (2021-03-10):
[0000936395-20-000036:note_history:87]
Capitalized contract acquisition costs consist of deferred sales commissions, were $13.0 million and $15.7 million as of August 1, 2020 and November 2, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $16.2 million and $12.5 million during the first nine months of fiscal 2020 and 2019, respectively, and was included in sales and marketing expense.

- removed (2021-03-10):
[0000936395-20-000036:note_history:88]
Remaining Performance Obligations

- removed (2021-03-10):
[0000936395-20-000036:note_history:89]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of August 1, 2020, the aggregate amount of RPO was $970.6 million. As of August 1, 2020, Ciena expects approximately 82% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-03-10):
[0000936395-21-000010:note_history:90]
SUBSEQUENT EVENTS
Stock Repurchase Program

- added (2021-03-10):
[0000936395-21-000010:note_history:91]
From the end of the first quarter of fiscal 2021 through March 5, 2021, Ciena repurchased an additional 188,169 shares of its common stock, for an aggregate purchase price of $10.1 million at an average price of $53.69 per share, inclusive of repurchases pending settlement. As of March 5, 2021, Ciena has repurchased an aggregate of 6,150,659 shares and has an aggregate of $252.1 million of authorized funds remaining under its stock repurchase program.
