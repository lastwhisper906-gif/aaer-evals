# CIEN notes — 0000936395-21-000010


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-21-000010:notes:1]
[same as prior period, unchanged from 0000936395-20-000036:notes:1]

[0000936395-21-000010:notes:2]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions, and estimates reflect, among other things, the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected. In addition, including because the duration and severity of COVID-19 pandemic are uncertain, certain of such estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve, Ciena’s estimates may change materially in future periods.

[0000936395-21-000010:notes:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2020 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2020 (the “2020 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2021 and 2020 are 52-week fiscal years.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-21-000010:notes:4]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2020 Annual Report.

[0000936395-21-000010:notes:5]
[same as prior period, unchanged from 0000936395-20-000036:notes:5]

[0000936395-21-000010:notes:6]
In June 2016, the Financial Accounting Standards Board (”FASB”) issued Accounting Standards Update No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. Ciena adopted ASU 2016-13 on a modified retrospective basis in the first quarter of fiscal year 2021 through a cumulative-effect adjustment at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts the value of Ciena’s accounts receivable, net and contract assets, net. Adoption of ASU 2016-13 did not have a material effect on Ciena’s financial position or results of operations.

[0000936395-21-000010:notes:7]
Ciena’s significant accounting policies updated as a result of adopting this standard are as follows:

[0000936395-21-000010:notes:8]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0000936395-21-000010:notes:9]
Ciena estimates its allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, Ciena determines collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default, the

[0000936395-21-000010:notes:10]
probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

[0000936395-21-000010:notes:11]
Probability of default rates are published by third-party credit rating agencies. Adjustments to Ciena’s exposure probability may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000936395-21-000010:notes:12]
[same as prior period, unchanged from 0000936395-20-000036:notes:23]

[0000936395-21-000010:notes:13]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which enhances and simplifies various aspects related to accounting for income taxes by removing certain exceptions to the general principles in ASC 740.  The amendments also improve consistent application of and simplify U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022, and early adoption is permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-21-000010:notes:14]
[same as prior period, unchanged from 0000936395-20-000036:notes:25]

[0000936395-21-000010:notes:15]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line. Effective as of the beginning of fiscal 2021, Ciena renamed its “Packet Networking” product line to “Routing and Switching.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. References to prior reported “Packet Networking” product line have been changed to“Routing and Switching” for this product line reported herein.

[0000936395-21-000010:notes:16]
[same as prior period, unchanged from 0000936395-20-000036:notes:27]

[0000936395-21-000010:notes:17]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |

[0000936395-21-000010:notes:18]
|  | Quarter Ended February 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Routing and Switching | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |

[0000936395-21-000010:notes:19]
Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-21-000010:notes:20]
[same as prior period, unchanged from 0000936395-20-000036:notes:33]

[0000936395-21-000010:notes:21]
|  |  | Quarter Ended |  |  |
|  |  | January 30, |  | February 1, |  |  |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 496,611 |  |  | $ | 574,004 |  |  |  |  |  |
| EMEA |  | 155,418 |  |  | 129,965 |  |  |  |  |  |
| APAC |  | 105,101 |  |  | 128,943 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 757,130 |  |  | $ | 832,912 |  |  |  |  |  |

[0000936395-21-000010:notes:22]
Ciena’s revenue includes $439.4 million and $524.3 million of United States revenue for the first quarter of fiscal 2021 and 2020, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-21-000010:notes:23]
For the first quarter of fiscal 2021, there were no customers that accounted for at least 10% of Ciena’s revenue. The table below shows the customers that accounted for at least 10% of Ciena’s revenue for the first quarter of fiscal 2020: (in thousands):

[0000936395-21-000010:notes:24]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| AT&T | n/a |  | $ | 84,010 |  |  |  |  |  |
| Verizon | n/a |  | 114,548 |  |  |  |  |  |
| Total | n/a |  | $ | 198,558 |  |  |  |  |  |

[0000936395-21-000010:notes:25]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

[0000936395-21-000010:notes:26]
The customers identified above for the first quarter of fiscal 2020 purchased products and services from each of Ciena’s operating segments.

[0000936395-21-000010:notes:27]
•Networking Platforms revenue reflects sales of Ciena’s Converged Packet Optical and Routing and Switching product lines.

[0000936395-21-000010:notes:28]
◦Converged Packet Optical - includes the 6500 Packet-Optical Platform, Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS) and the 5400 family of Packet-Optical Platforms. This product line also includes sales of the Z-Series Packet-Optical Platform.

[0000936395-21-000010:notes:29]
◦Routing and Switching - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics.

[0000936395-21-000010:notes:30]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-21-000010:notes:31]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support our installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-21-000010:notes:32]
•Blue Planet® Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led operations support system (OSS) transformations by transforming legacy networks into “service ready” networks, accelerating the

[0000936395-21-000010:notes:33]
creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-21-000010:notes:34]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-21-000010:notes:35]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-21-000010:notes:36]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over     time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-21-000010:notes:37]
[same as prior period, unchanged from 0000936395-20-000036:notes:44]

[0000936395-21-000010:notes:38]
[same as prior period, unchanged from 0000936395-20-000036:notes:45]

[0000936395-21-000010:notes:39]
|  |  | Balance at January 30, 2021 |  | Balance at October 31, 2020 |
| Accounts receivable, net |  | $ | 700,025 |  |  | $ | 719,405 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 85,461 |  |  | $ | 85,843 |  |
| Deferred revenue |  | $ | 190,600 |  |  | $ | 158,363 |  |

[0000936395-21-000010:notes:40]
Our contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. See Note 10 below.

[0000936395-21-000010:notes:41]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $46.4 million and $49.0 million of revenue during the first three months of fiscal 2021 and 2020 that was included in the deferred revenue balance at October 31, 2020 and November 2, 2019, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 30, 2021 and February 1, 2020.

[0000936395-21-000010:notes:42]
[same as prior period, unchanged from 0000936395-20-000036:notes:49]

[0000936395-21-000010:notes:43]
Capitalized contract acquisition costs consist of deferred sales commissions, were $15.7 million and $15.3 million as of January 30, 2021 and October 31, 2020, respectively, and were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $5.5 million and $5.6 million during the first three months of fiscal 2021 and 2020, respectively, and was included in sales and marketing expense.

[0000936395-21-000010:notes:44]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 30, 2021, the aggregate amount of RPO was $1.1 billion. As of January 30, 2021, Ciena expects approximately 80% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-21-000010:notes:45]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-21-000010:notes:46]
|  | January 30,2021 |  | October 31,2020 |
| Products | $ | 15,374 |  |  | $ | 17,534 |  |
| Services | 175,226 |  |  | 140,829 |  |
|  | 190,600 |  |  | 158,363 |  |
| Less current portion | (136,229) |  |  | (108,700) |  |
| Long-term deferred revenue | $ | 54,371 |  |  | $ | 49,663 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-21-000010:notes:47]
RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets, for the three months ended January 30, 2021 (in thousands):

[0000936395-21-000010:notes:48]
|  | Workforcereduction |  | Consolidationof excessfacilities and other restructuring activities |  | Total |
| Balance at October 31, 2020 | $ | 2,915 |  |  | $ | — |  |  | $ | 2,915 |  |
| Charges | 1,990 |  | (1) | 3,877 |  | (2) | 5,867 |  |
| Cash payments | (2,994) |  |  | (3,877) |  |  | (6,871) |  |
| Balance at January 30, 2021 | $ | 1,911 |  |  | $ | — |  |  | $ | 1,911 |  |
| Current restructuring liabilities | $ | 1,911 |  |  | $ | — |  |  | $ | 1,911 |  |

[0000936395-21-000010:notes:49]
(1) Reflects a global workforce reduction of 50 employees during the three months ended January 30, 2021 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-21-000010:notes:50]
[same as prior period, unchanged from 0000936395-20-000036:notes:65]

[0000936395-21-000010:notes:51]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets for the three months ended February 1, 2020 (in thousands):

[0000936395-21-000010:notes:52]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at November 2, 2019 | $ | 3,983 |  |  | $ | 11,160 |  |  | $ | 15,143 |  |
| Charges | 1,204 |  | (1) | 3,268 |  | (2) | 4,472 |  |
| Adjustments related to ASC 842 | — |  |  | (11,160) |  | (3) | (11,160) |  |
| Cash payments | (2,955) |  |  | (3,268) |  |  | (6,223) |  |
| Balance at February 1, 2020 | $ | 2,232 |  |  | $ | — |  |  | $ | 2,232 |  |
| Current restructuring liabilities | $ | 2,232 |  |  | $ | — |  |  | $ | 2,232 |  |

[0000936395-21-000010:notes:53]
(1) Reflects a global workforce reduction of approximately 22 employees during the three months ended February 1, 2020 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-21-000010:notes:54]
(2) Primarily represents variable costs and imputed interest expense related to restructured facilities.

[0000936395-21-000010:notes:55]
(3) Represents restructuring reserve liability recognized as a reduction to Operating right-of-use (“ROU”) assets, net in relation to adoption of ASC 842.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-21-000010:notes:56]
INTEREST AND OTHER INCOME (LOSS), NETThe components of interest and other income (loss), net, are as follows (in thousands):

[0000936395-21-000010:notes:57]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Interest income | $ | 534 |  |  | $ | 3,390 |  |  |  |  |  |
| Gains on non-hedge designated foreign currency forward contracts | 4,530 |  |  | 637 |  |  |  |  |  |
| Foreign currency exchange losses | (6,918) |  |  | (771) |  |  |  |  |  |
| Other | 733 |  |  | 390 |  |  |  |  |  |
| Interest and other income (loss), net | $ | (1,121) |  |  | $ | 3,646 |  |  |  |  |  |

[0000936395-21-000010:notes:58]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $6.9 million and $0.8 million in foreign currency exchange rate losses during the first three months of fiscal 2021 and 2020, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the related remeasurement adjustments were recorded in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. During the first three months of fiscal 2021 and 2020, respectively, Ciena recorded gains of $4.5 million and $0.6 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-21-000010:notes:59]
INCOME TAXES
On December 2, 2019, the U.S. Department of the Treasury released final regulations and proposed regulations under Section 59A of the Internal Revenue Code, the Base Erosion and Anti-Abuse Tax (“BEAT”). BEAT, which requires certain U.S. corporations to pay a minimum tax associated with deductible payments to non-U.S. related parties, was enacted as part of the Tax Cuts and Jobs Act (the “Tax Act”). Also, on December 2, 2019, the U.S. Department of the Treasury released final regulations that provide additional guidance with respect to the foreign tax credit regime under the Tax Act.

[0000936395-21-000010:notes:60]
The effective tax rate for the three months ended January 30, 2021 was higher than the effective tax rate for the three months ended February 1, 2020, primarily due to the BEAT reduction in fiscal 2020 and the effect of the final regulations released on December 2, 2019.
Our future income tax provisions and deferred tax balances may be affected by the amount of pre-tax income, the jurisdictions where it is earned, the existence and utilizability of tax attributes and changes in tax laws and business reorganizations. Ciena continues to monitor these items and will adopt strategies to address their impact as appropriate.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-21-000010:notes:61]
SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-21-000010:notes:62]
|  | January 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,420 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 151,434 |  |
| Included in long-term investments | 102,360 |  |  | 4 |  |  | — |  |  | 102,364 |  |
|  | $ | 253,780 |  |  | $ | 18 |  |  | $ | — |  |  | $ | 253,798 |  |

[0000936395-21-000010:notes:63]
|  | October 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 150,559 |  |  | $ | 109 |  |  | $ | (1) |  |  | $ | 150,667 |  |
| Included in long-term investments | 82,252 |  |  | — |  |  | (26) |  |  | 82,226 |  |
|  | $ | 232,811 |  |  | $ | 109 |  |  | $ | (27) |  |  | $ | 232,893 |  |

[0000936395-21-000010:notes:64]
The following table summarizes the final legal maturities of debt investments at January 30, 2021 (in thousands):

[0000936395-21-000010:notes:65]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 151,420 |  |  | $ | 151,434 |  |
| Due in 1-2 years | 102,360 |  |  | 102,364 |  |
|  | $ | 253,780 |  |  | $ | 253,798 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-21-000010:notes:66]
FAIR VALUE MEASUREMENTS
    As of the date indicated, the following table summarizes the assets and liabilities that are recorded at fair value on a recurring basis (in thousands):

[0000936395-21-000010:notes:67]
|  | January 30, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 810,289 |  |  | $ | — |  |  | $ | — |  |  | $ | 810,289 |  |
| Bond mutual fund | 50,348 |  |  | — |  |  | — |  |  | 50,348 |  |
| Time deposits | 35,014 |  |  | — |  |  | — |  |  | 35,014 |  |
| Deferred compensation plan assets | 10,669 |  |  | — |  |  | — |  |  | 10,669 |  |
| U.S. government obligations | — |  |  | 253,798 |  |  | — |  |  | 253,798 |  |
| Foreign currency forward contracts | — |  |  | 8,397 |  |  | — |  |  | 8,397 |  |
| Total assets measured at fair value | $ | 906,320 |  |  | $ | 262,195 |  |  | $ | — |  |  | $ | 1,168,515 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 417 |  |  | $ | — |  |  | $ | 417 |  |
| Forward starting interest rate swaps | — |  |  | 26,248 |  |  | — |  |  | 26,248 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 26,665 |  |  | $ | — |  |  | $ | 26,665 |  |

[0000936395-21-000010:notes:68]
|  | October 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 889,293 |  |  | $ | — |  |  | $ | — |  |  | $ | 889,293 |  |
| Bond mutual fund | 50,361 |  |  | — |  |  | — |  |  | 50,361 |  |
| Deferred compensation plan assets | 8,213 |  |  | — |  |  | — |  |  | 8,213 |  |
| U.S. government obligations | — |  |  | 232,893 |  |  | — |  |  | 232,893 |  |
| Foreign currency forward contracts | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Total assets measured at fair value | $ | 947,867 |  |  | $ | 232,975 |  |  | $ | — |  |  | $ | 1,180,842 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 681 |  |  | $ | — |  |  | $ | 681 |  |
| Forward starting interest rate swaps | — |  |  | 28,513 |  |  | — |  |  | 28,513 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 29,194 |  |  | $ | — |  |  | $ | 29,194 |  |

[0000936395-21-000010:notes:69]
[same as prior period, unchanged from 0000936395-20-000036:notes:83]

[0000936395-21-000010:notes:70]
|  | January 30, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 895,651 |  |  | $ | — |  |  | $ | — |  |  | $ | 895,651 |  |
| Short-term investments | — |  |  | 151,434 |  |  | — |  |  | 151,434 |  |
| Prepaid expenses and other | — |  |  | 8,397 |  |  | — |  |  | 8,397 |  |
| Other long-term assets | 10,669 |  |  | 102,364 |  |  | — |  |  | 113,033 |  |
| Total assets measured at fair value | $ | 906,320 |  |  | $ | 262,195 |  |  | $ | — |  |  | $ | 1,168,515 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 417 |  |  | $ | — |  |  | $ | 417 |  |
| Other long-term obligations | — |  |  | 26,248 |  |  | — |  |  | 26,248 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 26,665 |  |  | $ | — |  |  | $ | 26,665 |  |

[0000936395-21-000010:notes:71]
|  | October 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 939,654 |  |  | $ | — |  |  | $ | — |  |  | $ | 939,654 |  |
| Short-term investments | — |  |  | 150,667 |  |  | — |  |  | 150,667 |  |
| Prepaid expenses and other | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Other long-term assets | 8,213 |  |  | 82,226 |  |  | — |  |  | 90,439 |  |
| Total assets measured at fair value | $ | 947,867 |  |  | $ | 232,975 |  |  | $ | — |  |  | $ | 1,180,842 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 681 |  |  | $ | — |  |  | $ | 681 |  |
| Other long-term obligations | — |  |  | 28,513 |  |  | — |  |  | 28,513 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 29,194 |  |  | $ | — |  |  | $ | 29,194 |  |

[0000936395-21-000010:notes:72]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-21-000010:notes:73]
[same as prior period, unchanged from 0000936395-20-000036:notes:87]

[0000936395-21-000010:notes:74]
|  | January 30,2021 |  | October 31,2020 |
| Raw materials | $ | 123,388 |  |  | $ | 119,481 |  |
| Work-in-process | 11,353 |  |  | 13,738 |  |
| Finished goods | 257,048 |  |  | 210,050 |  |
| Deferred cost of goods sold | 38,920 |  |  | 40,747 |  |
| Gross inventories | 430,709 |  |  | 384,016 |  |
| Provision for excess and obsolescence | (40,976) |  |  | (39,637) |  |
| Inventories, net | $ | 389,733 |  |  | $ | 344,379 |  |

[0000936395-21-000010:notes:75]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first three months of fiscal 2021, Ciena recorded a provision for excess and obsolescence of $5.9 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-21-000010:notes:76]
[same as prior period, unchanged from 0000936395-20-000036:notes:90]

[0000936395-21-000010:notes:77]
|  | January 30,2021 |  | October 31,2020 |
| Contract assets for unbilled accounts receivable, net | $ | 85,461 |  |  | $ | 85,843 |  |
| Prepaid expenses | 76,462 |  |  | 70,647 |  |
| Prepaid VAT and other taxes | 73,767 |  |  | 72,838 |  |
| Product demonstration equipment, net | 44,707 |  |  | 44,793 |  |
| Other non-trade receivables | 26,099 |  |  | 21,981 |  |
| Capitalized contract acquisition costs | 10,712 |  |  | 11,296 |  |
| Derivative assets | 8,397 |  |  | 82 |  |
| Deferred deployment expense | 505 |  |  | 604 |  |
|  | $ | 326,110 |  |  | $ | 308,084 |  |

[0000936395-21-000010:notes:78]
Depreciation of product demonstration equipment was $2.6 million during the first three months of fiscal 2021 and $2.2 million during the first three months of fiscal 2020.

[0000936395-21-000010:notes:79]
[same as prior period, unchanged from 0000936395-20-000036:notes:93]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-21-000010:notes:80]
[same as prior period, unchanged from 0000936395-20-000036:notes:94]

[0000936395-21-000010:notes:81]
|  | January 30,2021 |  | October 31,2020 |
| Compensation, payroll related tax and benefits (1) | $ | 76,477 |  |  | $ | 135,462 |  |
| Warranty | 48,184 |  |  | 49,868 |  |
| Vacation | 28,414 |  |  | 26,945 |  |
| Finance lease obligations | 3,011 |  |  | 2,836 |  |
| Interest payable | 605 |  |  | 672 |  |
| Other | 118,312 |  |  | 118,349 |  |
|  | $ | 275,003 |  |  | $ | 334,132 |  |

[0000936395-21-000010:notes:82]
[same as prior period, unchanged from 0000936395-20-000036:notes:96]

[0000936395-21-000010:notes:83]
[same as prior period, unchanged from 0000936395-20-000036:notes:97]

[0000936395-21-000010:notes:84]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Three Months Ended February 1, 2020 |  | $ | 48,498 |  |  |  |  | 7,898 |  |  | (5,206) |  |  | $ | 51,190 |  |
| Three Months Ended January 30, 2021 |  | $ | 49,868 |  |  |  |  | 3,239 |  |  | (4,923) |  |  | $ | 48,184 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-21-000010:notes:85]
[same as prior period, unchanged from 0000936395-20-000036:notes:99]

[0000936395-21-000010:notes:86]
Ciena conducts business globally in numerous currencies, thus is exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-21-000010:notes:87]
As of January 30, 2021 and October 31, 2020, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability principally related to research and development activities. The notional amount of these contracts was approximately $248.3 million and $254.9 million as of January 30, 2021 and October 31, 2020, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-21-000010:notes:88]
As of January 30, 2021 and October 31, 2020, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $210.4 million and $212.0 million as of January 30, 2021 and October 31, 2020, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-21-000010:notes:89]
[same as prior period, unchanged from 0000936395-20-000036:notes:102]

[0000936395-21-000010:notes:90]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 15 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan (as defined in Note 15 below) at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of January 30, 2021 and October 31, 2020.

[0000936395-21-000010:notes:91]
[same as prior period, unchanged from 0000936395-20-000036:notes:104]

[0000936395-21-000010:notes:92]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Note 5 and Note 8 above.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-21-000010:notes:93]
ACCUMULATED OTHER COMPREHENSIVE INCOMEThe following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the three months ended January 30, 2021 (in thousands):

[0000936395-21-000010:notes:94]
|  | Unrealized Gain/(Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2020 | $ | 45 |  |  | $ | (219) |  |  | $ | (21,535) |  |  | $ | (13,649) |  |  | $ | (35,358) |  |
| Other comprehensive gain (loss) before reclassifications | (49) |  |  | 7,848 |  |  | (659) |  |  | 15,861 |  |  | 23,001 |  |
| Amounts reclassified from AOCI | — |  |  | (1,231) |  |  | 2,041 |  |  | — |  |  | 810 |  |
| Balance at January 30, 2021 | $ | (4) |  |  | $ | 6,398 |  |  | $ | (20,153) |  |  | $ | 2,212 |  |  | $ | (11,547) |  |

[0000936395-21-000010:notes:95]
The following table summarizes the changes in AOCI, net of tax, for the three months ended February 1, 2020 (in thousands):

[0000936395-21-000010:notes:96]
|  | Unrealized Gain/(Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at November 2, 2019 | $ | 152 |  |  | $ | 925 |  |  | $ | (13,686) |  |  | $ | (9,475) |  |  | $ | (22,084) |  |
| Other comprehensive loss before reclassifications | (86) |  |  | (921) |  |  | (1,718) |  |  | (2,982) |  |  | (5,707) |  |
| Amounts reclassified from AOCI | — |  |  | (158) |  |  | 238 |  |  | — |  |  | 80 |  |
| Balance at February 1, 2020 | $ | 66 |  |  | $ | (154) |  |  | $ | (15,166) |  |  | $ | (12,457) |  |  | $ | (27,711) |  |

[0000936395-21-000010:notes:97]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net, on the Condensed Consolidated Statements of Operations.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000936395-21-000010:notes:98]
LEASES
Ciena leases over 1.3 million square feet of facilities globally related to the ongoing operations of its business segments and related functions. Ciena’s principal executive offices are located in Hanover, Maryland. Ciena’s largest facilities are research and development centers located in Ottawa, Canada and Gurgaon, India. Ciena also has engineering and/or service delivery facilities located in San Jose, California; Alpharetta, Georgia; Quebec, Canada; Austin, Texas; and Pune and Bangalore, India. In addition, Ciena leases various smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. Ciena's current leases have remaining terms that vary up to 11 years. Certain leases provide for options to extend up to 10 years and/or options to terminate within five years.

[0000936395-21-000010:notes:99]
Leases included in the Condensed Consolidated Balance Sheets were as follows (in thousands):

[0000936395-21-000010:notes:100]
|  | Classification |  | As of January 30, 2021 | As of October 31, 2020 |
| Operating leases: |  |  |  |  |
| Operating ROU assets | Operating right-of-use assets |  | $ | 54,244 |  | $ | 57,026 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | 76,990 |  | 80,450 |  |
| Finance leases: |  |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 73,776 |  | $ | 70,791 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (19,764) |  | (17,837) |  |
| Buildings, net |  |  | $ | 54,012 |  | $ | 52,954 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 66,409 |  | $ | 64,401 |  |

[0000936395-21-000010:notes:101]
ROU assets that involve subleased or vacant space aggregate $4.7 million as of January 30, 2021. These assets may become impaired if tenants are unable to service their obligations under the sublease, and/or if the estimates as to occupancy are not realized, either of which may be more likely as COVID-19 impacts evolve.

[0000936395-21-000010:notes:102]
The components of lease expense included in the Condensed Consolidated Statement of Operations were as follows (in thousands):

[0000936395-21-000010:notes:103]
|  |  |  |  | Three Months Ended | Three Months Ended |
|  | Classification |  |  | January 30, 2021 | February 1, 2020 |
| Operating lease costs | Operating expense |  |  | $ | 4,229 |  | $ | 4,457 |  |
| Finance lease cost: |  |  |  |  |  |
| Amortization of finance ROU asset | Operating expense |  |  | 1,165 |  | 1,140 |  |
| Interest on finance lease liabilities | Interest expense |  |  | 1,221 |  | 1,244 |  |
| Total finance lease cost |  |  |  | 2,386 |  | 2,384 |  |
| Non-capitalized lease cost | Operating expense |  |  | 293 |  | 621 |  |
| Variable lease cost(1) | Operating expense |  |  | 1,599 |  | 1,311 |  |
| Net lease cost(2) |  |  |  | $ | 8,507 |  | $ | 8,773 |  |

[0000936395-21-000010:notes:104]
(1) Variable lease costs include expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0000936395-21-000010:notes:105]
(2) Excludes other operating expense of $2.3 million and $4.3 million for the three months ended January 30, 2021 and February 1, 2020, respectively, related to amortization of leasehold improvements.

[0000936395-21-000010:notes:106]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of January 30, 2021 were as follows (in thousands):

[0000936395-21-000010:notes:107]
|  | Operating Leases |  | Finance Leases |  | Total |
| Remaining fiscal 2021 | $ | 16,077 |  |  | $ | 7,759 |  |  | $ | 23,836 |  |
| 2022 | 19,112 |  |  | 8,215 |  |  | 27,327 |  |
| 2023 | 15,747 |  |  | 8,294 |  |  | 24,041 |  |
| 2024 | 13,237 |  |  | 8,310 |  |  | 21,547 |  |
| 2025 | 8,900 |  |  | 8,494 |  |  | 17,394 |  |
| Thereafter | 9,367 |  |  | 58,427 |  |  | 67,794 |  |
| Total lease payments | 82,440 |  |  | 99,499 |  |  | 181,939 |  |
| Less: Imputed interest | (5,450) |  |  | (33,090) |  |  | (38,540) |  |
| Present value of lease liabilities | 76,990 |  |  | 66,409 |  |  | 143,399 |  |
| Less: Current portion of present value of minimum lease payments | (19,364) |  |  | (3,011) |  |  | (22,375) |  |
| Long-term portion of present value of minimum lease payments | $ | 57,626 |  |  | $ | 63,398 |  |  | $ | 121,024 |  |

[0000936395-21-000010:notes:108]
The weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows:

[0000936395-21-000010:notes:109]
|  | As of January 30, 2021 | As of October 31, 2020 |
| Weighted-average remaining lease term in years: |  |  |
| Operating leases | 4.68 | 4.87 |
| Finance leases | 11.46 | 11.71 |
| Weighted-average discount rates: |  |  |
| Operating leases | 2.82 | % | 2.82 | % |
| Finance leases | 7.56 | % | 7.56 | % |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-21-000010:notes:110]
SHORT-TERM AND LONG-TERM DEBT 
2025 Term Loan

[0000936395-21-000010:notes:111]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-21-000010:notes:112]
The net carrying value of Ciena’s term loan was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-21-000010:notes:113]
|  |  | January 30, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 686,070 |  |  | $ | (1,495) |  |  | $ | (2,789) |  |  | $ | 681,786 |  |  | $ | 683,286 |  |

[0000936395-21-000010:notes:114]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loan totaled $2.8 million at January 30, 2021 and $2.9 million at October 31, 2020. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.2 million during the first three months of each of fiscal 2021 and fiscal 2020. The carrying value of the term loan listed above is also net of any unamortized debt discounts.

[0000936395-21-000010:notes:115]
As of January 30, 2021, the estimated fair value of the 2025 Term Loan was $686.1 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:EarningsPerShareTextBlock

[0000936395-21-000010:notes:116]
EARNINGS PER SHARE CALCULATION
The following tables (in thousands, except per share amounts) reconcile basic net income per common share (“Basic EPS”) and diluted net income per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-21-000010:notes:117]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
| Numerator | 2021 |  | 2020 |  |  |  |  |
| Net income used to calculate Basic and Diluted EPS | $ | 55,348 |  |  | $ | 62,328 |  |  |  |  |  |

[0000936395-21-000010:notes:118]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
| Denominator | 2021 |  | 2020 |  |  |  |  |
| Basic weighted average shares outstanding | 155,174 |  |  | 154,334 |  |  |  |  |  |
| Add: Shares underlying outstanding stock options and stock unit awards and issuable under employee stock purchase plan | 1,409 |  |  | 1,404 |  |  |  |  |  |
| Dilutive weighted average shares outstanding | 156,583 |  |  | 155,738 |  |  |  |  |  |

[0000936395-21-000010:notes:119]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
| EPS | 2021 |  | 2020 |  |  |  |  |
| Basic EPS | $ | 0.36 |  |  | $ | 0.40 |  |  |  |  |  |
| Diluted EPS | $ | 0.35 |  |  | $ | 0.40 |  |  |  |  |  |

[0000936395-21-000010:notes:120]
[same as prior period, unchanged from 0000936395-20-000036:notes:137]

[0000936395-21-000010:notes:121]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Shares underlying stock options and stock unit awards | 135 |  |  | 731 |  |  |  |  |  |
| Total shares excluded due to anti-dilutive effect | 135 |  |  | 731 |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-21-000010:notes:122]
[same as prior period, unchanged from 0000936395-20-000036:notes:139]

[0000936395-21-000010:notes:123]
On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of Ciena’s common stock. After temporarily suspending repurchases of Ciena’s common stock during fiscal 2020, Ciena reinstituted its stock repurchase program in the first quarter of 2021. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-21-000010:notes:124]
[same as prior period, unchanged from 0000936395-20-000036:notes:141]

[0000936395-21-000010:notes:125]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2020 | 5,710,912 |  |  | $ | 39.33 |  |  | $ | 224,611 |  |
| Repurchase of common stock under the stock repurchase program | 251,578 |  |  | 52.49 |  |  | 13,206 |  |
| Cumulative balance at January 30, 2021 | 5,962,490 |  |  | $ | 39.89 |  |  | $ | 237,817 |  |

[0000936395-21-000010:notes:126]
[same as prior period, unchanged from 0000936395-20-000036:notes:143]

[0000936395-21-000010:notes:127]
[same as prior period, unchanged from 0000936395-20-000036:notes:144]

[0000936395-21-000010:notes:128]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The purchase price of $19.2 million for the shares of Ciena’s stock repurchased during the first three months of fiscal 2021 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-21-000010:notes:129]
SHARE-BASED COMPENSATION EXPENSE
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-21-000010:notes:130]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Product costs | $ | 953 |  |  | $ | 671 |  |  |  |  |  |
| Service costs | 1,205 |  |  | 842 |  |  |  |  |  |
| Share-based compensation expense included in cost of goods sold | 2,158 |  |  | 1,513 |  |  |  |  |  |
| Research and development | 4,794 |  |  | 3,849 |  |  |  |  |  |
| Sales and marketing | 5,816 |  |  | 4,613 |  |  |  |  |  |
| General and administrative | 6,358 |  |  | 5,527 |  |  |  |  |  |
| Share-based compensation expense included in operating expense | 16,968 |  |  | 13,989 |  |  |  |  |  |
| Share-based compensation expense capitalized in inventory, net | (162) |  |  | 100 |  |  |  |  |  |
| Total share-based compensation | $ | 18,964 |  |  | $ | 15,602 |  |  |  |  |  |

[0000936395-21-000010:notes:131]
As of January 30, 2021, total unrecognized share-based compensation expense was approximately $169.0 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.68 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-21-000010:notes:132]
[same as prior period, unchanged from 0000936395-20-000036:notes:150]

[0000936395-21-000010:notes:133]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services.

[0000936395-21-000010:notes:134]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, ROU assets, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 30, 2021, equipment, building, furniture and fixtures, net, totaled $281.2 million, and operating ROU assets totaled $54.2 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of January 30, 2021, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-21-000010:notes:135]
|  | January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 12,924 |  |  | $ | — |  |  | $ | 78,592 |  |  | $ | — |  |  | $ | 91,516 |  |
| Goodwill | $ | 66,054 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 311,294 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 63,008 |  |  | $ | 63,008 |  |

[0000936395-21-000010:notes:136]
[same as prior period, unchanged from 0000936395-20-000036:notes:157]

[0000936395-21-000010:notes:137]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; significant asset impairments and restructuring costs; acquisition and integration costs; interest and other income (loss), net; interest expense; loss on extinguishment and modification of debt and provision for income taxes.

[0000936395-21-000010:notes:138]
[same as prior period, unchanged from 0000936395-20-000036:notes:159]

[0000936395-21-000010:notes:139]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 156,431 |  |  | $ | 168,270 |  |  |  |  |  |
| Platform Software and Services | 27,660 |  |  | 28,951 |  |  |  |  |  |
| Blue Planet Automation Software and Services | (2,434) |  |  | (3,113) |  |  |  |  |  |
| Global Services | 43,493 |  |  | 45,527 |  |  |  |  |  |
| Total segment profit | 225,150 |  |  | 239,635 |  |  |  |  |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 97,278 |  |  | 107,066 |  |  |  |  |  |
| General and administrative | 39,993 |  |  | 42,468 |  |  |  |  |  |
| Amortization of intangible assets | 5,910 |  |  | 5,853 |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 5,867 |  |  | 4,472 |  |  |  |  |  |
| Acquisition and integration costs | 307 |  |  | 1,819 |  |  |  |  |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (8,481) |  |  | (5,169) |  |  |  |  |  |
| Loss on extinguishment and modification of debt | — |  |  | (646) |  |  |  |  |  |
| Less: Provision for income taxes | 11,966 |  |  | 9,814 |  |  |  |  |  |
| Consolidated net income | $ | 55,348 |  |  | $ | 62,328 |  |  |  |  |  |

[0000936395-21-000010:notes:140]
[same as prior period, unchanged from 0000936395-20-000036:notes:161]

[0000936395-21-000010:notes:141]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, and operating ROU assets specifically identified. Equipment, building, furniture and fixtures, net, and operating ROU assets attributable to geographic regions outside of the U.S. and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets was as follows (in thousands):

[0000936395-21-000010:notes:142]
|  | January 30,2021 |  | October 31,2020 |
| Canada | $ | 226,331 |  |  | $ | 214,188 |  |
| United States | 62,980 |  |  | 65,321 |  |
| Other International | 46,161 |  |  | 49,894 |  |
| Total | $ | 335,472 |  |  | $ | 329,403 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-21-000010:notes:143]
COMMITMENTS AND CONTINGENCIES
Canadian Grant

[0000936395-21-000010:notes:144]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.1 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 30, 2021, Ciena has recorded CAD$44.2 million (approximately $34.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$3.6 million ($2.8 million) was recorded in the first three months of fiscal 2021. As of January 30, 2021, amounts receivable from this grant were CAD$3.2 million ($2.5 million).

[0000936395-21-000010:notes:145]
Tax Contingencies

[0000936395-21-000010:notes:146]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-21-000010:notes:147]
Litigation

[0000936395-21-000010:notes:148]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-21-000010:notes:149]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0000936395-21-000010:notes:150]
From the end of the first quarter of fiscal 2021 through March 5, 2021, Ciena repurchased an additional 188,169 shares of its common stock, for an aggregate purchase price of $10.1 million at an average price of $53.69 per share, inclusive of repurchases pending settlement. As of March 5, 2021, Ciena has repurchased an aggregate of 6,150,659 shares and has an aggregate of $252.1 million of authorized funds remaining under its stock repurchase program.
