# CIEN note change history — 0000936395-14-000040 → 0000936395-14-000051


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-09-09):
[0000936395-14-000051:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of C$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Ciena anticipates receiving disbursements, approximating C$5.0 million per fiscal year, over the period above. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2014, Ciena has recorded a C$21.5 million benefit to date as a reduction in research and development expenses, of which C$5.1 million was recorded in the first nine months of fiscal 2014. As of July 31, 2014, amounts receivable from this grant were C$1.5 million.
  (was, 2014-06-11, similarity 0.9559):
[0000936395-14-000040:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of C$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Ciena anticipates receiving disbursements, approximating C$5.0 million per fiscal year, over the period above. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of April 30, 2014, Ciena has recorded a C$20.0 million benefit to date as a reduction in research and development expenses, of which C$3.6 million was recorded in the first six months of fiscal 2014. As of April 30, 2014, amounts receivable from this grant were C$3.6 million.

- changed (2014-09-09):
[0000936395-14-000051:note_history:2]
As of October 31, 2013 and July 31, 2014, Ciena had accrued liabilities of $0.4 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 related to income taxes. This contingency has been reported as a component of other long-term liabilities. During February 2014, Ciena received a final audit assessment notice from the India tax authorities with respect to this matter. Ciena has filed an appeal citing deficiencies in this assessment. Although Ciena estimates that it could be exposed to possible losses of up to $2.8 million, it has not accrued a liability of such amount as of July 31, 2014. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to this assessment. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.
  (was, 2014-06-11, similarity 0.9917):
[0000936395-14-000040:note_history:2]
As of October 31, 2013 and April 30, 2014, Ciena had accrued liabilities of $0.4 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 related to income taxes. This contingency has been reported as a component of other long-term liabilities. During February 2014, Ciena received a final audit assessment notice from the India tax authorities with respect to this matter. Ciena has filed an appeal citing deficiencies in this assessment. Although Ciena estimates that it could be exposed to possible losses of up to $2.9 million, it has not accrued a liability of such amount as of April 30, 2014. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to this assessment. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-09-09):
[0000936395-14-000051:note_history:3]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending upon the duration of the restriction.
  (was, 2014-06-11, similarity 0.9931):
[0000936395-14-000040:note_history:3]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending upon the duration of the restriction.

- changed (2014-09-09):
[0000936395-14-000051:note_history:4]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and its intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.
  (was, 2014-06-11, similarity 0.9995):
[0000936395-14-000040:note_history:4]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and its intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

- changed (2014-09-09):
[0000936395-14-000051:note_history:5]
Long-lived assets include: equipment, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.
  (was, 2014-06-11, similarity 0.9919):
[0000936395-14-000040:note_history:5]
Long-lived assets include: equipment, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups which represent the lowest level for which cash flows can be identified.

- changed (2014-09-09):
[0000936395-14-000051:note_history:6]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and term loan, see Note 13 below.
  (was, 2014-06-11, similarity 0.9768):
[0000936395-14-000040:note_history:6]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes, see Note 13 below.

- changed (2014-09-09):
[0000936395-14-000051:note_history:7]
Some of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects a net loss on foreign currency re-measurement and exchange rate changes of $9.2 million for the nine months ended July 31, 2013 and a net gain of $1.0 million for the nine months ended July 31, 2014.
  (was, 2014-06-11, similarity 0.9583):
[0000936395-14-000040:note_history:7]
Some of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects a net loss on foreign currency re-measurement and exchange rate changes of $3.0 million for the six months ended April 30, 2013 and a net gain of $5.3 million for the six months ended April 30, 2014.

- changed (2014-09-09):
[0000936395-14-000051:note_history:8]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") include a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature is recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. Interest and other income (loss), net reflects an increase in fair value of $2.7 million for the nine months ended July 31, 2013 and a reduction in fair value of $2.7 million for the nine months ended July 31, 2014.
  (was, 2014-06-11, similarity 0.9133):
[0000936395-14-000040:note_history:8]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") include a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature is recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects an increase in fair value of $0.4 million for the six months ended April 30, 2013 and a reduction in fair value of $2.6 million for the six months ended April 30, 2014.

- changed (2014-09-09):
[0000936395-14-000051:note_history:9]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less and are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the forward contract has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and upon the occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statements of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net.
  (was, 2014-06-11, similarity 0.9984):
[0000936395-14-000040:note_history:9]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S.-dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less and are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the forward contract has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and upon the occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net.

- changed (2014-09-09):
[0000936395-14-000051:note_history:10]
From time to time, Ciena uses foreign currency forwards to hedge certain balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. Interest and other income (loss), net reflects a gain of $0.9 million for the nine months ended July 31, 2013 and a loss of $11.7 million related to foreign currency forward contracts for the nine months ended July 31, 2014. See Note 12 below.
  (was, 2014-06-11, similarity 0.8796):
[0000936395-14-000040:note_history:10]
From time to time, Ciena uses foreign currency forwards to hedge certain balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects losses of $0.1 million and $10.2 million related to foreign currency forward contracts for the six months ended April 30, 2013 and 2014, respectively. See Note 12 below.

- changed (2014-09-09):
[0000936395-14-000051:note_history:11]
Ciena records derivative instruments in the Condensed Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.
  (was, 2014-06-11, similarity 0.9974):
[0000936395-14-000040:note_history:11]
Ciena records derivative instruments in the Condensed Consolidated Statement of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

- changed (2014-09-09):
[0000936395-14-000051:note_history:12]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its condensed consolidated financial statements.
  (was, 2014-06-11, similarity 0.9994):
[0000936395-14-000040:note_history:12]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606) which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its condensed consolidated financial statements.


## cien:ConvertibleNotesPayableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-09-09):
[0000936395-14-000051:note_history:13]
SHORT-TERM AND LONG-TERM DEBT

- added (2014-09-09):
[0000936395-14-000051:note_history:14]
Term Loan

- added (2014-09-09):
[0000936395-14-000051:note_history:15]
On July 15, 2014, Ciena entered into a Credit Agreement (the “Term Loan Credit Agreement”) which provides for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”). Ciena received proceeds from the Term Loan, net of original issue discount and debt issuance costs, of approximately $246 million.

- added (2014-09-09):
[0000936395-14-000051:note_history:16]
The Term Loan bears interest at a rate equal to LIBOR (subject to a floor of 0.75%) plus an applicable margin of 3.00% and matures on July 15, 2019. The Term Loan Credit Agreement requires Ciena to make quarterly installment payments in aggregate amounts equal to 0.25% of the original principal amount of the Term Loan, with the balance of the Term Loan payable at maturity. The Term Loan Credit Agreement requires mandatory prepayments on the occurrence of certain customary events and, when the total secured net leverage ratio (as defined in the Term Loan Credit Agreement) is in excess of 2.50 to 1.00, the Term Loan Credit Agreement requires a mandatory prepayment of 50% of excess annual cash flow (as defined in the Term Loan Credit Agreement).

- added (2014-09-09):
[0000936395-14-000051:note_history:17]
The Term Loan Credit Agreement contains customary covenants that limit, absent lender approval, the ability of Ciena to, among other things, incur additional debt, create liens and encumbrances, pay cash dividends, enter into certain acquisition transactions or transactions with affiliates, merge, dissolve, repay certain indebtedness, change the nature of Ciena’s business, make investments or dispose of assets.

- added (2014-09-09):
[0000936395-14-000051:note_history:18]
The Term Loan Credit Agreement contains customary events of default including, among other things, failure to pay obligations when due, initiation of bankruptcy or insolvency proceedings, defaults on certain other indebtedness, change of control, incurrence of certain material judgments, violation of affirmative and negative covenants, and breaches of representations and warranties set forth in the Term Loan Credit Agreement. Upon an event of default, the administrative agent may, subject to various customary cure rights, require the immediate payment of all amounts outstanding and foreclose on collateral.

- added (2014-09-09):
[0000936395-14-000051:note_history:19]
In connection with Ciena entering into the Term Loan Credit Agreement, Ciena and certain of its subsidiaries entered into a guaranty, a security agreement and a pledge agreement, each on customary terms. The Term Loan is secured by (i) second-priority security interests in the ABL Priority Collateral (as defined in Note 14 below), and (ii) first-priority security interests in substantially all other tangible and intangible assets including equipment, intercompany notes, intellectual property and material owned real property (the "Term Loan Priority Collateral").

- changed (2014-09-09):
[0000936395-14-000051:note_history:20]
The principal balance, unamortized discount and net carrying amount of the Term Loan was as follows as of July 31, 2014:
  (was, 2014-06-11, similarity 0.6173):
[0000936395-14-000040:note_history:20]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 Notes ("2020 Notes") were as follows as of April 30, 2014:

- added (2014-09-09):
[0000936395-14-000051:note_history:21]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 250,000 |  |  | $ | 1,237 |  |  | $ | 248,763 |  |
|  |  | $ | 250,000 |  |  | $ | 1,237 |  |  | $ | 248,763 |  |

- added (2014-09-09):
[0000936395-14-000051:note_history:22]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

- added (2014-09-09):
[0000936395-14-000051:note_history:23]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 248,763 |  |  | $ | 249,375 |  |
|  |  | $ | 248,763 |  |  | $ | 249,375 |  |

- added (2014-09-09):
[0000936395-14-000051:note_history:24]
| (1) | Includes unamortized bond discount. |

- added (2014-09-09):
[0000936395-14-000051:note_history:25]
| (2) | The term loan was categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- changed (2014-09-09):
[0000936395-14-000051:note_history:26]
Convertible Notes
  (was, 2014-06-11, similarity 0.8095):
[0000936395-14-000040:note_history:26]
CONVERTIBLE NOTES PAYABLE

- added (2014-09-09):
[0000936395-14-000051:note_history:27]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 ("2020 Notes") were as follows as of July 31, 2014:

- added (2014-09-09):
[0000936395-14-000051:note_history:28]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,605 |  |  | $ | 206,719 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 445,813 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 177,853 |  |  | 242,822 |  |
|  |  | $ | 1,215,458 |  |  | $ | 1,389,729 |  |

- removed (2014-09-09):
[0000936395-14-000040:note_history:29]
|  |  | April 30, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | 187,647 |  |  | 214,805 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 448,875 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 176,641 |  |  | 246,797 |  |
|  |  | $ | 1,214,288 |  |  | $ | 1,404,852 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-09-09):
[0000936395-14-000051:note_history:30]
|  | July 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 90,210 |  |  | $ | 42 |  |  | — |  |  | $ | 90,252 |  |
| Included in long-term investments | 65,043 |  |  | — |  |  | (24 | ) |  | 65,019 |  |
|  | $ | 155,253 |  |  | $ | 42 |  |  | $ | (24 | ) |  | $ | 155,271 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,998 |  |  | — |  |  | — |  |  | 29,998 |  |
|  | $ | 29,998 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,998 |  |
  (was, 2014-06-11, similarity 0.8749):
[0000936395-14-000040:note_history:30]
|  | April 30, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 60,042 |  |  | $ | 16 |  |  | — |  |  | $ | 60,058 |  |
| Included in long-term investments | 14,997 |  |  | 45 |  |  | — |  |  | 15,042 |  |
|  | $ | 75,039 |  |  | $ | 61 |  |  | $ | — |  |  | $ | 75,100 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,991 |  |  | — |  |  | — |  |  | 29,991 |  |
|  | $ | 29,991 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,991 |  |

- changed (2014-09-09):
[0000936395-14-000051:note_history:31]
The following table summarizes final legal maturities of debt investments at July 31, 2014 (in thousands):
  (was, 2014-06-11, similarity 0.9655):
[0000936395-14-000040:note_history:31]
The following table summarizes final legal maturities of debt investments at April 30, 2014 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-09-09):
[0000936395-14-000051:note_history:32]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,605 |  |  | $ | 206,719 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 445,813 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 177,853 |  |  | 242,822 |  |
|  |  | $ | 1,215,458 |  |  | $ | 1,389,729 |  |

- added (2014-09-09):
[0000936395-14-000051:note_history:33]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

- added (2014-09-09):
[0000936395-14-000051:note_history:34]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 248,763 |  |  | $ | 249,375 |  |
|  |  | $ | 248,763 |  |  | $ | 249,375 |  |

- added (2014-09-09):
[0000936395-14-000051:note_history:35]
| (1) | Includes unamortized bond discount. |

- added (2014-09-09):
[0000936395-14-000051:note_history:36]
| (2) | The term loan was categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- added (2014-09-09):
[0000936395-14-000051:note_history:37]
The principal balance, unamortized discount and net carrying amount of the Term Loan was as follows as of July 31, 2014:

- added (2014-09-09):
[0000936395-14-000051:note_history:38]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 250,000 |  |  | $ | 1,237 |  |  | $ | 248,763 |  |
|  |  | $ | 250,000 |  |  | $ | 1,237 |  |  | $ | 248,763 |  |

- removed (2014-09-09):
[0000936395-14-000040:note_history:39]
|  |  | April 30, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | 187,647 |  |  | 214,805 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 448,875 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 176,641 |  |  | 246,797 |  |
|  |  | $ | 1,214,288 |  |  | $ | 1,404,852 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-09-09):
[0000936395-14-000051:note_history:40]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 ("2020 Notes") were as follows as of July 31, 2014:
  (was, 2014-06-11, similarity 0.9635):
[0000936395-14-000040:note_history:40]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 Notes ("2020 Notes") were as follows as of April 30, 2014:
