# CIEN notes — 0000936395-14-000051


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-14-000051:notes:1]
[same as prior period, unchanged from 0000936395-14-000040:notes:1]

[0000936395-14-000051:notes:2]
[same as prior period, unchanged from 0000936395-14-000040:notes:2]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-14-000051:notes:3]
[same as prior period, unchanged from 0000936395-14-000040:notes:3]

[0000936395-14-000051:notes:4]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending upon the duration of the restriction.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-14-000051:notes:5]
COMMITMENTS AND CONTINGENCIES

[0000936395-14-000051:notes:6]
Ontario Grant

[0000936395-14-000051:notes:7]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of C$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Ciena anticipates receiving disbursements, approximating C$5.0 million per fiscal year, over the period above. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2014, Ciena has recorded a C$21.5 million benefit to date as a reduction in research and development expenses, of which C$5.1 million was recorded in the first nine months of fiscal 2014. As of July 31, 2014, amounts receivable from this grant were C$1.5 million.

[0000936395-14-000051:notes:8]
Foreign Tax Contingencies

[0000936395-14-000051:notes:9]
As of October 31, 2013 and July 31, 2014, Ciena had accrued liabilities of $0.4 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 related to income taxes. This contingency has been reported as a component of other long-term liabilities. During February 2014, Ciena received a final audit assessment notice from the India tax authorities with respect to this matter. Ciena has filed an appeal citing deficiencies in this assessment. Although Ciena estimates that it could be exposed to possible losses of up to $2.8 million, it has not accrued a liability of such amount as of July 31, 2014. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to this assessment. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.

[0000936395-14-000051:notes:10]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-14-000051:notes:11]
Litigation

[0000936395-14-000051:notes:12]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-14-000051:notes:13]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-14-000051:notes:14]
Loss Contingencies

[0000936395-14-000051:notes:15]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-14-000051:notes:16]
[same as prior period, unchanged from 0000936395-14-000040:notes:16]

[0000936395-14-000051:notes:17]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. GAAP requires that a liability for the cost associated with an exit or disposal activity be recognized in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period of more than 60 days, which are accrued over the service period. See Note 3 below.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-14-000051:notes:18]
[same as prior period, unchanged from 0000936395-14-000040:notes:18]

[0000936395-14-000051:notes:19]
|  | October 31, 2013 |  | July 31, 2014 |
| Products | $ | 36,671 |  |  | $ | 57,590 |  |
| Services | 75,499 |  |  | 82,078 |  |
|  | 112,170 |  |  | 139,668 |  |
| Less current portion | (88,550 | ) |  | (114,590 | ) |
| Long-term deferred revenue | $ | 23,620 |  |  | $ | 25,078 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-14-000051:notes:20]
[same as prior period, unchanged from 0000936395-14-000040:notes:20]

[0000936395-14-000051:notes:21]
As of July 31, 2014, Ciena had forward contracts to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which expense principally relates to research and development activities. These derivative contracts have been designated as cash flow hedges. During the first nine months of fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell Brazilian Real and buy an equivalent U.S. Dollar amount and forward contracts to sell U.S. Dollars and buy an equivalent amount of Canadian Dollars. These derivative contracts have not been designated as hedges. Ciena's foreign currency forward contracts are immaterial for separate financial statement presentation.


## us-gaap:DerivativesPolicyTextBlock

[0000936395-14-000051:notes:22]
[same as prior period, unchanged from 0000936395-14-000040:notes:22]

[0000936395-14-000051:notes:23]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") include a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature is recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. Interest and other income (loss), net reflects an increase in fair value of $2.7 million for the nine months ended July 31, 2013 and a reduction in fair value of $2.7 million for the nine months ended July 31, 2014.

[0000936395-14-000051:notes:24]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less and are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the forward contract has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and upon the occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statements of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net.

[0000936395-14-000051:notes:25]
From time to time, Ciena uses foreign currency forwards to hedge certain balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. Interest and other income (loss), net reflects a gain of $0.9 million for the nine months ended July 31, 2013 and a loss of $11.7 million related to foreign currency forward contracts for the nine months ended July 31, 2014. See Note 12 below.

[0000936395-14-000051:notes:26]
Ciena records derivative instruments in the Condensed Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-14-000051:notes:27]
[same as prior period, unchanged from 0000936395-14-000040:notes:26]

[0000936395-14-000051:notes:28]
[same as prior period, unchanged from 0000936395-14-000040:notes:27]

[0000936395-14-000051:notes:29]
[same as prior period, unchanged from 0000936395-14-000040:notes:28]

[0000936395-14-000051:notes:30]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. Pursuant to Board and stockholder approval, effective April 10, 2014, Ciena amended its 2008 Plan to increase the number of shares available for issuance by 6.6 million shares. The total number of shares authorized for issuance under the 2008 Plan is 25.1 million shares. As of July 31, 2014, approximately 9.4 million shares remained available for issuance under the 2008 Plan.

[0000936395-14-000051:notes:31]
[same as prior period, unchanged from 0000936395-14-000040:notes:30]

[0000936395-14-000051:notes:32]
Outstanding stock option awards to employees are generally subject to service-based vesting restrictions and vest incrementally over a four-year period. As of July 31, 2014, all outstanding options have completed their service-based vesting conditions and are fully vested. The following table is a summary of Ciena’s stock option activity for the period indicated (shares in thousands):

[0000936395-14-000051:notes:33]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2013 | 2,102 |  |  | $ | 27.46 |  |
| Exercised | (153 | ) |  | 17.28 |  |
| Canceled | (571 | ) |  | 36.11 |  |
| Balance at July 31, 2014 | 1,378 |  |  | $ | 25.00 |  |

[0000936395-14-000051:notes:34]
The total intrinsic value of options exercised during the first nine months of fiscal 2013 and fiscal 2014 was $1.0 million and $1.0 million, respectively. Ciena did not grant any stock options during the first nine months of fiscal 2013 or fiscal 2014.

[0000936395-14-000051:notes:35]
The following table summarizes information with respect to stock options outstanding at July 31, 2014, based on Ciena’s closing stock price on the last trading day of Ciena’s third fiscal quarter of 2014 (shares and intrinsic value in thousands):

[0000936395-14-000051:notes:36]
|  |  |  |  |  |  | Options Outstanding and Vested at |
|  |  |  |  |  |  | July 31, 2014 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 0.94 |  |  | — |  |  | $ | 16.31 |  |  | 163 |  |  | 3.44 |  | $ | 8.08 |  |  | $ | 1,791 |  |
| $ | 16.52 |  |  | — |  |  | $ | 17.29 |  |  | 247 |  |  | 0.95 |  | 16.64 |  |  | 609 |  |
| $ | 17.43 |  |  | — |  |  | $ | 24.50 |  |  | 196 |  |  | 1.44 |  | 18.70 |  |  | 195 |  |
| $ | 24.69 |  |  | — |  |  | $ | 28.28 |  |  | 286 |  |  | 2.65 |  | 27.31 |  |  | — |  |
| $ | 28.61 |  |  | — |  |  | $ | 31.43 |  |  | 102 |  |  | 3.03 |  | 29.79 |  |  | — |  |
| $ | 31.71 |  |  | — |  |  | $ | 32.55 |  |  | 19 |  |  | 1.43 |  | 31.92 |  |  | — |  |
| $ | 33.00 |  |  | — |  |  | $ | 37.10 |  |  | 249 |  |  | 3.29 |  | 35.23 |  |  | — |  |
| $ | 37.31 |  |  | — |  |  | $ | 47.32 |  |  | 116 |  |  | 2.99 |  | 44.30 |  |  | — |  |
| $ | 0.94 |  |  | — |  |  | $ | 47.32 |  |  | 1,378 |  |  | 2.42 |  | $ | 25.00 |  |  | $ | 2,595 |  |

[0000936395-14-000051:notes:37]
[same as prior period, unchanged from 0000936395-14-000040:notes:36]

[0000936395-14-000051:notes:38]
[same as prior period, unchanged from 0000936395-14-000040:notes:37]

[0000936395-14-000051:notes:39]
[same as prior period, unchanged from 0000936395-14-000040:notes:38]

[0000936395-14-000051:notes:40]
[same as prior period, unchanged from 0000936395-14-000040:notes:39]

[0000936395-14-000051:notes:41]
[same as prior period, unchanged from 0000936395-14-000040:notes:40]

[0000936395-14-000051:notes:42]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2013 | 4,419 |  |  | $ | 15.33 |  |  | $ | 102,745 |  |
| Granted | 1,819 |  |  |  |  |  |
| Vested | (1,757 | ) |  |  |  |  |
| Canceled or forfeited | (127 | ) |  |  |  |  |
| Balance at July 31, 2014 | 4,354 |  |  | $ | 17.90 |  |  | $ | 83,173 |  |

[0000936395-14-000051:notes:43]
The total fair value of restricted stock units that vested and were converted into common stock during the first nine months of fiscal 2013 and fiscal 2014 was $25.3 million and $40.4 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first nine months of fiscal 2013 and fiscal 2014 was $15.89 and $21.96 respectively.

[0000936395-14-000051:notes:44]
[same as prior period, unchanged from 0000936395-14-000040:notes:43]

[0000936395-14-000051:notes:45]
[same as prior period, unchanged from 0000936395-14-000040:notes:44]

[0000936395-14-000051:notes:46]
[same as prior period, unchanged from 0000936395-14-000040:notes:45]

[0000936395-14-000051:notes:47]
[same as prior period, unchanged from 0000936395-14-000040:notes:46]

[0000936395-14-000051:notes:48]
[same as prior period, unchanged from 0000936395-14-000040:notes:47]

[0000936395-14-000051:notes:49]
[same as prior period, unchanged from 0000936395-14-000040:notes:48]

[0000936395-14-000051:notes:50]
During the first nine months of fiscal 2014, Ciena issued 0.9 million shares under the ESPP. At July 31, 2014, 6.8 million shares remained available for issuance under the ESPP.

[0000936395-14-000051:notes:51]
[same as prior period, unchanged from 0000936395-14-000040:notes:50]

[0000936395-14-000051:notes:52]
[same as prior period, unchanged from 0000936395-14-000040:notes:51]

[0000936395-14-000051:notes:53]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Product costs | $ | 658 |  |  | $ | 737 |  |  | $ | 1,905 |  |  | $ | 1,984 |  |
| Service costs | 461 |  |  | 572 |  |  | 1,323 |  |  | 1,720 |  |
| Share-based compensation expense included in cost of sales | 1,119 |  |  | 1,309 |  |  | 3,228 |  |  | 3,704 |  |
| Research and development | 2,054 |  |  | 2,368 |  |  | 6,291 |  |  | 7,722 |  |
| Sales and marketing | 3,562 |  |  | 3,890 |  |  | 9,687 |  |  | 12,199 |  |
| General and administrative | 3,198 |  |  | 3,376 |  |  | 8,898 |  |  | 10,543 |  |
| Share-based compensation expense included in operating expense | 8,814 |  |  | 9,634 |  |  | 24,876 |  |  | 30,464 |  |
| Share-based compensation expense capitalized in inventory, net | (48 | ) |  | (182 | ) |  | (72 | ) |  | 36 |  |
| Total share-based compensation | $ | 9,885 |  |  | $ | 10,761 |  |  | $ | 28,032 |  |  | $ | 34,204 |  |

[0000936395-14-000051:notes:54]
As of July 31, 2014, total unrecognized share-based compensation expense related to unvested restricted stock units was $64.5 million, and this expense is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-14-000051:notes:55]
[same as prior period, unchanged from 0000936395-14-000040:notes:54]

[0000936395-14-000051:notes:56]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 15 below.


## us-gaap:EarningsPerShareTextBlock

[0000936395-14-000051:notes:57]
[same as prior period, unchanged from 0000936395-14-000040:notes:56]

[0000936395-14-000051:notes:58]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of restricted stock units, (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method, and (iv) shares underlying Ciena’s outstanding convertible notes.

[0000936395-14-000051:notes:59]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Numerator | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Net income (loss) | $ | (1,231 | ) |  | $ | 16,160 |  |  | $ | (75,634 | ) |  | $ | (9,934 | ) |
| Add: Interest expense associated with 0.875% convertible senior notes due 2017 | — |  |  | 1,384 |  |  | $ | — |  |  | — |  |
| Net income (loss) used to calculate Diluted EPS | $ | (1,231 | ) |  | $ | 17,544 |  |  | $ | (75,634 | ) |  | $ | (9,934 | ) |

[0000936395-14-000051:notes:60]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Denominator | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Weighted average basic common shares outstanding | 102,713 |  |  | 106,236 |  |  | 101,951 |  |  | 105,404 |  |
| Add: Shares underlying outstanding stock options, employees stock purchase plan and restricted stock units | — |  |  | 1,465 |  |  | — |  |  | — |  |
| Add: Shares underlying 0.875% convertible senior notes due 2017 | — |  |  | 13,108 |  |  | — |  |  | — |  |
| Weighted average dilutive potential common shares outstanding | 102,713 |  |  | 120,809 |  |  | 101,951 |  |  | 105,404 |  |

[0000936395-14-000051:notes:61]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| EPS | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Basic EPS | $ | (0.01 | ) |  | $ | 0.15 |  |  | $ | (0.74 | ) |  | $ | (0.09 | ) |
| Diluted EPS | $ | (0.01 | ) |  | $ | 0.15 |  |  | $ | (0.74 | ) |  | $ | (0.09 | ) |

[0000936395-14-000051:notes:62]
[same as prior period, unchanged from 0000936395-14-000040:notes:61]

[0000936395-14-000051:notes:63]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Shares underlying stock options and restricted stock units | 3,599 |  |  | 1,123 |  |  | 3,727 |  |  | 3,205 |  |
| 0.25% Convertible Senior Notes due May 1, 2013 | — |  |  | — |  |  | 3,580 |  |  | — |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | 9,198 |  |  | 9,198 |  |  | 10,990 |  |  | 9,198 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | 13,108 |  |  | — |  |  | 13,108 |  |  | 13,108 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,356 |  |  | 17,356 |  |  | 17,356 |  |  | 17,356 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |  | 7,406 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 52,459 |  |  | 36,875 |  |  | 56,167 |  |  | 52,065 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-14-000051:notes:64]
[same as prior period, unchanged from 0000936395-14-000040:notes:63]

[0000936395-14-000051:notes:65]
|  | July 31, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 390,006 |  |  | $ | — |  |  | $ | — |  |  | $ | 390,006 |  |
| U.S. government obligations | — |  |  | 155,271 |  |  | — |  |  | 155,271 |  |
| Commercial paper | — |  |  | 79,993 |  |  | — |  |  | 79,993 |  |
| Foreign currency forward contracts | — |  |  | 849 |  |  | — |  |  | 849 |  |
| Total assets measured at fair value | $ | 390,006 |  |  | $ | 236,113 |  |  | $ | — |  |  | $ | 626,119 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 390 |  |  | $ | — |  |  | $ | 390 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 390 |  |  | $ | — |  |  | $ | 390 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0000936395-14-000051:notes:66]
[same as prior period, unchanged from 0000936395-14-000040:notes:65]

[0000936395-14-000051:notes:67]
|  | Level 3 |
| Balance at October 31, 2013 | $ | 2,740 |  |
| Issuances | — |  |
| Settlements | — |  |
| Changes in unrealized gain (loss) | (2,740 | ) |
| Transfers into Level 3 | — |  |
| Transfers out of Level 3 | — |  |
| Balance at July 31, 2014 | $ | — |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-14-000051:notes:68]
[same as prior period, unchanged from 0000936395-14-000040:notes:67]

[0000936395-14-000051:notes:69]
|  | July 31, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 390,006 |  |  | $ | 49,995 |  |  | $ | — |  |  | $ | 440,001 |  |
| Short-term investments | — |  |  | 120,250 |  |  | — |  |  | 120,250 |  |
| Prepaid expenses and other | — |  |  | 849 |  |  | — |  |  | 849 |  |
| Long-term investments | — |  |  | 65,019 |  |  | — |  |  | 65,019 |  |
| Total assets measured at fair value | $ | 390,006 |  |  | $ | 236,113 |  |  | $ | — |  |  | $ | 626,119 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 390 |  |  | $ | — |  |  | $ | 390 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 390 |  |  | $ | — |  |  | $ | 390 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-14-000051:notes:70]
[same as prior period, unchanged from 0000936395-14-000040:notes:69]

[0000936395-14-000051:notes:71]
Ciena’s Level 3 assets that were included in other long-term assets reflect an embedded redemption feature contained within the 2015 Notes. The embedded redemption feature is bifurcated from the 2015 Notes using the “with-and-without” approach. As such, the total value of the embedded redemption feature is calculated as the difference between the value of the 2015 Notes (the “Hybrid Instrument”) and the value of an identical instrument without the embedded redemption feature (the “Host Instrument”). Both the Host Instrument and the Hybrid Instrument are valued using a modified binomial model. The modified binomial model utilizes a risk free interest rate, an implied volatility of Ciena’s stock, the recovery rates of bonds and the implied default intensity of the 2015 Notes.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-14-000051:notes:72]
[same as prior period, unchanged from 0000936395-14-000040:notes:71]

[0000936395-14-000051:notes:73]
Some of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects a net loss on foreign currency re-measurement and exchange rate changes of $9.2 million for the nine months ended July 31, 2013 and a net gain of $1.0 million for the nine months ended July 31, 2014.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-14-000051:notes:74]
[same as prior period, unchanged from 0000936395-14-000040:notes:73]

[0000936395-14-000051:notes:75]
Long-lived assets include: equipment, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-14-000051:notes:76]
[same as prior period, unchanged from 0000936395-14-000040:notes:75]

[0000936395-14-000051:notes:77]
[same as prior period, unchanged from 0000936395-14-000040:notes:76]

[0000936395-14-000051:notes:78]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2008 through 2012 and in Canada for 2010 through 2012. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2011), United Kingdom (2012), Canada (2009) and India (2008). However, limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense. All of the uncertain tax positions, if recognized, would decrease the effective income tax rate.

[0000936395-14-000051:notes:79]
[same as prior period, unchanged from 0000936395-14-000040:notes:78]

[0000936395-14-000051:notes:80]
[same as prior period, unchanged from 0000936395-14-000040:notes:79]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-14-000051:notes:81]
[same as prior period, unchanged from 0000936395-14-000040:notes:80]

[0000936395-14-000051:notes:82]
[same as prior period, unchanged from 0000936395-14-000040:notes:81]

[0000936395-14-000051:notes:83]
|  | October 31, 2013 |  | July 31, 2014 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 417,833 |  |  | $ | (321,645 | ) |  | $ | 96,188 |  |  | $ | 417,833 |  |  | $ | (345,178 | ) |  | $ | 72,655 |  |
| Patents and licenses | 46,538 |  |  | (45,744 | ) |  | 794 |  |  | 46,538 |  |  | (45,867 | ) |  | 671 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 323,573 |  |  | (234,727 | ) |  | 88,846 |  |  | 323,573 |  |  | (255,002 | ) |  | 68,571 |  |
| Total other intangible assets | $ | 787,944 |  |  | $ | (602,116 | ) |  | $ | 185,828 |  |  | $ | 787,944 |  |  | $ | (646,047 | ) |  | $ | 141,897 |  |

[0000936395-14-000051:notes:84]
The amortization of finite-lived other intangible assets was $53.5 million and $43.9 million for the first nine months of fiscal 2013 and 2014, respectively. Expected future amortization of finite-lived other intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-14-000051:notes:85]
| Period ended October 31, |  |
| 2014 (remaining three months) | $ | 13,220 |  |
| 2015 | 52,879 |  |
| 2016 | 52,879 |  |
| 2017 | 22,783 |  |
| 2018 | 136 |  |
|  | $ | 141,897 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-14-000051:notes:86]
[same as prior period, unchanged from 0000936395-14-000040:notes:85]

[0000936395-14-000051:notes:87]
[same as prior period, unchanged from 0000936395-14-000040:notes:86]

[0000936395-14-000051:notes:88]
|  | October 31, 2013 |  | July 31, 2014 |
| Raw materials | $ | 53,274 |  |  | $ | 61,429 |  |
| Work-in-process | 7,773 |  |  | 8,268 |  |
| Finished goods | 153,855 |  |  | 172,321 |  |
| Deferred cost of goods sold | 75,764 |  |  | 103,701 |  |
|  | 290,666 |  |  | 345,719 |  |
| Provision for excess and obsolescence | (41,563 | ) |  | (52,627 | ) |
|  | $ | 249,103 |  |  | $ | 293,092 |  |

[0000936395-14-000051:notes:89]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first nine months of fiscal 2014, Ciena recorded a provision for excess and obsolescence of $22.0 million, primarily related to engineering design changes and the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform, and Converged Packet Optical products. Deductions from the provision for excess and obsolete inventory relate to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-14-000051:notes:90]
[same as prior period, unchanged from 0000936395-14-000040:notes:89]

[0000936395-14-000051:notes:91]
[same as prior period, unchanged from 0000936395-14-000040:notes:90]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-14-000051:notes:92]
[same as prior period, unchanged from 0000936395-14-000040:notes:91]

[0000936395-14-000051:notes:93]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and its intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-14-000051:notes:94]
The following table summarizes final legal maturities of debt investments at July 31, 2014 (in thousands):

[0000936395-14-000051:notes:95]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 120,208 |  |  | $ | 120,250 |  |
| Due in 1-2 years | 65,043 |  |  | 65,019 |  |
|  | $ | 185,251 |  |  | $ | 185,269 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-14-000051:notes:96]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-14-000051:notes:97]
As of the dates indicated, short-term and long-term investments are comprised of the following (in thousands):

[0000936395-14-000051:notes:98]
|  | July 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 90,210 |  |  | $ | 42 |  |  | — |  |  | $ | 90,252 |  |
| Included in long-term investments | 65,043 |  |  | — |  |  | (24 | ) |  | 65,019 |  |
|  | $ | 155,253 |  |  | $ | 42 |  |  | $ | (24 | ) |  | $ | 155,271 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,998 |  |  | — |  |  | — |  |  | 29,998 |  |
|  | $ | 29,998 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,998 |  |

[0000936395-14-000051:notes:99]
|  | October 31, 2013 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 99,974 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 99,985 |  |
| Included in long-term investments | 14,996 |  |  | 35 |  |  | — |  |  | 15,031 |  |
|  | $ | 114,970 |  |  | $ | 46 |  |  | $ | — |  |  | $ | 115,016 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 24,994 |  |  | — |  |  | — |  |  | 24,994 |  |
|  | $ | 24,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,994 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-14-000051:notes:100]
[same as prior period, unchanged from 0000936395-14-000040:notes:99]

[0000936395-14-000051:notes:101]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-14-000051:notes:102]
[same as prior period, unchanged from 0000936395-14-000040:notes:101]

[0000936395-14-000051:notes:103]
As of October 31, 2013, two customers each accounted for greater than 10% of net accounts receivable, and in the aggregate accounted for 22.5% of net accounts receivable. As of July 31, 2014, two customers each accounted for greater than 10% of net accounts receivable, and in the aggregate accounted for 24.3% of net accounts receivable. Allowance for doubtful accounts was $2.0 million and $2.7 million as of October 31, 2013 and July 31, 2014, respectively. Ciena has not historically experienced a significant amount of bad debt expense.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-14-000051:notes:104]
Newly Issued Accounting Standards

[0000936395-14-000051:notes:105]
In February 2013, the Financial Accounting Standards Board ("FASB") issued an accounting standard update to require reclassification adjustments from other comprehensive income to be presented either in the financial statements or in the notes to the financial statements. This accounting standard update was effective for Ciena beginning in the first quarter of fiscal 2014. Ciena has determined that reclassifications from other comprehensive income to net income are immaterial for separate financial statement presentation.

[0000936395-14-000051:notes:106]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its condensed consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-14-000051:notes:107]
[same as prior period, unchanged from 0000936395-14-000040:notes:106]

[0000936395-14-000051:notes:108]
[same as prior period, unchanged from 0000936395-14-000040:notes:107]

[0000936395-14-000051:notes:109]
[same as prior period, unchanged from 0000936395-14-000040:notes:108]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-14-000051:notes:110]
[same as prior period, unchanged from 0000936395-14-000040:notes:109]

[0000936395-14-000051:notes:111]
[same as prior period, unchanged from 0000936395-14-000040:notes:110]

[0000936395-14-000051:notes:112]
|  | October 31, 2013 |  | July 31, 2014 |
| Equipment, furniture and fixtures | $ | 364,574 |  |  | $ | 368,986 |  |
| Leasehold improvements | 46,247 |  |  | 45,423 |  |
|  | 410,821 |  |  | 414,409 |  |
| Accumulated depreciation and amortization | (291,092 | ) |  | (297,460 | ) |
|  | $ | 119,729 |  |  | $ | 116,949 |  |

[0000936395-14-000051:notes:113]
The total of depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements, was $37.1 million and $34.8 million for the first nine months of fiscal 2013 and 2014, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-14-000051:notes:114]
[same as prior period, unchanged from 0000936395-14-000040:notes:113]

[0000936395-14-000051:notes:115]
[same as prior period, unchanged from 0000936395-14-000040:notes:114]


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-14-000051:notes:116]
[same as prior period, unchanged from 0000936395-14-000040:notes:115]

[0000936395-14-000051:notes:117]
[same as prior period, unchanged from 0000936395-14-000040:notes:116]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-14-000051:notes:118]
[same as prior period, unchanged from 0000936395-14-000040:notes:117]

[0000936395-14-000051:notes:119]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 66,952 |  |  | $ | 104,020 |  |  | $ | 171,598 |  |  | $ | 279,299 |  |
| Packet Networking | 7,620 |  |  | 14,566 |  |  | 15,259 |  |  | 23,147 |  |
| Optical Transport | 29,459 |  |  | 8,900 |  |  | 71,459 |  |  | 29,259 |  |
| Software and Services | 31,121 |  |  | 38,802 |  |  | 92,232 |  |  | 93,136 |  |
| Total segment profit | 135,152 |  |  | 166,288 |  |  | 350,548 |  |  | 424,841 |  |
| Less: non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 75,613 |  |  | 81,919 |  |  | 216,676 |  |  | 243,929 |  |
| General and administrative | 32,066 |  |  | 36,285 |  |  | 91,157 |  |  | 98,264 |  |
| Amortization of intangible assets | 12,440 |  |  | 11,019 |  |  | 37,332 |  |  | 34,951 |  |
| Restructuring costs | 202 |  |  | 63 |  |  | 6,741 |  |  | 178 |  |
| Add: other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (14,139 | ) |  | (17,836 | ) |  | (39,116 | ) |  | (47,787 | ) |
| Loss on extinguishment of debt | — |  |  | — |  |  | (28,630 | ) |  | — |  |
| Less: Provision for income taxes | 1,923 |  |  | 3,006 |  |  | 6,530 |  |  | 9,666 |  |
| Consolidated net loss | $ | (1,231 | ) |  | $ | 16,160 |  |  | $ | (75,634 | ) |  | $ | (9,934 | ) |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-14-000051:notes:120]
[same as prior period, unchanged from 0000936395-14-000040:notes:119]

[0000936395-14-000051:notes:121]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 302,018 |  |  | $ | 382,031 |  |  | $ | 836,303 |  |  | $ | 1,072,272 |  |
| Packet Networking | 61,631 |  |  | 69,464 |  |  | 161,658 |  |  | 187,699 |  |
| Optical Transport | 66,218 |  |  | 31,016 |  |  | 181,186 |  |  | 100,729 |  |
| Software and Services | 108,489 |  |  | 121,051 |  |  | 320,014 |  |  | 336,626 |  |
| Consolidated revenue | $ | 538,356 |  |  | $ | 603,562 |  |  | $ | 1,499,161 |  |  | $ | 1,697,326 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-14-000051:notes:122]
[same as prior period, unchanged from 0000936395-14-000040:notes:121]

[0000936395-14-000051:notes:123]
[same as prior period, unchanged from 0000936395-14-000040:notes:122]

[0000936395-14-000051:notes:124]
[same as prior period, unchanged from 0000936395-14-000040:notes:123]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-14-000051:notes:125]
[same as prior period, unchanged from 0000936395-14-000040:notes:124]

[0000936395-14-000051:notes:126]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2014 (in thousands):

[0000936395-14-000051:notes:127]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2013 | $ | 80 |  |  | $ | 1,936 |  |  | $ | 2,016 |  |
| Additional liability recorded | 169 |  |  | 9 |  |  | 178 |  |
| Cash payments | (208 | ) |  | (269 | ) |  | (477 | ) |
| Balance at July 31, 2014 | $ | 41 |  |  | $ | 1,676 |  |  | $ | 1,717 |  |
| Current restructuring liabilities | $ | 41 |  |  | $ | 612 |  |  | $ | 653 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,064 |  |  | $ | 1,064 |  |

[0000936395-14-000051:notes:128]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2013 (in thousands):

[0000936395-14-000051:notes:129]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2012 | $ | 1,449 |  |  | $ | 3,600 |  |  | $ | 5,049 |  |
| Additional liability recorded | 5,003 |  |  | 1,738 |  |  | 6,741 |  |
| Non-cash disposal | — |  |  | (747 | ) |  | (747 | ) |
| Cash payments | (6,107 | ) |  | (2,999 | ) |  | (9,106 | ) |
| Balance at July 31, 2013 | $ | 345 |  |  | $ | 1,592 |  |  | $ | 1,937 |  |
| Current restructuring liabilities | $ | 345 |  |  | $ | 453 |  |  | $ | 798 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,139 |  |  | $ | 1,139 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-14-000051:notes:130]
[same as prior period, unchanged from 0000936395-14-000040:notes:129]

[0000936395-14-000051:notes:131]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is generally deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-14-000051:notes:132]
[same as prior period, unchanged from 0000936395-14-000040:notes:131]

[0000936395-14-000051:notes:133]
[same as prior period, unchanged from 0000936395-14-000040:notes:132]

[0000936395-14-000051:notes:134]
[same as prior period, unchanged from 0000936395-14-000040:notes:133]

[0000936395-14-000051:notes:135]
[same as prior period, unchanged from 0000936395-14-000040:notes:134]

[0000936395-14-000051:notes:136]
[same as prior period, unchanged from 0000936395-14-000040:notes:135]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-14-000051:notes:137]
[same as prior period, unchanged from 0000936395-14-000040:notes:136]

[0000936395-14-000051:notes:138]
|  | October 31, 2013 |  | July 31, 2014 |
| Warranty | $ | 56,303 |  |  | $ | 57,442 |  |
| Compensation, payroll related tax and benefits | 98,770 |  |  | 77,272 |  |
| Vacation | 32,118 |  |  | 33,837 |  |
| Current restructuring liabilities | 674 |  |  | 653 |  |
| Interest payable | 6,186 |  |  | 8,679 |  |
| Other | 77,605 |  |  | 89,963 |  |
|  | $ | 271,656 |  |  | $ | 267,846 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-14-000051:notes:139]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding convertible notes:

[0000936395-14-000051:notes:140]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,605 |  |  | $ | 206,719 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 445,813 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 177,853 |  |  | 242,822 |  |
|  |  | $ | 1,215,458 |  |  | $ | 1,389,729 |  |

[0000936395-14-000051:notes:141]
| (1) | Includes unamortized bond premium related to embedded redemption feature. |

[0000936395-14-000051:notes:142]
| (2) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-14-000051:notes:143]
| (3) | Includes unamortized discount and accretion of principal. |

[0000936395-14-000051:notes:144]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

[0000936395-14-000051:notes:145]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 248,763 |  |  | $ | 249,375 |  |
|  |  | $ | 248,763 |  |  | $ | 249,375 |  |

[0000936395-14-000051:notes:146]
| (1) | Includes unamortized bond discount. |

[0000936395-14-000051:notes:147]
| (2) | The term loan was categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-14-000051:notes:148]
The principal balance, unamortized discount and net carrying amount of the Term Loan was as follows as of July 31, 2014:

[0000936395-14-000051:notes:149]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 250,000 |  |  | $ | 1,237 |  |  | $ | 248,763 |  |
|  |  | $ | 250,000 |  |  | $ | 1,237 |  |  | $ | 248,763 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0000936395-14-000051:notes:150]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 ("2020 Notes") were as follows as of July 31, 2014:

[0000936395-14-000051:notes:151]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 193,101 |  |  | $ | 15,248 |  |  | $ | 177,853 |  |  | $ | 43,131 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-14-000051:notes:152]
[same as prior period, unchanged from 0000936395-14-000040:notes:145]

[0000936395-14-000051:notes:153]
|  | October 31, 2013 |  | July 31, 2014 |
| Maintenance spares inventory, net | $ | 61,305 |  |  | $ | 56,202 |  |
| Deferred debt issuance costs, net | 15,677 |  |  | 16,360 |  |
| Embedded redemption feature | 2,740 |  |  | — |  |
| Restricted cash | 2,053 |  |  | 46 |  |
| Other | 4,605 |  |  | 5,513 |  |
|  | $ | 86,380 |  |  | $ | 78,121 |  |


## us-gaap:ScheduleOfOtherAssetsTableTextBlock

[0000936395-14-000051:notes:154]
[same as prior period, unchanged from 0000936395-14-000040:notes:147]

[0000936395-14-000051:notes:155]
|  | October 31, 2013 |  | July 31, 2014 |
| Prepaid VAT and other taxes | $ | 101,072 |  |  | $ | 111,004 |  |
| Product demonstration equipment, net | 33,382 |  |  | 42,754 |  |
| Deferred deployment expense | 23,190 |  |  | 27,992 |  |
| Prepaid expenses | 16,963 |  |  | 20,742 |  |
| Other non-trade receivables | 12,048 |  |  | 8,140 |  |
|  | $ | 186,655 |  |  | $ | 210,632 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-14-000051:notes:156]
[same as prior period, unchanged from 0000936395-14-000040:notes:149]

[0000936395-14-000051:notes:157]
|  |  |  |  |  |  |  | Balance at |
| Nine months ended | Beginning |  |  |  |  |  | end of |
| July 31, | Balance |  | Provisions |  | Settlements |  | period |
| 2013 | $ | 55,132 |  |  | 15,148 |  |  | (16,904 | ) |  | $ | 53,376 |  |
| 2014 | $ | 56,303 |  |  | 18,720 |  |  | (17,581 | ) |  | $ | 57,442 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-14-000051:notes:158]
[same as prior period, unchanged from 0000936395-14-000040:notes:151]

[0000936395-14-000051:notes:159]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Company A | $ | 104,070 |  |  | $ | 130,278 |  |  | $ | 277,280 |  |  | $ | 351,323 |  |
| Company B | 67,051 |  |  | n/a |  |  | 172,407 |  |  | n/a |  |
| Total | $ | 171,121 |  |  | $ | 130,278 |  |  | $ | 449,687 |  |  | $ | 351,323 |  |

[0000936395-14-000051:notes:160]
[same as prior period, unchanged from 0000936395-14-000040:notes:153]

[0000936395-14-000051:notes:161]
[same as prior period, unchanged from 0000936395-14-000040:notes:154]


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-14-000051:notes:162]
[same as prior period, unchanged from 0000936395-14-000040:notes:155]

[0000936395-14-000051:notes:163]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| United States | $ | 339,426 |  |  | $ | 368,056 |  |  | $ | 891,233 |  |  | $ | 1,009,433 |  |
| International | 198,930 |  |  | 235,506 |  |  | 607,928 |  |  | 687,893 |  |
| Total | $ | 538,356 |  |  | $ | 603,562 |  |  | $ | 1,499,161 |  |  | $ | 1,697,326 |  |

[0000936395-14-000051:notes:164]
[same as prior period, unchanged from 0000936395-14-000040:notes:157]

[0000936395-14-000051:notes:165]
|  | October 31, 2013 |  | July 31, 2014 |
| United States | $ | 64,132 |  |  | $ | 62,733 |  |
| Canada | 43,772 |  |  | 42,755 |  |
| Other International | 11,825 |  |  | 11,461 |  |
| Total | $ | 119,729 |  |  | $ | 116,949 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-14-000051:notes:166]
[same as prior period, unchanged from 0000936395-14-000040:notes:159]

[0000936395-14-000051:notes:167]
[same as prior period, unchanged from 0000936395-14-000040:notes:160]

[0000936395-14-000051:notes:168]
[same as prior period, unchanged from 0000936395-14-000040:notes:161]

[0000936395-14-000051:notes:169]
[same as prior period, unchanged from 0000936395-14-000040:notes:162]

[0000936395-14-000051:notes:170]
| • | Packet Networking — principally includes Ciena's 3000 family of service delivery switches and service aggregation switches, the 5000 series of service aggregation switches. This segment also includes Ciena’s new 8700 Packetwave Platform, a multi-terabit packet switching platform for high-density metro networks. The 8700 combines Ethernet switching and optical transport to help network operators deliver on-demand, cloud-based services with improved economics. In addition, this segment includes Ciena's Ethernet packet configuration for the 5410 Service Aggregation Switch. These products support the access and aggregation tiers of communications networks and have principally been deployed to support wireless backhaul infrastructures and business data services. Employing sophisticated, carrier-grade Ethernet switching technology, these products deliver quality of service capabilities, virtual local area networking and switching functions, and carrier-grade operations, administration, and maintenance features. This segment includes stand-alone broadband products that transition voice networks to support Internet-based (IP) telephony, video services and DSL. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-14-000051:notes:171]
[same as prior period, unchanged from 0000936395-14-000040:notes:164]

[0000936395-14-000051:notes:172]
| • | Software and Services — includes Ciena's network software suite, including the Agility software portfolio which includes a multilayer software-defined networking (SDN) controller and new software applications for enabling on-demand, high-bandwidth wide area network (WAN) services delivered in an open network ecosystem. With Agility, Ciena's customers can better monetize cloud-based services and virtual network functions created in a traditional or an SDN environment. This segment also includes the OneControl Unified Management System. These software solutions can track individual services across multiple product suites, facilitating planned network maintenance, outage detection and identification of customers or services affected by network performance. In addition, this segment includes the ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and network level applications. This segment includes a broad range of consulting, network design and support services from Ciena's Network Transformation Solutions offering. This segment also includes installation and deployment, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-14-000051:notes:173]
[same as prior period, unchanged from 0000936395-14-000040:notes:166]

[0000936395-14-000051:notes:174]
[same as prior period, unchanged from 0000936395-14-000040:notes:167]

[0000936395-14-000051:notes:175]
[same as prior period, unchanged from 0000936395-14-000040:notes:168]

[0000936395-14-000051:notes:176]
[same as prior period, unchanged from 0000936395-14-000040:notes:169]

[0000936395-14-000051:notes:177]
[same as prior period, unchanged from 0000936395-14-000040:notes:170]

[0000936395-14-000051:notes:178]
[same as prior period, unchanged from 0000936395-14-000040:notes:171]

[0000936395-14-000051:notes:179]
[same as prior period, unchanged from 0000936395-14-000040:notes:172]

[0000936395-14-000051:notes:180]
[same as prior period, unchanged from 0000936395-14-000040:notes:173]


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-14-000051:notes:181]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Converged Packet Optical, (ii) Packet Networking, (iii) Optical Transport, and (iv) Software and Services. See Note 17 below.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-14-000051:notes:182]
[same as prior period, unchanged from 0000936395-14-000040:notes:175]

[0000936395-14-000051:notes:183]
[same as prior period, unchanged from 0000936395-14-000040:notes:176]

[0000936395-14-000051:notes:184]
[same as prior period, unchanged from 0000936395-14-000040:notes:177]

[0000936395-14-000051:notes:185]
accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, share-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-14-000051:notes:186]
[same as prior period, unchanged from 0000936395-14-000040:notes:180]

[0000936395-14-000051:notes:187]
[same as prior period, unchanged from 0000936395-14-000040:notes:181]

[0000936395-14-000051:notes:188]
[same as prior period, unchanged from 0000936395-14-000040:notes:182]

[0000936395-14-000051:notes:189]
[same as prior period, unchanged from 0000936395-14-000040:notes:183]

[0000936395-14-000051:notes:190]
[same as prior period, unchanged from 0000936395-14-000040:notes:184]

[0000936395-14-000051:notes:191]
[same as prior period, unchanged from 0000936395-14-000040:notes:185]

[0000936395-14-000051:notes:192]
[same as prior period, unchanged from 0000936395-14-000040:notes:186]

[0000936395-14-000051:notes:193]
[same as prior period, unchanged from 0000936395-14-000040:notes:187]

[0000936395-14-000051:notes:194]
[same as prior period, unchanged from 0000936395-14-000040:notes:188]

[0000936395-14-000051:notes:195]
[same as prior period, unchanged from 0000936395-14-000040:notes:189]

[0000936395-14-000051:notes:196]
[same as prior period, unchanged from 0000936395-14-000040:notes:190]

[0000936395-14-000051:notes:197]
[same as prior period, unchanged from 0000936395-14-000040:notes:191]

[0000936395-14-000051:notes:198]
[same as prior period, unchanged from 0000936395-14-000040:notes:192]

[0000936395-14-000051:notes:199]
[same as prior period, unchanged from 0000936395-14-000040:notes:193]

[0000936395-14-000051:notes:200]
[same as prior period, unchanged from 0000936395-14-000040:notes:194]

[0000936395-14-000051:notes:201]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and term loan, see Note 13 below.

[0000936395-14-000051:notes:202]
[same as prior period, unchanged from 0000936395-14-000040:notes:196]

[0000936395-14-000051:notes:203]
[same as prior period, unchanged from 0000936395-14-000040:notes:197]

[0000936395-14-000051:notes:204]
[same as prior period, unchanged from 0000936395-14-000040:notes:198]

[0000936395-14-000051:notes:205]
[same as prior period, unchanged from 0000936395-14-000040:notes:199]

[0000936395-14-000051:notes:206]
[same as prior period, unchanged from 0000936395-14-000040:notes:200]

[0000936395-14-000051:notes:207]
[same as prior period, unchanged from 0000936395-14-000040:notes:206]

[0000936395-14-000051:notes:208]
[same as prior period, unchanged from 0000936395-14-000040:notes:207]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-14-000051:notes:209]
[same as prior period, unchanged from 0000936395-14-000040:notes:208]

[0000936395-14-000051:notes:210]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the related debt. Amortization of debt issuance costs related to our convertible notes payable, term loan (described in Note 13 below) and the Credit Facility (described in Note 14 below), which is included in interest expense, was $4.2 million and $3.6 million during the first nine months of fiscal 2013 and fiscal 2014, respectively.


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-14-000051:notes:211]
ABL CREDIT FACILITY

[0000936395-14-000051:notes:212]
During fiscal 2012, Ciena and certain of its subsidiaries entered into a senior secured asset-based revolving credit facility (the “ABL Credit Facility”). On July 15, 2014, Ciena amended the ABL Credit Facility to, among other things:

[0000936395-14-000051:notes:213]
| • | increase the total commitment from $150 million to $200 million; |

[0000936395-14-000051:notes:214]
| • | extend the maturity date from August 13, 2015 to December 31, 2016, and eliminate the maturity date acceleration to December 15, 2014 in the event that any of Ciena’s 4.00% senior convertible notes due March 15, 2015 are then outstanding; |

[0000936395-14-000051:notes:215]
| • | reduce the minimum aggregate amount of unrestricted cash and cash equivalents that Ciena is required to maintain at all times from $200 million to $150 million; |

[0000936395-14-000051:notes:216]
| • | reduce the interest rate on borrowings from LIBOR plus an applicable margin ranging from 200 basis points to 250 basis points, to an applicable margin ranging from 150 basis points to 200 basis points, with the actual margin based upon Ciena's utilization of the ABL Credit Facility; and |

[0000936395-14-000051:notes:217]
| • | amend the borrowing base to include, among other items, up to $50 million in eligible cash. |

[0000936395-14-000051:notes:218]
Ciena also amended the terms of the existing security and pledge agreements to provide the lenders with second-priority security interests in the Term Loan Priority Collateral, in addition to its existing first-priority security interests in current assets, consisting principally of accounts receivable, inventory, cash, and deposit and securities accounts (the "ABL Priority Collateral"). Except as amended, the remaining terms of the ABL Credit Facility, and related security and pledge agreements, remain in full force and effect.

[0000936395-14-000051:notes:219]
Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of July 31, 2014, letters of credit totaling $56.0 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2014.


## cien:ConvertibleNotesPayableTextBlock

[0000936395-14-000051:notes:220]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-14-000051:notes:221]
Term Loan

[0000936395-14-000051:notes:222]
On July 15, 2014, Ciena entered into a Credit Agreement (the “Term Loan Credit Agreement”) which provides for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”). Ciena received proceeds from the Term Loan, net of original issue discount and debt issuance costs, of approximately $246 million.

[0000936395-14-000051:notes:223]
The Term Loan bears interest at a rate equal to LIBOR (subject to a floor of 0.75%) plus an applicable margin of 3.00% and matures on July 15, 2019. The Term Loan Credit Agreement requires Ciena to make quarterly installment payments in aggregate amounts equal to 0.25% of the original principal amount of the Term Loan, with the balance of the Term Loan payable at maturity. The Term Loan Credit Agreement requires mandatory prepayments on the occurrence of certain customary events and, when the total secured net leverage ratio (as defined in the Term Loan Credit Agreement) is in excess of 2.50 to 1.00, the Term Loan Credit Agreement requires a mandatory prepayment of 50% of excess annual cash flow (as defined in the Term Loan Credit Agreement).

[0000936395-14-000051:notes:224]
The Term Loan Credit Agreement contains customary covenants that limit, absent lender approval, the ability of Ciena to, among other things, incur additional debt, create liens and encumbrances, pay cash dividends, enter into certain acquisition transactions or transactions with affiliates, merge, dissolve, repay certain indebtedness, change the nature of Ciena’s business, make investments or dispose of assets.

[0000936395-14-000051:notes:225]
The Term Loan Credit Agreement contains customary events of default including, among other things, failure to pay obligations when due, initiation of bankruptcy or insolvency proceedings, defaults on certain other indebtedness, change of control, incurrence of certain material judgments, violation of affirmative and negative covenants, and breaches of representations and warranties set forth in the Term Loan Credit Agreement. Upon an event of default, the administrative agent may, subject to various customary cure rights, require the immediate payment of all amounts outstanding and foreclose on collateral.

[0000936395-14-000051:notes:226]
In connection with Ciena entering into the Term Loan Credit Agreement, Ciena and certain of its subsidiaries entered into a guaranty, a security agreement and a pledge agreement, each on customary terms. The Term Loan is secured by (i) second-priority security interests in the ABL Priority Collateral (as defined in Note 14 below), and (ii) first-priority security interests in substantially all other tangible and intangible assets including equipment, intercompany notes, intellectual property and material owned real property (the "Term Loan Priority Collateral").

[0000936395-14-000051:notes:227]
Convertible Notes


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-14-000051:notes:228]
[same as prior period, unchanged from 0000936395-14-000040:notes:213]

[0000936395-14-000051:notes:229]
Depreciation of product demonstration equipment was $5.5 million and $6.7 million for the first nine months of fiscal 2013 and 2014, respectively.
