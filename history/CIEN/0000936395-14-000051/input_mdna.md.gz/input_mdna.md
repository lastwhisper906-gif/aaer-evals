# CIEN MD&A — 0000936395-14-000051


## mdna

[0000936395-14-000051:mdna:1]
[same as prior period, unchanged from 0000936395-14-000040:mdna:1]

[0000936395-14-000051:mdna:2]
[same as prior period, unchanged from 0000936395-14-000040:mdna:2]

[0000936395-14-000051:mdna:3]
[same as prior period, unchanged from 0000936395-14-000040:mdna:3]

[0000936395-14-000051:mdna:4]
[same as prior period, unchanged from 0000936395-14-000040:mdna:4]

[0000936395-14-000051:mdna:5]
Our Converged Packet Optical, Packet Networking, Optical Transport and Software products are used, individually or as part of an integrated, programmable solution, in networks operated by communications service providers, cable operators, governments, enterprises, research and education institutions, content service providers and other network operators across the globe. Our products allow network operators to scale capacity, increase transmission speeds, allocate network traffic and deliver services to end users. Our network solutions also include an integrated software suite that provides network and service management capabilities that unify our product portfolio, facilitating automation and software-defined programmability to enable efficient service delivery. To complement our product portfolio, we offer a broad range of Network Transformation Solutions and related support services that help our customers design, optimize, deploy, manage and maintain their networks.

[0000936395-14-000051:mdna:6]
We believe that the close, collaborative partnership with customers enabled by our engagement model and services offering is an important component of our network specialist approach and a significant differentiator for Ciena with our customers.

[0000936395-14-000051:mdna:7]
[same as prior period, unchanged from 0000936395-14-000040:mdna:6]

[0000936395-14-000051:mdna:8]
Our OPn Architecture is designed to meet these challenges by providing increased scalability and programmability, as well as network-level software applications to control and configure the network dynamically. Through this network approach, we seek to enable high-capacity, configurable infrastructures that can adapt to the changing needs of end-users and the applications that they require, while providing flexible interfaces for the integration of computing, storage and network resources. By increasing network flexibility for service delivery, reducing required network elements and enabling increased scale at reduced cost, our solutions optimize networks. At the same time, our approach facilitates introduction of new service offerings, creating business and operational value for our customers. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in “Strategy” below.

[0000936395-14-000051:mdna:9]
Our quarterly reports on Form 10-Q, annual reports on Form 10-K, and current reports on Form 8-K filed with the SEC are available through the SEC's website at www.sec.gov or free of charge on our website as soon as reasonably practicable after we file these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the "Investors" section of our website at www.ciena.com. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-14-000051:mdna:10]
AT&T Domain 2.0

[0000936395-14-000051:mdna:11]
In September 2014, we announced that AT&T had selected Ciena to participate in its Domain 2.0 supplier program. The Domain 2.0 initiative is the next generation of AT&T’s Supplier Domain Program, intended to enable AT&T to quickly transition to next-generation, cloud-based network architectures that embrace Network Function Virtualization (NFV) and Software Defined Networks (SDN), and accelerate AT&T’s time-to-market with new products and services. Our commercial arrangement relating to this opportunity includes certain commercial concessions that we expect to have a significant, short-term adverse impact on our revenue and gross margin. We expect these concessions primarily to affect our fourth quarter of fiscal 2014, with a proportionately lesser impact on our first quarter of fiscal 2015, and thereafter having a less significant impact on our quarterly results. We believe that this selection represents a significant achievement for Ciena, that AT&T's network objectives in this program align well with our OPn Architecture, and that this program potentially expands our addressable market with this key customer.

[0000936395-14-000051:mdna:12]
Recent Product Announcements

[0000936395-14-000051:mdna:13]
In June 2014, we announced the launch of our 8700 Packetwave platform, a multi-terabit packet switching platform for high-density metro networks. The 8700 combines Ethernet switching and optical transport to help network operators deliver on-demand, cloud-based services with improved economics. In July 2014, we also introduced our Agility software portfolio, which includes a multilayer software-defined networking (SDN) controller and new software applications for enabling on-demand, high-bandwidth wide area network (WAN) services delivered in an open network ecosystem. With Agility, our customers can better monetize cloud-based services and virtual network functions created in a traditional or an SDN environment. Our 8700 product will be included within our Packet Networking segment and our Agility software portfolio will be included within our Software and Services segment.

[0000936395-14-000051:mdna:14]
Market Opportunity

[0000936395-14-000051:mdna:15]
We believe that the shift that is underway in network architectures to next-generation, converged infrastructures represents a significant, long-term opportunity for Ciena. We believe that certain market dynamics, including the proliferation of devices running mobile web applications, the prevalence of video applications, the increase in machine-to-machine connections, and the shift of enterprise and consumer applications to cloud-based or virtualized network environments, are representative of the magnitude of changing demands being placed upon network architectures. At the same time, bandwidth requirements and the

[0000936395-14-000051:mdna:16]
use and dependence by consumers and enterprises upon a  variety of communications applications, services and devices continues to grow. We expect that these drivers will require existing and emerging network operators to invest in converged next-generation network infrastructures that are more automated, open and software programmable.

[0000936395-14-000051:mdna:17]
This year we have seen certain service provider customers increase efforts to constrain capital expenditure budgets, resulting in a reduction in aggregate spending levels and adversely impacting certain segments of our market, including in the U.S. Notwithstanding these market dynamics. our specialist strategy to focus on certain higher growth and higher value segments of the network infrastructure market, combined with efforts to expand our addressable market and diversify our business, have enabled us to continue to grow revenue and take market share in fiscal 2014 to date.

[0000936395-14-000051:mdna:18]
[same as prior period, unchanged from 0000936395-14-000040:mdna:21]

[0000936395-14-000051:mdna:19]
We continue to encounter a highly competitive marketplace. Our sales of Converged Packet Optical solutions reflect an intense and fragmented competitive environment, as we and our competitors introduce and enhance new, high-capacity, high-speed network solutions. Our sales of Packet Networking solutions, including our new 8700 Packetwave Platform, also face a competitive marketplace as we seek to promote the benefits of our OPn Architecture, as compared to alternative network approaches, and to secure network operator adoption of our solutions. We expect the current competitive landscape to remain challenging and dynamic. As networking technologies become more software-driven, and network features and layers continue to converge, our competitive landscape continues to broaden beyond traditional competitors. As a result, we are competing with, and expect to compete increasingly with, additional vendors focused on IP routing, information technology and software.

[0000936395-14-000051:mdna:20]
Within these competitive dynamics, maintaining incumbency with key customers domestically and abroad, and securing new opportunities with network operators often requires that we agree to aggressive pricing, significant commercial concessions or other unfavorable commercial terms. These terms can adversely affect our quarterly results of operations and contribute to fluctuations in our results. These terms can also elongate our revenue recognition or cash collection cycles, add startup costs to initial sales or deployment of our solutions, require financial commitments or performance bonds that place cash resources at risk, and include onerous contractual commitments that place a disproportionate allocation of risk upon us.

[0000936395-14-000051:mdna:21]
Strategy

[0000936395-14-000051:mdna:22]
Our corporate strategy to capitalize on these market and competitive dynamics, promote operational efficiency and drive profitable growth of our business includes the following initiatives:

[0000936395-14-000051:mdna:23]
Promotion of our OPn Architecture for Next-Generation Networks. The services and applications running on communications networks require that more of the traffic on these networks be packet-oriented. The traditional approach to this problem has been to add IP routing capability at many points of intersection in the network. As capacity needs grow, this approach becomes unnecessarily complex and costly. We reduce the cost and complexity of growing networks with a programmable infrastructure that brings together the reliability and capacity of optical networking with the flexibility and economics of packet networking technologies. Combining these attributes with network level applications creates an approach we call our OPn Architecture. Our OPn Architecture leverages the convergence of optical and packet networking to enable network scale, applies advanced control plane software for network programmability, and enables cloud-level applications to integrate and optimize network resources — along with computing and storage resources — in a virtualized environment. The software-driven aspects of this architecture become increasingly important as network operators increasingly seek to leverage an open ecosystem of virtualized resources to enable the real-time analytics and network agility required for on-demand, next-generation network architectures. Our OPn Architecture offers network operators scalability, programmability, flexibility and cost-effectiveness, and we see opportunities in offering a portfolio of solutions that facilitate the transition to next-generation networks that are optimized to create new services rapidly and to meet end user demands.

[0000936395-14-000051:mdna:24]
Alignment of Research and Development Investment with Growth Opportunities. We seek to ensure that our product development initiatives are closely aligned with changing dynamics in our markets, network operator and end user demands, and growth opportunities for Ciena. We are investing in our OPn Architecture with current development efforts focused on expanding packet capabilities in our Packet Networking and Converged Packet Optical products for metro and service aggregation applications. We are also focused on optimizing our existing core networking solutions for application in metro networks. Our research and development efforts seek to extend and converge our existing technologies, including our WaveLogic coherent optical processor for 40G and 100G optical transport, and to introduce 400G and greater transmission speeds. In the packet area, we are increasing the scale and capability of our packet offerings and integrating standards-based open control interfaces. In the software area, we are enhancing our network management and planning applications. We are also focusing on initiatives to increase software-defined programmability and control of networks, including through our joint

[0000936395-14-000051:mdna:25]
development initiative with Ericsson, and working to develop network-level software applications that configure networks and support new service introduction.

[0000936395-14-000051:mdna:26]
[same as prior period, unchanged from 0000936395-14-000040:mdna:15]

[0000936395-14-000051:mdna:27]
Coverage. Our coverage model is focused on selling into key customer segments, penetrating high-growth geographic markets and addressing additional network applications with our solutions. To complement our existing service provider customers, we continue to pursue opportunities to diversify our customer base into key market segments. We are expanding our sales efforts to capture opportunities arising from enterprise migration to cloud-based services, and promoting our reputation with government agencies and research and educational institutions as a trusted network equipment supplier. We are also focused on further penetrating significant Web 2.0 players, including Internet content providers and other emerging network operators, who are changing the ways in which information is accessed and shared. To expand the geographic reach of our direct sales resources, and to broaden the role our solutions play in communications networks, we have pursued strategic channel opportunities enabling sales through third parties, including service providers, systems integrators and value-added resellers. Through our packet-optical distribution relationship with Ericsson, we are seeking to expand our geographic reach as well as the applications for our products. Our direct and indirect selling efforts are focused on the sale of our solutions into additional applications, including metro aggregation and submarine networks, and in support of cloud-based services, business Ethernet services and mobile backhaul.

[0000936395-14-000051:mdna:28]
Engagement. Our strategy is to leverage our close, collaborative relationships with customers in the design, development, implementation and support of their networks and to promote a close alignment of our solutions with customer network priorities. We believe that this engagement model is a key differentiator for our business and provides us with unique insight into the business and network needs of our customers. We seek to expand our Network Transformation Solutions offering to address the network modernization and service delivery demands of our customers, as well as their desire to derive additional value from their network infrastructures. We believe this services-oriented solutions offering shifts our value proposition beyond the sale of our next-generation communications networking equipment and allows us to play a key role in the design and evolution of our customers' networks to support their strategic business objectives. By understanding our customers’ infrastructure and business needs, and the evolving markets in which they compete, we believe our engagement approach creates additional business and operational value for our customers and enables us to go to market with a competitive solutions offering that is well aligned with customer business needs.

[0000936395-14-000051:mdna:29]
Business optimization to yield operating leverage. We are actively pursuing the transformation and redesign of certain business processes, systems, and resources. These initiatives include additional investments, re-engineering of enterprise systems and automation of certain key business processes. In addition, we are focused on optimizing our supply chain, including efforts to reduce our material and overhead costs in an effort to increase efficiency and reduce the cost to produce our product solutions. These initiatives include portfolio and process optimization, reducing our fulfillment, shipping and logistics expense, and identifying ways to drive improved efficiencies in the design and development of our solutions. We seek to leverage these opportunities to promote the profitable growth of our business and drive additional operating leverage.

[0000936395-14-000051:mdna:30]
Term Loan and Asset-Based Credit Facilities

[0000936395-14-000051:mdna:31]
On July 15, 2014, we entered into a credit agreement that provides for senior secured term loans in an aggregate principal amount of $250 million (the "Term Loan"). We expect to use the approximately $246 million in net proceeds to repay, in whole or part, the outstanding principal amount owing under our 4.00% senior convertible notes due March 15, 2015 in the event the holders thereof do not elect to convert such notes into common stock prior to maturity. In the event the holders of such notes elect to convert their notes into common stock upon or prior to maturity, we may elect to repay the Term Loan, in whole or in part, or may utilize the net proceeds for other general corporate purposes, including the repayment or refinancing of other existing indebtedness. See Note 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for a summary of the material terms and conditions of the Term Loan and the related security documents.

[0000936395-14-000051:mdna:32]
On July 15, 2014, we also amended the terms of our existing senior secured asset-based revolving credit facility to, among other things, increase the total commitment under the ABL Credit Facility from $150 million to $200 million and extend the maturity date from August 13, 2015 to December 31, 2016.  See Note 14 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for a summary of the material terms and conditions of the amendment to this credit agreement and the related security documents.

[0000936395-14-000051:mdna:33]
[same as prior period, unchanged from 0000936395-14-000040:mdna:24]

[0000936395-14-000051:mdna:34]
Revenue for the third quarter of fiscal 2014 was $603.6 million, representing a sequential increase of 7.8% from $560.1 million in the second quarter of fiscal 2014. Revenue-related details reflecting sequential changes from the second quarter of fiscal 2014 include:

[0000936395-14-000051:mdna:35]
| • | Product revenue for the third quarter of fiscal 2014 increased by $35.1 million, reflecting increased sales of $25.2 million in Converged Packet Optical, $5.6 million in software, $2.9 million in Packet Networking and $1.4 million in Optical Transport. |

[0000936395-14-000051:mdna:36]
| • | Service revenue for the third quarter of fiscal 2014 increased by $8.4 million. |

[0000936395-14-000051:mdna:37]
| • | Revenue from the United States for the third quarter of fiscal 2014 was $368.1 million, an increase from $324.0 million in the second quarter of fiscal 2014. |

[0000936395-14-000051:mdna:38]
| • | International revenue for the third quarter of fiscal 2014 was $235.5 million, a decrease from $236.1 million in the second quarter of fiscal 2014. |

[0000936395-14-000051:mdna:39]
| • | As a percentage of revenue, international revenue was 39.0% during the third quarter of fiscal 2014, a decrease from 42.2% during the second quarter of fiscal 2014. |

[0000936395-14-000051:mdna:40]
| • | For the third quarter of fiscal 2014, one customer accounted for 21.6% of total revenue. This compares to one customer that accounted for 21.5% of total revenue in the second quarter of fiscal 2014. |

[0000936395-14-000051:mdna:41]
Gross margin for the third quarter of fiscal 2014 was 43.7%, an increase from 42.4% in the second quarter of fiscal 2014.

[0000936395-14-000051:mdna:42]
Operating expense was $227.0 million for the third quarter of fiscal 2014, a decrease from $230.5 million in the second quarter of fiscal 2014. Third quarter fiscal 2014 operating expense primarily reflects decreases of $5.8 million in research and development expense and $1.7 million in sales and marketing expense. These decreases were partially offset by an increase of $4.4 million in general and administrative expense.

[0000936395-14-000051:mdna:43]
Reflecting the improvements in revenue and gross margin above, income from operations for the third quarter of fiscal 2014 was $37.0 million, compared to income from operations of $7.2 million during the second quarter of fiscal 2014. Our net income for the third quarter of fiscal 2014 was $16.2 million, or $0.15 per diluted common share. This compares to a net loss of $10.2 million or $0.10 per diluted common share, for the second quarter of fiscal 2014.

[0000936395-14-000051:mdna:44]
We generated cash from operations of $51.1 million during the third quarter of fiscal 2014, consisting of $80.9 million in cash provided by net income adjusted for non-cash charges, offset by a $29.8 million use of cash related to changes in working capital. This compares with $2.0 million of cash generated from operations during the second quarter of fiscal 2014, consisting of $49.5 million in cash provided by net losses adjusted for non-cash charges offset by a $47.5 million use of cash related to changes in working capital.

[0000936395-14-000051:mdna:45]
As of July 31, 2014, we had $532.9 million in cash and cash equivalents, $120.3 million of short-term investments in U.S. treasury securities and commercial paper, and $65.0 million of long-term investments in U.S. treasury securities. This compares to $378.2 million in cash and cash equivalents, $100.0 million of short-term investments in U.S. treasury securities and $15.0 million of long-term investments in U.S. treasury securities, at July 31, 2013, and $346.5 million in cash and cash equivalents, $125.0 million of short-term investments in U.S. treasury securities and commercial paper, and $15.0 million of long-term investments in U.S. treasury securities at October 31, 2013.

[0000936395-14-000051:mdna:46]
As of July 31, 2014, we had 5,136 employees, an increase from 4,754 at October 31, 2013 and an increase from 4,680 at July 31, 2013.

[0000936395-14-000051:mdna:47]
[same as prior period, unchanged from 0000936395-14-000040:mdna:38]

[0000936395-14-000051:mdna:48]
[same as prior period, unchanged from 0000936395-14-000040:mdna:39]

[0000936395-14-000051:mdna:49]
[same as prior period, unchanged from 0000936395-14-000040:mdna:40]

[0000936395-14-000051:mdna:50]
| • | Converged Packet Optical — includes networking solutions optimized for the convergence of coherent optical transport, OTN switching and packet switching. These platforms enable automated packet-optical infrastructures that create and efficiently allocate high-capacity bandwidth for the delivery of a wide variety of enterprise and consumer-oriented network services. Products in this segment include the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also |

[0000936395-14-000051:mdna:51]
include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. These products include multiservice, multi-protocol switching systems that consolidate the functionality of an add/drop multiplexer, digital cross-connect and packet switch into a single, high-capacity intelligent switching system. These products address both the core and metro segments of communications networks and support key managed services, Ethernet/TDM Private Line, Triple Play and IP services. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations.

[0000936395-14-000051:mdna:52]
| • | Packet Networking — principally includes Ciena's 3000 family of service delivery switches and service aggregation switches, the 5000 series of service aggregation switches. This segment also includes Ciena’s new 8700 Packetwave Platform, a multi-terabit packet switching platform for high-density metro networks. The 8700 combines Ethernet switching and optical transport to help network operators deliver on-demand, cloud-based services with improved economics. In addition, this segment includes Ciena's Ethernet packet configuration for the 5410 Service Aggregation Switch. These products support the access and aggregation tiers of communications networks and have principally been deployed to support wireless backhaul infrastructures and business data services. Employing sophisticated, carrier-grade Ethernet switching technology, these products deliver quality of service capabilities, virtual local area networking and switching functions, and carrier-grade operations, administration, and maintenance features. This segment includes stand-alone broadband products that transition voice networks to support Internet-based (IP) telephony, video services and DSL. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-14-000051:mdna:53]
[same as prior period, unchanged from 0000936395-14-000040:mdna:44]

[0000936395-14-000051:mdna:54]
| • | Software and Services — includes Ciena's network software suite, including the Agility software portfolio which includes a multilayer software-defined networking (SDN) controller and new software applications for enabling on-demand, high-bandwidth wide area network (WAN) services delivered in an open network ecosystem. With Agility, our customers can better monetize cloud-based services and virtual network functions created in a traditional or an SDN environment. This segment also includes the OneControl Unified Management System. These software solutions can track individual services across multiple product suites, facilitating planned network maintenance, outage detection and identification of customers or services affected by network performance. In addition, this segment includes the ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and network level applications. This segment includes a broad range of consulting, network design and support services from Ciena's Network Transformation Solutions offering. This segment also includes installation and deployment, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-14-000051:mdna:55]
Quarter ended July 31, 2013 compared to the quarter ended July 31, 2014

[0000936395-14-000051:mdna:56]
[same as prior period, unchanged from 0000936395-14-000040:mdna:47]

[0000936395-14-000051:mdna:57]
[same as prior period, unchanged from 0000936395-14-000040:mdna:48]

[0000936395-14-000051:mdna:58]
33

[0000936395-14-000051:mdna:59]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 302,018 |  |  | 56.1 |  | $ | 382,031 |  |  | 63.3 |  | $ | 80,013 |  |  | 26.5 |  |
| Packet Networking | 61,631 |  |  | 11.4 |  | 69,464 |  |  | 11.5 |  | 7,833 |  |  | 12.7 |  |
| Optical Transport | 66,218 |  |  | 12.3 |  | 31,016 |  |  | 5.1 |  | (35,202 | ) |  | (53.2 | ) |
| Software and Services | 108,489 |  |  | 20.2 |  | 121,051 |  |  | 20.1 |  | 12,562 |  |  | 11.6 |  |
| Consolidated revenue | $ | 538,356 |  |  | 100.0 |  | $ | 603,562 |  |  | 100.0 |  | $ | 65,206 |  |  | 12.1 |  |

[0000936395-14-000051:mdna:60]
[same as prior period, unchanged from 0000936395-14-000040:mdna:50]

[0000936395-14-000051:mdna:61]
[same as prior period, unchanged from 0000936395-14-000040:mdna:51]

[0000936395-14-000051:mdna:62]
[same as prior period, unchanged from 0000936395-14-000040:mdna:52]

[0000936395-14-000051:mdna:63]
| • | Converged Packet Optical revenue increased, reflecting a $70.6 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. In addition, sales of our 5430 Reconfigurable Switching System increased by $19.5 million and sales of the OTN configuration for the 5410 Reconfigurable Switching System increased by $2.7 million. These increases were slightly offset by a decrease of $12.8 million in sales of our CoreDirector® Multiservice Optical Switches. The strong performance of this segment, particularly as compared to the expected declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-14-000051:mdna:64]
| • | Packet Networking revenue increased, reflecting a $10.6 million increase in sales of our 3000 and 5000 families of service delivery and aggregation switches. This increase was partially offset by a $2.2 million decrease in our older stand-alone broadband products. Segment revenue benefited from the expansion of Ethernet business services by our North American service provider customers and sales of service delivery and aggregation products in support of their packet-related network initiatives. |

[0000936395-14-000051:mdna:65]
| • | Optical Transport revenue decreased, reflecting a $16.0 million decrease of our 5100/5200 Advanced Services Platform, a $12.6 million decrease in sales of other stand-alone transport products and a $6.6 million decrease in sales of our 4200 Advanced Services Platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in revenue in recent years. We expect this trend to continue, reflecting network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-14-000051:mdna:66]
| • | Software and Services revenue increased, reflecting increases of $5.8 million in software revenue, $5.3 million in maintenance and support services revenue, and $2.2 million in network transformation consulting revenue. |

[0000936395-14-000051:mdna:67]
[same as prior period, unchanged from 0000936395-14-000040:mdna:58]

[0000936395-14-000051:mdna:68]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| United States | $ | 339,426 |  |  | 63.0 |  | $ | 368,056 |  |  | 61.0 |  | $ | 28,630 |  |  | 8.4 |
| International | 198,930 |  |  | 37.0 |  | 235,506 |  |  | 39.0 |  | 36,576 |  |  | 18.4 |
| Total | $ | 538,356 |  |  | 100.0 |  | $ | 603,562 |  |  | 100.0 |  | $ | 65,206 |  |  | 12.1 |

[0000936395-14-000051:mdna:69]
[same as prior period, unchanged from 0000936395-14-000040:mdna:60]

[0000936395-14-000051:mdna:70]
[same as prior period, unchanged from 0000936395-14-000040:mdna:61]

[0000936395-14-000051:mdna:71]
[same as prior period, unchanged from 0000936395-14-000040:mdna:62]

[0000936395-14-000051:mdna:72]
| • | United States revenue reflects increases of $33.8 million in Converged Packet Optical sales, $8.7 million in Packet Networking sales and $8.2 million in Software and Services revenue. These increases were partially offset by a $22.0 million decrease in Optical Transport sales. Increased revenues reflect adoption by network operators in the United States of converged network architectures that align well with our OPn Architecture and solutions offering. |

[0000936395-14-000051:mdna:73]
| • | International revenue reflects increases of $46.3 million in Converged Packet Optical sales and $4.4 million in Software and Services revenue, partially offset by decreases of $13.2 million in Optical Transport sales and $1.0 million in Packet Networking sales. |

[0000936395-14-000051:mdna:74]
While we have taken steps to expand our addressable market and diversify our business and customer base, a sizable portion of our revenue continues to come from sales to a small number of service providers. As a result, our financial results are significantly affected by, and can fluctuate depending upon, spending levels of our key service provider customers, changes in their network and purchasing strategies, and the business opportunities and challenges encountered by our largest service provider customers. During the third quarter of fiscal 2014, one customer accounted for greater than 10% of total revenue and represented 21.6% of total revenue. This compares to the third quarter of fiscal 2013, when two such customers together accounted for 31.8% of total revenue.

[0000936395-14-000051:mdna:75]
[same as prior period, unchanged from 0000936395-14-000040:mdna:66]

[0000936395-14-000051:mdna:76]
[same as prior period, unchanged from 0000936395-14-000040:mdna:67]

[0000936395-14-000051:mdna:77]
[same as prior period, unchanged from 0000936395-14-000040:mdna:68]

[0000936395-14-000051:mdna:78]
While we have experienced recent periods in which our gross profit as a percentage of revenue, or “gross margin,” has been more consistent, it remains susceptible to fluctuation in any quarter due to a number of factors impacting our business. Gross margin can be adversely affected by the level of pricing pressure and competition that we encounter in the market, particularly in our efforts to compete to obtain business with new customers or to maintain business with existing customers. In an effort to penetrate additional markets, secure new business or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders, particularly associated with initial sales or deployment projects. Similarly, to maintain incumbency with key customers for existing and future business opportunities, we may be required to offer discounted pricing, provide commitments with respect to future technology development, or offer less favorable commercial terms as compared to our historical business arrangements with these customers. Some of our large existing customers are pursuing purchasing strategies or adopting procurement approaches intended to drive further pricing reductions, seek additional commercial concessions and consolidate their number of direct suppliers of networking technology. The impact of significant new wins or commercial concessions to significant customers can adversely affect our gross margin during the relevant periods and result in fluctuation in our results of operations.

[0000936395-14-000051:mdna:79]
[same as prior period, unchanged from 0000936395-14-000040:mdna:71]

[0000936395-14-000051:mdna:80]
[same as prior period, unchanged from 0000936395-14-000040:mdna:72]

[0000936395-14-000051:mdna:81]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 538,356 |  |  | 100.0 |  | $ | 603,562 |  |  | 100.0 |  | $ | 65,206 |  |  | 12.1 |
| Total cost of goods sold | 310,135 |  |  | 57.6 |  | 339,589 |  |  | 56.3 |  | 29,454 |  |  | 9.5 |
| Gross profit | $ | 228,221 |  |  | 42.4 |  | $ | 263,973 |  |  | 43.7 |  | $ | 35,752 |  |  | 15.7 |

[0000936395-14-000051:mdna:82]
[same as prior period, unchanged from 0000936395-14-000040:mdna:74]

[0000936395-14-000051:mdna:83]
[same as prior period, unchanged from 0000936395-14-000040:mdna:75]

[0000936395-14-000051:mdna:84]
[same as prior period, unchanged from 0000936395-14-000040:mdna:76]

[0000936395-14-000051:mdna:85]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 437,442 |  |  | 100.0 |  | $ | 495,889 |  |  | 100.0 |  | $ | 58,447 |  |  | 13.4 |
| Product cost of goods sold | 247,768 |  |  | 56.6 |  | 275,003 |  |  | 55.5 |  | 27,235 |  |  | 11.0 |
| Product gross profit | $ | 189,674 |  |  | 43.4 |  | $ | 220,886 |  |  | 44.5 |  | $ | 31,212 |  |  | 16.5 |

[0000936395-14-000051:mdna:86]
[same as prior period, unchanged from 0000936395-14-000040:mdna:78]

[0000936395-14-000051:mdna:87]
[same as prior period, unchanged from 0000936395-14-000040:mdna:79]

[0000936395-14-000051:mdna:88]
[same as prior period, unchanged from 0000936395-14-000040:mdna:80]

[0000936395-14-000051:mdna:89]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 100,914 |  |  | 100.0 |  | $ | 107,673 |  |  | 100.0 |  | $ | 6,759 |  |  | 6.7 |
| Service cost of goods sold | 62,367 |  |  | 61.8 |  | 64,586 |  |  | 60.0 |  | 2,219 |  |  | 3.6 |
| Service gross profit | $ | 38,547 |  |  | 38.2 |  | $ | 43,087 |  |  | 40.0 |  | $ | 4,540 |  |  | 11.8 |

[0000936395-14-000051:mdna:90]
[same as prior period, unchanged from 0000936395-14-000040:mdna:82]

[0000936395-14-000051:mdna:91]
[same as prior period, unchanged from 0000936395-14-000040:mdna:83]

[0000936395-14-000051:mdna:92]
[same as prior period, unchanged from 0000936395-14-000040:mdna:84]

[0000936395-14-000051:mdna:93]
[same as prior period, unchanged from 0000936395-14-000040:mdna:85]

[0000936395-14-000051:mdna:94]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to improved mix of higher-margin packet platforms with software content within our Packet Networking and Converged Packet Optical segments, and greater leverage from efforts to streamline and optimize our supply chain activities. |

[0000936395-14-000051:mdna:95]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to increased maintenance and consulting services revenues, including our Network Transformation Solutions offerings, and increased margin due to improved efficiencies for managed spares projects. |

[0000936395-14-000051:mdna:96]
[same as prior period, unchanged from 0000936395-14-000040:mdna:88]

[0000936395-14-000051:mdna:97]
[same as prior period, unchanged from 0000936395-14-000040:mdna:89]

[0000936395-14-000051:mdna:98]
[same as prior period, unchanged from 0000936395-14-000040:mdna:90]

[0000936395-14-000051:mdna:99]
[same as prior period, unchanged from 0000936395-14-000040:mdna:91]

[0000936395-14-000051:mdna:100]
[same as prior period, unchanged from 0000936395-14-000040:mdna:92]

[0000936395-14-000051:mdna:101]
[same as prior period, unchanged from 0000936395-14-000040:mdna:93]

[0000936395-14-000051:mdna:102]
[same as prior period, unchanged from 0000936395-14-000040:mdna:94]

[0000936395-14-000051:mdna:103]
[same as prior period, unchanged from 0000936395-14-000040:mdna:95]

[0000936395-14-000051:mdna:104]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 93,069 |  |  | 17.3 |  | $ | 97,685 |  |  | 16.2 |  | $ | 4,616 |  |  | 5.0 |  |
| Selling and marketing | 75,613 |  |  | 14.0 |  | 81,919 |  |  | 13.6 |  | 6,306 |  |  | 8.3 |  |
| General and administrative | 32,066 |  |  | 6.0 |  | 36,285 |  |  | 6.0 |  | 4,219 |  |  | 13.2 |  |
| Amortization of intangible assets | 12,440 |  |  | 2.3 |  | 11,019 |  |  | 1.8 |  | (1,421 | ) |  | (11.4 | ) |
| Restructuring costs | 202 |  |  | — |  | 63 |  |  | — |  | (139 | ) |  | (68.8 | ) |
| Total operating expenses | $ | 213,390 |  |  | 39.6 |  | $ | 226,971 |  |  | 37.6 |  | $ | 13,581 |  |  | 6.4 |  |

[0000936395-14-000051:mdna:105]
[same as prior period, unchanged from 0000936395-14-000040:mdna:97]

[0000936395-14-000051:mdna:106]
[same as prior period, unchanged from 0000936395-14-000040:mdna:98]

[0000936395-14-000051:mdna:107]
[same as prior period, unchanged from 0000936395-14-000040:mdna:99]

[0000936395-14-000051:mdna:108]
| • | Research and development expense benefited by $2.8 million as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Canadian Dollar. The $4.6 million increase in research and development expense consisted of a $2.4 million increase in employee compensation and related costs, a $1.0 million increase in prototype expense and a $1.0 million increase in facilities and information technology costs. Our prioritization of expense reflects the research and development strategy described in "Strategy" above. |

[0000936395-14-000051:mdna:109]
| • | Selling and marketing expense increased by $6.3 million, primarily reflecting increases of $4.2 million in employee compensation and related costs and $1.4 million increase in freight and logistics costs for demonstration equipment. |

[0000936395-14-000051:mdna:110]
| • | General and administrative expense increased by $4.2 million, reflecting increases of $2.6 million in legal fees associated with patent litigation costs, $0.8 million in employee compensation and related costs and $0.8 million in provisions for doubtful accounts receivable. |

[0000936395-14-000051:mdna:111]
[same as prior period, unchanged from 0000936395-14-000040:mdna:103]

[0000936395-14-000051:mdna:112]
[same as prior period, unchanged from 0000936395-14-000040:mdna:161]

[0000936395-14-000051:mdna:113]
[same as prior period, unchanged from 0000936395-14-000040:mdna:107]

[0000936395-14-000051:mdna:114]
[same as prior period, unchanged from 0000936395-14-000040:mdna:108]

[0000936395-14-000051:mdna:115]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (3,167 | ) |  | (0.6 | ) |  | $ | (6,328 | ) |  | (1.0 | ) |  | $ | (3,161 | ) |  | 99.8 |
| Interest expense | $ | 10,972 |  |  | 2.0 |  |  | $ | 11,508 |  |  | 1.9 |  |  | $ | 536 |  |  | 4.9 |
| Provision for income taxes | $ | 1,923 |  |  | 0.4 |  |  | $ | 3,006 |  |  | 0.5 |  |  | $ | 1,083 |  |  | 56.3 |

[0000936395-14-000051:mdna:116]
[same as prior period, unchanged from 0000936395-14-000040:mdna:110]

[0000936395-14-000051:mdna:117]
[same as prior period, unchanged from 0000936395-14-000040:mdna:111]

[0000936395-14-000051:mdna:118]
[same as prior period, unchanged from 0000936395-14-000040:mdna:112]

[0000936395-14-000051:mdna:119]
| • | Interest and other income (loss), net reflects a $2.5 million non-cash loss related to the change in fair value of the embedded redemption feature associated with our 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes"). |

[0000936395-14-000051:mdna:120]
[same as prior period, unchanged from 0000936395-14-000040:mdna:114]

[0000936395-14-000051:mdna:121]
[same as prior period, unchanged from 0000936395-14-000040:mdna:115]

[0000936395-14-000051:mdna:122]
Nine months ended July 31, 2013 compared to the nine months ended July 31, 2014

[0000936395-14-000051:mdna:123]
[same as prior period, unchanged from 0000936395-14-000040:mdna:117]

[0000936395-14-000051:mdna:124]
[same as prior period, unchanged from 0000936395-14-000040:mdna:118]

[0000936395-14-000051:mdna:125]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 836,303 |  |  | 55.8 |  | $ | 1,072,272 |  |  | 63.2 |  | $ | 235,969 |  |  | 28.2 |  |
| Packet Networking | 161,658 |  |  | 10.8 |  | 187,699 |  |  | 11.1 |  | 26,041 |  |  | 16.1 |  |
| Optical Transport | 181,186 |  |  | 12.1 |  | 100,729 |  |  | 5.9 |  | (80,457 | ) |  | (44.4 | ) |
| Software and Services | 320,014 |  |  | 21.3 |  | 336,626 |  |  | 19.8 |  | 16,612 |  |  | 5.2 |  |
| Consolidated revenue | $ | 1,499,161 |  |  | 100.0 |  | $ | 1,697,326 |  |  | 100.0 |  | $ | 198,165 |  |  | 13.2 |  |

[0000936395-14-000051:mdna:126]
[same as prior period, unchanged from 0000936395-14-000040:mdna:120]

[0000936395-14-000051:mdna:127]
[same as prior period, unchanged from 0000936395-14-000040:mdna:121]

[0000936395-14-000051:mdna:128]
[same as prior period, unchanged from 0000936395-14-000040:mdna:122]

[0000936395-14-000051:mdna:129]
| • | Converged Packet Optical revenue increased significantly, reflecting a $203.2 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. In addition, sales of our 5430 reconfigurable switching system and the OTN configuration for the 5410 Reconfigurable Switching System increased by $43.6 million and $6.4 million respectively. These increases were partially offset by a $17.2 million decrease in sales of our CoreDirector® Multiservice Optical Switches. The strong performance of this segment, particularly as compared to the expected declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-14-000051:mdna:130]
| • | Packet Networking revenue increased, reflecting an increase of $36.1 million in sales of our 3000 and 5000 families of service delivery and aggregation switches. This increase was partially offset by decreases of $3.3 million in sales of our older, stand-alone broadband products and $6.4 million in sales of our 5410 Service Aggregation Switch. Segment revenue benefited from the expansion of Ethernet business services by our North American service provider customers and sales of service delivery and aggregation products in support of their related network initiatives. |

[0000936395-14-000051:mdna:131]
| • | Optical Transport revenue decreased, reflecting sales decreases of $33.4 million in other stand-alone transport products, $26.0 million of 5100/5200 Advanced Services Platform and $21.1 million in our 4200 Advanced Services Platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-14-000051:mdna:132]
| • | Software and Services revenue increased, reflecting increases of $8.1 million in maintenance and support services revenue, $4.4 million in software sales, $2.1 million in networking transformation consulting revenue and $2.0 million for installation and deployment services revenue. |

[0000936395-14-000051:mdna:133]
[same as prior period, unchanged from 0000936395-14-000040:mdna:127]

[0000936395-14-000051:mdna:134]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| United States | $ | 891,233 |  |  | 59.4 |  | $ | 1,009,433 |  |  | 59.5 |  | $ | 118,200 |  |  | 13.3 |
| International | 607,928 |  |  | 40.6 |  | 687,893 |  |  | 40.5 |  | 79,965 |  |  | 13.2 |
| Total | $ | 1,499,161 |  |  | 100.0 |  | $ | 1,697,326 |  |  | 100.0 |  | $ | 198,165 |  |  | 13.2 |

[0000936395-14-000051:mdna:135]
[same as prior period, unchanged from 0000936395-14-000040:mdna:129]

[0000936395-14-000051:mdna:136]
[same as prior period, unchanged from 0000936395-14-000040:mdna:130]

[0000936395-14-000051:mdna:137]
[same as prior period, unchanged from 0000936395-14-000040:mdna:131]

[0000936395-14-000051:mdna:138]
| • | United States revenue reflects increases of $126.6 million in Converged Packet Optical sales, $26.6 million in Packet Networking sales and $17.7 million in Services and Software sales. In particular, during the first nine months of fiscal 2014, we benefited from the spending patterns and decisions of our largest service provider customers as they adopted converged, next generation network architectures that align well with our OPn Architecture and solutions offering. These increases were partially offset by a $52.7 million decrease in Optical Transport sales. |

[0000936395-14-000051:mdna:139]
| • | International revenue reflects an increase of $109.3 million in Converged Packet Optical sales. This increase was partially offset by decreases of $27.7 million in Optical Transport sales and $1.1 million in Software and Services revenue. |

[0000936395-14-000051:mdna:140]
[same as prior period, unchanged from 0000936395-14-000040:mdna:134]

[0000936395-14-000051:mdna:141]
[same as prior period, unchanged from 0000936395-14-000040:mdna:135]

[0000936395-14-000051:mdna:142]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 1,499,161 |  |  | 100.0 |  | $ | 1,697,326 |  |  | 100.0 |  | $ | 198,165 |  |  | 13.2 |
| Total cost of goods sold | 865,632 |  |  | 57.7 |  | 969,811 |  |  | 57.1 |  | 104,179 |  |  | 12.0 |
| Gross profit | $ | 633,529 |  |  | 42.3 |  | $ | 727,515 |  |  | 42.9 |  | $ | 93,986 |  |  | 14.8 |

[0000936395-14-000051:mdna:143]
[same as prior period, unchanged from 0000936395-14-000040:mdna:137]

[0000936395-14-000051:mdna:144]
[same as prior period, unchanged from 0000936395-14-000040:mdna:138]

[0000936395-14-000051:mdna:145]
[same as prior period, unchanged from 0000936395-14-000040:mdna:139]

[0000936395-14-000051:mdna:146]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 1,203,716 |  |  | 100.0 |  | $ | 1,389,651 |  |  | 100.0 |  | $ | 185,935 |  |  | 15.4 |
| Product cost of goods sold | 683,730 |  |  | 56.8 |  | 777,851 |  |  | 56.0 |  | 94,121 |  |  | 13.8 |
| Product gross profit | $ | 519,986 |  |  | 43.2 |  | $ | 611,800 |  |  | 44.0 |  | $ | 91,814 |  |  | 17.7 |

[0000936395-14-000051:mdna:147]
[same as prior period, unchanged from 0000936395-14-000040:mdna:141]

[0000936395-14-000051:mdna:148]
[same as prior period, unchanged from 0000936395-14-000040:mdna:142]

[0000936395-14-000051:mdna:149]
[same as prior period, unchanged from 0000936395-14-000040:mdna:143]

[0000936395-14-000051:mdna:150]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 295,445 |  |  | 100.0 |  | $ | 307,675 |  |  | 100.0 |  | $ | 12,230 |  |  | 4.1 |
| Service cost of goods sold | 181,902 |  |  | 61.6 |  | 191,960 |  |  | 62.4 |  | 10,058 |  |  | 5.5 |
| Service gross profit | $ | 113,543 |  |  | 38.4 |  | $ | 115,715 |  |  | 37.6 |  | $ | 2,172 |  |  | 1.9 |

[0000936395-14-000051:mdna:151]
[same as prior period, unchanged from 0000936395-14-000040:mdna:145]

[0000936395-14-000051:mdna:152]
[same as prior period, unchanged from 0000936395-14-000040:mdna:146]

[0000936395-14-000051:mdna:153]
[same as prior period, unchanged from 0000936395-14-000040:mdna:147]

[0000936395-14-000051:mdna:154]
[same as prior period, unchanged from 0000936395-14-000040:mdna:148]

[0000936395-14-000051:mdna:155]
[same as prior period, unchanged from 0000936395-14-000040:mdna:149]

[0000936395-14-000051:mdna:156]
| • | Gross profit on services as a percentage of services revenue decreased primarily due to higher spares usage costs in support of our maintenance contracts and an increase in deployment costs. |

[0000936395-14-000051:mdna:157]
[same as prior period, unchanged from 0000936395-14-000040:mdna:151]

[0000936395-14-000051:mdna:158]
[same as prior period, unchanged from 0000936395-14-000040:mdna:152]

[0000936395-14-000051:mdna:159]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 282,981 |  |  | 18.9 |  | $ | 302,674 |  |  | 17.8 |  | $ | 19,693 |  |  | 7.0 |  |
| Selling and marketing | 216,676 |  |  | 14.4 |  | 243,929 |  |  | 14.4 |  | $ | 27,253 |  |  | 12.6 |  |
| General and administrative | 91,157 |  |  | 6.1 |  | 98,264 |  |  | 5.8 |  | $ | 7,107 |  |  | 7.8 |  |
| Amortization of intangible assets | 37,332 |  |  | 2.5 |  | 34,951 |  |  | 2.1 |  | (2,381 | ) |  | (6.4 | ) |
| Restructuring costs | 6,741 |  |  | 0.4 |  | 178 |  |  | — |  | (6,563 | ) |  | (97.4 | ) |
| Total operating expenses | $ | 634,887 |  |  | 42.3 |  | $ | 679,996 |  |  | 40.1 |  | $ | 45,109 |  |  | 7.1 |  |

[0000936395-14-000051:mdna:160]
[same as prior period, unchanged from 0000936395-14-000040:mdna:154]

[0000936395-14-000051:mdna:161]
[same as prior period, unchanged from 0000936395-14-000040:mdna:155]

[0000936395-14-000051:mdna:162]
[same as prior period, unchanged from 0000936395-14-000040:mdna:156]

[0000936395-14-000051:mdna:163]
| • | Research and development expense benefited by $12.5 million, as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Canadian Dollar. The increase of $19.7 million primarily reflects increases of $7.2 million in professional services expense, $6.2 million in employee compensation and related costs, $5.3 million in prototype expense and $1.3 million in facilities and information technology costs. |

[0000936395-14-000051:mdna:164]
| • | Selling and marketing expense increased $27.3 million, primarily reflecting increases of $23.1 million in employee compensation and related costs, $2.9 million of travel and related costs and $1.2 million in facilities and information technology costs. |

[0000936395-14-000051:mdna:165]
| • | General and administrative expense increased $7.1 million, reflecting increases of $4.6 million in legal fees associated with patent litigation costs, $1.8 million in employee compensation and related costs and $0.7 million of consulting and audit fees. |

[0000936395-14-000051:mdna:166]
[same as prior period, unchanged from 0000936395-14-000040:mdna:160]

[0000936395-14-000051:mdna:167]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and restructuring activities to align our workforce and resources with market opportunities and research and development initiatives. Restructuring costs for fiscal 2013 also include the consolidation of certain facilities located within Maryland associated with the transition of our headquarters facility. |

[0000936395-14-000051:mdna:168]
[same as prior period, unchanged from 0000936395-14-000040:mdna:162]

[0000936395-14-000051:mdna:169]
[same as prior period, unchanged from 0000936395-14-000040:mdna:163]

[0000936395-14-000051:mdna:170]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (6,020 | ) |  | (0.4 | ) |  | $ | (14,231 | ) |  | (0.8 | ) |  | $ | (8,211 | ) |  | 136.4 |  |
| Interest expense | $ | 33,096 |  |  | 2.2 |  |  | $ | 33,556 |  |  | 2.0 |  |  | $ | 460 |  |  | 1.4 |  |
| Loss on extinguishment of debt | $ | 28,630 |  |  | 1.9 |  |  | $ | — |  |  | 0.0 |  |  | $ | (28,630 | ) |  | (100.0 | ) |
| Provision for income taxes | $ | 6,530 |  |  | 0.4 |  |  | $ | 9,666 |  |  | 0.6 |  |  | $ | 3,136 |  |  | 48.0 |  |

[0000936395-14-000051:mdna:171]
[same as prior period, unchanged from 0000936395-14-000040:mdna:165]

[0000936395-14-000051:mdna:172]
[same as prior period, unchanged from 0000936395-14-000040:mdna:166]

[0000936395-14-000051:mdna:173]
[same as prior period, unchanged from 0000936395-14-000040:mdna:167]

[0000936395-14-000051:mdna:174]
| • | Interest and other income (loss), net reflects a $5.5 million non-cash loss related to the change in fair value of the embedded redemption feature associated with our 2015 Notes and a $2.3 million loss related to foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-14-000051:mdna:175]
[same as prior period, unchanged from 0000936395-14-000040:mdna:169]

[0000936395-14-000051:mdna:176]
| • | Loss on extinguishment of debt for fiscal 2013 reflects a non-cash loss of $28.6 million relating to the exchange transactions during the first quarter of fiscal 2013. Upon issuance, the 4.0% convertible senior notes due December 15, 2020 (the "2020 Notes") were recorded at a fair value of $213.6 million. The exchange transactions resulted in the retirement of outstanding 2015 Notes with a carrying value of $187.9 million and the write-off of unamortized debt |

[0000936395-14-000051:mdna:177]
issuance costs of $2.3 million and $0.6 million relating to the redemption feature on the 2015 Notes, which was accounted for as a separate embedded derivative.

[0000936395-14-000051:mdna:178]
[same as prior period, unchanged from 0000936395-14-000040:mdna:171]

[0000936395-14-000051:mdna:179]
[same as prior period, unchanged from 0000936395-14-000040:mdna:172]

[0000936395-14-000051:mdna:180]
[same as prior period, unchanged from 0000936395-14-000040:mdna:173]

[0000936395-14-000051:mdna:181]
|  | Quarter Ended July 31, |  |  |  |
|  | 2013 |  | 2014 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 66,952 |  |  | $ | 104,020 |  |  | $ | 37,068 |  |  | 55.4 |  |
| Packet Networking | $ | 7,620 |  |  | $ | 14,566 |  |  | $ | 6,946 |  |  | 91.2 |  |
| Optical Transport | $ | 29,459 |  |  | $ | 8,900 |  |  | $ | (20,559 | ) |  | (69.8 | ) |
| Software and Services | $ | 31,121 |  |  | $ | 38,802 |  |  | $ | 7,681 |  |  | 24.7 |  |

[0000936395-14-000051:mdna:182]
[same as prior period, unchanged from 0000936395-14-000040:mdna:175]

[0000936395-14-000051:mdna:183]
[same as prior period, unchanged from 0000936395-14-000040:mdna:176]

[0000936395-14-000051:mdna:184]
[same as prior period, unchanged from 0000936395-14-000040:mdna:177]

[0000936395-14-000051:mdna:185]
[same as prior period, unchanged from 0000936395-14-000040:mdna:178]

[0000936395-14-000051:mdna:186]
[same as prior period, unchanged from 0000936395-14-000040:mdna:179]

[0000936395-14-000051:mdna:187]
| • | Software and Services segment profit increased primarily due to higher sales for software and consulting services, including our Network Transformation Solutions offerings, and increased margin due to improved efficiencies for managed spares projects. These increases were partially offset by higher software research and development expenses. |

[0000936395-14-000051:mdna:188]
[same as prior period, unchanged from 0000936395-14-000040:mdna:181]

[0000936395-14-000051:mdna:189]
|  | Nine Months Ended July 31, |  |  |  |
|  | 2013 |  | 2014 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 171,598 |  |  | $ | 279,299 |  |  | $ | 107,701 |  |  | 62.8 |  |
| Packet Networking | $ | 15,259 |  |  | $ | 23,147 |  |  | $ | 7,888 |  |  | 51.7 |  |
| Optical Transport | $ | 71,459 |  |  | $ | 29,259 |  |  | $ | (42,200 | ) |  | (59.1 | ) |
| Software and Services | $ | 92,232 |  |  | $ | 93,136 |  |  | $ | 904 |  |  | 1.0 |  |

[0000936395-14-000051:mdna:190]
[same as prior period, unchanged from 0000936395-14-000040:mdna:183]

[0000936395-14-000051:mdna:191]
[same as prior period, unchanged from 0000936395-14-000040:mdna:184]

[0000936395-14-000051:mdna:192]
[same as prior period, unchanged from 0000936395-14-000040:mdna:185]

[0000936395-14-000051:mdna:193]
| • | Packet Networking segment profit increased due to increased sales volume and improved gross margin, partially offset by increased research and development expense. Packet Networking revenue benefited from the expansion of Ethernet business services by our North American service provider customers and sales of service delivery and aggregation products in support of their related network initiatives. Gross margin improved due to sales reflecting a greater mix of higher-margin platforms with software content within the segment. |

[0000936395-14-000051:mdna:194]
[same as prior period, unchanged from 0000936395-14-000040:mdna:189]

[0000936395-14-000051:mdna:195]
| • | Software and Services segment profit increased slightly due to higher sales for software and consulting services, including our Network Transformation Solutions offerings. These increases were offset by higher spares usage costs in support of our maintenance contracts, increases in deployment costs and higher software research and development expense. |

[0000936395-14-000051:mdna:196]
[same as prior period, unchanged from 0000936395-14-000040:mdna:191]

[0000936395-14-000051:mdna:197]
At July 31, 2014, our principal sources of liquidity were cash and cash equivalents, short-term investments and long-term investments in marketable debt securities, representing U.S. treasuries and commercial paper, and our ABL Credit Facility. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-14-000051:mdna:198]
|  | October 31, 2013 |  | July 31, 2014 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 346,487 |  |  | $ | 532,884 |  |  | $ | 186,397 |  |
| Short-term investments in marketable debt securities | 124,979 |  |  | 120,250 |  |  | (4,729 | ) |
| Long-term investments in marketable debt securities | 15,031 |  |  | 65,019 |  |  | 49,988 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 486,497 |  |  | $ | 718,153 |  |  | $ | 231,656 |  |

[0000936395-14-000051:mdna:199]
The change in total cash and cash equivalents and investments in marketable debt securities during the first nine months of fiscal 2014 was primarily related to the $246 million in net proceeds from our Term Loan as described in "Overview" above and the following:

[0000936395-14-000051:mdna:200]
| • | $16.0 million cash generated from operations, consisting of $171.7 million provided by net loss (adjusted for non-cash charges) and $155.7 million used in working capital; |

[0000936395-14-000051:mdna:201]
| • | $36.0 million used for purchases of equipment, furniture, and fixtures and intellectual property; |

[0000936395-14-000051:mdna:202]
42

[0000936395-14-000051:mdna:203]
| • | $10.8 million used in settlement of foreign currency forward contracts, net; |

[0000936395-14-000051:mdna:204]
| • | $2.3 million used in relation to payment of capital lease obligations; and |

[0000936395-14-000051:mdna:205]
| • | $17.5 million provided by stock issuances under our employee stock purchase plan and exercise of stock options. |

[0000936395-14-000051:mdna:206]
As of July 31, 2014, letters of credit totaling $56.0 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2014. See "ABL Credit Facility" below for additional information.

[0000936395-14-000051:mdna:207]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our Credit Facility, will satisfy the working capital needs, capital expenditures, the repayment of our outstanding 4.0% convertible senior notes due March 15, 2015 and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-14-000051:mdna:208]
The following sections set forth the components of our $16.0 million of cash generated from operating activities during the first nine months of fiscal 2014:

[0000936395-14-000051:mdna:209]
[same as prior period, unchanged from 0000936395-14-000040:mdna:203]

[0000936395-14-000051:mdna:210]
[same as prior period, unchanged from 0000936395-14-000040:mdna:204]

[0000936395-14-000051:mdna:211]
|  | Nine months ended |
|  | July 31, 2014 |
| Net loss | $ | (9,934 | ) |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 41,463 |  |
| Share-based compensation costs | 34,204 |  |
| Amortization of intangible assets | 43,931 |  |
| Provision for inventory excess and obsolescence | 22,026 |  |
| Provision for warranty | 18,720 |  |
| Other | 21,254 |  |
| Net loss (adjusted for non-cash charges) | $ | 171,664 |  |

[0000936395-14-000051:mdna:212]
[same as prior period, unchanged from 0000936395-14-000040:mdna:206]

[0000936395-14-000051:mdna:213]
[same as prior period, unchanged from 0000936395-14-000040:mdna:207]

[0000936395-14-000051:mdna:214]
Cash used by an increase in accounts receivable during the first nine months of fiscal 2014, net of a $2.7 million provision for doubtful accounts, was $55.7 million. This reflects both increases in our revenues and days sales outstanding (DSOs). Our DSOs increased from 78 days for the first nine months of fiscal 2013 to 86 days for the first nine months of fiscal 2014. The increase in DSOs primarily reflects growth in certain new international customers whose contracts have longer payment terms.

[0000936395-14-000051:mdna:215]
The following table sets forth (in thousands) changes to our accounts receivable, net of allowance for doubtful accounts, from the end of fiscal 2013 through the end of the third quarter of fiscal 2014:

[0000936395-14-000051:mdna:216]
|  | October 31, 2013 |  | July 31, 2014 |  | Increase(decrease) |
| Accounts receivable, net | $ | 488,578 |  |  | $ | 541,573 |  |  | $ | 52,995 |  |

[0000936395-14-000051:mdna:217]
[same as prior period, unchanged from 0000936395-14-000040:mdna:211]

[0000936395-14-000051:mdna:218]
Cash used by an increase in inventory during the first nine months of fiscal 2014 was $66.0 million. The increase in inventory reflects our decision to carry more finished goods inventory for our Converged Packet Optical products to reduce our lead times for shipments to customers and higher deferred cost of goods sold for shipments awaiting acceptance. Our inventory turns decreased from 3.9 turns during the first nine months of fiscal 2013 to 3.5 turns during the first nine months of fiscal 2014. Our inventory balance, as reported on our Condensed Consolidated Balance Sheet, increased by $44.0 million during the first nine months of fiscal 2014. This change reflects our $66.0 million cash usage for inventory, partially offset by a $22.0

[0000936395-14-000051:mdna:219]
million non-cash provision for excess and obsolescence. The following table sets forth (in thousands) changes to the components of our inventory from the end of fiscal 2013 through the end of the third quarter of fiscal 2014:

[0000936395-14-000051:mdna:220]
|  | October 31, 2013 |  | July 31, 2014 |  | Increase(decrease) |
| Raw materials | $ | 53,274 |  |  | $ | 61,429 |  |  | $ | 8,155 |  |
| Work-in-process | 7,773 |  |  | 8,268 |  |  | 495 |  |
| Finished goods | 153,855 |  |  | 172,321 |  |  | 18,466 |  |
| Deferred cost of goods sold | 75,764 |  |  | 103,701 |  |  | 27,937 |  |
| Gross inventory | 290,666 |  |  | 345,719 |  |  | 55,053 |  |
| Provision for inventory excess and obsolescence | (41,563 | ) |  | (52,627 | ) |  | (11,064 | ) |
| Inventory | $ | 249,103 |  |  | $ | 293,092 |  |  | $ | 43,989 |  |

[0000936395-14-000051:mdna:221]
[same as prior period, unchanged from 0000936395-14-000040:mdna:214]

[0000936395-14-000051:mdna:222]
Cash used by an increase in prepaid expense and other during the first nine months of fiscal 2014 was $26.7 million primarily related to higher product demonstration equipment, prepaid value added tax and deferred deployment expense.

[0000936395-14-000051:mdna:223]
[same as prior period, unchanged from 0000936395-14-000040:mdna:216]

[0000936395-14-000051:mdna:224]
Utilization of cash resources for accounts payable, accruals and other obligations during the first nine months of fiscal 2014 was $34.8 million, reflecting, among other things, the timing of the annual payment under our cash incentive compensation plan to employees with respect to amounts earned for fiscal 2013. Changes in accrued liabilities reflect a $18.7 million non-cash provision related to warranties. Changes in accounts payable reflect a decrease of $1.9 million for investing activities related to equipment purchases.

[0000936395-14-000051:mdna:225]
The following table sets forth (in thousands) changes in our accounts payable, accruals and other obligations from the end of fiscal 2013 through the end of the third quarter of fiscal 2014:

[0000936395-14-000051:mdna:226]
|  | October 31, 2013 |  | July 31, 2014 |  | Increase(decrease) |
| Accounts payable | $ | 254,849 |  |  | $ | 236,630 |  |  | $ | (18,219 | ) |
| Accrued liabilities | 271,656 |  |  | 267,846 |  |  | (3,810 | ) |
| Other long-term obligations | 34,753 |  |  | 37,206 |  |  | 2,453 |  |
| Accounts payable, accruals and other obligations | $ | 561,258 |  |  | $ | 541,682 |  |  | $ | (19,576 | ) |

[0000936395-14-000051:mdna:227]
Interest Paid on Convertible Notes, ABL Credit Facility and Term Loan

[0000936395-14-000051:mdna:228]
Interest on our outstanding 4.0% convertible senior notes, due March 15, 2015, is payable on March 15 and September 15 of each year. We paid $3.8 million in interest on these convertible notes during the first nine months of fiscal 2014.

[0000936395-14-000051:mdna:229]
Interest on our outstanding 0.875% convertible senior notes, due June 15, 2017, is payable on June 15 and December 15 of each year. We paid $4.4 million in interest on these convertible notes during the first nine months of fiscal 2014.

[0000936395-14-000051:mdna:230]
Interest on our outstanding 3.75% convertible senior notes, due October 15, 2018, is payable on April 15 and October 15 of each year. We paid $6.6 million in interest on these convertible notes during the first nine months of fiscal 2014.

[0000936395-14-000051:mdna:231]
Interest on our outstanding 4.0% convertible senior notes, due December 15, 2020, is payable on June 15 and December 15 of each year. We paid $7.5 million in interest on these convertible notes during the first nine months of fiscal 2014.

[0000936395-14-000051:mdna:232]
Interest on our outstanding Term Loan, due July 15, 2019, is payable periodically based on the underlying market index rate selected for borrowing. We paid $0.1 million in interest on this term loan during the third quarter of fiscal 2014.

[0000936395-14-000051:mdna:233]
During the first nine months of fiscal 2014, we utilized the ABL Credit Facility to collateralize certain standby letters of credit. We paid $1.1 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility during the first nine months of fiscal 2014.

[0000936395-14-000051:mdna:234]
[same as prior period, unchanged from 0000936395-14-000040:mdna:226]

[0000936395-14-000051:mdna:235]
Deferred revenue increased by $27.5 million during the first nine months of fiscal 2014. Product deferred revenue represents either payments received in advance of shipment or payments received after shipment but before revenue recognition. Services deferred revenue is related to payment for service contracts for which revenue will be recognized over the contract term. The following table reflects (in thousands) the balance of deferred revenue and the change in this balance from the end of fiscal 2013 through the first nine months of fiscal 2014:

[0000936395-14-000051:mdna:236]
|  | October 31, 2013 |  | July 31, 2014 |  | Increase(decrease) |
| Products | $ | 36,671 |  |  | $ | 57,590 |  |  | $ | 20,919 |  |
| Services | 75,499 |  |  | 82,078 |  |  | 6,579 |  |
| Total deferred revenue | $ | 112,170 |  |  | $ | 139,668 |  |  | $ | 27,498 |  |

[0000936395-14-000051:mdna:237]
ABL Credit Facility

[0000936395-14-000051:mdna:238]
On July 15, 2014, we amended our ABL Credit Facility to, among other things:

[0000936395-14-000051:mdna:239]
| • | increase the total commitment from $150 million to $200 million; |

[0000936395-14-000051:mdna:240]
| • | extend the maturity date from August 13, 2015 to December 31, 2016 (and eliminate the December 15, 2014 maturity date acceleration feature); |

[0000936395-14-000051:mdna:241]
| • | reduce from $200 million to $150 million the minimum aggregate amount of unrestricted cash and cash equivalents that we are required to maintain at all times; |

[0000936395-14-000051:mdna:242]
| • | reduce the interest rate on borrowings from LIBOR plus an applicable margin ranging from 200 basis points to 250 basis points, to an applicable margin ranging from 150 basis points to 200 basis points, with the actual margin determined based on Ciena's utilization of the credit facility; and |

[0000936395-14-000051:mdna:243]
| • | amend the borrowing base to include, among other items, up to $50 million in eligible cash. |

[0000936395-14-000051:mdna:244]
We principally use the liquidity available under the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments.

[0000936395-14-000051:mdna:245]
[same as prior period, unchanged from 0000936395-14-000040:mdna:232]

[0000936395-14-000051:mdna:246]
During the third quarter of fiscal 2014, we entered into a Term Loan Credit Agreement that provides for senior secured term loans in an aggregate principal amount of $250 million as described in "Overview" above. The following is a summary of our future minimum payments under contractual obligations as of July 31, 2014 (in thousands):

[0000936395-14-000051:mdna:247]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 1,254,627 |  |  | $ | 187,500 |  |  | $ | 500,000 |  |  | $ | 350,000 |  |  | $ | 217,127 |  |
| Principal due on term loan | 250,000 |  |  | 2,500 |  |  | 5,000 |  |  | 242,500 |  |  | — |  |
| Interest due on convertible notes | 128,437 |  |  | 32,500 |  |  | 50,000 |  |  | 34,687 |  |  | 11,250 |  |
| Interest due on term loan (2) | 44,105 |  |  | 9,373 |  |  | 17,544 |  |  | 17,188 |  |  | — |  |
| Operating leases (3) | 159,339 |  |  | 33,009 |  |  | 55,337 |  |  | 24,906 |  |  | 46,087 |  |
| Purchase obligations (4) | 190,637 |  |  | 190,637 |  |  | — |  |  | — |  |  | — |  |
| Capital leases | 2,863 |  |  | 2,079 |  |  | 784 |  |  | — |  |  | — |  |
| Other obligations | 5,715 |  |  | 2,900 |  |  | 2,815 |  |  | — |  |  | — |  |
| Total (5) | $ | 2,035,723 |  |  | $ | 460,498 |  |  | $ | 631,480 |  |  | $ | 669,281 |  |  | $ | 274,464 |  |

[0000936395-14-000051:mdna:248]
[same as prior period, unchanged from 0000936395-14-000040:mdna:235]

[0000936395-14-000051:mdna:249]
[same as prior period, unchanged from 0000936395-14-000040:mdna:236]

[0000936395-14-000051:mdna:250]
| (2) | Interest on the term loan is variable and was calculated using the rate in effect on the balance sheet date. |

[0000936395-14-000051:mdna:251]
| (3) | Does not include variable insurance, taxes, maintenance and other costs required by the applicable operating lease. These costs are not expected to have a material future impact. |

[0000936395-14-000051:mdna:252]
| (4) | Purchase obligations relate to purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of the amount reported above relates to firm, non-cancelable and unconditional obligations. |

[0000936395-14-000051:mdna:253]
| (5) | As of July 31, 2014, we also had approximately $12.4 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-14-000051:mdna:254]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of July 31, 2014 (in thousands):

[0000936395-14-000051:mdna:255]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years | Thereafter |
| Standby letters of credit | $ | 55,975 |  |  | $ | 23,432 |  |  | $ | 11,923 |  |  | $ | 3,659 |  | $ | 16,961 |  |

[0000936395-14-000051:mdna:256]
[same as prior period, unchanged from 0000936395-14-000040:mdna:242]

[0000936395-14-000051:mdna:257]
[same as prior period, unchanged from 0000936395-14-000040:mdna:243]

[0000936395-14-000051:mdna:258]
[same as prior period, unchanged from 0000936395-14-000040:mdna:244]

[0000936395-14-000051:mdna:259]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-14-000051:mdna:260]
[same as prior period, unchanged from 0000936395-14-000040:mdna:247]

[0000936395-14-000051:mdna:261]
[same as prior period, unchanged from 0000936395-14-000040:mdna:248]

[0000936395-14-000051:mdna:262]
[same as prior period, unchanged from 0000936395-14-000040:mdna:249]

[0000936395-14-000051:mdna:263]
[same as prior period, unchanged from 0000936395-14-000040:mdna:250]

[0000936395-14-000051:mdna:264]
[same as prior period, unchanged from 0000936395-14-000040:mdna:251]

[0000936395-14-000051:mdna:265]
[same as prior period, unchanged from 0000936395-14-000040:mdna:252]

[0000936395-14-000051:mdna:266]
[same as prior period, unchanged from 0000936395-14-000040:mdna:253]

[0000936395-14-000051:mdna:267]
[same as prior period, unchanged from 0000936395-14-000040:mdna:254]

[0000936395-14-000051:mdna:268]
Our total deferred revenue for products was $36.7 million and $57.6 million as of October 31, 2013 and July 31, 2014, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $75.5 million and $82.1 million as of October 31, 2013 and July 31, 2014, respectively.

[0000936395-14-000051:mdna:269]
[same as prior period, unchanged from 0000936395-14-000040:mdna:256]

[0000936395-14-000051:mdna:270]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards, net of estimated forfeitures, as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-14-000051:mdna:271]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 16 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of

[0000936395-14-000051:mdna:272]
July 31, 2014, total unrecognized compensation expense was $64.5 million, which relates to unvested restricted stock units and this expense is expected to be recognized over a weighted-average period of 1.5 years.

[0000936395-14-000051:mdna:273]
[same as prior period, unchanged from 0000936395-14-000040:mdna:260]

[0000936395-14-000051:mdna:274]
[same as prior period, unchanged from 0000936395-14-000040:mdna:261]

[0000936395-14-000051:mdna:275]
[same as prior period, unchanged from 0000936395-14-000040:mdna:262]

[0000936395-14-000051:mdna:276]
For fiscal 2014, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2014. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for incentive compensation in any interim period in fiscal 2014 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are higher or lower than expected. We incurred an aggregate of $33.7 million of expense in the first nine months of fiscal 2014 associated with our cash incentive bonus plan for fiscal 2014.

[0000936395-14-000051:mdna:277]
[same as prior period, unchanged from 0000936395-14-000040:mdna:264]

[0000936395-14-000051:mdna:278]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write-downs due to discontinuance of a product, changes in our strategic direction and declines in market conditions. We recorded charges for excess and obsolete inventory of $15.3 million and $22.0 million in the first nine months of fiscal 2013 and 2014, respectively. The charges in fiscal 2014 primarily related to engineering design changes and the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform, and Converged Packet Optical products. Our inventory net of allowance for excess and obsolescence was $249.1 million and $293.1 million as of October 31, 2013 and July 31, 2014, respectively.

[0000936395-14-000051:mdna:279]
[same as prior period, unchanged from 0000936395-14-000040:mdna:267]

[0000936395-14-000051:mdna:280]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be

[0000936395-14-000051:mdna:281]
required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $488.6 million and $541.6 million as of October 31, 2013 and July 31, 2014, respectively. Our allowance for doubtful accounts was $2.0 million and $2.7 million as of October 31, 2013 and July 31, 2014, respectively.

[0000936395-14-000051:mdna:282]
[same as prior period, unchanged from 0000936395-14-000040:mdna:269]

[0000936395-14-000051:mdna:283]
Our long-lived assets include: equipment, furniture and fixtures, finite-lived intangible assets and maintenance spares. As of October 31, 2013 and July 31, 2014, these assets totaled $366.9 million and $315.0 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups that represents the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-14-000051:mdna:284]
[same as prior period, unchanged from 0000936395-14-000040:mdna:271]

[0000936395-14-000051:mdna:285]
As of July 31, 2014, we have recorded a valuation allowance offsetting substantially all our net deferred tax assets of $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to make judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies and tax planning strategies. The valuation allowance is reviewed quarterly and is maintained until sufficient positive evidence exists to support a reversal. Because evidence such as our operating results during the most recent three-year period is afforded more weight than forecasted results for future periods, our cumulative loss during this three-year period represents sufficient negative evidence regarding the need for nearly a full valuation allowance. We will release this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-14-000051:mdna:286]
[same as prior period, unchanged from 0000936395-14-000040:mdna:273]

[0000936395-14-000051:mdna:287]
Our liability for product warranties, included in other accrued liabilities, was $56.3 million and $57.4 million as of October 31, 2013 and July 31, 2014, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $15.1 million and $18.7 million for the first nine months of fiscal 2013 and 2014, respectively. See Note 11 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
