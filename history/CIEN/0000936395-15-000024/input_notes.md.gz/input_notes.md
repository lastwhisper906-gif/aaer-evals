# CIEN notes — 0000936395-15-000024


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-15-000024:notes:1]
ABL CREDIT FACILITY

[0000936395-15-000024:notes:2]
Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $200 million with a maturity date of December 31, 2016. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of January 31, 2015, letters of credit totaling $60.5 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 31, 2015.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-15-000024:notes:3]
Substantially all of Ciena's cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena's cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-15-000024:notes:4]
Historically, a significant percentage of Ciena's revenue has been concentrated among sales to a small number of large communications service providers. Consolidation among Ciena's customers has increased this concentration. Consequently, Ciena's accounts receivable are concentrated among these customers. See Note 19 below.

[0000936395-15-000024:notes:5]
Additionally, Ciena's access to certain materials or components is dependent upon sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena's supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers and forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena's business and results of operations may suffer.


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-15-000024:notes:6]
Ciena accounts for proceeds from government grants as a reduction of operating expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that the grant proceeds will be received. Grant benefits are recorded to the line item in the Condensed Consolidated Statement of Operations to which the grant activity relates.


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-15-000024:notes:7]
Maintenance spares are recorded at cost. Spares usage cost is expensed ratably over four years.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-15-000024:notes:8]
[same as prior period, unchanged from 0000936395-14-000051:notes:228]

[0000936395-15-000024:notes:9]
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-15-000024:notes:10]
|  | October 31, 2014 |  | January 31, 2015 |
| Prepaid VAT and other taxes | $ | 86,464 |  |  | $ | 79,181 |  |
| Product demonstration equipment, net | 42,385 |  |  | 44,661 |  |
| Deferred deployment expense | 27,991 |  |  | 24,229 |  |
| Prepaid expenses | 23,539 |  |  | 21,251 |  |
| Other non-trade receivables | 10,683 |  |  | 12,842 |  |
| Derivative assets | 1,562 |  |  | 654 |  |
|  | $ | 192,624 |  |  | $ | 182,818 |  |

[0000936395-15-000024:notes:11]
Depreciation of product demonstration equipment was $2.0 million and $2.5 million for the first three months of fiscal 2014 and 2015, respectively.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-15-000024:notes:12]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-15-000024:notes:13]
Term Loan

[0000936395-15-000024:notes:14]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2015:

[0000936395-15-000024:notes:15]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 248,750 |  |  | $ | 1,110 |  |  | $ | 247,640 |  |
|  |  | $ | 248,750 |  |  | $ | 1,110 |  |  | $ | 247,640 |  |

[0000936395-15-000024:notes:16]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

[0000936395-15-000024:notes:17]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 247,640 |  |  | $ | 247,817 |  |
|  |  | $ | 247,640 |  |  | $ | 247,817 |  |

[0000936395-15-000024:notes:18]
| (1) | Includes unamortized bond discount. |

[0000936395-15-000024:notes:19]
| (2) | The Term Loan was categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-15-000024:notes:20]
Outstanding Convertible Notes Payable

[0000936395-15-000024:notes:21]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of January 31, 2015:

[0000936395-15-000024:notes:22]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 194,879 |  |  | $ | 14,536 |  |  | $ | 180,343 |  |  | $ | 43,131 |  |

[0000936395-15-000024:notes:23]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding convertible notes:

[0000936395-15-000024:notes:24]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,520 |  |  | $ | 191,016 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 495,625 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 180,343 |  |  | 228,516 |  |
|  |  | $ | 1,217,863 |  |  | $ | 1,331,220 |  |

[0000936395-15-000024:notes:25]
| (1) | Includes unamortized bond premium related to embedded redemption feature. |

[0000936395-15-000024:notes:26]
| (2) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-15-000024:notes:27]
| (3) | Includes unamortized discount and accretion of principal. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-15-000024:notes:28]
[same as prior period, unchanged from 0000936395-14-000051:notes:2]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-15-000024:notes:29]
[same as prior period, unchanged from 0000936395-14-000051:notes:4]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-15-000024:notes:30]
COMMITMENTS AND CONTINGENCIES

[0000936395-15-000024:notes:31]
Ontario Grant

[0000936395-15-000024:notes:32]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2015, Ciena has recorded a CAD$24.6 million benefit to date, as a reduction in research and development expenses. As of January 31, 2015, the amount receivable from this grant was CAD$4.6 million.

[0000936395-15-000024:notes:33]
Foreign Tax Contingencies

[0000936395-15-000024:notes:34]
As of October 31, 2014 and January 31, 2015, Ciena had accrued liabilities of $1.1 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 and 2010 related to income taxes. This contingency has been reported as a component of other long-term liabilities. Although Ciena estimates that it could be exposed to possible losses of up to $5.5 million, it has not accrued a liability of such amount as of January 31, 2015. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to these assessments. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.

[0000936395-15-000024:notes:35]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-15-000024:notes:36]
Litigation

[0000936395-15-000024:notes:37]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-15-000024:notes:38]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-15-000024:notes:39]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-15-000024:notes:40]
ACCUMULATED OTHER COMPREHENSIVE INCOME

[0000936395-15-000024:notes:41]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the three months ending January 31, 2015:

[0000936395-15-000024:notes:42]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2014 | $ | 71 |  |  | $ | (173 | ) |  | $ | (2,083 | ) |  | $ | (12,483 | ) |  | $ | (14,668 | ) |
| Other comprehensive income(loss) before reclassifications | 36 |  |  | (5,315 | ) |  | (2,565 | ) |  | (12,248 | ) |  | (20,092 | ) |
| Amounts reclassified from AOCI | — |  |  | 802 |  |  | — |  |  | — |  |  | 802 |  |
| Balance at January 31, 2015 | $ | 107 |  |  | $ | (4,686 | ) |  | $ | (4,648 | ) |  | $ | (24,731 | ) |  | $ | (33,958 | ) |

[0000936395-15-000024:notes:43]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the three months ending January 31, 2014:

[0000936395-15-000024:notes:44]
|  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Derivative Instruments |  | Translation Adjustment |  | Total |
| Balance at October 31, 2013 | $ | 30 |  |  | $ | (261 | ) |  | $ | (7,543 | ) |  | $ | (7,774 | ) |
| Other comprehensive income(loss) before reclassifications | 21 |  |  | (2,277 | ) |  | (5,100 | ) |  | (7,356 | ) |
| Amounts reclassified from AOCI | — |  |  | 303 |  |  | — |  |  | 303 |  |
| Balance at January 31, 2014 | $ | 51 |  |  | $ | (2,235 | ) |  | $ | (12,643 | ) |  | $ | (14,827 | ) |

[0000936395-15-000024:notes:45]
All amounts reclassified from accumulated other comprehensive income were related to settlement (gains)/losses on foreign currency forward contracts designated as cash flow hedges. These reclassifications impacted "research and development" on the Condensed Consolidated Statements of Operations.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-15-000024:notes:46]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period of more than 60 days, which are accrued over the service period. See Note 3 below.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-15-000024:notes:47]
[same as prior period, unchanged from 0000936395-14-000051:notes:18]

[0000936395-15-000024:notes:48]
|  | October 31, 2014 |  | January 31, 2015 |
| Products | $ | 50,457 |  |  | $ | 58,041 |  |
| Services | 95,161 |  |  | 94,497 |  |
|  | 145,618 |  |  | 152,538 |  |
| Less current portion | (104,688 | ) |  | (106,486 | ) |
| Long-term deferred revenue | $ | 40,930 |  |  | $ | 46,052 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-15-000024:notes:49]
DERIVATIVE INSTRUMENTS

[0000936395-15-000024:notes:50]
Foreign Currency Derivatives

[0000936395-15-000024:notes:51]
As of January 31, 2015 and October 31, 2014, Ciena had forward contracts in place to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally related to its research and development activities. The notional amount of these contracts was approximately $49.1 million and $51.5 million as of January 31, 2015 and October 31, 2014, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-15-000024:notes:52]
During the first three months of fiscal 2015 and fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell Brazilian Real and buy an equivalent U.S. Dollar amount. During the first three months of fiscal 2015 and fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell U.S. Dollars and buy an equivalent amount of Canadian Dollars. The notional amount of these contracts was approximately $202.7 million and $194.5 million as of January 31, 2015 and October 31, 2014, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-15-000024:notes:53]
Interest Rate Derivatives

[0000936395-15-000024:notes:54]
During fiscal 2014, Ciena entered into interest rate cap arrangements to limit interest paid under the Term Loan to a maximum of 0.75% plus a spread of 300 basis points through July 2015. The total notional amount of interest rate caps outstanding as of January 31, 2015 and October 31, 2014 was $248.8 million.  Also in fiscal 2014, Ciena entered into floating interest rate to fixed interest rate swap arrangements ("interest rate swap") that fix the interest rate under the Term Loan at 5.004%, for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of January 31, 2015 and October 31, 2014 was $247.5 million.

[0000936395-15-000024:notes:55]
Ciena expects the variable rate payments to be received under the terms of the interest rate cap and the interest rate swap to exactly offset the forecasted variable rate payments on the equivalent notional amounts of the Term Loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-15-000024:notes:56]
Other information regarding Ciena's derivatives is immaterial for separate financial statement presentation. See Note 4 and Note 6 above.


## us-gaap:DerivativesPolicyTextBlock

[0000936395-15-000024:notes:57]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") includes a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature was recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.

[0000936395-15-000024:notes:58]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. During fiscal 2014, Ciena also entered into interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its Term Loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

[0000936395-15-000024:notes:59]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations.

[0000936395-15-000024:notes:60]
[same as prior period, unchanged from 0000936395-14-000051:notes:26]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-15-000024:notes:61]
[same as prior period, unchanged from 0000936395-14-000051:notes:27]

[0000936395-15-000024:notes:62]
Ciena grants equity awards under its 2008 Omnibus Incentive Plan (the "2008 Plan") and the Amended and Restated Employee Stock Purchase Plan (the “ESPP”). These plans were approved by stockholders and are described in Ciena’s Annual Report on Form 10-K for the fiscal year ended October 31, 2014.

[0000936395-15-000024:notes:63]
[same as prior period, unchanged from 0000936395-14-000051:notes:29]

[0000936395-15-000024:notes:64]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. The total number of shares authorized for issuance under the 2008 Plan is 25.1 million shares. As of January 31, 2015, approximately 6.6 million shares remained available for issuance under the 2008 Plan.

[0000936395-15-000024:notes:65]
[same as prior period, unchanged from 0000936395-14-000051:notes:31]

[0000936395-15-000024:notes:66]
Outstanding stock option awards to employees are generally subject to service-based vesting restrictions and vest incrementally over a four-year period. As of January 31, 2015, all outstanding options have completed their service-based vesting conditions and are fully vested. The following table is a summary of Ciena’s stock option activity for the period indicated (shares in thousands):

[0000936395-15-000024:notes:67]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2014 | 1,288 |  |  | $ | 25.43 |  |
| Exercised | (24 | ) |  | 12.56 |  |
| Canceled | (55 | ) |  | 21.62 |  |
| Balance at January 31, 2015 | 1,209 |  |  | $ | 25.86 |  |

[0000936395-15-000024:notes:68]
The total intrinsic value of options exercised during the first three months of fiscal 2014 and fiscal 2015 was $0.2 million and $0.1 million, respectively. Ciena did not grant any stock options during the first three months of fiscal 2014 or fiscal 2015.

[0000936395-15-000024:notes:69]
The following table summarizes information with respect to stock options outstanding at January 31, 2015, based on Ciena’s closing stock price on the last trading day of Ciena’s first fiscal quarter of 2015 (shares and intrinsic value in thousands):

[0000936395-15-000024:notes:70]
|  |  |  |  |  |  | Options Outstanding and Vested at |
|  |  |  |  |  |  | January 31, 2015 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 0.94 |  |  | — |  |  | $ | 16.31 |  |  | 145 |  |  | 2.96 |  | $ | 8.22 |  |  | $ | 1,495 |  |
| $ | 16.52 |  |  | — |  |  | $ | 17.29 |  |  | 174 |  |  | 0.68 |  | 16.55 |  |  | 341 |  |
| $ | 17.43 |  |  | — |  |  | $ | 24.50 |  |  | 147 |  |  | 1.25 |  | 18.42 |  |  | 115 |  |
| $ | 24.69 |  |  | — |  |  | $ | 28.28 |  |  | 277 |  |  | 2.10 |  | 27.33 |  |  | — |  |
| $ | 28.61 |  |  | — |  |  | $ | 31.43 |  |  | 95 |  |  | 2.44 |  | 29.79 |  |  | — |  |
| $ | 31.71 |  |  | — |  |  | $ | 32.55 |  |  | 9 |  |  | 2.19 |  | 31.91 |  |  | — |  |
| $ | 33.00 |  |  | — |  |  | $ | 37.10 |  |  | 248 |  |  | 2.78 |  | 35.24 |  |  | — |  |
| $ | 37.31 |  |  | — |  |  | $ | 47.32 |  |  | 114 |  |  | 2.24 |  | 44.33 |  |  | — |  |
| $ | 0.94 |  |  | — |  |  | $ | 47.32 |  |  | 1,209 |  |  | 2.08 |  | $ | 25.86 |  |  | $ | 1,951 |  |

[0000936395-15-000024:notes:71]
[same as prior period, unchanged from 0000936395-14-000051:notes:37]

[0000936395-15-000024:notes:72]
[same as prior period, unchanged from 0000936395-14-000051:notes:38]

[0000936395-15-000024:notes:73]
[same as prior period, unchanged from 0000936395-14-000051:notes:39]

[0000936395-15-000024:notes:74]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena's outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. Awards with performance-based vesting conditions require the achievement of certain operational, financial or other performance criteria or targets as a condition of vesting, or the acceleration of vesting, of such awards. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-15-000024:notes:75]
The following table is a summary of Ciena's restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena's closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-15-000024:notes:76]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2014 | 4,012 |  |  | $ | 18.02 |  |  | $ | 67,241 |  |
| Granted | 1,992 |  |  |  |  |  |
| Vested | (723 | ) |  |  |  |  |
| Canceled or forfeited | (97 | ) |  |  |  |  |
| Balance at January 31, 2015 | 5,184 |  |  | $ | 18.30 |  |  | $ | 96,003 |  |

[0000936395-15-000024:notes:77]
The total fair value of restricted stock units that vested and were converted into common stock during the first three months of fiscal 2014 and fiscal 2015 was $16.5 million and $14.0 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first three months of fiscal 2014 and fiscal 2015 was $21.89 and $18.49 respectively.

[0000936395-15-000024:notes:78]
[same as prior period, unchanged from 0000936395-14-000051:notes:44]

[0000936395-15-000024:notes:79]
[same as prior period, unchanged from 0000936395-14-000051:notes:45]

[0000936395-15-000024:notes:80]
Share-based expense for performance-based restricted stock unit awards, net of estimated forfeitures, is recognized ratably over the performance period based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-15-000024:notes:81]
[same as prior period, unchanged from 0000936395-14-000051:notes:47]

[0000936395-15-000024:notes:82]
[same as prior period, unchanged from 0000936395-14-000051:notes:48]

[0000936395-15-000024:notes:83]
[same as prior period, unchanged from 0000936395-14-000051:notes:49]

[0000936395-15-000024:notes:84]
During the first three months of fiscal 2015, Ciena issued 0.5 million shares under the ESPP. At January 31, 2015, 6.3 million shares remained available for issuance under the ESPP.

[0000936395-15-000024:notes:85]
[same as prior period, unchanged from 0000936395-14-000051:notes:51]

[0000936395-15-000024:notes:86]
[same as prior period, unchanged from 0000936395-14-000051:notes:52]

[0000936395-15-000024:notes:87]
|  | Quarter Ended January 31, |
|  | 2014 |  | 2015 |
| Product costs | $ | 506 |  |  | $ | 487 |  |
| Service costs | 580 |  |  | 519 |  |
| Share-based compensation expense included in cost of sales | 1,086 |  |  | 1,006 |  |
| Research and development | 2,572 |  |  | 2,167 |  |
| Sales and marketing | 4,063 |  |  | 3,659 |  |
| General and administrative | 3,506 |  |  | 3,919 |  |
| Share-based compensation expense included in operating expense | 10,141 |  |  | 9,745 |  |
| Share-based compensation expense capitalized in inventory, net | 165 |  |  | 56 |  |
| Total share-based compensation | $ | 11,392 |  |  | $ | 10,807 |  |

[0000936395-15-000024:notes:88]
As of January 31, 2015, total unrecognized share-based compensation expense related to unvested restricted stock units was $82.9 million, and this expense is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-15-000024:notes:89]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement.


## us-gaap:EarningsPerShareTextBlock

[0000936395-15-000024:notes:90]
[same as prior period, unchanged from 0000936395-14-000051:notes:57]

[0000936395-15-000024:notes:91]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Because the numerator reflects net losses for the periods indicated, both Basic EPS and Diluted EPS are computed using the weighted average number of common shares outstanding. If the numerator reflected net income, Diluted EPS would also include, to the extent the effect is not anti-dilutive, the following: (i) shares issuable upon vesting of restricted stock units, (ii) shares issuable under Ciena's employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method; and (iii) shares underlying Ciena's outstanding convertible notes.

[0000936395-15-000024:notes:92]
|  | Quarter Ended January 31, |
| Numerator | 2014 |  | 2015 |
| Net loss | $ | (15,936 | ) |  | $ | (18,779 | ) |

[0000936395-15-000024:notes:93]
|  | Quarter Ended January 31, |
| Denominator | 2014 |  | 2015 |
| Basic weighted average shares outstanding | 104,501 |  |  | 107,773 |  |
| Dilutive weighted average shares outstanding | 104,501 |  |  | 107,773 |  |

[0000936395-15-000024:notes:94]
|  | Quarter Ended January 31, |
| EPS | 2014 |  | 2015 |
| Basic EPS | $ | (0.15 | ) |  | $ | (0.17 | ) |
| Diluted EPS | $ | (0.15 | ) |  | $ | (0.17 | ) |

[0000936395-15-000024:notes:95]
[same as prior period, unchanged from 0000936395-14-000051:notes:62]

[0000936395-15-000024:notes:96]
|  | Quarter Ended January 31, |
|  | 2014 |  | 2015 |
| Shares underlying stock options and restricted stock units | 3,412 |  |  | 3,899 |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | 9,198 |  |  | 9,198 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | 13,108 |  |  | 13,108 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,355 |  |  | 17,355 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 52,271 |  |  | 52,758 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-15-000024:notes:97]
[same as prior period, unchanged from 0000936395-14-000051:notes:64]

[0000936395-15-000024:notes:98]
|  | January 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 411,477 |  |  | $ | — |  |  | $ | — |  |  | $ | 411,477 |  |
| U.S. government obligations | — |  |  | 170,321 |  |  | — |  |  | 170,321 |  |
| Commercial paper | — |  |  | 94,981 |  |  | — |  |  | 94,981 |  |
| Foreign currency forward contracts | — |  |  | 654 |  |  | — |  |  | 654 |  |
| Total assets measured at fair value | $ | 411,477 |  |  | $ | 265,956 |  |  | $ | — |  |  | $ | 677,433 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 5,241 |  |  | $ | — |  |  | $ | 5,241 |  |
| Forward starting interest rate swap | — |  |  | 4,648 |  |  | — |  |  | 4,648 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,889 |  |  | $ | — |  |  | $ | 9,889 |  |

[0000936395-15-000024:notes:99]
|  | October 31, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 440,013 |  |  | $ | — |  |  | $ | — |  |  | $ | 440,013 |  |
| U.S. government obligations | — |  |  | 160,268 |  |  | — |  |  | 160,268 |  |
| Commercial paper | — |  |  | 89,989 |  |  | — |  |  | 89,989 |  |
| Foreign currency forward contracts | — |  |  | 1,561 |  |  | — |  |  | 1,561 |  |
| Total assets measured at fair value | $ | 440,013 |  |  | $ | 251,818 |  |  | $ | — |  |  | $ | 691,831 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 200 |  |  | $ | — |  |  | $ | 200 |  |
| Forward starting interest rate swap | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,283 |  |  | $ | — |  |  | $ | 2,283 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-15-000024:notes:100]
[same as prior period, unchanged from 0000936395-14-000051:notes:68]

[0000936395-15-000024:notes:101]
|  | January 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 411,477 |  |  | $ | 64,995 |  |  | $ | — |  |  | $ | 476,472 |  |
| Short-term investments | — |  |  | 145,154 |  |  | — |  |  | 145,154 |  |
| Prepaid expenses and other | — |  |  | 654 |  |  | — |  |  | 654 |  |
| Long-term investments | — |  |  | 55,153 |  |  | — |  |  | 55,153 |  |
| Total assets measured at fair value | $ | 411,477 |  |  | $ | 265,956 |  |  | $ | — |  |  | $ | 677,433 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 5,241 |  |  | $ | — |  |  | $ | 5,241 |  |
| Other long-term obligations | — |  |  | 4,648 |  |  | — |  |  | 4,648 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,889 |  |  | $ | — |  |  | $ | 9,889 |  |

[0000936395-15-000024:notes:102]
|  | October 31, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 440,013 |  |  | $ | 59,995 |  |  | $ | — |  |  | $ | 500,008 |  |
| Short-term investments | — |  |  | 140,205 |  |  | — |  |  | 140,205 |  |
| Prepaid expenses and other | — |  |  | 1,561 |  |  | — |  |  | 1,561 |  |
| Long-term investments | — |  |  | 50,057 |  |  | — |  |  | 50,057 |  |
| Total assets measured at fair value | $ | 440,013 |  |  | $ | 251,818 |  |  | $ | — |  |  | $ | 691,831 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 200 |  |  | $ | — |  |  | $ | 200 |  |
| Other long-term obligations | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,283 |  |  | $ | — |  |  | $ | 2,283 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-15-000024:notes:103]
[same as prior period, unchanged from 0000936395-14-000051:notes:70]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-15-000024:notes:104]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-15-000024:notes:105]
[same as prior period, unchanged from 0000936395-14-000051:notes:75]


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-15-000024:notes:106]
[same as prior period, unchanged from 0000936395-14-000051:notes:77]

[0000936395-15-000024:notes:107]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2008 through 2013 and in Canada for 2010 through 2012. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2011), United Kingdom (2012), Canada (2009) and India (2008). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-15-000024:notes:108]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and any expansion requirements.

[0000936395-15-000024:notes:109]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena's net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena's net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-15-000024:notes:110]
[same as prior period, unchanged from 0000936395-14-000051:notes:81]

[0000936395-15-000024:notes:111]
[same as prior period, unchanged from 0000936395-14-000051:notes:82]

[0000936395-15-000024:notes:112]
|  | October 31, 2014 |  | January 31, 2015 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 417,833 |  |  | $ | (351,929 | ) |  | $ | 65,904 |  |  | $ | 417,833 |  |  | $ | (358,678 | ) |  | $ | 59,155 |  |
| Patents and licenses | 46,538 |  |  | (45,908 | ) |  | 630 |  |  | 46,538 |  |  | (45,949 | ) |  | 589 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 323,573 |  |  | (261,430 | ) |  | 62,143 |  |  | 323,573 |  |  | (267,859 | ) |  | 55,714 |  |
| Total other intangible assets | $ | 787,944 |  |  | $ | (659,267 | ) |  | $ | 128,677 |  |  | $ | 787,944 |  |  | $ | (672,486 | ) |  | $ | 115,458 |  |

[0000936395-15-000024:notes:113]
The amortization of finite-lived other intangible assets was $16.9 million and $13.2 million for the first three months of fiscal 2014 and 2015, respectively. Expected future amortization of finite-lived other intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-15-000024:notes:114]
| Period ended October 31, |  |
| 2015 (remaining nine months) | $ | 39,659 |  |
| 2016 | 52,879 |  |
| 2017 | 22,783 |  |
| 2018 | 137 |  |
|  | $ | 115,458 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-15-000024:notes:115]
[same as prior period, unchanged from 0000936395-14-000051:notes:86]

[0000936395-15-000024:notes:116]
[same as prior period, unchanged from 0000936395-14-000051:notes:87]

[0000936395-15-000024:notes:117]
|  | October 31, 2014 |  | January 31, 2015 |
| Raw materials | $ | 64,853 |  |  | $ | 53,920 |  |
| Work-in-process | 8,371 |  |  | 9,347 |  |
| Finished goods | 165,799 |  |  | 159,587 |  |
| Deferred cost of goods sold | 75,763 |  |  | 70,244 |  |
|  | 314,786 |  |  | 293,098 |  |
| Provision for excess and obsolescence | (60,126 | ) |  | (51,980 | ) |
|  | $ | 254,660 |  |  | $ | 241,118 |  |

[0000936395-15-000024:notes:118]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first three months of fiscal 2015, Ciena recorded a provision for excess and obsolescence of $5.8 million, primarily related to the discontinuance of certain parts and components used in the manufacture of its Converged Packet Optical products and a decrease in the forecasted demand for both its legacy, stand-alone WDM and SONET/SDH-based transport platforms and its 5410 Service Aggregation Switch. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-15-000024:notes:119]
[same as prior period, unchanged from 0000936395-14-000051:notes:91]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-15-000024:notes:120]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and Ciena's intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-15-000024:notes:121]
The following table summarizes final legal maturities of debt investments at January 31, 2015 (in thousands):

[0000936395-15-000024:notes:122]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 145,115 |  |  | $ | 145,154 |  |
| Due in 1-2 years | 55,085 |  |  | 55,153 |  |
|  | $ | 200,200 |  |  | $ | 200,307 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-15-000024:notes:123]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-15-000024:notes:124]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-15-000024:notes:125]
|  | January 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 115,129 |  |  | $ | 39 |  |  | — |  |  | $ | 115,168 |  |
| Included in long-term investments | 55,085 |  |  | 68 |  |  | — |  |  | 55,153 |  |
|  | $ | 170,214 |  |  | $ | 107 |  |  | $ | — |  |  | $ | 170,321 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,986 |  |  | — |  |  | — |  |  | 29,986 |  |
|  | $ | 29,986 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,986 |  |

[0000936395-15-000024:notes:126]
|  | October 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,182 |  |  | $ | 29 |  |  | $ | — |  |  | $ | 110,211 |  |
| Included in long-term investments | 50,016 |  |  | 41 |  |  | — |  |  | 50,057 |  |
|  | $ | 160,198 |  |  | $ | 70 |  |  | $ | — |  |  | $ | 160,268 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,994 |  |  | — |  |  | — |  |  | 29,994 |  |
|  | $ | 29,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,994 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-15-000024:notes:127]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-15-000024:notes:128]
[same as prior period, unchanged from 0000936395-14-000051:notes:102]

[0000936395-15-000024:notes:129]
As of October 31, 2014, there were no individual customers that accounted for greater than 10% of net accounts receivable. As of January 31, 2015, one customer accounted for 17.1% of net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. Allowance for doubtful accounts was $2.1 million and $2.0 million as of October 31, 2014 and January 31, 2015, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-15-000024:notes:130]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its Consolidated Financial Statements and disclosures.

[0000936395-15-000024:notes:131]
In August 2014, FASB issued ASU No. 2014-15, Disclosure of Uncertainties about an Entity's Ability to Continue as a Going Concern. ASU 2014-15 requires management to evaluate and provide related disclosures, at each annual or interim reporting period, whether there are conditions or events that exist that raise substantial doubt about an entity's ability to continue as a going concern within one year after the date the financial statements are issued. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. The adoption of this accounting standard update is not expected to have a material effect on Ciena's Consolidated Financial Statements and disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-15-000024:notes:132]
[same as prior period, unchanged from 0000936395-14-000051:notes:107]

[0000936395-15-000024:notes:133]
The interim financial statements included herein for Ciena Corporation (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with generally accepted accounting principles ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2014 was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2014.

[0000936395-15-000024:notes:134]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October of each year. Fiscal 2014 and 2015 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-15-000024:notes:135]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-15-000024:notes:136]
|  | October 31, 2014 |  | January 31, 2015 |
| Income tax liability | $ | 14,342 |  |  | $ | 14,110 |  |
| Deferred tenant allowance | 10,839 |  |  | 10,576 |  |
| Straight-line rent | 5,174 |  |  | 5,330 |  |
| Capital lease obligations | 4,589 |  |  | 3,105 |  |
| Forward starting interest rate swap | 2,083 |  |  | 4,648 |  |
| Other | 8,363 |  |  | 6,827 |  |
|  | $ | 45,390 |  |  | $ | 44,596 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-15-000024:notes:137]
INTEREST AND OTHER INCOME (LOSS), NET

[0000936395-15-000024:notes:138]
The components of interest and other income (loss), net, were as follows (in thousands):

[0000936395-15-000024:notes:139]
|  | Quarter Ended January 31, |
|  | 2014 |  | 2015 |
| Interest income | $ | 78 |  |  | $ | 218 |  |
| Change in fair value of embedded derivative | (1,090 | ) |  | — |  |
| Gain (loss) on non-hedge designated foreign currency forward contracts | 1,353 |  |  | (4,350 | ) |
| Foreign currency exchange losses | (5,915 | ) |  | (3,652 | ) |
| Other | (424 | ) |  | (449 | ) |
| Interest and other income (loss), net | $ | (5,998 | ) |  | $ | (8,233 | ) |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-15-000024:notes:140]
[same as prior period, unchanged from 0000936395-14-000051:notes:110]

[0000936395-15-000024:notes:141]
[same as prior period, unchanged from 0000936395-14-000051:notes:111]

[0000936395-15-000024:notes:142]
|  | October 31, 2014 |  | January 31, 2015 |
| Equipment, furniture and fixtures | $ | 383,059 |  |  | $ | 372,153 |  |
| Leasehold improvements | 46,354 |  |  | 45,969 |  |
|  | 429,413 |  |  | 418,122 |  |
| Accumulated depreciation and amortization | (302,781 | ) |  | (298,719 | ) |
|  | $ | 126,632 |  |  | $ | 119,403 |  |

[0000936395-15-000024:notes:143]
The total of depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements, was $11.4 million and $11.3 million for the first three months of fiscal 2014 and 2015, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-15-000024:notes:144]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment, furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-15-000024:notes:145]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from its customers. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer, which could negatively affect its results of operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-15-000024:notes:146]
[same as prior period, unchanged from 0000936395-14-000051:notes:118]

[0000936395-15-000024:notes:147]
|  | Quarter Ended January 31, |
|  | 2014 |  | 2015 |
| Segment profit: |  |  |  |
| Converged Packet Optical | $ | 78,698 |  |  | $ | 82,657 |  |
| Packet Networking | 385 |  |  | 6,531 |  |
| Optical Transport | 15,650 |  |  | 5,886 |  |
| Software and Services | 29,621 |  |  | 34,460 |  |
| Total segment profit | 124,354 |  |  | 129,534 |  |
| Less: Non-performance operating expenses |  |  |  |
| Selling and marketing | 78,348 |  |  | 76,712 |  |
| General and administrative | 30,097 |  |  | 29,553 |  |
| Amortization of intangible assets | 12,439 |  |  | 11,019 |  |
| Restructuring costs | 115 |  |  | 8,085 |  |
| Add: Other non-performance financial items |  |  |  |
| Interest expense and other income (loss), net | (17,026 | ) |  | (21,894 | ) |
| Less: Provision for income taxes | 2,265 |  |  | 1,050 |  |
| Consolidated net loss | $ | (15,936 | ) |  | $ | (18,779 | ) |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-15-000024:notes:148]
[same as prior period, unchanged from 0000936395-14-000051:notes:120]

[0000936395-15-000024:notes:149]
|  | Quarter Ended January 31, |
|  | 2014 |  | 2015 |
| Revenue: |  |  |  |
| Converged Packet Optical | $ | 333,401 |  |  | $ | 336,560 |  |
| Packet Networking | 51,709 |  |  | 54,983 |  |
| Optical Transport | 40,097 |  |  | 22,339 |  |
| Software and Services | 108,496 |  |  | 115,280 |  |
| Consolidated revenue | $ | 533,703 |  |  | $ | 529,162 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-15-000024:notes:150]
[same as prior period, unchanged from 0000936395-14-000051:notes:124]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-15-000024:notes:151]
[same as prior period, unchanged from 0000936395-14-000051:notes:125]

[0000936395-15-000024:notes:152]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2015 (in thousands):

[0000936395-15-000024:notes:153]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2014 | $ | 181 |  |  | $ | 1,134 |  |  | $ | 1,315 |  |
| Additional liability recorded | 8,081 |  | (a) | 4 |  |  | 8,085 |  |
| Cash payments | (4,768 | ) |  | (206 | ) |  | (4,974 | ) |
| Balance at January 31, 2015 | $ | 3,494 |  |  | $ | 932 |  |  | $ | 4,426 |  |
| Current restructuring liabilities | $ | 3,494 |  |  | $ | 446 |  |  | $ | 3,940 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 486 |  |  | $ | 486 |  |

[0000936395-15-000024:notes:154]
(a) During the fiscal quarter ended January 31, 2015, Ciena recorded a charge of $8.1 million of severance and other employee-related costs associated with a global workforce reduction of approximately 125 employees. This reduction was related to an organizational realignment and the reallocation of personnel resources toward strategic growth areas of the business.

[0000936395-15-000024:notes:155]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2014 (in thousands):

[0000936395-15-000024:notes:156]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2013 | $ | 80 |  |  | $ | 1,936 |  |  | $ | 2,016 |  |
| Additional liability recorded | 106 |  |  | 9 |  |  | 115 |  |
| Cash payments | (136 | ) |  | (77 | ) |  | (213 | ) |
| Balance at January 31, 2014 | $ | 50 |  |  | $ | 1,868 |  |  | $ | 1,918 |  |
| Current restructuring liabilities | $ | 50 |  |  | $ | 629 |  |  | $ | 679 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,239 |  |  | $ | 1,239 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-15-000024:notes:157]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-15-000024:notes:158]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of revenue recognized using the percentage-of-completion method for the three months ended January 31, 2014 and January 31, 2015 were 5.1% and 1.0%, respectively.

[0000936395-15-000024:notes:159]
[same as prior period, unchanged from 0000936395-14-000051:notes:133]

[0000936395-15-000024:notes:160]
[same as prior period, unchanged from 0000936395-14-000051:notes:134]

[0000936395-15-000024:notes:161]
[same as prior period, unchanged from 0000936395-14-000051:notes:135]

[0000936395-15-000024:notes:162]
[same as prior period, unchanged from 0000936395-14-000051:notes:136]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-15-000024:notes:163]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-15-000024:notes:164]
|  | October 31, 2014 |  | January 31, 2015 |
| Compensation, payroll related tax and benefits | 82,207 |  |  | 91,017 |  |
| Warranty | 55,997 |  |  | 53,382 |  |
| Vacation | 35,126 |  |  | 31,533 |  |
| Capital lease obligations | 7,788 |  |  | 6,229 |  |
| Interest payable | 6,409 |  |  | 8,572 |  |
| Other | 89,081 |  |  | 99,251 |  |
|  | $ | 276,608 |  |  | $ | 289,984 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-15-000024:notes:165]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2015:


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-15-000024:notes:166]
[same as prior period, unchanged from 0000936395-14-000051:notes:152]

[0000936395-15-000024:notes:167]
|  | October 31, 2014 |  | January 31, 2015 |
| Maintenance spares, net | $ | 54,101 |  |  | $ | 65,201 |  |
| Deferred debt issuance costs, net | 15,160 |  |  | 14,012 |  |
| Other | 4,815 |  |  | 5,561 |  |
|  | $ | 74,076 |  |  | $ | 84,774 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-15-000024:notes:168]
[same as prior period, unchanged from 0000936395-14-000051:notes:156]

[0000936395-15-000024:notes:169]
| Three months ended | Beginning |  |  |  |  |  | Ending |
| January 31, | Balance |  | Provisions |  | Settlements |  | Balance |
| 2014 | $ | 56,303 |  |  | 7,974 |  |  | (6,188 | ) |  | $ | 58,089 |  |
| 2015 | $ | 55,997 |  |  | 2,293 |  |  | (4,908 | ) |  | $ | 53,382 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-15-000024:notes:170]
[same as prior period, unchanged from 0000936395-14-000051:notes:164]

[0000936395-15-000024:notes:171]
|  | October 31, 2014 |  | January 31, 2015 |
| United States | $ | 73,420 |  |  | $ | 71,971 |  |
| Canada | 42,015 |  |  | 36,432 |  |
| Other International | 11,197 |  |  | 11,000 |  |
| Total | $ | 126,632 |  |  | $ | 119,403 |  |

[0000936395-15-000024:notes:172]
[same as prior period, unchanged from 0000936395-14-000051:notes:162]

[0000936395-15-000024:notes:173]
|  | Quarter Ended January 31, |
|  | 2014 |  | 2015 |
| North America | 355,848 |  |  | 331,535 |  |
| EMEA | 88,720 |  |  | 111,006 |  |
| CALA | 52,680 |  |  | 42,742 |  |
| APAC | 36,455 |  |  | 43,879 |  |
| Total | $ | 533,703 |  |  | $ | 529,162 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-15-000024:notes:174]
[same as prior period, unchanged from 0000936395-14-000051:notes:166]

[0000936395-15-000024:notes:175]
[same as prior period, unchanged from 0000936395-14-000051:notes:167]

[0000936395-15-000024:notes:176]
[same as prior period, unchanged from 0000936395-14-000051:notes:168]

[0000936395-15-000024:notes:177]
| • | Converged Packet Optical —includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-15-000024:notes:178]
| • | Packet Networking — includes Ciena's 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This segment also includes Ciena’s 8700 Packetwave Platform and Ciena's Ethernet packet configuration for the 5410 Service Aggregation Switch. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-15-000024:notes:179]
| • | Optical Transport — includes the 4200 Advanced Services Platform, Corestream® Agility Optical Transport System, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. This segment includes sales from SONET/SDH, transport and data networking products, as well as certain enterprise-oriented transport solutions that support storage and LAN extension, interconnection of data centers, and virtual private networks. This segment also includes operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-15-000024:notes:180]
| • | Software and Services — includes Ciena's Agility software portfolio, which includes a SDN multilayer WAN controller, NFV platform, and network level software applications for enabling on-demand, high-bandwidth WAN services delivered in an open network ecosystem. This segment also includes the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager and Optical Suite Release. This segment includes a broad range of services for consulting and network design, installation and deployment, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-15-000024:notes:181]
Ciena's long-lived assets, including equipment, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 31, 2015, equipment, furniture and fixtures totaling $119.4 million primarily support asset groups within Ciena's Converged Packet Optical, Packet Networking, and Software and Services segments and support Ciena's unallocated selling and general and administrative activities. As of January 31, 2015, all of Ciena's finite-lived intangible assets totaling $115.5 million were assigned to asset groups within Ciena's Converged Packet Optical segment. As of January 31, 2015, all of the maintenance spares totaling $65.2 million were assigned to asset groups within Ciena's Software and Services segment.

[0000936395-15-000024:notes:182]
[same as prior period, unchanged from 0000936395-14-000051:notes:174]

[0000936395-15-000024:notes:183]
[same as prior period, unchanged from 0000936395-14-000051:notes:175]

[0000936395-15-000024:notes:184]
Segment profit is determined based on internal performance measures used by the chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; restructuring costs; interest and other income (loss), net; interest expense; and provisions for income taxes.

[0000936395-15-000024:notes:185]
[same as prior period, unchanged from 0000936395-14-000051:notes:177]

[0000936395-15-000024:notes:186]
Ciena's operating segments each engage in business across four geographic regions: North America; Europe, Middle East and Africa (“EMEA”); Asia Pacific (“APAC”); and Caribbean and Latin America ("CALA"). North America includes only activities in the United States and Canada. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena's delivery of products and performance of services. For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-15-000024:notes:187]
North America includes $317.4 million and $297.7 million of United States revenue for fiscal quarters ended January 31, 2014 and 2015, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-15-000024:notes:188]
[same as prior period, unchanged from 0000936395-14-000051:notes:179]

[0000936395-15-000024:notes:189]
AT&T accounted for greater than 10% of Ciena's revenue for both fiscal quarters ended January 31, 2014 and 2015 and the total revenue was $100.5 million and $116.6 million, respectively. AT&T purchased products and services from each of Ciena's operating segments.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-15-000024:notes:190]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Converged Packet Optical, (ii) Packet Networking, (iii) Optical Transport, and (iv) Software and Services.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-15-000024:notes:191]
[same as prior period, unchanged from 0000936395-14-000051:notes:182]

[0000936395-15-000024:notes:192]
[same as prior period, unchanged from 0000936395-14-000051:notes:183]

[0000936395-15-000024:notes:193]
[same as prior period, unchanged from 0000936395-14-000051:notes:184]

[0000936395-15-000024:notes:194]
accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-15-000024:notes:195]
Cash and Cash Equivalents

[0000936395-15-000024:notes:196]
Investments

[0000936395-15-000024:notes:197]
Inventories

[0000936395-15-000024:notes:198]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Converged Packet Optical, (ii) Packet Networking, (iii) Optical Transport, and (iv) Software and Services. See Note 19 below.

[0000936395-15-000024:notes:199]
Long-lived Assets

[0000936395-15-000024:notes:200]
Equipment, Furniture and Fixtures and Internal Use Software

[0000936395-15-000024:notes:201]
[same as prior period, unchanged from 0000936395-14-000051:notes:186]

[0000936395-15-000024:notes:202]
[same as prior period, unchanged from 0000936395-14-000051:notes:187]

[0000936395-15-000024:notes:203]
[same as prior period, unchanged from 0000936395-14-000051:notes:188]

[0000936395-15-000024:notes:204]
[same as prior period, unchanged from 0000936395-14-000051:notes:190]

[0000936395-15-000024:notes:205]
Revenue Recognition

[0000936395-15-000024:notes:206]
[same as prior period, unchanged from 0000936395-14-000051:notes:194]

[0000936395-15-000024:notes:207]
[same as prior period, unchanged from 0000936395-14-000051:notes:195]

[0000936395-15-000024:notes:208]
Accounts Receivable, Net

[0000936395-15-000024:notes:209]
Research and Development

[0000936395-15-000024:notes:210]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, cost of prototype equipment, consulting and third party services, depreciation, facility costs and information technology.

[0000936395-15-000024:notes:211]
[same as prior period, unchanged from 0000936395-14-000051:notes:196]

[0000936395-15-000024:notes:212]
Ciena accounts for proceeds from government grants as a reduction of operating expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that the grant proceeds will be received. Grant benefits are recorded to the line item in the Condensed Consolidated Statement of Operations to which the grant activity relates. See Note 20 below.

[0000936395-15-000024:notes:213]
Advertising Costs

[0000936395-15-000024:notes:214]
Legal Costs

[0000936395-15-000024:notes:215]
[same as prior period, unchanged from 0000936395-14-000051:notes:198]

[0000936395-15-000024:notes:216]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon its determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 18 below.

[0000936395-15-000024:notes:217]
Income Taxes

[0000936395-15-000024:notes:218]
Loss Contingencies

[0000936395-15-000024:notes:219]
[same as prior period, unchanged from 0000936395-14-000051:notes:200]

[0000936395-15-000024:notes:220]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and Term Loan, see Note 15 below.

[0000936395-15-000024:notes:221]
[same as prior period, unchanged from 0000936395-14-000051:notes:202]

[0000936395-15-000024:notes:222]
[same as prior period, unchanged from 0000936395-14-000051:notes:203]

[0000936395-15-000024:notes:223]
[same as prior period, unchanged from 0000936395-14-000051:notes:204]

[0000936395-15-000024:notes:224]
[same as prior period, unchanged from 0000936395-14-000051:notes:205]

[0000936395-15-000024:notes:225]
[same as prior period, unchanged from 0000936395-14-000051:notes:206]

[0000936395-15-000024:notes:226]
Restructuring

[0000936395-15-000024:notes:227]
Foreign Currency

[0000936395-15-000024:notes:228]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.

[0000936395-15-000024:notes:229]
Derivatives

[0000936395-15-000024:notes:230]
See Notes 6 and 13 below.

[0000936395-15-000024:notes:231]
Computation of Net Income (Loss) per Share

[0000936395-15-000024:notes:232]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 17 below.

[0000936395-15-000024:notes:233]
[same as prior period, unchanged from 0000936395-14-000051:notes:207]

[0000936395-15-000024:notes:234]
[same as prior period, unchanged from 0000936395-14-000051:notes:208]

[0000936395-15-000024:notes:235]
Newly Issued Accounting Standards - Not Yet Effective


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-15-000024:notes:236]
[same as prior period, unchanged from 0000936395-14-000051:notes:209]

[0000936395-15-000024:notes:237]
Deferred debt issuance costs relate to our convertible notes payable (described in Note 15 below), Term Loan (described in Note 15 below) and our ABL Credit Facility (described in Note 16 below). Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the related debt. The amortization of deferred debt issuance costs is included in interest expense, and was $1.2 million and $1.3 million during the first three months of fiscal 2014 and fiscal 2015, respectively.

[0000936395-15-000024:notes:238]
The decrease in the first quarter of fiscal 2015 warranty provision was due to lower failure rates and reduced component and labor repair costs.
