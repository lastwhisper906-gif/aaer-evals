# CIEN note change history — 0000936395-14-000051 → 0000936395-15-000024


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-03-12):
[0000936395-15-000024:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2015, Ciena has recorded a CAD$24.6 million benefit to date, as a reduction in research and development expenses. As of January 31, 2015, the amount receivable from this grant was CAD$4.6 million.
  (was, 2014-09-09, similarity 0.7245):
[0000936395-14-000051:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of C$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Ciena anticipates receiving disbursements, approximating C$5.0 million per fiscal year, over the period above. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2014, Ciena has recorded a C$21.5 million benefit to date as a reduction in research and development expenses, of which C$5.1 million was recorded in the first nine months of fiscal 2014. As of July 31, 2014, amounts receivable from this grant were C$1.5 million.

- changed (2015-03-12):
[0000936395-15-000024:note_history:2]
As of October 31, 2014 and January 31, 2015, Ciena had accrued liabilities of $1.1 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 and 2010 related to income taxes. This contingency has been reported as a component of other long-term liabilities. Although Ciena estimates that it could be exposed to possible losses of up to $5.5 million, it has not accrued a liability of such amount as of January 31, 2015. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to these assessments. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.
  (was, 2014-09-09, similarity 0.8803):
[0000936395-14-000051:note_history:2]
As of October 31, 2013 and July 31, 2014, Ciena had accrued liabilities of $0.4 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 related to income taxes. This contingency has been reported as a component of other long-term liabilities. During February 2014, Ciena received a final audit assessment notice from the India tax authorities with respect to this matter. Ciena has filed an appeal citing deficiencies in this assessment. Although Ciena estimates that it could be exposed to possible losses of up to $2.8 million, it has not accrued a liability of such amount as of July 31, 2014. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to this assessment. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- removed (2015-03-12):
[0000936395-14-000051:note_history:3]
Loss Contingencies


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-03-12):
[0000936395-15-000024:note_history:4]
accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.
  (was, 2014-09-09, similarity 0.9925):
[0000936395-14-000051:note_history:4]
accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, share-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

- changed (2015-03-12):
[0000936395-15-000024:note_history:5]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and Ciena's intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.
  (was, 2014-09-09, similarity 0.9842):
[0000936395-14-000051:note_history:5]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and its intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

- changed (2015-03-12):
[0000936395-15-000024:note_history:6]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment, furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.
  (was, 2014-09-09, similarity 0.9982):
[0000936395-14-000051:note_history:6]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment, furniture and fixtures, and the shorter of useful life or lease term for leasehold improvements.

- changed (2015-03-12):
[0000936395-15-000024:note_history:7]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.
  (was, 2014-09-09, similarity 0.9956):
[0000936395-14-000051:note_history:7]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is generally deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

- changed (2015-03-12):
[0000936395-15-000024:note_history:8]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of revenue recognized using the percentage-of-completion method for the three months ended January 31, 2014 and January 31, 2015 were 5.1% and 1.0%, respectively.
  (was, 2014-09-09, similarity 0.8737):
[0000936395-14-000051:note_history:8]
Ciena applies the percentage-of-completion method to long-term arrangements where it is required to undertake significant production, customizations or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are accumulated in the contracts in progress account included in accounts receivable, net. Billings in excess of revenues recognized to date on these contracts are recorded within deferred revenue.

- changed (2015-03-12):
[0000936395-15-000024:note_history:9]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from its customers. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer, which could negatively affect its results of operations.
  (was, 2014-09-09, similarity 0.9872):
[0000936395-14-000051:note_history:9]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from its customers. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts, which would negatively affect its results of operations.

- changed (2015-03-12):
[0000936395-15-000024:note_history:10]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon its determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 18 below.
  (was, 2014-09-09, similarity 0.9787):
[0000936395-14-000051:note_history:10]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are ultimately expected to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon its determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 16 below.

- changed (2015-03-12):
[0000936395-15-000024:note_history:11]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2008 through 2013 and in Canada for 2010 through 2012. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2011), United Kingdom (2012), Canada (2009) and India (2008). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.
  (was, 2014-09-09, similarity 0.9493):
[0000936395-14-000051:note_history:11]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2008 through 2012 and in Canada for 2010 through 2012. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2011), United Kingdom (2012), Canada (2009) and India (2008). However, limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense. All of the uncertain tax positions, if recognized, would decrease the effective income tax rate.

- changed (2015-03-12):
[0000936395-15-000024:note_history:12]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and any expansion requirements.
  (was, 2014-09-09, similarity 0.8262):
[0000936395-14-000051:note_history:12]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and will be used to fund foreign operations, capital expenditures and any expansion requirements.

- changed (2015-03-12):
[0000936395-15-000024:note_history:13]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena's net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena's net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.
  (was, 2014-09-09, similarity 0.9968):
[0000936395-14-000051:note_history:13]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the tax law “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena's net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena's net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.

- changed (2015-03-12):
[0000936395-15-000024:note_history:14]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period of more than 60 days, which are accrued over the service period. See Note 3 below.
  (was, 2014-09-09, similarity 0.8251):
[0000936395-14-000051:note_history:14]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. GAAP requires that a liability for the cost associated with an exit or disposal activity be recognized in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period of more than 60 days, which are accrued over the service period. See Note 3 below.

- changed (2015-03-12):
[0000936395-15-000024:note_history:15]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.
  (was, 2014-09-09, similarity 0.8656):
[0000936395-14-000051:note_history:15]
Some of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. Interest and other income (loss), net reflects a net loss on foreign currency re-measurement and exchange rate changes of $9.2 million for the nine months ended July 31, 2013 and a net gain of $1.0 million for the nine months ended July 31, 2014.

- changed (2015-03-12):
[0000936395-15-000024:note_history:16]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") includes a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature was recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.
  (was, 2014-09-09, similarity 0.7633):
[0000936395-14-000051:note_history:16]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") include a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature is recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. Interest and other income (loss), net reflects an increase in fair value of $2.7 million for the nine months ended July 31, 2013 and a reduction in fair value of $2.7 million for the nine months ended July 31, 2014.

- changed (2015-03-12):
[0000936395-15-000024:note_history:17]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. During fiscal 2014, Ciena also entered into interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its Term Loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.
  (was, 2014-09-09, similarity 0.7145):
[0000936395-14-000051:note_history:17]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less and are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the forward contract has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and upon the occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statements of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net.

- changed (2015-03-12):
[0000936395-15-000024:note_history:18]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations.
  (was, 2014-09-09, similarity 0.7303):
[0000936395-14-000051:note_history:18]
From time to time, Ciena uses foreign currency forwards to hedge certain balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. Interest and other income (loss), net reflects a gain of $0.9 million for the nine months ended July 31, 2013 and a loss of $11.7 million related to foreign currency forward contracts for the nine months ended July 31, 2014. See Note 12 below.

- added (2015-03-12):
[0000936395-15-000024:note_history:19]
See Notes 6 and 13 below.

- changed (2015-03-12):
[0000936395-15-000024:note_history:20]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 17 below.
  (was, 2014-09-09, similarity 0.9948):
[0000936395-14-000051:note_history:20]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 15 below.

- changed (2015-03-12):
[0000936395-15-000024:note_history:21]
Newly Issued Accounting Standards - Not Yet Effective
  (was, 2014-09-09, similarity 0.7674):
[0000936395-14-000051:note_history:21]
Newly Issued Accounting Standards

- changed (2015-03-12):
[0000936395-15-000024:note_history:22]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its Consolidated Financial Statements and disclosures.
  (was, 2014-09-09, similarity 0.9844):
[0000936395-14-000051:note_history:22]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its condensed consolidated financial statements.

- added (2015-03-12):
[0000936395-15-000024:note_history:23]
In August 2014, FASB issued ASU No. 2014-15, Disclosure of Uncertainties about an Entity's Ability to Continue as a Going Concern. ASU 2014-15 requires management to evaluate and provide related disclosures, at each annual or interim reporting period, whether there are conditions or events that exist that raise substantial doubt about an entity's ability to continue as a going concern within one year after the date the financial statements are issued. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. The adoption of this accounting standard update is not expected to have a material effect on Ciena's Consolidated Financial Statements and disclosures.

- removed (2015-03-12):
[0000936395-14-000051:note_history:24]
In February 2013, the Financial Accounting Standards Board ("FASB") issued an accounting standard update to require reclassification adjustments from other comprehensive income to be presented either in the financial statements or in the notes to the financial statements. This accounting standard update was effective for Ciena beginning in the first quarter of fiscal 2014. Ciena has determined that reclassifications from other comprehensive income to net income are immaterial for separate financial statement presentation.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: title_similarity, score: 1.0

- added (2015-03-12):
[0000936395-15-000024:note_history:25]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2015:

- changed (2015-03-12):
[0000936395-15-000024:note_history:26]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 247,640 |  |  | $ | 247,817 |  |
|  |  | $ | 247,640 |  |  | $ | 247,817 |  |
  (was, 2014-09-09, similarity 0.9832):
[0000936395-14-000051:note_history:26]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 248,763 |  |  | $ | 249,375 |  |
|  |  | $ | 248,763 |  |  | $ | 249,375 |  |

- changed (2015-03-12):
[0000936395-15-000024:note_history:27]
Outstanding Convertible Notes Payable
  (was, 2014-09-09, similarity 0.6296):
[0000936395-14-000051:note_history:27]
Convertible Notes

- changed (2015-03-12):
[0000936395-15-000024:note_history:28]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of January 31, 2015:
  (was, 2014-09-09, similarity 0.9519):
[0000936395-14-000051:note_history:28]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 ("2020 Notes") were as follows as of July 31, 2014:

- changed (2015-03-12):
[0000936395-15-000024:note_history:29]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,520 |  |  | $ | 191,016 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 495,625 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 180,343 |  |  | 228,516 |  |
|  |  | $ | 1,217,863 |  |  | $ | 1,331,220 |  |
  (was, 2014-09-09, similarity 0.9902):
[0000936395-14-000051:note_history:29]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,605 |  |  | $ | 206,719 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 445,813 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 177,853 |  |  | 242,822 |  |
|  |  | $ | 1,215,458 |  |  | $ | 1,389,729 |  |

- removed (2015-03-12):
[0000936395-14-000051:note_history:30]
On July 15, 2014, Ciena entered into a Credit Agreement (the “Term Loan Credit Agreement”) which provides for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”). Ciena received proceeds from the Term Loan, net of original issue discount and debt issuance costs, of approximately $246 million.

- removed (2015-03-12):
[0000936395-14-000051:note_history:31]
The Term Loan bears interest at a rate equal to LIBOR (subject to a floor of 0.75%) plus an applicable margin of 3.00% and matures on July 15, 2019. The Term Loan Credit Agreement requires Ciena to make quarterly installment payments in aggregate amounts equal to 0.25% of the original principal amount of the Term Loan, with the balance of the Term Loan payable at maturity. The Term Loan Credit Agreement requires mandatory prepayments on the occurrence of certain customary events and, when the total secured net leverage ratio (as defined in the Term Loan Credit Agreement) is in excess of 2.50 to 1.00, the Term Loan Credit Agreement requires a mandatory prepayment of 50% of excess annual cash flow (as defined in the Term Loan Credit Agreement).

- removed (2015-03-12):
[0000936395-14-000051:note_history:32]
The Term Loan Credit Agreement contains customary covenants that limit, absent lender approval, the ability of Ciena to, among other things, incur additional debt, create liens and encumbrances, pay cash dividends, enter into certain acquisition transactions or transactions with affiliates, merge, dissolve, repay certain indebtedness, change the nature of Ciena’s business, make investments or dispose of assets.

- removed (2015-03-12):
[0000936395-14-000051:note_history:33]
The Term Loan Credit Agreement contains customary events of default including, among other things, failure to pay obligations when due, initiation of bankruptcy or insolvency proceedings, defaults on certain other indebtedness, change of control, incurrence of certain material judgments, violation of affirmative and negative covenants, and breaches of representations and warranties set forth in the Term Loan Credit Agreement. Upon an event of default, the administrative agent may, subject to various customary cure rights, require the immediate payment of all amounts outstanding and foreclose on collateral.

- removed (2015-03-12):
[0000936395-14-000051:note_history:34]
In connection with Ciena entering into the Term Loan Credit Agreement, Ciena and certain of its subsidiaries entered into a guaranty, a security agreement and a pledge agreement, each on customary terms. The Term Loan is secured by (i) second-priority security interests in the ABL Priority Collateral (as defined in Note 14 below), and (ii) first-priority security interests in substantially all other tangible and intangible assets including equipment, intercompany notes, intellectual property and material owned real property (the "Term Loan Priority Collateral").

- removed (2015-03-12):
[0000936395-14-000051:note_history:35]
The principal balance, unamortized discount and net carrying amount of the Term Loan was as follows as of July 31, 2014:


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-03-12):
[0000936395-15-000024:note_history:36]
As of the dates indicated, investments are comprised of the following (in thousands):
  (was, 2014-09-09, similarity 0.8718):
[0000936395-14-000051:note_history:36]
As of the dates indicated, short-term and long-term investments are comprised of the following (in thousands):

- changed (2015-03-12):
[0000936395-15-000024:note_history:37]
|  | January 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 115,129 |  |  | $ | 39 |  |  | — |  |  | $ | 115,168 |  |
| Included in long-term investments | 55,085 |  |  | 68 |  |  | — |  |  | 55,153 |  |
|  | $ | 170,214 |  |  | $ | 107 |  |  | $ | — |  |  | $ | 170,321 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,986 |  |  | — |  |  | — |  |  | 29,986 |  |
|  | $ | 29,986 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,986 |  |
  (was, 2014-09-09, similarity 0.6486):
[0000936395-14-000051:note_history:37]
|  | July 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 90,210 |  |  | $ | 42 |  |  | — |  |  | $ | 90,252 |  |
| Included in long-term investments | 65,043 |  |  | — |  |  | (24 | ) |  | 65,019 |  |
|  | $ | 155,253 |  |  | $ | 42 |  |  | $ | (24 | ) |  | $ | 155,271 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,998 |  |  | — |  |  | — |  |  | 29,998 |  |
|  | $ | 29,998 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,998 |  |

- changed (2015-03-12):
[0000936395-15-000024:note_history:38]
The following table summarizes final legal maturities of debt investments at January 31, 2015 (in thousands):
  (was, 2014-09-09, similarity 0.9756):
[0000936395-14-000051:note_history:38]
The following table summarizes final legal maturities of debt investments at July 31, 2014 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-03-12):
[0000936395-15-000024:note_history:39]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 247,640 |  |  | $ | 247,817 |  |
|  |  | $ | 247,640 |  |  | $ | 247,817 |  |
  (was, 2014-09-09, similarity 0.9832):
[0000936395-14-000051:note_history:39]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 248,763 |  |  | $ | 249,375 |  |
|  |  | $ | 248,763 |  |  | $ | 249,375 |  |

- changed (2015-03-12):
[0000936395-15-000024:note_history:40]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2015:
  (was, 2014-09-09, similarity 0.9573):
[0000936395-14-000051:note_history:40]
The principal balance, unamortized discount and net carrying amount of the Term Loan was as follows as of July 31, 2014:

- changed (2015-03-12):
[0000936395-15-000024:note_history:41]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,520 |  |  | $ | 191,016 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 495,625 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 180,343 |  |  | 228,516 |  |
|  |  | $ | 1,217,863 |  |  | $ | 1,331,220 |  |
  (was, 2014-09-09, similarity 0.9902):
[0000936395-14-000051:note_history:41]
|  |  | July 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,605 |  |  | $ | 206,719 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 494,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 445,813 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 177,853 |  |  | 242,822 |  |
|  |  | $ | 1,215,458 |  |  | $ | 1,389,729 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-03-12):
[0000936395-15-000024:note_history:42]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of January 31, 2015:
  (was, 2014-09-09, similarity 0.9519):
[0000936395-14-000051:note_history:42]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 ("2020 Notes") were as follows as of July 31, 2014:


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2015-03-12):
[0000936395-15-000024:note_history:43]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.
  (was, 2014-09-09, similarity 0.9956):
[0000936395-14-000051:note_history:43]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is generally deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

- changed (2015-03-12):
[0000936395-15-000024:note_history:44]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of revenue recognized using the percentage-of-completion method for the three months ended January 31, 2014 and January 31, 2015 were 5.1% and 1.0%, respectively.
  (was, 2014-09-09, similarity 0.8737):
[0000936395-14-000051:note_history:44]
Ciena applies the percentage-of-completion method to long-term arrangements where it is required to undertake significant production, customizations or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are accumulated in the contracts in progress account included in accounts receivable, net. Billings in excess of revenues recognized to date on these contracts are recorded within deferred revenue.

- removed (2015-03-12):
[0000936395-14-000051:note_history:45]
Revenue Recognition
