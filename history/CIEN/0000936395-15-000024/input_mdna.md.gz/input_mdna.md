# CIEN MD&A — 0000936395-15-000024


## mdna

[0000936395-15-000024:mdna:1]
[same as prior period, unchanged from 0000936395-14-000051:mdna:1]

[0000936395-15-000024:mdna:2]
Some of the statements contained in this quarterly report discuss future events or expectations, contain projections of results of operations or financial condition, changes in the markets for our products and services, or state other “forward-looking” information. Ciena’s “forward-looking” information is based on various factors and was derived using numerous assumptions. In some cases, you can identify these “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” "intends," “potential” or “continue” or the negative of those words and other comparable words. You should be aware that these statements only reflect our current predictions and beliefs. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially. Important factors that could cause our actual results to be materially different from the forward-looking statements are disclosed throughout this report, particularly in Item 1A “Risk Factors” of Part II of this report below. For a more complete understanding of the risks associated with an investment in Ciena’s securities, you should review these risk factors and the rest of this quarterly report in combination with the more detailed description of our business and management’s discussion and analysis of financial condition in our annual report on Form 10-K, which we filed with the Securities and Exchange Commission ("SEC") on December 19, 2014. Ciena undertakes no obligation to revise or update any forward-looking statements.

[0000936395-15-000024:mdna:3]
[same as prior period, unchanged from 0000936395-14-000051:mdna:3]

[0000936395-15-000024:mdna:4]
We are a network specialist focused on communications networking solutions that enable converged, next-generation architectures, optimized to create and deliver the broad array of high-bandwidth services relied upon by business and consumer end users. We provide equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks. These solutions enable network operators to adopt software-programmable network infrastructures that offer the on-demand experience required by end users of services and applications. At the same time, these solutions yield business and operational value for network operators.

[0000936395-15-000024:mdna:5]
Our Converged Packet Optical, Packet Networking, Optical Transport and Software products are used, individually or as part of an integrated solution, in networks operated by communications service providers, cable operators, Web-scale providers, governments, enterprises, research and education institutions and other network operators across the globe. Our products allow network operators to scale capacity, increase transmission speeds, allocate network traffic and adapt to changing end-user demands through rapid service creation and delivery. Our solutions also include network management and control software and network-level software applications that facilitate automation and efficient service delivery. To complement our hardware and software solutions, we offer a broad range of network transformation solutions and related support services that help our customers design, optimize, deploy, manage and maintain their networks.

[0000936395-15-000024:mdna:6]
The rapid proliferation of communications services and devices, together with increased mobility and growth in cloud-based services, have fundamentally affected the demands placed upon communications networks and how they are designed. Network operators also face a rapidly changing business environment that includes a shifting competitive landscape and challenges to existing business models. Our OPn Architecture, and the increased network scalability, flexibility and programmability that it enables, is designed to meet these challenges. Our OPn network approach allows for network-level software applications to control and configure the network dynamically, while flexible interfaces integrate computing, storage and network resources. This approach enables highly configurable infrastructures that can meet the "on-demand" requirements of end-users and the changing services they rely upon. By enhancing software programmability and control, enabling network functions virtually, and reducing required network elements, our OPn approach optimizes network infrastructures to connect content data centers, and users to such content. At the same time, our approach creates business and operational value for our customers by increasing scale at reduced cost and facilitating rapid introduction of new, revenue-generating service offerings. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in the "Strategy" section below.

[0000936395-15-000024:mdna:7]
Our quarterly reports on Form 10-Q, annual reports on Form 10-K, and current reports on Form 8-K filed with the SEC are available through the SEC's website at www.sec.gov or free of charge on our website as soon as reasonably practicable after we file these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the "Investors" section of our website at www.ciena.com. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us. Information contained on our website is not a part of this report.

[0000936395-15-000024:mdna:8]
[same as prior period, unchanged from 0000936395-14-000051:mdna:14]

[0000936395-15-000024:mdna:9]
The markets in which we sell our communications networking solutions have been subject to significant changes in recent years, including rapid growth in network traffic, technology convergence, increased mobility, and evolving cloud-based service offerings and end-user demands. These conditions have created market opportunities and challenges that have impacted how networks are designed, the diversity of network operator customers, and the competitive landscapes of network operators and the vendors that support them. Existing and emerging network operators are competing to distinguish their service offerings and rapidly introduce differentiated, revenue-generating services. At the same time, network operators continue to seek to manage the costs of their network and to ensure a profitable business model. These dynamics are driving technology convergence of network features, functions and layers, virtualization of certain network functions, and the adoption of software-based network control and programmability. We believe that these dynamics, and the need to adapt to changing business conditions, are creating an environment that will cause network operators to adopt infrastructures that are more open, programmable and automated. We also believe that these conditions will require vendors and network operators to leverage an open ecosystem of virtualized resources provided by a variety of third parties and will drive increased openness and interoperability of network infrastructures.

[0000936395-15-000024:mdna:10]
In recent periods, we have seen certain of our large service provider customers, including some in the U.S., take steps to constrain their capital expenditure budgets. This has adversely impacted segments of our market and the spending levels we have experienced from certain of these customers as compared to prior periods. During fiscal 2014, we were able to continue to grow revenue, in part, as a result of our strategy of focusing on certain higher growth segments of the network infrastructure market, combined with our efforts to diversify our customer base to include additional customer segments, such as Web-scale providers, and to secure additional service provider customers in geographies including Brazil and India. Our broader corporate strategy to capitalize on market dynamics and drive profitable growth of our business includes the initiatives set forth in the "Strategy" section below.

[0000936395-15-000024:mdna:11]
[same as prior period, unchanged from 0000936395-14-000051:mdna:18]

[0000936395-15-000024:mdna:12]
We continue to encounter a highly competitive and and fragmented marketplace. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, high-capacity, high-speed network solutions and seek adoption of these solutions and our network architectural approach, particularly in metro applications. Our sales of Packet Networking solutions, including our 8700 Packetwave Platform, also face a highly competitive marketplace for data center interconnection and connecting users-to-content, with additional competitors, including traditional IP router vendors. We expect the current competitive landscape to remain challenging and dynamic. As networking technologies become more software-driven, and network features and layers continue to converge, our competitive landscape continues to broaden beyond traditional competitors. As a result, we are competing with, and expect to compete increasingly with, additional vendors focused on IP routing, information technology and software.

[0000936395-15-000024:mdna:13]
Within these competitive dynamics, maintaining incumbency with key customers domestically and abroad, and securing new opportunities with network operators, often require that we agree to aggressive pricing, significant commercial concessions or other unfavorable commercial terms. These terms have previously and may in the future adversely affect our quarterly results of operations and contribute to fluctuations in our results. These terms can also elongate our revenue recognition or cash collection cycles, add start-up costs to initial sales or deployment of our solutions, require financial commitments or performance bonds, and include onerous contractual commitments that place a disproportionate allocation of risk upon us.

[0000936395-15-000024:mdna:14]
[same as prior period, unchanged from 0000936395-14-000051:mdna:21]

[0000936395-15-000024:mdna:15]
Our corporate strategy to capitalize on the market dynamics above and drive the profitable growth of our business includes the following initiatives:

[0000936395-15-000024:mdna:16]
Promotion of Our OPn Architecture.  Our OPn Architecture enables a programmable infrastructure that brings together the reliability and capacity of optical networking with the flexibility and economics of packet networking technologies. Our OPn Architecture leverages this convergence to enable network operators to scale their networks efficiently and cost effectively, while applying advanced software-based network control and network-level software applications for enhanced programmability. The software-driven aspects of this architecture become increasingly important as network operators increasingly seek to leverage an open ecosystem of virtualized resources to enable the real-time analytics and network agility required for on-demand, next-generation network architectures. We see opportunities in offering a portfolio of OPn Architecture solutions that facilitate the transition to these next-generation networks and that are optimized to create new services rapidly and meet end-user demands.

[0000936395-15-000024:mdna:17]
Research and Development Investment to Expand the Role and Application of Our Solutions. Our product development initiatives are focused on opportunities that enable Ciena to expand its role in customer networks and to address a more diverse set of network applications. We are investing in our OPn Architecture with current development efforts focused on expanding high-capacity service delivery capabilities in our Packet Networking and Converged Packet Optical products for metro networks, data center interconnectivity and wide area network applications. Our research and development efforts also seek to extend our existing technologies, including our WaveLogic coherent optical processor for 200G and 400G optical transport, and to introduce Terabit per second  and greater transmission speeds. In the packet area, we are increasing the scale, density and capability of our packet offerings, and reducing power and space requirements, for applications in metro networks, user aggregation and data center connectivity. In the software area, we are focusing on Agility Matrix, our network function virtualization (NFV) solution, in order to provide virtual network functions in managed service applications. We are also focused on increasing programmability and software control of networks. These efforts include our joint initiative with Ericsson to develop an expanded software-defined networking (SDN) multilayer WAN controller that spans network layers, as well as Ciena's direct efforts to develop software-based networking control platforms and network-level software applications.

[0000936395-15-000024:mdna:18]
Go-to-Market Model to Expand Our Role and Reach. Our go-to-market model is focused on driving sales growth from the diversification of our business and further penetrating additional customer verticals and international markets. We are focused on further penetrating Internet content providers, data center operators and other emerging network operators that form the "Web-scale" marketplace, who are changing the ways in which information and services are accessed and provided. To expand the geographic reach of our direct sales resources, we have pursued strategic channel opportunities that enable sales through third parties, including service providers, systems integrators and value-added resellers. Through the packet-optical resale element of our strategic relationship with Ericsson, we are seeking to expand our geographic reach, as well as the application of our products in customer networks. We also remain focused on expanding the application of our products by existing customers, including communications service provider customers and cable and multiservice operators. These sales efforts seek opportunities for our solutions in applications including metro aggregation, data center interconnectivity, managed services offerings, cloud-based services, business Ethernet services and mobile backhaul.

[0000936395-15-000024:mdna:19]
Business Optimization to Yield Operating Leverage. We are actively pursuing initiatives to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. These initiatives include portfolio optimization and engineering efforts to drive improved efficiencies in the design and development of our solutions and procurement initiatives to consolidate vendors and ensure that our cost model remains ahead of market-based price erosion. We are also focused on transforming our supply chain, including efforts to reduce our material and overhead costs, reduce customer lead times and improve inventory management and logistics. Our initiatives also include significant investments in the re-engineering of company-wide enterprise resource planning platforms, improved automation of key business processes and systems, and the off-shoring of certain business functions. We seek to leverage these initiatives to promote the profitable growth of our business and to drive additional operating leverage.

[0000936395-15-000024:mdna:20]
[same as prior period, unchanged from 0000936395-14-000051:mdna:33]

[0000936395-15-000024:mdna:21]
Revenue for the first quarter of fiscal 2015 was $529.2 million, representing a sequential decrease of 10.5% from $591.0 million in the fourth quarter of fiscal 2014, reflecting, in part, typical seasonality in our business. We typically experience reductions in order volume toward the end of the calendar year, as the procurement cycles of some of our customers slow and network deployment activity at service providers is curtailed. This seasonality in our order flows can result in weaker revenue results in the first quarter of our fiscal year. Also, during the first quarter of fiscal 2015, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar and Euro, in which we have our most significant foreign currency revenue exposure. Consequently our revenue reported in U.S. dollars was adversely impacted by approximately $7.6 million or 1.4% as compared to the fourth quarter of fiscal 2014. Revenue-related details reflecting sequential changes from the fourth quarter of fiscal 2014 include:

[0000936395-15-000024:mdna:22]
| • | Product revenue for the first quarter of fiscal 2015 decreased by $53.9 million, reflecting decreases of $46.7 million in Converged Packet Optical, $4.2 million in Optical Transport, $1.6 million in software and $1.4 million in Packet Networking. |

[0000936395-15-000024:mdna:23]
| • | Service revenue for the first quarter of fiscal 2015 decreased by $7.9 million. |

[0000936395-15-000024:mdna:24]
| • | North America revenue for the first quarter of fiscal 2015 was $331.5 million, a decrease from $340.5 million in the fourth quarter of fiscal 2014. This primarily reflects decreases of $5.4 million in Optical Transport, $2.7 million in Software and Services and $1.7 million in Converged Packet Optical. |

[0000936395-15-000024:mdna:25]
| • | Europe, Middle East and Africa ("EMEA") revenue for the first quarter of fiscal 2015 was $111.0 million, a decrease from $133.7 million in the fourth quarter of fiscal 2014. This primarily reflects decreases of $15.2 million in |

[0000936395-15-000024:mdna:26]
31

[0000936395-15-000024:mdna:27]
Converged Packet Optical, $4.3 million in Software and Services, $2.2 million in Packet Networking and $1.0 million in Optical Transport.

[0000936395-15-000024:mdna:28]
| • | Caribbean and Latin America ("CALA") revenue for the first quarter of fiscal 2015 was $42.8 million, a decrease from $51.8 million in the fourth quarter of fiscal 2014. This primarily reflects a decrease of $12.0 million in Converged Packet Optical, partially offset by a $3.0 million increase in Optical Transport. |

[0000936395-15-000024:mdna:29]
| • | Asia Pacific ("APAC") revenue for the first quarter of fiscal 2015 was $43.9 million, a decrease from $65.0 million in the fourth quarter of fiscal 2014. This primarily reflects decreases of $17.8 million in Converged Packet Optical and $2.5 million in Software and Services. |

[0000936395-15-000024:mdna:30]
| • | For the first quarter of fiscal 2015, AT&T accounted for 22.0% of total revenue. This compares to 12.2% of total revenue in the fourth quarter of fiscal 2014. |

[0000936395-15-000024:mdna:31]
Gross margin for the first quarter of fiscal 2015 was 43.5%, an increase from 37.4% in the fourth quarter of fiscal 2014. Gross margin for these periods was adversely impacted by a commercial arrangement with AT&T entered into in the fourth quarter of fiscal 2014 relating to our participation in AT&T's Domain 2.0 supplier program. The Domain 2.0 initiative is the next generation of AT&T's Supplier Domain Program, intended to enable AT&T to transition more quickly to next-generation, cloud-based architectures that embrace NFV and SDN, and accelerate their time to market with new products and services. Our commercial arrangement relating to this opportunity included, in addition to typical customer price erosion, certain commercial concessions that had a disproportionate impact on our gross margin during the fourth quarter of fiscal 2014. These concessions adversely affected our gross margin by approximately 4.0% during the fourth quarter of fiscal 2014, and by less than 1.0% during the first quarter of fiscal 2015. We do not expect these concessions to have an adverse impact on our quarterly gross margin or revenue during the remainder of fiscal 2015, and believe that price erosion associated with this arrangement can be largely offset by normally recurring product cost reductions.

[0000936395-15-000024:mdna:32]
Operating expense was $226.1 million for the first quarter of fiscal 2015, an increase from $222.7 million in the fourth quarter of fiscal 2014. First quarter fiscal 2015 operating expense primarily reflects increases of $7.9 million in restructuring expense, $2.3 million in research and development expenses and $1.0 million in general and administrative expense, partially offset by a decrease of $7.7 million in selling and marketing expense. Restructuring expense for the first quarter of fiscal 2015 includes severance and employee-related costs associated with a global workforce reduction of approximately 125 employees to address organizational realignment and the reallocation of resources toward strategic growth areas of the business.

[0000936395-15-000024:mdna:33]
Income from operations for the first quarter of fiscal 2015 was $4.2 million, compared to loss from operations of $1.8 million during the fourth quarter of fiscal 2014. Due primarily to the fluctuation in foreign currency exchange rates, net of hedging, we incurred losses in interest and other income, net of $8.2 million and $11.0 million during the first quarter of fiscal 2015 and the fourth quarter of fiscal 2014, respectively. Our net loss for the first quarter of fiscal 2015 was $18.8 million, or $0.17 per diluted common share. This compares to a net loss of $30.7 million or $0.29 per diluted common share, for the fourth quarter of fiscal 2014.

[0000936395-15-000024:mdna:34]
We generated cash from operations of $22.1 million during the first quarter of fiscal 2015, consisting of $16.4 million in cash provided by net losses adjusted for non-cash charges and $5.7 million provided by cash related to reductions in working capital. This compares with $73.8 million of cash generated from operations during the fourth quarter of fiscal 2014, consisting of $23.5 million in cash provided by net losses adjusted for non-cash charges and $50.3 million provided by cash related to reductions in working capital.

[0000936395-15-000024:mdna:35]
As of January 31, 2015, we had $598.7 million in cash and cash equivalents, $145.2 million of short-term investments in U.S. treasury securities and commercial paper, and $55.2 million of long-term investments in U.S. treasury securities. This compares to $330.1 million in cash and cash equivalents, $95.0 million of short-term investments in U.S. treasury securities and commercial paper and $15.0 million of long-term investments in U.S. treasury securities, at January 31, 2014, and $586.7 million in cash and cash equivalents, $140.2 million of short-term investments in U.S. treasury securities and commercial paper, and $50.1 million of long-term investments in U.S. treasury securities at October 31, 2014.

[0000936395-15-000024:mdna:36]
As of January 31, 2015, we had 5,070 employees, a decrease from 5,161 at October 31, 2014 and an increase from 4,865 at January 31, 2014. The decrease in headcount during the first quarter of fiscal 2015 related principally to restructuring activities during the quarter.

[0000936395-15-000024:mdna:37]
[same as prior period, unchanged from 0000936395-14-000051:mdna:47]

[0000936395-15-000024:mdna:38]
[same as prior period, unchanged from 0000936395-14-000051:mdna:48]

[0000936395-15-000024:mdna:39]
[same as prior period, unchanged from 0000936395-14-000051:mdna:49]

[0000936395-15-000024:mdna:40]
| • | Converged Packet Optical —includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-15-000024:mdna:41]
| • | Packet Networking — includes Ciena's 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This segment also includes Ciena’s 8700 Packetwave Platform and Ciena's Ethernet packet configuration for the 5410 Service Aggregation Switch. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-15-000024:mdna:42]
| • | Optical Transport — includes the 4200 Advanced Services Platform, Corestream® Agility Optical Transport System, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. This segment includes sales from SONET/SDH, transport and data networking products, as well as certain enterprise-oriented transport solutions that support storage and LAN extension, interconnection of data centers, and virtual private networks. This segment also includes operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-15-000024:mdna:43]
| • | Software and Services — includes Ciena's Agility software portfolio, which includes a SDN multilayer WAN controller, NFV platform, and network level software applications for enabling on-demand, high-bandwidth WAN services delivered in an open network ecosystem. This segment also includes the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager and Optical Suite Release. This segment includes a broad range of services for consulting and network design, installation and deployment, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-15-000024:mdna:44]
Quarter ended January 31, 2014 compared to the quarter ended January 31, 2015

[0000936395-15-000024:mdna:45]
[same as prior period, unchanged from 0000936395-14-000051:mdna:56]

[0000936395-15-000024:mdna:46]
During the first quarter of fiscal 2015, as compared to the first quarter of fiscal 2014, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar and Euro, in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. dollars was adversely impacted by approximately $12.7 million or 2.4%. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-15-000024:mdna:47]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 333,401 |  |  | 62.5 |  | $ | 336,560 |  |  | 63.6 |  | $ | 3,159 |  |  | 0.9 |  |
| Packet Networking | 51,709 |  |  | 9.7 |  | 54,983 |  |  | 10.4 |  | 3,274 |  |  | 6.3 |  |
| Optical Transport | 40,097 |  |  | 7.5 |  | 22,339 |  |  | 4.2 |  | (17,758 | ) |  | (44.3 | ) |
| Software and Services | 108,496 |  |  | 20.3 |  | 115,280 |  |  | 21.8 |  | 6,784 |  |  | 6.3 |  |
| Consolidated revenue | $ | 533,703 |  |  | 100.0 |  | $ | 529,162 |  |  | 100.0 |  | $ | (4,541 | ) |  | (0.9 | ) |

[0000936395-15-000024:mdna:48]
[same as prior period, unchanged from 0000936395-14-000051:mdna:60]

[0000936395-15-000024:mdna:49]
[same as prior period, unchanged from 0000936395-14-000051:mdna:61]

[0000936395-15-000024:mdna:50]
**    Denotes % change from 2014 to 2015

[0000936395-15-000024:mdna:51]
| • | Converged Packet Optical revenue increased, reflecting increases of $14.2 million in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructure, and increases of $2.5 million in sales of the OTN configuration for the 5410 Reconfigurable Switching System. These increases were partially offset by a decrease of $11.6 million in sales of our CoreDirector® Multiservice Optical Switches and a decrease of $1.9 million of sales of our 5430 Reconfigurable Switching System. The strong performance of this segment, particularly as compared to the steady declines we have experienced in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-15-000024:mdna:52]
| • | Packet Networking revenue increased, reflecting a $4.8 million increase in sales of our 3000 and 5000 families of service delivery and aggregation switches. This increase was largely driven by the expansion of Ethernet business services by AT&T, our largest service provider customer. Segment revenue also benefited from $1.9 million in sales of our 8700 Packetwave Platform, which became available for sale in the fourth quarter of fiscal 2014. These increases were partially offset by decreases of $2.2 million in sales of our 5410 Service Aggregation Switch and $1.3 million in sales of our older, stand-alone broadband products. |

[0000936395-15-000024:mdna:53]
| • | Optical Transport revenue decreased, reflecting a $9.2 million decrease of our 5100/5200 Advanced Services Platform, a $4.6 million decrease in sales of our 4200 Advanced Services Platform and a $3.9 million decrease in sales of other stand-alone transport products. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in revenue in recent years. We expect this trend to continue, reflecting network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-15-000024:mdna:54]
| • | Software and Services revenue increased, reflecting increases of $5.7 million in maintenance and support services revenue and $0.9 million in consulting revenue. |

[0000936395-15-000024:mdna:55]
Our operating segments each engage in business and operations across four geographic regions: North America, EMEA, CALA and APAC. Results for North America include only activities in the United States and Canada. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly from quarter to quarter. Among other things, the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-15-000024:mdna:56]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 355,848 |  |  | 66.7 |  | $ | 331,535 |  |  | 62.6 |  | $ | (24,313 | ) |  | (6.8 | ) |
| EMEA | 88,720 |  |  | 16.6 |  | 111,006 |  |  | 21.0 |  | $ | 22,286 |  |  | 25.1 |  |
| CALA | 52,680 |  |  | 9.9 |  | 42,742 |  |  | 8.1 |  | $ | (9,938 | ) |  | (18.9 | ) |
| APAC | 36,455 |  |  | 6.8 |  | 43,879 |  |  | 8.3 |  | $ | 7,424 |  |  | 20.4 |  |
| Total | $ | 533,703 |  |  | 100.0 |  | $ | 529,162 |  |  | 100.0 |  | $ | (4,541 | ) |  | (0.9 | ) |

[0000936395-15-000024:mdna:57]
[same as prior period, unchanged from 0000936395-14-000051:mdna:69]

[0000936395-15-000024:mdna:58]
[same as prior period, unchanged from 0000936395-14-000051:mdna:70]

[0000936395-15-000024:mdna:59]
**    Denotes % change from 2014 to 2015

[0000936395-15-000024:mdna:60]
| • | North America revenue reflects a decrease of $19.5 million in Converged Packet Optical sales and $13.6 million in Optical Transport sales. These decreases were partially offset by increases of $4.8 million in Packet Networking sales and $4.0 million in Software and Services sales. Converged Packet Optical sales reflects decreases of $10.5 million of sales of our CoreDirector® Multiservice Optical Switches, and $8.9 million of sales of our 6500 Packet-Optical Platform due to decreased sales to certain large communication service provider customers, partially offset by increased sales to AT&T and certain Web-scale providers. |

[0000936395-15-000024:mdna:61]
| • | EMEA revenue reflects an increase of $26.8 million in Converged Packet Optical sales. This increase was partially offset by decreases of $2.6 million in Optical Transport sales and $1.1 million in Software and Services sales. Converged Packet Optical sales reflects increases of $23.3 million of sales of our 6500 Packet-Optical Platform due to increased sales to communication service providers, including submarine network operators, cable and multiservice operator customers, Web-scale providers and sales through our strategic relationship with Ericsson. Converged Packet |

[0000936395-15-000024:mdna:62]
34

[0000936395-15-000024:mdna:63]
Optical sales also reflect increases of $4.4 million of sales of our 5430 Reconfigurable Switching System due to increased sales to communication service providers, including submarine network operators.

[0000936395-15-000024:mdna:64]
| • | CALA revenue reflects a decrease of $14.0 million in Converged Packet Optical sales. This decrease was partially offset by an increase of $4.2 million in Software and Services sales. Converged Packet Optical sales reflects decreases of $14.1 million of sales of our 5430 Reconfigurable Switching System, and $2.1 million of sales of our 6500 Packet-Optical Platform, partially offset by $2.0 million of sales of our OTN configuration for the 5410 Reconfigurable Switching System. |

[0000936395-15-000024:mdna:65]
| • | APAC revenue reflects an increase of $9.8 million in Converged Packet Optical sales, partially offset by decreases of $1.6 million in Optical Transport sales. Converged Packet Optical sales reflects increases of $7.0 million of sales of our 5430 Reconfigurable Switching System, $1.7 million of sales of our 6500 Packet-Optical Platform, and $1.0 million of sales of our OTN configuration for the 5410 Reconfigurable Switching System. |

[0000936395-15-000024:mdna:66]
[same as prior period, unchanged from 0000936395-14-000051:mdna:75]

[0000936395-15-000024:mdna:67]
Product cost of goods sold consists primarily of amounts paid to third party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-15-000024:mdna:68]
Services cost of goods sold consists primarily of direct and third party costs, including employee-related costs, associated with our provision of services including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated losses on committed customer contracts.

[0000936395-15-000024:mdna:69]
Our gross profit as a percentage of revenue, or “gross margin,” is susceptible to fluctuations due to a number of factors. In any given period, gross margin can vary significantly depending upon the mix and concentration of revenue by segment, product line within a particular segment, geography and customers. Gross margin can also be affected by our concentration of lower margin "common" equipment sales and higher margin channel cards, the mix of lower margin installation services within our service revenue, our introduction of new products, and changes in expense for excess and obsolete inventory and warranty obligations. Gross margin can also be adversely affected by the level of pricing pressure and competition that we encounter in the market. We expect that gross margins will be subject to fluctuation based on our level of success in driving product cost reductions relative to the market-based price erosion we encounter. In an effort to retain or secure customers, enter new markets or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders. Gross margin can also be affected as a result of our degree of success in rationalizing our supply chain and consolidating third party contract manufacturers and distribution sites as part of our effort to optimize our operations. These market dynamics and factors may adversely affect our gross margin and results of operations in certain periods.

[0000936395-15-000024:mdna:70]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-15-000024:mdna:71]
[same as prior period, unchanged from 0000936395-14-000051:mdna:80]

[0000936395-15-000024:mdna:72]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 533,703 |  |  | 100.0 |  | $ | 529,162 |  |  | 100.0 |  | $ | (4,541 | ) |  | (0.9 | ) |
| Total cost of goods sold | 307,852 |  |  | 57.7 |  | 298,867 |  |  | 56.5 |  | (8,985 | ) |  | (2.9 | ) |
| Gross profit | $ | 225,851 |  |  | 42.3 |  | $ | 230,295 |  |  | 43.5 |  | $ | 4,444 |  |  | 2.0 |  |

[0000936395-15-000024:mdna:73]
[same as prior period, unchanged from 0000936395-14-000051:mdna:82]

[0000936395-15-000024:mdna:74]
[same as prior period, unchanged from 0000936395-14-000051:mdna:83]

[0000936395-15-000024:mdna:75]
**    Denotes % change from 2014 to 2015

[0000936395-15-000024:mdna:76]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 432,941 |  |  | 100.0 |  | $ | 422,315 |  |  | 100.0 |  | $ | (10,626 | ) |  | (2.5 | ) |
| Product cost of goods sold | 245,216 |  |  | 56.6 |  | 236,548 |  |  | 56.0 |  | (8,668 | ) |  | (3.5 | ) |
| Product gross profit | $ | 187,725 |  |  | 43.4 |  | $ | 185,767 |  |  | 44.0 |  | $ | (1,958 | ) |  | (1.0 | ) |

[0000936395-15-000024:mdna:77]
[same as prior period, unchanged from 0000936395-14-000051:mdna:86]

[0000936395-15-000024:mdna:78]
[same as prior period, unchanged from 0000936395-14-000051:mdna:87]

[0000936395-15-000024:mdna:79]
**    Denotes % change from 2014 to 2015

[0000936395-15-000024:mdna:80]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 100,762 |  |  | 100.0 |  | $ | 106,847 |  |  | 100.0 |  | $ | 6,085 |  |  | 6.0 |  |
| Service cost of goods sold | 62,636 |  |  | 62.2 |  | 62,319 |  |  | 58.3 |  | (317 | ) |  | (0.5 | ) |
| Service gross profit | $ | 38,126 |  |  | 37.8 |  | $ | 44,528 |  |  | 41.7 |  | $ | 6,402 |  |  | 16.8 |  |

[0000936395-15-000024:mdna:81]
[same as prior period, unchanged from 0000936395-14-000051:mdna:90]

[0000936395-15-000024:mdna:82]
[same as prior period, unchanged from 0000936395-14-000051:mdna:91]

[0000936395-15-000024:mdna:83]
**    Denotes % change from 2014 to 2015

[0000936395-15-000024:mdna:84]
[same as prior period, unchanged from 0000936395-14-000051:mdna:93]

[0000936395-15-000024:mdna:85]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to product cost reductions and lower warranty expense. These improvements were partially offset by unfavorable impacts from product pricing, which were driven by typical market based price erosion, and commercial concessions related to the AT&T's Supplier Domain Program as described in "Overview" above. |

[0000936395-15-000024:mdna:86]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to higher margin due to lower repair and spares costs to support maintenance contracts. |

[0000936395-15-000024:mdna:87]
[same as prior period, unchanged from 0000936395-14-000051:mdna:96]

[0000936395-15-000024:mdna:88]
We expect operating expense to increase slightly in fiscal 2015 from the level reported for fiscal 2014 to support the growth of our business, to fund our research and development initiatives and to provide for investments in the re-engineering of company-wide enterprise resource planning platforms. Operating expense consists of the component elements described below.

[0000936395-15-000024:mdna:89]
[same as prior period, unchanged from 0000936395-14-000051:mdna:98]

[0000936395-15-000024:mdna:90]
[same as prior period, unchanged from 0000936395-14-000051:mdna:99]

[0000936395-15-000024:mdna:91]
[same as prior period, unchanged from 0000936395-14-000051:mdna:100]

[0000936395-15-000024:mdna:92]
Amortization of intangible assets primarily reflects the amortization of purchased technology and customer relationships from our past acquisitions.

[0000936395-15-000024:mdna:93]
[same as prior period, unchanged from 0000936395-14-000051:mdna:102]

[0000936395-15-000024:mdna:94]
[same as prior period, unchanged from 0000936395-14-000051:mdna:103]

[0000936395-15-000024:mdna:95]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 101,497 |  |  | 19.0 |  | $ | 100,761 |  |  | 19.0 |  | $ | (736 | ) |  | (0.7 | ) |
| Selling and marketing | 78,348 |  |  | 14.7 |  | 76,712 |  |  | 14.5 |  | (1,636 | ) |  | (2.1 | ) |
| General and administrative | 30,097 |  |  | 5.6 |  | 29,553 |  |  | 5.6 |  | (544 | ) |  | (1.8 | ) |
| Amortization of intangible assets | 12,439 |  |  | 2.3 |  | 11,019 |  |  | 2.1 |  | (1,420 | ) |  | (11.4 | ) |
| Restructuring costs | 115 |  |  | — |  | 8,085 |  |  | 1.5 |  | 7,970 |  |  | n/a |  |
| Total operating expenses | $ | 222,496 |  |  | 41.6 |  | $ | 226,130 |  |  | 42.7 |  | $ | 3,634 |  |  | 1.6 |  |

[0000936395-15-000024:mdna:96]
[same as prior period, unchanged from 0000936395-14-000051:mdna:105]

[0000936395-15-000024:mdna:97]
[same as prior period, unchanged from 0000936395-14-000051:mdna:106]

[0000936395-15-000024:mdna:98]
**    Denotes % change from 2014 to 2015

[0000936395-15-000024:mdna:99]
| • | Research and development expense benefited from $4.5 million as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Canadian Dollar. Including the benefit from foreign exchange rates, research and development expenses decreased by $0.7 million, primarily reflecting decreases of $3.0 million in professional services and $2.6 million in prototype expense. These decreases were offset by increases of $1.7 million in facilities and information technology costs and $1.4 million in employee compensation and related costs. |

[0000936395-15-000024:mdna:100]
| • | Selling and marketing expense benefited from $2.6 million as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Euro. Including the benefit from foreign exchange rates, selling and marketing expense decreased by $1.6 million, primarily reflecting decreases of $1.4 million in professional services and $1.0 million for travel and related costs. |

[0000936395-15-000024:mdna:101]
| • | General and administrative expense decreased, primarily due to a decrease in legal fees and other consulting services. |

[0000936395-15-000024:mdna:102]
[same as prior period, unchanged from 0000936395-14-000051:mdna:111]

[0000936395-15-000024:mdna:103]
| • | Restructuring costs increased reflecting a global workforce reduction of approximately 125 employees in the first quarter of fiscal 2015 as part of our business optimization strategy to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. |

[0000936395-15-000024:mdna:104]
[same as prior period, unchanged from 0000936395-14-000051:mdna:113]

[0000936395-15-000024:mdna:105]
[same as prior period, unchanged from 0000936395-14-000051:mdna:114]

[0000936395-15-000024:mdna:106]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (5,998 | ) |  | (1.1 | ) |  | $ | (8,233 | ) |  | (1.6 | ) |  | $ | (2,235 | ) |  | 37.3 |  |
| Interest expense | $ | 11,028 |  |  | 2.1 |  |  | $ | 13,661 |  |  | 2.6 |  |  | $ | 2,633 |  |  | 23.9 |  |
| Provision for income taxes | $ | 2,265 |  |  | 0.4 |  |  | $ | 1,050 |  |  | 0.2 |  |  | $ | (1,215 | ) |  | (53.6 | ) |

[0000936395-15-000024:mdna:107]
[same as prior period, unchanged from 0000936395-14-000051:mdna:116]

[0000936395-15-000024:mdna:108]
[same as prior period, unchanged from 0000936395-14-000051:mdna:117]

[0000936395-15-000024:mdna:109]
**    Denotes % change from 2014 to 2015

[0000936395-15-000024:mdna:110]
| • | Interest and other income (loss), net decreased by $2.2 million reflecting a $3.4 million loss in foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, partially offset by a $1.1 million non-cash gain related to the change in fair value of the embedded redemption feature associated with our 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes"). |

[0000936395-15-000024:mdna:111]
| • | Interest expense increased primarily due to the Term Loan that was entered into in fiscal 2014. For additional information about our Term Loan, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-15-000024:mdna:112]
| • | Provision for income taxes decreased primarily due to foreign tax expense, which is largely a result of lower income from our Brazilian operations. |

[0000936395-15-000024:mdna:113]
[same as prior period, unchanged from 0000936395-14-000051:mdna:179]

[0000936395-15-000024:mdna:114]
[same as prior period, unchanged from 0000936395-14-000051:mdna:180]

[0000936395-15-000024:mdna:115]
|  | Quarter Ended January 31, |  |  |  |
|  | 2014 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 78,698 |  |  | $ | 82,657 |  |  | $ | 3,959 |  |  | 5.0 |  |
| Packet Networking | $ | 385 |  |  | $ | 6,531 |  |  | $ | 6,146 |  |  | 1,596.4 |  |
| Optical Transport | $ | 15,650 |  |  | $ | 5,886 |  |  | $ | (9,764 | ) |  | (62.4 | ) |
| Software and Services | $ | 29,621 |  |  | $ | 34,460 |  |  | $ | 4,839 |  |  | 16.3 |  |

[0000936395-15-000024:mdna:116]
[same as prior period, unchanged from 0000936395-14-000051:mdna:135]

[0000936395-15-000024:mdna:117]
*    Denotes % change from 2014 to 2015

[0000936395-15-000024:mdna:118]
| • | Converged Packet Optical segment profit increased, primarily due to increased sales volume and improved gross margin, partially offset by increased research and development expense. Increased sales volume is largely driven by service provider demand for convergence of high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. Improved gross margin is primarily due to product cost reductions and lower warranty expense. These improvements were partially offset by unfavorable impacts from product pricing, which were driven by typical market based price erosion, and commercial concessions related to the AT&T's Supplier Domain Program as described in "Overview" above. |

[0000936395-15-000024:mdna:119]
| • | Packet Networking segment profit increased due to increased sales volume and lower research and development costs, partially offset by lower gross margin. Packet Networking revenue benefited from the expansion of Ethernet business services by the expansion of Ethernet business services by AT&T, our largest service provider customer. Gross margin decreased due to unfavorable impacts from product pricing, which were driven by typical market based price erosion, and commercial concessions related to the AT&T's Supplier Domain Program as described in "Overview" above, partially offset by product cost reductions. |

[0000936395-15-000024:mdna:120]
| • | Optical Transport segment profit decreased, primarily due to reduced sales volume and decreased gross margin. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. Gross margin decreased due to unfavorable impacts from product pricing, which were driven by typical market based price erosion and a higher provision for excess and obsolete inventory. |

[0000936395-15-000024:mdna:121]
| • | Software and Services segment profit increased primarily due to higher sales for maintenance, support and consulting services, and increased margin due to lower repair and spares costs to support maintenance contracts. These increases were partially offset by higher software research and development expenses. |

[0000936395-15-000024:mdna:122]
[same as prior period, unchanged from 0000936395-14-000051:mdna:196]

[0000936395-15-000024:mdna:123]
At January 31, 2015, our principal sources of liquidity were cash and cash equivalents, investments in marketable debt securities, representing U.S. treasuries and commercial paper, and our ABL Credit Facility. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-15-000024:mdna:124]
|  | October 31, 2014 |  | January 31, 2015 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 586,720 |  |  | $ | 598,723 |  |  | $ | 12,003 |  |
| Short-term investments in marketable debt securities | 140,205 |  |  | 145,154 |  |  | 4,949 |  |
| Long-term investments in marketable debt securities | 50,057 |  |  | 55,153 |  |  | 5,096 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 776,982 |  |  | $ | 799,030 |  |  | $ | 22,048 |  |

[0000936395-15-000024:mdna:125]
The change in total cash and cash equivalents and investments in marketable debt securities during the first three months of fiscal 2015 was primarily related to the following:

[0000936395-15-000024:mdna:126]
38

[0000936395-15-000024:mdna:127]
| • | $22.1 million cash generated from operations, consisting of $16.4 million provided by net loss (adjusted for non-cash charges) and $5.7 million provided by working capital; |

[0000936395-15-000024:mdna:128]
| • | $11.2 million used for purchases of equipment, furniture, and fixtures and intellectual property; |

[0000936395-15-000024:mdna:129]
| • | $9.3 million provided by settlement of foreign currency forward contracts, net; |

[0000936395-15-000024:mdna:130]
| • | $3.0 million used to pay capital lease obligations; |

[0000936395-15-000024:mdna:131]
| • | $8.3 million provided by stock issuances under our employee stock purchase plan and exercise of stock options; and |

[0000936395-15-000024:mdna:132]
| • | $2.8 million used by the effect of exchange rate changes on cash and cash equivalents. |

[0000936395-15-000024:mdna:133]
Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $200 million with a maturity date of December 31, 2016. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of January 31, 2015, letters of credit totaling $60.5 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 31, 2015.

[0000936395-15-000024:mdna:134]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our ABL Credit Facility, will satisfy the working capital needs, capital expenditures, the repayment of our outstanding 4.0% convertible senior notes due March 15, 2015, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-15-000024:mdna:135]
The following sections set forth the components of our $22.1 million of cash generated from operating activities during the first three months of fiscal 2015:

[0000936395-15-000024:mdna:136]
[same as prior period, unchanged from 0000936395-14-000051:mdna:209]

[0000936395-15-000024:mdna:137]
[same as prior period, unchanged from 0000936395-14-000051:mdna:210]

[0000936395-15-000024:mdna:138]
|  | Three months ended |
|  | January 31, 2015 |
| Net loss | $ | (18,779 | ) |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 13,772 |  |
| Share-based compensation costs | 10,807 |  |
| Amortization of intangible assets | 13,219 |  |
| Provision for inventory excess and obsolescence | 5,787 |  |
| Provision for warranty | 2,293 |  |
| Other | (10,689 | ) |
| Net loss (adjusted for non-cash charges) | $ | 16,410 |  |

[0000936395-15-000024:mdna:139]
[same as prior period, unchanged from 0000936395-14-000051:mdna:212]

[0000936395-15-000024:mdna:140]
[same as prior period, unchanged from 0000936395-14-000051:mdna:213]

[0000936395-15-000024:mdna:141]
Cash generated from decreases in accounts receivable during the first three months of fiscal 2015, net of a $0.1 million provision for doubtful accounts, was $5.4 million. Our days sales outstanding (DSOs) decreased from 88 days for the first three months of fiscal 2014 to 87 days for the first three months of fiscal 2015.

[0000936395-15-000024:mdna:142]
The following table sets forth (in thousands) changes to our accounts receivable, net of allowance for doubtful accounts, from the end of fiscal 2014 through the end of the first quarter of fiscal 2015:

[0000936395-15-000024:mdna:143]
|  | October 31, 2014 |  | January 31, 2015 |  | Increase(decrease) |
| Accounts receivable, net | $ | 518,981 |  |  | $ | 513,554 |  |  | $ | (5,427 | ) |

[0000936395-15-000024:mdna:144]
[same as prior period, unchanged from 0000936395-14-000051:mdna:217]

[0000936395-15-000024:mdna:145]
Cash generated from decreases in inventory during the first three months of fiscal 2015 was $7.8 million. Our inventory turns increased from 3.5 turns during the first three months of fiscal 2014 to 3.9 turns during the first three months of fiscal 2015. Our inventory balance, as reported on our Condensed Consolidated Balance Sheet, decreased by $13.5 million during the  first three months of fiscal 2015. This change reflects $7.8 million of cash provided by inventory and a $5.8 million non-cash provision for excess and obsolescence. The following table sets forth (in thousands) changes to the components of our inventory from the end of fiscal 2014 through the end of the first quarter of fiscal 2015:

[0000936395-15-000024:mdna:146]
|  | October 31, 2014 |  | January 31, 2015 |  | Increase(decrease) |
| Raw materials | $ | 64,853 |  |  | $ | 53,920 |  |  | $ | (10,933 | ) |
| Work-in-process | 8,371 |  |  | 9,347 |  |  | 976 |  |
| Finished goods | 165,799 |  |  | 159,587 |  |  | (6,212 | ) |
| Deferred cost of goods sold | 75,763 |  |  | 70,244 |  |  | (5,519 | ) |
| Gross inventory | 314,786 |  |  | 293,098 |  |  | (21,688 | ) |
| Provision for inventory excess and obsolescence | (60,126 | ) |  | (51,980 | ) |  | 8,146 |  |
| Inventory | $ | 254,660 |  |  | $ | 241,118 |  |  | $ | (13,542 | ) |

[0000936395-15-000024:mdna:147]
[same as prior period, unchanged from 0000936395-14-000051:mdna:221]

[0000936395-15-000024:mdna:148]
Cash used in prepaid expense and other during the first three months of fiscal 2015 was $4.5 million primarily related to higher maintenance spares and higher product demonstration equipment, partially offset by lower prepaid value added tax expense and lower deferred deployment expense.

[0000936395-15-000024:mdna:149]
[same as prior period, unchanged from 0000936395-14-000051:mdna:223]

[0000936395-15-000024:mdna:150]
Utilization of cash resources for accounts payable, accruals and other obligations during the first three months of fiscal 2015 was $9.8 million. This amount reflects a $5.1 million decrease in our accounts payable, accruals and other obligations plus additional liabilities recorded for the following items: $4.5 million related to our foreign currency forward contracts, $2.6 million related to our forward starting interest rate swap and $2.3 million relating to warranties. These items were offset by decreases of $3.0 million for financing activities relating to unpaid capital leases and $1.7 million for investing activities related to equipment purchases.

[0000936395-15-000024:mdna:151]
The following table sets forth (in thousands) changes in our accounts payable, accruals and other obligations from the end of fiscal 2014 through the end of the first quarter of fiscal 2015:

[0000936395-15-000024:mdna:152]
|  | October 31, 2014 |  | January 31, 2015 |  | Increase(decrease) |
| Accounts payable | $ | 209,777 |  |  | $ | 192,109 |  |  | $ | (17,668 | ) |
| Accrued liabilities | 276,608 |  |  | 289,984 |  |  | 13,376 |  |
| Other long-term obligations | 45,390 |  |  | 44,596 |  |  | (794 | ) |
| Accounts payable, accruals and other obligations | $ | 531,775 |  |  | $ | 526,689 |  |  | $ | (5,086 | ) |

[0000936395-15-000024:mdna:153]
Interest Paid on Convertible Notes, ABL Credit Facility and Term Loan

[0000936395-15-000024:mdna:154]
Interest on our outstanding 4.0% convertible senior notes, due March 15, 2015, is payable on March 15 and September 15 of each year.

[0000936395-15-000024:mdna:155]
Interest on our outstanding 0.875% convertible senior notes, due June 15, 2017, is payable on June 15 and December 15 of each year. We paid $2.2 million in interest on these convertible notes during the first three months of fiscal 2015.

[0000936395-15-000024:mdna:156]
Interest on our outstanding 3.75% convertible senior notes, due October 15, 2018, is payable on April 15 and October 15 of each year.

[0000936395-15-000024:mdna:157]
Interest on our outstanding 4.0% convertible senior notes, due December 15, 2020, is payable on June 15 and December 15 of each year. We paid $3.8 million in interest on these convertible notes during the first three months of fiscal 2015.

[0000936395-15-000024:mdna:158]
Interest on our outstanding Term Loan, due July 15, 2019, is payable periodically based on the underlying market index rate selected for borrowing. We paid $2.4 million in interest on this term loan during the first quarter of fiscal 2015.

[0000936395-15-000024:mdna:159]
During the first three months of fiscal 2015, we utilized the ABL Credit Facility to collateralize certain standby letters of credit. We paid $0.4 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility during the first three months of fiscal 2015.

[0000936395-15-000024:mdna:160]
For additional information about our convertible notes and Term Loan, see Note 15 to our Condensed Consolidated Financial Statements included in in Item 1 of Part I of this report.

[0000936395-15-000024:mdna:161]
[same as prior period, unchanged from 0000936395-14-000051:mdna:234]

[0000936395-15-000024:mdna:162]
Deferred revenue increased by $6.9 million during the first three months of fiscal 2015. Product deferred revenue represents either payments received in advance of shipment or payments received after shipment but before revenue recognition. Services deferred revenue is related to payment for service contracts for which revenue will be recognized over the contract term. The following table reflects (in thousands) the balance of deferred revenue and the change in this balance from the end of fiscal 2014 through the first three months of fiscal 2015:

[0000936395-15-000024:mdna:163]
|  | October 31, 2014 |  | January 31, 2015 |  | Increase(decrease) |
| Products | $ | 50,457 |  |  | $ | 58,041 |  |  | $ | 7,584 |  |
| Services | 95,161 |  |  | 94,497 |  |  | (664 | ) |
| Total deferred revenue | $ | 145,618 |  |  | $ | 152,538 |  |  | $ | 6,920 |  |

[0000936395-15-000024:mdna:164]
[same as prior period, unchanged from 0000936395-14-000051:mdna:245]

[0000936395-15-000024:mdna:165]
The following is a summary of our future minimum payments under contractual obligations as of January 31, 2015 (in thousands):

[0000936395-15-000024:mdna:166]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 1,254,627 |  |  | $ | 187,500 |  |  | $ | 500,000 |  |  | $ | 350,000 |  |  | $ | 217,127 |  |
| Principal due on Term Loan | 248,750 |  |  | 2,500 |  |  | 5,000 |  |  | 241,250 |  |  | — |  |
| Interest due on convertible notes | 112,188 |  |  | 28,750 |  |  | 47,813 |  |  | 28,125 |  |  | 7,500 |  |
| Interest due on Term Loan (2) | 41,655 |  |  | 9,426 |  |  | 18,592 |  |  | 13,637 |  |  | — |  |
| Operating leases (3) | 191,893 |  |  | 32,766 |  |  | 56,983 |  |  | 25,594 |  |  | 76,550 |  |
| Purchase obligations (4) | 173,474 |  |  | 173,474 |  |  | — |  |  | — |  |  | — |  |
| Capital leases | 9,744 |  |  | 6,577 |  |  | 3,167 |  |  | — |  |  | — |  |
| Other obligations | 4,813 |  |  | 3,460 |  |  | 1,353 |  |  | — |  |  | — |  |
| Total (5) | $ | 2,037,144 |  |  | $ | 444,453 |  |  | $ | 632,908 |  |  | $ | 658,606 |  |  | $ | 301,177 |  |

[0000936395-15-000024:mdna:167]
[same as prior period, unchanged from 0000936395-14-000051:mdna:143]

[0000936395-15-000024:mdna:168]
[same as prior period, unchanged from 0000936395-14-000051:mdna:249]

[0000936395-15-000024:mdna:169]
| (2) | Interest on the Term Loan is variable and was calculated using the rate in effect on the balance sheet date. |

[0000936395-15-000024:mdna:170]
[same as prior period, unchanged from 0000936395-14-000051:mdna:251]

[0000936395-15-000024:mdna:171]
[same as prior period, unchanged from 0000936395-14-000051:mdna:252]

[0000936395-15-000024:mdna:172]
| (5) | As of January 31, 2015, we also had approximately $14.1 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-15-000024:mdna:173]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of January 31, 2015 (in thousands):

[0000936395-15-000024:mdna:174]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years | Thereafter |
| Standby letters of credit | $ | 60,468 |  |  | $ | 36,775 |  |  | $ | 7,063 |  |  | $ | 5,280 |  | $ | 11,350 |  |

[0000936395-15-000024:mdna:175]
[same as prior period, unchanged from 0000936395-14-000051:mdna:256]

[0000936395-15-000024:mdna:176]
[same as prior period, unchanged from 0000936395-14-000051:mdna:257]

[0000936395-15-000024:mdna:177]
[same as prior period, unchanged from 0000936395-14-000051:mdna:258]

[0000936395-15-000024:mdna:178]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-15-000024:mdna:179]
[same as prior period, unchanged from 0000936395-14-000051:mdna:260]

[0000936395-15-000024:mdna:180]
[same as prior period, unchanged from 0000936395-14-000051:mdna:261]

[0000936395-15-000024:mdna:181]
We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. We assess whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are to be performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-15-000024:mdna:182]
We apply the percentage-of-completion method to long-term arrangements where we are required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of revenue recognized using the percentage-of-completion method for the first three months ended January 31, 2014 and January 31, 2015 were 5.1% and 1.0%, respectively.

[0000936395-15-000024:mdna:183]
[same as prior period, unchanged from 0000936395-14-000051:mdna:264]

[0000936395-15-000024:mdna:184]
[same as prior period, unchanged from 0000936395-14-000051:mdna:265]

[0000936395-15-000024:mdna:185]
[same as prior period, unchanged from 0000936395-14-000051:mdna:266]

[0000936395-15-000024:mdna:186]
[same as prior period, unchanged from 0000936395-14-000051:mdna:267]

[0000936395-15-000024:mdna:187]
Our total deferred revenue for products was $50.5 million and $58.0 million as of October 31, 2014 and January 31, 2015, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $95.2 million and $94.5 million as of October 31, 2014 and January 31, 2015, respectively.

[0000936395-15-000024:mdna:188]
[same as prior period, unchanged from 0000936395-14-000051:mdna:269]

[0000936395-15-000024:mdna:189]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards, net of estimated forfeitures, as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-15-000024:mdna:190]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 18 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of January 31, 2015, total unrecognized compensation expense was $82.9 million, which relates to unvested restricted stock units and this expense is expected to be recognized over a weighted-average period of 1.6 years.

[0000936395-15-000024:mdna:191]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net

[0000936395-15-000024:mdna:192]
operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.

[0000936395-15-000024:mdna:193]
[same as prior period, unchanged from 0000936395-14-000051:mdna:274]

[0000936395-15-000024:mdna:194]
[same as prior period, unchanged from 0000936395-14-000051:mdna:275]

[0000936395-15-000024:mdna:195]
For fiscal 2015, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2015. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for incentive compensation in any interim period in fiscal 2015 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are higher or lower than expected. We incurred an aggregate of $14.0 million of expense in the first three months of fiscal 2015 associated with our cash incentive bonus plan for fiscal 2015.

[0000936395-15-000024:mdna:196]
[same as prior period, unchanged from 0000936395-14-000051:mdna:277]

[0000936395-15-000024:mdna:197]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $5.4 million and $5.8 million in the first three months of fiscal 2014 and 2015, respectively. The charges in fiscal 2015 primarily related to the discontinuance of certain parts and components used in the manufacture of Converged Packet Optical products and decreases in forecasted demand for our legacy, stand-alone WDM and SONET/SDH-based transport platforms and our 5410 Service Aggregation Switch. Our inventory net of allowance for excess and obsolescence was $254.7 million and $241.1 million as of October 31, 2014 and January 31, 2015, respectively.

[0000936395-15-000024:mdna:198]
[same as prior period, unchanged from 0000936395-14-000051:mdna:279]

[0000936395-15-000024:mdna:199]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $519.0 million and $513.6 million as of October 31, 2014 and January 31, 2015, respectively. Our allowance for doubtful accounts was $2.1 million and $2.0 million as of October 31, 2014 and January 31, 2015, respectively.

[0000936395-15-000024:mdna:200]
[same as prior period, unchanged from 0000936395-14-000051:mdna:282]

[0000936395-15-000024:mdna:201]
Our long-lived assets include: equipment, furniture and fixtures, finite-lived intangible assets and maintenance spares. As of October 31, 2014 and January 31, 2015, these assets totaled $309.4 million and $300.1 million, net, respectively. We test

[0000936395-15-000024:mdna:202]
long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows.We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-15-000024:mdna:203]
[same as prior period, unchanged from 0000936395-14-000051:mdna:284]

[0000936395-15-000024:mdna:204]
As of January 31, 2015, we have recorded a valuation allowance offsetting substantially all our net deferred tax assets of  $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to make judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies and tax planning strategies. The valuation allowance is reviewed quarterly and is maintained until sufficient positive evidence exists to support a reversal. Because evidence such as our operating results during the most recent three-year period is afforded more weight than forecasted results for future periods, our cumulative loss during this three-year period represents sufficient negative evidence regarding the need for nearly a full valuation allowance. We will release this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-15-000024:mdna:205]
[same as prior period, unchanged from 0000936395-14-000051:mdna:286]

[0000936395-15-000024:mdna:206]
Our liability for product warranties, included in other accrued liabilities, was $56.0 million and $53.4 million as of October 31, 2014 and January 31, 2015, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $8.0 million and $2.3 million for the first three months of fiscal 2014 and 2015, respectively. See Note 12 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
