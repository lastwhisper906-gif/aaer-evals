# CIEN 8-K — 0000936395-15-000017 filed 2015-03-05

## item codes, every 8-K on or before 2015-03-12

- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2015-03-12

- none on or before 2015-03-12

## item 2.02 — earnings release, exhibit 99.1

[0000936395-15-000017:8k_2_02:1]
EX-99.1
2
exhibit-2015q1earningspres.htm
EXHIBIT 99.1

[0000936395-15-000017:8k_2_02:2]
Exhibit - 2015 Q1 Earnings Press Release

[0000936395-15-000017:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-15-000017:8k_2_02:4]
Ciena Reports Fiscal First Quarter 2015 Financial Results

[0000936395-15-000017:8k_2_02:5]
Demonstrates continued operating leverage improvement with strong quarterly operating profit

[0000936395-15-000017:8k_2_02:6]
HANOVER, Md. - March 5, 2015 - Ciena® Corporation (NYSE:  CIEN), the network specialist, today announced unaudited financial results for its fiscal first quarter ended January 31, 2015.

[0000936395-15-000017:8k_2_02:7]
For the fiscal first quarter 2015, Ciena reported revenue of $529.2 million as compared to $533.7 million for the fiscal first quarter 2014.

[0000936395-15-000017:8k_2_02:8]
On the basis of generally accepted accounting principles (GAAP), Ciena's net loss for the fiscal first quarter 2015 was $(18.8) million, or $(0.17) per diluted common share, which compares to a GAAP net loss of $(15.9) million, or $(0.15) per diluted common share, for the fiscal first quarter 2014.

[0000936395-15-000017:8k_2_02:9]
Ciena's adjusted (non-GAAP) net income for the fiscal first quarter 2015 was $13.6 million, or $0.12 per diluted common share, which compares to an adjusted (non-GAAP) net income of $13.7 million, or $0.13 per diluted common share, for the fiscal first quarter 2014.

[0000936395-15-000017:8k_2_02:10]
“Our first quarter performance is highlighted by continued customer diversification, an expanding portfolio, and strong profitability. While order timing and foreign exchange headwinds impacted revenue in the quarter, we delivered improved gross margin and excellent operating profit," said Gary B. Smith, president and CEO of Ciena. "We are consistently delivering on our business model and are well positioned to capitalize on our leadership in driving an open, global network for the cloud."

[0000936395-15-000017:8k_2_02:11]
Fiscal First Quarter 2015 Performance Summary

[0000936395-15-000017:8k_2_02:12]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarter and year-over-year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendix A.

[0000936395-15-000017:8k_2_02:13]
|  |  | GAAP Results |
|  |  | Q1 |  | Q4 |  | Q1 |  | Period Change |
|  |  | FY 2015 |  | FY 2014 |  | FY 2014 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 529.2 |  |  | $ | 591.0 |  |  | $ | 533.7 |  |  | (10.5 | )% |  | (0.8 | )% |
| Gross margin |  | 43.5 | % |  | 37.4 | % |  | 42.3 | % |  | 6.1 | % |  | 1.2 | % |
| Operating expense |  | $ | 226.1 |  |  | $ | 222.7 |  |  | $ | 222.5 |  |  | 1.5 | % |  | 1.6 | % |
| Operating margin |  | 0.8 | % |  | (0.3 | )% |  | 0.6 | % |  | 1.1 | % |  | 0.2 | % |

[0000936395-15-000017:8k_2_02:14]
|  |  | Non-GAAP Results |
|  |  | Q1 |  | Q4 |  | Q1 |  | Period Change |
|  |  | FY 2015 |  | FY 2014 |  | FY 2014 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 529.2 |  |  | $ | 591.0 |  |  | $ | 533.7 |  |  | (10.5 | )% |  | (0.8 | )% |
| Adj. gross margin |  | 44.1 | % |  | 37.9 | % |  | 43.4 | % |  | 6.2 | % |  | 0.7 | % |
| Adj. operating expense |  | $ | 197.3 |  |  | $ | 203.7 |  |  | $ | 199.8 |  |  | (3.1 | )% |  | (1.3 | )% |
| Adj. operating margin |  | 6.8 | % |  | 3.4 | % |  | 5.9 | % |  | 3.4 | % |  | 0.9 | % |

[0000936395-15-000017:8k_2_02:15]
|  |  | Revenue by Segment |
|  |  | Q1 FY 2015 |  | Q4 FY 2014 |  | Q1 FY 2014 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| Converged Packet Optical |  | $ | 336.6 |  |  | 63.6 |  | $ | 383.3 |  |  | 64.9 |  | $ | 333.4 |  |  | 62.5 |
| Packet Networking |  | 55.0 |  |  | 10.4 |  | 56.4 |  |  | 9.5 |  | 51.7 |  |  | 9.7 |
| Optical Transport |  | 22.3 |  |  | 4.2 |  | 26.5 |  |  | 4.5 |  | 40.1 |  |  | 7.5 |
| Software and Services |  | 115.3 |  |  | 21.8 |  | 124.8 |  |  | 21.1 |  | 108.5 |  |  | 20.3 |
| Total |  | $ | 529.2 |  |  | 100.0 |  | $ | 591.0 |  |  | 100.0 |  | $ | 533.7 |  |  | 100.0 |

[0000936395-15-000017:8k_2_02:16]
| * Denotes % change, or in the case of margin, absolute change |

[0000936395-15-000017:8k_2_02:17]
Additional Performance Metrics for Fiscal First Quarter 2015

[0000936395-15-000017:8k_2_02:18]
|  |  | Revenue by Geographic Region |
|  |  | Q1 FY 2015 |  | Q4 FY 2014 |  | Q1 FY 2014 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| North America |  | 331.5 |  |  | 62.6 |  | 340.5 |  |  | 57.6 |  | 355.8 |  |  | 66.7 |
| Europe, Middle East and Africa |  | 111.0 |  |  | 21.0 |  | 133.7 |  |  | 22.6 |  | 88.7 |  |  | 16.6 |
| Caribbean and Latin America |  | 42.8 |  |  | 8.1 |  | 51.8 |  |  | 8.8 |  | 52.7 |  |  | 9.9 |
| Asia Pacific |  | 43.9 |  |  | 8.3 |  | 65.0 |  |  | 11.0 |  | 36.5 |  |  | 6.8 |
| Total |  | $ | 529.2 |  |  | 100.0 |  | $ | 591.0 |  |  | 100.0 |  | $ | 533.7 |  |  | 100.0 |

[0000936395-15-000017:8k_2_02:19]
| • | U.S. customers contributed 56.3% of total revenue |

[0000936395-15-000017:8k_2_02:20]
| • | One customer accounted for greater than 10% of revenue and represented 22% of total revenue |

[0000936395-15-000017:8k_2_02:21]
| • | Cash and investments totaled $799.0 million |

[0000936395-15-000017:8k_2_02:22]
| • | Cash flow from operations totaled $22.1 million |

[0000936395-15-000017:8k_2_02:23]
| • | Average days' sales outstanding (DSOs) were 87 |

[0000936395-15-000017:8k_2_02:24]
| • | Accounts receivable balance was $513.6 million |

[0000936395-15-000017:8k_2_02:25]
| • | Inventories totaled $241.1 million, including: |

[0000936395-15-000017:8k_2_02:26]
| ◦ | Raw materials: $53.9 million |

[0000936395-15-000017:8k_2_02:27]
| ◦ | Work in process: $9.4 million |

[0000936395-15-000017:8k_2_02:28]
| ◦ | Finished goods: $159.6 million |

[0000936395-15-000017:8k_2_02:29]
| ◦ | Deferred cost of sales: $70.2 million |

[0000936395-15-000017:8k_2_02:30]
| ◦ | Reserve for excess and obsolescence: $(52.0) million |

[0000936395-15-000017:8k_2_02:31]
| • | Product inventory turns were 3.9 |

[0000936395-15-000017:8k_2_02:32]
| • | Headcount totaled 5,070 |

[0000936395-15-000017:8k_2_02:33]
Business Outlook for Fiscal Second Quarter 2015

[0000936395-15-000017:8k_2_02:34]
Statements relating to business outlook are forward-looking in nature and actual results may differ materially. These statements should be read in the context of the Notes to Investors below.

[0000936395-15-000017:8k_2_02:35]
Ciena expects fiscal second quarter 2015 financial performance to include:

[0000936395-15-000017:8k_2_02:36]
| • | Revenue in the range of $585 to $615 million |

[0000936395-15-000017:8k_2_02:37]
| • | Adjusted (non-GAAP) gross margin between 42 percent and 43 percent |

[0000936395-15-000017:8k_2_02:38]
| • | Adjusted (non-GAAP) operating expense to be approximately $210 million |

[0000936395-15-000017:8k_2_02:39]
Live Web Broadcast of Unaudited Fiscal First Quarter 2015 Results

[0000936395-15-000017:8k_2_02:40]
Ciena will host a discussion of its unaudited fiscal first quarter 2015 results with investors and financial analysts today, Thursday, March 5, 2014 at 8:30 a.m. (Eastern). The live broadcast of the discussion will be available via Ciena's homepage at www.ciena.com. An archived transcript of the discussion will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at www.ciena.com/investors.

[0000936395-15-000017:8k_2_02:41]
To accompany its live broadcast, Ciena has posted to the Investor Relations page of its website at www.ciena.com/investors a presentation that includes certain highlighted information to be discussed on the call and certain historical results of operations.

[0000936395-15-000017:8k_2_02:42]
Notes to Investors

[0000936395-15-000017:8k_2_02:43]
Forward-looking statements. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: “Our first quarter performance is highlighted by continued customer diversification, an expanding portfolio, and strong profitability"; "While order timing and foreign exchange headwinds impacted revenue in the quarter, we delivered improved gross margin and excellent operating profit"; "We are consistently delivering on our business model and are well positioned to capitalize on our leadership in driving an open, global network for the cloud"; "Ciena expects fiscal second quarter 2015 financial performance to include: Revenue in the range of $585 to $615 million; Adjusted (non-GAAP) gross margin between 42 percent and 43 percent; Adjusted (non-GAAP) operating expense to be approximately $210 million."

[0000936395-15-000017:8k_2_02:44]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-K, which Ciena filed with the Securities and Exchange Commission on December 19, 2014. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-15-000017:8k_2_02:45]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income (loss) from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not

[0000936395-15-000017:8k_2_02:46]
expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-15-000017:8k_2_02:47]
About Ciena.  Ciena (NYSE: CIEN) is the network specialist. We collaborate with customers worldwide to unlock the strategic potential of their networks and fundamentally change the way they perform and compete. Ciena leverages its deep expertise in packet and optical networking and distributed software automation to deliver solutions in alignment with its OPn architecture for next-generation networks. We enable a high-scale, programmable infrastructure that can be controlled and adapted by network-level applications, and provide open interfaces to coordinate computing, storage and network resources in a unified, virtualized environment. For updates on Ciena news, follow us on Twitter @Ciena or on LinkedIn at http://www.linkedin.com/company/ciena. Investors are encouraged to review the Investors section of our website at www.ciena.com/investors, where we routinely post press releases, SEC filings, recent news, financial results, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use.

[0000936395-15-000017:8k_2_02:48]
CIENA CORPORATION

[0000936395-15-000017:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-15-000017:8k_2_02:50]
(in thousands, except per share data)

[0000936395-15-000017:8k_2_02:51]
(unaudited)

[0000936395-15-000017:8k_2_02:52]
|  | Quarter Ended January 31, |
|  | 2014 |  | 2015 |
| Revenue: |  |  |  |
| Products | $ | 432,941 |  |  | $ | 422,315 |  |
| Services | 100,762 |  |  | 106,847 |  |
| Total revenue | 533,703 |  |  | 529,162 |  |
| Cost of goods sold: |  |  |  |
| Products | 245,216 |  |  | 236,548 |  |
| Services | 62,636 |  |  | 62,319 |  |
| Total cost of goods sold | 307,852 |  |  | 298,867 |  |
| Gross profit | 225,851 |  |  | 230,295 |  |
| Operating expenses: |  |  |  |
| Research and development | 101,497 |  |  | 100,761 |  |
| Selling and marketing | 78,348 |  |  | 76,712 |  |
| General and administrative | 30,097 |  |  | 29,553 |  |
| Amortization of intangible assets | 12,439 |  |  | 11,019 |  |
| Restructuring costs | 115 |  |  | 8,085 |  |
| Total operating expenses | 222,496 |  |  | 226,130 |  |
| Income from operations | 3,355 |  |  | 4,165 |  |
| Interest and other income (loss), net | (5,998 | ) |  | (8,233 | ) |
| Interest expense | (11,028 | ) |  | (13,661 | ) |
| Loss before income taxes | (13,671 | ) |  | (17,729 | ) |
| Provision for income taxes | 2,265 |  |  | 1,050 |  |
| Net loss | $ | (15,936 | ) |  | $ | (18,779 | ) |
| Net Loss per Common Share |  |  |  |
| Basic net loss per common share | $ | (0.15 | ) |  | $ | (0.17 | ) |
| Diluted net loss per potential common share | $ | (0.15 | ) |  | $ | (0.17 | ) |
| Weighted average basic common shares outstanding | 104,501 |  |  | 107,773 |  |
| Weighted average dilutive potential common shares outstanding | 104,501 |  |  | 107,773 |  |

[0000936395-15-000017:8k_2_02:53]
CIENA CORPORATION

[0000936395-15-000017:8k_2_02:54]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-15-000017:8k_2_02:55]
(in thousands, except share data)

[0000936395-15-000017:8k_2_02:56]
(unaudited)

[0000936395-15-000017:8k_2_02:57]
|  | October 31, 2014 |  | January 31, 2015 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 586,720 |  |  | $ | 598,723 |  |
| Short-term investments | 140,205 |  |  | 145,154 |  |
| Accounts receivable, net | 518,981 |  |  | 513,554 |  |
| Inventories | 254,660 |  |  | 241,118 |  |
| Prepaid expenses and other | 192,624 |  |  | 182,818 |  |
| Total current assets | 1,693,190 |  |  | 1,681,367 |  |
| Long-term investments | 50,057 |  |  | 55,153 |  |
| Equipment, furniture and fixtures, net | 126,632 |  |  | 119,403 |  |
| Other intangible assets, net | 128,677 |  |  | 115,458 |  |
| Other long-term assets | 74,076 |  |  | 84,774 |  |
| Total assets | $ | 2,072,632 |  |  | $ | 2,056,155 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 209,777 |  |  | $ | 192,109 |  |
| Accrued liabilities | 276,608 |  |  | 289,984 |  |
| Deferred revenue | 104,688 |  |  | 106,486 |  |
| Current portion of long-term debt | 190,063 |  |  | 190,020 |  |
| Total current liabilities | 781,136 |  |  | 778,599 |  |
| Long-term deferred revenue | 40,930 |  |  | 46,052 |  |
| Other long-term obligations | 45,390 |  |  | 44,596 |  |
| Long-term debt, net | 1,274,791 |  |  | 1,275,483 |  |
| Total liabilities | $2,142,247 |  | $2,144,730 |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity (deficit): |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 106,979,960 and 108,246,661 shares issued and outstanding | 1,070 |  |  | 1,082 |  |
| Additional paid-in capital | 5,954,440 |  |  | 5,973,537 |  |
| Accumulated other comprehensive loss | (14,668 | ) |  | (33,958 | ) |
| Accumulated deficit | (6,010,457 | ) |  | (6,029,236 | ) |
| Total stockholders’ equity (deficit) | (69,615 | ) |  | (88,575 | ) |
| Total liabilities and stockholders’ equity (deficit) | $ | 2,072,632 |  |  | $ | 2,056,155 |  |

[0000936395-15-000017:8k_2_02:58]
CIENA CORPORATION

[0000936395-15-000017:8k_2_02:59]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-15-000017:8k_2_02:60]
(in thousands)

[0000936395-15-000017:8k_2_02:61]
(unaudited)

[0000936395-15-000017:8k_2_02:62]
|  | Three Months Ended January 31, |
|  | 2014 |  | 2015 |
| Cash flows provided by (used in) operating activities: |  |  |  |
| Net loss | $ | (15,936 | ) |  | $ | (18,779 | ) |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 13,328 |  |  | 13,772 |  |
| Share-based compensation costs | 11,392 |  |  | 10,807 |  |
| Amortization of intangible assets | 16,890 |  |  | 13,219 |  |
| Provision for inventory excess and obsolescence | 5,439 |  |  | 5,787 |  |
| Provision for warranty | 7,974 |  |  | 2,293 |  |
| Other | 2,175 |  |  | (10,689 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (31,291 | ) |  | 5,362 |  |
| Inventories | (40,460 | ) |  | 7,755 |  |
| Prepaid expenses and other | (252 | ) |  | (4,473 | ) |
| Accounts payable, accruals and other obligations | (14,647 | ) |  | (9,836 | ) |
| Deferred revenue | 8,230 |  |  | 6,920 |  |
| Net cash provided by (used in) operating activities | (37,158 | ) |  | 22,138 |  |
| Cash flows provided by (used in) investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (15,776 | ) |  | (11,194 | ) |
| Restricted cash | (33 | ) |  | — |  |
| Purchase of available for sale securities | (54,991 | ) |  | (50,085 | ) |
| Proceeds from maturities of available for sale securities | 85,000 |  |  | 40,000 |  |
| Settlement of foreign currency forward contracts, net | 441 |  |  | 9,314 |  |
| Net cash provided by (used in) investing activities | 14,641 |  |  | (11,965 | ) |
| Cash flows from financing activities: |  |  |  |
| Payment of long term debt | — |  |  | (625 | ) |
| Payment for debt and equity issuance costs | — |  |  | (60 | ) |
| Payment of capital lease obligations | (762 | ) |  | (2,993 | ) |
| Proceeds from issuance of common stock | 7,412 |  |  | 8,302 |  |
| Net cash provided by financing activities | 6,650 |  |  | 4,624 |  |
| Effect of exchange rate changes on cash and cash equivalents | (536 | ) |  | (2,794 | ) |
| Net increase (decrease) in cash and cash equivalents | (15,867 | ) |  | 14,797 |  |
| Cash and cash equivalents at beginning of period | 346,487 |  |  | 586,720 |  |
| Cash and cash equivalents at end of period | $ | 330,084 |  |  | $ | 598,723 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 6,333 |  |  | $ | 8,754 |  |
| Cash paid during the period for income taxes, net | $ | 4,086 |  |  | $ | 2,894 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 4,401 |  |  | $ | 3,270 |  |
| Debt issuance costs in accrued liabilities | $ | — |  |  | $ | 178 |  |

[0000936395-15-000017:8k_2_02:63]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements |
|  |  | Quarter Ended |
|  |  | January 31, |
|  |  | 2014 |  | 2015 |
| Gross Profit Reconciliation |  |  |  |  |
| GAAP gross profit |  | $ | 225,851 |  |  | $ | 230,295 |  |
| Share-based compensation-products |  | 506 |  |  | 487 |  |
| Share-based compensation-services |  | 580 |  |  | 519 |  |
| Amortization of intangible assets |  | 4,451 |  |  | 2,200 |  |
| Total adjustments related to gross profit |  | 5,537 |  |  | 3,206 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 231,388 |  |  | $ | 233,501 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.4 | % |  | 44.1 | % |
| Operating Expense Reconciliation |  |  |  |  |
| GAAP operating expense |  | $ | 222,496 |  |  | $ | 226,130 |  |
| Share-based compensation-research and development |  | 2,572 |  |  | 2,167 |  |
| Share-based compensation-sales and marketing |  | 4,063 |  |  | 3,659 |  |
| Share-based compensation-general and administrative |  | 3,506 |  |  | 3,919 |  |
| Amortization of intangible assets |  | 12,439 |  |  | 11,019 |  |
| Restructuring costs |  | 115 |  |  | 8,085 |  |
| Total adjustments related to operating expense |  | 22,695 |  |  | 28,849 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 199,801 |  |  | $ | 197,281 |  |
| Income from Operations Reconciliation |  |  |  |  |
| GAAP income from operations |  | $ | 3,355 |  |  | $ | 4,165 |  |
| Total adjustments related to gross profit |  | 5,537 |  |  | 3,206 |  |
| Total adjustments related to operating expense |  | 22,695 |  |  | 28,849 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 31,587 |  |  | 36,220 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 5.9 | % |  | 6.8 | % |
| Net Income (Loss) Reconciliation |  |  |  |  |
| GAAP net income (loss) |  | $ | (15,936 | ) |  | $ | (18,779 | ) |
| Total adjustments related to gross profit |  | 5,537 |  |  | 3,206 |  |
| Total adjustments related to operating expense |  | 22,695 |  |  | 28,849 |  |
| Non-cash interest expense |  | 293 |  |  | 361 |  |
| Change in fair value of embedded redemption feature |  | 1,090 |  |  | — |  |
| Adjusted (non-GAAP) net income |  | $ | 13,679 |  |  | $ | 13,637 |  |
| Weighted average basic common shares outstanding |  | 104,501 |  |  | 107,773 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 119,789 |  |  | 121,896 |  |
| Net Income (Loss) per Common Share |  |  |  |  |
| GAAP diluted net income (loss) per common share |  | $ | (0.15 | ) |  | $ | (0.17 | ) |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.13 |  |  | $ | 0.12 |  |

[0000936395-15-000017:8k_2_02:64]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2014 includes 2.2 million shares underlying certain stock options and restricted stock units, and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017. |

[0000936395-15-000017:8k_2_02:65]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2015 includes 1.0 million shares underlying certain stock options and restricted stock units and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-15-000017:8k_2_02:66]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the fiscal first quarter of 2014 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-15-000017:8k_2_02:67]
The calculation of Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2015 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-15-000017:8k_2_02:68]
* * *

[0000936395-15-000017:8k_2_02:69]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-15-000017:8k_2_02:70]
| • | Share-based compensation expense - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-15-000017:8k_2_02:71]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-15-000017:8k_2_02:72]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. During the fiscal quarter ended January 31, 2015, Ciena recorded a charge of $8.1 million of severance and other employee-related costs associated with a global workforce reduction of approximately 125 employees to address organizational realignment and the reallocation of resources toward strategic growth areas of the business. |

[0000936395-15-000017:8k_2_02:73]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-15-000017:8k_2_02:74]
| • | Change in fair value of embedded redemption feature - a non-cash unrealized gain or loss reflective of a mark to market fair value adjustment of an embedded derivative related to the redemption feature of Ciena's outstanding 4.0% senior convertible notes due March 15, 2015. |
