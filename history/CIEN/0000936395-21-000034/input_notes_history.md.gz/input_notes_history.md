# CIEN note change history — 0000936395-21-000010 → 0000936395-21-000034


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-06-09):
[0000936395-21-000034:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $46.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject
  (was, 2021-03-10, similarity 0.7891):
[0000936395-21-000010:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.1 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 30, 2021, Ciena has recorded CAD$44.2 million (approximately $34.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$3.6 million ($2.8 million) was recorded in the first three months of fiscal 2021. As of January 30, 2021, amounts receivable from this grant were CAD$3.2 million ($2.5 million).

- added (2021-06-09):
[0000936395-21-000034:note_history:2]
to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of May 1, 2021, Ciena has recorded CAD$45.5 million (approximately $37.0 million) in cumulative benefits as a reduction in research and development expense of which CAD$4.9 million ($3.8 million) was recorded in the first six months of fiscal 2021. As of May 1, 2021, amounts receivable from this grant were CAD$2.7 million ($2.2 million).


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-06-09):
[0000936395-21-000034:note_history:3]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022, and early adoption is permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
  (was, 2021-03-10, similarity 0.9812):
[0000936395-21-000010:note_history:3]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which enhances and simplifies various aspects related to accounting for income taxes by removing certain exceptions to the general principles in ASC 740.  The amendments also improve consistent application of and simplify U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022, and early adoption is permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-06-09):
[0000936395-21-000034:note_history:4]
The net carrying value of Ciena’s term loan was comprised of the following for the periods indicated (in thousands):
  (was, 2021-03-10, similarity 0.9707):
[0000936395-21-000010:note_history:4]
The net carrying value of Ciena’s term loan was comprised of the following for the fiscal periods indicated (in thousands):

- added (2021-06-09):
[0000936395-21-000034:note_history:5]
|  |  | May 1, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 684,337 |  |  | $ | (1,414) |  |  | $ | (2,638) |  |  | $ | 680,285 |  |  | $ | 683,286 |  |

- changed (2021-06-09):
[0000936395-21-000034:note_history:6]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loan totaled $2.6 million as of May 1, 2021 and $2.9 million at October 31, 2020. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.3 million during the first six months of each of fiscal 2021 and fiscal 2020. The carrying value of the term loan listed above is also net of any unamortized debt discounts.
  (was, 2021-03-10, similarity 0.9811):
[0000936395-21-000010:note_history:6]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loan totaled $2.8 million at January 30, 2021 and $2.9 million at October 31, 2020. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.2 million during the first three months of each of fiscal 2021 and fiscal 2020. The carrying value of the term loan listed above is also net of any unamortized debt discounts.

- changed (2021-06-09):
[0000936395-21-000034:note_history:7]
As of May 1, 2021, the estimated fair value of the 2025 Term Loan was $685.2 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2021-03-10, similarity 0.9874):
[0000936395-21-000010:note_history:7]
As of January 30, 2021, the estimated fair value of the 2025 Term Loan was $686.1 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2021-06-09):
[0000936395-21-000010:note_history:8]
|  |  | January 30, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 686,070 |  |  | $ | (1,495) |  |  | $ | (2,789) |  |  | $ | 681,786 |  |  | $ | 683,286 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-06-09):
[0000936395-21-000034:note_history:9]
|  | May 1, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,764 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 151,816 |  |
| Included in long-term investments | 91,695 |  |  | 22 |  |  | (2) |  |  | 91,715 |  |
|  | $ | 243,459 |  |  | $ | 74 |  |  | $ | (2) |  |  | $ | 243,531 |  |
  (was, 2021-03-10, similarity 0.811):
[0000936395-21-000010:note_history:9]
|  | January 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,420 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 151,434 |  |
| Included in long-term investments | 102,360 |  |  | 4 |  |  | — |  |  | 102,364 |  |
|  | $ | 253,780 |  |  | $ | 18 |  |  | $ | — |  |  | $ | 253,798 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-06-09):
[0000936395-21-000034:note_history:10]
|  | May 1, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,764 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 151,816 |  |
| Included in long-term investments | 91,695 |  |  | 22 |  |  | (2) |  |  | 91,715 |  |
|  | $ | 243,459 |  |  | $ | 74 |  |  | $ | (2) |  |  | $ | 243,531 |  |
  (was, 2021-03-10, similarity 0.811):
[0000936395-21-000010:note_history:10]
|  | January 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,420 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 151,434 |  |
| Included in long-term investments | 102,360 |  |  | 4 |  |  | — |  |  | 102,364 |  |
|  | $ | 253,780 |  |  | $ | 18 |  |  | $ | — |  |  | $ | 253,798 |  |

- changed (2021-06-09):
[0000936395-21-000034:note_history:11]
The following table summarizes the final legal maturities of debt investments at May 1, 2021 (in thousands):
  (was, 2021-03-10, similarity 0.9717):
[0000936395-21-000010:note_history:11]
The following table summarizes the final legal maturities of debt investments at January 30, 2021 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-06-09):
[0000936395-21-000034:note_history:12]
The net carrying value of Ciena’s term loan was comprised of the following for the periods indicated (in thousands):
  (was, 2021-03-10, similarity 0.9707):
[0000936395-21-000010:note_history:12]
The net carrying value of Ciena’s term loan was comprised of the following for the fiscal periods indicated (in thousands):

- added (2021-06-09):
[0000936395-21-000034:note_history:13]
|  |  | May 1, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 684,337 |  |  | $ | (1,414) |  |  | $ | (2,638) |  |  | $ | 680,285 |  |  | $ | 683,286 |  |

- removed (2021-06-09):
[0000936395-21-000010:note_history:14]
|  |  | January 30, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 686,070 |  |  | $ | (1,495) |  |  | $ | (2,789) |  |  | $ | 681,786 |  |  | $ | 683,286 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-06-09):
[0000936395-21-000034:note_history:15]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):
  (was, 2021-03-10, similarity 0.9949):
[0000936395-21-000010:note_history:15]
The tables below set forth Ciena’s disaggregated revenue for the respective period (in thousands):

- changed (2021-06-09):
[0000936395-21-000034:note_history:16]
|  | Quarter Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
  (was, 2021-03-10, similarity 0.9966):
[0000936395-21-000010:note_history:16]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |

- changed (2021-06-09):
[0000936395-21-000034:note_history:17]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Routing and Switching | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
  (was, 2021-03-10, similarity 0.9961):
[0000936395-21-000010:note_history:17]
|  | Quarter Ended February 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Routing and Switching | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |

- added (2021-06-09):
[0000936395-21-000034:note_history:18]
|  | Six Months Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

- added (2021-06-09):
[0000936395-21-000034:note_history:19]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Routing Switching | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,519 |  |  | $ | 30,092 |  |  | $ | 8,481 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

- changed (2021-06-09):
[0000936395-21-000034:note_history:20]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 587,475 |  |  | $ | 650,381 |  |  | $ | 1,084,086 |  |  | $ | 1,224,385 |  |
| EMEA |  | 155,054 |  |  | 141,431 |  |  | 310,472 |  |  | 271,396 |  |
| APAC |  | 91,398 |  |  | 102,241 |  |  | 196,499 |  |  | 231,184 |  |
| Total revenue by geographic distribution |  | $ | 833,927 |  |  | $ | 894,053 |  |  | $ | 1,591,057 |  |  | $ | 1,726,965 |  |
  (was, 2021-03-10, similarity 0.7437):
[0000936395-21-000010:note_history:20]
|  |  | Quarter Ended |  |  |
|  |  | January 30, |  | February 1, |  |  |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 496,611 |  |  | $ | 574,004 |  |  |  |  |  |
| EMEA |  | 155,418 |  |  | 129,965 |  |  |  |  |  |
| APAC |  | 105,101 |  |  | 128,943 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 757,130 |  |  | $ | 832,912 |  |  |  |  |  |

- added (2021-06-09):
[0000936395-21-000034:note_history:21]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- changed (2021-06-09):
[0000936395-21-000034:note_history:22]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| AT&T | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 189,640 |  |
| Verizon | n/a |  | n/a |  | n/a |  | 203,630 |  |
| Total | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 393,270 |  |
  (was, 2021-03-10, similarity 0.76):
[0000936395-21-000010:note_history:22]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| AT&T | n/a |  | $ | 84,010 |  |  |  |  |  |
| Verizon | n/a |  | 114,548 |  |  |  |  |  |
| Total | n/a |  | $ | 198,558 |  |  |  |  |  |

- removed (2021-06-09):
[0000936395-21-000010:note_history:23]
For the first quarter of fiscal 2021, there were no customers that accounted for at least 10% of Ciena’s revenue. The table below shows the customers that accounted for at least 10% of Ciena’s revenue for the first quarter of fiscal 2020: (in thousands):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-06-09):
[0000936395-21-000034:note_history:24]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line. Effective as of the beginning of fiscal 2021, Ciena renamed its “Packet Networking” product line to “Routing and Switching.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. References to prior reported “Packet Networking” product line have been changed herein to“Routing and Switching.”
  (was, 2021-03-10, similarity 0.9693):
[0000936395-21-000010:note_history:24]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line. Effective as of the beginning of fiscal 2021, Ciena renamed its “Packet Networking” product line to “Routing and Switching.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. References to prior reported “Packet Networking” product line have been changed to“Routing and Switching” for this product line reported herein.

- changed (2021-06-09):
[0000936395-21-000034:note_history:25]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):
  (was, 2021-03-10, similarity 0.9949):
[0000936395-21-000010:note_history:25]
The tables below set forth Ciena’s disaggregated revenue for the respective period (in thousands):

- changed (2021-06-09):
[0000936395-21-000034:note_history:26]
|  | Quarter Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
  (was, 2021-03-10, similarity 0.9966):
[0000936395-21-000010:note_history:26]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |

- changed (2021-06-09):
[0000936395-21-000034:note_history:27]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Routing and Switching | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
  (was, 2021-03-10, similarity 0.9961):
[0000936395-21-000010:note_history:27]
|  | Quarter Ended February 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Routing and Switching | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |

- added (2021-06-09):
[0000936395-21-000034:note_history:28]
|  | Six Months Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

- added (2021-06-09):
[0000936395-21-000034:note_history:29]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Routing Switching | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,519 |  |  | $ | 30,092 |  |  | $ | 8,481 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

- changed (2021-06-09):
[0000936395-21-000034:note_history:30]
Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.
  (was, 2021-03-10, similarity 0.876):
[0000936395-21-000010:note_history:30]
Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2021-06-09):
[0000936395-21-000034:note_history:31]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 587,475 |  |  | $ | 650,381 |  |  | $ | 1,084,086 |  |  | $ | 1,224,385 |  |
| EMEA |  | 155,054 |  |  | 141,431 |  |  | 310,472 |  |  | 271,396 |  |
| APAC |  | 91,398 |  |  | 102,241 |  |  | 196,499 |  |  | 231,184 |  |
| Total revenue by geographic distribution |  | $ | 833,927 |  |  | $ | 894,053 |  |  | $ | 1,591,057 |  |  | $ | 1,726,965 |  |
  (was, 2021-03-10, similarity 0.7437):
[0000936395-21-000010:note_history:31]
|  |  | Quarter Ended |  |  |
|  |  | January 30, |  | February 1, |  |  |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 496,611 |  |  | $ | 574,004 |  |  |  |  |  |
| EMEA |  | 155,418 |  |  | 129,965 |  |  |  |  |  |
| APAC |  | 105,101 |  |  | 128,943 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 757,130 |  |  | $ | 832,912 |  |  |  |  |  |

- added (2021-06-09):
[0000936395-21-000034:note_history:32]
Ciena’s revenue includes $518.6 million and $598.4 million of United States revenue for the second quarter of fiscal 2021 and 2020, respectively. For the six months ended May 1, 2021 and May 2, 2020, United States revenue was $1.0 billion and $1.1 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- added (2021-06-09):
[0000936395-21-000034:note_history:33]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- changed (2021-06-09):
[0000936395-21-000034:note_history:34]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| AT&T | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 189,640 |  |
| Verizon | n/a |  | n/a |  | n/a |  | 203,630 |  |
| Total | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 393,270 |  |
  (was, 2021-03-10, similarity 0.76):
[0000936395-21-000010:note_history:34]
|  | Quarter Ended |  |  |
|  | January 30, |  | February 1, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| AT&T | n/a |  | $ | 84,010 |  |  |  |  |  |
| Verizon | n/a |  | 114,548 |  |  |  |  |  |
| Total | n/a |  | $ | 198,558 |  |  |  |  |  |

- changed (2021-06-09):
[0000936395-21-000034:note_history:35]
The customers identified above purchased products and services from each of Ciena’s operating segments.
  (was, 2021-03-10, similarity 0.8583):
[0000936395-21-000010:note_history:35]
The customers identified above for the first quarter of fiscal 2020 purchased products and services from each of Ciena’s operating segments.

- changed (2021-06-09):
[0000936395-21-000034:note_history:36]
◦Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS) and the 5400 family of Packet-Optical Platforms. This product line also includes sales of the Z-Series Packet-Optical Platform.
  (was, 2021-03-10, similarity 0.9928):
[0000936395-21-000010:note_history:36]
◦Converged Packet Optical - includes the 6500 Packet-Optical Platform, Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS) and the 5400 family of Packet-Optical Platforms. This product line also includes sales of the Z-Series Packet-Optical Platform.

- added (2021-06-09):
[0000936395-21-000034:note_history:37]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2021-06-09):
[0000936395-21-000034:note_history:38]
•Blue Planet® Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led operations support system (OSS) transformations by transforming legacy networks into “service ready” networks, accelerating the creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform
  (was, 2021-03-10, similarity 0.8589):
[0000936395-21-000010:note_history:38]
•Blue Planet® Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led operations support system (OSS) transformations by transforming legacy networks into “service ready” networks, accelerating the

- changed (2021-06-09):
[0000936395-21-000034:note_history:39]
includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2021-03-10, similarity 0.9185):
[0000936395-21-000010:note_history:39]
creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2021-06-09):
[0000936395-21-000034:note_history:40]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.
  (was, 2021-03-10, similarity 0.9909):
[0000936395-21-000010:note_history:40]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- changed (2021-06-09):
[0000936395-21-000034:note_history:41]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over     time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.
  (was, 2021-03-10, similarity 0.9956):
[0000936395-21-000010:note_history:41]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over     time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

- changed (2021-06-09):
[0000936395-21-000034:note_history:42]
|  |  | Balance at May 1, 2021 |  | Balance at October 31, 2020 |
| Accounts receivable, net |  | $ | 716,779 |  |  | $ | 719,405 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 81,437 |  |  | $ | 85,843 |  |
| Deferred revenue |  | $ | 204,299 |  |  | $ | 158,363 |  |
  (was, 2021-03-10, similarity 0.983):
[0000936395-21-000010:note_history:42]
|  |  | Balance at January 30, 2021 |  | Balance at October 31, 2020 |
| Accounts receivable, net |  | $ | 700,025 |  |  | $ | 719,405 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 85,461 |  |  | $ | 85,843 |  |
| Deferred revenue |  | $ | 190,600 |  |  | $ | 158,363 |  |

- changed (2021-06-09):
[0000936395-21-000034:note_history:43]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. See Note 11 below.
  (was, 2021-03-10, similarity 0.9905):
[0000936395-21-000010:note_history:43]
Our contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. See Note 10 below.

- changed (2021-06-09):
[0000936395-21-000034:note_history:44]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $78.0 million and $76.5 million of revenue during the first six months of fiscal 2021 and 2020, respectively, that was included in the deferred revenue balance as of October 31, 2020 and November 2, 2019, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 1, 2021 and May 2, 2020.
  (was, 2021-03-10, similarity 0.8885):
[0000936395-21-000010:note_history:44]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $46.4 million and $49.0 million of revenue during the first three months of fiscal 2021 and 2020 that was included in the deferred revenue balance at October 31, 2020 and November 2, 2019, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 30, 2021 and February 1, 2020.

- changed (2021-06-09):
[0000936395-21-000034:note_history:45]
Capitalized contract acquisition costs consist of deferred sales commissions, were $18.4 million and $15.3 million as of May 1, 2021 and October 31, 2020, respectively, and were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $10.7 million and $10.1 million during the first six months of fiscal 2021 and 2020, respectively, and was included in sales and marketing expense.
  (was, 2021-03-10, similarity 0.9811):
[0000936395-21-000010:note_history:45]
Capitalized contract acquisition costs consist of deferred sales commissions, were $15.7 million and $15.3 million as of January 30, 2021 and October 31, 2020, respectively, and were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $5.5 million and $5.6 million during the first three months of fiscal 2021 and 2020, respectively, and was included in sales and marketing expense.

- added (2021-06-09):
[0000936395-21-000034:note_history:46]
Remaining Performance Obligations

- changed (2021-06-09):
[0000936395-21-000034:note_history:47]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of May 1, 2021, the 
aggregate amount of RPO was $1.4 billion. As of May 1, 2021, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.
  (was, 2021-03-10, similarity 0.94):
[0000936395-21-000010:note_history:47]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 30, 2021, the aggregate amount of RPO was $1.1 billion. As of January 30, 2021, Ciena expects approximately 80% of the RPO to be recognized as revenue within the next twelve months.

- removed (2021-06-09):
[0000936395-21-000010:note_history:48]
Ciena’s revenue includes $439.4 million and $524.3 million of United States revenue for the first quarter of fiscal 2021 and 2020, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- removed (2021-06-09):
[0000936395-21-000010:note_history:49]
For the first quarter of fiscal 2021, there were no customers that accounted for at least 10% of Ciena’s revenue. The table below shows the customers that accounted for at least 10% of Ciena’s revenue for the first quarter of fiscal 2020: (in thousands):

- removed (2021-06-09):
[0000936395-21-000010:note_history:50]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support our installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-06-09):
[0000936395-21-000034:note_history:51]
From the end of the second quarter of fiscal 2021 through June 4, 2021, Ciena repurchased an additional 195,920 shares of its common stock, for an aggregate purchase price of $10.4 million at an average price of $52.84 per share, inclusive of repurchases pending settlement. As of June 4, 2021, Ciena has repurchased an aggregate of 6,641,907 shares and has an aggregate of $225.6 million of authorized funds remaining under its stock repurchase program.
  (was, 2021-03-10, similarity 0.9652):
[0000936395-21-000010:note_history:51]
From the end of the first quarter of fiscal 2021 through March 5, 2021, Ciena repurchased an additional 188,169 shares of its common stock, for an aggregate purchase price of $10.1 million at an average price of $53.69 per share, inclusive of repurchases pending settlement. As of March 5, 2021, Ciena has repurchased an aggregate of 6,150,659 shares and has an aggregate of $252.1 million of authorized funds remaining under its stock repurchase program.
