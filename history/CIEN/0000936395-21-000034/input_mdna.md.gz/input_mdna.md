# CIEN MD&A — 0000936395-21-000034


## mdna

[0000936395-21-000034:mdna:1]
[same as prior period, unchanged from 0000936395-21-000010:mdna:1]

[0000936395-21-000034:mdna:2]
[same as prior period, unchanged from 0000936395-21-000010:mdna:2]

[0000936395-21-000034:mdna:3]
[same as prior period, unchanged from 0000936395-21-000010:mdna:3]

[0000936395-21-000034:mdna:4]
[same as prior period, unchanged from 0000936395-21-000010:mdna:4]

[0000936395-21-000034:mdna:5]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) should be read in conjunction with, our Condensed Consolidated Financial Statements and the accompanying notes thereto included in Item 1 of Part I of this report and our 2020 Annual Report.

[0000936395-21-000034:mdna:6]
[same as prior period, unchanged from 0000936395-21-000010:mdna:6]

[0000936395-21-000034:mdna:7]
[same as prior period, unchanged from 0000936395-21-000010:mdna:7]

[0000936395-21-000034:mdna:8]
Demand for Products & Services. The demand environment for our products and services remains dynamic and continues to be impacted by the effects of the COVID-19 pandemic. For example, constrained spending in the second half of fiscal 2020 and the first quarter of fiscal 2021 contributed to lower revenue in the second quarter of fiscal 2021 as compared to the second quarter of fiscal 2020. However, during the second quarter of fiscal 2021, we experienced higher than typical orders for our products and services among a concentrated set of larger customers with which we have existing positions as a supplier. We believe some portion of these orders likely reflects certain short-term purchasing behaviors based on customer-specific considerations including possible acceleration of future orders due to the implementation of security of supply strategies as a result of the recent strain on the global supply market for semiconductor components and increased quarterly demand to address network requirements following a period of constrained spending in recent quarters. It is unclear whether the increased level of demand we experienced in the second quarter of fiscal 2021 will continue during the remainder of fiscal 2021. Over the longer term, we continue to believe that the unique and increased demands placed on network infrastructures as a result of the COVID-19 pandemic, and the related increase in remote working worldwide, have accelerated certain trends, including cloud network adoption, networking resilience and flexibility, and enhanced network automation.

[0000936395-21-000034:mdna:9]
[same as prior period, unchanged from 0000936395-21-000010:mdna:9]

[0000936395-21-000034:mdna:10]
[same as prior period, unchanged from 0000936395-21-000010:mdna:10]

[0000936395-21-000034:mdna:11]
Market Growth & Conditions. As a result of the impact of the COVID-19 pandemic on market dynamics, particularly in the enterprise business segments of our communications service provider customers, the growth rates in our addressable markets were adversely impacted during the first half of fiscal 2021. It is unclear whether these trends will continue into the second half of fiscal 2021.

[0000936395-21-000034:mdna:12]
Canada Emergency Wage Subsidy (“CEWS”). In April 2020, the government of Canada introduced the CEWS program to help employers offset a portion of their employee wages for a limited period in response to the COVID-19 outbreak, retroactive to March 15, 2020. Amounts from the CEWS program positively impacted our operating expense and measures of profit in the second quarter of fiscal 2021. In the second quarter of fiscal 2021, we recorded CEWS benefits of CAD$51.1 million ($40.4 million), net of certain fees, related to CEWS for claim periods beginning March 15, 2020, including CAD$43.9 million ($34.7 million) related to employee wages from fiscal 2020. The CEWS program is of a limited duration. We do not anticipate a similar proportionate impact on our financial results in future periods and may not receive any benefits from the CEWS program in the future.

[0000936395-21-000034:mdna:13]
The COVID-19 pandemic and countermeasures taken to contain its spread have caused economic and financial disruptions globally. We continue to monitor the situation and actively assess further implications to our business, supply chain, fulfillment operations and customer demand. However, the COVID-19 situation remains dynamic, and the duration and severity of its impact on our business and results of operations in future periods remains uncertain. If the COVID-19 pandemic or its adverse effects become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, such as the new outbreak in India, or we experience more pronounced disruptions in our business or operations, or in economic activity and demand for our products and services generally, our business and results of operations in future periods could be materially adversely affected.

[0000936395-21-000034:mdna:14]
Supply Chain Constraints. Due to increased demand across a range of industries, the global supply market for semiconductor components, which we use in most of our products, has experienced significant strain in recent periods. The market shortage for semiconductor components has impacted lead times and cost of components. We believe these supply chain challenges will persist at least through the second half of fiscal 2021. In addition, some of our suppliers have indicated that as a result of this shortage they intend to cease manufacturing of certain components used in our products. In response to these dynamics, we have implemented mitigation strategies, increased our purchases of inventory for certain components and taken other steps to promote security of supply and resiliency. These dynamics and our resulting mitigating actions may also result in increased product costs of goods sold and inventory levels in the future.

[0000936395-21-000034:mdna:15]
Supply Chain and Distribution Structure. To better accommodate the requirements of a global business, we are evaluating a plan to reorganize our global supply chain and distribution structure more substantially, which would include a legal entity reorganization and related system upgrade. We expect to adopt the plan in the third quarter of fiscal 2021. This reorganization could have a material effect on our financial position and operating results, including a significant one-time tax benefit associated with the recognition of a net deferred tax asset and potential reversal of a portion of the valuation allowance.

[0000936395-21-000034:mdna:16]
[same as prior period, unchanged from 0000936395-21-000010:mdna:13]

[0000936395-21-000034:mdna:17]
[same as prior period, unchanged from 0000936395-21-000010:mdna:14]

[0000936395-21-000034:mdna:18]
[same as prior period, unchanged from 0000936395-21-000010:mdna:15]

[0000936395-21-000034:mdna:19]
Our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. Effective as of the beginning of fiscal 2021, we renamed our “Packet Networking” product line “Routing and Switching.” This change was made on a prospective basis and does not impact comparability of previous financial results or the composition of this product line. References to our “Packet Networking” product line in prior periods have been changed to “Routing and Switching” in this report. See Note 3 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000034:mdna:20]
[same as prior period, unchanged from 0000936395-21-000010:mdna:18]

[0000936395-21-000034:mdna:21]
Currency Fluctuations

[0000936395-21-000034:mdna:22]
Approximately 18.0% of our revenue was non-U.S. Dollar-denominated during both the second quarter and first six months of fiscal 2021, primarily including sales in Euros, Canadian Dollars, Brazilian Reais and British Pounds. During the second quarter of fiscal 2021, as compared to the second quarter of fiscal 2020, and during the first six months of fiscal 2021, as compared to the first six months of fiscal 2020, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue for the second quarter and first six months of fiscal 2021 reported in U.S. Dollars was adversely impacted by approximately $6.8 million, or 0.8%, and $8.7 million or 0.6%, respectively.

[0000936395-21-000034:mdna:23]
Operating Segment Revenue

[0000936395-21-000034:mdna:24]
The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-21-000034:mdna:25]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | 654,294 |  |  |  |  | (12.3) | % |  | $ | 1,085,981 |  |  | $ | 1,245,844 |  |  |  |  | (12.8) | % |
| %** | 68.8 | % |  | 73.2 | % |  |  |  |  |  | 68.2 | % |  | 72.1 | % |  |  |  |  |
| Routing and Switching | 63,628 |  |  | 64,167 |  |  |  |  | (0.8) | % |  | 127,934 |  |  | 131,675 |  |  |  |  | (2.8) | % |
| %** | 7.6 | % |  | 7.2 | % |  |  |  |  |  | 8.0 | % |  | 7.6 | % |  |  |  |  |
| Total Networking Platforms | 637,285 |  |  | 718,461 |  |  |  |  | (11.3) | % |  | 1,213,915 |  |  | 1,377,519 |  |  |  |  | (11.9) | % |
| %** | 76.4 | % |  | 80.4 | % |  |  |  |  |  | 76.2 | % |  | 79.7 | % |  |  |  |  |
| Platform Software and Services | 56,688 |  |  | 44,985 |  |  |  |  | 26.0 | % |  | 106,527 |  |  | 96,873 |  |  |  |  | 10.0 | % |
| %** | 6.8 | % |  | 5.0 | % |  |  |  |  |  | 6.7 | % |  | 5.6 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 23,958 |  |  | 15,017 |  |  |  |  | 59.5 | % |  | 40,892 |  |  | 30,482 |  |  |  |  | 34.2 | % |
| %** | 2.9 | % |  | 1.7 | % |  |  |  |  |  | 2.6 | % |  | 1.8 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 70,418 |  |  | 71,479 |  |  |  |  | (1.5) | % |  | 138,049 |  |  | 133,271 |  |  |  |  | 3.6 | % |
| %** | 8.4 | % |  | 8.0 | % |  |  |  |  |  | 8.7 | % |  | 7.8 | % |  |  |  |  |
| Installation and Deployment | 37,999 |  |  | 34,242 |  |  |  |  | 11.0 | % |  | 77,610 |  |  | 69,196 |  |  |  |  | 12.2 | % |
| %** | 4.6 | % |  | 3.8 | % |  |  |  |  |  | 4.9 | % |  | 4.0 | % |  |  |  |  |
| Consulting and Network Design | 7,579 |  |  | 9,869 |  |  |  |  | (23.2) | % |  | 14,064 |  |  | 19,624 |  |  |  |  | (28.3) | % |
| %** | 0.9 | % |  | 1.1 | % |  |  |  |  |  | 0.9 | % |  | 1.1 | % |  |  |  |  |
| Total Global Services | 115,996 |  |  | 115,590 |  |  |  |  | 0.4 | % |  | 229,723 |  |  | 222,091 |  |  |  |  | 3.4 | % |
| %** | 13.9 | % |  | 12.9 | % |  |  |  |  |  | 14.5 | % |  | 12.9 | % |  |  |  |  |
| Consolidated revenue | $ | 833,927 |  |  | $ | 894,053 |  |  |  |  | (6.7) | % |  | $ | 1,591,057 |  |  | $ | 1,726,965 |  |  |  |  | (7.9) | % |

[0000936395-21-000034:mdna:26]
[same as prior period, unchanged from 0000936395-21-000010:mdna:21]

[0000936395-21-000034:mdna:27]
[same as prior period, unchanged from 0000936395-21-000010:mdna:84]

[0000936395-21-000034:mdna:28]
**     Denotes % of Total Revenue

[0000936395-21-000034:mdna:29]
Quarter ended May 1, 2021 as compared to the quarter ended May 2, 2020

[0000936395-21-000034:mdna:30]
•Networking Platforms segment revenue decreased, primarily reflecting product line sales decreases of $80.6 million of our Converged Packet Optical products.

[0000936395-21-000034:mdna:31]
◦Converged Packet Optical sales decreased, primarily reflecting a sales decrease of $91.7 million of our 6500 Packet-Optical Platform to communications service providers and Web-scale providers. This sales decrease was partially offset by a sales increase of $9.4 million of our Waveserver® products, primarily to communications service providers and Web-scale providers.

[0000936395-21-000034:mdna:32]
◦Routing and Switching sales remained relatively unchanged.

[0000936395-21-000034:mdna:33]
•Platform Software and Services segment revenue increased by $11.7 million, reflecting increases of $8.0 million in software services and $3.7 million in sales of software platforms.

[0000936395-21-000034:mdna:34]
•Blue Planet Automation Software and Services segment revenue increased by $8.9 million, primarily reflecting increases of $7.6 million in sales of software platforms and $1.3 million in related services.

[0000936395-21-000034:mdna:35]
•Global Services segment revenue remained relatively unchanged.

[0000936395-21-000034:mdna:36]
Six months ended May 1, 2021 as compared to the six months ended May 2, 2020

[0000936395-21-000034:mdna:37]
•Networking Platforms segment revenue decreased, reflecting product line sales decreases of $159.9 million of our Converged Packet Optical products and $3.7 million of our Routing and Switching products.

[0000936395-21-000034:mdna:38]
◦Converged Packet Optical sales decreased, primarily reflecting decreases of $190.2 million of our 6500 Packet-Optical Platform, primarily to communications service providers and Web-Scale providers, and $46.9 million of our 5430 Reconfigurable Switching Systems to communications service providers. These sales decreases were partially offset by sales increases of $63.2 million of our Waveserver products, which benefited from increased sales to communications service providers and Web-scale providers, and $17.3 million of our 6500 Reconfigurable Line Service (RLS) primarily to communications service providers.

[0000936395-21-000034:mdna:39]
◦Routing and Switching sales decreased, primarily reflecting sales decreases of $7.0 million of our 6500 Packet Transport System (PTS) and $6.7 million of our 3000 and 5000 families of service delivery and aggregation switches, each to communications service providers. These decreases were partially offset by a sales increase of $9.1 million of our platform independent software to a communications service provider.

[0000936395-21-000034:mdna:40]
•Platform Software and Services segment revenue increased by $9.7 million, reflecting an increase of $14.8 million in software services, offset by a decrease of $5.1 million in sales of software platforms.

[0000936395-21-000034:mdna:41]
•Blue Planet Automation Software and Services segment revenue increased by $10.4 million, reflecting increases of $8.8 million in software sales and $1.6 million in software sales.

[0000936395-21-000034:mdna:42]
•Global Services segment revenue increased, primarily reflecting sales increases of $8.4 million of our installation and deployment services and $4.8 million of our maintenance support and training, partially offset by a sales decrease of $5.6 million of our consulting and network design services.

[0000936395-21-000034:mdna:43]
Revenue by Geographic Region

[0000936395-21-000034:mdna:44]
Our operating segments engage in business and operations across three geographic regions: Americas; EMEA; and APAC. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our EMEA region revenue for the quarter and six months ended May 1, 2021 was primarily driven by increased sales in Great Britain and France. The decrease in our APAC region revenue for the quarter and six months ended May 1, 2021 was primarily driven by decreased sales in Singapore and Japan, partially offset by increased sales in India. The decrease in our Americas region revenue for the quarter and six months ended May 1, 2021 was primarily driven by decreased sales in the United States, partially offset by increased sales in Brazil.

[0000936395-21-000034:mdna:45]
The following table reflects our geographic distribution of revenue, principally based on the relevant location for our delivery of products and performance of services. The table sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-21-000034:mdna:46]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |
| Americas | $ | 587,475 |  |  | $ | 650,381 |  |  |  |  | (9.7) | % |  | $ | 1,084,086 |  |  | $ | 1,224,385 |  |  |  |  | (11.5) | % |
| %** | 70.4 | % |  | 72.7 | % |  |  |  |  |  | 68.1 | % |  | 70.9 | % |  |  |  |  |
| EMEA | 155,054 |  |  | 141,431 |  |  |  |  | 9.6 | % |  | 310,472 |  |  | 271,396 |  |  |  |  | 14.4 | % |
| %** | 18.6 | % |  | 15.8 | % |  |  |  |  |  | 19.5 | % |  | 15.7 | % |  |  |  |  |
| APAC | 91,398 |  |  | 102,241 |  |  |  |  | (10.6) | % |  | 196,499 |  |  | 231,184 |  |  |  |  | (15.0) | % |
| %** | 11.0 | % |  | 11.5 | % |  |  |  |  |  | 12.4 | % |  | 13.4 | % |  |  |  |  |
| Total | $ | 833,927 |  |  | $ | 894,053 |  |  |  |  | (6.7) | % |  | $ | 1,591,057 |  |  | $ | 1,726,965 |  |  |  |  | (7.9) | % |

[0000936395-21-000034:mdna:47]
[same as prior period, unchanged from 0000936395-21-000010:mdna:33]

[0000936395-21-000034:mdna:48]
*    Denotes % change from 2020 to 2021

[0000936395-21-000034:mdna:49]
**     Denotes % of Total Revenue

[0000936395-21-000034:mdna:50]
Quarter ended May 1, 2021 as compared to the quarter ended May 2, 2020

[0000936395-21-000034:mdna:51]
•Americas revenue decreased by $62.9 million, primarily reflecting sales decreases of $70.8 million within our Networking Platforms segment and $3.2 million within our Global Services segment, partially offset by sales increases of $5.7 million within our Platform Software and Services segment and $5.4 million within our Blue Planet

[0000936395-21-000034:mdna:52]
Automation Software and Services segment. The decrease within our Networking Platforms segment reflects a product line sales decrease of $67.7 million of our Converged Packet Optical products, primarily related to a sales decrease of $66.6 million of our 6500 Packet-Optical Platform to communications service providers.

[0000936395-21-000034:mdna:53]
•EMEA revenue increased by $13.6 million, primarily reflecting sales increases of $4.5 million within our Blue Planet Automation Software and Services segment, $4.0 million within our Global Services segment, $3.0 million within our Platform Software and Services segment and $2.1 million within our Networking Platforms segment.

[0000936395-21-000034:mdna:54]
•APAC revenue decreased by $10.8 million, primarily reflecting a sales decrease of $12.5 million within our Networking Platforms segment. Our Networking Platforms segment revenue decrease primarily reflects a decrease of $16.2 million in sales of our 6500 Packet-Optical Platform, partially offset by an increase of $4.3 million in sales of our 3000 and 5000 families of service delivery and aggregation switches.

[0000936395-21-000034:mdna:55]
Six months ended May 1, 2021 as compared to the six months ended May 2, 2020

[0000936395-21-000034:mdna:56]
•Americas revenue decreased by $140.3 million, primarily reflecting a sales decrease of $149.3 million within our Networking Platforms segment, which was partially offset by a sales increase of $7.1 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue decrease reflects product line sales decreases of $141.3 million of Converged Packet Optical products and $7.9 million of Routing and Switching products. Our Converged Packet Optical revenue decrease primarily reflects sales decreases of $143.9 million of our 6500 Packet-Optical Platform and $31.6 million of our 5430 Reconfigurable Switching Systems, partially offset by a sales increase of $22.5 million of our Waveserver products. Our 6500 Packet-Optical Platform revenue decrease primarily reflects decreased sales to communications service providers.

[0000936395-21-000034:mdna:57]
•EMEA revenue increased by $39.1 million, reflecting increases of $21.1 million within our Networking Platforms segment, $7.5 million within our Global Services segment, $5.3 million within our Platform Software and Services segment and $5.2 million within our Blue Planet Automation Software and Services segment.

[0000936395-21-000034:mdna:58]
•APAC revenue decreased by $34.7 million, primarily reflecting decreases of $35.4 million within our Networking Platforms segment, $1.9 million within our Blue Planet Automation Software and Services segment and $1.8 million of our Global Services segment. These decreases were partially offset by a sales increase of $4.4 million within our Platform Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects a decrease of $43.9 million in sales of our 6500 Packet-Optical Platform to communications service providers in Japan, partially offset by an increase of $8.3 million in sales of our Waveserver products primarily to communications service providers and submarine network operators.

[0000936395-21-000034:mdna:59]
[same as prior period, unchanged from 0000936395-21-000010:mdna:39]

[0000936395-21-000034:mdna:60]
[same as prior period, unchanged from 0000936395-21-000010:mdna:40]

[0000936395-21-000034:mdna:61]
CEWS benefits, recorded to the particular line item within cost of goods sold in our Condensed Consolidated Statement of Operations to which the activity relates, were $6.8 million in the second quarter and first six months of fiscal 2021, net of certain fees. For further information relating to our receipt of amounts under the CEWS program, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-21-000034:mdna:62]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |
| Total revenue | $ | 833,927 |  |  | $ | 894,053 |  |  |  |  | (6.7) | % |  | $ | 1,591,057 |  |  | $ | 1,726,965 |  |  |  |  | (7.9) | % |
| Total cost of goods sold | 421,508 |  |  | 480,727 |  |  |  |  | (12.3) | % |  | 820,747 |  |  | 943,104 |  |  |  |  | (13.0) | % |
| Gross profit | $ | 412,419 |  |  | $ | 413,326 |  |  |  |  | (0.2) | % |  | $ | 770,310 |  |  | $ | 783,861 |  |  |  |  | (1.7) | % |
| %** | 49.5 | % |  | 46.2 | % |  |  |  |  |  | 48.4 | % |  | 45.4 | % |  |  |  |  |

[0000936395-21-000034:mdna:63]
[same as prior period, unchanged from 0000936395-21-000010:mdna:43]

[0000936395-21-000034:mdna:64]
*    Denotes % change from 2020 to 2021

[0000936395-21-000034:mdna:65]
**     Denotes % of Total Revenue

[0000936395-21-000034:mdna:66]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |
| Product revenue | $ | 670,043 |  |  | $ | 739,892 |  |  |  |  | (9.4) | % |  | $ | 1,267,263 |  |  | $ | 1,427,107 |  |  |  |  | (11.2) | % |
| Product cost of goods sold | 339,601 |  |  | 405,138 |  |  |  |  | (16.2) | % |  | 654,699 |  |  | 794,151 |  |  |  |  | (17.6) | % |
| Product gross profit | $ | 330,442 |  |  | $ | 334,754 |  |  |  |  | (1.3) | % |  | $ | 612,564 |  |  | $ | 632,956 |  |  |  |  | (3.2) | % |
| %** | 49.3 | % |  | 45.2 | % |  |  |  |  |  | 48.3 | % |  | 44.4 | % |  |  |  |  |

[0000936395-21-000034:mdna:67]
[same as prior period, unchanged from 0000936395-21-000010:mdna:47]

[0000936395-21-000034:mdna:68]
*    Denotes % change from 2020 to 2021

[0000936395-21-000034:mdna:69]
**     Denotes % of Product Revenue

[0000936395-21-000034:mdna:70]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |
| Service revenue | $ | 163,884 |  |  | $ | 154,161 |  |  |  |  | 6.3 | % |  | $ | 323,794 |  |  | $ | 299,858 |  |  |  |  | 8.0 | % |
| Service cost of goods sold | 81,907 |  |  | 75,589 |  |  |  |  | 8.4 | % |  | 166,048 |  |  | 148,953 |  |  |  |  | 11.5 | % |
| Service gross profit | $ | 81,977 |  |  | $ | 78,572 |  |  |  |  | 4.3 | % |  | $ | 157,746 |  |  | $ | 150,905 |  |  |  |  | 4.5 | % |
| % ** | 50.0 | % |  | 51.0 | % |  |  |  |  |  | 48.7 | % |  | 50.3 | % |  |  |  |  |

[0000936395-21-000034:mdna:71]
[same as prior period, unchanged from 0000936395-21-000010:mdna:51]

[0000936395-21-000034:mdna:72]
*    Denotes % change from 2020 to 2021

[0000936395-21-000034:mdna:73]
**     Denotes % of Service Revenue

[0000936395-21-000034:mdna:74]
Quarter ended May 1, 2021 as compared to the quarter ended May 2, 2020

[0000936395-21-000034:mdna:75]
•Gross profit decreased by $0.9 million, partially as a result of lower revenues. Gross profit as a percentage of total revenue (“gross margin”) increased by 330 basis points. Our gross margin benefited significantly from a favorable mix of customers and products, as well as a $6.8 million benefit from the CEWS program which we do not expect to continue at this level. Due to the impact of COVID-19 and related restrictions on sales and marketing activities described in “Overview” above, we continue to see a higher proportion of our revenue consisting of sales of existing technology offerings deployed in the networks of existing customers, as compared to sales to new customers, early stage network deployments for recent design wins, or the introduction of new platforms, which tend to carry lower margins. We expect our gross margins to reduce from these elevated short-term levels as the adverse impact of the pandemic on new business lessens and our overall revenue resumes a more typical composition of revenue from existing and new business.

[0000936395-21-000034:mdna:76]
•Gross profit on products decreased by $4.3 million. Gross profit on products as a percentage of product revenue (“product gross margin”) increased by 410 basis points, primarily due to a favorable mix of customers and products, as described above, continued product cost reductions and a $4.2 million benefit from the CEWS program, partially offset by market-based price compression we encountered during the period.

[0000936395-21-000034:mdna:77]
•Gross profit on services increased by $3.4 million. Gross profit as a percentage of services revenue (“services gross margin”) decreased by 100 basis points, primarily due to lower installation and deployment margins and a lower mix of higher margin consulting and network design services. The lower margins on installation and deployment services were primarily due to certain customer site readiness delays that caused cost inefficiencies. These lower margins were partially offset by increased higher margin maintenance revenues and a $2.6 million benefit from the CEWS program.

[0000936395-21-000034:mdna:78]
Six months ended May 1, 2021 as compared to the six months ended May 2, 2020

[0000936395-21-000034:mdna:79]
•Gross profit decreased by $13.6 million largely due to lower revenues. Gross margin increased by 300 basis points, as our gross margin benefited significantly from product cost reductions, a favorable mix of customers and product lines that we believe to be a short-term effect due to COVID-19 related factors and a $6.8 million benefit from the CEWS program, partially offset by a reduction in our services gross margin.

[0000936395-21-000034:mdna:80]
•Gross profit on products decreased by $20.4 million. Product gross margin increased by 390 basis points, primarily due to product cost reductions, a favorable mix of customers and product lines as described above and a $4.2 million benefit from the CEWS program, partially offset by market-based price compression we encountered during the period.

[0000936395-21-000034:mdna:81]
•Gross profit on services increased by $6.8 million. Services gross margin decreased by 160 basis points, primarily due to lower installation and deployment margins and a lower mix of higher margin consulting and network design services. The lower margins on installation and deployment services were primarily due to certain customer site readiness delays that caused cost inefficiencies. These lower margins were partially offset by increased higher margin maintenance revenues and a $2.6 million benefit from the CEWS program.

[0000936395-21-000034:mdna:82]
[same as prior period, unchanged from 0000936395-21-000010:mdna:57]

[0000936395-21-000034:mdna:83]
Currency Fluctuations

[0000936395-21-000034:mdna:84]
Approximately 42.7% and 47.3% of our operating expense was non-U.S. Dollar-denominated during the second quarter and first six months of fiscal 2021, respectively, including expenses in Canadian Dollars, Indian Rupees and British Pounds. During the second quarter of fiscal 2021, as compared to the second quarter of fiscal 2020, and the first six months of fiscal 2021, as compared to the first six months of fiscal 2020, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense reported in U.S. Dollars slightly increased by approximately $3.4 million, or 1.2%, and $4.8 million, or 0.9%, respectively.

[0000936395-21-000034:mdna:85]
CEWS Benefits

[0000936395-21-000034:mdna:86]
CEWS benefits, recorded to the particular line item within operating expense in our Condensed Consolidated Statement of Operations to which the activity relates, were $33.6 million in the second quarter and first six months of fiscal 2021, net of certain fees. For further information relating to our receipt of amounts under the CEWS program, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000034:mdna:87]
The component elements that comprise each of our operating expense categories in the table below are set forth in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our 2020 Annual Report. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-21-000034:mdna:88]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |
| Research and development | $ | 110,246 |  |  | $ | 131,530 |  |  |  |  | (16.2) | % |  | $ | 242,987 |  |  | $ | 262,430 |  |  |  |  | (7.4) | % |
| %** | 13.2 | % |  | 14.7 | % |  |  |  |  |  | 15.3 | % |  | 15.2 | % |  |  |  |  |
| Selling and marketing | 110,387 |  |  | 101,214 |  |  |  |  | 9.1 | % |  | 207,665 |  |  | 208,280 |  |  |  |  | (0.3) | % |
| %** | 13.2 | % |  | 11.3 | % |  |  |  |  |  | 13.1 | % |  | 12.1 | % |  |  |  |  |
| General and administrative | 43,635 |  |  | 42,030 |  |  |  |  | 3.8 | % |  | 83,628 |  |  | 84,498 |  |  |  |  | (1.0) | % |
| %** | 5.2 | % |  | 4.7 | % |  |  |  |  |  | 5.3 | % |  | 4.9 | % |  |  |  |  |
| Amortization of intangible assets | 6,019 |  |  | 5,839 |  |  |  |  | 3.1 | % |  | 11,929 |  |  | 11,692 |  |  |  |  | 2.0 | % |
| %** | 0.7 | % |  | 0.7 | % |  |  |  |  |  | 0.7 | % |  | 0.7 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 8,209 |  |  | 3,811 |  |  |  |  | 115.4 | % |  | 14,076 |  |  | 8,283 |  |  |  |  | 69.9 | % |
| %** | 1.0 | % |  | 0.4 | % |  |  |  |  |  | 0.9 | % |  | 0.4 | % |  |  |  |  |
| Acquisition and integration costs | 294 |  |  | 1,414 |  |  |  |  | (79.2) | % |  | 601 |  |  | 3,233 |  |  |  |  | (81.4) | % |
| %** | — | % |  | 0.2 | % |  |  |  |  |  | — | % |  | 0.2 | % |  |  |  |  |
| Total operating expenses | $ | 278,790 |  |  | $ | 285,838 |  |  |  |  | (2.5) | % |  | $ | 560,886 |  |  | $ | 578,416 |  |  |  |  | (3.0) | % |
| %** | 33.4 | % |  | 32.0 | % |  |  |  |  |  | 35.3 | % |  | 33.5 | % |  |  |  |  |

[0000936395-21-000034:mdna:89]
[same as prior period, unchanged from 0000936395-21-000010:mdna:61]

[0000936395-21-000034:mdna:90]
*    Denotes % change from 2020 to 2021

[0000936395-21-000034:mdna:91]
**     Denotes % of Total Revenue

[0000936395-21-000034:mdna:92]
Quarter ended May 1, 2021 as compared to the quarter ended May 2, 2020

[0000936395-21-000034:mdna:93]
•Research and development expense was adversely affected by $0.8 million as a result of foreign exchange rates, primarily due to fluctuations in the U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, net of hedging, research and development expense decreased by $21.3 million. This decrease primarily

[0000936395-21-000034:mdna:94]
reflects $28.9 million received for CEWS, partially offset by increases in compensation costs primarily driven by increases in headcount.

[0000936395-21-000034:mdna:95]
•Selling and marketing expense was adversely affected by $2.2 million as a result of foreign exchange rates, primarily due to fluctuations in the U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expenses increased by $9.2 million. This increase reflects increases in compensation costs primarily driven by increases in headcount, and professional services, partially offset by decreases in travel and entertainment costs due to restrictions on travel as a result of COVID-19 and $2.6 million received for CEWS.

[0000936395-21-000034:mdna:96]
•General and administrative expense was adversely affected by $0.5 million as a result of foreign exchange rates, primarily due to fluctuations in the U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, general and administrative expense increased by $1.6 million primarily as a result of legal fees, partially offset by $2.2 million received for CEWS and reduced bad debt expense.

[0000936395-21-000034:mdna:97]
[same as prior period, unchanged from 0000936395-21-000010:mdna:67]

[0000936395-21-000034:mdna:98]
•Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin and constrain operating expense, and redesign certain business processes.

[0000936395-21-000034:mdna:99]
•Acquisition and integration costs primarily reflect reduced acquisition compensation associated with a three-year earn-out arrangement related to the acquisition of DonRiver Holdings, LLC (“Don River”) in fiscal 2018.

[0000936395-21-000034:mdna:100]
Six months ended May 1, 2021 as compared to the six months ended May 2, 2020

[0000936395-21-000034:mdna:101]
•Research and development expense was adversely affected by $0.5 million as a result of foreign exchange rates, net of hedging, primarily due to fluctuations in the U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, net of hedging, research and development expenses decreased by $19.4 million. This decrease primarily reflects $28.9 million received for CEWS, partially offset by increases in compensation costs primarily driven by increases in headcount.

[0000936395-21-000034:mdna:102]
•Selling and marketing expense was adversely affected by $3.6 million as a result of foreign exchange rates, primarily due to fluctuations in the U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expense decreased by $0.6 million. This decrease primarily reflects decreases in travel and entertainment costs due to restrictions on travel as a result of COVID-19 and $2.6 million received for CEWS, partially offset by increases in compensation costs primarily driven by increases in headcount.

[0000936395-21-000034:mdna:103]
•General and administrative expense was adversely affected by $0.7 million as a result of foreign exchange rates, primarily due to a weaker U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, general and administrative expenses decreased by $0.9 million. This decrease primarily reflects reduced bad debt expense, decreases in travel and entertainment costs due to restrictions on travel as a result of COVID-19 and $2.2 million received for CEWS, partially offset by increased legal fees.

[0000936395-21-000034:mdna:104]
•Amortization of intangible assets remained relatively unchanged.

[0000936395-21-000034:mdna:105]
[same as prior period, unchanged from 0000936395-21-000010:mdna:68]

[0000936395-21-000034:mdna:106]
•Acquisition and integration costs primarily reflect reduced acquisition compensation associated with a three-year earn-out arrangement related to the acquisition of DonRiver in fiscal 2018 and other fees related to the acquisition of Centina Systems, Inc. in the first quarter of fiscal 2020.

[0000936395-21-000034:mdna:107]
[same as prior period, unchanged from 0000936395-21-000010:mdna:70]

[0000936395-21-000034:mdna:108]
[same as prior period, unchanged from 0000936395-21-000010:mdna:71]

[0000936395-21-000034:mdna:109]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |
| Interest and other income (loss), net | $ | (1,274) |  |  | $ | (2,665) |  |  |  |  | (52.2) | % |  | $ | (2,395) |  |  | $ | 981 |  |  |  |  | (344.1) | % |
| %** | (0.2) | % |  | (0.3) | % |  |  |  |  |  | (0.2) | % |  | 0.1 | % |  |  |  |  |
| Interest expense | $ | 7,785 |  |  | $ | 7,860 |  |  |  |  | (1.0) | % |  | $ | 15,145 |  |  | $ | 16,675 |  |  |  |  | (9.2) | % |
| %** | 0.9 | % |  | 0.9 | % |  |  |  |  |  | 1.0 | % |  | 1.0 | % |  |  |  |  |
| Loss on extinguishment and modification of debt | $ | — |  |  | $ | — |  |  |  |  | — | % |  | $ | — |  |  | $ | 646 |  |  |  |  | (100.0) | % |
| %** | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Provision for income taxes | $ | 21,453 |  |  | $ | 25,308 |  |  |  |  | (15.2) | % |  | $ | 33,419 |  |  | $ | 35,122 |  |  |  |  | (4.8) | % |
| %** | 2.6 | % |  | 2.8 | % |  |  |  |  |  | 2.1 | % |  | 2.0 | % |  |  |  |  |

[0000936395-21-000034:mdna:110]
[same as prior period, unchanged from 0000936395-21-000010:mdna:73]

[0000936395-21-000034:mdna:111]
*    Denotes % change from 2020 to 2021

[0000936395-21-000034:mdna:112]
**     Denotes % of Total Revenue

[0000936395-21-000034:mdna:113]
Quarter ended May 1, 2021 as compared to the quarter ended May 2, 2020

[0000936395-21-000034:mdna:114]
•Interest and other income (loss), net increased by $1.4 million, primarily reflecting the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-21-000034:mdna:115]
•Interest expense remained relatively unchanged.

[0000936395-21-000034:mdna:116]
•Provision for income taxes decreased by $3.9 million, primarily due to an increased deduction for foreign-derived intangible income for the second quarter of fiscal 2021. The effective tax rate for the second quarter of 2021 was lower as compared to the second quarter of fiscal 2020, primarily due to an increased deduction for foreign-derived intangible income and a decrease in the foreign effective tax rate.

[0000936395-21-000034:mdna:117]
Six months ended May 1, 2021 as compared to the six months ended May 2, 2020

[0000936395-21-000034:mdna:118]
•Interest and other income, net decreased by $3.4 million, primarily reflecting lower interest income due to reduced interest rates on our investments and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-21-000034:mdna:119]
•Interest expense decreased by $1.5 million, primarily due to a reduction of LIBOR rates impacting our 2025 Term Loan.

[0000936395-21-000034:mdna:120]
[same as prior period, unchanged from 0000936395-21-000010:mdna:78]

[0000936395-21-000034:mdna:121]
•Provision for income taxes decreased by $1.7 million, primarily due to an increased deduction for foreign-derived intangible income for the first six months of fiscal 2021. The effective tax rate for the first six months of fiscal 2021 was lower as compared to the first six months of fiscal 2020, primarily due to an increased deduction for foreign-derived intangible income and a decrease in the foreign effective tax rate.

[0000936395-21-000034:mdna:122]
[same as prior period, unchanged from 0000936395-21-000010:mdna:80]

[0000936395-21-000034:mdna:123]
[same as prior period, unchanged from 0000936395-21-000010:mdna:81]

[0000936395-21-000034:mdna:124]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |  | May 1, 2021 |  | May 2, 2020 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 211,412 |  |  | $ | 210,987 |  |  |  |  | 0.2 | % |  | $ | 367,843 |  |  | $ | 379,256 |  |  |  |  | (3.0) | % |
| Platform Software and Services | $ | 36,506 |  |  | $ | 21,668 |  |  |  |  | 68.5 | % |  | $ | 64,166 |  |  | $ | 50,619 |  |  |  |  | 26.8 | % |
| Blue Planet Automation Software and Services | $ | 5,688 |  |  | $ | (4,399) |  |  |  |  | 229.3 | % |  | $ | 3,254 |  |  | $ | (7,512) |  |  |  |  | 143.3 | % |
| Global Services | $ | 48,567 |  |  | $ | 53,540 |  |  |  |  | (9.3) | % |  | $ | 92,060 |  |  | $ | 99,068 |  |  |  |  | (7.1) | % |

[0000936395-21-000034:mdna:125]
[same as prior period, unchanged from 0000936395-21-000010:mdna:83]

[0000936395-21-000034:mdna:126]
*    Denotes % change from 2020 to 2021

[0000936395-21-000034:mdna:127]
Segment profit (loss) includes CEWS benefits of $35.7 million in the second quarter and first six months of fiscal 2021, net of certain fees. For further discussion of CEWS, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000034:mdna:128]
Quarter ended May 1, 2021 as compared to the quarter ended May 2, 2020

[0000936395-21-000034:mdna:129]
•Networking Platforms segment profit increased by $0.4 million, primarily due to CEWS benefit of $29.7 million and improved gross margin, offset by lower sales volume as described above and higher research and development costs.

[0000936395-21-000034:mdna:130]
•Platform Software and Services segment profit increased by $14.8 million, primarily due to higher sales volume, services margin and a CEWS benefit of $2.5 million.

[0000936395-21-000034:mdna:131]
•Blue Planet Automation Software and Services segment profit increased by $10.1 million, primarily due to higher sales volume, higher gross margin on product sales and a CEWS benefit of $1.2 million, partially offset by lower gross margin on software-related services.

[0000936395-21-000034:mdna:132]
•Global Services segment profit decreased by $5.0 million, primarily due to reduced gross margin, as described above, partially offset by a CEWS benefit of $2.3 million.

[0000936395-21-000034:mdna:133]
Six months ended May 1, 2021 as compared to the six months ended May 2, 2020

[0000936395-21-000034:mdna:134]
•Networking Platforms segment profit decreased by $11.4 million, primarily due to lower sales volume as described above and higher research and development costs, partially offset by a CEWS benefit of $29.7 million and improved gross margin.

[0000936395-21-000034:mdna:135]
•Platform Software and Services segment profit increased by $13.5 million, primarily due to higher sales volume, a CEWS benefit of $2.5 million and improved gross margin as described above.

[0000936395-21-000034:mdna:136]
•Blue Planet Automation Software and Services segment profit increased by $10.8 million, primarily due to higher sales volume, higher gross margin on product sales and a CEWS benefit of $1.2 million, partially offset by lower gross margin on software-related services.

[0000936395-21-000034:mdna:137]
•Global Services segment profit decreased by $7.0 million, primarily due to reduced gross margin as described above, partially offset by higher sales volume and a CEWS benefit of $2.3 million.

[0000936395-21-000034:mdna:138]
[same as prior period, unchanged from 0000936395-21-000010:mdna:89]

[0000936395-21-000034:mdna:139]
Overview. For the six months ended May 1, 2021, we generated $217.7 million of cash in operating activities, which included $36.5 million of cash from a CEWS benefit. Our net income (adjusted for non-cash charges) of $279.4 million exceeded our working capital requirements of $61.7 million. For additional details, see “Cash Provided By Operating Activities” below. For further information relating to our receipt of amounts under the CEWS program, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000034:mdna:140]
Cash, cash equivalents and investments increased by $125.0 million during the first six months of fiscal 2021. The cash from operations above was partially offset by the following items: (i) cash used to fund our investing activities for capital expenditures totaling $51.7 million; (ii) cash used for stock repurchases under our stock repurchase program of $38.5 million; and (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $27.9 million.

[0000936395-21-000034:mdna:141]
Proceeds from the issuance of equity under our employee stock purchase plan provided $13.5 million in cash during the six months ended May 1, 2021.

[0000936395-21-000034:mdna:142]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities for the respective periods (in thousands):

[0000936395-21-000034:mdna:143]
|  | May 1,2021 |  | October 31,2020 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,202,974 |  |  | $ | 1,088,624 |  |  | $ | 114,350 |  |
| Short-term investments in marketable debt securities | 151,816 |  |  | 150,667 |  |  | 1,149 |  |
| Long-term investments in marketable debt securities | 91,715 |  |  | 82,226 |  |  | 9,489 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,446,505 |  |  | $ | 1,321,517 |  |  | $ | 124,988 |  |

[0000936395-21-000034:mdna:144]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of May 1, 2021 totaled $1.4 billion, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of May 1, 2021, letters of credit totaling $84.0 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of May 1, 2021.

[0000936395-21-000034:mdna:145]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $120.4 million as of May 1, 2021. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical foreign earnings, the estimated amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $25.0 million.

[0000936395-21-000034:mdna:146]
Stock Repurchase Authorization. On December 13, 2018, we announced that the Board of Directors authorized a program to repurchase up to $500.0 million of its common stock. After temporarily suspending repurchases of our common stock during fiscal 2020, we reinstituted our stock repurchase program in the first quarter of 2021 and are currently targeting repurchases in the range of $150 million of our common stock during fiscal 2021. We repurchased $39.4 million under this program during the first six months of fiscal 2021, and had $236.0 million remaining under the current authorization as of May 1, 2021. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be reinstated, modified, suspended, or discontinued at any time.

[0000936395-21-000034:mdna:147]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to disruptions and volatility in capital markets and credit markets. The duration and severity of any further economic or market impact of the COVID-19 pandemic remains uncertain and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future.

[0000936395-21-000034:mdna:148]
Cash Provided By Operating Activities

[0000936395-21-000034:mdna:149]
The following sections set forth the components of our $217.7 million of cash provided by operating activities during the first six months of fiscal 2021:

[0000936395-21-000034:mdna:150]
[same as prior period, unchanged from 0000936395-21-000010:mdna:100]

[0000936395-21-000034:mdna:151]
[same as prior period, unchanged from 0000936395-21-000010:mdna:101]

[0000936395-21-000034:mdna:152]
|  | Six Months Ended |
|  | May 1, 2021 |
| Net income | $ | 158,465 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 47,295 |  |
| Share-based compensation costs | 40,499 |  |
| Amortization of intangible assets | 18,517 |  |
| Deferred taxes | (9,606) |  |
| Provision for inventory excess and obsolescence | 10,402 |  |
| Provision for warranty | 7,937 |  |
| Other | 5,928 |  |
| Net income (adjusted for non-cash charges) | $ | 279,437 |  |

[0000936395-21-000034:mdna:153]
[same as prior period, unchanged from 0000936395-21-000010:mdna:103]

[0000936395-21-000034:mdna:154]
We used $61.7 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-21-000034:mdna:155]
|  | Six Months Ended |
|  | May 1, 2021 |
| Cash used in accounts receivable | $ | (180) |  |
| Cash used in inventories | (66,934) |  |
| Cash used in prepaid expenses and other | (8,565) |  |
| Cash used in accounts payable, accruals and other obligations | (30,108) |  |
| Cash provided by deferred revenue | 45,482 |  |
| Cash used in operating lease assets and liabilities, net | (1,473) |  |
| Total cash used for working capital | $ | (61,778) |  |

[0000936395-21-000034:mdna:156]
[same as prior period, unchanged from 0000936395-21-000010:mdna:106]

[0000936395-21-000034:mdna:157]
•Cash used in accounts receivable was not material during the first six months of fiscal 2021;

[0000936395-21-000034:mdna:158]
•The $66.9 million of cash used in inventories during the first six months of fiscal 2021 primarily reflects increases in finished goods to meet customer delivery schedules and related to some of the actions that we have taken since early fiscal 2020 to mitigate the risk of adverse supply chain impact on our business and operations due to COVID-19 related disruptions;

[0000936395-21-000034:mdna:159]
•The $8.6 million of cash used in prepaid expense and other during the first six months of fiscal 2021 primarily reflects increases in foreign currency forward contracts and CEWS receivable of $3.9 million, partially offset by a reduction in contract assets and other receivables;

[0000936395-21-000034:mdna:160]
•The $30.1 million of cash used in accounts payable, accruals and other obligations during the first six months of fiscal 2021 primarily reflects the payment to employees under our annual cash incentive compensation plan in the first quarter, as well as inventory purchases;

[0000936395-21-000034:mdna:161]
•The $45.5 million of cash provided by deferred revenue during the first six months of fiscal 2021 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-21-000034:mdna:162]
•The $1.5 million of cash used in operating lease assets and liabilities, net, during the first six months of fiscal 2021 represents cash paid for operating lease payments in excess of operating lease costs. For more details, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000034:mdna:163]
Our days sales outstanding (“DSOs”) for the first six months of fiscal 2021 were 90 days, and our inventory turns for the first six months of fiscal 2021 were 3.3. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other.

[0000936395-21-000034:mdna:164]
[same as prior period, unchanged from 0000936395-21-000010:mdna:114]

[0000936395-21-000034:mdna:165]
[same as prior period, unchanged from 0000936395-21-000010:mdna:115]

[0000936395-21-000034:mdna:166]
|  | Six Months Ended |
|  | May 1, 2021 |
| Term Loan due September 28, 2025(1) | $ | 6,547 |  |
| Interest rate swaps(2) | 4,995 |  |
| ABL Credit Facility(3) | 979 |  |
| Finance leases | 2,428 |  |
| Cash paid during period | $ | 14,949 |  |

[0000936395-21-000034:mdna:167]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of the second quarter of fiscal 2021, the interest rate on the 2025 Term Loan was 1.86%.

[0000936395-21-000034:mdna:168]
[same as prior period, unchanged from 0000936395-21-000010:mdna:118]

[0000936395-21-000034:mdna:169]
(3) During the first six months of fiscal 2021, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.0 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-21-000034:mdna:170]
[same as prior period, unchanged from 0000936395-21-000010:mdna:120]

[0000936395-21-000034:mdna:171]
[same as prior period, unchanged from 0000936395-21-000010:mdna:121]

[0000936395-21-000034:mdna:172]
[same as prior period, unchanged from 0000936395-21-000010:mdna:122]

[0000936395-21-000034:mdna:173]
[same as prior period, unchanged from 0000936395-21-000010:mdna:123]

[0000936395-21-000034:mdna:174]
[same as prior period, unchanged from 0000936395-21-000010:mdna:124]

[0000936395-21-000034:mdna:175]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition, because the duration, severity, and impact of the COVID-19 pandemic remain uncertain, certain of our estimates could require further judgment or modification, and therefore carry a higher degree of variability and volatility. As events continue to evolve, our estimates may change materially in future periods.

[0000936395-21-000034:mdna:176]
[same as prior period, unchanged from 0000936395-21-000010:mdna:126]

[0000936395-21-000034:mdna:177]
[same as prior period, unchanged from 0000936395-21-000010:mdna:127]

[0000936395-21-000034:mdna:178]
See Note 2 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for information regarding the change in our allowance for credit losses for accounts receivable and contract assets accounting policies as a result of our adoption of ASU 2016-13, Financial Instruments - Credit Losses.

[0000936395-21-000034:mdna:179]
[same as prior period, unchanged from 0000936395-21-000010:mdna:129]

[0000936395-21-000034:mdna:180]
[same as prior period, unchanged from 0000936395-21-000010:mdna:130]
