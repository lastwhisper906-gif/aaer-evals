# CIEN 8-K — 0000936395-21-000027 filed 2021-06-03

## item codes, every 8-K on or before 2021-06-09

- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2021-06-09

- none on or before 2021-06-09

## item 2.02 — earnings release, exhibit 99.1

[0000936395-21-000027:8k_2_02:1]
EX-99.1
2
ex991-2021q2earningspressr.htm
EX-99.1

[0000936395-21-000027:8k_2_02:2]
Document

[0000936395-21-000027:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-21-000027:8k_2_02:4]
Ciena Reports Fiscal Second Quarter 2021 Financial Results

[0000936395-21-000027:8k_2_02:5]
HANOVER, Md. - June 3, 2021 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal second quarter ended May 1, 2021.

[0000936395-21-000027:8k_2_02:6]
•Q2 Revenue: $833.9 million

[0000936395-21-000027:8k_2_02:7]
•Q2 Net Income per Share: $0.66 GAAP; $0.62 adjusted (non-GAAP)

[0000936395-21-000027:8k_2_02:8]
•Share Repurchases: Repurchased approximately 0.5 million shares of common stock for an aggregate price of $26.2 million during the quarter

[0000936395-21-000027:8k_2_02:9]
“We delivered strong fiscal second quarter results as we continued to see encouraging signs in the market environment, including improvements in customer spending,” said Gary Smith, president and CEO of Ciena. “These dynamics, combined with our business and financial performance in the first half of the year, give us strong visibility and confidence in our ability to achieve our financial targets as we move through the year.”

[0000936395-21-000027:8k_2_02:10]
For the fiscal second quarter 2021, Ciena reported revenue of $833.9 million as compared to $894.1 million for the fiscal second quarter 2020.

[0000936395-21-000027:8k_2_02:11]
Ciena's GAAP net income for the fiscal second quarter 2021 was $103.1 million, or $0.66 per diluted common share, which compares to a GAAP net income of $91.7 million, or $0.59 per diluted common share, for the fiscal second quarter 2020. Ciena's GAAP net income for the second quarter of 2021 benefited from recording $40.4 million in pre-tax amounts from the Canadian Emergency Wage Subsidy program. See APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures for more information and a reconciliation of our adjusted (non-GAAP) net income which excludes the effect of these amounts.

[0000936395-21-000027:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal second quarter 2021 was $97.6 million, or $0.62 per diluted common share, which compares to an adjusted (non-GAAP) net income of $117.4 million, or $0.76 per diluted common share, for the fiscal second quarter 2020.

[0000936395-21-000027:8k_2_02:13]
Fiscal Second Quarter 2021 Performance Summary

[0000936395-21-000027:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-21-000027:8k_2_02:15]
|  |  | GAAP Results |
|  |  | Q2 |  | Q2 |  |  |
|  |  | FY 2021 |  | FY 2020 |  | Y-T-Y* |
| Revenue |  | $ | 833.9 |  |  | $ | 894.1 |  |  | (6.7) | % |
| Gross margin |  | 49.5 | % |  | 46.2 | % |  | 3.3 | % |
| Operating expense |  | $ | 278.8 |  |  | $ | 285.8 |  |  | (2.5) | % |
| Operating margin |  | 16.0 | % |  | 14.3 | % |  | 1.7 | % |

[0000936395-21-000027:8k_2_02:16]
|  |  | Non-GAAP Results |
|  |  | Q2 |  | Q2 |  |  |
|  |  | FY 2021 |  | FY 2020 |  | Y-T-Y* |
| Revenue |  | $ | 833.9 |  |  | $ | 894.1 |  |  | (6.7) | % |
| Adj. gross margin |  | 49.2 | % |  | 46.9 | % |  | 2.3 | % |
| Adj. operating expense |  | $ | 278.7 |  |  | $ | 258.7 |  |  | 7.7 | % |
| Adj. operating margin |  | 15.8 | % |  | 17.9 | % |  | (2.1) | % |
| Adj. EBITDA |  | $ | 156.2 |  |  | $ | 183.0 |  |  | (14.6) | % |

[0000936395-21-000027:8k_2_02:17]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-21-000027:8k_2_02:18]
|  |  | Revenue by Segment |
|  |  | Q2 FY 2021 |  | Q2 FY 2020 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 573.7 |  |  | 68.8 |  |  | $ | 654.3 |  |  | 73.2 |  |
| Routing and Switching (1) |  | 63.6 |  |  | 7.6 |  |  | 64.2 |  |  | 7.2 |  |
| Total Networking Platforms |  | 637.3 |  |  | 76.4 |  |  | 718.5 |  |  | 80.4 |  |
| Platform Software and Services |  | 56.7 |  |  | 6.8 |  |  | 45.0 |  |  | 5.0 |  |
| Blue Planet Automation Software and Services |  | 23.9 |  |  | 2.9 |  |  | 15.0 |  |  | 1.7 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 70.4 |  |  | 8.4 |  |  | 71.5 |  |  | 8.0 |  |
| Installation and Deployment |  | 38.0 |  |  | 4.6 |  |  | 34.2 |  |  | 3.8 |  |
| Consulting and Network Design |  | 7.6 |  |  | 0.9 |  |  | 9.9 |  |  | 1.1 |  |
| Total Global Services |  | 116.0 |  |  | 13.9 |  |  | 115.6 |  |  | 12.9 |  |
| Total |  | $ | 833.9 |  |  | 100.0 |  |  | $ | 894.1 |  |  | 100.0 |  |

[0000936395-21-000027:8k_2_02:19]
**  Denotes %  of total revenue

[0000936395-21-000027:8k_2_02:20]
(1)  Ciena renamed its former “Packet Networking” product line “Routing and Switching” effective as of the beginning of fiscal 2021. This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results or the composition of this product category.

[0000936395-21-000027:8k_2_02:21]
Additional Performance Metrics for Fiscal Second Quarter 2021

[0000936395-21-000027:8k_2_02:22]
2

[0000936395-21-000027:8k_2_02:23]
|  |  | Revenue by Geographic Region |
|  |  | Q2 FY 2021 |  | Q2 FY 2020 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 587.5 |  |  | 70.4 |  |  | $ | 650.4 |  |  | 72.7 |  |
| Europe, Middle East and Africa |  | 155.0 |  |  | 18.6 |  |  | 141.4 |  |  | 15.8 |  |
| Asia Pacific |  | 91.4 |  |  | 11.0 |  |  | 102.3 |  |  | 11.5 |  |
| Total |  | $ | 833.9 |  |  | 100.0 |  |  | $ | 894.1 |  |  | 100.0 |  |

[0000936395-21-000027:8k_2_02:24]
**  Denotes %  of total revenue

[0000936395-21-000027:8k_2_02:25]
•One 10%-plus customer represented a total of 15% of revenue

[0000936395-21-000027:8k_2_02:26]
•Cash and investments totaled $1.4 billion

[0000936395-21-000027:8k_2_02:27]
•Cash flow from operations totaled $225.0 million

[0000936395-21-000027:8k_2_02:28]
•Average days' sales outstanding (DSOs) were 86

[0000936395-21-000027:8k_2_02:29]
•Accounts receivable, net balance was $716.8 million

[0000936395-21-000027:8k_2_02:30]
•Unbilled contract asset, net balance was $81.4 million

[0000936395-21-000027:8k_2_02:31]
•Inventories totaled $401.2 million, including:

[0000936395-21-000027:8k_2_02:32]
◦Raw materials: $139.4 million

[0000936395-21-000027:8k_2_02:33]
◦Work in process: $10.8 million

[0000936395-21-000027:8k_2_02:34]
◦Finished goods: $234.2 million

[0000936395-21-000027:8k_2_02:35]
◦Deferred cost of sales: $57.4 million

[0000936395-21-000027:8k_2_02:36]
◦Reserve for excess and obsolescence: $(40.6) million

[0000936395-21-000027:8k_2_02:37]
•Product inventory turns were 3.4

[0000936395-21-000027:8k_2_02:38]
•Headcount totaled 7,077

[0000936395-21-000027:8k_2_02:39]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Second Quarter 2021 Results

[0000936395-21-000027:8k_2_02:40]
Today, Thursday, June 3, 2021, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website an accompanying investor presentation for its unaudited fiscal second quarter 2021 results.

[0000936395-21-000027:8k_2_02:41]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-21-000027:8k_2_02:42]
Notes to Investors

[0000936395-21-000027:8k_2_02:43]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: “We delivered strong fiscal second quarter results as we continued to see encouraging signs in the market environment, including improvements in customer spending,” and “These dynamics, combined with our business

[0000936395-21-000027:8k_2_02:44]
and financial performance in the first half of the year, give us strong visibility and confidence in our ability to achieve our financial targets as we move through the year.”

[0000936395-21-000027:8k_2_02:45]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; our ability to execute successfully our business and growth strategies; the duration and severity of the COVID-19 pandemic and its impact on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our business operations, liquidity, and financial results; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions; changes in foreign currency exchange rates affecting revenue and operating expense; factors beyond our control such as natural disasters, acts of war or terrorism, and public health emergencies; the impact of the Tax Cuts and Jobs Act; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise; and the other risk factors disclosed in its Annual Report on Form 10-K filed with the SEC on December 18, 2020 and included in its Quarterly Report on Form 10-Q for the second quarter of fiscal 2021 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-21-000027:8k_2_02:46]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-21-000027:8k_2_02:47]
About Ciena. Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our customers create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-21-000027:8k_2_02:48]
4

[0000936395-21-000027:8k_2_02:49]
CIENA CORPORATION

[0000936395-21-000027:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-21-000027:8k_2_02:51]
(in thousands, except per share data)

[0000936395-21-000027:8k_2_02:52]
(unaudited)

[0000936395-21-000027:8k_2_02:53]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 670,043 |  |  | $ | 739,892 |  |  | $ | 1,267,263 |  |  | $ | 1,427,107 |  |
| Services | 163,884 |  |  | 154,161 |  |  | 323,794 |  |  | 299,858 |  |
| Total revenue | 833,927 |  |  | 894,053 |  |  | 1,591,057 |  |  | 1,726,965 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 339,601 |  |  | 405,138 |  |  | 654,699 |  |  | 794,151 |  |
| Services | 81,907 |  |  | 75,589 |  |  | 166,048 |  |  | 148,953 |  |
| Total cost of goods sold | 421,508 |  |  | 480,727 |  |  | 820,747 |  |  | 943,104 |  |
| Gross profit | 412,419 |  |  | 413,326 |  |  | 770,310 |  |  | 783,861 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 110,246 |  |  | 131,530 |  |  | 242,987 |  |  | 262,430 |  |
| Selling and marketing | 110,387 |  |  | 101,214 |  |  | 207,665 |  |  | 208,280 |  |
| General and administrative | 43,635 |  |  | 42,030 |  |  | 83,628 |  |  | 84,498 |  |
| Amortization of intangible assets | 6,019 |  |  | 5,839 |  |  | 11,929 |  |  | 11,692 |  |
| Significant asset impairments and restructuring costs | 8,209 |  |  | 3,811 |  |  | 14,076 |  |  | 8,283 |  |
| Acquisition and integration costs | 294 |  |  | 1,414 |  |  | 601 |  |  | 3,233 |  |
| Total operating expenses | 278,790 |  |  | 285,838 |  |  | 560,886 |  |  | 578,416 |  |
| Income from operations | 133,629 |  |  | 127,488 |  |  | 209,424 |  |  | 205,445 |  |
| Interest and other income (loss), net | (1,274) |  |  | (2,665) |  |  | (2,395) |  |  | 981 |  |
| Interest expense | (7,785) |  |  | (7,860) |  |  | (15,145) |  |  | (16,675) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | — |  |  | (646) |  |
| Income before income taxes | 124,570 |  |  | 116,963 |  |  | 191,884 |  |  | 189,105 |  |
| Provision for income taxes | 21,453 |  |  | 25,308 |  |  | 33,419 |  |  | 35,122 |  |
| Net income | $ | 103,117 |  |  | $ | 91,655 |  |  | $ | 158,465 |  |  | $ | 153,983 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.66 |  |  | $ | 0.60 |  |  | $ | 1.02 |  |  | $ | 1.00 |  |
| Diluted net income per potential common share | $ | 0.66 |  |  | $ | 0.59 |  |  | $ | 1.01 |  |  | $ | 0.99 |  |
| Weighted average basic common shares outstanding | 155,331 |  |  | 153,858 |  |  | 155,257 |  |  | 154,099 |  |
| Weighted average dilutive potential common shares outstanding 1 | 156,876 |  |  | 155,141 |  |  | 156,734 |  |  | 155,443 |  |

[0000936395-21-000027:8k_2_02:54]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the second quarter of fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000027:8k_2_02:55]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the first six months of fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000027:8k_2_02:56]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the second quarter of fiscal 2020 includes 1.3 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000027:8k_2_02:57]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the first six months of fiscal 2020 includes 1.3 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000027:8k_2_02:58]
CIENA CORPORATION

[0000936395-21-000027:8k_2_02:59]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-21-000027:8k_2_02:60]
(in thousands, except share data)

[0000936395-21-000027:8k_2_02:61]
(unaudited)

[0000936395-21-000027:8k_2_02:62]
|  | May 1,2021 |  | October 31,2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,202,974 |  |  | $ | 1,088,624 |  |
| Short-term investments | 151,816 |  |  | 150,667 |  |
| Accounts receivable, net | 716,779 |  |  | 719,405 |  |
| Inventories | 401,233 |  |  | 344,379 |  |
| Prepaid expenses and other | 321,651 |  |  | 308,084 |  |
| Total current assets | 2,794,453 |  |  | 2,611,159 |  |
| Long-term investments | 91,715 |  |  | 82,226 |  |
| Equipment, building, furniture and fixtures, net | 298,329 |  |  | 272,377 |  |
| Operating lease right-of-use assets | 50,997 |  |  | 57,026 |  |
| Goodwill | 311,734 |  |  | 310,847 |  |
| Other intangible assets, net | 82,879 |  |  | 96,647 |  |
| Deferred tax asset, net | 653,922 |  |  | 647,805 |  |
| Other long-term assets | 103,984 |  |  | 102,830 |  |
| Total assets | $ | 4,388,013 |  |  | $ | 4,180,917 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 279,247 |  |  | $ | 291,904 |  |
| Accrued liabilities and other short-term obligations | 330,060 |  |  | 334,132 |  |
| Deferred revenue | 147,075 |  |  | 108,700 |  |
| Operating lease liabilities | 19,364 |  |  | 19,035 |  |
| Current portion of long-term debt | 6,930 |  |  | 6,930 |  |
| Total current liabilities | 782,676 |  |  | 760,701 |  |
| Long-term deferred revenue | 57,224 |  |  | 49,663 |  |
| Other long-term obligations | 127,700 |  |  | 123,185 |  |
| Long-term operating lease liabilities | 53,795 |  |  | 61,415 |  |
| Long-term debt, net | 673,355 |  |  | 676,356 |  |
| Total liabilities | $ | 1,694,750 |  |  | $ | 1,671,320 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 154,962,122and 154,563,005 shares issued and outstanding | 1,550 |  |  | 1,546 |  |
| Additional paid-in capital | 6,813,215 |  |  | 6,826,531 |  |
| Accumulated other comprehensive gain (loss) | 5,361 |  |  | (35,358) |  |
| Accumulated deficit | (4,126,863) |  |  | (4,283,122) |  |
| Total stockholders’ equity | 2,693,263 |  |  | 2,509,597 |  |
| Total liabilities and stockholders’ equity | $ | 4,388,013 |  |  | $ | 4,180,917 |  |

[0000936395-21-000027:8k_2_02:63]
6

[0000936395-21-000027:8k_2_02:64]
CIENA CORPORATION

[0000936395-21-000027:8k_2_02:65]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-21-000027:8k_2_02:66]
(in thousands) (unaudited)

[0000936395-21-000027:8k_2_02:67]
|  | Six Months Ended |
|  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 158,465 |  |  | $ | 153,983 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 47,295 |  |  | 48,381 |  |
| Share-based compensation costs | 40,499 |  |  | 33,579 |  |
| Amortization of intangible assets | 18,517 |  |  | 19,361 |  |
| Deferred taxes | (9,606) |  |  | 25,420 |  |
| Provision for inventory excess and obsolescence | 10,402 |  |  | 12,640 |  |
| Provision for warranty | 7,937 |  |  | 13,793 |  |
| Other | 5,928 |  |  | 16,190 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (180) |  |  | 15,865 |  |
| Inventories | (66,934) |  |  | 5,618 |  |
| Prepaid expenses and other | (8,565) |  |  | (54,839) |  |
| Operating lease right-of-use assets | 8,253 |  |  | 8,642 |  |
| Accounts payable, accruals and other obligations | (30,108) |  |  | (151,713) |  |
| Deferred revenue | 45,482 |  |  | (5,679) |  |
| Short and long-term operating lease liabilities | (9,726) |  |  | (10,311) |  |
| Net cash provided by operating activities | 217,659 |  |  | 130,930 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (51,651) |  |  | (45,458) |  |
| Purchase of available for sale securities | (102,429) |  |  | (40,894) |  |
| Proceeds from maturities of available for sale securities | 91,810 |  |  | 60,000 |  |
| Settlement of foreign currency forward contracts, net | 9,414 |  |  | (3,836) |  |
| Acquisition of business, net of cash acquired | — |  |  | (28,300) |  |
| Proceeds from sale of equity investment | 4,678 |  |  | — |  |
| Net cash used in investing activities | (48,178) |  |  | (58,488) |  |
| Cash flows used in financing activities: |  |  |  |
| Payment of long term debt | (3,465) |  |  | (1,733) |  |
| Payment of debt issuance costs | — |  |  | (382) |  |
| Payment of finance lease obligations | (1,463) |  |  | (1,381) |  |
| Shares repurchased for tax withholdings on vesting of restricted stock units | (27,893) |  |  | (18,200) |  |
| Repurchases of common stock - repurchase program | (38,498) |  |  | (74,535) |  |
| Proceeds from issuance of common stock | 13,480 |  |  | 12,290 |  |
| Net cash used in financing activities | (57,839) |  |  | (83,941) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 2,696 |  |  | (4,876) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 114,338 |  |  | (16,375) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,088,708 |  |  | 904,161 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,203,046 |  |  | $ | 887,786 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 14,949 |  |  | $ | 17,590 |  |
| Cash paid during the period for income taxes, net | $ | 27,666 |  |  | $ | 22,011 |  |
| Operating lease payments | $ | 10,785 |  |  | $ | 11,409 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 4,966 |  |  | $ | 4,480 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 900 |  |  | $ | — |  |
| Operating lease right-of-use assets subject to lease liability | $ | 1,770 |  |  | $ | 4,887 |  |

[0000936395-21-000027:8k_2_02:68]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |
|  |  | May 1, |  | May 2, |
|  |  | 2021 |  | 2020 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 412,419 |  |  | $ | 413,326 |  |
| Share-based compensation-products |  | 498 |  |  | 827 |  |
| Share-based compensation-services |  | 1,421 |  |  | 1,036 |  |
| Canadian Emergency Wage Subsidy-products |  | (4,189) |  |  | — |  |
| Canadian Emergency Wage Subsidy-services |  | (2,620) |  |  | — |  |
| Amortization of intangible assets |  | 2,856 |  |  | 3,835 |  |
| Total adjustments related to gross profit |  | (2,034) |  |  | 5,698 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 410,385 |  |  | $ | 419,024 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 49.2 | % |  | 46.9 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 278,790 |  |  | $ | 285,838 |  |
| Share-based compensation-research and development |  | 5,844 |  |  | 4,822 |  |
| Share-based compensation-sales and marketing |  | 6,610 |  |  | 5,264 |  |
| Share-based compensation-general and administrative |  | 6,743 |  |  | 5,975 |  |
| Canadian Emergency Wage Subsidy-research and development |  | (28,923) |  |  | — |  |
| Canadian Emergency Wage Subsidy-sales and marketing |  | (2,551) |  |  | — |  |
| Canadian Emergency Wage Subsidy-general and administrative |  | (2,161) |  |  | — |  |
| Amortization of intangible assets |  | 6,019 |  |  | 5,839 |  |
| Significant asset impairments and restructuring costs |  | 8,209 |  |  | 3,811 |  |
| Acquisition and integration costs |  | 294 |  |  | 1,414 |  |
| Total adjustments related to operating expense |  | 84 |  |  | 27,125 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 278,706 |  |  | $ | 258,713 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 133,629 |  |  | $ | 127,488 |  |
| Total adjustments related to gross profit |  | (2,034) |  |  | 5,698 |  |
| Total adjustments related to operating expense |  | 84 |  |  | 27,125 |  |
| Total adjustments related to income from operations |  | (1,950) |  |  | 32,823 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 131,679 |  |  | $ | 160,311 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 15.8 | % |  | 17.9 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income |  | $ | 103,117 |  |  | $ | 91,655 |  |
| Exclude GAAP provision for income taxes |  | 21,453 |  |  | 25,308 |  |
| Income before income taxes |  | 124,570 |  |  | 116,963 |  |
| Total adjustments related to income from operations |  | (1,950) |  |  | 32,823 |  |
| Unrealized loss on equity investment |  | 165 |  |  | — |  |
| Adjusted income before income taxes |  | 122,785 |  |  | 149,786 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 25,171 |  |  | 32,354 |  |
| Adjusted (non-GAAP) net income |  | $ | 97,614 |  |  | $ | 117,432 |  |
| Weighted average basic common shares outstanding |  | 155,331 |  | 153,858 |
| Weighted average dilutive potential common shares outstanding 1 |  | 156,876 |  | 155,141 |

[0000936395-21-000027:8k_2_02:69]
8

[0000936395-21-000027:8k_2_02:70]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |
|  |  | May 1, |  | May 2, |
|  |  | 2021 |  | 2020 |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.66 |  |  | $ | 0.59 |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.62 |  |  | $ | 0.76 |  |

[0000936395-21-000027:8k_2_02:71]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the second quarter of fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000027:8k_2_02:72]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the second quarter of fiscal 2020 includes 1.3 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000027:8k_2_02:73]
9

[0000936395-21-000027:8k_2_02:74]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |
|  |  | May 1, |  | May 2, |
|  |  | 2021 |  | 2020 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |
| Net income (GAAP) |  | $ | 103,117 |  |  | $ | 91,655 |  |
| Add: Interest expense |  | 7,785 |  |  | 7,860 |  |
| Add: Interest and other loss, net |  | 1,274 |  |  | 2,665 |  |
| Add: Provision for income taxes |  | 21,453 |  |  | 25,308 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 24,107 |  |  | 22,599 |  |
| Add: Amortization of intangible assets |  | 8,875 |  |  | 9,674 |  |
| EBITDA |  | $ | 166,611 |  |  | $ | 159,761 |  |
| Less: Canadian Emergency Wage Subsidy |  | 40,444 |  |  | — |  |
| Add: Share-based compensation cost |  | 21,535 |  |  | 17,977 |  |
| Add: Significant asset impairments and restructuring costs |  | 8,209 |  |  | 3,811 |  |
| Add: Acquisition and integration costs |  | 294 |  |  | 1,414 |  |
| Adjusted EBITDA |  | $ | 156,205 |  |  | $ | 182,963 |  |

[0000936395-21-000027:8k_2_02:75]
* * *

[0000936395-21-000027:8k_2_02:76]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-21-000027:8k_2_02:77]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-21-000027:8k_2_02:78]
•Canadian Emergency Wage Subsidy - a program introduced by the Government of Canada to offset a portion of employee wages for a limited period in response to COVID-19 outbreak.

[0000936395-21-000027:8k_2_02:79]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-21-000027:8k_2_02:80]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities and the redesign of business processes.

[0000936395-21-000027:8k_2_02:81]
•Acquisition and integration costs - includes costs of acquisition compensation associated with a three-year earn-out arrangement related to the DonRiver acquisition in fiscal 2018. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities.

[0000936395-21-000027:8k_2_02:82]
•Unrealized loss on equity investment - reflects a change in the carrying value of a certain cost method equity investment.

[0000936395-21-000027:8k_2_02:83]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 20.5% for the second fiscal quarter of 2021 and 21.6% for the second fiscal quarter of 2020. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
