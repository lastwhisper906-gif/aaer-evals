# CIEN notes — 0000936395-21-000034


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-21-000034:notes:1]
[same as prior period, unchanged from 0000936395-21-000010:notes:1]

[0000936395-21-000034:notes:2]
[same as prior period, unchanged from 0000936395-21-000010:notes:2]

[0000936395-21-000034:notes:3]
[same as prior period, unchanged from 0000936395-21-000010:notes:3]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-21-000034:notes:4]
[same as prior period, unchanged from 0000936395-21-000010:notes:4]

[0000936395-21-000034:notes:5]
[same as prior period, unchanged from 0000936395-21-000010:notes:5]

[0000936395-21-000034:notes:6]
In June 2016, the Financial Accounting Standards Board (”FASB”) issued Accounting Standards Update No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. Ciena adopted ASU 2016-13 on a modified retrospective basis in the first quarter of fiscal year 2021 through a cumulative-effect adjustment at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts the value of Ciena’s accounts receivable, net and contract assets, net. Adoption of ASU 2016-13 did not have a material effect on Ciena’s financial position or results of operations.

[0000936395-21-000034:notes:7]
[same as prior period, unchanged from 0000936395-21-000010:notes:7]

[0000936395-21-000034:notes:8]
[same as prior period, unchanged from 0000936395-21-000010:notes:8]

[0000936395-21-000034:notes:9]
[same as prior period, unchanged from 0000936395-21-000010:notes:9]

[0000936395-21-000034:notes:10]
[same as prior period, unchanged from 0000936395-21-000010:notes:10]

[0000936395-21-000034:notes:11]
[same as prior period, unchanged from 0000936395-21-000010:notes:11]

[0000936395-21-000034:notes:12]
[same as prior period, unchanged from 0000936395-21-000010:notes:12]

[0000936395-21-000034:notes:13]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022, and early adoption is permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-21-000034:notes:14]
[same as prior period, unchanged from 0000936395-21-000010:notes:14]

[0000936395-21-000034:notes:15]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line. Effective as of the beginning of fiscal 2021, Ciena renamed its “Packet Networking” product line to “Routing and Switching.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. References to prior reported “Packet Networking” product line have been changed herein to“Routing and Switching.”

[0000936395-21-000034:notes:16]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

[0000936395-21-000034:notes:17]
|  | Quarter Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |

[0000936395-21-000034:notes:18]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Routing and Switching | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |

[0000936395-21-000034:notes:19]
|  | Six Months Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

[0000936395-21-000034:notes:20]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Routing Switching | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,519 |  |  | $ | 30,092 |  |  | $ | 8,481 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

[0000936395-21-000034:notes:21]
Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-21-000034:notes:22]
[same as prior period, unchanged from 0000936395-21-000010:notes:20]

[0000936395-21-000034:notes:23]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 587,475 |  |  | $ | 650,381 |  |  | $ | 1,084,086 |  |  | $ | 1,224,385 |  |
| EMEA |  | 155,054 |  |  | 141,431 |  |  | 310,472 |  |  | 271,396 |  |
| APAC |  | 91,398 |  |  | 102,241 |  |  | 196,499 |  |  | 231,184 |  |
| Total revenue by geographic distribution |  | $ | 833,927 |  |  | $ | 894,053 |  |  | $ | 1,591,057 |  |  | $ | 1,726,965 |  |

[0000936395-21-000034:notes:24]
Ciena’s revenue includes $518.6 million and $598.4 million of United States revenue for the second quarter of fiscal 2021 and 2020, respectively. For the six months ended May 1, 2021 and May 2, 2020, United States revenue was $1.0 billion and $1.1 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-21-000034:notes:25]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-21-000034:notes:26]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| AT&T | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 189,640 |  |
| Verizon | n/a |  | n/a |  | n/a |  | 203,630 |  |
| Total | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 393,270 |  |

[0000936395-21-000034:notes:27]
[same as prior period, unchanged from 0000936395-21-000010:notes:25]

[0000936395-21-000034:notes:28]
The customers identified above purchased products and services from each of Ciena’s operating segments.

[0000936395-21-000034:notes:29]
[same as prior period, unchanged from 0000936395-21-000010:notes:27]

[0000936395-21-000034:notes:30]
◦Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS) and the 5400 family of Packet-Optical Platforms. This product line also includes sales of the Z-Series Packet-Optical Platform.

[0000936395-21-000034:notes:31]
[same as prior period, unchanged from 0000936395-21-000010:notes:29]

[0000936395-21-000034:notes:32]
[same as prior period, unchanged from 0000936395-21-000010:notes:30]

[0000936395-21-000034:notes:33]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-21-000034:notes:34]
•Blue Planet® Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led operations support system (OSS) transformations by transforming legacy networks into “service ready” networks, accelerating the creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform

[0000936395-21-000034:notes:35]
includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-21-000034:notes:36]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-21-000034:notes:37]
[same as prior period, unchanged from 0000936395-21-000010:notes:35]

[0000936395-21-000034:notes:38]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over     time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-21-000034:notes:39]
[same as prior period, unchanged from 0000936395-21-000010:notes:37]

[0000936395-21-000034:notes:40]
[same as prior period, unchanged from 0000936395-21-000010:notes:38]

[0000936395-21-000034:notes:41]
|  |  | Balance at May 1, 2021 |  | Balance at October 31, 2020 |
| Accounts receivable, net |  | $ | 716,779 |  |  | $ | 719,405 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 81,437 |  |  | $ | 85,843 |  |
| Deferred revenue |  | $ | 204,299 |  |  | $ | 158,363 |  |

[0000936395-21-000034:notes:42]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. See Note 11 below.

[0000936395-21-000034:notes:43]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $78.0 million and $76.5 million of revenue during the first six months of fiscal 2021 and 2020, respectively, that was included in the deferred revenue balance as of October 31, 2020 and November 2, 2019, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 1, 2021 and May 2, 2020.

[0000936395-21-000034:notes:44]
[same as prior period, unchanged from 0000936395-21-000010:notes:42]

[0000936395-21-000034:notes:45]
Capitalized contract acquisition costs consist of deferred sales commissions, were $18.4 million and $15.3 million as of May 1, 2021 and October 31, 2020, respectively, and were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $10.7 million and $10.1 million during the first six months of fiscal 2021 and 2020, respectively, and was included in sales and marketing expense.

[0000936395-21-000034:notes:46]
Remaining Performance Obligations

[0000936395-21-000034:notes:47]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of May 1, 2021, the 
aggregate amount of RPO was $1.4 billion. As of May 1, 2021, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-21-000034:notes:48]
[same as prior period, unchanged from 0000936395-21-000010:notes:45]

[0000936395-21-000034:notes:49]
|  | May 1,2021 |  | October 31,2020 |
| Products | $ | 13,257 |  |  | $ | 17,534 |  |
| Services | 191,042 |  |  | 140,829 |  |
|  | 204,299 |  |  | 158,363 |  |
| Less current portion | (147,075) |  |  | (108,700) |  |
| Long-term deferred revenue | $ | 57,224 |  |  | $ | 49,663 |  |


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0000936395-21-000034:notes:50]
CANADIAN EMERGENCY WAGE SUBSIDY
In April 2020, the Canadian government introduced the Canada Emergency Wage Subsidy (“CEWS”) to help employers offset a portion of their employee wages for a limited period in response to the COVID-19 outbreak, retroactive to March 15, 2020. The CEWS program has been extended through June 2021, with a proposed extension through September 2021. The subsidy covers employers of all sizes and across all sectors.

[0000936395-21-000034:notes:51]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. During the second quarter and six months ended May 1, 2021, Ciena recorded a CAD$51.1 million ($40.4 million) benefit, net of certain fees, related to CEWS for claim periods beginning March 15, 2020, including CAD$43.9 million ($34.7 million) related to employee wages during fiscal 2020. As of May 1, 2021, amounts receivable from this subsidy were CAD$4.8 million ($3.9 million).

[0000936395-21-000034:notes:52]
The following table summarizes CEWS for the periods indicated (in thousands):

[0000936395-21-000034:notes:53]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Product | $ | 4,189 |  |  | $ | — |  |  | $ | 4,189 |  |  | $ | — |  |
| Service | 2,620 |  |  | — |  |  | 2,620 |  |  | — |  |
| CEWS benefit in cost of goods sold | 6,809 |  |  | — |  |  | 6,809 |  |  | — |  |
| Research and development | 28,923 |  |  | — |  |  | 28,923 |  |  | — |  |
| Sales and marketing | 2,551 |  |  | — |  |  | 2,551 |  |  | — |  |
| General and administrative | 2,161 |  |  | — |  |  | 2,161 |  |  | — |  |
| CEWS benefit in operating expense | 33,635 |  |  | — |  |  | 33,635 |  |  | — |  |
| Total CEWS benefit | $ | 40,444 |  |  | $ | — |  |  | $ | 40,444 |  |  | $ | — |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-21-000034:notes:54]
RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets, for the six months ended May 1, 2021 (in thousands):

[0000936395-21-000034:notes:55]
|  | Workforcereduction |  | Consolidationof excessfacilities and other restructuring activities |  | Total |
| Balance at October 31, 2020 | $ | 2,915 |  |  | $ | — |  |  | $ | 2,915 |  |
| Charges | 2,617 |  | (1) | 11,459 |  | (2) | 14,076 |  |
| Cash payments | (4,696) |  |  | (11,459) |  |  | (16,155) |  |
| Balance at May 1, 2021 | $ | 836 |  |  | $ | — |  |  | $ | 836 |  |
| Current restructuring liabilities | $ | 836 |  |  | $ | — |  |  | $ | 836 |  |

[0000936395-21-000034:notes:56]
(1) Reflects a global workforce reduction of 66 employees during the six months ended May 1, 2021 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-21-000034:notes:57]
(2) Primarily represents the redesign of certain business processes and costs and imputed interest expense related to restructured facilities.

[0000936395-21-000034:notes:58]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets for the six months ended May 2, 2020 (in thousands):

[0000936395-21-000034:notes:59]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at November 2, 2019 | $ | 3,983 |  |  | $ | 11,160 |  |  | $ | 15,143 |  |
| Charges | 4,426 |  | (1) | 3,857 |  | (2) | 8,283 |  |
| Adjustments related to ASC 842 | — |  |  | (11,160) |  | (3) | (11,160) |  |
| Cash payments | (5,982) |  |  | (3,857) |  |  | (9,839) |  |
| Balance at May 2, 2020 | $ | 2,427 |  |  | $ | — |  |  | $ | 2,427 |  |
| Current restructuring liabilities | $ | 2,427 |  |  | $ | — |  |  | $ | 2,427 |  |

[0000936395-21-000034:notes:60]
(1) Reflects a global workforce reduction of approximately 86 employees during the six months ended May 2, 2020 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-21-000034:notes:61]
[same as prior period, unchanged from 0000936395-21-000010:notes:54]

[0000936395-21-000034:notes:62]
[same as prior period, unchanged from 0000936395-21-000010:notes:55]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-21-000034:notes:63]
INTEREST AND OTHER INCOME (LOSS), NET
The components of interest and other income (loss), net, are as follows (in thousands):

[0000936395-21-000034:notes:64]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest income | $ | 554 |  |  | $ | 2,023 |  |  | $ | 1,088 |  |  | $ | 5,413 |  |
| Gains on non-hedge designated foreign currency forward contracts | 5,180 |  |  | 1,086 |  |  | 9,709 |  |  | 1,723 |  |
| Foreign currency exchange losses | (6,575) |  |  | (4,067) |  |  | (13,493) |  |  | (4,839) |  |
| Other | (433) |  |  | (1,707) |  |  | 301 |  |  | (1,316) |  |
| Interest and other income (loss), net | $ | (1,274) |  |  | $ | (2,665) |  |  | $ | (2,395) |  |  | $ | 981 |  |

[0000936395-21-000034:notes:65]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $13.5 million and $4.8 million in foreign currency exchange rate losses during the first six months of fiscal 2021 and 2020, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. During the first six months of fiscal 2021 and 2020, respectively, Ciena recorded gains of $9.7 million and $1.7 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-21-000034:notes:66]
INCOME TAXES
The effective tax rate for the quarter and six months ended May 1, 2021 was lower than the effective tax rate for the second quarter and six months ended May 2, 2020, primarily due to an increased deduction for foreign-derived intangible income (“FDII”) as well as a decrease in the foreign effective tax rate.

[0000936395-21-000034:notes:67]
Ciena’s future income tax provisions and deferred tax balances may be affected by the amount of pre-tax income, the jurisdictions where it is earned, the existence and ability to utilize tax attributes and changes in tax laws and business reorganizations. Ciena continues to monitor these items and will adopt strategies to address their impact as appropriate.
To better accommodate the requirements of a global business, Ciena is evaluating a plan to reorganize its global supply chain and distribution structure, which would include a legal entity reorganization and related system upgrade. Ciena expects to adopt the plan in the third quarter of fiscal 2021. This reorganization could have a material effect on Ciena’s financial position and operating results, including a significant one-time tax benefit associated with the recognition of a net deferred tax asset and potential reversal of a portion of the valuation allowance.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-21-000034:notes:68]
SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-21-000034:notes:69]
|  | May 1, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,764 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 151,816 |  |
| Included in long-term investments | 91,695 |  |  | 22 |  |  | (2) |  |  | 91,715 |  |
|  | $ | 243,459 |  |  | $ | 74 |  |  | $ | (2) |  |  | $ | 243,531 |  |

[0000936395-21-000034:notes:70]
|  | October 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 150,559 |  |  | $ | 109 |  |  | $ | (1) |  |  | $ | 150,667 |  |
| Included in long-term investments | 82,252 |  |  | — |  |  | (26) |  |  | 82,226 |  |
|  | $ | 232,811 |  |  | $ | 109 |  |  | $ | (27) |  |  | $ | 232,893 |  |

[0000936395-21-000034:notes:71]
The following table summarizes the final legal maturities of debt investments at May 1, 2021 (in thousands):

[0000936395-21-000034:notes:72]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 151,764 |  |  | $ | 151,816 |  |
| Due in 1-2 years | 91,695 |  |  | 91,715 |  |
|  | $ | 243,459 |  |  | $ | 243,531 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-21-000034:notes:73]
FAIR VALUE MEASUREMENTS    As of the date indicated, the following table summarizes the assets and liabilities that are recorded at fair value on a recurring basis (in thousands):

[0000936395-21-000034:notes:74]
|  | May 1, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 933,403 |  |  | $ | — |  |  | $ | — |  |  | $ | 933,403 |  |
| Bond mutual fund | 75,370 |  |  | — |  |  | — |  |  | 75,370 |  |
| Time deposits | 30,018 |  |  | — |  |  | — |  |  | 30,018 |  |
| Deferred compensation plan assets | 11,799 |  |  | — |  |  | — |  |  | 11,799 |  |
| U.S. government obligations | — |  |  | 243,531 |  |  | — |  |  | 243,531 |  |
| Foreign currency forward contracts | — |  |  | 13,785 |  |  | — |  |  | 13,785 |  |
| Total assets measured at fair value | $ | 1,050,590 |  |  | $ | 257,316 |  |  | $ | — |  |  | $ | 1,307,906 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 285 |  |  | $ | — |  |  | $ | 285 |  |
| Forward starting interest rate swaps | — |  |  | 22,794 |  |  | — |  |  | 22,794 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 23,079 |  |  | $ | — |  |  | $ | 23,079 |  |

[0000936395-21-000034:notes:75]
[same as prior period, unchanged from 0000936395-21-000010:notes:68]

[0000936395-21-000034:notes:76]
[same as prior period, unchanged from 0000936395-21-000010:notes:69]

[0000936395-21-000034:notes:77]
|  | May 1, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,038,791 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,038,791 |  |
| Short-term investments | — |  |  | 151,816 |  |  | — |  |  | 151,816 |  |
| Prepaid expenses and other | — |  |  | 13,785 |  |  | — |  |  | 13,785 |  |
| Long-term investments | — |  |  | 91,715 |  |  | — |  |  | 91,715 |  |
| Other long-term assets | 11,799 |  |  | — |  |  | — |  |  | 11,799 |  |
| Total assets measured at fair value | $ | 1,050,590 |  |  | $ | 257,316 |  |  | $ | — |  |  | $ | 1,307,906 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 285 |  |  | $ | — |  |  | $ | 285 |  |
| Other long-term obligations | — |  |  | 22,794 |  |  | — |  |  | 22,794 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 23,079 |  |  | $ | — |  |  | $ | 23,079 |  |

[0000936395-21-000034:notes:78]
[same as prior period, unchanged from 0000936395-21-000010:notes:71]

[0000936395-21-000034:notes:79]
[same as prior period, unchanged from 0000936395-21-000010:notes:72]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-21-000034:notes:80]
[same as prior period, unchanged from 0000936395-21-000010:notes:73]

[0000936395-21-000034:notes:81]
|  | May 1,2021 |  | October 31,2020 |
| Raw materials | $ | 139,430 |  |  | $ | 119,481 |  |
| Work-in-process | 10,809 |  |  | 13,738 |  |
| Finished goods | 234,220 |  |  | 210,050 |  |
| Deferred cost of goods sold | 57,390 |  |  | 40,747 |  |
| Gross inventories | 441,849 |  |  | 384,016 |  |
| Provision for excess and obsolescence | (40,616) |  |  | (39,637) |  |
| Inventories, net | $ | 401,233 |  |  | $ | 344,379 |  |

[0000936395-21-000034:notes:82]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first six months of fiscal 2021, Ciena recorded a provision for excess and obsolescence of $10.4 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-21-000034:notes:83]
PREPAID EXPENSES AND OTHERAs of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-21-000034:notes:84]
|  | May 1,2021 |  | October 31,2020 |
| Contract assets for unbilled accounts receivable, net | $ | 81,437 |  |  | $ | 85,843 |  |
| Prepaid expenses | 77,389 |  |  | 70,647 |  |
| Prepaid VAT and other taxes | 72,325 |  |  | 72,838 |  |
| Product demonstration equipment, net | 45,151 |  |  | 44,793 |  |
| Other non-trade receivables | 14,193 |  |  | 21,981 |  |
| Derivative assets | 13,785 |  |  | 82 |  |
| Capitalized contract acquisition costs | 13,008 |  |  | 11,296 |  |
| CEWS receivable | 3,942 |  |  | — |  |
| Deferred deployment expense | 421 |  |  | 604 |  |
|  | $ | 321,651 |  |  | $ | 308,084 |  |

[0000936395-21-000034:notes:85]
Depreciation of product demonstration equipment was $5.1 million during the first six months of fiscal 2021 and $4.2 million during the first six months of fiscal 2020.

[0000936395-21-000034:notes:86]
[same as prior period, unchanged from 0000936395-21-000010:notes:79]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-21-000034:notes:87]
[same as prior period, unchanged from 0000936395-21-000010:notes:80]

[0000936395-21-000034:notes:88]
|  | May 1,2021 |  | October 31,2020 |
| Compensation, payroll related tax and benefits (1) | $ | 114,119 |  |  | $ | 135,462 |  |
| Warranty | 48,123 |  |  | 49,868 |  |
| Vacation | 30,612 |  |  | 26,945 |  |
| Finance lease obligations | 3,245 |  |  | 2,836 |  |
| Interest payable | 665 |  |  | 672 |  |
| Other | 133,296 |  |  | 118,349 |  |
|  | $ | 330,060 |  |  | $ | 334,132 |  |

[0000936395-21-000034:notes:89]
[same as prior period, unchanged from 0000936395-21-000010:notes:82]

[0000936395-21-000034:notes:90]
The following table summarizes the activity in Ciena’s accrued warranty for the periods indicated (in thousands):

[0000936395-21-000034:notes:91]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Six Months Ended May 2, 2020 |  | $ | 48,498 |  |  |  |  | 13,793 |  |  | (10,428) |  |  | $ | 51,863 |  |
| Six Months Ended May 1, 2021 |  | $ | 49,868 |  |  |  |  | 7,937 |  |  | (9,682) |  |  | $ | 48,123 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-21-000034:notes:92]
[same as prior period, unchanged from 0000936395-21-000010:notes:85]

[0000936395-21-000034:notes:93]
Ciena conducts business globally in numerous currencies, and thus is exposed to adverse foreign currency exchange rate changes. To limit this exposure, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-21-000034:notes:94]
As of May 1, 2021 and October 31, 2020, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability principally related to research and development activities. The notional amount of these contracts was approximately $239.1 million and $254.9 million as of May 1, 2021 and October 31, 2020, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-21-000034:notes:95]
As of May 1, 2021 and October 31, 2020, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $244.8 million and $212.0 million as of May 1, 2021 and October 31, 2020, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-21-000034:notes:96]
[same as prior period, unchanged from 0000936395-21-000010:notes:89]

[0000936395-21-000034:notes:97]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan (as defined in Note 16 below) at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of May 1, 2021 and October 31, 2020.

[0000936395-21-000034:notes:98]
[same as prior period, unchanged from 0000936395-21-000010:notes:91]

[0000936395-21-000034:notes:99]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Note 6 and Note 9 above.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-21-000034:notes:100]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the six months ended May 1, 2021 (in thousands):

[0000936395-21-000034:notes:101]
|  | Unrealized Gain/(Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2020 | $ | 45 |  |  | $ | (219) |  |  | $ | (21,535) |  |  | $ | (13,649) |  |  | $ | (35,358) |  |
| Other comprehensive gain (loss) before reclassifications | (7) |  |  | 14,690 |  |  | (494) |  |  | 26,261 |  |  | 40,450 |  |
| Amounts reclassified from AOCI | — |  |  | (4,256) |  |  | 4,525 |  |  | — |  |  | 269 |  |
| Balance at May 1, 2021 | $ | 38 |  |  | $ | 10,215 |  |  | $ | (17,504) |  |  | $ | 12,612 |  |  | $ | 5,361 |  |

[0000936395-21-000034:notes:102]
The following table summarizes the changes in AOCI, net of tax, for the six months ended May 2, 2020 (in thousands):

[0000936395-21-000034:notes:103]
|  | Unrealized Gain/(Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at November 2, 2019 | $ | 152 |  |  | $ | 925 |  |  | $ | (13,686) |  |  | $ | (9,475) |  |  | $ | (22,084) |  |
| Other comprehensive loss before reclassifications | 310 |  |  | (9,559) |  |  | (10,932) |  |  | (21,490) |  |  | (41,671) |  |
| Amounts reclassified from AOCI | — |  |  | 1,540 |  |  | 829 |  |  | — |  |  | 2,369 |  |
| Balance at May 2, 2020 | $ | 462 |  |  | $ | (7,094) |  |  | $ | (23,789) |  |  | $ | (30,965) |  |  | $ | (61,386) |  |

[0000936395-21-000034:notes:104]
[same as prior period, unchanged from 0000936395-21-000010:notes:97]


## us-gaap:LesseeFinanceLeasesTextBlock

[0000936395-21-000034:notes:105]
LEASES
Ciena leases over 1.3 million square feet of facilities globally. Ciena’s principal executive offices are located in Hanover, Maryland. Ciena’s largest facilities are research and development centers located in Ottawa, Canada and Gurgaon, India. Ciena also has engineering and/or service delivery facilities located in San Jose, California; Alpharetta, Georgia; Quebec, Canada; and Pune and Bangalore, India. In addition, Ciena leases various smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. Ciena's current leases have remaining terms that vary up to 11 years. Certain leases provide for options to extend up to ten years and/or options to terminate within five years.

[0000936395-21-000034:notes:106]
Leases included in the Condensed Consolidated Balance Sheets were as follows (in thousands):

[0000936395-21-000034:notes:107]
|  | Classification |  | As of May 1, 2021 | As of October 31, 2020 |
| Operating leases: |  |  |  |  |
| Operating ROU assets | Operating right-of-use assets |  | $ | 50,997 |  | $ | 57,026 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | 73,159 |  | 80,450 |  |
| Finance leases: |  |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 76,711 |  | $ | 70,791 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (21,771) |  | (17,837) |  |
| Buildings, net |  |  | $ | 54,940 |  | $ | 52,954 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 68,271 |  | $ | 64,401 |  |

[0000936395-21-000034:notes:108]
ROU assets that involve subleased or vacant space aggregate to $4.6 million as of May 1, 2021. These assets may become impaired if tenants are unable to service their obligations under the sublease, and/or if the estimates as to occupancy are not realized, either of which may be more likely as COVID-19 impacts evolve.

[0000936395-21-000034:notes:109]
The components of lease expense included in the Condensed Consolidated Statement of Operations were as follows (in thousands):

[0000936395-21-000034:notes:110]
|  |  |  | Quarter Ended |  | Six Months Ended |
|  |  |  | May 1, | May 2, |  | May 1, | May 2, |
|  | Classification |  | 2021 | 2020 |  | 2021 | 2020 |
| Operating lease costs | Operating expense |  | $ | 4,202 |  | $ | 4,744 |  |  | $ | 8,431 |  | $ | 9,201 |  |
| Finance lease cost: |  |  |  |  |  |  |  |
| Amortization of finance ROU asset | Operating expense |  | 1,191 |  | 1,093 |  |  | 2,356 |  | 2,233 |  |
| Interest on finance lease liabilities | Interest expense |  | 1,207 |  | 1,168 |  |  | 2,428 |  | 2,412 |  |
| Total finance lease cost |  |  | 2,398 |  | 2,261 |  |  | 4,784 |  | 4,645 |  |
| Non-capitalized lease cost | Operating expense |  | 333 |  | 707 |  |  | 626 |  | 1,328 |  |
| Variable lease cost(1) | Operating expense |  | 1,452 |  | 1,324 |  |  | 3,051 |  | 2,635 |  |
| Net lease cost(2) |  |  | $ | 8,385 |  | $ | 9,036 |  |  | $ | 16,892 |  | $ | 17,809 |  |

[0000936395-21-000034:notes:111]
(1) Variable lease costs include expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0000936395-21-000034:notes:112]
(2) Excludes other operating expense of $2.6 million and $2.2 million for the second quarter of fiscal 2021 and 2020, respectively and $4.9 million and $6.5 million for the six months ended May 1, 2021 and May 2, 2020, respectively, related to amortization of leasehold improvements.

[0000936395-21-000034:notes:113]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of May 1, 2021 were as follows (in thousands):

[0000936395-21-000034:notes:114]
|  | Operating Leases |  | Finance Leases |  | Total |
| Remaining fiscal 2021 | $ | 10,772 |  |  | $ | 8,125 |  |  | $ | 18,897 |  |
| 2022 | 19,462 |  |  | 8,623 |  |  | 28,085 |  |
| 2023 | 16,020 |  |  | 8,624 |  |  | 24,644 |  |
| 2024 | 13,371 |  |  | 8,693 |  |  | 22,064 |  |
| 2025 | 9,058 |  |  | 8,832 |  |  | 17,890 |  |
| Thereafter | 9,434 |  |  | 58,544 |  |  | 67,978 |  |
| Total lease payments | 78,117 |  |  | 101,441 |  |  | 179,558 |  |
| Less: Imputed interest | (4,958) |  |  | (33,170) |  |  | (38,128) |  |
| Present value of lease liabilities | 73,159 |  |  | 68,271 |  |  | 141,430 |  |
| Less: Current portion of present value of minimum lease payments | (19,364) |  |  | (3,245) |  |  | (22,609) |  |
| Long-term portion of present value of minimum lease payments | $ | 53,795 |  |  | $ | 65,026 |  |  | $ | 118,821 |  |

[0000936395-21-000034:notes:115]
The weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows:

[0000936395-21-000034:notes:116]
|  | As of May 1, 2021 | As of October 31, 2020 |
| Weighted-average remaining lease term in years: |  |  |
| Operating leases | 4.53 | 4.87 |
| Finance leases | 11.22 | 11.71 |
| Weighted-average discount rates: |  |  |
| Operating leases | 2.79 | % | 2.82 | % |
| Finance leases | 7.56 | % | 7.56 | % |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-21-000034:notes:117]
SHORT-TERM AND LONG-TERM DEBT 
2025 Term Loan

[0000936395-21-000034:notes:118]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-21-000034:notes:119]
The net carrying value of Ciena’s term loan was comprised of the following for the periods indicated (in thousands):

[0000936395-21-000034:notes:120]
|  |  | May 1, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 684,337 |  |  | $ | (1,414) |  |  | $ | (2,638) |  |  | $ | 680,285 |  |  | $ | 683,286 |  |

[0000936395-21-000034:notes:121]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loan totaled $2.6 million as of May 1, 2021 and $2.9 million at October 31, 2020. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.3 million during the first six months of each of fiscal 2021 and fiscal 2020. The carrying value of the term loan listed above is also net of any unamortized debt discounts.

[0000936395-21-000034:notes:122]
As of May 1, 2021, the estimated fair value of the 2025 Term Loan was $685.2 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:EarningsPerShareTextBlock

[0000936395-21-000034:notes:123]
EARNINGS PER SHARE CALCULATION
The following table presents the calculation of basic and diluted net income per share (in thousands, except per share amounts):

[0000936395-21-000034:notes:124]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income | $ | 103,117 |  |  | $ | 91,655 |  |  | $ | 158,465 |  |  | $ | 153,983 |  |
| Basic weighted average shares outstanding | 155,331 |  |  | 153,858 |  |  | 155,257 |  |  | 154,099 |  |
| Effect of dilutive potential common shares | 1,545 |  |  | 1,283 |  |  | 1,477 |  |  | 1,344 |  |
| Diluted weighted average shares | 156,876 |  |  | 155,141 |  |  | 156,734 |  |  | 155,443 |  |
| Basic EPS | $ | 0.66 |  |  | $ | 0.60 |  |  | $ | 1.02 |  |  | $ | 1.00 |  |
| Diluted EPS | $ | 0.66 |  |  | $ | 0.59 |  |  | $ | 1.01 |  |  | $ | 0.99 |  |
| Antidilutive employee share-based awards, excluded | 30 |  |  | 203 |  |  | 82 |  |  | 467 |  |

[0000936395-21-000034:notes:125]
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-21-000034:notes:126]
[same as prior period, unchanged from 0000936395-21-000010:notes:122]

[0000936395-21-000034:notes:127]
[same as prior period, unchanged from 0000936395-21-000010:notes:123]

[0000936395-21-000034:notes:128]
[same as prior period, unchanged from 0000936395-21-000010:notes:124]

[0000936395-21-000034:notes:129]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2020 | 5,710,912 |  |  | $ | 39.33 |  |  | $ | 224,611 |  |
| Repurchase of common stock under the stock repurchase program | 735,075 |  |  | 53.60 |  |  | 39,398 |  |
| Cumulative balance at May 1, 2021 | 6,445,987 |  |  | $ | 40.96 |  |  | $ | 264,009 |  |

[0000936395-21-000034:notes:130]
[same as prior period, unchanged from 0000936395-21-000010:notes:126]

[0000936395-21-000034:notes:131]
[same as prior period, unchanged from 0000936395-21-000010:notes:127]

[0000936395-21-000034:notes:132]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The purchase price of $27.9 million for the shares of Ciena’s stock repurchased during the first six months of fiscal 2021 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-21-000034:notes:133]
SHARE-BASED COMPENSATION EXPENSEAmended and Restated ESPP
Ciena makes shares of its common stock available for purchase under its Amended and Restated Ciena Corporation Employee Stock Purchase Plan (the “ESPP”). Under the ESPP, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. On January 29, 2021, Ciena’s Board of Directors adopted an amendment and restatement of the ESPP to increase the number of shares available for issuance thereunder by 8.7 million and eliminate the evergreen mechanism thereunder, which became effective upon its approval by Ciena’s stockholders on April 1, 2021. Unless earlier terminated, the ESPP will terminate on April 1, 2031.

[0000936395-21-000034:notes:134]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-21-000034:notes:135]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Product | $ | 498 |  |  | $ | 827 |  |  | $ | 1,451 |  |  | $ | 1,498 |  |
| Service | 1,421 |  |  | 1,036 |  |  | 2,626 |  |  | 1,878 |  |
| Share-based compensation expense included in cost of goods sold | 1,919 |  |  | 1,863 |  |  | 4,077 |  |  | 3,376 |  |
| Research and development | 5,844 |  |  | 4,822 |  |  | 10,638 |  |  | 8,671 |  |
| Sales and marketing | 6,610 |  |  | 5,264 |  |  | 12,426 |  |  | 9,877 |  |
| General and administrative | 6,743 |  |  | 5,975 |  |  | 13,101 |  |  | 11,502 |  |
| Share-based compensation expense included in operating expense | 19,197 |  |  | 16,061 |  |  | 36,165 |  |  | 30,050 |  |
| Share-based compensation expense capitalized in inventory, net | 419 |  |  | 53 |  |  | 257 |  |  | 153 |  |
| Total share-based compensation | $ | 21,535 |  |  | $ | 17,977 |  |  | $ | 40,499 |  |  | $ | 33,579 |  |

[0000936395-21-000034:notes:136]
As of May 1, 2021, total unrecognized share-based compensation expense was approximately $155.6 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.57 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-21-000034:notes:137]
[same as prior period, unchanged from 0000936395-21-000010:notes:132]

[0000936395-21-000034:notes:138]
[same as prior period, unchanged from 0000936395-21-000010:notes:133]

[0000936395-21-000034:notes:139]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, ROU assets, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of May 1, 2021, equipment, building, furniture and fixtures, net, totaled $298.3 million, and operating ROU assets totaled $51.0 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of May 1, 2021, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-21-000034:notes:140]
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 11,395 |  |  | $ | — |  |  | $ | 71,484 |  |  | $ | — |  |  | $ | 82,879 |  |
| Goodwill | $ | 66,493 |  |  | $ | 156,191 |  |  | $ | 89,050 |  |  | $ | — |  |  | $ | 311,734 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 63,003 |  |  | $ | 63,003 |  |

[0000936395-21-000034:notes:141]
[same as prior period, unchanged from 0000936395-21-000010:notes:136]

[0000936395-21-000034:notes:142]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive

[0000936395-21-000034:notes:143]
officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; significant asset impairments and restructuring costs; acquisition and integration costs; interest and other income (loss), net; interest expense; loss on extinguishment and modification of debt and provision for income taxes.

[0000936395-21-000034:notes:144]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income for the periods indicated (in thousands):

[0000936395-21-000034:notes:145]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 211,412 |  |  | $ | 210,987 |  |  | $ | 367,843 |  |  | $ | 379,256 |  |
| Platform Software and Services | 36,506 |  |  | 21,668 |  |  | 64,166 |  |  | 50,619 |  |
| Blue Planet Automation Software and Services | 5,688 |  |  | (4,399) |  |  | 3,254 |  |  | (7,512) |  |
| Global Services | 48,567 |  |  | 53,540 |  |  | 92,060 |  |  | 99,068 |  |
| Total segment profit | 302,173 |  |  | 281,796 |  |  | 527,323 |  |  | 521,431 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 110,387 |  |  | 101,214 |  |  | 207,665 |  |  | 208,280 |  |
| General and administrative | 43,635 |  |  | 42,030 |  |  | 83,628 |  |  | 84,498 |  |
| Amortization of intangible assets | 6,019 |  |  | 5,839 |  |  | 11,929 |  |  | 11,692 |  |
| Significant asset impairments and restructuring costs | 8,209 |  |  | 3,811 |  |  | 14,076 |  |  | 8,283 |  |
| Acquisition and integration costs | 294 |  |  | 1,414 |  |  | 601 |  |  | 3,233 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (9,059) |  |  | (10,525) |  |  | (17,540) |  |  | (15,694) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | — |  |  | (646) |  |
| Less: Provision for income taxes | 21,453 |  |  | 25,308 |  |  | 33,419 |  |  | 35,122 |  |
| Consolidated net income | $ | 103,117 |  |  | $ | 91,655 |  |  | $ | 158,465 |  |  | $ | 153,983 |  |

[0000936395-21-000034:notes:146]
[same as prior period, unchanged from 0000936395-21-000010:notes:140]

[0000936395-21-000034:notes:147]
[same as prior period, unchanged from 0000936395-21-000010:notes:141]

[0000936395-21-000034:notes:148]
|  | May 1,2021 |  | October 31,2020 |
| Canada | $ | 247,309 |  |  | $ | 214,188 |  |
| United States | 59,229 |  |  | 65,321 |  |
| Other International | 42,788 |  |  | 49,894 |  |
| Total | $ | 349,326 |  |  | $ | 329,403 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-21-000034:notes:149]
COMMITMENTS AND CONTINGENCIES
Canadian Grant

[0000936395-21-000034:notes:150]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $46.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject

[0000936395-21-000034:notes:151]
to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of May 1, 2021, Ciena has recorded CAD$45.5 million (approximately $37.0 million) in cumulative benefits as a reduction in research and development expense of which CAD$4.9 million ($3.8 million) was recorded in the first six months of fiscal 2021. As of May 1, 2021, amounts receivable from this grant were CAD$2.7 million ($2.2 million).

[0000936395-21-000034:notes:152]
Tax Contingencies

[0000936395-21-000034:notes:153]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-21-000034:notes:154]
Litigation

[0000936395-21-000034:notes:155]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-21-000034:notes:156]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0000936395-21-000034:notes:157]
From the end of the second quarter of fiscal 2021 through June 4, 2021, Ciena repurchased an additional 195,920 shares of its common stock, for an aggregate purchase price of $10.4 million at an average price of $52.84 per share, inclusive of repurchases pending settlement. As of June 4, 2021, Ciena has repurchased an aggregate of 6,641,907 shares and has an aggregate of $225.6 million of authorized funds remaining under its stock repurchase program.
