# CIEN 8-K — 0000936395-18-000043 filed 2018-12-13

## item codes, every 8-K on or before 2018-12-21

- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2018-12-21

- none on or before 2018-12-21

## item 2.02 — earnings release, exhibit 99.1

[0000936395-18-000043:8k_2_02:1]
EX-99.1
2
ex991-2018q4pressrelease.htm
EXHIBIT 99.1

[0000936395-18-000043:8k_2_02:2]
Exhibit

[0000936395-18-000043:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-18-000043:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2018 and Year-End Financial Results

[0000936395-18-000043:8k_2_02:5]
Announces new share repurchase program of up to $500 million

[0000936395-18-000043:8k_2_02:6]
HANOVER, Md. - December 13, 2018 - Ciena® Corporation (NYSE: CIEN), a network strategy and technology company, today announced unaudited financial results for its fiscal fourth quarter and year ended October 31, 2018.

[0000936395-18-000043:8k_2_02:7]
| • | Q4 Revenue: $899.4 million, increasing 20.8% year over year |

[0000936395-18-000043:8k_2_02:8]
| • | Q4 Net Income per Share: $0.34 GAAP; $0.53 adjusted (non-GAAP) |

[0000936395-18-000043:8k_2_02:9]
| • | Share Repurchases: Repurchased approximately 1.3 million shares of common stock for an aggregate price of $36.2 million during the quarter |

[0000936395-18-000043:8k_2_02:10]
“We achieved outstanding financial results in our fourth quarter and fiscal 2018 due to continued execution of our proven strategy," said Gary B. Smith, president and CEO, Ciena. "The combination of our innovation strength, successful interception of market trends and sustained ability to take share and outperform the market, along with a thriving industry environment, gives us tremendous confidence in both the near and longer term outlook for our business.”

[0000936395-18-000043:8k_2_02:11]
For the fiscal fourth quarter 2018, Ciena reported revenue of $899.4 million as compared to $744.4 million for the fiscal fourth quarter 2017. For fiscal year 2018, Ciena reported revenue of $3.09 billion, as compared to $2.80 billion for fiscal year 2017.

[0000936395-18-000043:8k_2_02:12]
Ciena's GAAP net income for the fiscal fourth quarter 2018 was $64.0 million or $0.34 per diluted common share, which compares to a GAAP net income of $1,160.1 million, or $7.32 per diluted common share, for the fiscal fourth quarter 2017. For fiscal year 2018, Ciena's GAAP net loss was $(344.7) million, or $(2.49) per diluted common share, as compared to a GAAP net income of $1,262.0 million, or $7.53 per diluted common share for fiscal year 2017.

[0000936395-18-000043:8k_2_02:13]
Ciena's adjusted (non-GAAP) net income for the fiscal fourth quarter 2018 was $81.0 million, or $0.53 per diluted common share, which compares to an adjusted (non-GAAP) net income of $48.5 million, or $0.32 per diluted common share, for the fiscal fourth quarter 2017. For fiscal year 2018, Ciena's adjusted (non-GAAP) net income was $210.6 million, or $1.39 per diluted common share, as compared to an adjusted (non-GAAP) net income of $177.7 million, or $1.14 per diluted common share for fiscal year 2017.

[0000936395-18-000043:8k_2_02:14]
Fiscal Fourth Quarter 2018 Performance Summary

[0000936395-18-000043:8k_2_02:15]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarterly and  year over year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendix A and B to this release.

[0000936395-18-000043:8k_2_02:16]
|  |  | GAAP Results (unaudited) |
|  |  | Q4 |  | Q4 | Period Change |
|  |  | FY 2018 |  | FY 2017 |  | Y-T-Y* |
| Revenue |  | $ | 899.4 |  |  | $ | 744.4 |  |  | 20.8 | % |
| Gross margin |  | 44.3 | % |  | 43.7 | % |  | 0.6 | % |
| Operating expense |  | $ | 302.2 |  |  | $ | 269.9 |  |  | 12.0 | % |
| Operating margin |  | 10.7 | % |  | 7.5 | % |  | 3.2 | % |

[0000936395-18-000043:8k_2_02:17]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q4 |  | Q4 |  | Period Change |
|  |  | FY 2018 |  | FY 2017 |  | Y-T-Y* |
| Revenue |  | $ | 899.4 |  |  | $ | 744.4 |  |  | 20.8 | % |
| Adj. gross margin |  | 44.7 | % |  | 44.2 | % |  | 0.5 | % |
| Adj. operating expense |  | $ | 277.7 |  |  | $ | 240.9 |  |  | 15.3 | % |
| Adj. operating margin |  | 13.9 | % |  | 11.9 | % |  | 2.0 | % |

[0000936395-18-000043:8k_2_02:18]
* Denotes % change, or in the case of margin, absolute change

[0000936395-18-000043:8k_2_02:19]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q4 FY 2018 |  | Q4 FY 2017 |
|  |  | Revenue |  | % |  | Revenue |  | % |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 646.4 |  |  | 71.9 |  | $ | 506.4 |  |  | 68.0 |
| Packet Networking |  | 66.5 |  |  | 7.4 |  | 92.5 |  |  | 12.5 |
| Total Networking Platforms |  | 712.9 |  |  | 79.3 |  | 598.9 |  |  | 80.5 |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |
| Platform Software and Services |  | 56.6 |  |  | 6.3 |  | 35.9 |  |  | 4.8 |
| Blue Planet Automation Software and Services |  | 10.7 |  |  | 1.2 |  | 5.9 |  |  | 0.8 |
| Total Software and Software-Related Services |  | 67.3 |  |  | 7.5 |  | 41.8 |  |  | 5.6 |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 67.4 |  |  | 7.5 |  | 56.2 |  |  | 7.5 |
| Installation and Deployment |  | 39.3 |  |  | 4.4 |  | 33.5 |  |  | 4.5 |
| Consulting and Network Design |  | 12.5 |  |  | 1.3 |  | 14.0 |  |  | 1.9 |
| Total Global Services |  | 119.2 |  |  | 13.2 |  | 103.7 |  |  | 13.9 |
| Total |  | $ | 899.4 |  |  | 100.0 |  | $ | 744.4 |  |  | 100.0 |

[0000936395-18-000043:8k_2_02:20]
Additional Performance Metrics for Fiscal Fourth Quarter 2018

[0000936395-18-000043:8k_2_02:21]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q4 FY 2018 |  | Q4 FY 2017 |
|  |  | Revenue |  | % |  | Revenue |  | % |
| North America |  | $ | 555.3 |  |  | 61.7 |  | $ | 440.5 |  |  | 59.2 |
| Europe, Middle East and Africa |  | 123.1 |  |  | 13.7 |  | 110.7 |  |  | 14.9 |
| Caribbean and Latin America |  | 53.0 |  |  | 5.9 |  | 43.5 |  |  | 5.8 |
| Asia Pacific |  | 168.0 |  |  | 18.7 |  | 149.7 |  |  | 20.1 |
| Total |  | $ | 899.4 |  |  | 100.0 |  | $ | 744.4 |  |  | 100.0 |

[0000936395-18-000043:8k_2_02:22]
| • | Three 10%-plus customers represented a total of 33.1% of revenue |

[0000936395-18-000043:8k_2_02:23]
| • | Cash and investments totaled $953.4 million |

[0000936395-18-000043:8k_2_02:24]
| • | Cash flow from operations totaled $68.0 million |

[0000936395-18-000043:8k_2_02:25]
| • | Average days' sales outstanding (DSOs) were 79 |

[0000936395-18-000043:8k_2_02:26]
| • | Accounts receivable balance was $786.5 million |

[0000936395-18-000043:8k_2_02:27]
| • | Inventories totaled $262.8 million, including: |

[0000936395-18-000043:8k_2_02:28]
| ◦ | Raw materials: $67.5 million |

[0000936395-18-000043:8k_2_02:29]
| ◦ | Work in process: 9.5 million |

[0000936395-18-000043:8k_2_02:30]
| ◦ | Finished goods: $188.6 million |

[0000936395-18-000043:8k_2_02:31]
| ◦ | Deferred cost of sales: $48.1 million |

[0000936395-18-000043:8k_2_02:32]
| ◦ | Reserve for excess and obsolescence: $(50.9) million |

[0000936395-18-000043:8k_2_02:33]
| • | Product inventory turns were 6.4 |

[0000936395-18-000043:8k_2_02:34]
| • | Headcount totaled 6,013 |

[0000936395-18-000043:8k_2_02:35]
Share Repurchase Program

[0000936395-18-000043:8k_2_02:36]
During fiscal year 2018, Ciena repurchased approximately 4.3 million shares of its common stock at an average price of $25.86 per share for an aggregate purchase price of $111.0 million. Highlighting its ongoing commitment to returning capital to shareholders, Ciena today announced that its Board of Directors has authorized a new program to repurchase up to $500 million of its common stock, replacing the previous targeted repurchase plan.

[0000936395-18-000043:8k_2_02:37]
Ciena may purchase shares at management's discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. Ciena may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of its shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended or discontinued at any time.

[0000936395-18-000043:8k_2_02:38]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2018 Results

[0000936395-18-000043:8k_2_02:39]
Today, Thursday, December 13, 2018, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain prepared remarks of management and related supporting materials for its unaudited fiscal fourth quarter and fiscal 2018 results.

[0000936395-18-000043:8k_2_02:40]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's fiscal first quarter 2019 outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-18-000043:8k_2_02:41]
Notes to Investors

[0000936395-18-000043:8k_2_02:42]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "The combination of continued execution against our strategy and robust, broad-based customer demand resulted in outstanding fiscal third quarter performance."; "With our diversification, global scale and innovation leadership, we remain confident in our business model and our ability to achieve our three-year financial targets."

[0000936395-18-000043:8k_2_02:43]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; the impact of the Tax Cuts and Jobs Act, changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise, and the other risk factors disclosed in Ciena's periodic reports filed with the Securities and Exchange Commission, including its Quarterly Report on Form 10-Q filed with the SEC on September 5, 2018 and its Annual Report on Form 10-K to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-18-000043:8k_2_02:44]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release for the relevant period, Appendix A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-18-000043:8k_2_02:45]
About Ciena.  Ciena (NYSE: CIEN) is a networking systems, services, and software company. We provide solutions that help our clients create more adaptive networks in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most sophisticated networks with automation and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-18-000043:8k_2_02:46]
CIENA CORPORATION

[0000936395-18-000043:8k_2_02:47]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-18-000043:8k_2_02:48]
(in thousands, except per share data)

[0000936395-18-000043:8k_2_02:49]
|  |  | Quarter Ended October 31, |  | Year Ended October 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |  |  |  |
| Products |  | 743,867 |  |  | 616,216 |  |  | 2,565,460 |  |  | 2,318,581 |  |
| Services |  | 155,489 |  |  | 128,233 |  |  | 528,826 |  |  | 483,106 |  |
| Total revenue |  | 899,356 |  |  | 744,449 |  |  | 3,094,286 |  |  | 2,801,687 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |
| Products |  | 421,583 |  |  | 352,992 |  |  | 1,507,157 |  |  | 1,308,295 |  |
| Services |  | 79,698 |  |  | 65,772 |  |  | 272,439 |  |  | 247,606 |  |
| Total cost of goods sold |  | 501,281 |  |  | 418,764 |  |  | 1,779,596 |  |  | 1,555,901 |  |
| Gross profit |  | 398,075 |  |  | 325,685 |  |  | 1,314,690 |  |  | 1,245,786 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 134,983 |  |  | 119,108 |  |  | 491,564 |  |  | 475,329 |  |
| Selling and marketing |  | 112,791 |  |  | 95,877 |  |  | 394,060 |  |  | 356,169 |  |
| General and administrative |  | 44,539 |  |  | 36,181 |  |  | 160,133 |  |  | 142,604 |  |
| Amortization of intangible assets |  | 4,654 |  |  | 3,661 |  |  | 15,737 |  |  | 33,029 |  |
| Acquisition and integration costs |  | 3,778 |  |  | — |  |  | 5,111 |  |  | — |  |
| Significant asset impairments and restructuring costs |  | 1,460 |  |  | 15,059 |  |  | 18,139 |  |  | 23,933 |  |
| Total operating expenses |  | 302,205 |  |  | 269,886 |  |  | 1,084,744 |  |  | 1,031,064 |  |
| Income from operations |  | 95,870 |  |  | 55,799 |  |  | 229,946 |  |  | 214,722 |  |
| Interest and other income (loss), net |  | (13,357 | ) |  | 1,344 |  |  | (12,029 | ) |  | 913 |  |
| Interest expense |  | (14,873 | ) |  | (13,926 | ) |  | (55,249 | ) |  | (55,852 | ) |
| Loss on extinguishment and modification of debt |  | (13,887 | ) |  | (692 | ) |  | (13,887 | ) |  | (3,657 | ) |
| Income before income taxes |  | 53,753 |  |  | 42,525 |  |  | 148,781 |  |  | 156,126 |  |
| Provision (benefit) for income taxes |  | (10,224 | ) |  | (1,117,531 | ) |  | 493,471 |  |  | (1,105,827 | ) |
| Net income (loss) |  | $ | 63,977 |  |  | $ | 1,160,056 |  |  | $ | (344,690 | ) |  | $ | 1,261,953 |  |
| Net Income (Loss) per Common Share |  |  |  |  |  |  |  |  |
| Basic net income (loss) per common share |  | $ | 0.45 |  |  | $ | 8.11 |  |  | $ | (2.40 | ) |  | $ | 8.89 |  |
| Diluted net income (loss) per potential common share1 |  | $ | 0.34 |  |  | $ | 7.32 |  |  | $ | (2.49 | ) |  | $ | 7.53 |  |
| Weighted average basic common shares outstanding |  | 143,659 |  |  | 143,097 |  |  | 143,738 |  |  | 141,997 |  |
| Weighted average diluted potential common shares outstanding 2 |  | 157,745 |  |  | 158,791 |  |  | 143,738 |  |  | 169,919 |  |

[0000936395-18-000043:8k_2_02:50]
1.  The calculation of GAAP diluted net income per common share for the fourth quarter of fiscal 2018 requires a) adding back interest expense of approximately $0.4 million associated with Ciena's "Original" 3.75% convertible senior notes, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018 and approximately $2.8 million associated with Ciena's 4.0% convertible senior notes, which were converted at Ciena's election during the fourth quarter of fiscal 2018, and b) reducing net income by $12.9 million for a non-cash loss due to a mark to market fair value adjustment related to the outstanding conversion feature of Ciena's "New" 3.75% senior convertible notes, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018, in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-18-000043:8k_2_02:51]
The calculation of GAAP diluted net loss per common share for fiscal 2018 requires an adjustment of $12.9 million for a non-cash loss due to a mark to market fair value adjustment related to the outstanding conversion feature of Ciena's "New" 3.75% senior convertible notes to the GAAP net loss in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-18-000043:8k_2_02:52]
The calculation of GAAP diluted net income per common share for the fourth quarter of fiscal 2017 requires adding back interest expense of approximately $0.4 million associated with Ciena's "Original" 3.75% convertible senior notes and approximately $2.3 million associated with Ciena's 4.0% convertible senior notes to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-18-000043:8k_2_02:53]
The calculation of GAAP diluted net income per common share for fiscal 2017 requires adding back interest expense of approximately $0.9 million associated with Ciena's 0.875% convertible senior notes, approximately $7.2 million associated with Ciena's "Original" 3.75% convertible senior notes and approximately $8.7 million associated with Ciena's 4.0% convertible senior notes to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-18-000043:8k_2_02:54]
2. Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the fourth quarter of fiscal 2018 includes 2.0 million shares underlying certain stock option and stock unit awards, 0.7 million and 2.5 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, and 8.9 million shares underlying Ciena's 4.0% convertible senior notes.

[0000936395-18-000043:8k_2_02:55]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the fourth quarter of fiscal 2017 includes 1.2 million shares underlying certain stock option and stock unit awards, 1.6 million and 3.7 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, and 9.2 million shares underlying Ciena's 4.0% convertible senior notes.

[0000936395-18-000043:8k_2_02:56]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for fiscal 2017 includes 1.4 million shares underlying certain stock option and stock unit awards, 0.4 million and 13.9 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, 3.0 million shares underlying Ciena's 0.875% convertible senior notes, and 9.2 million shares underlying Ciena's 4.0% convertible senior notes.

[0000936395-18-000043:8k_2_02:57]
CIENA CORPORATION

[0000936395-18-000043:8k_2_02:58]
CONDENSED UNAUDITED CONSOLIDATED BALANCE SHEETS

[0000936395-18-000043:8k_2_02:59]
(in thousands, except share data)

[0000936395-18-000043:8k_2_02:60]
|  | October 31, |
|  | 2018 |  | 2017 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 745,423 |  |  | $ | 640,513 |  |
| Short-term investments | 148,981 |  |  | 279,133 |  |
| Accounts receivable, net | 786,502 |  |  | 622,183 |  |
| Inventories | 262,751 |  |  | 267,143 |  |
| Prepaid expenses and other | 198,945 |  |  | 197,339 |  |
| Total current assets | 2,142,602 |  |  | 2,006,311 |  |
| Long-term investments | 58,970 |  |  | 49,783 |  |
| Equipment, building, furniture and fixtures, net | 292,067 |  |  | 308,465 |  |
| Goodwill | 297,968 |  |  | 267,458 |  |
| Other intangible assets, net | 148,225 |  |  | 100,997 |  |
| Deferred tax asset, net | 745,039 |  |  | 1,155,104 |  |
| Other long-term assets | 71,652 |  |  | 63,593 |  |
| Total assets | $ | 3,756,523 |  |  | $ | 3,951,711 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 340,582 |  |  | $ | 260,098 |  |
| Accrued liabilities and other short-term obligations | 340,075 |  |  | 322,934 |  |
| Deferred revenue | 111,134 |  |  | 102,418 |  |
| Current portion of long-term debt | 7,000 |  |  | 352,293 |  |
| Debt conversion liability | 164,212 |  |  | — |  |
| Total current liabilities | 963,003 |  |  | 1,037,743 |  |
| Long-term deferred revenue | 58,323 |  |  | 82,589 |  |
| Other long-term obligations | 119,413 |  |  | 111,349 |  |
| Long-term debt, net | 686,450 |  |  | 583,688 |  |
| Total liabilities | $ | 1,827,189 |  |  | $ | 1,815,369 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock — par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock — par value $0.01; 290,000,000 shares authorized; 154,318,531 and 143,043,227 shares issued and outstanding | 1,543 |  |  | 1,430 |  |
| Additional paid-in capital | 6,881,223 |  |  | 6,810,182 |  |
| Accumulated other comprehensive loss | (5,780 | ) |  | (11,017 | ) |
| Accumulated deficit | (4,947,652 | ) |  | (4,664,253 | ) |
| Total stockholders’ equity | 1,929,334 |  |  | 2,136,342 |  |
| Total liabilities and stockholders’ equity | $ | 3,756,523 |  |  | $ | 3,951,711 |  |

[0000936395-18-000043:8k_2_02:61]
CIENA CORPORATION

[0000936395-18-000043:8k_2_02:62]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-18-000043:8k_2_02:63]
(in thousands)

[0000936395-18-000043:8k_2_02:64]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |
| Cash flows from operating activities: |  |  |  |
| Net income (loss) | $ | (344,690 | ) |  | $ | 1,261,953 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Loss on extinguishment of debt | 10,039 |  |  | — |  |
| Loss on fair value of debt conversion liability | 12,070 |  |  | — |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 84,214 |  |  | 77,189 |  |
| Share-based compensation costs | 52,972 |  |  | 48,360 |  |
| Amortization of intangible assets | 25,806 |  |  | 45,713 |  |
| Deferred taxes | 463,631 |  |  | (1,126,732 | ) |
| Provision for doubtful accounts | 2,700 |  |  | 18,221 |  |
| Provision for inventory excess and obsolescence | 30,615 |  |  | 35,459 |  |
| Provision for warranty | 20,992 |  |  | 7,965 |  |
| Other | 21,685 |  |  | 22,417 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (168,357 | ) |  | (66,123 | ) |
| Inventories | (27,445 | ) |  | (91,567 | ) |
| Prepaid expenses and other | (21,425 | ) |  | (33,834 | ) |
| Accounts payable, accruals and other obligations | 85,798 |  |  | 33,897 |  |
| Deferred revenue | (19,344 | ) |  | 1,964 |  |
| Net cash provided by operating activities | 229,261 |  |  | 234,882 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (67,616 | ) |  | (94,600 | ) |
| Restricted cash | 117 |  |  | (54 | ) |
| Purchase of available for sale securities | (286,824 | ) |  | (299,038 | ) |
| Proceeds from maturities of available for sale securities | 410,109 |  |  | 335,075 |  |
| Settlement of foreign currency forward contracts, net | 9,385 |  |  | (2,810 | ) |
| Purchase of cost method investment | (1,767 | ) |  | — |  |
| Acquisition of businesses, net of cash acquired | (82,670 | ) |  | — |  |
| Net cash used in investing activities | (19,266 | ) |  | (61,427 | ) |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of long-term debt, net | 305,125 |  |  | — |  |
| Payment of long-term debt | (292,730 | ) |  | (233,554 | ) |
| Payment for make-whole provision upon conversion of long-term debt | (13,453 | ) |  | — |  |
| Payment for modification of term loans | — |  |  | (93,625 | ) |
| Payment of debt issuance costs | (1,936 | ) |  | (722 | ) |
| Payment of capital lease obligations | (3,624 | ) |  | (3,562 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units | (4,757 | ) |  | — |  |
| Repurchases of common stock-repurchase program | (110,981 | ) |  | — |  |
| Proceeds from issuance of common stock | 23,127 |  |  | 20,412 |  |
| Net cash used in financing activities | (99,229 | ) |  | (311,051 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (5,856 | ) |  | 494 |  |
| Net increase (decrease) in cash and cash equivalents | 104,910 |  |  | (137,102 | ) |
| Cash and cash equivalents at beginning of fiscal year | 640,513 |  |  | 777,615 |  |
| Cash and cash equivalents at end of fiscal year | $ | 745,423 |  |  | $ | 640,513 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the fiscal year for interest | $ | 44,750 |  |  | $ | 47,235 |  |
| Cash paid during the fiscal year for income taxes, net | $ | 26,900 |  |  | $ | 22,136 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 5,118 |  |  | $ | 6,214 |  |
| Building subject to capital lease | $ | — |  |  | $ | 50,370 |  |
| Contingent consideration for acquisition of business | $ | 10,900 |  |  | $ | — |  |
| Conversion of 3.75% convertible senior notes, due October 15, 2018 (Original) into 3,038,208 shares of common stock | $ | 61,270 |  |  | $ | — |  |
| Conversion of 4.0% convertible senior notes, due December 15, 2020 into 9,197,943 shares of common stock, net | $ | 214,286 |  |  | $ | — |  |

[0000936395-18-000043:8k_2_02:65]
| APPENDIX A- Reconciliation of Adjusted (Non- GAAP) Measurements (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, |  | October 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 398,075 |  |  | $ | 325,685 |  |  | $ | 1,314,690 |  |  | $ | 1,245,786 |  |
| Share-based compensation-products |  | 705 |  |  | 694 |  |  | 2,984 |  |  | 2,672 |  |
| Share-based compensation-services |  | 651 |  |  | 561 |  |  | 2,616 |  |  | 2,487 |  |
| Amortization of intangible assets |  | 2,957 |  |  | 2,332 |  |  | 10,069 |  |  | 12,685 |  |
| Total adjustments related to gross profit |  | 4,313 |  |  | 3,587 |  |  | 15,669 |  |  | 17,844 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 402,388 |  |  | $ | 329,272 |  |  | $ | 1,330,359 |  |  | $ | 1,263,630 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 44.7 | % |  | 44.2 | % |  | 43.0 | % |  | 45.1 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 302,205 |  |  | $ | 269,886 |  |  | $ | 1,084,744 |  |  | $ | 1,031,064 |  |
| Share-based compensation-research and development |  | 3,385 |  |  | 2,956 |  |  | 13,518 |  |  | 12,957 |  |
| Share-based compensation-sales and marketing |  | 3,741 |  |  | 3,218 |  |  | 14,246 |  |  | 12,846 |  |
| Share-based compensation-general and administrative |  | 5,588 |  |  | 4,130 |  |  | 19,709 |  |  | 17,321 |  |
| Amortization of intangible assets |  | 4,654 |  |  | 3,661 |  |  | 15,737 |  |  | 33,029 |  |
| Acquisition and integration costs |  | 3,778 |  |  | — |  |  | 5,111 |  |  | — |  |
| Significant asset impairments and restructuring costs |  | 1,460 |  |  | 15,059 |  |  | 18,139 |  |  | 23,933 |  |
| Legal settlements |  | 1,929 |  |  | — |  |  | 4,682 |  |  | — |  |
| Total adjustments related to operating expense |  | $ | 24,535 |  |  | $ | 29,024 |  |  | $ | 91,142 |  |  | $ | 100,086 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 277,670 |  |  | $ | 240,862 |  |  | $ | 993,602 |  |  | $ | 930,978 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 95,870 |  |  | $ | 55,799 |  |  | $ | 229,946 |  |  | $ | 214,722 |  |
| Total adjustments related to gross profit |  | 4,313 |  |  | 3,587 |  |  | 15,669 |  |  | 17,844 |  |
| Total adjustments related to operating expense |  | 24,535 |  |  | 29,024 |  |  | 91,142 |  |  | 100,086 |  |
| Total adjustments related to income from operations |  | 28,848 |  |  | 32,611 |  |  | 106,811 |  |  | 117,930 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 124,718 |  |  | $ | 88,410 |  |  | $ | 336,757 |  |  | $ | 332,652 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 13.9 | % |  | 11.9 | % |  | 10.9 | % |  | 11.9 | % |

[0000936395-18-000043:8k_2_02:66]
| APPENDIX A- Reconciliation of Adjusted (Non- GAAP) Measurements (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, |  | October 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net Income (Loss) Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | 63,977 |  |  | $ | 1,160,056 |  |  | $ | (344,690 | ) |  | $ | 1,261,953 |  |
| Exclude GAAP provision (benefit) for income taxes |  | (10,224 | ) |  | (1,117,531 | ) |  | 493,471 |  |  | (1,105,827 | ) |
| Income before income taxes |  | 53,753 |  |  | 42,525 |  |  | 148,781 |  |  | 156,126 |  |
| Total adjustments related to income from operations |  | 28,848 |  |  | 32,611 |  |  | 106,811 |  |  | 117,930 |  |
| Loss on extinguishment and modification of debt |  | 13,887 |  |  | 692 |  |  | 13,887 |  |  | 3,657 |  |
| Non-cash interest expense |  | 727 |  |  | 525 |  |  | 2,579 |  |  | 2,099 |  |
| Change in fair value of debt conversion liability |  | 12,070 |  |  | — |  |  | 12,070 |  |  | — |  |
| Adjusted income before income taxes |  | 109,285 |  |  | 76,353 |  |  | 284,128 |  |  | 279,812 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 28,272 |  |  | 27,869 |  |  | 73,504 |  |  | 102,131 |  |
| Adjusted (non-GAAP) net income |  | $ | 81,013 |  |  | $ | 48,484 |  |  | $ | 210,624 |  |  | $ | 177,681 |  |
| Weighted average basic common shares outstanding |  | 143,659 |  |  | 143,097 |  |  | 143,738 |  |  | 141,997 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 157,745 |  |  | 158,791 |  |  | 158,884 |  |  | 169,919 |  |
| Net Income (Loss) per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income (loss) per common share |  | $ | 0.34 |  |  | $ | 7.32 |  |  | $ | (2.49 | ) |  | $ | 7.53 |  |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.53 |  |  | $ | 0.32 |  |  | $ | 1.39 |  |  | $ | 1.14 |  |

[0000936395-18-000043:8k_2_02:67]
1.  Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2018 includes 2.0 million shares underlying certain stock option and stock unit awards, 0.7 million and 2.5 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018, and 8.9 million shares underlying Ciena's 4.0% convertible senior notes, which were converted at Ciena's election during the fourth quarter of fiscal 2018.

[0000936395-18-000043:8k_2_02:68]
Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for fiscal 2018 includes 1.4 million shares underlying certain stock option and stock unit awards, 1.8 million and 2.9 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, and 9.1 million shares underlying Ciena's 4.0% convertible senior notes.

[0000936395-18-000043:8k_2_02:69]
Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2017 includes 1.2 million shares underlying certain stock option and stock unit awards, 1.6 million and 3.7 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, and 9.2 million shares underlying Ciena's 4.0% convertible senior notes.

[0000936395-18-000043:8k_2_02:70]
Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for fiscal 2017 includes 1.4 million shares underlying certain stock option and stock unit awards, 0.4 million and 13.9 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, 3.0 million shares underlying Ciena's 0.875% convertible senior notes and 9.2 million shares underlying Ciena's 4.0% convertible senior notes.

[0000936395-18-000043:8k_2_02:71]
2.  The calculation of adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2018 requires adding back interest expense of approximately $0.4 million associated with Ciena's "Original" 3.75% convertible senior notes and approximately $2.3 million associated with Ciena's 4.0% convertible senior notes to the adjusted (non-GAAP) net income in order to derive the numerator for the adjusted (non-GAAP) earnings per common share calculation.

[0000936395-18-000043:8k_2_02:72]
The calculation of adjusted (non-GAAP) diluted net income per common share for fiscal 2018 requires adding back interest expense of  approximately $1.8 million associated with Ciena's "Original" 3.75% convertible senior notes and approximately $8.7 million associated with

[0000936395-18-000043:8k_2_02:73]
Ciena's 4.0% convertible senior notes to the adjusted (non-GAAP) net income in order to derive the numerator for the adjusted (non-GAAP) earnings per common share calculation.

[0000936395-18-000043:8k_2_02:74]
The calculation of adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2017 requires adding back interest expense of approximately $0.4 million associated with Ciena's "Original" 3.75% convertible senior notes and approximately $1.9 million associated with Ciena's 4.0% convertible senior notes to the adjusted (non-GAAP) net income in order to derive the numerator for the adjusted (non-GAAP) earnings per common share calculation.

[0000936395-18-000043:8k_2_02:75]
The calculation of adjusted (non-GAAP) diluted net income per common share for fiscal 2017 requires adding back interest expense of  approximately $0.9 million associated with Ciena's 0.875% convertible senior notes, approximately $7.2 million associated with Ciena's "Original" 3.75% convertible senior notes and approximately $7.4 million associated with Ciena's 4.0% convertible senior notes to the adjusted (non-GAAP) net income in order to derive the numerator for the adjusted (non-GAAP) earnings per common share calculation.

[0000936395-18-000043:8k_2_02:76]
| APPENDIX B- Calculation of EBITDA and Adjusted EBITDA (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, |  | October 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (loss) (GAAP) |  | $ | 63,977 |  |  | $ | 1,160,056 |  |  | $ | (344,690 | ) |  | $ | 1,261,953 |  |
| Add: Interest expense |  | 14,873 |  |  | 13,926 |  |  | 55,249 |  |  | 55,852 |  |
| Less: Interest and other income (loss), net |  | (13,357 | ) |  | 1,344 |  |  | (12,029 | ) |  | 913 |  |
| Add: Loss on extinguishment and modification of debt |  | (13,887 | ) |  | (692 | ) |  | (13,887 | ) |  | (3,657 | ) |
| Add: Provision (benefit) for income taxes |  | (10,224 | ) |  | (1,117,531 | ) |  | 493,471 |  |  | (1,105,827 | ) |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 21,110 |  |  | 21,316 |  |  | 84,214 |  |  | 77,189 |  |
| Add: Amortization of intangible assets |  | 7,611 |  |  | 5,993 |  |  | 25,806 |  |  | 45,713 |  |
| EBITDA |  | 124,591 |  |  | 83,108 |  |  | 339,966 |  |  | 337,624 |  |
| Add: Shared-based compensation cost |  | 14,076 |  |  | 11,517 |  |  | 52,972 |  |  | 48,360 |  |
| Add: Significant asset impairments and restructuring costs |  | 1,460 |  |  | 15,059 |  |  | 18,139 |  |  | 23,933 |  |
| Add: Acquisition and integration costs |  | 3,778 |  |  | — |  |  | 5,111 |  |  | — |  |
| Add: Legal settlement |  | 1,929 |  |  | — |  |  | 4,682 |  |  | — |  |
| Adjusted EBITDA |  | 145,834 |  |  | 109,684 |  |  | 420,870 |  |  | 409,917 |  |

[0000936395-18-000043:8k_2_02:77]
* * *

[0000936395-18-000043:8k_2_02:78]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-18-000043:8k_2_02:79]
| • | Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-18-000043:8k_2_02:80]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-18-000043:8k_2_02:81]
| • | Acquisition and integration costs - consist of financial, legal and accounting advisors' costs and severance and other employment-related costs related to Ciena's acquisition of Packet Design and DonRiver. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-18-000043:8k_2_02:82]
| • | Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities and in fiscal 2017, a significant asset impairment for a trade receivable for a customer in the Asia Pacific region. |

[0000936395-18-000043:8k_2_02:83]
| • | Legal settlements - costs incurred as a result of settlements, during the third quarter of fiscal 2018, of a commercial dispute with a former vendor, and during the fourth quarter of fiscal 2018, of securities class action suit relating the initial public offering of Cyan. |

[0000936395-18-000043:8k_2_02:84]
| • | Loss on extinguishment and modification of debt - reflects extinguishment of debt costs related to our conversion of Ciena's 4.0% convertible senior notes and debt modification expenses related to refinancing our then existing term loan, both of which occurred during the fourth quarter of fiscal 2018. For fiscal 2017, this reflects debt modification expenses related to our then existing term loans that were refinanced during the second quarter of fiscal 2017, the exchange offer of Ciena's "Original" 3.75% convertible senior notes and extinguishment of debt losses related to certain private repurchase transactions during fiscal 2017 of Ciena's then outstanding 0.875% convertible senior notes. |

[0000936395-18-000043:8k_2_02:85]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes, which were converted during the fourth quarter of 2018, relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-18-000043:8k_2_02:86]
| • | Change in fair value of debt conversion liability - a non-cash loss reflective of a mark to market fair value adjustment related to the outstanding conversion feature of Ciena's "New" 3.75% senior convertible notes. |

[0000936395-18-000043:8k_2_02:87]
| • | Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 25.87% for the fourth fiscal quarter of 2018, and 36.5% for the fourth fiscal quarter of 2017. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. |
