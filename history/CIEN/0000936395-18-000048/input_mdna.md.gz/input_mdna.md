# CIEN MD&A — 0000936395-18-000048


## mdna

[0000936395-18-000048:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-18-000048:mdna:2]
The following discussion and analysis should be read in conjunction with our “Selected Consolidated Financial Data” and consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-18-000048:mdna:3]
Overview

[0000936395-18-000048:mdna:4]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide network hardware, software and services that support the transport, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Our solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions and other emerging network operators.

[0000936395-18-000048:mdna:5]
Our solutions include a diverse portfolio of high-capacity Networking Platform products, which can be applied from the network core to network access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. We also offer Platform Software that provides management and domain control of our next-generation packet and optical platforms and automates network lifecycle operations including provisioning equipment and services. In addition, through our comprehensive suite of Blue Planet Automation Software, we enable network operators to use network data and analytics to drive enhanced automation across multi-vendor and multi-domain network environments, accelerate service delivery and enable an increasingly predictive and autonomous network infrastructure. To complement our hardware and software solutions, we offer a broad range of attached and software-related services that help our customers design, optimize, integrate, deploy, manage and maintain their networks and associated operational environments. Through our complete portfolio of solutions, we enable our customers to transform their network into a dynamic, programmable environment driven by automation and analytics, which we refer to as the Adaptive Network. Our solutions for the Adaptive Network create business and operational value for our customers, enabling them to introduce new revenue-generating services, reduce costs and maximize the return on their network infrastructure investment.

[0000936395-18-000048:mdna:6]
Market Opportunity

[0000936395-18-000048:mdna:7]
The markets in which we sell our communications networking solutions have seen significant changes in recent years, including rapid growth in bandwidth demand, proliferation of cloud-based services and heightened end-user service demands. We have also seen the impact of Web-scale network operators and their services on the business models and network infrastructures of communication service providers. These conditions have placed significant demands on networks and altered the overall competitive landscape of network operators. Existing and emerging network operators are competing to distinguish their service offerings and rapidly introduce differentiated, revenue-generating services, while managing the costs of their networks and seeking to ensure a profitable business model.  Network operators are under pressure to constrain their capital expenditure budgets and cannot grow their network spending at the rate of bandwidth growth.  As a result, the markets in which we operate expect new and more robust solutions that increase capacity or features and that are more cost-effective to operate. We believe that these dynamics, and the need to adapt to rapidly changing business and network demands, will cause network operators to leverage increased software-based network control and programmability and to evolve their infrastructures to be more automated.

[0000936395-18-000048:mdna:8]
Our Adaptive Network vision and our business strategy to capitalize on these market dynamics include the initiatives set forth in the “Strategy” section of the description of our business in Item 1 of Part 1 of this annual report.

[0000936395-18-000048:mdna:9]
Revenue Growth and Diversification of our Business During Fiscal 2018

[0000936395-18-000048:mdna:10]
During fiscal 2018, our revenue growth accelerated as we benefited meaningfully from our innovation leadership, the diversification of our business and efforts to take market share from competitors. We continue to diversify our solutions offerings and customer base to address fast-growing applications and customer segments, such as Web-scale providers and data center interconnection. These customers were important contributors to our overall growth during fiscal 2018 and are included among our largest customers by revenue. At the same time, a significant portion of our revenue and customer base continues to consist of sales to large communication service providers and cable operators. Our revenue growth benefited from a go-to-market strategy focused on generating new wins and capturing additional opportunities with service providers in international markets, particularly in our Asia-Pacific and India regions. We believe that continued diversification of our business is important to address the dynamic industry environment in which we operate, to continue to grow our business, and to better

[0000936395-18-000048:mdna:11]
withstand potential slowdowns which could adversely affect demand from particular geographies, markets, customers or customer segments.

[0000936395-18-000048:mdna:12]
We also believe that current market and competitive dynamics create opportunities for us to leverage our technology leadership and competitive position to displace competitors and capture additional market share. This strategy of share capture was an important contributor to our overall revenue growth during fiscal 2018, and it resulted in, and may continue to result in, fluctuations or reductions in our gross margin.

[0000936395-18-000048:mdna:13]
Investment in Blue Planet Automation Software Platform

[0000936395-18-000048:mdna:14]
We have continued to pursue both organic investment to pursue opportunities in the software automation market and acquisition opportunities to expand our software portfolio and business. On October 1, 2018, we acquired DonRiver Holdings, LLC (“DonRiver”), a global software and services company specializing in federated network and service inventory management solutions within the service provider Operational Support Systems (OSS) environment. On July 2, 2018, we acquired Packet Design, LLC (“Packet Design”), a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics.

[0000936395-18-000048:mdna:15]
Balance Sheet Initiatives

[0000936395-18-000048:mdna:16]
Our cash balance and level of indebtedness were influenced by a number of balance sheet initiatives during fiscal 2018, which included the following.

[0000936395-18-000048:mdna:17]
Increased Stock Repurchase Program. During fiscal 2018, we repurchased $111.0 million of our common stock under a stock repurchase program. On December 13, 2018, we announced that our Board of Directors authorized a new program to repurchase up to $500 million of our common stock. This program replaces our previously authorized repurchase program, under which we were authorized to repurchase up to $300 million of our common stock through the end of fiscal 2020. We may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. We may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. For additional information, including our repurchase activities under the previously authorized program, see Note 19 and Note 25 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 5 of Part II of this annual report.

[0000936395-18-000048:mdna:18]
Issuer Conversion of 4.0% Convertible Senior Notes due December 15, 2020 (“2020 Notes”). On October 31, 2018, we exercised our option to convert the $187.5 million principal amount outstanding of our 2020 Notes into shares of Ciena common stock. In connection with this conversion, we issued approximately 9.2 million shares and the 2020 Notes ceased to be outstanding. In accordance with the "make-whole" provision, note holders were also entitled to certain additional shares of Ciena common stock upon conversion. We elected to deliver cash in lieu of these additional shares. The amount of cash in lieu of the additional shares was approximately $13.5 million, which was also paid on October 31, 2018. See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information relating to our 2020 Notes.

[0000936395-18-000048:mdna:19]
Settlement Upon Conversion of 3.75% Convertible Senior Notes due October 15, 2018. On October 15, 2018, both our 3.75% Convertible Senior Notes due October 15, 2018 (Original) (the “Original Notes”) and our 3.75% Convertible Senior Notes due October 15, 2018 (New) (the “New Notes”) matured. Following conversion elections by the holders thereof, the outstanding Original Notes were converted in advance of maturity on October 15, 2018 and we issued approximately 3.0 million shares of Ciena common stock in settlement of such conversion. The Original Notes thereafter ceased to be outstanding. During the fourth quarter of fiscal 2018, we elected to settle conversion of the New Notes in a combination of cash and shares, provided that the cash portion would not exceed an aggregate amount of approximately $400 million. Upon conversion of the New Notes by the holders in advance of maturity, on October 15, 2018, we paid in cash an amount of $288.7 million representing the aggregate principal amount outstanding of the New Notes. The New Notes thereafter ceased to be outstanding. In addition, because Ciena common stock traded in excess of the $20.17 per share conversion price during an observation period from October 15, 2018 through November 9, 2018, on November 15, 2018, we paid an additional $111.3 million in cash and issued approximately 1.6 million shares with respect to the “in the money” portion of the notes in settlement of the conversion. See Notes 14 and 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information relating to our Original Notes and New Notes.

[0000936395-18-000048:mdna:20]
Term Loan Refinancing. On September 28, 2018, we refinanced our existing term loan in the aggregate principal amount of $394 million, maturing on January 30, 2022 (the “2022 Term Loan”) into a term loan with an aggregate principal amount of $700 million maturing on September 28, 2025 (the “2025 Term Loan”). See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information relating to our term loan refinancing.

[0000936395-18-000048:mdna:21]
Impact of Tax Cuts and Jobs Act

[0000936395-18-000048:mdna:22]
Our results of operations for fiscal 2018 have been impacted by enactment of the Tax Cuts and Jobs Act (the “Tax Act”) in December 2017. Specifically, our results for fiscal 2018 include a $472.8 million tax charge consisting of the following:

[0000936395-18-000048:mdna:23]
| • | $438.2 million charge related to the remeasurement of U.S. net deferred tax assets at the lower statutory rate under the Tax Act; and |

[0000936395-18-000048:mdna:24]
| • | $34.6 million charge related to a transition tax on accumulated historical foreign earnings and its deemed repatriation to the U.S. |

[0000936395-18-000048:mdna:25]
See Note 20 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information related to the impact of the Tax Act.

[0000936395-18-000048:mdna:26]
42

[0000936395-18-000048:mdna:27]
Consolidated Results of Operations

[0000936395-18-000048:mdna:28]
Operating Segments

[0000936395-18-000048:mdna:29]
We have the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Software and Software-Related Services; and (iii) Global Services. As of the first quarter of fiscal 2018, sales of our Optical Transport products are reflected within the Converged Packet Optical product line of our Networking Platforms segment for all periods presented. See Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-18-000048:mdna:30]
Fiscal 2018 compared to Fiscal 2017

[0000936395-18-000048:mdna:31]
Revenue

[0000936395-18-000048:mdna:32]
During fiscal 2018, approximately 17.8% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Canadian Dollars, Japanese Yen, Brazilian Reais, Argentina Pesos, Indian Rupee and British Pounds. During fiscal 2018 as compared to fiscal 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars was slightly reduced by approximately $1.5 million, or 0.1%, net of hedging, as compared to fiscal 2017 due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-18-000048:mdna:33]
|  | Fiscal Year |  |  |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,194,519 |  |  | 70.9 |  | $ | 1,939,621 |  |  | 69.2 |  | $ | 254,898 |  |  | 13.1 |  |
| Packet Networking | 283,499 |  |  | 9.2 |  | 313,089 |  |  | 11.2 |  | (29,590 | ) |  | (9.5 | ) |
| Total Networking Platforms | 2,478,018 |  |  | 80.1 |  | 2,252,710 |  |  | 80.4 |  | 225,308 |  |  | 10.0 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 173,949 |  |  | 5.6 |  | 145,009 |  |  | 5.2 |  | 28,940 |  |  | 20.0 |  |
| Blue Planet Automation Software and Services | 26,764 |  |  | 0.9 |  | 16,110 |  |  | 0.6 |  | 10,654 |  |  | 66.1 |  |
| Total Software and Software-Related Services | 200,713 |  |  | 6.5 |  | 161,119 |  |  | 5.8 |  | 39,594 |  |  | 24.6 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 245,161 |  |  | 7.9 |  | 227,400 |  |  | 8.1 |  | 17,761 |  |  | 7.8 |  |
| Installation and Deployment | 128,829 |  |  | 4.2 |  | 117,524 |  |  | 4.2 |  | 11,305 |  |  | 9.6 |  |
| Consulting and Network Design | 41,565 |  |  | 1.3 |  | 42,934 |  |  | 1.5 |  | (1,369 | ) |  | (3.2 | ) |
| Total Global Services | 415,555 |  |  | 13.4 |  | 387,858 |  |  | 13.8 |  | 27,697 |  |  | 7.1 |  |
| Consolidated revenue | $ | 3,094,286 |  |  | 100.0 |  | $ | 2,801,687 |  |  | 100.0 |  | $ | 292,599 |  |  | 10.4 |  |

[0000936395-18-000048:mdna:34]
_________________________________

[0000936395-18-000048:mdna:35]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2017 to 2018 |

[0000936395-18-000048:mdna:36]
| • | Networking Platforms revenue increased, primarily reflecting a product line sales increase of $254.9 million of our Converged Packet Optical products, partially offset by a product line sales decrease of $29.6 million of our Packet Networking products. |

[0000936395-18-000048:mdna:37]
| ◦ | Converged Packet Optical primarily reflect sales increases of $252.8 million of our Waveserver stackable interconnect system and $68.9 million of our 6500 Packet-Optical Platform. These increases were partially |

[0000936395-18-000048:mdna:38]
offset by sales decreases of $51.6 million of our 5410/5430 Reconfigurable Switching Systems and $7.9 million of our Z-Series Packet-Optical Platform. Increased sales of our Waveserver stackable interconnect system were primarily to Web-scale providers for data center interconnection applications. As we continue to diversify our business, Web-scale providers represent a growing portion of our business and are included among our largest customers during fiscal 2018. Increased sales of our 6500 Packet-Optical Platform were primarily to communications service providers, Web-scale providers and enterprise customers, partially offset by decreased sales to AT&T, cable and multiservice operators, and government customers.

[0000936395-18-000048:mdna:39]
| ◦ | Packet Networking reflects a sales decrease of $51.5 million of our 3000 and 5000 families of our service delivery and aggregation switches, primarily related to reduced sales to AT&T. This decrease was partially offset by a sales increase of $16.3 million of our 8700 Packetwave Platform. |

[0000936395-18-000048:mdna:40]
| • | Software and Software-Related Services segment revenue increased, reflecting sales increases of $28.9 million of our Platform Software and Services and $10.7 million of our Blue Planet Automation Software and Services. |

[0000936395-18-000048:mdna:41]
| ◦ | Platform Software and Services primarily reflect sales increases of $19.2 million in sales of our software and $9.7 million in sales of our software-related services. These increases primarily reflect sales increases of $17.9 million of our Manage, Control and Plan (MCP) software and $7.3 million in sales of our software subscription services. |

[0000936395-18-000048:mdna:42]
| ◦ | Blue Planet Automation Software and Services primarily reflects sales increases of $8.4 million of services and $2.3 million of software. Increased services revenue primarily reflects increases of $3.3 million from professional services, $2.7 million in maintenance services and $1.4 million in professional services related to the Packet Design and DonRiver businesses acquired during fiscal 2018, respectively. |

[0000936395-18-000048:mdna:43]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $17.8 million of our maintenance support and training services and $11.3 million of our installation and deployment services. |

[0000936395-18-000048:mdna:44]
Our operating segments engage in business and operations across four geographic regions: North America; Europe, Middle East and Africa (“EMEA”); Caribbean and Latin America (“CALA”); and Asia Pacific and India (“APAC”). Results for North America include only activities in the U.S. and Canada. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-18-000048:mdna:45]
|  | Fiscal Year |  |  |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | Increase(decrease) |  | %** |
| North America | $ | 1,886,450 |  |  | 61.0 |  | $ | 1,736,047 |  |  | 62.0 |  | $ | 150,403 |  |  | 8.7 |  |
| EMEA | 464,876 |  |  | 15.0 |  | 404,099 |  |  | 14.4 |  | 60,777 |  |  | 15.0 |  |
| CALA | 140,177 |  |  | 4.5 |  | 164,308 |  |  | 5.9 |  | (24,131 | ) |  | (14.7 | ) |
| APAC | 602,783 |  |  | 19.5 |  | 497,233 |  |  | 17.7 |  | 105,550 |  |  | 21.2 |  |
| Total | $ | 3,094,286 |  |  | 100.0 |  | $ | 2,801,687 |  |  | 100.0 |  | $ | 292,599 |  |  | 10.4 |  |

[0000936395-18-000048:mdna:46]
_________________________________

[0000936395-18-000048:mdna:47]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2017 to 2018 |

[0000936395-18-000048:mdna:48]
| • | North America revenue primarily reflects sales increases of $112.4 million within our Networking Platforms segment, $29.6 million within our Software and Software-Related Services segment and $8.4 million within our Global Services segment. North America revenue reflects, in part, an annual decline in sales to AT&T from $448.9 million in fiscal 2017 to $374.6 million in fiscal 2018, as set forth below. |

[0000936395-18-000048:mdna:49]
| ◦ | Networking Platforms segment revenue primarily reflects a product line increase of $150.5 million of Converged Packet Optical sales, partially offset by a product line decrease of $38.1 million of Packet Networking sales. Converged Packet Optical sales reflect an increase of $205.9 million in sales of our Waveserver stackable interconnect system primarily to Web-scale providers, partially offset by a $48.6 |

[0000936395-18-000048:mdna:50]
44

[0000936395-18-000048:mdna:51]
million decrease in sales of our 6500 Packet-Optical Platform, primarily reflecting decreased sales to AT&T, cable and multiservice operators and government customers. Packet Networking sales reflect a decrease of $45.5 million in sales of our 3000 and 5000 families of service delivery and aggregation switches, primarily related to reduced sales to AT&T.

[0000936395-18-000048:mdna:52]
| ◦ | Software and Software-Related Services segment revenue primarily reflects sales increases of $20.3 million of our Platform Software and Services and $9.2 million of our Blue Planet Automation Software and Services. Platform Software and Services sales reflect increases of $15.2 million in platform software and $5.1 million in software-related services. These increases primarily reflect sales increases $17.0 million of our Manage, Control and Plan (MCP) software, $3.3 million of software subscription services and $1.5 million of our software training services. Blue Planet Automation Software and Services sales primarily reflect increases of $5.7 million of services and $3.4 million of software. |

[0000936395-18-000048:mdna:53]
| ◦ | Global Services segment revenue primarily reflects sales increases of $6.0 million of our maintenance support and training services and $2.9 million of our installation and deployment services. |

[0000936395-18-000048:mdna:54]
| • | EMEA revenue primarily reflects sales increases of $49.2 million within our Networking Platforms segment, $9.8 million within our Global Services segment and $1.8 million within our Software and Software-Related Services segment. |

[0000936395-18-000048:mdna:55]
| ◦ | Networking Platforms segment revenue primarily reflects a product line increase of $53.0 million in Converged Packet Optical sales, partially offset by a product line decrease of $3.9 million in Packet Networking sales. Converged Packet Optical reflects increases of $32.5 million in sales of our Waveserver stackable interconnect system primarily to Web-scale providers and $22.4 million in sales of our 6500 Packet-Optical Platform to communications service providers, Web-scale providers and enterprise customers. |

[0000936395-18-000048:mdna:56]
| ◦ | Global Services segment revenue primarily reflects sales increases of $8.5 million of our maintenance and training support services and $1.6 million of our installation and deployment services, primarily to communications service providers. |

[0000936395-18-000048:mdna:57]
| • | CALA revenue primarily reflects decreases of $23.3 million within our Networking Platforms segment and $2.9 million within our Global Services segment. These decreases were partially offset by a revenue increase of $2.1 million within our Software and Software-Related Services segment. The decrease in CALA revenue primarily relates to decreased sales to a cable and multiservice operator in Argentina and communications service providers in Brazil. |

[0000936395-18-000048:mdna:58]
| • | APAC revenue primarily reflects sales increases of $87.0 million within our Networking Platforms segment, $12.4 million within our Global Services segment and $6.1 million within our Software and Software-Related Services segment, primarily reflecting increased sales in Japan and India. |

[0000936395-18-000048:mdna:59]
| ◦ | Networking Platforms segment revenue primarily reflects product line increases of $72.0 million in Converged Packet Optical sales and $15.0 million of Packet Networking sales. Converged Packet Optical sales reflect sales increases of $114.2 million in sales of our 6500 Packet-Optical Platform to communications service providers and $9.1 million in sales of our Waveserver stackable interconnect system to communications service providers, Web-scale providers and government customers. These increases were partially offset by a $47.0 million decrease in sales of our 5410/5430 Reconfigurable Switching Systems, reflecting decreased sales to certain communications service providers. Packet Networking sales primarily reflect sales increases of $13.1 million in sales of our 8700 Packetwave Platform and $1.9 million in sales of our 3000 and 5000 families of service delivery and aggregation switches, primarily to a certain communication service provider in India. |

[0000936395-18-000048:mdna:60]
| ◦ | Software and Software-Related Services segment revenue primarily reflects sales increases of $4.8 million of our Platform Software and Services and $1.3 million of our Blue Planet Automation Software and Services. |

[0000936395-18-000048:mdna:61]
| ◦ | Global Services segment revenue primarily reflects increases of $9.5 million in sales of installation and deployment services and $3.6 million in our maintenance and training support services. |

[0000936395-18-000048:mdna:62]
In fiscal 2018 and fiscal 2017, our top ten customers contributed 56.5% and 55.6% of revenue, respectively. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can be significantly affected by market, industry or competitive dynamics affecting their businesses. Our reliance upon a relatively small number of customers also increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations, and our results of operations can fluctuate quarterly depending upon sales volumes and purchasing priorities with these large customers. Sales to

[0000936395-18-000048:mdna:63]
AT&T were $374.6 million, or 12.1% of total revenue in fiscal 2018, and $448.9 million, or 16.0% of total revenue in fiscal 2017. Verizon accounted for $318.0 million or 10.3% of total revenue for fiscal 2018 and $288.0 million, or 10.3% of total revenue in fiscal 2017. No other customer accounted for greater than 10% of our revenue in fiscal 2018 or fiscal 2017. While drivers of bandwidth growth and network evolution remain strong, our customers are under constant pressure to constrain their capital expenditure budgets and cannot grow their network spending at the rate of bandwidth growth. As a result, as we innovate and introduce new and more robust solutions that increase capacity or features, there is a market expectation of solutions that are more cost-effective from price for performance perspective than existing or competing solutions. The combination of this regular technology-driven price compression, price competition and pricing pressure in our markets and ongoing customer efforts to manage network costs can impact growth rates in our markets, and requires that we increase our volume of product shipments to maintain and grow revenue

[0000936395-18-000048:mdna:64]
Cost of Goods Sold and Gross Profit

[0000936395-18-000048:mdna:65]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-18-000048:mdna:66]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-18-000048:mdna:67]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending upon our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative to the price erosion that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. When we have success in taking share and winning new business, it can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers adding capacity or services to their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-18-000048:mdna:68]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-18-000048:mdna:69]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-18-000048:mdna:70]
|  | Fiscal Year |  |  |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 3,094,286 |  |  | 100.0 |  | $ | 2,801,687 |  |  | 100.0 |  | $ | 292,599 |  |  | 10.4 |
| Total cost of goods sold | 1,779,596 |  |  | 57.5 |  | 1,555,901 |  |  | 55.5 |  | 223,695 |  |  | 14.4 |
| Gross profit | $ | 1,314,690 |  |  | 42.5 |  | $ | 1,245,786 |  |  | 44.5 |  | $ | 68,904 |  |  | 5.5 |

[0000936395-18-000048:mdna:71]
_________________________________

[0000936395-18-000048:mdna:72]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2017 to 2018 |

[0000936395-18-000048:mdna:73]
|  | Fiscal Year |  |  |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,565,460 |  |  | 100.0 |  | $ | 2,318,581 |  |  | 100.0 |  | $ | 246,879 |  |  | 10.6 |
| Product cost of goods sold | 1,507,157 |  |  | 58.7 |  | 1,308,295 |  |  | 56.4 |  | 198,862 |  |  | 15.2 |
| Product gross profit | $ | 1,058,303 |  |  | 41.3 |  | $ | 1,010,286 |  |  | 43.6 |  | $ | 48,017 |  |  | 4.8 |

[0000936395-18-000048:mdna:74]
_________________________________

[0000936395-18-000048:mdna:75]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2017 to 2018 |

[0000936395-18-000048:mdna:76]
|  | Fiscal Year |  |  |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 528,826 |  |  | 100.0 |  | $ | 483,106 |  |  | 100.0 |  | $ | 45,720 |  |  | 9.5 |
| Service cost of goods sold | 272,439 |  |  | 51.5 |  | 247,606 |  |  | 51.3 |  | 24,833 |  |  | 10.0 |
| Service gross profit | $ | 256,387 |  |  | 48.5 |  | $ | 235,500 |  |  | 48.7 |  | $ | 20,887 |  |  | 8.9 |

[0000936395-18-000048:mdna:77]
_________________________________

[0000936395-18-000048:mdna:78]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2017 to 2018 |

[0000936395-18-000048:mdna:79]
| • | Gross profit as a percentage of revenue, or gross margin reflects reduced product and service gross profits as described below. We encountered fluctuations or reductions in our gross margin during fiscal 2018 as a result of our strategy to leverage our technology leadership and to aggressively capture additional market share and displace competitors, particularly with communications service providers internationally. We were successful in executing our strategy during fiscal 2018, which allowed us to achieve meaningful revenue growth but which adversely impacted gross margins. Our continued success in implementing this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, and result in an increased mix of revenues from early stage deployments, any or all of which may result in low or negative gross margins on a particular order or group of orders. |

[0000936395-18-000048:mdna:80]
| • | Gross profit on products as a percentage of product revenue, or product gross margin, decreased primarily as a result of our strategy to capture market share as described above and the impact of early stages of international network deployments with communications service provider customers, including an increased concentration of lower margin “common” equipment sales and lower mix of higher margin packet networking sales, partially offset by increased sales of our higher margin software platforms and product cost reductions. |

[0000936395-18-000048:mdna:81]
| • | Gross profit on services as a percentage of services revenue, or services gross margin, decreased slightly, primarily as a result of reduced margins on our software services, which was primarily due to increased costs related to developing resources to promote our growth strategy. |

[0000936395-18-000048:mdna:82]
Operating Expense

[0000936395-18-000048:mdna:83]
Operating expense increased in fiscal 2018 from the level reported for fiscal 2017 primarily due to increased research and development initiatives and increased selling and marketing resources.

[0000936395-18-000048:mdna:84]
Operating expense consists of the component elements described below.

[0000936395-18-000048:mdna:85]
| • | Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense and third-party consulting costs. |

[0000936395-18-000048:mdna:86]
| • | Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense and third-party consulting costs. |

[0000936395-18-000048:mdna:87]
47

[0000936395-18-000048:mdna:88]
| • | General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services. |

[0000936395-18-000048:mdna:89]
| • | Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions. |

[0000936395-18-000048:mdna:90]
| • | Acquisition and integration costs consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs associated with our acquisition of Packet Design on July 2, 2018 and DonRiver on October 1, 2018. For more information on our acquisitions, see Note 2 to our Consolidated Financial Statements included in Item 8 of Part II of this report. |

[0000936395-18-000048:mdna:91]
| • | Significant asset impairments and restructuring costs primarily reflect actions we have taken to better align our workforce, facilities and operating costs with perceived market opportunities, business strategies, changes in market and business conditions and significant impairments of assets. |

[0000936395-18-000048:mdna:92]
During fiscal 2018, approximately 52.6% of our operating expense was non-U.S. Dollar denominated, including expenses in Canadian Dollars, British Pounds, Indian Rupees, Euros, Brazilian Reais and Australian Dollars. During fiscal 2018 as compared to fiscal 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense reported in U.S. Dollars increased by approximately $9.7 million, or 0.9%, as compared to fiscal 2017 due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-18-000048:mdna:93]
|  | Fiscal Year |  |  |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 491,564 |  |  | 15.9 |  | $ | 475,329 |  |  | 17.0 |  | $ | 16,235 |  |  | 3.4 |  |
| Selling and marketing | 394,060 |  |  | 12.7 |  | 356,169 |  |  | 12.7 |  | 37,891 |  |  | 10.6 |  |
| General and administrative | 160,133 |  |  | 5.2 |  | 142,604 |  |  | 5.1 |  | 17,529 |  |  | 12.3 |  |
| Amortization of intangible assets | 15,737 |  |  | 0.5 |  | 33,029 |  |  | 1.2 |  | (17,292 | ) |  | (52.4 | ) |
| Acquisition and integration costs | 5,111 |  |  | 0.2 |  | — |  |  | — |  | 5,111 |  |  | 100.0 |  |
| Significant asset impairments and restructuring costs | 18,139 |  |  | 0.6 |  | 23,933 |  |  | 0.9 |  | (5,794 | ) |  | (24.2 | ) |
| Total operating expenses | $ | 1,084,744 |  |  | 35.1 |  | $ | 1,031,064 |  |  | 36.9 |  | $ | 53,680 |  |  | 5.2 |  |

[0000936395-18-000048:mdna:94]
_________________________________

[0000936395-18-000048:mdna:95]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2017 to 2018 |

[0000936395-18-000048:mdna:96]
| • | Research and development expense was adversely affected by $5.1 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $16.2 million. This increase primarily reflects increases of $21.7 million in employee and compensation costs, $4.5 million in technology and related costs, $3.2 million in professional services and $1.3 million in depreciation expense. These increases were partially offset by a benefit of $13.6 million for the ENCQOR grant reimbursement and $1.0 million in facilities and information technology costs. For more information on the ENCQOR grant, see Note 24 to our Consolidated Financial Statements included in Item 8 of Part II of this report. |

[0000936395-18-000048:mdna:97]
| • | Selling and marketing expense was adversely affected by $4.3 million, as a result of foreign exchange rates, primarily due to a weaker U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expense increased by $37.9 million, primarily reflecting increases of $27.5 million in employee and compensation costs, $3.8 million in selling and marketing costs, $2.7 million in customer demonstration equipment, $1.9 million in professional services, $1.6 million in travel and entertainment costs and $1.5 million in facilities and information technology costs. These increases were slightly offset by a decrease of $1.0 million in depreciation expense. |

[0000936395-18-000048:mdna:98]
| • | General and administrative expense increased by $17.5 million, primarily reflecting increases of $8.5 million in employee and compensation costs, $5.0 million in legal settlements, $4.3 million in professional services and $1.0 |

[0000936395-18-000048:mdna:99]
million in facilities and information technology costs. These increases were partially offset by a decrease of $2.2 million in legal fees.

[0000936395-18-000048:mdna:100]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. The decrease was partially offset by the addition of intangibles related to our acquisitions of Packet Design on July 2, 2018 and DonRiver on October 1, 2018. |

[0000936395-18-000048:mdna:101]
| • | Acquisition and integration costs reflect expense for financial, legal and accounting advisors and severance and other employment-related costs related to our acquisition of Packet Design on July 2, 2018 and DonRiver on October 1, 2018. |

[0000936395-18-000048:mdna:102]
| • | Significant asset impairments and restructuring costs for fiscal 2018 primarily reflect $14.9 million for workforce reductions and $3.9 million for unfavorable lease commitments in connection with with a portion of facilities located in Petaluma, California and in Gurgaon, India. For more information on our workforce reductions, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information. |

[0000936395-18-000048:mdna:103]
Other items

[0000936395-18-000048:mdna:104]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-18-000048:mdna:105]
|  | Fiscal Year |  |  |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (12,029 | ) |  | (0.4 | ) |  | $ | 913 |  |  | — |  |  | $ | (12,942 | ) |  | 1,417.5 |  |
| Interest expense | $ | 55,249 |  |  | 1.8 |  |  | $ | 55,852 |  |  | 2.0 |  |  | $ | (603 | ) |  | (1.1 | ) |
| Loss on extinguishment/modification of debt | $ | (13,887 | ) |  | (0.4 | ) |  | $ | (3,657 | ) |  | (0.1 | ) |  | $ | (10,230 | ) |  | 279.7 |  |
| Provision (benefit) for income taxes | $ | 493,471 |  |  | 15.9 |  |  | $ | (1,105,827 | ) |  | (39.5 | ) |  | $ | 1,599,298 |  |  | (144.6 | ) |

[0000936395-18-000048:mdna:106]
_________________________________

[0000936395-18-000048:mdna:107]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2017 to 2018 |

[0000936395-18-000048:mdna:108]
| • | Interest and other income (loss), net primarily reflects a $12.1 million loss reflective of a mark to market fair value adjustment related to the outstanding conversion feature of our “New” 3.75% Convertible Senior Notes and a $7.1 million unfavorable impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. These losses were partially offset by a $7.1 million gain in interest income due to higher interest rates on our investments during fiscal 2018. |

[0000936395-18-000048:mdna:109]
| • | Interest expense decreased slightly, primarily due to a reduction in our aggregate outstanding debt in both fiscal 2018 and fiscal 2017. For more information, see Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report. |

[0000936395-18-000048:mdna:110]
| • | Loss on extinguishment and modification of debt primarily reflects approximately $10.0 million of extinguishment of debt costs related to our conversion of the 2020 Notes and approximately $3.8 million in debt modification costs related to our term loan refinancing which both occurred in the fourth quarter of fiscal 2018. For fiscal 2017, this loss reflects $3.6 million in debt modification expenses related to the 2022 Term Loan that was entered into in the second quarter of fiscal 2017 and the exchange offer for our “New” 3.75% Convertible Senior Notes in the fourth quarter of fiscal 2017. For more information, see Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report. |

[0000936395-18-000048:mdna:111]
| • | Provision (benefit) for income taxes during fiscal 2018 primarily reflects the impact of the Tax Act including $438.2 million in expense for the remeasurement of our net deferred tax assets and a $34.6 million charge related to a transition tax on accumulated historical foreign earnings and their deemed repatriation to the U.S. The fiscal 2017 benefit for income taxes primarily reflects a reversal of a deferred tax asset valuation allowance. See Note 20 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information. |

[0000936395-18-000048:mdna:112]
Fiscal 2017 compared to Fiscal 2016

[0000936395-18-000048:mdna:113]
Revenue

[0000936395-18-000048:mdna:114]
During fiscal 2017, approximately 17.4% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Canadian Dollars, Brazilian Reais, British Pounds and Japanese Yen. During fiscal 2017 as compared to fiscal 2016, the U.S. Dollar fluctuated against these currencies. As a result, our total revenue reported in U.S. Dollars during fiscal 2017 was adversely impacted by approximately $4.9 million or 0.2% as compared to fiscal 2016. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-18-000048:mdna:115]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,939,621 |  |  | 69.2 |  | $ | 1,815,921 |  |  | 69.9 |  | $ | 123,700 |  |  | 6.8 |  |
| Packet Networking | 313,089 |  |  | 11.2 |  | 252,862 |  |  | 9.7 |  | 60,227 |  |  | 23.8 |  |
| Total Networking Platforms | 2,252,710 |  |  | 80.4 |  | 2,068,783 |  |  | 79.6 |  | 183,927 |  |  | 8.9 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Related Services | 145,009 |  |  | 5.2 |  | 117,251 |  |  | 4.5 |  | 27,758 |  |  | 23.7 |  |
| Blue Planet Automation Software and Related Services | 16,110 |  |  | 0.6 |  | 7,818 |  |  | 0.3 |  | 8,292 |  |  | 106.1 |  |
| Total Software and Software-Related Services | 161,119 |  |  | 5.8 |  | 125,069 |  |  | 4.8 |  | 36,050 |  |  | 28.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 227,400 |  |  | 8.1 |  | 228,982 |  |  | 8.8 |  | (1,582 | ) |  | (0.7 | ) |
| Installation and Deployment | 117,524 |  |  | 4.2 |  | 130,916 |  |  | 5.0 |  | (13,392 | ) |  | (10.2 | ) |
| Consulting and Network Design | 42,934 |  |  | 1.5 |  | 46,823 |  |  | 1.8 |  | (3,889 | ) |  | (8.3 | ) |
| Total Global Services | 387,858 |  |  | 13.8 |  | 406,721 |  |  | 15.6 |  | (18,863 | ) |  | (4.6 | ) |
| Consolidated revenue | $ | 2,801,687 |  |  | 100.0 |  | $ | 2,600,573 |  |  | 100.0 |  | $ | 201,114 |  |  | 7.7 |  |

[0000936395-18-000048:mdna:116]
_________________________________

[0000936395-18-000048:mdna:117]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-18-000048:mdna:118]
| • | Networking Platforms revenue increased, reflecting product line sales increases of $123.7 million of our Converged Packet Optical products and $60.2 million of our Packet Networking products. |

[0000936395-18-000048:mdna:119]
| ◦ | Converged Packet Optical primarily reflects sales increases of $100.8 million of our Waveserver stackable interconnect system, $61.5 million of our 6500 Packet-Optical Platform, $34.2 million of our 5430 Reconfigurable Switching System and $6.8 million of our OTN configuration for the 5410 Reconfigurable Switching System. These increases were partially offset by sales decreases of $49.9 million of our Z-Series Packet-Optical Platform and $7.4 million of our CoreDirector® Multiservice Optical Switches. |

[0000936395-18-000048:mdna:120]
| ◦ | Packet Networking primarily reflects sales increases of $38.7 million of our 3000 and 5000 families of service delivery and aggregation switches, $11.9 million in initial sales of packet networking platform independent software and $10.2 million of our 8700 Packetwave Platform. |

[0000936395-18-000048:mdna:121]
| • | Software and Software-Related Services revenue increased, primarily reflecting sales increases of $27.8 million in our Platform Software and Services and $8.3 of our Blue Planet Automation Software and Services. |

[0000936395-18-000048:mdna:122]
50

[0000936395-18-000048:mdna:123]
| ◦ | Platform Software and Services primarily reflects sales increases of $14.7 million of services and $13.1 million of software. These increases primarily reflect sales increases of $12.7 million of our OneControl Unified Management System and $12.5 million of software subscription services. |

[0000936395-18-000048:mdna:124]
| ◦ | Blue Planet Automation Software and Services primarily reflects sales increases of $4.2 million of professional services and $3.4 million of our software related to orchestration and V-WAN applications. |

[0000936395-18-000048:mdna:125]
| • | Global Services revenue decreased, primarily reflecting sales decreases of $13.4 million of installation and deployment services, $3.9 million of consulting and network design services, and $1.6 million of maintenance support and training services. These sales decreases were primarily due to activity levels in the North America and CALA regions as described below. |

[0000936395-18-000048:mdna:126]
The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-18-000048:mdna:127]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| North America | $ | 1,736,047 |  |  | 62.0 |  | $ | 1,689,263 |  |  | 65.0 |  | $ | 46,784 |  |  | 2.8 |  |
| EMEA | 404,099 |  |  | 14.4 |  | 393,705 |  |  | 15.1 |  | 10,394 |  |  | 2.6 |  |
| CALA | 164,308 |  |  | 5.9 |  | 195,085 |  |  | 7.5 |  | (30,777 | ) |  | (15.8 | ) |
| APAC | 497,233 |  |  | 17.7 |  | 322,520 |  |  | 12.4 |  | 174,713 |  |  | 54.2 |  |
| Total | $ | 2,801,687 |  |  | 100.0 |  | $ | 2,600,573 |  |  | 100.0 |  | $ | 201,114 |  |  | 7.7 |  |

[0000936395-18-000048:mdna:128]
_________________________________

[0000936395-18-000048:mdna:129]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-18-000048:mdna:130]
| • | North America revenue primarily reflects sales increases of $34.7 million within our Networking Platforms segment and $25.7 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $13.6 million within our Global Services segment. |

[0000936395-18-000048:mdna:131]
| ◦ | Networking Platforms segment revenue primarily reflects product line increases of $29.0 million of Packet Networking sales and $5.8 million of Converged Packet Optical sales. |

[0000936395-18-000048:mdna:132]
| ▪ | Packet Networking primarily reflects sales increases of $15.5 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $11.9 million of packet networking platform independent software. Packet Networking sales have traditionally been concentrated, with significant sales to AT&T. However, during fiscal 2017, a significant portion of the growth benefited from sales to other network operators. |

[0000936395-18-000048:mdna:133]
| ▪ | Converged Packet Optical primarily reflects a sales increase of $85.7 million of our Waveserver stackable interconnect system, partially offset by sales decreases of $48.2 million of our Z-Series Packet-Optical Platform, $14.8 million of our 6500 Packet-Optical Platform and $13.3 million of our 5430 Reconfigurable Switching System. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. |

[0000936395-18-000048:mdna:134]
| ◦ | Software and Software-Related Services reflects sales increases of $22.8 million of our Platform Software and Services and $2.8 million of our Blue Planet Automation Software and Services. Platform Software and Services revenue primarily reflects increases of $11.5 million in sales of our software and $11.3 million in sales of services, principally software subscription. |

[0000936395-18-000048:mdna:135]
| ◦ | Global Services primarily reflects sales decreases of $9.0 million for installation and deployment activities and $5.0 million in maintenance support and training. Installation and deployment activities were impacted by the contribution of sales of our Waveserver stackable interconnect system, which does not typically include installation services. |

[0000936395-18-000048:mdna:136]
| • | EMEA revenue primarily reflects increases of $5.4 million within our Networking Platforms segment and $5.4 million within our Software and Software-Related Services segment. |

[0000936395-18-000048:mdna:137]
| ◦ | Networking Platforms segment revenue primarily reflects product line increases of $3.7 million in Packet Networking sales and $1.7 million in Converged Packet Optical sales. |

[0000936395-18-000048:mdna:138]
| • | CALA revenue primarily reflects decreases of $22.1 million within our Networking Platforms segment and $8.9 million within our Global Services segment. The decrease in CALA revenue primarily relates to decreased sales to certain communications service providers in Brazil and to AT&T in Mexico. |

[0000936395-18-000048:mdna:139]
| ◦ | Networking Platforms segment revenue primarily reflects a product line decrease of $25.8 million of Converged Packet Optical sales partially offset by a product line increase of $3.7 million of Packet Networking sales. Converged Packet Optical sales primarily reflect decreases of $15.8 million of our 5430 Reconfigurable Switching System and $3.4 million of our 6500 Packet-Optical Platform. |

[0000936395-18-000048:mdna:140]
| ◦ | Global Services segment revenue primarily reflects reduced installation and deployment activities which reflect the decrease in sales of our Networking Platforms products as described above. |

[0000936395-18-000048:mdna:141]
| • | APAC revenue primarily reflects increases of $165.9 million within our Networking Platforms segment, $4.9 million within our Software and Software-Related Services segment and $3.9 million within our Global Services segment. Revenue contribution from India in fiscal 2017 was a significant driver of our annual revenue growth. |

[0000936395-18-000048:mdna:142]
| ◦ | Networking Platforms segment revenue primarily reflects product line increases of $142.0 million of Converged Packet Optical sales and $23.9 million of Packet Networking sales. |

[0000936395-18-000048:mdna:143]
| ▪ | Converged Packet Optical primarily reflects an increase of $79.5 million in sales of our 6500 Packet-Optical Platform, primarily due to increases in sales through our strategic relationship with Ericsson in Australia and sales to service providers in India and Japan. The revenue increase within Converged Packet Optical also reflects an increase of $64.3 million of our 5430 Reconfigurable Switching System sales primarily due to a service provider in India. |

[0000936395-18-000048:mdna:144]
| ▪ | Packet Networking primarily reflects increases of $15.9 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $8.0 million in sales of our 8700 Packetwave Platform primarily to certain communication service providers in India. |

[0000936395-18-000048:mdna:145]
Cost of Goods Sold and Gross Profit

[0000936395-18-000048:mdna:146]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-18-000048:mdna:147]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 2,801,687 |  |  | 100.0 |  | $ | 2,600,573 |  |  | 100.0 |  | $ | 201,114 |  |  | 7.7 |
| Total cost of goods sold | 1,555,901 |  |  | 55.5 |  | 1,438,997 |  |  | 55.3 |  | 116,904 |  |  | 8.1 |
| Gross profit | $ | 1,245,786 |  |  | 44.5 |  | $ | 1,161,576 |  |  | 44.7 |  | $ | 84,210 |  |  | 7.2 |

[0000936395-18-000048:mdna:148]
_________________________________

[0000936395-18-000048:mdna:149]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-18-000048:mdna:150]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,318,581 |  |  | 100.0 |  | $ | 2,117,472 |  |  | 100.0 |  | $ | 201,109 |  |  | 9.5 |
| Product cost of goods sold | 1,308,295 |  |  | 56.4 |  | 1,176,304 |  |  | 55.6 |  | 131,991 |  |  | 11.2 |
| Product gross profit | $ | 1,010,286 |  |  | 43.6 |  | $ | 941,168 |  |  | 44.4 |  | $ | 69,118 |  |  | 7.3 |

[0000936395-18-000048:mdna:151]
_________________________________

[0000936395-18-000048:mdna:152]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-18-000048:mdna:153]
52

[0000936395-18-000048:mdna:154]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 483,106 |  |  | 100.0 |  | $ | 483,101 |  |  | 100.0 |  | $ | 5 |  |  | — |  |
| Service cost of goods sold | 247,606 |  |  | 51.3 |  | 262,693 |  |  | 54.4 |  | (15,087 | ) |  | (5.7 | ) |
| Service gross profit | $ | 235,500 |  |  | 48.7 |  | $ | 220,408 |  |  | 45.6 |  | $ | 15,092 |  |  | 6.8 |  |

[0000936395-18-000048:mdna:155]
_________________________________

[0000936395-18-000048:mdna:156]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-18-000048:mdna:157]
| • | Gross profit as a percentage of revenue, or gross margin reflects improved services gross profit partially offset by reduced product gross profit. |

[0000936395-18-000048:mdna:158]
| • | Gross profit on products as a percentage of product revenue, or product gross margin, decreased primarily as a result of market-based price erosion partially offset by product cost reductions and increased software platform sales. |

[0000936395-18-000048:mdna:159]
| • | Gross profit on services as a percentage of services revenue, or services gross margin, increased, primarily due to increased sales of higher margin software subscription services and decreased sales of lower margin installation and deployment services. |

[0000936395-18-000048:mdna:160]
Operating expense

[0000936395-18-000048:mdna:161]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-18-000048:mdna:162]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 475,329 |  |  | 17.0 |  | $ | 451,794 |  |  | 17.4 |  | $ | 23,535 |  |  | 5.2 |  |
| Selling and marketing | 356,169 |  |  | 12.7 |  | 349,731 |  |  | 13.4 |  | 6,438 |  |  | 1.8 |  |
| General and administrative | 142,604 |  |  | 5.1 |  | 132,828 |  |  | 5.1 |  | 9,776 |  |  | 7.4 |  |
| Amortization of intangible assets | 33,029 |  |  | 1.2 |  | 61,508 |  |  | 2.4 |  | (28,479 | ) |  | (46.3 | ) |
| Acquisition and integration costs | — |  |  | — |  | 4,613 |  |  | 0.2 |  | (4,613 | ) |  | (100.0 | ) |
| Significant asset impairments and restructuring costs | 23,933 |  |  | 0.9 |  | 4,933 |  |  | 0.2 |  | 19,000 |  |  | 385.2 |  |
| Total operating expenses | $ | 1,031,064 |  |  | 36.9 |  | $ | 1,005,407 |  |  | 38.7 |  | $ | 25,657 |  |  | 2.6 |  |

[0000936395-18-000048:mdna:163]
_________________________________

[0000936395-18-000048:mdna:164]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-18-000048:mdna:165]
| • | Research and development expense was adversely affected by $2.0 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $23.5 million. This increase primarily reflects increases of $17.6 million in employee and compensation costs and $9.5 million in facilities and information technology costs largely due to facilities transitions. These increases were partially offset by decreases of $2.9 million in professional services and $1.1 million in prototype expense. |

[0000936395-18-000048:mdna:166]
| • | Selling and marketing expense increased by $6.4 million, primarily reflecting increases of $1.5 million in facilities and information technology costs, $1.5 million in technology and related costs, $1.4 million in employee and compensation costs and $1.1 million in travel and related costs. |

[0000936395-18-000048:mdna:167]
| • | General and administrative expense increased by $9.8 million, primarily reflecting increases of $4.5 million for employee and compensation costs, $2.9 million for professional services and legal fees and $1.2 million for facilities and information technology costs. |

[0000936395-18-000048:mdna:168]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-18-000048:mdna:169]
| • | Acquisition and integration costs incurred during fiscal 2016 reflects expense for financial, legal and accounting advisors and severance and other employee compensation costs, related to our acquisition of Cyan on August 3, 2015 and our acquisition of certain high-speed photonics components (“HSPC”) assets of TeraXion, Inc. (“TeraXion”) and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-18-000048:mdna:170]
| • | Significant asset impairments and restructuring costs during fiscal 2017 primarily reflects a $13.7 million asset impairment related to a trade receivable for a single customer in the APAC region, $5.9 million for workforce reductions and $4.4 million for unfavorable lease commitments and relocation costs incurred in connection with our research and development center facility transitions in Ottawa, Canada. For more information on our workforce reductions, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information. |

[0000936395-18-000048:mdna:171]
Other items

[0000936395-18-000048:mdna:172]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-18-000048:mdna:173]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | 913 |  |  | — |  |  | $ | (12,569 | ) |  | (0.5 | ) |  | $ | 13,482 |  |  | 107.3 |  |
| Interest expense | $ | 55,852 |  |  | 2.0 |  |  | $ | 56,656 |  |  | 2.2 |  |  | $ | (804 | ) |  | (1.4 | ) |
| Loss on extinguishment and modification of debt | $ | (3,657 | ) |  | (0.1 | ) |  | $ | (226 | ) |  | — |  |  | $ | (3,431 | ) |  | 1,518.1 |  |
| Provision for income taxes | $ | (1,105,827 | ) |  | (39.5 | ) |  | $ | 14,134 |  |  | 0.5 |  |  | $ | (1,119,961 | ) |  | (7,923.9 | ) |

[0000936395-18-000048:mdna:174]
_________________________________

[0000936395-18-000048:mdna:175]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-18-000048:mdna:176]
| • | Interest and other income (loss), net primarily reflects $11.9 million of improved impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-18-000048:mdna:177]
| • | Interest expense decreased slightly, primarily due to a reduction in our aggregate outstanding debt due to the refinancing of our 2022 term loans during the second quarter of fiscal 2017 and the maturity of the 2017 Notes on June 15, 2017. This decrease was offset by higher interest expense related to our new facilities in Ottawa, Canada which are subject to capital lease accounting treatment. |

[0000936395-18-000048:mdna:178]
| • | Loss on extinguishment and modification of debt reflects $3.6 million in debt modification expenses related to the 2022 Term Loan that was entered into in the second quarter of fiscal 2017 and the exchange offer of our New Notes in the fourth quarter of fiscal 2017. |

[0000936395-18-000048:mdna:179]
| • | Provision for income taxes decreased primarily due to a reversal of a deferred tax asset valuation allowance. See Note 20 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information. |

[0000936395-18-000048:mdna:180]
Segment Profit

[0000936395-18-000048:mdna:181]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-18-000048:mdna:182]
54

[0000936395-18-000048:mdna:183]
|  | Fiscal Year |  |  |
|  | 2018 |  | 2017 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 581,113 |  |  | $ | 578,039 |  |  | $ | 3,074 |  |  | 0.5 |
| Software and Software-Related Services | $ | 69,808 |  |  | $ | 32,536 |  |  | $ | 37,272 |  |  | 114.6 |
| Global Services | $ | 172,205 |  |  | $ | 159,882 |  |  | $ | 12,323 |  |  | 7.7 |

[0000936395-18-000048:mdna:184]
_________________________________

[0000936395-18-000048:mdna:185]
| * | Denotes % change from 2017 to 2018 |

[0000936395-18-000048:mdna:186]
| • | Networking Platforms segment profit slightly increased, primarily due to higher sales volume, partially offset by reduced gross margin as described above and increased research and development costs. |

[0000936395-18-000048:mdna:187]
| • | Software and Software-Related Services segment profit increased, primarily due to higher sales volume and lower research and development costs, partially offset by reduced gross margin on software-related services. |

[0000936395-18-000048:mdna:188]
| • | Global Services segment profit increased, primarily due to higher sales volume. |

[0000936395-18-000048:mdna:189]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-18-000048:mdna:190]
|  | Fiscal Year |  |  |
|  | 2017 |  | 2016 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 578,039 |  |  | $ | 544,744 |  |  | $ | 33,295 |  |  | 6.1 |
| Software and Software-Related Services | $ | 32,536 |  |  | $ | 7,123 |  |  | $ | 25,413 |  |  | 356.8 |
| Global Services | $ | 159,882 |  |  | $ | 157,915 |  |  | $ | 1,967 |  |  | 1.2 |

[0000936395-18-000048:mdna:191]
_________________________________

[0000936395-18-000048:mdna:192]
| * | Denotes % change from 2016 to 2017 |

[0000936395-18-000048:mdna:193]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, resulting in increased gross profits, slightly offset by increased research and development costs. Research and development costs primarily reflect increased expenses relating to the continued development of our coherent modem technology, including our WaveLogic Ai coherent optical chipset, and relocation costs in connection with our research and development center facility transitions in Ottawa, Canada. |

[0000936395-18-000048:mdna:194]
| • | Software and Software-Related Services segment profit increased reflecting higher sales volume, as described above, and improved gross margin, partially offset by increased research and development costs. Research and development costs primarily reflect increased expenses relating to the continued development of our Blue Planet software platform. |

[0000936395-18-000048:mdna:195]
| • | Global Services segment profit increased, primarily due to improved gross margin, as described above, partially offset by lower sales volume. |

[0000936395-18-000048:mdna:196]
Liquidity and Capital Resources

[0000936395-18-000048:mdna:197]
Overview. For the fiscal year ended October 31, 2018, we generated $229.3 million in cash from operations, as our net loss (adjusted for non-cash charges) provided $380.0 million which exceeded our working capital requirements of $150.7 million. Our net loss (adjusted for non-cash charges) reflects a non-cash tax provision of $463.6 million primarily related to the enactment of the Tax Act. For additional information on the non-cash tax provision, see Note 20 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report. For additional details on our cash from operations, see the discussion below entitled “Cash from Operations.”

[0000936395-18-000048:mdna:198]
Total cash, cash equivalents and investments decreased by $16.1 million during fiscal 2018. There were several transactions or initiatives that occurred in fiscal 2018 that significantly impacted our cash, cash equivalents and indebtedness:

[0000936395-18-000048:mdna:199]
| • | Term Loan Refinancing. On September 28, 2018, we refinanced our existing 2022 Term Loan in the aggregate principal amount of $394.0 million, into a term loan with an aggregate principal amount of $700 million maturing on September 28, 2025 (the “2025 Term Loan”). This resulted in net proceeds of $305.1 million and debt issuance costs of $1.9 million. |

[0000936395-18-000048:mdna:200]
| • | Settlement Upon Conversion of 2018 Notes. On October 15, 2018, both our 3.75% Convertible Senior Notes due October 15, 2018 (Original) (the “Original Notes”) and our 3.75% Convertible Senior Notes due October 15, 2018 (New) (the “New Notes”) matured. Following conversion elections by the holders thereof, the outstanding Original Notes were converted in advance of maturity on October 15, 2018 and we issued approximately 3.0 million shares of Ciena common stock in settlement of such conversion. During the fourth quarter of fiscal 2018, we elected to settle the conversion of the New Notes in a combination of cash and shares, provided that the cash portion would not exceed an aggregate amount of approximately $400 million. Upon conversion of the New Notes by the holders in advance of maturity, on October 15, 2018, we paid in cash an amount of $288.7 million representing the aggregate principal amount outstanding of the New Notes. |

[0000936395-18-000048:mdna:201]
| • | Stock Repurchase Program. During fiscal 2018, we repurchased $111.0 million of our common stock under our stock repurchase program. |

[0000936395-18-000048:mdna:202]
| • | Acquisitions of Packet Design and DonRiver. On July 2, 2018 we acquired Packet Design for $40.4 million, net of cash acquired, and on October 1, 2018, we acquired DonRiver for upfront cash consideration of $42.3 million, net of cash acquired, plus contingent consideration. See Note 2 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information regarding the three-year earn-out arrangement in connection with the DonRiver acquisition. |

[0000936395-18-000048:mdna:203]
| • | Issuer Conversion of 2020 Notes. On September 20, 2018, we elected to exercise an option to convert the $187.5 million principal amount of 2020 Notes outstanding into shares of Ciena common stock. On the October 31, 2018 conversion date, we issued approximately 9.2 million shares of common stock and paid cash of $13.5 million to satisfy an additional make-whole share obligation to the note holders. |

[0000936395-18-000048:mdna:204]
See Notes 2, 16 and 19 to our Consolidated Financial Statements included in Item 8 of Part II of this report for information relating to these transactions.

[0000936395-18-000048:mdna:205]
The decrease in cash also reflects (i) cash used in investing activities for capital expenditures of $67.6 million; (ii) cash used from financing activities for capital lease obligations of $3.6 million; (iii) stock repurchased upon vesting of our stock units award to employees relating to tax withholding of $4.8 million; and (iv) payments on our term loan of $4.0 million. Proceeds from the issuance of equity under our employee stock purchase plans provided approximately $23.1 million and our settlement of certain foreign currency forward contracts provided $9.4 million in cash during the period.

[0000936395-18-000048:mdna:206]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-18-000048:mdna:207]
|  | October 31, |  | Increase |
|  | 2018 |  | 2017 |  | (decrease) |
| Cash and cash equivalents | $ | 745,423 |  |  | $ | 640,513 |  |  | $ | 104,910 |  |
| Short-term investments in marketable debt securities | 148,981 |  |  | 279,133 |  |  | (130,152 | ) |
| Long-term investments in marketable debt securities | 58,970 |  |  | 49,783 |  |  | 9,187 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 953,374 |  |  | $ | 969,429 |  |  | $ | (16,055 | ) |

[0000936395-18-000048:mdna:208]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash and investments, which as of October 31, 2018 totaled $953.4 million, as well as our ABL credit facility. Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of October 31, 2018, letters of credit totaling $61.7 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2018.

[0000936395-18-000048:mdna:209]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $67.8 million as of October 31, 2018. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate these accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $23.0 million. See Note 20 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-18-000048:mdna:210]
56

[0000936395-18-000048:mdna:211]
Settlement of Debt Conversion Liability. On November 15, 2018, we paid $111.3 million and issued 1.6 million shares in settlement of the remaining debt conversion liability related to the conversion of the 3.75% Convertible Senior Notes due 2018 (the “New Notes”).

[0000936395-18-000048:mdna:212]
Stock Repurchase Authorization. On December 13, 2018, we announced that our Board of Directors authorized a program to repurchase up to $500 million of our common stock. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. This program terminates and replaces in its entirety the previous stock repurchase program authorized in fiscal 2018.

[0000936395-18-000048:mdna:213]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically pay down or refinance our outstanding debt. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents and investments and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures and other liquidity requirements associated with our operations, through at least the next 12 months.

[0000936395-18-000048:mdna:214]
Cash from Operations

[0000936395-18-000048:mdna:215]
The following sections set forth the components of our $229.3 million of cash provided by operating activities for fiscal 2018:

[0000936395-18-000048:mdna:216]
Cash provided by net loss (adjusted for non-cash charges)

[0000936395-18-000048:mdna:217]
The following tables set forth (in thousands) our net loss adjusted for non-cash charges during fiscal 2018:

[0000936395-18-000048:mdna:218]
|  | Year ended |
|  | October 31, 2018 |
| Net loss | $ | (344,690 | ) |
| Adjustments for non-cash charges: |  |
| Loss on extinguishment of debt | 10,039 |  |
| Loss on fair value of debt conversion liability | 12,070 |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 84,214 |  |
| Share-based compensation costs | 52,972 |  |
| Amortization of intangible assets | 25,806 |  |
| Deferred taxes | 463,631 |  |
| Provision for doubtful accounts | 2,700 |  |
| Provision for inventory excess and obsolescence | 30,615 |  |
| Provision for warranty | 20,992 |  |
| Other | 21,685 |  |
| Cash provided by net loss (adjusted for non-cash charges) | $ | 380,034 |  |

[0000936395-18-000048:mdna:219]
Working Capital

[0000936395-18-000048:mdna:220]
Our working capital used $150.7 million of cash during fiscal 2018. The following tables set forth (in thousands) the major components of the reduction in working capital:

[0000936395-18-000048:mdna:221]
|  | Year ended |
|  | October 31, 2018 |
| Cash used in accounts receivable | $ | (168,357 | ) |
| Cash used in inventories | (27,445 | ) |
| Cash used in prepaid expenses and other | (21,425 | ) |
| Cash provided by accounts payable, accruals and other obligations | 85,798 |  |
| Cash used in deferred revenue | (19,344 | ) |
| Cash used in working capital | $ | (150,773 | ) |

[0000936395-18-000048:mdna:222]
As compared to the end of fiscal 2017:

[0000936395-18-000048:mdna:223]
| • | The $168.4 million of cash used in accounts receivable during fiscal 2018 reflects higher sales volume in the fourth quarter of fiscal 2018 as compared to fiscal 2017; |

[0000936395-18-000048:mdna:224]
| • | The $27.4 million in cash used in inventory during fiscal 2018 primarily reflects increases in finished goods to meet customer delivery schedules; |

[0000936395-18-000048:mdna:225]
| • | Cash used in prepaid expenses and other during fiscal 2018 was $21.4 million, primarily reflects increased government grant receivables and other non-customer receivables partially offset by lower prepaid value added taxes and lower deferred deployment costs; |

[0000936395-18-000048:mdna:226]
| • | The $85.8 million of cash provided by accounts payable, accruals and other obligations during fiscal 2018 reflects increased inventory purchases at the end of fiscal 2018; and |

[0000936395-18-000048:mdna:227]
| • | The $19.3 million of cash used in deferred revenue represents a decrease in advanced payments received from customers prior to revenue recognition. |

[0000936395-18-000048:mdna:228]
Our days sales outstanding (DSOs) were 92 days for fiscal 2018 as compared to 80 days for fiscal 2017. Our inventory turns increased from 4.9 turns during fiscal 2017 to 5.7 turns during fiscal 2018.

[0000936395-18-000048:mdna:229]
Cash paid for interest

[0000936395-18-000048:mdna:230]
The following tables set forth (in thousands) our interest paid during fiscal 2018:

[0000936395-18-000048:mdna:231]
|  | Year ended |
|  | October 31, 2018 |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New)(1) | $ | 10,827 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) (1) | 2,298 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(2) | 7,500 |  |
| Term Loan due January 30, 2022 (3) | 15,594 |  |
| Term Loan due September 28, 2025 (4) | 1,980 |  |
| Interest rate swaps(5) | 94 |  |
| ABL Credit Facility(6) | 1,500 |  |
| Capital leases | 4,957 |  |
| Total | $ | 44,750 |  |

[0000936395-18-000048:mdna:232]
| (1) | The final interest payment owing on both issues of our 2018 Notes was paid during the fourth quarter of fiscal 2018. |

[0000936395-18-000048:mdna:233]
| (2) | The final interest payment on our 2020 Notes was paid during the third quarter of fiscal 2018. |

[0000936395-18-000048:mdna:234]
| (3) | Interest on the 2022 Term Loan was payable periodically based on the interest period selected for borrowing. The 2022 Term Loan bore interest at LIBOR plus a spread of 2.50% subject to a minimum LIBOR rate of 0.75%. On September 28, 2018, we refinanced and replaced this term loan with the 2025 Term Loan. See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information. |

[0000936395-18-000048:mdna:235]
| (4) | Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR plus a spread of 2.00% subject to a minimum LIBOR rate of 0.00%. As of the end of fiscal 2018, the interest rate on the 2025 Term Loan was 4.28%. |

[0000936395-18-000048:mdna:236]
58

[0000936395-18-000048:mdna:237]
| (5) | We entered into floating-to-fixed interest rate swap in a total amount of $350 million on October 1, 2018 that fixed the LIBOR rate of approximately 50% of the principal amount of the 2025 Term Loan at 2.957% through September 2023. |

[0000936395-18-000048:mdna:238]
| (6) | During fiscal 2018, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.5 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-18-000048:mdna:239]
For additional information about our convertible notes, term loans (including the refinancing of our 2022 Term Loan into the 2025 Term Loan), ABL Credit Facility and interest rate swaps see Notes 14, 16 and 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-18-000048:mdna:240]
Contractual Obligations

[0000936395-18-000048:mdna:241]
The following is a summary of our future minimum payments under contractual obligations as of October 31, 2018 (in thousands):

[0000936395-18-000048:mdna:242]
|  | Total |  | Less than oneyear |  | One to threeyears |  | Three to fiveyears |  | Thereafter |
| Principal due on Term Loan due September 28, 2025(1) | $ | 700,000 |  |  | $ | 7,000 |  |  | $ | 14,000 |  |  | $ | 14,000 |  |  | $ | 665,000 |  |
| Interest due on Term Loan due September 28, 2025(1) | 203,797 |  |  | 30,187 |  |  | 59,630 |  |  | 58,414 |  |  | 55,566 |  |
| Payments due under interest rate swaps (1) | 11,814 |  |  | 2,397 |  |  | 4,807 |  |  | 4,610 |  |  | — |  |
| Operating leases (2) | 150,608 |  |  | 28,912 |  |  | 45,668 |  |  | 28,981 |  |  | 47,047 |  |
| Purchase obligations (3) | 379,096 |  |  | 379,096 |  |  | — |  |  | — |  |  | — |  |
| Capital leases - equipment | 1,419 |  |  | 1,281 |  |  | 138 |  |  | — |  |  | — |  |
| Capital leases - buildings (4) | 113,862 |  |  | 7,373 |  |  | 15,104 |  |  | 15,974 |  |  | 75,411 |  |
| Payment due on debt conversion - cash settlement (5) | 111,268 |  |  | 111,268 |  |  | — |  |  | — |  |  | — |  |
| Payment due on debt conversion - equity settlement (5) | 52,944 |  |  | 52,944 |  |  | — |  |  | — |  |  | — |  |
| Other obligations | 830 |  |  | 796 |  |  | 34 |  |  | — |  |  | — |  |
| Total (6) | $ | 1,725,638 |  |  | $ | 621,254 |  |  | $ | 139,381 |  |  | $ | 121,979 |  |  | $ | 843,024 |  |

[0000936395-18-000048:mdna:243]
_________________________________

[0000936395-18-000048:mdna:244]
| (1) | Interest on the 2025 Term Loan and payments due under the interest rate swaps is variable and calculated using the rate in effect on the balance sheet date. For additional information about our term loans and the interest rate swaps, see Notes 14 and 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report. |

[0000936395-18-000048:mdna:245]
| (2) | Does not include variable insurance, taxes, maintenance and other costs that may be required by the applicable operating lease. These costs are not expected to have a material future impact. |

[0000936395-18-000048:mdna:246]
| (3) | Purchase obligations relate to purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of the amount reported above relates to firm, non-cancelable and unconditional obligations. |

[0000936395-18-000048:mdna:247]
| (4) | This represents the total minimum lease payments due for all buildings that are subject to capital lease accounting. Does not include variable insurance, taxes, maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact. |

[0000936395-18-000048:mdna:248]
| (5) | This represents the fair value of the total obligation for the cash and equity portion of the conversion feature incurred in conjunction with the November 15, 2018 settlement of the New 3.75% Convertible Senior Notes. See Notes 14 and 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report |

[0000936395-18-000048:mdna:249]
| (6) | As of October 31, 2018, we also had $15.9 million of other long-term obligations on our Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing or amount of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-18-000048:mdna:250]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of October 31, 2018 (in thousands):

[0000936395-18-000048:mdna:251]
|  | Total |  | Less than oneyear |  | One tothree years |  | Three tofive years |  | Thereafter |
| Standby letters of credit | $ | 61,726 |  |  | $ | 19,171 |  |  | $ | 24,564 |  |  | $ | 12,221 |  |  | $ | 5,770 |  |

[0000936395-18-000048:mdna:252]
Off-Balance Sheet Arrangements

[0000936395-18-000048:mdna:253]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-18-000048:mdna:254]
Critical Accounting Policies and Estimates

[0000936395-18-000048:mdna:255]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-18-000048:mdna:256]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-18-000048:mdna:257]
Revenue Recognition

[0000936395-18-000048:mdna:258]
We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. We assess whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer’s payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are to be performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-18-000048:mdna:259]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

[0000936395-18-000048:mdna:260]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

[0000936395-18-000048:mdna:261]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. We determine the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, we use vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third-party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, we use our best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-18-000048:mdna:262]
VSOE, when determinable, is established based on our pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. We have generally been unable to establish TPE of selling price because our go-to-market strategy differs from that of others in our markets, and the extent of customization and differentiated features and functions varies among comparable products or services from our peers. We determine BESP based

[0000936395-18-000048:mdna:263]
upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions and the go-to-market strategy, all of which can affect pricing practices.

[0000936395-18-000048:mdna:264]
Our total deferred revenue for products was $42.5 million and $49.1 million as of October 31, 2018 and October 31, 2017, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $127.0 million and $135.9 million as of October 31, 2018 and October 31, 2017, respectively.

[0000936395-18-000048:mdna:265]
In May 2014, the FASB issued Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers,  a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP on revenue recognition and eliminated industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing and uncertainty of revenues and cash flows related to contracts with customers.

[0000936395-18-000048:mdna:266]
For multiple element software arrangements where vendor-specific objective evidence (“VSOE”) of undelivered maintenance does not exist, we currently recognize revenue for the entire arrangement over the maintenance term. The adoption of ASC 606 will require us to determine the stand alone selling price for each of the software and software-related deliverables at contract inception, and we consequently note that certain software deliverables will be recognized at a point in time rather than over a period of time.

[0000936395-18-000048:mdna:267]
We also note that certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

[0000936395-18-000048:mdna:268]
We have considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, we have elected to implement the practical expedient allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.

[0000936395-18-000048:mdna:269]
We elected to implement ASC 606 using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of accumulated deficit. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASC 606 will be effective for us beginning in the first quarter of fiscal 2019.

[0000936395-18-000048:mdna:270]
We do not expect that ASC 606 will have a material impact on total revenue for fiscal 2019 as we believe the revenue that will be accelerated from certain software arrangements consistent with the changes in timing as described above will be largely offset by a reduction of revenue from software arrangements where revenue was previously deferred in prior periods and recognized ratably over time as required under the current standard. This preliminary assessment is based on the types and number of revenue arrangements currently in place. The exact impact of ASC 606 will be dependent on the facts and circumstances at adoption and could vary from quarter to quarter. For further discussion of ASC 606, see Note 1 to our Consolidated Financial Statements in Item 8 of Part II of this annual report.

[0000936395-18-000048:mdna:271]
Business Combinations

[0000936395-18-000048:mdna:272]
We record acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates. During fiscal 2016, we completed the acquisition of TeraXion’s HSPC assets for a purchase price of $32.0 million.

[0000936395-18-000048:mdna:273]
During fiscal 2018, we completed the Packet Design acquisition for a purchase price of $41.1 million and the DonRiver acquisition for a purchase price of $54.2 million, including a contingent consideration component. See Note 2 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information regarding these transactions and the three-year earn-out arrangement in connection with the DonRiver acquisition.

[0000936395-18-000048:mdna:274]
Share-Based Compensation

[0000936395-18-000048:mdna:275]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-18-000048:mdna:276]
Share-based compensation expense is taken into account based on awards granted. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of our share-based compensation. See Note 21 to our Consolidated Financial Statements in Item 8 of Part II of this annual report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of October 31, 2018, total unrecognized compensation expense was $77.3 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.45 years.

[0000936395-18-000048:mdna:277]
Ciena is required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-18-000048:mdna:278]
Reserve for Inventory Obsolescence

[0000936395-18-000048:mdna:279]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted.

[0000936395-18-000048:mdna:280]
We have experienced write downs due to changes in our strategic direction, discontinuance of a product or introduction of newer versions of our products, declines in the sales of or forecasted demand for certain products, and general market conditions. We recorded charges for excess and obsolete inventory of $30.6 million, $35.5 million and $33.7 million in fiscal 2018, 2017 and 2016, respectively. Our inventory net of allowance for excess and obsolescence was $262.8 million and $267.1 million as of October 31, 2018 and October 31, 2017, respectively.

[0000936395-18-000048:mdna:281]
Allowance for Doubtful Accounts Receivable

[0000936395-18-000048:mdna:282]
Our allowance for doubtful accounts receivable is based on management’s assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer’s financial condition changes, or if actual defaults are higher than our historical experience, we may be

[0000936395-18-000048:mdna:283]
required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations.

[0000936395-18-000048:mdna:284]
During fiscal 2017, Ciena’s allowance for doubtful accounts included a provision for a significant asset impairment of $13.7 million for a trade receivable related to a single customer in the APAC region. Our accounts receivable, net of allowance for doubtful accounts, was $786.5 million and $622.2 million as of October 31, 2018 and October 31, 2017, respectively. Our allowance for doubtful accounts was $17.4 million and $17.6 million as of October 31, 2018 and October 31, 2017, respectively.

[0000936395-18-000048:mdna:285]
Goodwill

[0000936395-18-000048:mdna:286]
Our goodwill was generated from the acquisition of (i) Cyan during fiscal 2015, (ii) the HSPC assets of TeraXion during fiscal 2016, (iii) Packet Design on July 2, 2018, and (iv) DonRiver on October 1, 2018. The goodwill from these acquisitions is primarily related to expected synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-18-000048:mdna:287]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit’s carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of October 31, 2018 and October 31, 2017, the goodwill balance was $298.0 million and $267.5 million, respectively. There were no goodwill impairments resulting from our fiscal 2018 and 2017 impairment tests and no reporting unit was determined to be at risk of failing step one of the goodwill impairment test. See Note 2 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-18-000048:mdna:288]
Long-lived Assets

[0000936395-18-000048:mdna:289]
Our long-lived assets include equipment, building, furniture and fixtures, finite-lived intangible assets, in-process research and development, and maintenance spares. As of October 31, 2018 and October 31, 2017 these assets totaled $486.0 million and $456.3 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets’ carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-18-000048:mdna:290]
Deferred Tax Assets

[0000936395-18-000048:mdna:291]
Pursuant to Accounting Standards Codification (“ASC”) Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-18-000048:mdna:292]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. During the fourth quarter of fiscal 2017, this analysis consisted of the evaluation of all available positive and negative evidence, including our improved profitability in fiscal 2016 and fiscal 2017. We also considered third-party estimates of market growth and our internal projections of future profitability as indicated in our annual update to our operating plan for fiscal 2018 and our long-term strategic forecast which were completed during the fourth quarter of fiscal 2017. We also considered our strong performance against our annual operating plans in recent years and our ability to utilize tax planning strategies. Based on this analysis, we concluded that it was more likely than not that the majority of our U.S. deferred tax assets will be realized, and we therefore reversed most of the valuation allowance against those deferred assets. This reversal resulted in a one-time, non-cash income tax benefit of $1.2 billion and a $26.0 million adjustment to additional paid-in capital. The valuation allowance balance at October 31, 2018 was

[0000936395-18-000048:mdna:293]
$142.7 million and the corresponding net deferred tax asset was $745.0 million. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending upon our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy. For further discussion, see Note 20 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-18-000048:mdna:294]
Warranty

[0000936395-18-000048:mdna:295]
Our liability for product warranties, included in other accrued liabilities, was $44.7 million and $42.5 million as of October 31, 2018 and October 31, 2017, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties, net of adjustments for previous years’ provisions, was $21.0 million, $8.0 million and $15.5 million for fiscal 2018, 2017 and 2016 respectively. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. These adjustments for previous years provisions had the effect of reducing warranty provisions by $9.7 million and $5.3 million for fiscal 2017 and 2016 respectively. During fiscal 2018, we determined that failure rates for prior estimates remained unchanged, and accordingly did not make any adjustments for previous fiscal year provisions not yet settled. As a result, our warranty provision for fiscal 2018 increased as compared to these prior years. See Note 13 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.

[0000936395-18-000048:mdna:296]
Effects of Recent Accounting Pronouncements

[0000936395-18-000048:mdna:297]
See Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to our discussion of the effects of recent accounting pronouncements.

[0000936395-18-000048:mdna:298]
Unaudited Quarterly Results of Operations

[0000936395-18-000048:mdna:299]
The tables below (in thousands, except per share data) set forth the operating results in our consolidated statements of operations for each of the eight quarters in the period ended October 31, 2018. Our revenue can fluctuate from quarter to quarter as a result of a number of factors, including changes in customer spending levels or networking strategies, order timing and volume, backlog levels, timing of revenue recognition and other competitive dynamics. As our business has evolved, including the sales of our solutions to meet the “on-demand” service requirements of both our customers and their end-users, the amount of quarterly revenue that we recognize in a quarter from customer orders received in that same quarter (which we refer to as “book to revenue”) has increased as compared to our historical periods. Increased reliance on book to revenue introduces a number of risks, including the inherent difficulty in forecasting the amount and timing of book to revenue in any given quarter, and may increase the likelihood of fluctuations in our results. This information is unaudited, but in our opinion reflects all adjustments (consisting only of normal recurring adjustments) that we consider necessary for a fair statement of such information in accordance with generally accepted accounting principles. The results for any quarter are not necessarily indicative of results for any future period.

[0000936395-18-000048:mdna:300]
|  | Oct. 31, |  | Jul. 31, |  | Apr. 30, |  | Jan. 31, |  | Oct. 31, |  | Jul. 31, |  | Apr. 30, |  | Jan. 31, |
|  | 2018 |  | 2018 |  | 2018 |  | 2018 |  | 2017 |  | 2017 |  | 2017 |  | 2017 |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 743,867 |  |  | $ | 691,758 |  |  | $ | 604,226 |  |  | $ | 525,609 |  |  | $ | 616,216 |  |  | $ | 610,742 |  |  | $ | 584,630 |  |  | $ | 506,993 |  |
| Services | 155,489 |  |  | 127,059 |  |  | 125,752 |  |  | 120,526 |  |  | 128,233 |  |  | 117,977 |  |  | 122,392 |  |  | 114,504 |  |
| Total revenue | 899,356 |  |  | 818,817 |  |  | 729,978 |  |  | 646,135 |  |  | 744,449 |  |  | 728,719 |  |  | 707,022 |  |  | 621,497 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | 421,583 |  |  | 399,886 |  |  | 372,568 |  |  | 313,120 |  |  | 352,992 |  |  | 341,197 |  |  | 327,295 |  |  | 286,811 |  |
| Services | 79,698 |  |  | 67,388 |  |  | 64,103 |  |  | 61,250 |  |  | 65,772 |  |  | 59,446 |  |  | 61,487 |  |  | 60,901 |  |
| Total costs of goods sold | 501,281 |  |  | 467,274 |  |  | 436,671 |  |  | 374,370 |  |  | 418,764 |  |  | 400,643 |  |  | 388,782 |  |  | 347,712 |  |
| Gross profit | 398,075 |  |  | 351,543 |  |  | 293,307 |  |  | 271,765 |  |  | 325,685 |  |  | 328,076 |  |  | 318,240 |  |  | 273,785 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 134,983 |  |  | 121,133 |  |  | 116,924 |  |  | 118,524 |  |  | 119,108 |  |  | 117,729 |  |  | 121,623 |  |  | 116,869 |  |
| Selling and marketing | 112,791 |  |  | 95,395 |  |  | 97,359 |  |  | 88,515 |  |  | 95,877 |  |  | 86,739 |  |  | 88,551 |  |  | 85,002 |  |
| General and administrative | 44,539 |  |  | 38,212 |  |  | 38,976 |  |  | 38,406 |  |  | 36,181 |  |  | 35,569 |  |  | 34,990 |  |  | 35,864 |  |
| Amortization of intangible assets | 4,654 |  |  | 3,837 |  |  | 3,623 |  |  | 3,623 |  |  | 3,661 |  |  | 3,837 |  |  | 10,980 |  |  | 14,551 |  |
| Acquisition and integration costs | 3,778 |  |  | 1,333 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Significant asset impairments and restructuring costs | 1,460 |  |  | 6,359 |  |  | 4,359 |  |  | 5,961 |  |  | 15,059 |  |  | 2,203 |  |  | 4,276 |  |  | 2,395 |  |
| Total operating expenses | 302,205 |  |  | 266,269 |  |  | 261,241 |  |  | 255,029 |  |  | 269,886 |  |  | 246,077 |  |  | 260,420 |  |  | 254,681 |  |
| Income from operations | 95,870 |  |  | 85,274 |  |  | 32,066 |  |  | 16,736 |  |  | 55,799 |  |  | 81,999 |  |  | 57,820 |  |  | 19,104 |  |
| Interest and other income (loss), net | (13,357 | ) |  | (1,543 | ) |  | 1,296 |  |  | 1,575 |  |  | 1,344 |  |  | (848 | ) |  | 6 |  |  | 411 |  |
| Interest expense | (14,873 | ) |  | (13,611 | ) |  | (13,031 | ) |  | (13,734 | ) |  | (13,926 | ) |  | (13,415 | ) |  | (13,308 | ) |  | (15,203 | ) |
| Loss on extinguishment and modification of debt | (13,887 | ) |  | — |  |  | — |  |  | — |  |  | (692 | ) |  | — |  |  | (2,924 | ) |  | (41 | ) |
| Income before income taxes | 53,753 |  |  | 70,120 |  |  | 20,331 |  |  | 4,577 |  |  | 42,525 |  |  | 67,736 |  |  | 41,594 |  |  | 4,271 |  |
| Provision (benefit) for income tax | (10,224 | ) |  | 19,280 |  |  | 6,475 |  |  | 477,940 |  |  | (1,117,531 | ) |  | 7,726 |  |  | 3,568 |  |  | 410 |  |
| Net income (loss) | $ | 63,977 |  |  | $ | 50,840 |  |  | $ | 13,856 |  |  | $ | (473,363 | ) |  | $ | 1,160,056 |  |  | $ | 60,010 |  |  | $ | 38,026 |  |  | $ | 3,861 |  |
| Basic net income (loss) per common share | $ | 0.45 |  |  | $ | 0.35 |  |  | $ | 0.10 |  |  | $ | (3.29 | ) |  | $ | 8.11 |  |  | $ | 0.42 |  |  | $ | 0.27 |  |  | $ | 0.03 |  |
| Diluted net income (loss) per potential common share | $ | 0.34 |  |  | $ | 0.34 |  |  | $ | 0.09 |  |  | $ | (3.29 | ) |  | $ | 7.32 |  |  | $ | 0.39 |  |  | $ | 0.25 |  |  | $ | 0.03 |  |
| Weighted average basic common shares outstanding | 143,659 |  |  | 143,400 |  |  | 143,975 |  |  | 143,922 |  |  | 143,097 |  |  | 142,464 |  |  | 141,743 |  |  | 140,682 |  |
| Weighted average diluted potential common shares outstanding | 157,745 |  |  | 159,998 |  |  | 147,973 |  |  | 143,922 |  |  | 158,791 |  |  | 172,112 |  |  | 165,273 |  |  | 142,184 |  |
