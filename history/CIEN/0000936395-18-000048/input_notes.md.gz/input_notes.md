# CIEN notes — 0000936395-18-000048


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-18-000048:notes:1]
ABL CREDIT FACILITY

[0000936395-18-000048:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $250 million with a maturity date of December 31, 2020. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-18-000048:notes:3]
As of October 31, 2018, letters of credit totaling $61.7 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2018.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-18-000048:notes:4]
Substantially all of Ciena’s cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena’s cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-18-000048:notes:5]
Historically, a significant percentage of Ciena’s revenue has been concentrated among sales to a small number of large communications service providers. Consolidation among Ciena’s customers has increased this concentration. Consequently, Ciena’s accounts receivable are concentrated among these customers. See Note 22 below.

[0000936395-18-000048:notes:6]
Additionally, Ciena’s access to certain materials or components is dependent upon sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena’s supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena’s business and results of operations may suffer.


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-18-000048:notes:7]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statement of Operations to which the grant activity relates.


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-18-000048:notes:8]
Maintenance spares are recorded at cost. Spares usage cost is expensed ratably over four years.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-18-000048:notes:9]
PREPAID EXPENSES AND OTHER

[0000936395-18-000048:notes:10]
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-18-000048:notes:11]
|  | October 31, |
|  | 2018 |  | 2017 |
| Prepaid VAT and other taxes | $ | 82,518 |  |  | $ | 91,647 |  |
| Product demonstration equipment, net | 37,623 |  |  | 40,713 |  |
| Prepaid expenses | 32,987 |  |  | 26,114 |  |
| Other non-trade receivables | 25,716 |  |  | 9,655 |  |
| Deferred deployment expense | 19,342 |  |  | 26,934 |  |
| Financing receivable | 626 |  |  | 2,049 |  |
| Derivative assets | 133 |  |  | 227 |  |
|  | $ | 198,945 |  |  | $ | 197,339 |  |

[0000936395-18-000048:notes:12]
Depreciation of product demonstration equipment was $9.0 million, $10.0 million and $10.7 million for fiscal 2018, 2017 and 2016, respectively.


## cien:ScheduleOfInventoryValuationReservesTableTextBlock

[0000936395-18-000048:notes:13]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0000936395-18-000048:notes:14]
| Year ended |  | Beginning |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Provisions |  | Disposals |  | Balance |
| 2016 |  | $ | 53,001 |  |  | $ | 33,713 |  |  | $ | 24,211 |  |  | $ | 62,503 |  |
| 2017 |  | $ | 62,503 |  |  | $ | 35,459 |  |  | $ | 46,756 |  |  | $ | 51,206 |  |
| 2018 |  | $ | 51,206 |  |  | $ | 30,615 |  |  | $ | 30,883 |  |  | $ | 50,938 |  |


## cien:ScheduleOfStockRepurchaseProgramTableTextBlock

[0000936395-18-000048:notes:15]
A summary of the stock repurchase program, reported based on trade date, is summarized as follows:

[0000936395-18-000048:notes:16]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2017 | — |  |  | $ | — |  |  | $ | — |  |
| Repurchase of common stock under the stock repurchase program | 4,290,801 |  |  | 25.86 |  |  | 110,981 |  |
| Cumulative balance at October 31, 2018 | 4,290,801 |  |  | $ | 25.86 |  |  | $ | 110,981 |  |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-18-000048:notes:17]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-18-000048:notes:18]
Outstanding Term Loan Payable

[0000936395-18-000048:notes:19]
The net carrying values of Ciena’s term loans were comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-18-000048:notes:20]
|  |  | October 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | — |  |  | $ | 392,972 |  |
| Term Loan Payable due September 28, 2025 |  | 693,450 |  |  | — |  |
|  |  | $ | 693,450 |  |  | $ | 392,972 |  |

[0000936395-18-000048:notes:21]
Deferred debt issuance costs deducted from the carrying amounts of the term loans totaled $4.3 million at October 31, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans is included in interest expense, and was $0.7 million and $0.5 million during fiscal 2018 and fiscal 2017, respectively. The carrying values of the term loans listed above are also net of any unamortized debt discounts.

[0000936395-18-000048:notes:22]
2025 Term Loan

[0000936395-18-000048:notes:23]
On September 28, 2018, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Increase Joinder and Refinancing Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its existing 2022 Term Loan (as described under "2022 Term Loan" below) into a term loan with an aggregate principal amount of $700 million maturing on September 28, 2025 (the “2025 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $699.1 million, net of original discount, from the 2025 Term Loan and simultaneously repaid $394.0 million of outstanding principal under the 2022 Term Loan, resulting in proceeds of $305.1 million. The 2025 Term Loan requires Ciena to make installment payments of $1.75 million on a quarterly basis. Based on the continuation of existing lenders and the addition of new lenders, this arrangement was primarily accounted for as a modification of debt and, as such, $3.8 million of debt issuance costs associated with the 2025 Term Loan were expensed. The aggregate balance of $2.4 million of debt issuance costs and approximately $1.4 million of original discount from the 2022 Term Loan, $1.9 million of debt issuance costs associated with new lenders for the 2025 Term Loan, and approximately $0.9 million of original discount from the 2025 Term Loan, were included in the carrying value of the 2025 Term Loan.

[0000936395-18-000048:notes:24]
The Refinancing Agreement amends the Term Loan Credit Agreement (as defined below) and provides that the 2025 Term Loan will, among other things:

[0000936395-18-000048:notes:25]
| • | amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the Refinancing Term Loan as of September 28, 2018, with the balance payable at maturity; |

[0000936395-18-000048:notes:26]
| • | be subject to mandatory prepayment provisions upon the occurrence of certain specified events substantially similar to the Existing Term Loan, including certain asset sales, debt issuances and receipt of annual Excess Cash Flow (as defined in the Credit Agreement); |

[0000936395-18-000048:notes:27]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.00%) plus an applicable margin of 2.00%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.00%; and |

[0000936395-18-000048:notes:28]
| • | be repayable at any time at Ciena’s election, provided that repayment of the 2025 Term Loan with proceeds of certain indebtedness prior to March 28, 2019 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment. |

[0000936395-18-000048:notes:29]
Except as amended by the Refinancing Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

[0000936395-18-000048:notes:30]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of Ciena’s 2025 Term Loan were as follows as of October 31, 2018 (in thousands):

[0000936395-18-000048:notes:31]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due September 28, 2025 | $ | 700,000 |  |  | $ | (2,300 | ) |  | $ | (4,250 | ) |  | $ | 693,450 |  |

[0000936395-18-000048:notes:32]
The following table sets forth the carrying value and the estimated fair value of Ciena’s 2025 Term Loan (in thousands):

[0000936395-18-000048:notes:33]
|  |  | October 31, 2018 |
|  |  | Carrying Value(1) |  | Fair Value(2) |
| Term Loan Payable due September 28, 2025 |  | $ | 693,450 |  |  | $ | 702,625 |  |

[0000936395-18-000048:notes:34]
| (1) | Includes unamortized debt discount and debt issuance costs. |

[0000936395-18-000048:notes:35]
| (2) | Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-18-000048:notes:36]
2022 Term Loan

[0000936395-18-000048:notes:37]
On January 30, 2017 Ciena entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement (the “Refinancing Agreement”).  The Refinancing Agreement refinanced prior term loans into a single term loan with an aggregate principal amount of $400 million (the “2022 Term Loan”). The 2022 Term Loan required Ciena to make installment payments of approximately $1.0 million on a quarterly basis.

[0000936395-18-000048:notes:38]
Convertible Notes Payable

[0000936395-18-000048:notes:39]
As of October 31, 2018, there were no outstanding convertible notes payable or principal amounts owing with respect thereto. The net carrying values of Ciena’s convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-18-000048:notes:40]
|  |  | October 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | — |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | — |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | — |  |  | 194,717 |  |
|  |  | $ | — |  |  | $ | 543,009 |  |

[0000936395-18-000048:notes:41]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $2.1 million at October 31, 2017, there are no deferred debt issuance costs attributed to convertible notes outstanding at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs for these convertible notes are included in interest expense, and were $1.4 million, $1.8 million and $2.7 million during fiscal 2018, fiscal 2017 and fiscal 2016, respectively. The carrying values of the term loans listed above as of October 31, 2017 are also net of any unamortized debt discounts.

[0000936395-18-000048:notes:42]
3.75% Convertible Senior Notes, due October 15, 2018

[0000936395-18-000048:notes:43]
On October 18, 2010, Ciena completed a private placement of 3.75% Convertible Senior Notes due October 15, 2018 (the “Original Notes”), in aggregate principal amount of $350.0 million. At the election of the holder, the Original Notes were convertible prior to maturity into shares of Ciena common stock at a conversion rate of 49.5872 shares per $1,000 in principal amount, which is equivalent to an initial conversion price of approximately $20.17 per share. On August 2, 2017, Ciena completed an offer to exchange the Original Notes for a new series of 3.75% Convertible Senior Notes due 2018 (the “New Notes”) and an exchange fee of $2.50 per $1,000 original principal amount, or $0.7 million. Following settlement of the exchange, $61.3 million in aggregate principal amount at maturity of Original Notes and $288.7 million in aggregate principal amount at maturity of the New Notes were outstanding. Except with respect to the additional cash settlement option upon conversion, the New Notes were issued on substantially the same terms as the Original Notes including the holder conversion option and interest payment dates described above. Since the calculated fair value of the liability component was greater than the fair value of the New Notes, the adjustment to equity for the cash conversion feature was immaterial. This arrangement was accounted for as a modification of debt and, as such, $0.7 million of debt issuance costs associated with the New Notes was expensed, and the aggregate balance of $1.2 million of debt issuance costs for the Old Notes and approximately $0.7 million of original discount from the New Notes were included in the carrying value of the New Notes.

[0000936395-18-000048:notes:44]
Conversion of Original Notes. Following conversion elections by the holders thereof, the Original Notes were converted in advance of maturity during the fourth quarter of fiscal 2018 and Ciena issued approximately 3.0 million shares of its common stock in settlement of such conversion. The Original Notes thereafter ceased to be outstanding.

[0000936395-18-000048:notes:45]
Conversion of New Notes. The New Notes provided Ciena the option, at its election, to settle conversions of such notes for cash, shares of its common stock, or a combination of cash and shares equal to the aggregate amount due upon conversion.

[0000936395-18-000048:notes:46]
During the fourth quarter of fiscal 2018, Ciena elected to settle conversion of the New Notes in a combination of cash and shares, provided that the cash portion would not to exceed an aggregate amount of approximately $400 million. As a result of this election, Ciena became obligated to settle a portion of the conversion feature in cash and reclassified the cash conversion feature from equity to a derivative liability at its current fair value of $152.1 million. The embedded conversion feature was remeasured in earnings through period end and was settled on November 15, 2018. See Notes 14 and 25 for more information on this liability and settlement. Following conversion elections by the holders thereof, the New Notes were converted in advance of maturity during the fourth quarter of fiscal 2018 and Ciena paid an amount of $288.7 million in cash, representing the aggregate principal amount of the notes, on October 15, 2018. The New Notes principal thereafter ceased to be outstanding.

[0000936395-18-000048:notes:47]
4.0% Convertible Senior Notes due December 15, 2020

[0000936395-18-000048:notes:48]
On December 27, 2012, Ciena issued $187.5 million in aggregate principal amount of 4.0% Convertible Senior Notes due December 15, 2020 (the “2020 Notes”) in separate private offerings in exchange for $187.5 million in aggregate principal amount of a then existing issue of convertible notes maturing in 2015. The principal amount of the 2020 Notes also accreted at a rate of 1.85% per year commencing December 27, 2012, compounding on a semi-annual basis. The accreted portion of the principal payable at maturity did not bear interest and was not convertible into shares of Ciena’s common stock. The 2020 Notes were convertible prior to maturity, at the option of the holder, into shares of Ciena’s common stock at a conversion rate of 49.0557 shares of common stock per $1,000 in original principal amount, which is equal to an initial conversion price of $20.39 per share. In addition, the indenture provided that Ciena could elect to convert the 2020 Notes, in whole or in part, at any time on or prior to December 15, 2020, if the daily volume weighted average price of the common stock equals or exceeds 130% of the conversion price then in effect for at least 20 trading days in any 30 consecutive trading day period, provided that upon such an election the conversion rate would be adjusted to include an amount of additional shares, determined by reference to a make-whole table, payable in Ciena common stock, or its cash equivalent. On September 20, 2018, Ciena elected to exercise its option to convert the entire principal amount outstanding into shares of Ciena common stock, with such conversion to occur on October 31, 2018 (the “Conversion Date”). Upon the Conversion Date, Ciena issued approximately 9.2 million shares of its common stock and paid cash of $13.5 million, having elected to satisfy its additional make-whole share obligation in cash.

[0000936395-18-000048:notes:49]
Accounting guidance issued by the FASB requires the issuer of convertible debt instruments with cash settlement features, including partial cash settlement, to account separately for the liability and equity components of the instrument. Under this guidance, the debt is recognized at the present value of its cash flows discounted using the issuer’s nonconvertible debt borrowing rate at the time of issuance, and the equity component is recognized as the difference between the proceeds from the issuance of the note and the fair value of the liability. The reduced carrying value on the convertible debt results in a debt discount that is accreted back to the convertible debt’s principal amount through the recognition of non-cash interest expense over the expected life of the debt, which results in recognizing the interest expense on these borrowings at effective rates approximating what Ciena would have incurred had nonconvertible debt with otherwise similar terms been issued.

[0000936395-18-000048:notes:50]
Because the additional make-whole shares could be settled in cash or common stock at Ciena’s option, the debt and equity components were accounted for separately. Ciena measured the fair value of the debt component of the 2020 Notes using an effective interest rate of 7.0%. As a result, Ciena attributed $170.4 million of the fair value of the 2020 Notes to the debt component. The debt component was netted against the face value of the 2020 Notes to determine the debt discount. The debt discount was accreted over the period from the date of issuance to the contractual maturity date, resulting in the recognition of non-cash interest expense. In addition, Ciena recorded $43.1 million within additional paid-in capital representing the equity component of the 2020 Notes. There was no net tax expense recorded at that time due to Ciena’s full valuation allowance against its deferred tax assets.

[0000936395-18-000048:notes:51]
Because the 2020 Notes contained both debt and equity elements as described above, Ciena allocated the fair value of the consideration transferred (cash and shares) between (i) the debt component to reflect the extinguishment of the debt and (ii) the equity component to reflect the reacquisition of the embedded conversion option. The fair value of the 2020 notes was calculated by Ciena immediately prior to its derecognition in the fourth quarter of fiscal 2018. Accordingly, Ciena recorded a $9.9 million loss on extinguishment of debt, representing the difference between the calculated fair value of the debt and the carrying amount of the debt component, including any unamortized debt discount or issuance costs. The remainder of the consideration was allocated to the reacquisition of the equity component.


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-18-000048:notes:52]
Ciena expenses all advertising costs as incurred.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-18-000048:notes:53]
BUSINESS COMBINATIONS

[0000936395-18-000048:notes:54]
DonRiver Holdings, LLC Acquisition

[0000936395-18-000048:notes:55]
On October 1, 2018, Ciena acquired DonRiver Holdings, LLC (“DonRiver”), a global software and services company specializing in federated network and service inventory management solutions within the service provider Operational Support Systems (OSS) environment. This transaction has been accounted for as the acquisition of a business.

[0000936395-18-000048:notes:56]
During the fourth quarter of fiscal 2018, Ciena incurred approximately $3.5 million of acquisition-related costs associated with this transaction. These costs and expenses include fees associated with financial, legal and accounting advisors and other employment-related costs.

[0000936395-18-000048:notes:57]
The following table summarizes the purchase price for the acquisition (in thousands):

[0000936395-18-000048:notes:58]
|  | Amount |
| Cash | $ | 43,283 |  |
| Contingent consideration | 10,900 |  |
| Total purchase price | $ | 54,183 |  |

[0000936395-18-000048:notes:59]
The following table summarizes the final purchase price allocation related to the acquisition based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-18-000048:notes:60]
|  | Amount |
| Cash and cash equivalents | $ | 1,025 |  |
| Accounts receivable | 4,790 |  |
| Prepaid expenses and other long term assets | 372 |  |
| Goodwill | 10,453 |  |
| Customer relationships and contracts | 37,700 |  |
| Developed technology | 9,700 |  |
| Deferred revenue | (193 | ) |
| Other current and long term liabilities | (9,664 | ) |
| Total purchase price | $ | 54,183 |  |

[0000936395-18-000048:notes:61]
The acquisition of DonRiver includes a $28.5 million three-year earn-out arrangement that consists of both a contingent consideration element and a contingent compensation element. The contingent consideration element requires additional cash consideration to be paid based on the future revenues generally derived from the DonRiver business over a 25-month period from the acquisition date through October 31, 2020. The undiscounted amounts potentially payable by Ciena under the contingent consideration element range from $0.0 million to $15.0 million in the aggregate over the period. Any amounts earned under the contingent consideration element are payable in the first quarters of fiscal 2019, fiscal 2020 and fiscal 2021. The $10.9 million fair value of the contingent consideration element as of the acquisition date was estimated by applying the income approach based upon a discounted cash flow technique using Monte Carlo simulations. The contingent compensation element of the earn-out arrangement includes an employment condition for the selling shareholders who became employees of Ciena upon the completion of the acquisition. The range of amounts that Ciena could pay under the contingent compensation element is between $0.0 million and $13.5 million in the aggregate over the period. Any amounts earned under the contingent compensation element are payable in the first quarters of fiscal 2021 and fiscal 2022. These amounts will be accrued over the period earned and recorded as expense in the Consolidated Statement of Operations.

[0000936395-18-000048:notes:62]
Customer relationships and contracts represent agreements with existing DonRiver customers. Customer relationships and contracts are amortized on a straight line basis over their estimated useful life of seven years. Fair value was determined using the multi-period excess earnings method based on the present value of the incremental after-tax cash flows (or “excess earnings”) attributable to customer relationships for a discrete projection period.

[0000936395-18-000048:notes:63]
Developed technology represents purchased technology that had reached technological feasibility and for which DonRiver had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of seven years.

[0000936395-18-000048:notes:64]
The goodwill generated from the acquisition of DonRiver is primarily related to expected synergies. The total goodwill amount was recorded in the Software and Software-Related Services segment. The goodwill related to this acquisition is not deductible for tax purposes.

[0000936395-18-000048:notes:65]
Pro forma disclosures have not been included due to immateriality.

[0000936395-18-000048:notes:66]
Packet Design, LLC Acquisition

[0000936395-18-000048:notes:67]
On July 2, 2018, Ciena acquired Packet Design, LLC (“Packet Design”), a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics, in a cash transaction for approximately $41.1 million in cash. This transaction has been accounted for as the acquisition of a business.

[0000936395-18-000048:notes:68]
During fiscal 2018, Ciena incurred approximately $1.6 million of acquisition-related costs associated with this transaction. These costs and expenses include fees associated with financial, legal and accounting advisors and severance and other employment-related costs, including payments to certain former Packet Design employees.

[0000936395-18-000048:notes:69]
|  | Amount |
| Cash and cash equivalents | $ | 642 |  |
| Accounts receivable | 1,525 |  |
| Prepaid expenses and other | 450 |  |
| Equipment, furniture and fixtures | 31 |  |
| Goodwill | 20,304 |  |
| Customer relationships and contracts | 2,200 |  |
| Developed technology | 21,900 |  |
| Accounts payable | (165 | ) |
| Accrued liabilities | (657 | ) |
| Deferred revenue | (5,176 | ) |
| Total purchase price | $ | 41,054 |  |

[0000936395-18-000048:notes:70]
Customer relationships and contracts represent agreements with existing Packet Design customers.  Customer relationships and contracts are amortized on a straight line basis over their estimated useful life of three years.

[0000936395-18-000048:notes:71]
Developed technology represents purchased technology that had reached technological feasibility and for which Packet Design had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of five years.

[0000936395-18-000048:notes:72]
The goodwill generated from the acquisition of Packet Design is primarily related to expected synergies. The total goodwill amount was recorded in the Software and Software-Related Services segment. The goodwill related to this acquisition is not deductible for tax purposes.

[0000936395-18-000048:notes:73]
TeraXion HSPC Asset Acquisition

[0000936395-18-000048:notes:74]
On February 1, 2016, Ciena, through a Canadian subsidiary, acquired certain high-speed photonics components (“HSPC”) assets of TeraXion Inc. (“TeraXion”) and its wholly-owned subsidiary for approximately $32 million in cash. The assets purchased include TeraXion’s high-speed indium phosphide and silicon photonics technologies, as well as the underlying intellectual property. These technologies support the development of Ciena’s WaveLogic coherent optical chipsets. This transaction has been accounted for as the acquisition of a business.

[0000936395-18-000048:notes:75]
The following table summarizes the final purchase price allocation related to the acquisition of the HSPC assets based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-18-000048:notes:76]
|  | Amount |
| Inventory | $ | 119 |  |
| Fixed assets | 1,381 |  |
| Developed technology | 16,468 |  |
| In-process technology | 3,949 |  |
| Goodwill | 10,083 |  |
| Total purchase price | $ | 32,000 |  |

[0000936395-18-000048:notes:77]
Developed technology represents purchased technology that had reached technological feasibility and for which TeraXion had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of five years.

[0000936395-18-000048:notes:78]
In-process technology represents purchased technology that had not reached technological feasibility as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the in-process technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Upon completion of the in-process technology, it will be amortized on a straight line basis over its estimated useful life, which will be determined on that date.

[0000936395-18-000048:notes:79]
The goodwill generated from the acquisition of the HSPC assets was primarily related to expected synergies and has been allocated to the Networking Platforms segment. The goodwill is not deductible for income tax purposes.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-18-000048:notes:80]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending upon the duration of the restriction.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-18-000048:notes:81]
COMMITMENTS AND CONTINGENCIES

[0000936395-18-000048:notes:82]
Canadian Grant

[0000936395-18-000048:notes:83]
During the second quarter of fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.0 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. During fiscal 2018, Ciena recorded a CAD$16.6 million (approximately $12.9 million) benefit as a reduction in research and development expense, related to eligible costs that it incurred from the commencement date of February 20, 2017 to October 31, 2018, because it believes it has complied with the conditions of the agreements entitling it to this amount. In future periods, through the term of these agreements, Ciena expects to record a quarterly benefit to operating expense of approximately CAD$2.95 million (approximately $2.3 million) related to these grants. As of October 31, 2018, amounts receivable from this grant were CAD$7.5 million (approximately $5.7 million).

[0000936395-18-000048:notes:84]
Foreign Tax Contingencies

[0000936395-18-000048:notes:85]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-18-000048:notes:86]
Litigation

[0000936395-18-000048:notes:87]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, the first of two purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. The cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. During the fourth quarter of fiscal 2018, the parties agreed to the terms of a settlement of the action, which settlement is subject to notice to class members and approval by the court. The terms of the proposed settlement, which include a release and dismissal of all claims against all defendants without any liability or wrongdoing attributed to them, are not material to the Company’s financial results. There is no assurance that the court will ultimately approve the settlement.

[0000936395-18-000048:notes:88]
Internal Investigation

[0000936395-18-000048:notes:89]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. On December 10, 2018, the DOJ advised that it has declined to prosecute this matter and that its investigation into the matter is now closed. Ciena continues to cooperate fully with the SEC in its investigation into this matter.

[0000936395-18-000048:notes:90]
Ciena’s operations in the relevant country have constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year from 2012 through 2017. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this Report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

[0000936395-18-000048:notes:91]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

[0000936395-18-000048:notes:92]
Lease Commitments

[0000936395-18-000048:notes:93]
Ciena has certain minimum obligations under non-cancelable leases expiring on various dates through 2032 for equipment and facilities. The following table summarizes our future annual minimum lease commitments under non-cancelable leases that are not recorded on the balance sheet as of October 31, 2018 (in thousands):

[0000936395-18-000048:notes:94]
|  |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
| Operating leases |  | $ | 28,912 |  |  | $ | 24,348 |  |  | $ | 21,320 |  |  | $ | 15,839 |  |  | $ | 13,142 |  |  | $ | 47,047 |  |  | $ | 150,608 |  |

[0000936395-18-000048:notes:95]
Rental expense for fiscal 2018, fiscal 2017 and fiscal 2016 was approximately $24.1 million, $30.9 million and $26.6 million, respectively. In addition, Ciena paid approximately $1.9 million, $2.7 million and $0.8 million during fiscal 2018, fiscal 2017 and fiscal 2016, respectively, related to rent costs for restructured facilities and unfavorable lease commitments, which were offset against Ciena’s restructuring liabilities and unfavorable lease obligations. The amount for operating lease commitments above does not include variable expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. These costs are not expected to have a material impact on Ciena’s financial condition, results of operations or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-18-000048:notes:96]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena’s ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000936395-18-000048:notes:97]
OTHER EMPLOYEE BENEFIT PLANS

[0000936395-18-000048:notes:98]
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. The plan covers all Canada-based employees who are not part of an excluded group. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual dollar limit (CAD$26,230 (approximately $34,364) for 2018). This plan includes a required employer contribution of 1% for all participants and a 50% matching of participant contributions up to a total annual maximum of CAD$3,000 (approximately $3,930) per employee. During fiscal 2018, 2017 and 2016, Ciena made matching contributions of approximately CAD$5.1 million (approximately $6.7 million), CAD$4.7 million (approximately $6.2 million) and CAD$4.5 million (approximately $5.9 million), respectively.

[0000936395-18-000048:notes:99]
Ciena has a 401(k) defined contribution profit sharing plan. Participants may contribute up to 60% of pre-tax compensation, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 6% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2018, 2017 and 2016, Ciena made matching contributions of approximately $5.8 million, $5.7 million and $5.4 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-18-000048:notes:100]
ACCUMULATED OTHER COMPREHENSIVE INCOME

[0000936395-18-000048:notes:101]
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”):

[0000936395-18-000048:notes:102]
|  |  | Unrealized Gain/(Loss) on Available-for-Sale Securities |  | Unrealized Gain/(Loss) on Foreign Currency Forward Contracts |  | Unrealized Gain/(Loss) on Forward Starting Interest Rate Swaps |  | Cumulative Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2015 |  | $ | (78 | ) |  | $ | (268 | ) |  | $ | (5,522 | ) |  | $ | (16,258 | ) |  | $ | (22,126 | ) |
| Other comprehensive gain (loss) before reclassifications |  | 217 |  |  | (1,453 | ) |  | (4,101 | ) |  | (1,152 | ) |  | (6,489 | ) |
| Amounts reclassified from AOCI |  | — |  |  | 630 |  |  | 3,656 |  |  | — |  |  | 4,286 |  |
| Balance at October 31, 2016 |  | 139 |  |  | (1,091 | ) |  | (5,967 | ) |  | (17,410 | ) |  | (24,329 | ) |
| Other comprehensive gain (loss) before reclassifications |  | (590 | ) |  | 1,290 |  |  | 3,669 |  |  | 8,012 |  |  | 12,381 |  |
| Amounts reclassified from AOCI |  | — |  |  | (1,585 | ) |  | 2,516 |  |  | — |  |  | 931 |  |
| Balance at October 31, 2017 |  | (451 | ) |  | (1,386 | ) |  | 218 |  |  | (9,398 | ) |  | (11,017 | ) |
| Other comprehensive gain (loss) before reclassifications |  | 26 |  |  | (3,242 | ) |  | 6,011 |  |  | 686 |  |  | 3,481 |  |
| Amounts reclassified from AOCI |  | — |  |  | 1,568 |  |  | 188 |  |  | — |  |  | 1,756 |  |
| Balance at October 31, 2018 |  | $ | (425 | ) |  | $ | (3,060 | ) |  | $ | 6,417 |  |  | $ | (8,712 | ) |  | $ | (5,780 | ) |

[0000936395-18-000048:notes:103]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted revenue, research and development expense or sales and marketing expense on the Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Consolidated Statements of Operations.


## us-gaap:ConsolidationPolicyTextBlock

[0000936395-18-000048:notes:104]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-18-000048:notes:105]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-18-000048:notes:106]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-18-000048:notes:107]
|  | October 31, |
|  | 2018 |  | 2017 |
| Products | $ | 42,474 |  |  | $ | 49,135 |  |
| Services | 126,983 |  |  | 135,872 |  |
|  | 169,457 |  |  | 185,007 |  |
| Less current portion | (111,134 | ) |  | (102,418 | ) |
| Long-term deferred revenue | $ | 58,323 |  |  | $ | 82,589 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-18-000048:notes:108]
DERIVATIVE INSTRUMENTS

[0000936395-18-000048:notes:109]
Foreign Currency Derivatives

[0000936395-18-000048:notes:110]
During fiscal 2018 and fiscal 2017, Ciena entered into forward contracts to hedge its foreign exchange exposure from its forecasted cash flows in order to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities, its British Pound denominated expense, which principally relates to sales and marketing activities, and its Euro denominated revenue. The notional amount of these contracts was approximately $163.2 million and $86.1 million as of October 31, 2018 and October 31, 2017, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-18-000048:notes:111]
During fiscal 2018 and fiscal 2017, in order to hedge its foreign exchange exposure from certain balance sheet items, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar, Euro, Australian Dollar, British Pound Sterling, and Mexican Peso. The notional amount of these contracts was approximately $162.6 million and $83.4 million as of October 31, 2018 and October 31, 2017. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-18-000048:notes:112]
Interest Rate Derivatives

[0000936395-18-000048:notes:113]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements ("interest rate swaps"). During the fourth quarter of fiscal 2018, Ciena refinanced its existing 2022 Term Loans into a new 2025 Term Loan, increasing the aggregate outstanding principal to $700 million and extending the maturity to September 2025 (see Note 16 below). In conjunction with the refinancing, Ciena unwound its existing interest rate swaps for a cash gain of $6.8 million, which was recorded in Other Comprehensive Income, and entered into new floating-to-fixed interest rate swaps. The new interest rate swaps fix the LIBOR rate of approximately 50% of the principal amount of the 2025 Term Loan at 2.957% through September 2023. The total notional amount of these interest rate swaps in effect as of October 31, 2018 was $350.0 million.

[0000936395-18-000048:notes:114]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amounts of the term loans. These derivative contracts have been designated as cash flow hedges.

[0000936395-18-000048:notes:115]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Notes 4 and 6 above.

[0000936395-18-000048:notes:116]
Debt Conversion Liability Associated With 3.75% Convertible Senior Notes due October 15, 2018 (“New Notes”)

[0000936395-18-000048:notes:117]
The New Notes provided Ciena the option, at its election, to settle conversions of such notes for cash, shares of its common stock, or a combination of cash and shares equal to the aggregate amount due upon conversion. On August 30, 2018, Ciena notified the noteholders that it had elected to settle conversion of the New Notes in a combination of cash and shares, provided that the cash portion would not exceed an aggregate amount of $400 million. Ciena became obligated to settle a portion of the conversion feature in cash and reclassified the cash conversion feature from equity to a derivative liability at its current fair value of $152.1 million. As of October 31, 2018, Ciena recorded a loss of approximately $12.1 million related to the change in fair value of the embedded conversion feature. On November 15, 2018, Ciena paid approximately $111.3 million in cash and issued 1.6 million shares in settlement of this embedded conversion feature.


## us-gaap:DerivativesPolicyTextBlock

[0000936395-18-000048:notes:118]
Ciena’s 3.75% Convertible Senior Notes due October 15, 2018 (the "New Notes") included a conversion feature that is accounted for as a separate embedded derivative. The embedded conversion feature is recorded at fair value on a recurring basis    using the underlying stock price, time to maturity and expected volatility of Ciena’s stock and conversion price. These changes are included in interest and other income (loss), net on the Consolidated Statement of Operations.

[0000936395-18-000048:notes:119]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 24 months or less. Ciena also has interest rate  swap arrangements to reduce variability in certain forecasted interest expense associated with its term loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The derivative’s net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statement of Operations to which the hedged transaction relates.

[0000936395-18-000048:notes:120]
Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

[0000936395-18-000048:notes:121]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet foreign exchange exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Consolidated Statement of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-18-000048:notes:122]
SHARE-BASED COMPENSATION EXPENSE

[0000936395-18-000048:notes:123]
Ciena has outstanding equity awards issued under its 2017 Omnibus Incentive Plan (the "2017 Plan"), its 2008 Omnibus Incentive Plan, and certain legacy equity plans and equity plans assumed as a result of previous acquisitions. All equity awards granted on or after March 23, 2017 are made exclusively from the 2017 Plan. Ciena also makes shares of its common stock available for purchase under its Amended and Restated 2003 Employee Stock Purchase Plan (the "ESPP"). Each of the 2017 Plan and the ESPP are described below.

[0000936395-18-000048:notes:124]
2017 Plan

[0000936395-18-000048:notes:125]
The 2017 Plan has a ten-year term and authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2017 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2017 Plan to vest, unless the awards are continued or substituted for in connection with the transaction.

[0000936395-18-000048:notes:126]
The 2017 Plan authorizes and reserves 8.9 million shares for issuance. In addition, any shares that remained available for issuance under the 2008 Plan as of March 23, 2017 were added to the 2017 Plan and are available for issuance thereunder. The number of shares available under the 2017 Plan will also be increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena’s prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition of another company. As of October 31, 2018, the total number of shares authorized for issuance under the 2017 Plan is 8.9 million and approximately 7.2 million shares remained available for issuance thereunder.

[0000936395-18-000048:notes:127]
Stock Options

[0000936395-18-000048:notes:128]
There were no stock options granted by Ciena during fiscal 2018, fiscal 2017 or fiscal 2016. Outstanding stock option awards granted to employees in prior periods are generally subject to service-based vesting conditions and vest over a four-year period. The following table is a summary of Ciena’s stock option activity for the periods indicated (shares in thousands):

[0000936395-18-000048:notes:129]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance as of October 31, 2017 | 875 |  |  | $ | 30.19 |  |
| Granted | — |  |  | — |  |
| Exercised | (179 | ) |  | 12.75 |  |
| Canceled | (420 | ) |  | 35.46 |  |
| Balance as of October 31, 2018 | 276 |  |  | $ | 33.52 |  |

[0000936395-18-000048:notes:130]
The total intrinsic value of options exercised during fiscal 2018, fiscal 2017 and fiscal 2016 was $2.2 million, $3.1 million and $5.7 million, respectively.

[0000936395-18-000048:notes:131]
The following table summarizes information with respect to stock options outstanding at October 31, 2018, based on Ciena’s closing stock price on the last trading day of Ciena’s fiscal 2018 (shares and intrinsic value in thousands):

[0000936395-18-000048:notes:132]
|  |  |  |  |  |  | Options Outstanding at |  | Vested Options at |
|  |  |  |  |  |  | October 31, 2018 |  | October 31, 2018 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  | Number |  | WeightedAverageRemaining | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  | of |  | Contractual | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  | Underlying |  | Life | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  | Shares |  | (Years) | Price |  | Value |
| $ | 5.34 |  |  | — |  |  | $ | 11.16 |  |  | 14 |  |  | 1.31 |  | $ | 8.30 |  |  | $ | 323 |  |  | 14 |  |  | 1.31 | $ | 8.30 |  |  | $ | 323 |  |
| $ | 11.34 |  |  | — |  |  | $ | 16.79 |  |  | 64 |  |  | 3.63 |  | 13.53 |  |  | 1,191 |  |  | 64 |  |  | 3.62 | 13.52 |  |  | 1,185 |  |
| $ | 17.50 |  |  | — |  |  | $ | 25.36 |  |  | 11 |  |  | 5.6 |  | 18.44 |  |  | 156 |  |  | 11 |  |  | 5.55 | 18.21 |  |  | 151 |  |
| $ | 32.06 |  |  | — |  |  | $ | 37.10 |  |  | 54 |  |  | 3.97 |  | 35.60 |  |  | — |  |  | 54 |  |  | 3.97 | 35.60 |  |  | — |  |
| $ | 37.82 |  |  | — |  |  | $ | 55.63 |  |  | 133 |  |  | 4.59 |  | 46.29 |  |  | — |  |  | 132 |  |  | 4.59 | 46.29 |  |  | — |  |
| $ | 5.34 |  |  | — |  |  | $ | 55.63 |  |  | 276 |  |  | 4.13 |  | $ | 33.52 |  |  | $ | 1,670 |  |  | 275 |  |  | 4.12 | $ | 33.56 |  |  | $ | 1,659 |  |

[0000936395-18-000048:notes:133]
Assumptions for Option-Based Awards

[0000936395-18-000048:notes:134]
Ciena recognizes the fair value of stock options as share-based compensation expense on a straight-line basis over the requisite service period. Ciena did not grant any option-based awards during fiscal 2018, fiscal 2017, or fiscal 2016.

[0000936395-18-000048:notes:135]
Restricted Stock Units

[0000936395-18-000048:notes:136]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena’s outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. However, the 2017 Plan permits Ciena to grant service-based stock awards with a minimum one-year vesting period. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets; or (ii) measure Ciena’s total shareholder return as compared to an index of peer companies, a condition of vesting of such awards, in whole or in part. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena’s determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-18-000048:notes:137]
The following table is a summary of Ciena’s restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena’s closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-18-000048:notes:138]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance as of October 31, 2017 | 4,143 |  |  | $ | 21.46 |  |  | $ | 86,721 |  |
| Granted | 2,713 |  |  |  |  |  |
| Vested | (2,155 | ) |  |  |  |  |
| Canceled or forfeited | (299 | ) |  |  |  |  |
| Balance as of October 31, 2018 | 4,402 |  |  | $ | 22.26 |  |  | $ | 140,943 |  |

[0000936395-18-000048:notes:139]
The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2018, fiscal 2017 and fiscal 2016 was $54.3 million, $49.5 million and $50.3 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2018, fiscal 2017 and fiscal 2016 was $22.46, $23.29 and $19.81, respectively.

[0000936395-18-000048:notes:140]
Assumptions for Restricted Stock Unit Awards

[0000936395-18-000048:notes:141]
The fair value of each restricted stock unit award is based on the closing price on the date of grant. Share-based expense for service-based restricted stock unit awards is recognized ratably over the vesting period on a straight-line basis.

[0000936395-18-000048:notes:142]
Share-based expense for performance-based restricted stock unit awards is recognized ratably over the performance period based upon Ciena’s determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-18-000048:notes:143]
Share-based compensation expense is recognized only for those awards that are ultimately expected to vest. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of our share-based compensation.

[0000936395-18-000048:notes:144]
Amended and Restated Employee Stock Purchase Plan (ESPP)

[0000936395-18-000048:notes:145]
Under the ESPP, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Pursuant to the ESPP’s “evergreen” provision, on December 31 of each year, the number of shares available under the ESPP increases by up to 0.6 million shares, provided that the total number of shares available at that time shall not exceed 8.2 million. Unless earlier terminated, the ESPP will terminate on January 24, 2023.

[0000936395-18-000048:notes:146]
During fiscal 2018, fiscal 2017 and fiscal 2016, Ciena issued 1.1 million, 1.0 million and 1.1 million shares under the ESPP, respectively. At October 31, 2018, 4.9 million shares remained available for issuance under the ESPP.

[0000936395-18-000048:notes:147]
Share-Based Compensation Expense

[0000936395-18-000048:notes:148]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-18-000048:notes:149]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Product cost of goods sold | $ | 2,984 |  |  | $ | 2,672 |  |  | $ | 2,457 |  |
| Service cost of goods sold | 2,616 |  |  | 2,487 |  |  | 2,479 |  |
| Share-based compensation expense included in cost of goods sold | 5,600 |  |  | 5,159 |  |  | 4,936 |  |
| Research and development | 13,518 |  |  | 12,957 |  |  | 13,870 |  |
| Sales and marketing | 14,246 |  |  | 12,846 |  |  | 15,138 |  |
| General and administrative | 19,709 |  |  | 17,321 |  |  | 17,342 |  |
| Acquisition and integration costs | — |  |  | — |  |  | 714 |  |
| Share-based compensation expense included in operating expense | 47,473 |  |  | 43,124 |  |  | 47,064 |  |
| Share-based compensation expense capitalized in inventory, net | (101 | ) |  | 77 |  |  | (7 | ) |
| Total share-based compensation | $ | 52,972 |  |  | $ | 48,360 |  |  | $ | 51,993 |  |

[0000936395-18-000048:notes:150]
As of October 31, 2018, total unrecognized share-based compensation expense was $77.3 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.45 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-18-000048:notes:151]
Ciena calculates basic earnings per share (“EPS”) by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 18 below.


## us-gaap:EarningsPerShareTextBlock

[0000936395-18-000048:notes:152]
EARNINGS (LOSS) PER SHARE CALCULATION

[0000936395-18-000048:notes:153]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of restricted stock units, (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method, (iv) shares underlying Ciena’s outstanding convertible notes for which Ciena uses the treasury stock method (New Notes), and (v) shares underlying Ciena’s outstanding convertible notes for which Ciena uses the if-converted method.

[0000936395-18-000048:notes:154]
Numerator

[0000936395-18-000048:notes:155]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Net income (loss) | $ | (344,690 | ) |  | $ | 1,261,953 |  |  | $ | 72,584 |  |
| Less: Loss on fair value of debt conversion liability (1) | (12,894 | ) |  | — |  |  | — |  |
| Add: Interest expense associated with 0.875% Convertible Senior Notes due 2017 | — |  |  | 853 |  |  | 4,801 |  |
| Add: Interest expense associated with 3.75% Convertible Senior Notes due 2018 (Original Notes) | — |  |  | 7,224 |  |  | — |  |
| Add: Interest expense associated with 4.0% Convertible Senior Notes due 2020 | — |  |  | 8,691 |  |  | — |  |
| Net income (loss) used to calculate Diluted EPS | $ | (357,584 | ) |  | $ | 1,278,721 |  |  | $ | 77,385 |  |

[0000936395-18-000048:notes:156]
Denominator

[0000936395-18-000048:notes:157]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Basic weighted average shares outstanding | 143,738 |  |  | 141,997 |  |  | 138,312 |  |
| Add: Shares underlying outstanding stock options, employee stock purchase plan and restricted stock units | — |  |  | 1,354 |  |  | 1,311 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New Notes) | — |  |  | 404 |  |  | — |  |
| Add: Shares underlying 0.875% Convertible Senior Notes due 2017 | — |  |  | 3,032 |  |  | 11,081 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (Original Notes) | — |  |  | 13,934 |  |  | — |  |
| Add: Shares underlying 4.0% Convertible Senior Notes due 2020 | — |  |  | 9,198 |  |  | — |  |
| Diluted weighted average shares outstanding | 143,738 |  |  | 169,919 |  |  | 150,704 |  |

[0000936395-18-000048:notes:158]
| (1) | On October 15, 2018, we settled our New Notes with an aggregate principal amount of $288.7 million. It was our intent to settle the principal amount of the New Notes in cash; accordingly, the principal amount was excluded from the determination of diluted earnings per share. On August 21, 2018, we changed our policy and decided to settle the payment of the conversion premium in cash and stock; see Note 16 above. Prior to this change, for EPS purposes we accounted for the conversion feature using the treasury stock method by adjusting the diluted weighted-average common shares if the effect was dilutive. As a consequence of our change in policy described above, the numerator for the computation of diluted earnings per common share was adjusted for any dilutive changes in the estimated value of the debt conversion liability during the period of August 20, 2018 through August 30, 2018, the date at which we began to account for the conversion feature as a derivative. There were no adjustments to diluted weighted average shares outstanding subsequent to our change in policy. See Note 14 above. For the fiscal year ended October 31, 2018, the adjustment to the numerator had the effect of reducing the diluted earnings per share by $0.09. |

[0000936395-18-000048:notes:159]
EPS

[0000936395-18-000048:notes:160]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Basic EPS | $ | (2.40 | ) |  | $ | 8.89 |  |  | $ | 0.52 |  |
| Diluted EPS | $ | (2.49 | ) |  | $ | 7.53 |  |  | $ | 0.51 |  |

[0000936395-18-000048:notes:161]
The following table summarizes the weighted average shares excluded from the calculation of the denominator for Diluted EPS due to their anti-dilutive effect for the fiscal years indicated (in thousands):

[0000936395-18-000048:notes:162]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Shares underlying stock options and restricted stock units | 2,235 |  |  | 958 |  |  | 1,882 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New Notes) | 1,780 |  |  | — |  | — |  | — |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original Notes) | 2,883 |  |  | — |  |  | 17,355 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,123 |  |  | — |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 16,021 |  |  | 958 |  |  | 28,435 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-18-000048:notes:163]
As of the dates indicated, the following tables summarize the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0000936395-18-000048:notes:164]
|  | October 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 590,684 |  |  | $ | — |  |  | $ | — |  |  | $ | 590,684 |  |
| U.S. government obligations | — |  |  | 197,988 |  |  | — |  |  | 197,988 |  |
| Commercial paper | — |  |  | 69,888 |  |  | — |  |  | 69,888 |  |
| Foreign currency forward contracts | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Forward starting interest rate swaps | — |  |  | 779 |  |  | — |  |  | 779 |  |
| Total assets measured at fair value | $ | 590,684 |  |  | $ | 268,788 |  |  | $ | — |  |  | $ | 859,472 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,231 |  |  | $ | — |  |  | $ | 3,231 |  |
| Debt conversion liability | — |  |  | 164,212 |  |  | — |  |  | 164,212 |  |
| Contingent consideration | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 167,443 |  |  | $ | 10,900 |  |  | $ | 178,343 |  |

[0000936395-18-000048:notes:165]
|  | October 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 511,355 |  |  | $ | — |  |  | $ | — |  |  | $ | 511,355 |  |
| U.S. government obligations | — |  |  | 298,976 |  |  | — |  |  | 298,976 |  |
| Commercial paper | — |  |  | 89,865 |  |  | — |  |  | 89,865 |  |
| Foreign currency forward contracts | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Forward starting interest rate swaps | — |  |  | 218 |  |  | — |  |  | 218 |  |
| Total assets measured at fair value | $ | 511,355 |  |  | $ | 389,286 |  |  | $ | — |  |  | $ | 900,641 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-18-000048:notes:166]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheet as follows (in thousands):

[0000936395-18-000048:notes:167]
|  | October 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 590,684 |  |  | $ | 59,925 |  |  | $ | — |  |  | $ | 650,609 |  |
| Short-term investments | — |  |  | 148,981 |  |  | — |  |  | 148,981 |  |
| Prepaid expenses and other | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Long-term investments | — |  |  | 58,970 |  |  | — |  |  | 58,970 |  |
| Other long-term assets | — |  |  | 779 |  |  | — |  |  | 779 |  |
| Total assets measured at fair value | $ | 590,684 |  |  | $ | 268,788 |  |  | $ | — |  |  | $ | 859,472 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 3,231 |  |  | $ | — |  |  | $ | 3,231 |  |
| Debt conversion liability | — |  |  | 164,212 |  |  | — |  |  | 164,212 |  |
| Other long-term obligations | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 167,443 |  |  | $ | 10,900 |  |  | $ | 178,343 |  |

[0000936395-18-000048:notes:168]
|  | October 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 511,355 |  |  | $ | 59,925 |  |  | $ | — |  |  | $ | 571,280 |  |
| Short-term investments | — |  |  | 279,133 |  |  | — |  |  | 279,133 |  |
| Prepaid expenses and other | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Long-term investments | — |  |  | 49,783 |  |  | — |  |  | 49,783 |  |
| Other long-term assets | — |  |  | 218 |  |  | — |  |  | 218 |  |
| Total assets measured at fair value | $ | 511,355 |  |  | $ | 389,286 |  |  | $ | — |  |  | $ | 900,641 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-18-000048:notes:169]
FAIR VALUE MEASUREMENTS

[0000936395-18-000048:notes:170]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000936395-18-000048:notes:171]
Ciena’s Level 3 liability is included in other long-term obligations and reflects a contingent consideration element of a three-year payout arrangement associated with Ciena’s purchase of DonRiver in the fourth quarter of fiscal 2018. See Note 2 above. The contingent consideration is valued by applying the income approach based upon a discounted cash flow technique using Monte Carlo simulations. As of October 31, 2018, there was no change to the fair value.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-18-000048:notes:172]
Certain of Ciena’s foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders’ equity. Where the monetary assets and liabilities are transacted in a currency other than the entity’s functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statement of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-18-000048:notes:173]
GOODWILL

[0000936395-18-000048:notes:174]
The following table presents the goodwill allocated to our operating segments as of October 31, 2018 and October 31, 2017, as well as the changes to goodwill during fiscal 2018. (in thousands):

[0000936395-18-000048:notes:175]
|  | Balance at October 31, 2017 |  | Acquisitions |  | Impairments |  | Translation |  | Balance at October 31, 2018 |
| Software and Software-Related Services | $ | 201,428 |  |  | $ | 30,757 |  |  | $ | — |  |  | $ | — |  |  | $ | 232,185 |  |
| Networking Platforms | 66,030 |  |  | — |  |  | — |  |  | (247 | ) |  | 65,783 |  |
| Total | $ | 267,458 |  |  | $ | 30,757 |  |  | $ | — |  |  | $ | (247 | ) |  | $ | 297,968 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-18-000048:notes:176]
Long-lived assets include: equipment, building, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset’s carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena’s long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-18-000048:notes:177]
INCOME TAXES

[0000936395-18-000048:notes:178]
For the periods indicated, the provision (benefit) for income taxes consists of the following (in thousands):

[0000936395-18-000048:notes:179]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Provision (benefit) for income taxes: |  |  |  |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | 8,327 |  |  | $ | — |  |  | $ | — |  |
| State | 8,219 |  |  | 6,342 |  |  | 5,281 |  |
| Foreign | 13,294 |  |  | 14,563 |  |  | 9,969 |  |
| Total current | 29,840 |  |  | 20,905 |  |  | 15,250 |  |
| Deferred: |  |  |  |  |  |
| Federal | 475,951 |  | (1) | (1,047,699 | ) | (1 | ) | — |  |
| State | (8,202 | ) |  | (77,429 | ) | (1 | ) | — |  |
| Foreign | (4,118 | ) |  | (1,604 | ) |  | (1,116 | ) |
| Total deferred | 463,631 |  |  | (1,126,732 | ) |  | (1,116 | ) |
| Provision (benefit) for income taxes | $ | 493,471 |  |  | $ | (1,105,827 | ) |  | $ | 14,134 |  |

[0000936395-18-000048:notes:180]
_________________________________

[0000936395-18-000048:notes:181]
(1)  The income tax expense for 2018 includes the impact of the remeasurement of the net deferred tax assets and the federal transition tax. See further discussion below. The income tax benefit for fiscal 2017 includes the reversal of a significant portion of the valuation allowance on Ciena’s deferred tax assets in the U.S. as described below.

[0000936395-18-000048:notes:182]
For the periods indicated, income before provision for income taxes consists of the following (in thousands):

[0000936395-18-000048:notes:183]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| United States | $ | 106,972 |  |  | $ | 114,242 |  |  | $ | 58,237 |  |
| Foreign | 41,809 |  |  | 41,884 |  |  | 28,481 |  |
| Total | $ | 148,781 |  |  | $ | 156,126 |  |  | $ | 86,718 |  |

[0000936395-18-000048:notes:184]
Ciena’s foreign income tax as a percentage of foreign income may appear disproportionate compared to the expected tax based on the U.S. federal statutory rate and is dependent upon the mix of earnings and tax rates in foreign jurisdictions.

[0000936395-18-000048:notes:185]
For the periods indicated, the tax provision (benefit) reconciles to the amount computed by multiplying income before income taxes by the U.S. federal statutory rate of 35% (23.41% for fiscal 2018, see note below) as follows:

[0000936395-18-000048:notes:186]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Provision at statutory rate | 23.41 | % |  | 35.00 | % |  | 35.00 | % |
| Deferred tax assets remeasurement | 294.56 | % |  | — | % |  | — | % |
| State taxes | (0.16 | )% |  | 2.29 | % |  | 4.00 | % |
| Foreign taxes | 1.22 | % |  | (0.35 | )% |  | 3.11 | % |
| Research and development credit | (8.80 | )% |  | (15.38 | )% |  | (22.61 | )% |
| Non-deductible compensation | 3.39 | % |  | 3.45 | % |  | 5.16 | % |
| Fair value of debt conversion liability | 1.90 | % |  | — | % |  | — | % |
| Transition tax | 23.23 | % |  | — | % |  | — | % |
| Valuation allowance | (11.95 | )% |  | (739.97 | )% |  | (7.33 | )% |
| Other | 4.88 | % |  | 6.67 | % |  | (1.03 | )% |
| Effective income tax rate | 331.68 | % |  | (708.29 | )% |  | 16.30 | % |

[0000936395-18-000048:notes:187]
On December 22, 2017, the Tax Cuts and Jobs Act (the “Tax Act”) was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (the “federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries that were previously tax deferred. As a fiscal-year taxpayer, certain provisions of the Tax Act impact Ciena in fiscal 2018, including the change in the federal tax rate and the one-time transition tax, while other provisions will be effective at the beginning of fiscal 2019, including the implementation of a modified territorial tax system, other changes to how foreign earnings are subject to U.S. tax, and adoption of an alternative tax system.

[0000936395-18-000048:notes:188]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, Ciena has computed its income tax expense for the October 31, 2018 fiscal year using a blended federal tax rate of 23.41%. Ciena remeasured its deferred tax assets and liabilities (“DTA”) using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000936395-18-000048:notes:189]
During fiscal 2018, Ciena recorded a tax expense of $493.5 million, primarily related to the Tax Act which consists of the following:

[0000936395-18-000048:notes:190]
| • | a $438.2 million charge related to the remeasurement of U.S. net deferred tax assets at the lower statutory rate under the Tax Act; and |

[0000936395-18-000048:notes:191]
| • | a $34.6 million charge related to a transition tax on accumulated historical foreign earnings and its deemed repatriation to the U.S. |

[0000936395-18-000048:notes:192]
In December 2017, the SEC issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional amounts when it does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes due to the Tax Act. The measurement period ends when a company has obtained, prepared and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above amounts to the extent they are provisional due to changes in interpretations of the Tax Act, legislative action to address questions that arise because of the Tax Act, changes in accounting standards for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. In the fourth quarter of fiscal 2018, Ciena recorded a $10.5 million benefit to the provisional amounts originally recorded in the first quarter of fiscal 2018 related to the U.S transition tax on accumulated earnings of foreign subsidiaries. Ciena has determined that the $34.6 million of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries is a provisional amount and a reasonable estimate as of October 31, 2018. Ciena is able to reduce the transition tax payable through the utilization of research and development credits which previously had a valuation allowance. The net transition tax payable is $8.6 million. Ciena has further determined that the $438.2 million of tax expense for DTA remeasurement is complete. Ciena is also required to make accounting policy elections as a result of the Tax Act. These include whether a valuation allowance is recorded for the estimated effect of the application of GILTI and BEAT or if these will be treated as period costs when incurred. Ciena has made an accounting policy election to record an $8.6 million provisional valuation allowance against the U.S. NOL due to an anticipated incremental cash tax cost projected to be generated by the new GILTI tax rules that begin to apply to Ciena in fiscal 2019. Ciena’s analysis of the new BEAT rules, as well as the very recent regulatory guidance and how they may impact the company, continue to progress. Accordingly, Ciena has not made an accounting policy election on whether to establish a valuation allowance for the estimated impact for BEAT. Ciena is also required to elect to either treat taxes due on future GILTI inclusions in U.S. taxable income as a current period expense when incurred or reflect such portion of the future GILTI inclusions in U.S. taxable income that relate to existing basis differences in Ciena’s current measurement of deferred taxes. Ciena’s accounting policy election is to treat the taxes due on future U.S. inclusions in taxable income under GILTI as a period cost when incurred.

[0000936395-18-000048:notes:193]
The significant components of deferred tax assets and liabilities are as follows (in thousands):

[0000936395-18-000048:notes:194]
|  | October 31, |
|  | 2018 |  | 2017 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 40,959 |  |  | $ | 56,597 |  |
| Depreciation and amortization | 353,838 |  |  | 451,385 |  |
| NOL and credit carry forward | 483,495 |  |  | 803,622 |  |
| Other | 9,397 |  |  | 29,398 |  |
| Gross deferred tax assets | 887,689 |  |  | 1,341,002 |  |
| Valuation allowance | (142,650 | ) |  | (185,898 | ) |
| Deferred tax asset, net of valuation allowance | $ | 745,039 |  |  | $ | 1,155,104 |  |

[0000936395-18-000048:notes:195]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0000936395-18-000048:notes:196]
|  | Amount |
| Unrecognized tax benefits at October 31, 2015 | $ | 27,536 |  |
| Increase related to positions taken in prior period | 2,187 |  |
| Increase related to positions taken in current period | 2,654 |  |
| Reductions related to expiration of statute of limitations | (1,709 | ) |
| Unrecognized tax benefits at October 31, 2016 | 30,668 |  |
| Increase related to positions taken in prior period | 122 |  |
| Increase related to positions taken in current period | 111,412 |  |
| Reductions related to expiration of statute of limitations | (620 | ) |
| Unrecognized tax benefits at October 31, 2017 | 141,582 |  |
| Decrease related to positions taken in prior period | (46,400 | ) |
| Increase related to positions taken in current period | 2,482 |  |
| Reductions related to expiration of statute of limitations | (1,301 | ) |
| Unrecognized tax benefits at October 31, 2018 | $ | 96,363 |  |

[0000936395-18-000048:notes:197]
As of October 31, 2018 and 2017, Ciena had accrued $3.5 million and $4.0 million of interest and penalties, respectively, related to unrecognized tax benefits within other long-term liabilities in the Consolidated Balance Sheets. Interest and penalties of $1.1 million and $1.2 million were recorded to the provision for income taxes during fiscal 2018 and fiscal 2016, respectively. During fiscal 2017, Ciena recorded a net benefit for interest and penalties in its provision for income taxes of $0.6 million, primarily as a result of recognizing a portion of previously unrecognized tax benefits. If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate. Over the next 12 months, Ciena does not estimate any material changes in unrecognized income tax benefits.

[0000936395-18-000048:notes:198]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest these foreign earnings outside the U.S. As of October 31, 2018, the cumulative amount of such temporary differences for which a deferred tax liability has not been recognized is an estimated $336 million. If these earnings were distributed to the U.S., Ciena would be subject to additional foreign withholding taxes of approximately $23.0 million.  Additionally, there are no other significant temporary differences for which a deferred tax liability has not been recognized.

[0000936395-18-000048:notes:199]
As of October 31, 2018, Ciena continues to maintain a valuation allowance against net deferred tax assets of $142.7 million primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use.

[0000936395-18-000048:notes:200]
The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0000936395-18-000048:notes:201]
| Year ended |  | Beginning |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Additions |  | Deductions |  | Balance |
| 2016 |  | $ | 1,495,672 |  |  | $ | — |  |  | $ | 5,892 |  |  | $ | 1,489,780 |  |
| 2017 |  | $ | 1,489,780 |  |  | $ | — |  |  | $ | 1,303,882 |  |  | $ | 185,898 |  |
| 2018 |  | $ | 185,898 |  |  | $ | 23,720 |  |  | $ | 66,968 |  |  | $ | 142,650 |  |

[0000936395-18-000048:notes:202]
As of October 31, 2018, Ciena had a $1.27 billion net operating loss carry forward and a $0.1 billion income tax credit carry forward which both begin to expire in fiscal year 2021. Ciena’s ability to use net operating losses and credit carry forwards is subject to limitations pursuant to the ownership change rules of the Internal Revenue Code Section 382.

[0000936395-18-000048:notes:203]
Ciena adopted ASU 2016-09, Improvements to Employee Share-Based Payment Accounting, in the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018.


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-18-000048:notes:204]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based upon the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-18-000048:notes:205]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 and 2014 through 2017, and in Canada for 2011 through 2015. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2015), United Kingdom (2015), Canada (2011), India (2012) and Brazil (2013). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-18-000048:notes:206]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest these foreign earnings outside the U.S. As of October 31, 2018, the cumulative amount of such temporary differences for which a deferred tax liability has not been recognized totaled approximately $336 million. If these earnings were distributed to the U.S. in the form of dividends, or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, Ciena would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes.

[0000936395-18-000048:notes:207]
Ciena is required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-18-000048:notes:208]
The Tax Act includes provisions that do not affect Ciena in fiscal 2018, including a provision designed to tax global intangible low-taxed income (“GILTI”). Due to the complexity of the GILTI tax rules, this provision and related tax accounting will continue to be evaluated. An accounting policy choice is allowed to either treat taxes due on future U.S. inclusions related to GILTI in taxable income as a current-period expense when incurred (the “period cost method”) or factor such amounts into the measurement of deferred taxes (the “deferred method”). The calculation of the deferred balance with respect to the new GILTI tax provisions will depend, in part, on analyzing global income to determine whether future U.S. inclusions in taxable income are expected related to GILTI and, if so, what the impact is expected to be. Ciena is electing to use the period cost method for future GILTI inclusions. Additionally, Ciena is electing to use the incremental cash tax savings approach when determining whether a valuation allowance needs to be recorded against the U.S. net operating loss (“NOL”) due to the GILTI inclusions.

[0000936395-18-000048:notes:209]
The Tax Act also introduced an alternative tax known as the base erosion and anti-abuse tax (BEAT).  An accounting policy choice can be made on whether or not to consider the impact of BEAT on its valuation allowance.  Ciena continues to evaluate very recent regulatory guidance in order to assess its impact.  Accordingly, an accounting policy choice has not yet been made.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-18-000048:notes:210]
INTANGIBLE ASSETS

[0000936395-18-000048:notes:211]
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-18-000048:notes:212]
|  | October 31, |
|  | 2018 |  | 2017 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 373,581 |  |  | $ | (285,233 | ) |  | $ | 88,348 |  |  | $ | 341,255 |  |  | $ | (266,693 | ) |  | $ | 74,562 |  |
| In-process research and development | — |  |  | — |  |  | — |  |  | 671 |  |  | — |  |  | 671 |  |
| Patents and licenses | 3,565 |  |  | (1,958 | ) |  | 1,607 |  |  | 7,165 |  |  | (6,535 | ) |  | 630 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 374,620 |  |  | (316,350 | ) |  | 58,270 |  |  | 334,642 |  |  | (309,508 | ) |  | 25,134 |  |
| Total intangible assets | $ | 751,766 |  |  | $ | (603,541 | ) |  | $ | 148,225 |  |  | $ | 683,733 |  |  | $ | (582,736 | ) |  | $ | 100,997 |  |

[0000936395-18-000048:notes:213]
During fiscal 2018 and 2017, certain fully amortized intangible assets of approximately $5.0 million and $34.0 million, respectively, were eliminated from gross intangible assets and accumulated amortization during the period, with no corresponding impact to the income statement. These assets were primarily technology for products no longer being sold by Ciena.

[0000936395-18-000048:notes:214]
The aggregate amortization expense of intangible assets was $25.8 million, $45.7 million and $78.3 million for fiscal 2018, fiscal 2017 and fiscal 2016, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-18-000048:notes:215]
| Year Ended October 31, |  |
| 2019 | $ | 35,375 |  |
| 2020 | 34,019 |  |
| 2021 | 30,841 |  |
| 2022 | 24,820 |  |
| 2023 | 10,011 |  |
| Thereafter | 13,159 |  |
|  | $ | 148,225 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-18-000048:notes:216]
INVENTORIES

[0000936395-18-000048:notes:217]
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-18-000048:notes:218]
|  | October 31, |
|  | 2018 |  | 2017 |
| Raw materials | $ | 67,468 |  |  | $ | 52,898 |  |
| Work-in-process | 9,589 |  |  | 18,623 |  |
| Finished goods | 188,575 |  |  | 185,488 |  |
| Deferred cost of goods sold | 48,057 |  |  | 61,340 |  |
|  | 313,689 |  |  | 318,349 |  |
| Provision for excess and obsolescence | (50,938 | ) |  | (51,206 | ) |
|  | $ | 262,751 |  |  | $ | 267,143 |  |

[0000936395-18-000048:notes:219]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During fiscal 2018, fiscal 2017 and fiscal 2016, Ciena recorded a provision for excess and obsolescence of $30.6 million, $35.5 million, and $33.7 million, respectively, primarily related to the decrease in the forecasted demand for certain Converged Packet Optical products. Deductions from the provision for excess and obsolete inventory relate to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-18-000048:notes:220]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0000936395-18-000048:notes:221]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions.


## us-gaap:InvestmentPolicyTextBlock

[0000936395-18-000048:notes:222]
Ciena’s investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena’s cost basis, and Ciena’s intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

[0000936395-18-000048:notes:223]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of October 31, 2018, the combined carrying value of these investments was $8.1 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-18-000048:notes:224]
The following table summarizes the legal maturities of debt investments at October 31, 2018:

[0000936395-18-000048:notes:225]
|  | October 31, 2018 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 149,328 |  |  | $ | 148,981 |  |
| Due in 1-2 years | 59,029 |  |  | 58,970 |  |
|  | $ | 208,357 |  |  | $ | 207,951 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-18-000048:notes:226]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-18-000048:notes:227]
As of October 31, 2018, investments are comprised of the following (in thousands):

[0000936395-18-000048:notes:228]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |

[0000936395-18-000048:notes:229]
As of October 31, 2017, investments are comprised of the following (in thousands):

[0000936395-18-000048:notes:230]
|  | October 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 249,498 |  |  | $ | — |  |  | $ | (305 | ) |  | $ | 249,193 |  |
| Included in long-term investments | 49,910 |  |  | — |  |  | (127 | ) |  | 49,783 |  |
|  | $ | 299,408 |  |  | $ | — |  |  | $ | (432 | ) |  | $ | 298,976 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |
|  | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-18-000048:notes:231]
Ciena expenses legal costs associated with litigation as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-18-000048:notes:232]
ACCOUNTS RECEIVABLE

[0000936395-18-000048:notes:233]
Accounts receivable includes $40.9 million and $26.1 million of unbilled receivables as October 31, 2018 and October 31, 2017, respectively.  As of October 31, 2018, one customer accounted for 10.0% of net accounts receivable. As of October 31, 2017, two customers together accounted for 23.0% of net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. During fiscal 2017, Ciena’s allowance for doubtful accounts includes a provision for a significant asset impairment of $13.7 million for a trade receivable related to a single customer in the APAC region. The following table summarizes the activity in Ciena’s allowance for doubtful accounts for the fiscal years indicated (in thousands):

[0000936395-18-000048:notes:234]
| Year ended |  | Beginning |  |  |  | Net |  | Ending |
| October 31, |  | Balance |  | Provisions |  | Deductions |  | Balance |
| 2016 |  | $ | 2,963 |  |  | $ | 1,701 |  |  | $ | 701 |  |  | $ | 3,963 |  |
| 2017 |  | $ | 3,963 |  |  | $ | 18,221 |  |  | $ | 4,604 |  |  | $ | 17,580 |  |
| 2018 |  | $ | 17,580 |  |  | $ | 2,700 |  |  | $ | 2,902 |  |  | $ | 17,378 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-18-000048:notes:235]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-01 (“ASU 2017-01”), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. Ciena adopted ASU 2017-01 during the first quarter of fiscal 2018.

[0000936395-18-000048:notes:236]
In August 2017, the FASB issued ASU No. 2017-12 (“ASU 2017-12”), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity’s risk management activities and financial reporting for hedging relationships, through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. Ciena adopted ASU 2017-12 during the first quarter of fiscal 2018. For hedges for which Ciena has elected to exclude the spot-forward difference from assessment of effectiveness, Ciena has elected to amortize the difference on a straight-line basis. Ciena will record amortization in earnings each period with an offsetting entry to other comprehensive income, and all changes in fair value over the term of the derivative in other comprehensive income. The application of this accounting standard did not have a material impact on Ciena’s Consolidated Financial Statements.

[0000936395-18-000048:notes:237]
In March 2016, the FASB issued ASU No. 2016-09 (“ASU 2016-09”), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. Ciena adopted ASU 2016-09 during the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to accumulated deficit as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening accumulated deficit in the first quarter of fiscal 2018.

[0000936395-18-000048:notes:238]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-18-000048:notes:239]
In May 2014, the FASB issued Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers,  a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP on revenue recognition and eliminated industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000936395-18-000048:notes:240]
For multiple element software arrangements where vendor-specific objective evidence (“VSOE”) of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. The adoption of ASC 606 will require Ciena to determine the stand alone selling price for each of the software and software-related deliverables at contract inception, and Ciena consequently notes that certain software deliverables will be recognized at a point in time rather than over a period of time.

[0000936395-18-000048:notes:241]
Ciena also notes that certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

[0000936395-18-000048:notes:242]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.

[0000936395-18-000048:notes:243]
Ciena elected to implement ASC 606 using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of accumulated deficit. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASC 606 will be effective for Ciena beginning in the first quarter of fiscal 2019.

[0000936395-18-000048:notes:244]
Upon adopting ASC 606 at the beginning of fiscal 2019, the cumulative effect adjustment will reduce accumulated deficit by approximately $49.2 million. This cumulative effect adjustment is primarily driven by a reduction to deferred product revenue of approximately $30.2 million related to software arrangements and an increase to unbilled accounts receivable of approximately $29.6 million primarily related to installation and deployment and consulting and network design service arrangements, with additional amounts related to hardware sales and other adjustments. In addition to the adjustment to deferred revenue and unbilled accounts receivable, other adjustments at transition include immaterial adjustments to billed accounts receivable, deferred product costs, prepaid service costs and other current and non-current assets, and other liabilities. The adjustment to other current and non-current assets is primarily for capitalized incremental contract acquisitions costs. The cumulative effect adjustment is recorded net of tax with the direct tax effect recorded primarily as an increase in deferred tax liability.

[0000936395-18-000048:notes:245]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

[0000936395-18-000048:notes:246]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Adoption of ASU 2018-13 will not have a material effect on Ciena’s financial position or results of operations.

[0000936395-18-000048:notes:247]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. ASU 2018-15 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its Consolidated Financial Statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000936395-18-000048:notes:248]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES

[0000936395-18-000048:notes:249]
Description of Business

[0000936395-18-000048:notes:250]
Ciena Corporation (“Ciena” or the “Company”) is a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. Ciena provides network hardware, software and services that support the transport, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Ciena’s solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions and other emerging network operators.

[0000936395-18-000048:notes:251]
Ciena’s solutions include a diverse portfolio of high-capacity Networking Platform products, which can be applied from the network core to network access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. Ciena also offers Platform Software that provides management and domain control of our next-generation packet and optical platforms and automates network lifecycle operations including provisioning equipment and services. In addition, through its comprehensive suite of Blue Planet Automation Software, Ciena enables network operators to use network data and analytics to drive enhanced automation across multi-vendor and multi-domain network environments, accelerate service delivery and enable an increasingly predictive and autonomous network infrastructure. To complement its hardware and software solutions, Ciena offers broad range of attached and software-related services that help customers design, optimize, integrate, deploy, manage and maintain their networks and associated operational environments. Ciena’s complete portfolio of solutions enables customers to transform their network into a dynamic, programmable environment driven by automation and analytics, which Ciena refers to as the Adaptive Network. Ciena’s solutions for the Adaptive Network create business and operational value for customers, enabling them to introduce new revenue-generating services, reduce costs and maximize the return on their network infrastructure investment.

[0000936395-18-000048:notes:252]
Basis of Presentation

[0000936395-18-000048:notes:253]
Ciena has a 52 or 53 week fiscal year, which ends on the Saturday nearest to the last day of October in each year (November 3, 2018, October 28, 2017 and October 29, 2016 for the periods reported). Fiscal 2018 consisted of a 53-week fiscal year. Fiscal 2017 and fiscal 2016 each consisted of a 52-week fiscal year. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31.

[0000936395-18-000048:notes:254]
Business Combinations

[0000936395-18-000048:notes:255]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed, in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Ciena’s estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-18-000048:notes:256]
Use of Estimates

[0000936395-18-000048:notes:257]
The preparation of the financial statements and related disclosures in conformity with Generally Accepted Accounting Principles (“GAAP”) requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-18-000048:notes:258]
Cash and Cash Equivalents

[0000936395-18-000048:notes:259]
Investments

[0000936395-18-000048:notes:260]
Inventories

[0000936395-18-000048:notes:261]
Segment Reporting

[0000936395-18-000048:notes:262]
Ciena’s chief operating decision maker, its chief executive officer, evaluates the company’s performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 22 below.

[0000936395-18-000048:notes:263]
Goodwill

[0000936395-18-000048:notes:264]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-18-000048:notes:265]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill.  If this test indicates that the fair value is less than the carrying value, then step two requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit’s carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-18-000048:notes:266]
Long-lived Assets

[0000936395-18-000048:notes:267]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0000936395-18-000048:notes:268]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

[0000936395-18-000048:notes:269]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two to five years.

[0000936395-18-000048:notes:270]
Intangible Assets

[0000936395-18-000048:notes:271]
Ciena has recorded finite-lived intangible assets as a result of several acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

[0000936395-18-000048:notes:272]
Ciena has recorded in-process research and development projects acquired as the result of an acquisition as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the asset, which will be determined on that date. Should the project be determined to be abandoned, and if the asset developed has no alternative use, the full value of the asset will be charged to expense.

[0000936395-18-000048:notes:273]
Maintenance Spares

[0000936395-18-000048:notes:274]
Concentrations

[0000936395-18-000048:notes:275]
Revenue Recognition

[0000936395-18-000048:notes:276]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer’s payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-18-000048:notes:277]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

[0000936395-18-000048:notes:278]
Ciena limits the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

[0000936395-18-000048:notes:279]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. Ciena determines the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, Ciena uses vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third-party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, Ciena uses its best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-18-000048:notes:280]
VSOE, when determinable, is established based on Ciena’s pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service falls within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

[0000936395-18-000048:notes:281]
Warranty Accruals

[0000936395-18-000048:notes:282]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based upon actual warranty cost experience, estimates of component failure rates and management’s industry experience. Ciena’s sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

[0000936395-18-000048:notes:283]
Accounts Receivable, Net

[0000936395-18-000048:notes:284]
Accounts receivable includes both billed accounts receivable and unbilled accounts receivable due from customers. Unbilled accounts receivable is derived from contract arrangements whereby the billing term is post the revenue recognition term. Ciena’s allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from them. In determining the appropriate balance for Ciena’s allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer’s financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer,  which could negatively affect its results of operations.

[0000936395-18-000048:notes:285]
Research and Development

[0000936395-18-000048:notes:286]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third-party services, depreciation, facility costs and information technology.

[0000936395-18-000048:notes:287]
Government Grants

[0000936395-18-000048:notes:288]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statement of Operations to which the grant activity relates. See Note 24 below.

[0000936395-18-000048:notes:289]
Advertising Costs

[0000936395-18-000048:notes:290]
Legal Costs

[0000936395-18-000048:notes:291]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena’s stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena’s determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 21 below.

[0000936395-18-000048:notes:292]
Income Taxes

[0000936395-18-000048:notes:293]
Loss Contingencies

[0000936395-18-000048:notes:294]
Fair Value of Financial Instruments

[0000936395-18-000048:notes:295]
The carrying value of Ciena’s cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena’s convertible notes and term loans, see Note 16 below.

[0000936395-18-000048:notes:296]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000936395-18-000048:notes:297]
| • | Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities; |

[0000936395-18-000048:notes:298]
| • | Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0000936395-18-000048:notes:299]
| • | Level 3 inputs are unobservable inputs based on Ciena’s assumptions used to measure assets and liabilities at fair value. |

[0000936395-18-000048:notes:300]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-18-000048:notes:301]
Restructuring

[0000936395-18-000048:notes:302]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 3 below.

[0000936395-18-000048:notes:303]
Foreign Currency

[0000936395-18-000048:notes:304]
Certain of Ciena’s foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders’ equity. Where the monetary assets and liabilities are transacted in a currency other than the entity’s functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statement of Operations. See Note 4 below.

[0000936395-18-000048:notes:305]
Derivatives

[0000936395-18-000048:notes:306]
See Notes 6 and 14 below.

[0000936395-18-000048:notes:307]
Computation of Net Income (Loss) per Share

[0000936395-18-000048:notes:308]
Software Development Costs

[0000936395-18-000048:notes:309]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized using the straight-line method over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-18-000048:notes:310]
Newly Issued Accounting Standards - Effective


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-18-000048:notes:311]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-18-000048:notes:312]
|  | October 31, |
|  | 2018 |  | 2017 |
| Capital lease obligations | $ | 68,245 |  |  | $ | 73,407 |  |
| Income tax liability | 15,894 |  |  | 15,445 |  |
| Deferred tenant allowance | 7,244 |  |  | 8,162 |  |
| Straight-line rent | 6,750 |  |  | 7,267 |  |
| Contingent consideration | 10,900 |  |  | — |  |
| Other | 10,380 |  |  | 7,068 |  |
|  | $ | 119,413 |  |  | $ | 111,349 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-18-000048:notes:313]
INTEREST AND OTHER INCOME (LOSS), NET

[0000936395-18-000048:notes:314]
The components of interest and other income (loss), net, were as follows (in thousands):

[0000936395-18-000048:notes:315]
|  |  | Year Ended October 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Interest income |  | $ | 13,703 |  |  | $ | 6,579 |  |  | $ | 4,058 |  |
| Gain (loss) on non-hedge designated foreign currency forward contracts |  | 6,791 |  |  | (1,198 | ) |  | (23,355 | ) |
| Foreign currency exchange gains (losses) |  | (19,434 | ) |  | (4,376 | ) |  | 5,870 |  |
| Loss on fair value of debt conversion liability |  | (12,070 | ) |  | — |  |  | — |  |
| Other |  | (1,019 | ) |  | (92 | ) |  | 858 |  |
| Interest and other income (loss), net |  | $ | (12,029 | ) |  | $ | 913 |  |  | $ | (12,569 | ) |

[0000936395-18-000048:notes:316]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During fiscal 2018 and fiscal 2017, Ciena recorded $19.4 million and $4.4 million, respectively, in exchange rate losses, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net. For fiscal 2018, the majority of the foreign currency exchange rate losses relate to Ciena’s Brazilian and Argentinian subsidiaries owing U.S. Dollars to Ciena Corporation. In fiscal 2016, Ciena recorded $5.9 million in foreign currency exchange gains. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is also reported in interest and other income (loss), net. During fiscal 2018, Ciena recorded a gain of $6.8 million from non-hedge designated foreign currency forward contracts. For fiscal 2017 and fiscal 2016, Ciena recorded losses of $1.2 million, and $23.4 million respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-18-000048:notes:317]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES

[0000936395-18-000048:notes:318]
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0000936395-18-000048:notes:319]
|  | October 31, |
|  | 2018 |  | 2017 |
| Equipment, furniture and fixtures | $ | 504,714 |  |  | $ | 486,451 |  |
| Building subject to capital lease | 71,968 |  |  | 76,702 |  |
| Leasehold improvements | 94,195 |  |  | 87,763 |  |
|  | 670,877 |  |  | 650,916 |  |
| Accumulated depreciation and amortization | (378,810 | ) |  | (342,451 | ) |
|  | $ | 292,067 |  |  | $ | 308,465 |  |

[0000936395-18-000048:notes:320]
During fiscal 2018, fiscal 2017 and fiscal 2016, Ciena recorded depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements of $75.3 million, $67.2 million and $52.7 million, respectively.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-18-000048:notes:321]
The table below (in thousands) sets forth Ciena’s segment profit and the reconciliation to consolidated net income during the respective periods indicated:

[0000936395-18-000048:notes:322]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Segment profit: |  |  |  |  |  |
| Networking Platforms | $ | 581,113 |  |  | $ | 578,039 |  |  | $ | 544,744 |  |
| Software and Software-Related Services | 69,808 |  |  | 32,536 |  |  | 7,123 |  |
| Global Services | 172,205 |  |  | 159,882 |  |  | 157,915 |  |
| Total segment profit | 823,126 |  |  | 770,457 |  |  | 709,782 |  |
| Less: non-performance operating expenses |  |  |  |  |  |
| Selling and marketing | 394,060 |  |  | 356,169 |  |  | 349,731 |  |
| General and administrative | 160,133 |  |  | 142,604 |  |  | 132,828 |  |
| Amortization of intangible assets | 15,737 |  |  | 33,029 |  |  | 61,508 |  |
| Acquisition and integration costs | 5,111 |  |  | — |  |  | 4,613 |  |
| Significant asset impairments and restructuring costs | 18,139 |  |  | 23,933 |  |  | 4,933 |  |
| Add: other non-performance financial items |  |  |  |  |  |
| Interest and other income (loss), net | (12,029 | ) |  | 913 |  |  | (12,569 | ) |
| Interest expense | (55,249 | ) |  | (55,852 | ) |  | (56,656 | ) |
| Loss on extinguishment and modification of debt | (13,887 | ) |  | (3,657 | ) |  | (226 | ) |
| Less: Provision (benefit) for income taxes | 493,471 |  |  | (1,105,827 | ) |  | 14,134 |  |
| Total net income (loss) | $ | (344,690 | ) |  | $ | 1,261,953 |  |  | $ | 72,584 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-18-000048:notes:323]
The table below (in thousands, except percentage data) sets forth Ciena’s segment revenue for the respective periods indicated:

[0000936395-18-000048:notes:324]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |
| Converged Packet Optical | $ | 2,194,519 |  |  | $ | 1,939,621 |  |  | $ | 1,815,921 |  |
| Packet Networking | 283,499 |  |  | 313,089 |  |  | 252,862 |  |
| Total Networking Platforms | 2,478,018 |  |  | 2,252,710 |  |  | 2,068,783 |  |
| Software and Software-Related Services |  |  |  |  |  |
| Platform Software and Services | 173,949 |  |  | 145,009 |  |  | 117,251 |  |
| Blue Planet Automation Software and Services | 26,764 |  |  | 16,110 |  |  | 7,818 |  |
| Total Software and Software-Related Services | 200,713 |  |  | 161,119 |  |  | 125,069 |  |
| Global Services |  |  |  |  |  |
| Maintenance Support and Training | 245,161 |  |  | 227,400 |  |  | 228,982 |  |
| Installation and Deployment | 128,829 |  |  | 117,524 |  |  | 130,916 |  |
| Consulting and Network Design | 41,565 |  |  | 42,934 |  |  | 46,823 |  |
| Total Global Services | 415,555 |  |  | 387,858 |  |  | 406,721 |  |
| Total revenue | $ | 3,094,286 |  |  | $ | 2,801,687 |  |  | $ | 2,600,573 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-18-000048:notes:325]
RESTRUCTURING COSTS

[0000936395-18-000048:notes:326]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the fiscal years indicated (in thousands):

[0000936395-18-000048:notes:327]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2015 | $ | 591 |  |  | $ | 688 |  |  | $ | 1,279 |  |
| Additional liability recorded | 2,844 |  | (1) | 2,089 |  |  | 4,933 |  |
| Cash payments | (2,567 | ) |  | (807 | ) |  | (3,374 | ) |
| Balance at October 31, 2016 | 868 |  |  | 1,970 |  |  | 2,838 |  |
| Additional liability recorded | 5,883 |  | (2) | 5,432 |  | (4) | 11,315 |  |
| Adjustment to previous estimates | — |  |  | (1,048 | ) |  | (1,048 | ) |
| Cash payments | (5,460 | ) |  | (4,706 | ) |  | (10,166 | ) |
| Balance at October 31, 2017 | 1,291 |  |  | 1,648 |  |  | 2,939 |  |
| Additional liability recorded | 14,853 |  | (3) | 3,890 |  | (5) | 18,743 |  |
| Cash payments | (14,036 | ) |  | (3,799 | ) |  | (17,835 | ) |
| Balance at October 31, 2018 | $ | 2,108 |  |  | $ | 1,739 |  |  | $ | 3,847 |  |
| Current restructuring liabilities | $ | 2,108 |  |  | $ | 502 |  |  | $ | 2,610 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,237 |  |  | $ | 1,237 |  |

[0000936395-18-000048:notes:328]
| (1) | During fiscal 2016, Ciena recorded a charge of $2.8 million of severance and other employee-related costs associated with a workforce reduction of approximately 75 employees. |

[0000936395-18-000048:notes:329]
| (2) | During fiscal 2017, Ciena recorded a charge of $5.9 million of severance and other employee-related costs associated with a workforce reduction of approximately 100 employees. |

[0000936395-18-000048:notes:330]
| (3) | During fiscal 2018, Ciena recorded a charge of $14.9 million of severance and other employee-related costs associated with a workforce reduction of approximately 240 employees. |

[0000936395-18-000048:notes:331]
| (4) | Reflects unfavorable lease commitments and relocation costs incurred in connection with our research and development center facility transitions in Ottawa, Canada. |

[0000936395-18-000048:notes:332]
| (5) | Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California and in Gurgaon, India. |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-18-000048:notes:333]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-18-000048:notes:334]
|  | October 31, |
|  | 2018 |  | 2017 |
| Compensation, payroll related tax and benefits | $ | 140,277 |  |  | $ | 113,272 |  |
| Warranty | 44,740 |  |  | 42,456 |  |
| Vacation | 42,507 |  |  | 39,778 |  |
| Capital lease obligations | 3,547 |  |  | 3,772 |  |
| Interest payable | 1,072 |  |  | 3,612 |  |
| Other | 107,932 |  |  | 120,044 |  |
|  | $ | 340,075 |  |  | $ | 322,934 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-18-000048:notes:335]
The net carrying values of Ciena’s convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-18-000048:notes:336]
The following is a schedule by fiscal years of future minimum lease payments under capital leases and the present value of minimum lease payments as of October 31, 2018 (in thousands):

[0000936395-18-000048:notes:337]
| Year Ending October 31, | Amount |
| 2019 | $ | 8,654 |  |
| 2020 | 7,674 |  |
| 2021 | 7,569 |  |
| 2022 | 7,883 |  |
| 2023 | 8,090 |  |
| Thereafter | 75,413 |  |
| Net minimum capital lease payments | 115,283 |  |
| Less: Amount representing interest | (43,491 | ) |
| Present value of minimum lease payments | 71,792 |  |
| Less: Current portion of present value of minimum lease payments | (3,547 | ) |
| Long-term portion of present value of minimum lease payments | $ | 68,245 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-18-000048:notes:338]
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-18-000048:notes:339]
|  | October 31, |
|  | 2018 |  | 2017 |
| Maintenance spares inventory, net | $ | 45,679 |  |  | $ | 46,872 |  |
| Minority equity investments | 8,056 |  |  | 6,000 |  |
| Forward starting interest rate swaps | 779 |  |  | 218 |  |
| Deferred debt issuance costs, net (1) | 720 |  |  | 1,041 |  |
| Financing receivable | — |  |  | 1,052 |  |
| Other | 16,418 |  |  | 8,410 |  |
|  | $ | 71,652 |  |  | $ | 63,593 |  |

[0000936395-18-000048:notes:340]
(1) Deferred debt issuance costs relate to Ciena’s ABL Credit Facility (described in Note 17 below). The amortization of deferred debt issuance costs for Ciena’s ABL Credit Facility is included in interest expense, and was $0.3 million, $0.3 million and $0.4 million for fiscal 2018, fiscal 2017 and fiscal 2016, respectively.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-18-000048:notes:341]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years indicated (in thousands):

[0000936395-18-000048:notes:342]
| Year ended |  | Beginning |  | Current Year |  |  |  | Ending |
| October 31, |  | Balance |  | Provisions (1) |  | Settlements |  | Balance |
| 2016 |  | $ | 56,654 |  |  | $ | 15,483 |  |  | $ | 19,813 |  |  | $ | 52,324 |  |
| 2017 |  | $ | 52,324 |  |  | $ | 7,965 |  |  | $ | 17,833 |  |  | $ | 42,456 |  |
| 2018 |  | $ | 42,456 |  |  | $ | 20,992 |  |  | $ | 18,708 |  |  | $ | 44,740 |  |

[0000936395-18-000048:notes:343]
(1) As a result of actual failure rates lower than expected, Ciena adjusted its fiscal 2017 provisions for warranty. These adjustments for previous fiscal year provisions had the effect of reducing warranty provisions by $9.7 million and $5.3 million for fiscal 2017 and 2016 respectively. During fiscal 2018, Ciena determined that failure rates for prior estimates remained unchanged, and accordingly did not make any adjustments for previous fiscal year provisions not yet settled. As a result, Ciena’s warranty provision for fiscal 2018 increased as compared to these prior years.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-18-000048:notes:344]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-18-000048:notes:345]
|  | October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| AT&T | $ | 374,576 |  |  | $ | 448,943 |  |  | $ | 479,077 |  |
| Verizon | 318,013 |  |  | 288,048 |  |  | n/a |  |
| Total | $ | 692,589 |  |  | $ | 736,991 |  |  | $ | 479,077 |  |

[0000936395-18-000048:notes:346]
________________________________

[0000936395-18-000048:notes:347]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-18-000048:notes:348]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-18-000048:notes:349]
|  | Year Ended October 31, |
|  | 2018 |  | 2017 |  | 2016 |
| North America | $ | 1,886,450 |  |  | $ | 1,736,047 |  |  | $ | 1,689,263 |  |
| EMEA | 464,876 |  |  | 404,099 |  |  | 393,705 |  |
| CALA | 140,177 |  |  | 164,308 |  |  | 195,085 |  |
| APAC | 602,783 |  |  | 497,233 |  |  | 322,520 |  |
| Total | $ | 3,094,286 |  |  | $ | 2,801,687 |  |  | $ | 2,600,573 |  |

[0000936395-18-000048:notes:350]
For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):

[0000936395-18-000048:notes:351]
|  | October 31, |
|  | 2018 |  | 2017 |
| Canada | $ | 198,028 |  |  | $ | 203,491 |  |
| United States | 75,479 |  |  | 90,482 |  |
| Other International | 18,560 |  |  | 14,492 |  |
| Total | $ | 292,067 |  |  | $ | 308,465 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-18-000048:notes:352]
SEGMENT AND ENTITY WIDE DISCLOSURES

[0000936395-18-000048:notes:353]
Ciena manages its business, measures its performance and allocates its resources based on the following operating segments:

[0000936395-18-000048:notes:354]
| • | Networking Platforms reflects sales of Ciena’s Converged Packet Optical and Packet Networking product lines. |

[0000936395-18-000048:notes:355]
| ◦ | Converged Packet Optical — includes the 6500 Packet-Optical Platform, the 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. As of the first quarter of fiscal 2018, sales of Optical Transport products are also reflected within the Converged Packet Optical product line for all periods presented. |

[0000936395-18-000048:notes:356]
| ◦ | Packet Networking — includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics. |

[0000936395-18-000048:notes:357]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations.

[0000936395-18-000048:notes:358]
•Software and Software-Related Services reflects sales of the following:

[0000936395-18-000048:notes:359]
| ◦ | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their network to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design. Ciena acquired the inventory management and ROA software solutions from DonRiver and Packet Design, respectively. Services includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |

[0000936395-18-000048:notes:360]
| ◦ | Ciena’s Platform Software and Services, which provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Software-related services includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms and operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |

[0000936395-18-000048:notes:361]
Revenue from the software portions of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-18-000048:notes:362]
| • | Global Services reflects sales of a broad range of Ciena’s services for consulting and network design, installation and deployment, maintenance support and training activities. Revenue from this segment is included in services revenue on the Consolidated Statement of Operations. |

[0000936395-18-000048:notes:363]
Ciena’s long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets, and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of October 31, 2018, equipment, building, furniture and fixtures totaling $292.1 million primarily supports asset groups within Ciena’s Networking Platforms and Software and Software-Related Services segments and Ciena’s unallocated selling and general and administrative activities. As of October 31, 2018, $29.7 million of Ciena’s intangible assets were assigned to asset groups within Ciena’s Networking Platforms segment and $118.5 million of Ciena’s intangible assets were assigned to asset groups within Ciena’s Software and Software-Related Services segment. As of October 31, 2018, all of the maintenance spares totaling $45.7 million were assigned to asset groups within Ciena’s Global Services segment.

[0000936395-18-000048:notes:364]
Segment Revenue

[0000936395-18-000048:notes:365]
Segment Profit

[0000936395-18-000048:notes:366]
Segment profit is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; acquisition and integration costs; significant asset impairments and restructuring costs, interest and other income (loss), net; interest expense; loss on extinguishment of debt; and provision (benefit) for income taxes.

[0000936395-18-000048:notes:367]
Entity Wide Reporting

[0000936395-18-000048:notes:368]
Ciena’s operating segments each engage in business across four geographic regions: North America; Europe, Middle East and Africa (“EMEA”); Asia-Pacific (“APAC”); and Caribbean and Latin America (“CALA”). North America includes only activities in the United States and Canada. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services. For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-18-000048:notes:369]
North America includes $1.77 billion, $1.63 billion and $1.58 billion of United States revenue for fiscal years ended October 31, 2018, 2017 and 2016, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-18-000048:notes:370]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):

[0000936395-18-000048:notes:371]
While we have benefited from the diversification of our business and customer base, our ten largest customers contributed 56.5% of fiscal 2018 revenue, 55.6% of fiscal 2017 revenue and 51.1% of fiscal 2016 revenue.

[0000936395-18-000048:notes:372]
Both customers purchased products and services from each of Ciena’s operating segments.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-18-000048:notes:373]
STOCKHOLDERS’ EQUITY

[0000936395-18-000048:notes:374]
Stock Repurchase Program

[0000936395-18-000048:notes:375]
On December 7, 2017, Ciena announced that its Board of Directors authorized a program to repurchase up to $300 million of Ciena’s common stock. A summary of the stock repurchase program, reported based on trade date, is summarized as follows:

[0000936395-18-000048:notes:376]
The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-18-000048:notes:377]
Stock Repurchases Related to Restricted Stock Unit Tax Withholdings

[0000936395-18-000048:notes:378]
Historically, Ciena satisfied employee tax withholding obligations due upon the vesting of stock unit awards through directed open market sales. Beginning in the fourth quarter of fiscal 2018, Ciena changed this practice to begin the repurchase of shares of common stock delivered with respect to such stock units in settlement of employee tax withholding obligations due upon the vesting of such awards. The purchase price of $4.8 million for the shares of Ciena’s stock repurchased is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:SubsequentEventsTextBlock

[0000936395-18-000048:notes:379]
SUBSEQUENT EVENTS

[0000936395-18-000048:notes:380]
On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of its common stock. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. This program terminates and replaces in its entire the previous stock repurchase program authorized in fiscal 2018. From the end of the fiscal year ending October 31, 2018 through December 17, 2018, Ciena did not repurchase shares of its common stock under this prior stock repurchase program.

[0000936395-18-000048:notes:381]
Settlement of Conversions of 3.75% Convertible Senior Notes due October 15, 2018 (“New Notes”)

[0000936395-18-000048:notes:382]
During the fourth quarter of fiscal 2018 Ciena elected to settle the conversion of the New Notes prior to maturity in a combination of cash and shares, with the cash portion not to exceed an aggregate amount of approximately $400 million. Per the settlement provisions of the indenture governing conversion of the New Notes, an amount of $288.7 million (representing the aggregate principal amount) was paid in cash on October 15, 2018. During the relevant settlement period, Ciena’s shares traded at a volume weighted average price in excess of the $20.17 per share conversion price. As such, Ciena paid $111.3 million in excess of the aggregate principal amount in cash, and $52.9 million settled in shares, or 1.6 million shares. These amounts were recorded as debt conversion liability at fiscal year-end October 31, 2018 and were settled during the first quarter of fiscal 2019.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-18-000048:notes:383]
OTHER BALANCE SHEET DETAILS
