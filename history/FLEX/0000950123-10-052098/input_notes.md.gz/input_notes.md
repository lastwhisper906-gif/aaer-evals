# FLEX notes — 0000950123-10-052098


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0000950123-10-052098:notes:1]
13. SHARE REPURCHASE PLAN

[0000950123-10-052098:notes:2]
In accordance with Share Purchase Mandates approved by the Company's shareholders at the annual general meetings of shareholders, the Company generally is authorized to repurchase up to 10% of its outstanding ordinary shares in the open market, subject to limitations under Singapore laws and covenants under the Company's debt facilities.  The Company did not repurchase any shares during fiscal year 2010.  During fiscal year 2009, the Company repurchased approximately 29.8 million shares under this plan for an aggregate purchase price of $260.1 million.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950123-10-052098:notes:3]
12.  BUSINESS AND ASSET ACQUISITIONS AND DIVESTITURES

[0000950123-10-052098:notes:4]
Business and Asset Acquisitions

[0000950123-10-052098:notes:5]
The business and asset acquisitions described below were accounted for using the purchase method of accounting, and accordingly, the fair value of the net assets acquired and the results of the acquired businesses were included in the Company's consolidated financial statements from the acquisition dates forward. The Company has not finalized the allocation of the consideration for certain of its recently completed acquisitions and expects to complete these allocations within one year of the respective acquisition dates.

[0000950123-10-052098:notes:6]
Solectron Corporation

[0000950123-10-052098:notes:7]
On October 1, 2007, the Company completed its acquisition of 100% of the outstanding common stock of Solectron, a provider of value-added electronics manufacturing and supply chain services to OEMs. The acquisition of Solectron broadened the Company's service offering, strengthened its capabilities in the high-end computing, communications and networking infrastructure market segments, increased the scale of its existing operations and diversified the Company's customer and product mix.

[0000950123-10-052098:notes:8]
The results of Solectron's operations were included in the Company's consolidated financial results beginning on October 1, 2007, the acquisition date.

[0000950123-10-052098:notes:9]
The Company issued approximately 221.8 million of its ordinary shares and paid approximately $1.1 billion in cash in connection with the acquisition. The Company also assumed the Solectron Corporation 2002 Stock Plan, including all options to purchase Solectron common stock with an exercise price equal to or less than $5.00 per share of Solectron common stock outstanding under such plan. Each option assumed was converted into an option to acquire the Company's ordinary shares, and the Company assumed approximately 7.4 million fully vested and unvested options to acquire the Company's ordinary shares with exercise prices ranging between $5.45 and $14.41 per Flextronics ordinary share.

[0000950123-10-052098:notes:10]
Pursuant to the purchase method of accounting, the fair value of each Flextronics ordinary share issued was $11.36, which was based on an average of the Company's closing share prices for the five trading days beginning two trading days before and ending two trading days after September 27, 2007, the date on which the number of the Company's ordinary shares to be issued was known. The fair value of options assumed was estimated using the Black-Scholes option-pricing formula.

[0000950123-10-052098:notes:11]
As previously discussed, the Company wrote off all of its goodwill during the quarter ended December 31, 2008, which included goodwill related to the acquisition of Solectron. Subsequent to that write-off the Company reduced valuation allowances attributable to deferred tax assets acquired from Solectron. As a result, the Company reduced acquired customer-related intangibles by approximately $23.6 million.

[0000950123-10-052098:notes:12]
Pro Forma Financial Information (Unaudited)

[0000950123-10-052098:notes:13]
The following table reflects the pro forma consolidated results of operations for the period presented, as though the acquisition of Solectron had occurred as of the beginning of the period being reported on, after giving effect to certain adjustments primarily related to the amortization of acquired intangibles, stock-based compensation expense, and incremental interest expense, including related income tax effects. The pro forma adjustments are based upon available information and certain assumptions that the Company believes are reasonable. The pro forma financial information presented is for illustrative purposes only and is not necessarily indicative of the results of operations that would have been realized if the acquisition had been completed on the date indicated, nor is it indicative of future operating results.

[0000950123-10-052098:notes:14]
The pro forma consolidated results of operations do not include the effects of:

[0000950123-10-052098:notes:15]
•      synergies, which are expected to result from anticipated operating efficiencies and cost savings, including expected gross margin improvement in future quarters due to scale and leveraging of Flextronics' and Solectron's manufacturing platforms;

[0000950123-10-052098:notes:16]
•      potential losses in gross profit due to revenue attrition resulting from combining the two companies; and

[0000950123-10-052098:notes:17]
•      any costs of restructuring, integration, and retention bonuses associated with the closing of the acquisition.

[0000950123-10-052098:notes:18]
|  |  | Fiscal Year Ended March 31, 2008 |
|  |  | (In thousands, except per share amounts) |
| Net sales |  | $ | 33,605,140 |
| Net loss |  | $ | (680,606) |
| Basic and diluted loss per share |  | $ | (0.82) |

[0000950123-10-052098:notes:19]
Other Acquisitions

[0000950123-10-052098:notes:20]
During the fiscal year 2010, the Company paid approximately $75.9 million, net of cash acquired, for contingent consideration and deferred purchase price payments related to four acquisitions, and payments for three completed acquisitions. The completed acquisitions were not individually, nor in the aggregate, significant to the Company's consolidated results of operations and financial position. The acquired businesses expanded the Company's capabilities in the medical and automotive market segments. The purchase prices for certain historical acquisitions completed prior to fiscal 2010 are subject to adjustments for contingent consideration that generally have not been recorded as part of the purchase price, pending the outcome of the contingency. Contingent considerations and provisional fair value adjustments for acquisitions completed in fiscal year 2010 are subject to change as certain information as of the date of the respective acquisition is evaluated during the measurement period, not to exceed one year subsequent to the acquisition date.

[0000950123-10-052098:notes:21]
During fiscal year 2009, the Company completed six acquisitions that were not individually, or in the aggregate, significant to the Company's consolidated results of operations and financial position. The acquired businesses complement the Company's design and manufacturing capabilities for the computing, infrastructure, industrial and consumer digital market segments, and expanded the Company's power supply capabilities. The aggregate cash paid for these acquisitions totaled approximately $199.7 million, net of cash acquired. The Company recorded goodwill of $118.2 million from these acquisitions during fiscal year 2009, including $6.2 million during the fiscal fourth quarter. The purchase prices for these acquisitions have been allocated on the basis of the estimated fair value of assets acquired and liabilities assumed. The Company recognized a net increase in goodwill of $27.1 million during fiscal year 2009, including $30.1 million during the fiscal fourth quarter, for various contingent purchase price arrangements from certain historical acquisitions. The Company also paid approximately $14.8 million relating to contingent purchase price adjustments from certain historical acquisitions. The purchase price for certain acquisitions is subject to adjustments for contingent consideration, based upon the businesses achieving specified levels of earnings. Generally, the contingent consideration has not been recorded as part of the purchase price, pending the outcome of the contingency.

[0000950123-10-052098:notes:22]
During fiscal year 2008, the Company completed three acquisitions that were not individually, or in the aggregate, significant to the Company's consolidated results of operations and financial position. The acquired businesses complemented the Company's design and manufacturing capabilities for the computing and automotive market segments, and expanded the Company's capabilities in the medical market segment, including the design, manufacturing and logistics of disposable medical devices, hand held diagnostics, drug delivery devices and imaging, lab and life sciences equipment. The aggregate cash paid for these acquisitions totaled approximately $188.5 million, net of cash acquired. The Company recorded goodwill of $264.7 million from these acquisitions. In addition, the Company paid approximately $17.2 million in cash for contingent purchase price adjustments relating to certain historical acquisitions. The purchase prices for these acquisitions have been allocated on the basis of the estimated fair value of assets acquired and liabilities assumed.

[0000950123-10-052098:notes:23]
Pro forma results for the Company's other acquisitions have not been presented as such results would not be materially different from the Company's actual results on either an individual or an aggregate basis.

[0000950123-10-052098:notes:24]
Divestitures

[0000950123-10-052098:notes:25]
During the 2008 fiscal year, the Company recognized a gain of approximately $9.7 million in connection with the divesture of certain international entities, which is included in Interest and other expense, net in the Consolidated Statements of Operations. The results for these entities were not significant for any period presented.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000950123-10-052098:notes:26]
3.  SUPPLEMENTAL CASH FLOW DISCLOSURES

[0000950123-10-052098:notes:27]
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000950123-10-052098:notes:28]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
|  |  | (In thousands) |
| Net cash paid (received) for: |  |  |  |  |  |  |  |  |
| Interest | $ | 126,327 |  | $ | 178,641 |  | $ | 126,975 |
| Income taxes | $ | 89,973 |  | $ | (56,315) |  | $ | 59,553 |
| Non-cash investing and financing activities: |  |  |  |  |  |  |  |  |
| Issuance of ordinary shares for acquisition of businesses | $ | — |  | $ | 270 |  | $ | 2,519,670 |
| Fair value of vested options assumed in acquisition of business | $ | — |  | $ | — |  | $ | 11,282 |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-10-052098:notes:29]
7.  COMMITMENTS AND CONTINGENCIES

[0000950123-10-052098:notes:30]
As of March 31, 2010 and 2009, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under capital leases, and the related obligations was not material. The Company also leases certain of its facilities under non-cancelable operating leases. These operating leases expire in various years through 2024 and require the following minimum lease payments:

[0000950123-10-052098:notes:31]
|  | Operating |  |
| Fiscal Year Ending March 31, | Lease |  |
|  | (In thousands) |
| 2011 | $ 123,646 |  |
| 2012 | 93,228 |  |
| 2013 | 75,167 |  |
| 2014 | 56,867 |  |
| 2015 | 38,763 |  |
| Thereafter | 86,959 |  |
| Total minimum lease payments | $ 474,630 |  |

[0000950123-10-052098:notes:32]
Total rent expense amounted to $143.2 million, $139.2 million and $94.2 million in fiscal years 2010, 2009 and 2008, respectively.

[0000950123-10-052098:notes:33]
The Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:DebtDisclosureTextBlock

[0000950123-10-052098:notes:34]
4.  BANK BORROWINGS AND LONG-TERM DEBT

[0000950123-10-052098:notes:35]
Bank borrowings and long-term debt are as follows:

[0000950123-10-052098:notes:36]
|  | As of March 31, |
|  | 2010 |  | 2009 |
|  | (In thousands) |
| 0.00% convertible junior subordinated notes due July 2009 | $ - |  | $ 189,045 |
| 1.00% convertible subordinated notes due August 2010 | 234,240 |  | 218,391 |
| 6.50% senior subordinated notes due May 2013 | - |  | 399,622 |
| 6.25% senior subordinated notes due November 2014 | 302,172 |  | 402,090 |
| Term Loan Agreement, including current portion, due in installments |  |  |  |
| through October 2014 | 1,691,775 |  | 1,709,116 |
| Other | 26,643 |  | 23,270 |
|  | 2,254,830 |  | 2,941,534 |
| Current portion | (265,954) |  | (207,991) |
| Non-current portion | $ 1,988,876 |  | $ 2,733,543 |

[0000950123-10-052098:notes:37]
Maturities for the Company's long-term debt are as follows:

[0000950123-10-052098:notes:38]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2011 | $ | 265,954 |
| 2012 |  | 16,752 |
| 2013 |  | 489,702 |
| 2014 |  | 11,688 |
| 2015 |  | 1,458,574 |
| Thereafter |  | 12,160 |
| Total | $ | 2,254,830 |

[0000950123-10-052098:notes:39]
Revolving Credit Facilities and Other Credit Lines

[0000950123-10-052098:notes:40]
On May 10, 2007, the Company entered into a five-year $2.0 billion credit facility that expires in May 2012. As of March 31, 2010 and 2009, there were no borrowings outstanding under the credit facility. Borrowings under the credit facility bear interest, at the Company's option, either at (i) the base rate (the greater of the agent's prime rate or the federal funds rate plus 0.50%); or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 0.50% and 1.25%, based on the Company's credit ratings. The Company is required to pay a quarterly commitment fee ranging from 0.10% to 0.20% per annum on the unutilized portion of the credit facility based on the Company's credit ratings and, if the utilized portion of the credit facility exceeds 50% of the total commitments, a quarterly utilization fee of 0.125% on such utilized portion. The Company is also required to pay letter of credit usage fees ranging between 0.50% and 1.25% per annum (based on the Company's credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of (i) in the case of commercial letters of credit, 0.125% of the amount available to be drawn under such letters of credit, and (ii) in the case of standby letters of credit, 0.125% per annum on the daily average undrawn amount of such letters of credit.

[0000950123-10-052098:notes:41]
The credit facility is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum fixed charge coverage ratio, as defined, during the term of the credit facility. Borrowings under the credit facility are guaranteed by the Company and certain of its subsidiaries. As of March 31, 2010, the Company was in compliance with the covenants under the credit facility.

[0000950123-10-052098:notes:42]
The Company and certain of its subsidiaries also have various uncommitted revolving credit facilities, lines of credit and other loans in the amount of $254.9 million in the aggregate, under which there were approximately $6.7 million and $1.9 million of borrowings outstanding as of March 31, 2010 and 2009, respectively. These facilities, lines of credit and other loans bear annual interest at the respective country's inter — bank offering rate, plus an applicable margin, and generally have maturities that expire on various dates through fiscal year 2011. The credit facilities are unsecured and the lines of credit and other loans are primarily secured by accounts receivable.

[0000950123-10-052098:notes:43]
Zero Coupon Convertible Junior Subordinated Notes

[0000950123-10-052098:notes:44]
On July 31, 2009, the Company paid $195.0 million to redeem the Zero Coupon Convertible Junior Subordinated Notes upon maturity. The Notes carried conversion provisions to issue shares to settle any conversion spread (excess of conversion value over the conversion price of $10.50 per share).  On the maturity date, the Company's stock price was less than the conversion price, and therefore no shares were issued.

[0000950123-10-052098:notes:45]
1% Convertible Subordinated Notes

[0000950123-10-052098:notes:46]
The 1% Convertible Subordinated Notes are due in August 2010 and are convertible at any time prior to maturity into ordinary shares of the Company at a conversion price of $15.525 (subject to certain adjustments). During December 2008, the Company paid approximately $226.2 million to purchase an aggregate principal amount of $260.0 million of these notes under a modified Dutch auction procedure. The Company recognized a gain of approximately $22.3 million (as adjusted for the retroactive adoption of the accounting for convertible debt described in Note 2) during the fiscal year ended March 31, 2009 associated with the partial extinguishment of the Notes net of approximately $5.7 million for estimated transaction costs and the write-off of related debt issuance costs, which is recorded in Other charges, net in the Consolidated Statements of Operations. The gain was reduced by $5.8 million in connection with the retroactive adoption of a new accounting standard effective April 1, 2009. As of March 31, 2010, the $234.2 million net principal amount of these Notes was classified as current liabilities and included in "Bank borrowings, current portion of long-term debt and capital lease obligations" in the Consolidated Balance Sheet.

[0000950123-10-052098:notes:47]
6.5% Senior Subordinated Notes

[0000950123-10-052098:notes:48]
On March 19, 2010, the Company paid approximately $306.3 million to redeem the aggregate principal balance of $299.8 million of these notes at a redemption price of 102.167% of the principal amount. The Company recognized a loss associated with the early redemption of the notes of approximately $10.5 million during the fiscal year ended March 31, 2010, consisting of the redemption price premium of approximately $6.5 million, and approximately $4.0 million for transaction costs and the write-off of unamortized debt costs. The loss is recorded in Other charges, net in the Consolidated Statements of Operations.

[0000950123-10-052098:notes:49]
During June 2009, the Company paid approximately $101.8 million to purchase an aggregate principal amount of $99.8 million of these Notes in a cash tender offer. The cash paid included $2.3 million in consent fees paid to holders of the Notes that were tendered but not purchased as well as to holders that consented but did not tender, which were capitalized and were being recognized as a component of interest expense over the remaining life of the Notes until the redemption noted above. The Company recognized a $2.3 million loss during fiscal year 2010 associated with the partial extinguishment of the Notes, which included approximately $2.6 million for transaction costs and the write-down of related debt issuance costs. In conjunction with the tender offer, the Company obtained consents to certain amendments to the restricted payments covenants and certain related definitions in the indenture under which the Notes were issued. The amendments permitted the Company greater flexibility to purchase or make other payments in respect of its equity securities and debt that was subordinated to the Notes and to make certain other restricted payments under the indenture.

[0000950123-10-052098:notes:50]
6.25% Senior Subordinated Notes

[0000950123-10-052098:notes:51]
The Company may redeem its 6.25% Senior Subordinated Notes that are due on November 15, 2014, in whole or in part at redemption prices of 102.083% and 101.042% of the principal amount thereof if the redemption occurs during the respective 12-month periods beginning on November 15 of the years 2010 and 2011, respectively, and at a redemption price of 100% of the principal amount thereof on and after November 15, 2012, in each case, plus any accrued and unpaid interest to the redemption date.

[0000950123-10-052098:notes:52]
During June 2009, the Company paid approximately $101.3 million to purchase an aggregate principal amount of $99.9 million of these Notes in a cash tender offer. The cash paid included $6.5 million in consent fees paid to holders of the Notes that were tendered but not purchased as well as to holders that consented but did not tender, which were capitalized and are being recognized as a component of interest expense over the remaining life of the Notes. The Company recognized a $2.3 million gain during fiscal year 2010 associated with the partial extinguishment of the Notes, net of approximately $2.7 million for transaction costs and the write-down of related debt issuance costs. In conjunction with the tender offer, the Company obtained consents to certain amendments to the restricted payments covenants and certain related definitions in the indenture under which the Notes were issued. The amendments permit the Company greater flexibility to purchase or make other payments in respect of its equity securities and debt that is subordinated to the Notes and to make certain other restricted payments under the indenture.

[0000950123-10-052098:notes:53]
The indenture governing the Company's outstanding 6.25% Senior Subordinated Notes contain certain covenants that, among other things, limit the ability of the Company and its restricted subsidiaries to (i) incur additional debt, (ii) issue or sell stock of certain subsidiaries, (iii) engage in certain asset sales, (iv) make distributions or pay dividends, (v) purchase or redeem capital stock, or (vi) engage in transactions with affiliates. The covenants are subject to a number of significant exceptions and limitations. As of March 31, 2010, the Company was in compliance with the covenants under this indenture.

[0000950123-10-052098:notes:54]
Term Loan Agreement

[0000950123-10-052098:notes:55]
In connection with the Company's acquisition of Solectron Corporation, the Company entered into a $1.759 billion term loan facility, dated as of October 1, 2007, and subsequently amended as of December 28, 2007 (the "Term Loan Agreement"). The Term Loan Agreement was obtained for the purposes of consummating the acquisition, to pay the applicable repurchase or redemption price for certain of Solectron's notes in connection with the acquisition, and to pay any related fees and expenses including acquisition related costs.

[0000950123-10-052098:notes:56]
On October 1, 2007, the Company borrowed $1.109 billion under the Term Loan Agreement to pay the cash consideration in the acquisition and acquisition-related fees and expenses. Of this amount, $500.0 million matures five years from the date of the Term Loan Agreement and the remainder matures in seven years. On October 15, 2007, the Company borrowed an additional $175.0 million to fund its repurchase and redemption of certain Solectron Notes. On February 29, 2008, the Company borrowed the remaining $450.0 million available under the Term Loan Agreement to fund its repurchase of additional Solectron notes. The maturity date of these loans is seven years from the date of the Term Loan Agreement. These loans will amortize in quarterly installments in an amount equal to 1% per annum with the balance due at the end of the fifth or seventh year, as applicable. The Company may prepay the loans at any time at 100% of par for any loan with a five year maturity and at 101% of par for the first year and 100% of par thereafter, for any loan with a seven year maturity, in each case plus accrued and unpaid interest and reimbursement of the lender's redeployment costs. Borrowings under the Term Loan Agreement bear interest, at the Company's option, either at (i) the base rate (the greater of the agent's prime rate or the federal funds rate plus 0.50%) plus a margin of 1.25%; or (ii) LIBOR plus a margin of 2.25%.

[0000950123-10-052098:notes:57]
The Term Loan Agreement is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to, among other things, (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The Term Loan Agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA, during the term of the Term Loan Agreement. Borrowings under the Term Loan Agreement are guaranteed by the Company and certain of its subsidiaries. As of March 31, 2010, the Company was in compliance with the financial covenants under the Term Loan Agreement.

[0000950123-10-052098:notes:58]
As of March 31, 2010, the Company had approximately $1.7 billion of borrowings outstanding under the Term Loan Agreement, of which the floating interest payments on $847.0 million has been swapped for fixed interest payments with remaining terms ranging from one to ten months (see Note 5).

[0000950123-10-052098:notes:59]
Fair Values

[0000950123-10-052098:notes:60]
As of March 31, 2010, the approximate fair values of the Company's 6.25% Senior Subordinated Notes, 1% Convertible Subordinated Notes and debt outstanding under its Term Loan Agreement were 101.0%, 99.18% and 95.58% of the face values of the debt obligations, respectively, based on broker trading prices.

[0000950123-10-052098:notes:61]
Interest Expense

[0000950123-10-052098:notes:62]
For the fiscal years ended March 31, 2010, 2009 and 2008, the Company recognized total interest expense of $158.1 million, $245.5 million and $227.4 million (including $21.4 million, $43.5 million, and $42.0 million for the retrospective application of the new accounting standard discussed above), respectively, on its debt obligations outstanding during the period.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950123-10-052098:notes:63]
5.  FINANCIAL INSTRUMENTS

[0000950123-10-052098:notes:64]
Due to their short-term nature, the carrying amount of the Company's cash and cash equivalents, accounts receivable and accounts payable approximates fair value. The Company's cash equivalents are comprised of cash and bank deposits and money market accounts. The Company's investment policy limits the amount of credit exposure to 20% of the total investment portfolio or $10.0 million in any single issuer.

[0000950123-10-052098:notes:65]
Foreign Currency Contracts

[0000950123-10-052098:notes:66]
The Company transacts business in various foreign countries and is therefore, exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency unit of the operating entity. The Company enters into short-term foreign currency forward and swap contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies.  Gains and losses on the Company's forward and swap contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these forward and swap contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counter-party financial institution was not material.

[0000950123-10-052098:notes:67]
As of March 31, 2010, the aggregate notional amount of the Company's outstanding foreign currency forward and swap contracts was $2.1 billion as summarized below:

[0000950123-10-052098:notes:68]
| Currency |  | Buy/Sell |  | Foreign Currency Amount |  |  | Notional Contract Value in USD |
| (In thousands) |  |  |  |  |  |  |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| CNY |  | Buy |  | 1,214,718 |  | $ | 177,960 |
| EUR |  | Buy |  | 21,329 |  |  | 28,745 |
| EUR |  | Sell |  | 9,127 |  |  | 13,500 |
| HUF |  | Buy |  | 10,166,200 |  |  | 51,519 |
| MXN |  | Buy |  | 1,513,000 |  |  | 121,769 |
| Other |  | Buy |  | N/A |  |  | 51,792 |
|  |  |  |  |  |  |  | 445,285 |
| Other Forward/Swap Contracts |  |  |  |  |  |  |  |
| BRL |  | Buy |  | 72,200 |  |  | 40,245 |
| BRL |  | Sell |  | 142,100 |  |  | 79,208 |
| CAD |  | Buy |  | 49,384 |  |  | 48,321 |
| CAD |  | Sell |  | 105,773 |  |  | 103,311 |
| CNY |  | Buy |  | 569,937 |  |  | 83,500 |
| EUR |  | Buy |  | 51,549 |  |  | 69,596 |
| EUR |  | Sell |  | 266,673 |  |  | 359,934 |
| GBP |  | Buy |  | 68,444 |  |  | 103,327 |
| GBP |  | Sell |  | 92,117 |  |  | 138,941 |
| JPY |  | Buy |  | 3,978,221 |  |  | 43,087 |
| MXN |  | Buy |  | 652,000 |  |  | 52,474 |
| MYR |  | Buy |  | 210,944 |  |  | 64,487 |
| SEK |  | Buy |  | 1,777,481 |  |  | 245,512 |
| SGD |  | Buy |  | 69,394 |  |  | 49,649 |
| Other |  | Buy |  | N/A |  |  | 54,871 |
| Other |  | Sell |  | N/A |  |  | 119,327 |
|  |  |  |  |  |  |  | 1,655,790 |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 2,101,075 |

[0000950123-10-052098:notes:69]
As of March 31, 2009, the Company had foreign currency forward and swap contracts with notional values totaling $1.7 billion, of which $120.2 million had been designated as cash flow hedges.

[0000950123-10-052098:notes:70]
As of March 31, 2010 and 2009, the fair value of the Company's short-term foreign currency contracts was not material and included in other current assets or other current liabilities, as applicable, in the consolidated balance sheet. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in fair value of these instruments are recognized in earnings during the period of change as a component of interest and other expense, net in the consolidated statement of operations. As of March 31, 2010 and 2009, the Company also has included net deferred gains and losses, respectively, in other comprehensive income, a component of shareholders' equity in the consolidated balance sheet, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred gains and losses were not material, and the deferred losses as of March 31, 2010 are expected to be recognized as a component of cost of sales in the consolidated statement of operations primarily over the next twelve month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal years presented and are included as a component of interest and other expense, net in the consolidated statement of operations.

[0000950123-10-052098:notes:71]
Interest Rate Swap Agreements

[0000950123-10-052098:notes:72]
The Company is also exposed to variability in cash flows associated with changes in short-term interest rates primarily on borrowings under its revolving credit facility and Term Loan Agreement. During fiscal years 2009 and 2008, the Company entered into interest rate swap agreements to mitigate the exposure to interest rate risk resulting from unfavorable changes in interest rates resulting from the Term Loan Agreement, as summarized below:

[0000950123-10-052098:notes:73]
| Notional Amount |  | Fixed Interest |  | Interest Payment |  |  |  |  |
| (in millions) |  | Rate Payable |  | Received |  | Term |  | Expiration Date |
| Fiscal 2009 Contracts: |  |  |  |  |  |  |
| $100.0 |  | 1.94% |  | 1-Month Libor |  | 12 month |  | January 2010 |
| $100.0 |  | 2.45% |  | 3-Month Libor |  | 12 month |  | January 2010 |
| $100.0 |  | 1.00% |  | 1-Month Libor |  | 12 month |  | March 2010 |
| $100.0 |  | 1.00% |  | 1-Month Libor |  | 12 month |  | April 2010 |
| Fiscal 2008 Contracts: |  |  |  |  |  |  |
| $250.0 |  | 3.61% |  | 1-Month Libor |  | 34 months |  | October 2010 |
| $250.0 |  | 3.61% |  | 1-Month Libor |  | 34 months |  | October 2010 |
| $175.0 |  | 3.60% |  | 3-Month Libor |  | 36 months |  | January 2011 |
| $72.0 |  | 3.57% |  | 3-Month Libor |  | 36 months |  | January 2011 |
| $1,147.0 |  |  |  |  |  |  |  |  |

[0000950123-10-052098:notes:74]
During March 2009, the Company amended its two $250.0 million swaps expiring in October 2010 and one of its $100.0 million swaps, which expired January 2010, from three-month to one-month Libor and reduced the fixed interest payments from 3.89% to 3.61% and from 2.42% to 1.94%, respectively.

[0000950123-10-052098:notes:75]
These contracts provided for the receipt of interest payments at rates equal to the terms of the various tranches of the underlying borrowings outstanding under the Term Loan Arrangement (excluding the applicable margin), other than the two $250.0 million swaps, expiring October 2010, and the $100.0 million swaps that expired during January 2010 and March 2010, respectively.  These swaps provided for the receipt of interest at one-month Libor while the underlying borrowings were based on three-month Libor.

[0000950123-10-052098:notes:76]
All of the Company's interest rate swap agreements were accounted for as cash flow hedges, and no portion of the swaps were considered ineffective.  For fiscal years 2010, 2009 and 2008 the net amount recorded as interest expense from these swaps was not material. As of March 31, 2010 and 2009, the fair value of the Company's interest rate swaps were not material and were included in other current liabilities in the consolidated balance sheet, with a corresponding decrease in other comprehensive income. The deferred losses included in other comprehensive income will effectively be released through earnings as the Company makes fixed, and receives variable, payments over the remaining term of the swaps through January 2011.

[0000950123-10-052098:notes:77]
In January 2010, two swaps totaling $200.0 million with a weighted average interest rate of 2.195% expired, and in March 2010, a $100.0 million swap, with an interest rate of 1%, expired.  As of March 31, 2010, the Company had an aggregate amount of $847.0 million in swaps outstanding with a weighted average fixed interest rate of 3.30%.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-10-052098:notes:78]
8.  INCOME TAXES

[0000950123-10-052098:notes:79]
The domestic ("Singapore") and foreign components of income before income taxes were comprised of the following:

[0000950123-10-052098:notes:80]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
|  | (In thousands) |
| Domestic | $ 86,411 |  | $ (1,090,863) |  | $ 268,294 |
| Foreign | (103,186) |  | (4,990,075) |  | (202,627) |
| Total | $ (16,775) |  | $ (6,080,938) |  | $ 65,667 |

[0000950123-10-052098:notes:81]
The provision for (benefit from) income taxes consisted of the following:

[0000950123-10-052098:notes:82]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Domestic | $ 50 |  | $ 3,461 |  | $ 547 |
| Foreign | (18,529) |  | 68,581 |  | 65,469 |
|  | (18,479) |  | 72,042 |  | 66,016 |
| Deferred: |  |  |  |  |  |
| Domestic | 1,077 |  | 895 |  | (252) |
| Foreign | (17,967) |  | (67,728) |  | 639,273 |
|  | (16,890) |  | (66,833) |  | 639,021 |
| Provision for (benefit from) income taxes | $ (35,369) |  | $ 5,209 |  | $ 705,037 |

[0000950123-10-052098:notes:83]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2010 and 2009, and approximately 18.0% in fiscal year 2008. The reconciliation of the income tax expense (benefit) expected based on domestic statutory income tax rates to the expense (benefit) for income taxes included in the consolidated statements of operations is as follows:

[0000950123-10-052098:notes:84]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
|  | (In thousands) |
| Income taxes based on domestic statutory rates | $ (2,852) |  | $ (1,033,760) |  | $ 11,821 |
| Effect of tax rate differential | (40,728) |  | 38,440 |  | (314,108) |
| Intangible amortization | 15,279 |  | 23,098 |  | 12,924 |
| Change in liability for uncertain tax positions | (80,175) |  | 8,339 |  | 6,367 |
| Goodwill impairment | — |  | 1,011,496 |  | — |
| Change in valuation allowance | 69,076 |  | (50,225) |  | 986,338 |
| Other | 4,031 |  | 7,821 |  | 1,695 |
| Provision for income taxes | $ (35,369) |  | $ 5,209 |  | $ 705,037 |

[0000950123-10-052098:notes:85]
The $986.3 million change in valuation allowance during fiscal year 2008 includes non-cash tax expense of $661.3 million, principally resulting from management's re-evaluation of previously recorded deferred tax assets in the United States, which are primarily comprised of tax loss carry forwards. Management believes that the realizability of certain deferred tax assets was no longer more likely than not because it expected future projected taxable income in the United States will be lower as a result of increased interest expense resulting from the term loan entered into as part of the acquisition of Solectron. The remaining change in the valuation allowance during the 2008 fiscal year was primarily for that year's operating losses and restructuring charges, on which the tax benefit was not more likely than not to be realized.

[0000950123-10-052098:notes:86]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company's operations. The aggregate dollar effect on the Company's income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2010, 2009 and 2008 were $65.4 million, $85.3 million and $118.0 million, respectively. The effect on basic and diluted earnings per share for the fiscal year ended March 31, 2010 is $0.08 and the effect on basic and diluted loss per share during fiscal years 2009 and 2008 were $0.10 and $0.16, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in the fiscal years ending March 31, 2011 through fiscal 2018.

[0000950123-10-052098:notes:87]
The components of deferred income taxes are as follows:

[0000950123-10-052098:notes:88]
|  | As of March 31, |
|  | 2010 |  | 2009 |
|  | (In thousands) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ - |  | $ (2,211) |
| Total deferred tax liabilities | - |  | (2,211) |
| Deferred tax assets: |  |  |  |
| Fixed assets | 24,512 |  | - |
| Intangible assets | 342,495 |  | 246,001 |
| Deferred compensation | 10,049 |  | 9,616 |
| Inventory valuation | 22,238 |  | 28,365 |
| Provision for doubtful accounts | 9,448 |  | 11,834 |
| Net operating loss and other carryforwards | 2,773,599 |  | 2,857,640 |
| Others | 146,965 |  | 188,254 |
|  | 3,329,306 |  | 3,341,710 |
| Valuation allowances | (3,280,827) |  | (3,308,966) |
| Net deferred tax assets | 48,479 |  | 32,744 |
| Net deferred tax asset | $ 48,479 |  | $ 30,533 |
| The net deferred tax asset is classified as follows: |  |  |  |
| Current asset (classified as other current assets) | $ 1,205 |  | $ 66 |
| Long-term asset | 47,274 |  | 30,467 |
| Total | $ 48,479 |  | $ 30,533 |

[0000950123-10-052098:notes:89]
The Company has tax loss carryforwards of approximately $8.2 billion, a portion of which begin expiring in 2011. Utilization of the tax loss carryforwards and other deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision. Approximately $34.0 million of the valuation allowance relates to income tax benefits arising from the exercise of stock options, which if realized will be credited directly to shareholders' equity and will not be available to benefit the income tax provision in any future period.

[0000950123-10-052098:notes:90]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management's estimates.

[0000950123-10-052098:notes:91]
The Company does not provide for income taxes on the undistributed earnings of its foreign subsidiaries, as such earnings are not intended by management to be repatriated in the foreseeable future. Determination of the amount of the unrecognized deferred tax liability on these undistributed earnings is not practicable.

[0000950123-10-052098:notes:92]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000950123-10-052098:notes:93]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |
|  | (In thousands) |
| Balance, beginning of fiscal year | $ 221,401 |  | $ 191,147 |
| Additions based on tax position related to the current year | 10,605 |  | 15,089 |
| Additions for tax positions of prior years | 15,693 |  | 37,298 |
| Reductions for tax positions of prior years | (63,134) |  | (972) |
| Reductions related to lapse of applicable statute of limitations | (3,123) |  | (3,276) |
| Settlements | (55,412) |  | (15,547) |
| Other | 3,858 |  | (2,338) |
| Balance, end of fiscal year | $ 129,888 |  | $ 221,401 |

[0000950123-10-052098:notes:94]
The Company's unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an estimated range of $10.0 - $30.0 million within the next twelve months due primarily to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000950123-10-052098:notes:95]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2000.

[0000950123-10-052098:notes:96]
The entire amount of unrecognized tax benefits at March 31, 2010, may affect the annual effective tax rate if the benefits are eventually recognized.

[0000950123-10-052098:notes:97]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company's tax expense. During the fiscal years ended March 31, 2010 and 2009, the Company recognized interest of approximately $5.3 million and $5.9 million, respectively, and no penalties. The Company had approximately $66.8 million and $89.0 million, and $0.3 million and $29.5 million accrued for the payment of interest and penalties, respectively, as of the fiscal years ended March 31, 2010 and 2009, respectively.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000950123-10-052098:notes:98]
6.  TRADE RECEIVABLES SECURITIZATION

[0000950123-10-052098:notes:99]
The Company continuously sells designated pools of trade receivables under two asset backed securitization programs and an accounts receivable factoring program.

[0000950123-10-052098:notes:100]
Global Asset-Backed Securitization Agreement

[0000950123-10-052098:notes:101]
The Company continuously sells a designated pool of trade receivables to a third-party qualified special purpose entity, which in turn sells an undivided ownership interest to two commercial paper conduits, administered by an unaffiliated financial institution. In addition to these commercial paper conduits, the Company participates in the securitization agreement as an investor in the conduit. The securitization agreement allows the operating subsidiaries participating in the securitization program to receive a cash payment for sold receivables, less a deferred purchase price receivable.

[0000950123-10-052098:notes:102]
The Company services, administers and collects the receivables on behalf of the entity and receives a servicing fee of 1.00% of serviced receivables per annum. Servicing fees recognized during the fiscal years ended March 31, 2010, 2009 and 2008 were not material and are included in Interest and other expense, net within the Consolidated Statements of Operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000950123-10-052098:notes:103]
During October 2009, the securitization agreement was amended such that the maximum investment limit of these commercial paper conduits was $500.0 million. Additionally, the Company pays annual facility and commitment fees totaling 1.5% per annum under the facility to the extent funded through the issuance of commercial paper.

[0000950123-10-052098:notes:104]
The third-party special purpose entity was a qualifying special purpose entity, and accordingly, the Company did not consolidate this entity. As of March 31, 2010 and 2009, approximately $352.5 million and $422.0 million of the Company's accounts receivable, respectively, had been sold to this third-party qualified special purpose entity. The amounts represent the face amount of the total outstanding trade receivables on all designated customer accounts on those dates. For the years ended March 31, 2010 and 2009, the Company sold approximately $5.7 billion and $6.0 billion, respectively, to the third party special purpose entity.  The accounts receivable balances that were sold under this agreement were removed from the Consolidated Balance Sheets and the amounts received are included as cash provided by operating activities in the Consolidated Statements of Cash Flows. The Company had a recourse obligation that was limited to the deferred purchase price receivable, which approximated 5% of the total sold receivables, and its own investment participation, the total of which was approximately $135.4 million and $123.8 million as of March 31, 2010 and 2009, respectively, and each was recorded in Other current assets in the Consolidated Balance Sheets as of March 31, 2010 and 2009. The amount of the Company's own investment participation varied depending on certain criteria, mainly the collection performance on the sold receivables and the Company's financing requirements. As the recoverability of the trade receivables underlying the Company's own investment participation was determined in conjunction with the Company's accounting policies for determining provisions for doubtful accounts prior to sale into the third party qualified special purpose entity, the fair value of the Company's own investment participation reflected the estimated recoverability of the underlying trade receivables.  The Company received net cash proceeds of approximately $217.1 million and $298.1 million from the commercial paper conduits for the sale of these receivables as of March 31, 2010 and 2009, respectively. The difference between the amount sold to the commercial paper conduits (net of the Company's investment participation) and net cash proceeds received from the commercial paper conduits was recognized as a loss on sale of the receivables and recorded in Interest and other expense, net in the Consolidated Statements of Operations.

[0000950123-10-052098:notes:105]
Effective April 1, 2010, the adoption of a new accounting standard will eliminate the concept of a qualifying special purpose entity and will create more stringent conditions for reporting the transfer of a financial asset as a sale. In addition, effective April 1, 2010, the adoption of a new accounting standard will amend consolidation guidance for determining the primary beneficiary of a variable interest entity. Under this new standard the Company will be deemed the primary beneficiary of this special purpose entity and will be required to consolidate the special purpose entity. As a result, accounts receivable sold under this program will remain on the Company's balance sheet, as currently structured, and cash received from the program will be accounted for as a borrowing on the Company's balance sheet and as a financing activity in the statement of cash flows.

[0000950123-10-052098:notes:106]
North American Asset-Backed Securitization Agreement

[0000950123-10-052098:notes:107]
The Company continuously sells a designated pool of trade receivables to an affiliated special purpose vehicle, which in turn sells such receivables to an agent on behalf of two commercial paper conduits administered by unaffiliated financial institutions. The Company continues to service, administer and collect the receivables on behalf of the special purpose entity and receives a servicing fee of 0.50% per annum on the outstanding balance of the serviced receivables. Servicing fees recognized during the fiscal year ended March 31, 2010 and 2009 were not material and are included in Interest and other expense, net within the Consolidated Statements of Operations. As the Company estimates that the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized. The Company, by design of the transaction, absorbed the majority of expected losses from transfers of trade receivables into the special purpose vehicle and, as such, was deemed the primary beneficiary of this entity. Accordingly, the Company consolidated the special purpose vehicle.

[0000950123-10-052098:notes:108]
The maximum investment limit of the two commercial paper conduits is $300.0 million. During September 2009, the securitization agreement was amended such that the Company paid commitment fees of 0.80% per annum on the aggregate amount of the liquidity commitments of the financial institutions under the facility (which approximates the maximum investment limit) and an additional program fee of 0.70% on the aggregate amounts invested under the facility by the conduits to the extent funded through the issuance of commercial paper.

[0000950123-10-052098:notes:109]
As of March 31, 2010 and 2009, the Company transferred approximately $356.9 million and $448.7 million, respectively, into the special purpose vehicle.  The Company  sold approximately  $200.7 million and $173.8 million of accounts receivable to the two commercial paper conduits as of March 31, 2010 and 2009, respectively, and received approximately $200.0 million and $173.1 million, respectively, in net cash proceeds from the sales. For the years ended March 31, 2010 and 2009, the Company received approximately $1.6 billion and $1.7 billion, respectively, in net cash proceeds from the sale.   The accounts receivable balances that were sold to the two commercial paper conduits under this agreement were removed from the Consolidated Balance Sheets and were reflected as cash provided by operating activities in the Consolidated Statements of Cash Flows, and the difference between the amount sold and net cash proceeds received was recognized as a loss on sale of the receivables, and was recorded in Interest and other expense, net in the Consolidated Statements of Operations.  The remaining trade receivables transferred into the special purpose vehicle and not sold to the two commercial paper conduits comprised the primary assets of that entity, and were included in trade accounts receivable, net in the Consolidated Balance Sheets of the Company.  The recoverability of these trade receivables, both those included in the Consolidated Balance Sheets and those sold but uncollected by the commercial paper conduits, were determined in conjunction with the Company's accounting policies for determining provisions for doubtful accounts.  Although the special purpose vehicle was fully consolidated by the Company, it was a separate corporate entity and its assets were available first to satisfy the claims of its creditors.

[0000950123-10-052098:notes:110]
Effective April 2010, the securitization agreement was amended to provide for the sale by the special purpose vehicle of 100% of the receivables instead of a sale of an undivided ownership interest in such receivables.  A portion of the purchase price for the receivables will be paid by the two commercial paper conduits in cash and the balance in the form of a deferred purchase price receivable.  The amount of the Company's deferred purchase price receivable will vary primarily depending on the financing requirements of the Company and the performance of the receivables sold.  The accounts receivable balances sold under this agreement will be removed from the Consolidated Balance Sheets and be reported as cash provided by operating activities in the Consolidated Statements of Cash Flows. The deferred purchase price receivable will be recorded in other current assets in the consolidated balance sheet. The Company's participation in the deferred purchase price receivable will be reported as an operating activity in the Consolidated Statements of Cash Flows.

[0000950123-10-052098:notes:111]
Factored Accounts Receivable

[0000950123-10-052098:notes:112]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $164.2 million and $171.6 million as of March 31, 2010 and 2009, respectively.  For the years ended March 31, 2010 and 2009, total accounts receivables sold to certain third party banking institutions was approximately $1.2 billion and $3.6 billion, respectively.  These receivables that were sold were removed from the Consolidated Balance Sheets and were reflected as cash provided by operating activities in the Consolidated Statement of Cash Flows.  This arrangement was amended to allow sold accounts receivable to continue to be removed from the Consolidated Balance Sheets upon the adoption of a new accounting standard on April 1, 2010.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950123-10-052098:notes:113]
1.  ORGANIZATION OF THE COMPANY

[0000950123-10-052098:notes:114]
Flextronics International Ltd. ("Flextronics" or the "Company") was incorporated in the Republic of Singapore in May 1990.  The Company's operations have expanded over the years by a combination of internal expansion and acquisitions, including the acquisition of Solectron Corporation ("Solectron") in fiscal year 2008 (see Note 12). The Company is a leading provider of advanced design and electronics manufacturing services ("EMS") to original equipment manufacturers ("OEMs") of a broad range of products in the following markets: infrastructure; mobile communication devices; computing; consumer digital devices; industrial, semiconductor capital equipment, clean technology, aerospace and defense, and white goods; automotive and marine; and medical devices. The Company's strategy is to provide customers with a full range of vertically-integrated global supply chain services through which the Company designs, builds, ships and services a complete packaged product for its OEM customers. OEM customers leverage the Company's services to meet their product requirements throughout the entire product life cycle.

[0000950123-10-052098:notes:115]
The Company's service offerings include rigid printed circuit board and flexible circuit fabrication, systems assembly and manufacturing (including enclosures, testing services, materials procurement and inventory management), logistics, after-sales services (including product repair, re-manufacturing and maintenance) and multiple component product offerings. Additionally, the Company provides market-specific design and engineering services ranging from contract design services ("CDM"), where the customer purchases services on a time and materials basis, to original product design and manufacturing services, where the customer purchases a product that was designed, developed and manufactured by the Company (commonly referred to as original design manufacturing, or "ODM"). ODM products are then sold by the Company's OEM customers under the OEM's brand names. The Company's CDM and ODM services include user interface and industrial design, mechanical engineering and tooling design, electronic system design and printed circuit board design. The Company also provides after market services such as logistics, repair and warranty services.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000950123-10-052098:notes:116]
10.  OTHER CHARGES, NET

[0000950123-10-052098:notes:117]
During fiscal year 2010, the Company recognized impairment charges totaling approximately $199.4 million related to our equity investments and notes receivable. Refer to Note 2, "Summary of Accounting Policies" for further discussion.

[0000950123-10-052098:notes:118]
During fiscal year 2009, the Company recognized approximately $74.1 million in charges to write-down certain notes receivable from an affiliate to the expected recoverable amount, and $37.5 million in charges for the other-than-temporary impairment of certain of the Company's investments in companies that were experiencing significant financial and liquidity difficulties. Refer to Note 2, "Summary of Accounting Policies" for further discussion. These charges were partially offset by a gain of approximately $22.3 million associated with the partial extinguishment of the Company's 1% Convertible Subordinated Notes due August 1, 2010. Refer to Note 4, "Bank Borrowings and Long-Term Debt" for additional information.

[0000950123-10-052098:notes:119]
During fiscal year 2008, the Company recognized approximately $61.1 million in other charges related to other-than-temporary impairment and related charges on certain of the Company's investments. Of this amount, approximately $57.6 million was for the impairment loss and other related charges attributable to the Company's divestiture of an equity method investment, which was liquidated in January 2008. The Company received approximately $57.4 million of cash proceeds in connection with the divestiture of this investment. Refer to Note 2, "Summary of Accounting Policies" for further discussion of this investment.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000950123-10-052098:notes:120]
11.  RELATED PARTY TRANSACTIONS

[0000950123-10-052098:notes:121]
From July 2000 through December 2001, in connection with an investment partnership, one of the Company's subsidiaries made loans to several of its executive officers to fund their contributions to the investment partnership. Each loan was evidenced by a full-recourse promissory note in favor of the Company. Interest rates on the notes ranged from 5.05% to 6.40%.  The balance of these loans as of March 31, 2008, was $1.4 million and were paid off in full during fiscal year 2009. There were no other loans outstanding from the Company's executive officers as of March 31, 2010 or 2009.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950123-10-052098:notes:122]
9.  RESTRUCTURING CHARGES

[0000950123-10-052098:notes:123]
Historically, the Company has initiated a series of restructuring activities intended to realign the Company's global capacity and infrastructure with demand by its customers so as to optimize the operational efficiency, which included reducing excess workforce and capacity, and consolidating and relocating certain manufacturing, design and administrative facilities to lower-cost regions.

[0000950123-10-052098:notes:124]
The restructuring costs include employee severance, costs related to leased facilities, owned facilities that are no longer in use and are to be disposed of, leased equipment that is no longer in use and will be disposed of, and other costs associated with the exit of certain contractual agreements due to facility closures. The overall intent of these activities is that the Company shifts its manufacturing capacity to locations with higher efficiencies and, in most instances, lower costs, and better utilize its overall existing manufacturing capacity. This would enhance the Company's ability to provide cost-effective manufacturing service offerings, which in turn may enhance its ability to retain and expand the Company's existing relationships with customers and attract new business.

[0000950123-10-052098:notes:125]
Fiscal Year 2010

[0000950123-10-052098:notes:126]
The Company recognized restructuring charges of approximately $107.5 million during fiscal year 2010 primarily to rationalize the Company's global manufacturing capacity and infrastructure due to the recent macroeconomic crisis which significantly impacted our customers' businesses. The Company's restructuring activities are intended to improve its operational efficiencies by reducing excess workforce and capacity. In addition to the cost reductions, these activities will result in a further shift of manufacturing capacity to locations with higher efficiencies and, in most instances, lower costs. The costs associated with these restructuring activities included employee severance, costs related to owned and leased facilities and equipment that is no longer in use and is to be disposed of, and other costs associated with the exit of certain contractual arrangements due to facility closures. The Company classified approximately $92.4 million of these charges as cost of sales and approximately $15.1 million of these charges as selling, general and administrative expenses during fiscal year 2010.

[0000950123-10-052098:notes:127]
The components of the restructuring charges during fiscal year 2010 were as follows:

[0000950123-10-052098:notes:128]
|  |  | First |  |  | Second |  |  | Third |  |  | Fourth |  |  |  |
|  |  | Quarter |  |  | Quarter |  |  | Quarter |  |  | Quarter |  |  | Total |
|  |  | (In thousands) |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance | $ | 7,234 |  | $ | 1,765 |  | $ | 2,223 |  | $ | 5,214 |  | $ | 16,436 |
| Long-lived asset impairment |  | 1,004 |  |  | 2,154 |  |  | 1,326 |  |  | — |  |  | 4,484 |
| Other exit costs |  | 1,742 |  |  | 2,687 |  |  | (240) |  |  | — |  |  | 4,189 |
| Total restructuring charges |  | 9,980 |  |  | 6,606 |  |  | 3,309 |  |  | 5,214 |  |  | 25,109 |
| Asia: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance |  | 7,579 |  |  | 801 |  |  | 1,659 |  |  | 1,964 |  |  | 12,003 |
| Long-lived asset impairment |  | 21,482 |  |  | 1,558 |  |  | 1,589 |  |  | 4,694 |  |  | 29,323 |
| Other exit costs |  | 5,519 |  |  | (947) |  |  | 426 |  |  | (1,191) |  |  | 3,807 |
| Total restructuring charges |  | 34,580 |  |  | 1,412 |  |  | 3,674 |  |  | 5,467 |  |  | 45,133 |
| Europe: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance |  | 4,556 |  |  | 4,573 |  |  | 2,733 |  |  | 892 |  |  | 12,754 |
| Long-lived asset impairment |  | 9,305 |  |  | — |  |  | — |  |  | — |  |  | 9,305 |
| Other exit costs |  | 6,418 |  |  | — |  |  | 70 |  |  | 8,739 |  |  | 15,227 |
| Total restructuring charges |  | 20,279 |  |  | 4,573 |  |  | 2,803 |  |  | 9,631 |  |  | 37,286 |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance |  | 19,369 |  |  | 7,139 |  |  | 6,615 |  |  | 8,070 |  |  | 41,193 |
| Long-lived asset impairment |  | 31,791 |  |  | 3,712 |  |  | 2,915 |  |  | 4,694 |  |  | 43,112 |
| Other exit costs |  | 13,679 |  |  | 1,740 |  |  | 256 |  |  | 7,548 |  |  | 23,223 |
| Total restructuring charges | $ | 64,839 |  | $ | 12,591 |  | $ | 9,786 |  | $ | 20,312 |  | $ | 107,528 |

[0000950123-10-052098:notes:129]
During fiscal year 2010, the Company recognized approximately $41.2 million of employee termination costs associated with the involuntary terminations of 5,727 identified employees in connection with the charges described above. The identified involuntary employee terminations by reportable geographic region amounted to approximately 2,086, 2,740, and 901 for Asia, the Americas and Europe, respectively. Approximately $35.2 million of these charges were classified as a component of cost of sales.

[0000950123-10-052098:notes:130]
During fiscal year 2010, the Company recognized approximately $43.1 million of non-cash charges for the write-down of property and equipment to management's estimate of fair value associated with various manufacturing and administrative facility closures. Approximately $33.4 million of this amount was classified as a component of cost of sales. The restructuring charges recognized during fiscal year 2010 also included approximately $23.2 million for other exit costs, all of which were classified as a component of cost of sales. Other exit costs were primarily comprised of contractual obligations associated with facility and equipment lease terminations of $19.8 million, facility abandonment and refurbishment costs of $3.2 million, and approximately $0.2 million of other costs.

[0000950123-10-052098:notes:131]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of March 31, 2010 for charges incurred in fiscal year 2010 and prior periods:

[0000950123-10-052098:notes:132]
|  |  |  |  | Long-Lived |  |  |  |  |  |  |
|  |  |  |  | Asset |  | Other |  |  |
|  | Severance |  | Impairment |  | Exit Costs |  | Total |
|  | (In thousands) |
| Balance as of March 31, 2008 | $ | 166,254 |  | $ | — |  | $ | 119,439 |  | $ | 285,693 |
| Activities during the fiscal year 2009: |  |  |  |  |  |  |  |  |  |  |  |
| Provisions for charges incurred during the year |  | 108,956 |  |  | 53,233 |  |  | 17,596 |  |  | 179,785 |
| Cash payments for charges incurred in fiscal year 2009 |  | (42,355) |  |  | — |  |  | (2,646) |  |  | (45,001) |
| Cash payments for charges incurred in fiscal year 2008 |  | (124,736) |  |  | — |  |  | (64,624) |  |  | (189,360) |
| Cash payments for charges incurred in fiscal year 2007 and prior |  | (6,906) |  |  | — |  |  | (6,993) |  |  | (13,899) |
| Non-cash charges incurred during the year |  | — |  |  | (53,233) |  |  | (2,518) |  |  | (55,751) |
| Balance as of March 31, 2009 |  | 101,213 |  |  | — |  |  | 60,254 |  |  | 161,467 |
| Activities during the fiscal year 2010: |  |  |  |  |  |  |  |  |  |  |  |
| Provisions for charges incurred during the year |  | 41,193 |  |  | 43,112 |  |  | 23,223 |  |  | 107,528 |
| Cash payments for charges incurred in fiscal year 2010 |  | (29,661) |  |  | — |  |  | (21,021) |  |  | (50,682) |
| Cash payments for charges incurred in fiscal year 2009 |  | (61,926) |  |  | — |  |  | (3,828) |  |  | (65,754) |
| Cash payments for charges incurred in fiscal year 2008 and prior |  | (22,603) |  |  | — |  |  | (17,135) |  |  | (39,738) |
| Non-cash charges incurred during the year |  | — |  |  | (43,112) |  |  | (5,464) |  |  | (48,576) |
| Balance as of March 31, 2010 |  | 28,216 |  |  | — |  |  | 36,029 |  |  | 64,245 |
| Less: Current portion (classified as other current liabilities) |  | (27,228) |  |  | — |  |  | (14,805) |  |  | (42,033) |
| Accrued facility closure costs, net of current portion (classified as |  |  |  |  |  |  |  |  |  |  |  |
| other liabilities) | $ | 988 |  | $ | — |  | $ | 21,224 |  | $ | 22,212 |

[0000950123-10-052098:notes:133]
As of March 31, 2010, accrued costs related to restructuring charges incurred during fiscal year 2010 were approximately $13.7 million, the entire amount of which was classified as current.

[0000950123-10-052098:notes:134]
As of March 31, 2010 and 2009, accrued restructuring costs for charges incurred during fiscal year 2009 were approximately $13.3 million and $79.0 million, respectively, of which approximately $2.5 million and $4.8 million, respectively, was classified as a long-term obligation. As of March 31, 2010 and 2009, accrued restructuring costs for charges incurred during fiscal years 2008 and prior were approximately $37.3 million and $82.4 million, respectively, of which approximately $19.7 million and $29.0 million, respectively, was classified as a long-term obligation.

[0000950123-10-052098:notes:135]
As of March 31, 2010 and 2009, assets that were no longer in use and held for sale as a result of restructuring activities totaled approximately $46.9 million and $46.8 million, respectively, representing manufacturing facilities that have been closed as part of the Company's facility consolidations. These assets are recorded at the lesser of carrying value or fair value, which is based on comparable sales from prevailing market data. For assets held for sale, depreciation ceases and an impairment loss is recognized if the carrying amount of the asset exceeds its fair value less cost to sell. Assets held for sale are included in other current assets in the consolidated balance sheets.

[0000950123-10-052098:notes:136]
Fiscal Year 2009

[0000950123-10-052098:notes:137]
The Company recognized restructuring charges of approximately $179.8 million during fiscal year 2009 primarily to rationalize the Company's global manufacturing capacity and infrastructure as a result of weak macroeconomic conditions. The global economic crisis and decline in the Company's customers' products across all of the industries it serves, caused the Company's OEM customers to reduce their manufacturing and supply chain outsourcing and had negatively impacted the Company's capacity utilization levels. The Company's restructuring activities were intended to improve the operational efficiencies by reducing excess workforce and capacity. In addition to the cost reductions, these activities resulted in a further shift of manufacturing capacity to locations with higher efficiencies and, in most instances, lower costs. The costs associated with these restructuring activities included employee severance, costs related to owned and leased facilities and equipment that is no longer in use and is to be disposed of, and other costs associated with the exit of certain contractual arrangements due to facility closures. The Company classified approximately $155.1 million of these charges as cost of sales and approximately $24.7 million of these charges as selling, general and administrative expenses during fiscal year 2009.

[0000950123-10-052098:notes:138]
The components of the restructuring charges during the first and fourth quarters of fiscal year 2009 were as follows:

[0000950123-10-052098:notes:139]
|  |  | First |  |  | Second |  |  | Third |  |  | Fourth |  |  |  |
|  |  | Quarter |  |  | Quarter |  |  | Quarter |  |  | Quarter |  |  | Total |
|  |  | (In thousands) |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance | $ | 10,540 |  | $ | — |  | $ | — |  | $ | 28,878 |  | $ | 39,418 |
| Long-lived asset impairment |  | — |  |  | — |  |  | — |  |  | 11,699 |  |  | 11,699 |
| Other exit costs |  | — |  |  | — |  |  | — |  |  | 5,559 |  |  | 5,559 |
| Total restructuring charges |  | 10,540 |  |  | — |  |  | — |  |  | 46,136 |  |  | 56,676 |
| Asia: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance |  | 12,496 |  |  | — |  |  | — |  |  | 32,893 |  |  | 45,389 |
| Long-lived asset impairment |  | 121 |  |  | — |  |  | — |  |  | 40,239 |  |  | 40,360 |
| Other exit costs |  | 775 |  |  | — |  |  | — |  |  | 10,425 |  |  | 11,200 |
| Total restructuring charges |  | 13,392 |  |  | — |  |  | — |  |  | 83,557 |  |  | 96,949 |
| Europe: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance |  | 5,283 |  |  | — |  |  | — |  |  | 18,866 |  |  | 24,149 |
| Long-lived asset impairment |  | — |  |  | — |  |  | — |  |  | 1,174 |  |  | 1,174 |
| Other exit costs |  | — |  |  | — |  |  | — |  |  | 837 |  |  | 837 |
| Total restructuring charges |  | 5,283 |  |  | — |  |  | — |  |  | 20,877 |  |  | 26,160 |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance |  | 28,319 |  |  | — |  |  | — |  |  | 80,637 |  |  | 108,956 |
| Long-lived asset impairment |  | 121 |  |  | — |  |  | — |  |  | 53,112 |  |  | 53,233 |
| Other exit costs |  | 775 |  |  | — |  |  | — |  |  | 16,821 |  |  | 17,596 |
| Total restructuring charges | $ | 29,215 |  | $ | — |  | $ | — |  | $ | 150,570 |  | $ | 179,785 |

[0000950123-10-052098:notes:140]
During fiscal year 2009, the Company recognized approximately $109.0 million of employee termination costs associated with the involuntary terminations of 14,970 identified employees in connection with the charges described above. The identified involuntary employee terminations by reportable geographic region amounted to approximately 7,623, 4,832, and 2,515 for Asia, the Americas and Europe, respectively. Approximately $88.8 million of these charges were classified as a component of cost of sales.

[0000950123-10-052098:notes:141]
During fiscal year 2009, the Company recognized approximately $53.2 million of non-cash charges for the write-down of property and equipment to management's estimate of fair value associated with various manufacturing and administrative facility closures. Approximately $51.4 million of this amount was classified as a component of cost of sales. The restructuring charges recognized during fiscal year 2009 also included approximately $17.6 million for other exit costs, of which $14.9 million was classified as a component of cost of sales. Other exit costs were primarily comprised of contractual obligations associated with facility and equipment lease terminations of $12.5 million, and customer disengagement, facility abandonment and refurbishment costs of $5.1 million. The customer disengagement costs related primarily to inventory and other asset impairment charges resulting from customer contracts that were terminated by the Company as a result of various facility closures.

[0000950123-10-052098:notes:142]
Fiscal Year 2008

[0000950123-10-052098:notes:143]
The Company recognized restructuring charges of approximately $447.7 million during fiscal year 2008 primarily resulting from the acquisition of Solectron. These costs were related to restructuring activities which included closing, consolidating and relocating certain manufacturing, design and administrative operations, eliminating redundant assets, and reducing excess workforce and capacity. These actions impacted over 25 different manufacturing and design locations and were initiated in an effort to consolidate and integrate our global capacity and infrastructure so as to optimize the Company's operational efficiencies post-acquisition. The activities associated with these charges involved multiple actions at each location, were completed in multiple steps and were substantially completed within one year of the commitment dates of the respective activities, except for certain long-term contractual obligations. The Company classified approximately $408.9 million of these charges as a component of cost of sales during fiscal year 2008. The fiscal 2008 restructuring charge of approximately $447.7 million was net of approximately $52.9 million of customer reimbursements earned in accordance with the various agreements with Nortel. The reimbursements were included as a reduction of cost of sales during fiscal year 2008.

[0000950123-10-052098:notes:144]
The components of the restructuring charges during the first, third and fourth quarters of fiscal year 2008 were as follows:

[0000950123-10-052098:notes:145]
|  |  | First |  |  | Second |  |  | Third |  |  | Fourth |  |  |  |
|  |  | Quarter |  |  | Quarter |  |  | Quarter |  |  | Quarter |  |  | Total |
|  |  | (In thousands) |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance | $ | — |  | $ | — |  | $ | 14,405 |  | $ | 67,670 |  | $ | 82,075 |
| Long-lived asset impairment |  | — |  |  | — |  |  | 11,802 |  |  | 6,876 |  |  | 18,678 |
| Other exit costs |  | — |  |  | — |  |  | 17,538 |  |  | 28,189 |  |  | 45,727 |
| Total restructuring charges |  | — |  |  | — |  |  | 43,745 |  |  | 102,735 |  |  | 146,480 |
| Asia: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance |  | — |  |  | — |  |  | 23,286 |  |  | 3,701 |  |  | 26,987 |
| Long-lived asset impairment |  | — |  |  | — |  |  | 71,471 |  |  | 37,702 |  |  | 109,173 |
| Other exit costs |  | — |  |  | — |  |  | 33,027 |  |  | 9,704 |  |  | 42,731 |
| Total restructuring charges |  | — |  |  | — |  |  | 127,784 |  |  | 51,107 |  |  | 178,891 |
| Europe: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance |  | 10,674 |  |  | — |  |  | 44,137 |  |  | 41,191 |  |  | 96,002 |
| Long-lived asset impairment |  | — |  |  | — |  |  | 6,796 |  |  | 2,931 |  |  | 9,727 |
| Other exit costs |  | — |  |  | — |  |  | 23,370 |  |  | 46,142 |  |  | 69,512 |
| Total restructuring charges |  | 10,674 |  |  | — |  |  | 74,303 |  |  | 90,264 |  |  | 175,241 |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance |  | 10,674 |  |  | — |  |  | 81,828 |  |  | 112,562 |  |  | 205,064 |
| Long-lived asset impairment |  | — |  |  | — |  |  | 90,069 |  |  | 47,509 |  |  | 137,578 |
| Other exit costs |  | — |  |  | — |  |  | 73,935 |  |  | 84,035 |  |  | 157,970 |
|  |  | 10,674 |  |  | — |  |  | 245,832 |  |  | 244,106 |  |  | 500,612 |
| Less: Customer reimbursement |  | — |  |  | — |  |  | — |  |  | (52,924) |  |  | (52,924) |
| Total restructuring charges | $ | 10,674 |  | $ | — |  | $ | 245,832 |  | $ | 191,182 |  | $ | 447,688 |

[0000950123-10-052098:notes:146]
During fiscal year 2008, the Company recognized approximately $205.1 million of employee termination costs associated with the involuntary terminations of 8,932 identified employees in connection with the charges described above. The identified involuntary employee terminations by reportable geographic region amounted to approximately 5,588, 1,885,and 1,459 for Asia, the Americas, and Europe, respectively. Approximately $183.5 million of the charges were classified as a component of cost of sales.

[0000950123-10-052098:notes:147]
During fiscal year 2008, the Company recognized approximately $137.6 million of non-cash charges for the write-down of property and equipment to management's estimate of fair value associated with various manufacturing and administrative facility closures. Approximately $134.1 million of this amount was classified as a component of cost of sales. The restructuring charges recognized during fiscal year 2008 also included approximately $158.0 million for other exit costs, of which $144.2 million was classified as a component of cost of sales. Other exit costs were primarily comprised of contractual obligations associated with facility and equipment lease terminations of $65.7 million, customer disengagement costs of $52.4 million, facility abandonment and refurbishment costs of $39.9 million. The customer disengagement costs related primarily to inventory and other asset impairment charges resulting from customer contracts that were terminated by the Company as a result of various facility closures.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000950123-10-052098:notes:148]
14.  SEGMENT REPORTING

[0000950123-10-052098:notes:149]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker, or decision making group, in deciding how to allocate resources and in assessing performance. The Company's chief operating decision maker is its Chief Executive Officer. As of March 31, 2010, the Company operates and internally manages a single operating segment, Electronics Manufacturing Services.

[0000950123-10-052098:notes:150]
Geographic information is as follows:

[0000950123-10-052098:notes:151]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |  |
| Asia | $ | 11,595,401 |  | $ | 15,220,157 |  | $ | 15,517,113 |
| Americas |  | 7,831,035 |  |  | 10,315,794 |  |  | 7,688,701 |
| Europe |  | 4,684,297 |  |  | 5,412,624 |  |  | 4,352,321 |
|  | $ | 24,110,733 |  | $ | 30,948,575 |  | $ | 27,558,135 |

[0000950123-10-052098:notes:152]
|  | As of March 31, |
|  | 2010 |  | 2009 |
|  | (In thousands) |
| Long-lived assets: |  |  |  |  |  |
| Asia | $ | 1,094,222 |  | $ | 1,232,978 |
| Americas |  | 633,525 |  |  | 657,125 |
| Europe |  | 390,829 |  |  | 443,678 |
|  | $ | 2,118,576 |  | $ | 2,333,781 |

[0000950123-10-052098:notes:153]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0000950123-10-052098:notes:154]
For purposes of the preceding tables, "Asia" includes China, India, Indonesia, Japan, Korea, Labuan, Malaysia, Mauritius, Singapore, and Taiwan; "Americas" includes Brazil, Canada, Cayman Islands, Mexico, and the United States; "Europe" includes Austria, Belgium, the Czech Republic, Denmark, Finland, France, Germany, Hungary, Ireland, Israel, Italy, the Netherlands, Norway, Poland, Romania, Slovakia, Scotland, South Africa, Sweden, Turkey, Ukraine, and the United Kingdom. During fiscal years 2010 and 2009, there were no revenues attributable to Belgium, Cayman Islands, Korea, Scotland and South Africa, respectively.

[0000950123-10-052098:notes:155]
During fiscal years 2010, 2009 and 2008, net sales generated from Singapore, the principal country of domicile, were approximately $428.0 million, $444.2 million and $580.3 million, respectively.

[0000950123-10-052098:notes:156]
As of March 31, 2010 and 2009, long-lived assets held in Singapore were approximately $13.8 million and $36.5 million, respectively.

[0000950123-10-052098:notes:157]
During fiscal year 2010, China, Mexico, United States, and Malaysia accounted for approximately 33%, 15%, 14%, and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2010. As of March 31, 2010, China and Mexico accounted for approximately 42% and 17%, respectively, of consolidated long-lived assets. No other country accounted for more than 10% of long-lived assets as of March 31, 2010.

[0000950123-10-052098:notes:158]
During fiscal year 2009, China, United States, Malaysia and Mexico accounted for approximately 32%, 16%, 13% and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2009. As of March 31, 2009, China and Mexico accounted for approximately 43% and 15%, respectively, of consolidated long-lived assets. No other country accounted for more than 10% of long-lived assets as of March 31, 2009.

[0000950123-10-052098:notes:159]
During fiscal year 2008, China, Malaysia and the United States accounted for approximately 35%, 17% and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2008. As of March 31, 2008, China and Mexico accounted for approximately 39% and 15%, respectively, of consolidated long-lived assets. No other country accounted for more than 10% of long-lived assets as of March 31, 2008.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950123-10-052098:notes:160]
2.  SUMMARY OF ACCOUNTING POLICIES

[0000950123-10-052098:notes:161]
Basis of Presentation and Principles of Consolidation

[0000950123-10-052098:notes:162]
The Company's third fiscal quarter ends on December 31, and the fourth fiscal quarter and year ends on March 31 of each year. The first fiscal quarter ended on July 3, 2009, June 27, 2008 and June 29, 2007, respectively and the second fiscal quarter ended on October 2, 2009, September 26, 2008 and September 28, 2007, respectively. Amounts included in the consolidated financial statements are expressed in U.S. dollars unless otherwise designated.

[0000950123-10-052098:notes:163]
The accompanying consolidated financial statements include the accounts of Flextronics and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates all majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a minority interest for the ownership of the minority owners. As of March 31, 2010 and 2009, minority interest was not material. The associated minority owners' interest in the income or losses of these companies has not been material to the Company's results of operations for fiscal years 2010, 2009 and 2008, and has been classified within Interest and other expense, net, in the consolidated statements of operations.

[0000950123-10-052098:notes:164]
Use of Estimates

[0000950123-10-052098:notes:165]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; asset impairments; fair values of financial instruments including investments, notes receivable and derivative instruments; restructuring charges; contingencies; fair values of assets and liabilities obtained in business combinations and the fair values of options granted under the Company's stock-based compensation plans. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000950123-10-052098:notes:166]
Translation of Foreign Currencies

[0000950123-10-052098:notes:167]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet date. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as a separate component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for fiscal years 2010, 2009 and 2008, and have been classified as a component of interest and other expense, net in the consolidated statement of operations.

[0000950123-10-052098:notes:168]
Revenue Recognition

[0000950123-10-052098:notes:169]
The Company recognizes manufacturing revenue when it ships goods or the goods are received by its customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then the Company recognizes the related revenues at the time when such requirements are completed and the obligations are fulfilled. The Company makes provisions for estimated sales returns and other adjustments at the time revenue is recognized based upon contractual terms and an analysis of historical returns. These provisions were not material to the consolidated financial statements for the 2010, 2009 and 2008 fiscal years.

[0000950123-10-052098:notes:170]
The Company provides services for its customers that range from contract design to original product design to repair services. The Company recognizes service revenue when the services have been performed, and the related costs are expensed as incurred. Net sales for services were less than 10% of the Company's total sales in the 2010, 2009 and 2008 fiscal years, and accordingly, are included in net sales in the consolidated statements of operations.

[0000950123-10-052098:notes:171]
Customer Credit Risk

[0000950123-10-052098:notes:172]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.  During fiscal year 2009, the Company incurred $262.7 million of charges relating to Nortel and other customers that filed for bankruptcy or restructuring protection or otherwise experienced significant financial and liquidity difficulties. Of these charges, the Company classified approximately $189.5 million in cost of sales related to the write-down of inventory and associated contractual obligations and $73.3 million as selling, general and administrative expenses for provisions for doubtful accounts during fiscal year 2009.  We do not expect to incur additional charges relating to Nortel or other customers referenced above.

[0000950123-10-052098:notes:173]
In November 2009, the Company agreed to a settlement with Nortel primarily related to pre-bankruptcy petition claims. As a result, the Company revised its estimates related to the recovery of Nortel accounts receivable, certain retirement and contractual obligations and other claims. In addition, the Company has continued to recover amounts related to previously reserved inventory as a result of continuing business with Nortel post bankruptcy. During fiscal year 2010, the Company recorded a net $2.3 million reduction to the original charge, which included a reduction to cost of sales of $26.3 million and an increase to selling, general and administrative expenses of $24.0 million.

[0000950123-10-052098:notes:174]
Concentration of Credit Risk

[0000950123-10-052098:notes:175]
Financial instruments, which potentially subject the Company to concentrations of credit risk, are primarily accounts receivable, cash and cash equivalents, investments, and derivative instruments.

[0000950123-10-052098:notes:176]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2010, 2009 and 2008:

[0000950123-10-052098:notes:177]
|  | Balance at Beginning of Year | Charged to Costs and Expenses | Deductions/ Write-Offs | Balance at End of Year |
|  | (In thousands) |
| Allowance for doubtful accounts: |  |  |  |  |
| Year ended March 31, 2008 | $ 17,074 | $ 1,326 | $ (1,668) | $ 16,732 |
| Year ended March 31, 2009 | $ 16,732 | $ 73,845 | $ (61,557) | $ 29,020 |
| Year ended March 31, 2010 | $ 29,020 | $ 44,066 | $ (59,923) | $ 13,163 |

[0000950123-10-052098:notes:178]
The amount charged to costs and expenses net of deductions/write-offs for the fiscal years ended March 31, 2010 and 2009 includes $42.2 million and $52.6 million, respectively, attributable to Nortel discussed under Customer Credit Risk above.

[0000950123-10-052098:notes:179]
One customer accounted for approximately 10% of the Company's net sales in fiscal 2010. A separate customer accounted for approximately 11% and 16% of the Company's net sales in fiscal years 2009 and 2008, respectively. The Company's ten largest customers accounted for approximately 47%, 50% and 55% of its net sales, in fiscal years 2010, 2009, and 2008, respectively. As of March 31, 2010 and 2009, no single customer accounted for greater than 10% of the Company's total accounts receivable.

[0000950123-10-052098:notes:180]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's cash equivalents are primarily comprised of cash deposited in checking and money market accounts. The Company's investment policy limits the amount of credit exposure to 20% of the total investment portfolio in any single issuer.

[0000950123-10-052098:notes:181]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives at Note 5.

[0000950123-10-052098:notes:182]
Cash and Cash Equivalents

[0000950123-10-052098:notes:183]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts,  money market funds and time deposits.

[0000950123-10-052098:notes:184]
Cash and cash equivalents consisted of the following:

[0000950123-10-052098:notes:185]
|  | As of March 31, |
|  | 2010 |  | 2009 |
|  | (In thousands) |
| Cash and bank balances | $ 715,146 |  | $ 1,024,694 |
| Money market funds and time deposits | 1,212,410 |  | 797,192 |
|  | $ 1,927,556 |  | $ 1,821,886 |

[0000950123-10-052098:notes:186]
Inventories

[0000950123-10-052098:notes:187]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or market value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or market write-downs, were as follows:

[0000950123-10-052098:notes:188]
|  | As of March 31, |
|  | 2010 |  | 2009 |
|  | (In thousands) |
| Raw materials | $ 1,874,244 |  | $ 1,907,584 |
| Work-in-progress | 480,216 |  | 524,038 |
| Finished goods | 521,359 |  | 565,163 |
|  | $ 2,875,819 |  | $ 2,996,785 |

[0000950123-10-052098:notes:189]
Property and Equipment

[0000950123-10-052098:notes:190]
Property and equipment are stated at cost. Depreciation and amortization is recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are amortized over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment was comprised of the following:

[0000950123-10-052098:notes:191]
|  | Depreciable |  |  |
|  | Life |  | As of March 31, |
|  | (In Years) |  | 2010 |  | 2009 |
|  |  |  | (In thousands) |
| Machinery and equipment | 3-10 |  | $ 2,286,988 |  | $ 2,335,273 |
| Buildings | 30 |  | 963,460 |  | 1,019,454 |
| Leasehold improvements | up to 30 |  | 250,373 |  | 237,136 |
| Furniture, fixtures, computer equipment and software | 3-7 |  | 367,206 |  | 404,477 |
| Land | — |  | 137,959 |  | 150,204 |
| Construction-in-progress | — |  | 145,925 |  | 97,565 |
|  |  |  | 4,151,911 |  | 4,244,109 |
| Accumulated depreciation and amortization |  |  | (2,033,335) |  | (1,910,328) |
| Property and equipment, net |  |  | $ 2,118,576 |  | $ 2,333,781 |

[0000950123-10-052098:notes:192]
Total depreciation expense associated with property and equipment amounted to approximately $375.9 million, $385.5 million and $338.4 million in fiscal years 2010, 2009 and 2008, respectively. Proceeds from the disposition of property and equipment were $58.1 million, $51.9 million and $140.3 million in fiscal years 2010, 2009 and 2008, respectively, and are presented net with purchases of property and equipment within cash flows from investing activities in the consolidated statements of cash flows. Property and equipment excludes assets no longer in use and held for sale as a result of restructuring activities, as discussed in Note 9.

[0000950123-10-052098:notes:193]
The Company reviews property and equipment for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is measured by comparing its carrying amount to the projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of a long-lived asset exceeds its fair value. Refer to Note 9, "Restructuring Charges" for a discussion of impairment charges recorded in fiscal years 2010, 2009 and 2008.

[0000950123-10-052098:notes:194]
Deferred Income Taxes

[0000950123-10-052098:notes:195]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences.

[0000950123-10-052098:notes:196]
Accounting for Business and Asset Acquisitions

[0000950123-10-052098:notes:197]
The Company has actively pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's Consolidated Financial Statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the identified fair value of the assets and liabilities acquired is recognized as goodwill.

[0000950123-10-052098:notes:198]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings.  Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000950123-10-052098:notes:199]
Goodwill and Other Intangibles

[0000950123-10-052098:notes:200]
Goodwill is tested for impairment on an annual basis, and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. The Company has one reporting unit: Electronic Manufacturing Services. If the recorded value of the assets, including goodwill, and liabilities ("net book value") of the reporting unit exceeds its fair value, an impairment loss may be required to be recognized. Further, to the extent the net book value of the Company as a whole is greater than its market capitalization, all, or a significant portion of its goodwill may be considered impaired. The Company completed its annual impairment test during its fourth quarter of fiscal year 2010 and determined that no impairment existed as of the date of the impairment test. The fair value of the reporting unit significantly exceeded the carrying value.

[0000950123-10-052098:notes:201]
During its third fiscal quarter of 2009, which ended December 31, 2008, the Company concluded that an interim goodwill impairment analysis was required based on the significant decline in the Company's market capitalization during the quarter. This decline in market capitalization was driven largely by deteriorating macroeconomic conditions that contributed to a considerable decrease in market multiples as well as a decline in the Company's estimated discounted cash flows.

[0000950123-10-052098:notes:202]
Pursuant to the accounting guidance for goodwill and other intangible assets, the measurement of impairment of goodwill consists of two steps.  In the first step, the fair value of the Company is compared to its carrying value.  In connection with the preparation of interim financial statements for the period ended December 31, 2008, management completed a valuation of the Company, which incorporated existing market-based considerations as well as a discounted cash flow methodology based on current results and projections, and concluded the estimated fair value of the Company was less than its net book value.  Accordingly the guidance required a second step to determine the implied fair value of the Company's goodwill, and to compare it to the carrying value of the Company's goodwill.  This second step included valuing all of the tangible and intangible assets and liabilities of the Company as if it had been acquired in a business combination, including valuing all of the Company's intangible assets even if they were not currently recorded to determine the implied fair value of goodwill.  The result of this assessment indicated that the implied fair value of goodwill as of that date was zero.  As a result, the Company recognized a non-cash impairment charge of approximately $5.9 billion during the quarter ended December 31, 2008 to write-off the entire carrying value of its goodwill.

[0000950123-10-052098:notes:203]
The following table summarizes the activity in the Company's goodwill account during fiscal years 2010 and 2009:

[0000950123-10-052098:notes:204]
|  | As of March 31, |
|  | 2010 |  | 2009 |
|  | (In thousands) |
| Balance, beginning of the year | $ 36,776 |  | $ 5,559,351 |
| Additions (1) | 17,635 |  | 118,240 |
| Impairment | — |  | (5,949,977) |
| Purchase accounting adjustments and |  |  |  |
| reclassification to other intangibles (2) | 31,646 |  | 385,275 |
| Foreign currency translation adjustments | (1,697) |  | (76,113) |
| Balance, as of March 31, 2010 and 2009, net of accumulated impairment |  |  |  |
| of $5,949,977, respectively | $ 84,360 |  | $ 36,776 |

[0000950123-10-052098:notes:205]
__________

[0000950123-10-052098:notes:206]
| (1) | For fiscal years 2010 and 2009, additions were attributable to certain acquisitions that were not individually, nor in the aggregate, significant to the Company. Refer to the discussion of the Company's acquisitions in Note 12, "Business and Asset Acquisitions and Divestitures." |
| (2) | Includes adjustments and reclassifications resulting from management's review and finalization of the valuation of assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition, based on management's estimates. Adjustments and reclassifications during fiscal year 2010 was attributable to purchase accounting adjustments for certain historical acquisitions that were not individually significant to the Company. Adjustments and reclassifications during fiscal year 2009 included approximately $362.5 million attributable to the Company's October 2007 acquisition of Solectron, and other purchase accounting adjustments for certain acquisitions that were not individually significant to the Company. Refer to the discussion of the Company's acquisitions in Note 12, "Business and Asset Acquisitions and Divestitures." |

[0000950123-10-052098:notes:207]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets concurrent with its testing of goodwill for impairment for the period ended March 31, 2010 and concluded that such amounts continued to be recoverable.

[0000950123-10-052098:notes:208]
Intangible assets are comprised of customer-related intangibles, which primarily include contractual agreements and customer relationships; and licenses and other intangibles, which is primarily comprised of licenses and also includes patents and trademarks, and developed technologies. Generally customer-related intangibles are amortized on an accelerated method based on expected cash flows, generally over a period of up to eight years, and licenses and other intangibles generally over a period of up to seven years. No residual value is estimated for any intangible assets. During fiscal year 2010, the Company did not have any material additions to intangible assets. During fiscal year 2009, the Company added approximately $71.6 million of intangible assets comprised of approximately $56.8 million related to customer related intangible assets, and approximately $14.8 million related to acquired licenses and other intangibles. The fair value of the Company's intangible assets purchased through business combinations is principally determined based on management's estimates of cash flow and recoverability. The Company is in the process of determining the fair value of its intangible assets acquired from certain acquisitions made in fiscal 2010. Such valuations will be completed within one year of purchase. Accordingly, these amounts represent preliminary estimates, which are subject to change upon finalization of purchase accounting, and any such change may have a material effect on the Company's results of operations. The components of acquired intangible assets are as follows:

[0000950123-10-052098:notes:209]
|  | As of March 31, 2010 |  | As of March 31, 2009 |
|  | Gross |  |  |  |  | Net |  | Gross |  |  |  |  | Net |
|  | Carrying |  | Accumulated |  | Carrying |  | Carrying |  | Accumulated |  | Carrying |
|  | Amount |  | Amortization |  | Amount |  | Amount |  | Amortization |  | Amount |
|  | (In thousands) |  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 506,595 |  | $ | (355,409) |  | $ | 151,186 |  | $ | 506,449 |  | $ | (280,046) |  | $ | 226,403 |
| Licenses and other intangibles... |  | 54,792 |  |  | (35,621) |  |  | 19,171 |  |  | 54,559 |  |  | (26,247) |  |  | 28,312 |
| Total | $ | 561,387 |  | $ | (391,030) |  | $ | 170,357 |  | $ | 561,008 |  | $ | (306,293) |  | $ | 254,715 |

[0000950123-10-052098:notes:210]
Total intangible amortization expense recognized during fiscal years 2010, 2009, and 2008 was $89.6 million, $135.9 million, and $112.3 million, respectively. As of March 31, 2010, the weighted-average remaining useful lives of the Company's intangible assets were approximately 2.2 years and 3.2 years for customer-related intangibles, and licenses and other intangibles, respectively. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000950123-10-052098:notes:211]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2011 | $ | 64,433 |
| 2012 |  | 42,311 |
| 2013 |  | 28,786 |
| 2014 |  | 18,964 |
| 2015 |  | 9,506 |
| Thereafter |  | 6,357 |
| Total amortization expense | $ | 170,357 |

[0000950123-10-052098:notes:212]
Derivative Instruments and Hedging Activities

[0000950123-10-052098:notes:213]
All derivative instruments are recognized on the consolidated balance sheet at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is measured quarterly based on a regression of the forward rate on the derivative instrument against the forward rate for the furthest time period the hedged item can be recognized and still be within the documented hedge period. The effective portion of changes in the fair value of the derivative instrument is recognized in shareholders' equity as a separate component of accumulated other comprehensive income, and recognized in the consolidated statement of operations when the hedged item affects earnings. Ineffective portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Additional information is included in Note 5.

[0000950123-10-052098:notes:214]
Other Assets

[0000950123-10-052098:notes:215]
The Company has certain equity investments in, and notes receivable from, non-publicly traded companies, which are included within other assets in the Company's consolidated balance sheets. Non-majority-owned investments are accounted for using the equity method when the Company has an ownership percentage equal to or greater than 20%, or has the ability to significantly influence the operating decisions of the issuer; otherwise the cost method is used. The Company monitors these investments for impairment and makes appropriate reductions in carrying values as required. Fair values of these investments, when required, are estimated using unobservable inputs, primarily discounted cash flow projections.

[0000950123-10-052098:notes:216]
As of March 31, 2010 and 2009, the Company's equity investments in non-majority owned companies totaled $27.3 million and $120.7 million, respectively, of which $1.9 million and $7.0 million, respectively, were accounted for using the equity method. Notes receivable from these investments were $0 and $352.9 million as of March 31, 2010 and 2009, respectively.  The equity in the earnings or losses of the Company's equity method investments were not material to the consolidated results of operations for fiscal years 2010, 2009 and 2008.

[0000950123-10-052098:notes:217]
In August 2009, the Company sold its entire interest in one of its non-majority owned investments and related note receivable for cash of approximately $252.5 million, net of closing costs. In conjunction with this transaction, the Company recognized an impairment charge of approximately $107.4 million during the first quarter of 2010. During the second quarter fiscal 2010, as a result deterioration in the business prospects, cash flow expectations, and increased liquidity concerns, the Company recognized charges totaling approximately $92.0 million associated with the other-than-temporary impairment of our notes receivable from one affiliate and an equity investment in another affiliate.  Total impairment charges related to the Company's equity investments and notes receivable for fiscal year 2010 were approximately $199.4 million and are included in Other charges, net in the Consolidated Statements of Operations.  During fiscal year 2009, the Company recognized an approximate $74.1 million impairment charge to write-down notes receivable from an affiliate to its expected recoverable amount, which was included in Other charges, net in the Consolidated Statements of Operations.

[0000950123-10-052098:notes:218]
In January 2008, the Company liquidated all of its approximately 35% investment in the common stock of an affiliate, which was accounted for under the equity method. The Company decided to sell its investment to the majority holder rather than participate in a new equity round of financing. The Company received approximately $57.4 million of cash proceeds in connection with the divestiture of this equity investment and recognized an impairment loss of approximately $48.5 million based on the price at which it was sold.

[0000950123-10-052098:notes:219]
Restructuring Charges

[0000950123-10-052098:notes:220]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing and administrative facilities. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000950123-10-052098:notes:221]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed exit plans.  See Note 9 for additional information regarding restructuring charges.

[0000950123-10-052098:notes:222]
Stock-Based Compensation

[0000950123-10-052098:notes:223]
Equity Compensation Plans

[0000950123-10-052098:notes:224]
As of March 31, 2010, the Company grants equity compensation awards from four plans: the 2001 Equity Incentive Plan (the "2001 Plan"), the 2002 Interim Incentive Plan (the "2002 Plan"), the 2004 Award Plan for New Employees (the "2004 Plan") and the Solectron Corporation 2002 Stock Plan, which was assumed by the Company as a result of its acquisition of Solectron. These plans are collectively referred to as the Company's equity compensation plans below.

[0000950123-10-052098:notes:225]
·         The 2001 Plan provides for grants of up to 62.0 million ordinary shares (plus shares available under prior Company plans and assumed plans consolidated into the 2001 Plan). The 2001 Plan provides for grants of incentive and nonqualified stock options and share bonus awards to employees, officers and non-employee directors. Options issued to employees under the 2001 Plan generally vest over four years and generally expire either seven or ten years from the date of grant. Options granted to non-employee directors expire five years from the date of grant.

[0000950123-10-052098:notes:226]
·         The 2002 Plan provides for grants of up to 20.0 million ordinary shares. The 2002 Plan provides for grants of nonqualified stock options and share bonus awards to employees and officers. Options issued under the 2002 Plan generally vest over four years and generally expire either seven or ten years from the date of grant. Share bonus awards generally vest in installments over a three to five year period.

[0000950123-10-052098:notes:227]
·         The 2004 Plan provides for grants of up to 10.0 million ordinary shares. The 2004 Plan provides for grants of nonqualified stock options and share bonus awards to new employees. Options issued under the 2004 Plan generally vest over four years and generally expire either seven or ten years from the date of grant. Share bonus awards generally vest in installments over a three to five year period.

[0000950123-10-052098:notes:228]
·         In connection with the acquisition of Solectron (see Note 12), the Company assumed the Solectron corporation 2002 Stock Plan (the "SLR Plan"), including all options to purchase Solectron common stock with exercise prices equal to, or less than, $5.00 per share of Solectron common stock outstanding under such plan. Each option assumed was converted into an option to acquire the Company's ordinary shares and the Company assumed approximately 7.4 million vested and unvested options with exercise prices ranging between $5.45 and $14.41 per Flextronics ordinary share. Further, there were approximately 19.4 million shares available for grant under the SLR Plan when it was assumed by the Company.

[0000950123-10-052098:notes:229]
The SLR plan provides for grants of nonqualified stock options to new employees and to legacy Solectron employees who joined the Company in connection with the acquisition. Options issued under the SLR Plan generally vest over four years and generally expire either seven or ten years from the date of grant.

[0000950123-10-052098:notes:230]
The exercise price of options granted under the Company's equity compensation plans is determined by the Company's Board of Directors or the Compensation Committee and typically equals or exceeds the closing price of the Company's ordinary shares on the date of grant.

[0000950123-10-052098:notes:231]
The Company grants share bonus awards under its equity compensation plans. Share bonus awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. Share bonus awards generally vest in installments over a three to five year period and unvested share bonus awards are forfeited upon termination of employment. Vesting for certain share bonus awards is contingent upon both service and performance criteria.

[0000950123-10-052098:notes:232]
Stock-Based Compensation Expense

[0000950123-10-052098:notes:233]
The following table summarizes the Company's stock-based compensation expense:

[0000950123-10-052098:notes:234]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
|  | (In thousands) |
| Cost of sales | $ 10,847 |  | $ 9,283 |  | $ 6,850 |
| Selling, general and administrative expenses | 45,627 |  | 47,631 |  | 40,791 |
| Total stock-based compensation expense | $ 56,474 |  | $ 56,914 |  | $ 47,641 |

[0000950123-10-052098:notes:235]
As required by the authoritative guidance for stock-based compensation, management made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as an analysis of actual option forfeitures. Total stock-based compensation capitalized as part of inventory during the fiscal years ended March 31, 2010 and 2009 was not material.

[0000950123-10-052098:notes:236]
As of March 31, 2010, the total compensation cost related to unvested stock options granted to employees under the Company's equity compensation plans, but not yet recognized, was approximately $60.5 million. This cost will be amortized on a straight-line basis over a weighted-average period of approximately 2.0 years and will be adjusted for estimated forfeitures. As of March 31, 2010, the total unrecognized compensation cost related to unvested share bonus awards granted to employees under the Company's equity compensation plans was approximately $54.4 million. This cost will be amortized generally on a straight-line basis over a weighted-average period of approximately 1.2 years and will be adjusted for estimated forfeitures. Approximately $27.4 million of the unrecognized compensation cost is related to share bonus awards where vesting is contingent upon meeting both a service requirement and achievement of longer-term goals.  As further discussed below, this cost will not be recognized unless it is determined that vesting of these awards is probable.

[0000950123-10-052098:notes:237]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of stock options over the stock-based compensation cost recognized for those options) are classified as financing cash flows pursuant to the authoritative guidance. During fiscal years 2010, 2009 and 2008, the Company did not recognize any excess tax benefits as a financing cash inflow related to its equity compensation plans.

[0000950123-10-052098:notes:238]
Determining Fair Value

[0000950123-10-052098:notes:239]
Valuation and Amortization Method — The Company estimates the fair value of stock options granted using the Black-Scholes option-pricing formula and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period. The fair market value of share bonus awards granted is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period. For share bonus awards where vesting is contingent upon both a service and a performance condition, compensation expense is recognized on a graded attribute basis over the respective requisite service period of the award when achievement of the performance condition is considered probable.

[0000950123-10-052098:notes:240]
Expected Term — The Company's expected term used in the Black-Scholes valuation method represents the period that the Company's stock options are expected to be outstanding and is determined based on historical experience of similar awards, giving consideration to the contractual terms of the stock options, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its stock options.

[0000950123-10-052098:notes:241]
Expected Volatility — The Company's expected volatility used in the Black-Scholes valuation method is derived from a combination of implied volatility related to publicly traded options to purchase Flextronics ordinary shares and historical variability in the Company's periodic stock price.

[0000950123-10-052098:notes:242]
Expected Dividend — The Company has never paid dividends on its ordinary shares and currently does not intend to do so in the near term, and accordingly, the dividend yield percentage is zero for all periods.

[0000950123-10-052098:notes:243]
Risk-Free Interest Rate — The Company bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0000950123-10-052098:notes:244]
The fair value of the Company's stock options granted to employees for fiscal years 2010, 2009 and 2008, other than those granted in connection with the option exchange in fiscal year 2010 and those with market criteria discussed below, was estimated using the following weighted-average assumptions:

[0000950123-10-052098:notes:245]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
| Expected term | 4.5 years |  | 4.2 years |  | 4.6 years |
| Expected volatility |  | 53.8 | % |  |  | 51.0 | % |  |  | 36.2 | % |
| Expected dividends |  | 0.0 | % |  |  | 0.0 | % |  |  | 0.0 | % |
| Risk-free interest rate |  | 1.3 | % |  |  | 2.2 | % |  |  | 4.2 | % |
| Weighted-average fair value | $ | 2.75 |  |  | $ | 2.22 |  |  | $ | 4.29 |  |

[0000950123-10-052098:notes:246]
Options granted during the 2010 and 2009 fiscal years had contractual lives of seven years, and options granted during fiscal year 2008 had contractual lives of ten years.

[0000950123-10-052098:notes:247]
During the 2009 fiscal year, 2.7 million options were granted to certain key employees which vest over a period of four years. These options expire seven years from the date of grant and are exercisable only when the Company's stock price is $12.50 per share, or above. The fair value of these options was estimated to be $4.25 per share and were calculated using a lattice model.

[0000950123-10-052098:notes:248]
Stock-Based Awards Activity

[0000950123-10-052098:notes:249]
On July 14, 2009, the Company launched an exchange offer under which eligible employees had the opportunity to voluntarily exchange their eligible outstanding stock options for a lesser amount of replacement stock options with new exercise prices equal to the closing price of the Company's ordinary shares on the date of exchange (the "Exchange").  The Exchange offer was not open to the Company's Board of Directors or its executive officers.  To be eligible for exchange an option must: (i) have had an exercise price of at least $10.00 per share, (ii) have been outstanding, and (iii) have been granted at least 12 months prior to the commencement date of the Exchange offer.  All replacement option grants were subject to a vesting schedule of two, three or four years from the date of grant of the replacement options depending on the remaining vesting period of the option grants surrendered for cancellation in the Exchange.  Stock options with exercise prices between $10.00 and $11.99 were exchangeable for new options at a rate of 1.5 existing options per new option grant, and stock options with exercise prices of $12.00 or more were exchangeable at a rate of 2.4 existing options per new option grant. Outstanding options covering approximately 29.8 million shares were eligible to participate in the Exchange.

[0000950123-10-052098:notes:250]
The Exchange was completed on August 11, 2009. Approximately 27.9 million stock options were tendered in the Exchange, and approximately 16.9 million replacement options were granted with an exercise price of $5.57, a weighted average vesting term of 1.58 years, and a contractual life of 7 years.  The Exchange was accounted for as a modification of the existing option awards tendered in the Exchange. As a result of the Exchange, the Company will recognize approximately $1.8 million in incremental compensation expense over the expected service period of the replacement grants' vesting terms.

[0000950123-10-052098:notes:251]
The following is a summary of option activity for the Company's equity compensation plans, excluding unvested share bonus awards ("Price" reflects the weighted-average exercise price):

[0000950123-10-052098:notes:252]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
|  | Options |  | Price |  | Options |  | Price |  | Options |  | Price |
| Outstanding, beginning of fiscal year | 81,927,879 |  | $ 9.13 |  | 52,541,413 |  | $ 11.67 |  | 51,821,915 |  | $ 11.63 |
| Granted | 869,600 |  | 6.17 |  | 43,586,251 |  | 6.21 |  | 5,391,475 |  | 11.66 |
| Granted under option exchange program | 16,867,452 |  | 5.57 |  | — |  | — |  | — |  | — |
| Assumed in business combination |  |  |  |  |  |  |  |  |  |  |  |
| (Note 12) | — |  | — |  | — |  | — |  | 7,355,133 |  | 10.68 |
| Exercised | (2,496,254) |  | 6.54 |  | (2,242,639) |  | 6.13 |  | (4,291,426) |  | 8.39 |
| Forfeited | (6,376,879) |  | 9.50 |  | (11,957,146) |  | 10.16 |  | (7,735,684) |  | 12.31 |
| Cancelled under option exchange program | (27,923,229) |  | 11.85 |  | — |  | — |  | — |  | — |
| Outstanding, end of fiscal year | 62,868,569 |  | $ 7.16 |  | 81,927,879 |  | $ 9.13 |  | 52,541,413 |  | $ 11.67 |
| Options exercisable, end of fiscal year | 24,989,665 |  | $ 10.71 |  | 34,329,956 |  | $ 12.51 |  | 39,931,387 |  | $ 11.80 |

[0000950123-10-052098:notes:253]
The aggregate intrinsic value of options exercised (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise) under the Company's equity compensation plans was $10.3 million, $6.3 million and $14.5 million during fiscal years 2010, 2009 and 2008, respectively.

[0000950123-10-052098:notes:254]
Cash received from option exercises under all equity compensation plans was $6.0 million, $13.8 million and $35.9 million for fiscal years 2010, 2009 and 2008, respectively.

[0000950123-10-052098:notes:255]
The following table presents the composition of options outstanding and exercisable as of March 31, 2010:

[0000950123-10-052098:notes:256]
|  | Options Outstanding |  | Options Exercisable |
|  |  |  | Weighted |  |  |  |  |  |  |
|  |  |  | Average |  |  |  |  |  |  |
|  |  |  | Remaining |  | Weighted |  |  |  | Weighted |
|  | Number of |  | Contractual |  | Average |  | Number of |  | Average |
|  | Shares |  | Life |  | Exercise |  | Shares |  | Exercise |
| Range of Exercise Prices | Outstanding |  | (In Years) |  | Price |  | Exercisable |  | Price |
| $ 1.94 – $2.26 | 19,075,550 |  | 5.71 |  | $ 2.22 |  | 3,129,575 |  | $ 2.20 |
| $ 3.35 – $5.75 | 16,316,384 |  | 6.35 |  | 5.56 |  | 29,612 |  | 5.39 |
| $ 5.87 – $7.07 | 1,215,915 |  | 3.61 |  | 6.01 |  | 828,215 |  | 5.89 |
| $ 7.08 – $10.60 | 12,457,294 |  | 4.60 |  | 9.83 |  | 7,330,221 |  | 9.54 |
| $ 10.67 – $11.41 | 1,593,383 |  | 5.81 |  | 11.13 |  | 1,509,717 |  | 11.12 |
| $ 11.53 – $13.98 | 8,444,327 |  | 4.39 |  | 12.44 |  | 8,396,609 |  | 12.44 |
| $ 14.34 – $23.19 | 3,765,716 |  | 3.30 |  | 17.16 |  | 3,765,716 |  | 17.16 |
| $ 1.94 – $23.19 | 62,868,569 |  | 5.30 |  | $ 7.16 |  | 24,989,665 |  | $ 10.71 |
| Options vested and expected to vest.. | 61,157,681 |  | 5.28 |  | $ 7.23 |  |  |  |  |

[0000950123-10-052098:notes:257]
As of March 31, 2010, the aggregate intrinsic value for options outstanding, options vested and expected to vest (which includes adjustments for expected forfeitures), and options exercisable were $146.9 million, $140.9 million and $19.4 million, respectively. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2010 for the approximately 37.1 million options that were in-the-money at March 31, 2010. As of March 31, 2010, the weighted average remaining contractual life for options exercisable was 4.3 years.

[0000950123-10-052098:notes:258]
The following table summarizes the Company's share bonus award activity ("Price" reflects the weighted-average grant-date fair value):

[0000950123-10-052098:notes:259]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested share bonus awards outstanding, |  |  |  |  |  |  |  |  |  |  |  |
| beginning of fiscal year | 10,456,905 |  | $10.31 |  | 8,866,364 |  | $10.70 |  | 4,332,500 |  | $ 8.11 |
| Granted | 523,229 |  | 7.08 |  | 4,364,194 |  | 9.30 |  | 6,540,197 |  | 11.42 |
| Vested | (1,331,357) |  | 8.98 |  | (1,825,252) |  | 9.41 |  | (1,564,733) |  | 6.71 |
| Forfeited | (847,168) |  | 10.40 |  | (948,401) |  | 11.08 |  | (441,600) |  | 10.24 |
| Unvested share bonus awards outstanding, |  |  |  |  |  |  |  |  |  |  |  |
| end of fiscal year | 8,801,609 |  | $10.31 |  | 10,456,905 |  | $10.31 |  | 8,866,364 |  | $10.70 |

[0000950123-10-052098:notes:260]
Of the unvested share bonus awards granted under the Company's equity compensation plans during fiscal years 2009 and 2008, 1,930,000 and 1,162,500, respectively, were granted to certain key employees whereby vesting is contingent upon both a service requirement and the Company's achievement of certain longer-term goals over a period of three to five years.  Due to a change in business outlook, which has been significantly impacted by the macroeconomic decline which began in fiscal 2009, management believes that achievement of these longer-term goals is no longer probable.  Accordingly, approximately 2.8 million of these unvested share bonus awards are not expected to vest. As a result, in the fourth quarter of fiscal year 2009, approximately $8.9 million in cumulative compensation expense previously recognized through December 31, 2008 (including $4.7 million recognized in fiscal years 2008 and prior) for share bonus awards with both a service requirement and a performance condition was reversed. Compensation expense will not be recognized for these share bonus awards unless management determines it is again probable these share bonus awards will vest for which a cumulative catch-up of expense would be recorded.

[0000950123-10-052098:notes:261]
The total intrinsic value of shares vested under the Company's equity compensation plans was $7.0 million, $17.2 million and $17.7 million during fiscal years 2010, 2009 and 2008, respectively, based on the closing price of the Company's ordinary shares on the date vested.

[0000950123-10-052098:notes:262]
Earnings (Loss) Per Share

[0000950123-10-052098:notes:263]
Basic earnings per share exclude dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000950123-10-052098:notes:264]
Diluted earnings per share reflects the potential dilution from stock options, share bonus awards and convertible securities. The potential dilution from stock options exercisable into ordinary share equivalents and share bonus awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period. The potential dilution from the conversion spread (excess of conversion value over face value) of the Subordinated Notes convertible into ordinary share equivalents was calculated as the quotient of the conversion spread and the average fair market value of the Company's ordinary shares for the period.

[0000950123-10-052098:notes:265]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income per share:

[0000950123-10-052098:notes:266]
|  | Fiscal Year Ended March 31, |
|  | 2010 |  | 2009 |  | 2008 |
|  | (In thousands, except per share amounts) |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 18,594 |  | $ | (6,135,518) |  | $ | (681,383) |
| Shares used in computation: |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  | 811,677 |  |  | 820,955 |  |  | 720,523 |
| Basic earnings (loss) per share | $ | 0.02 |  | $ | (7.47) |  | $ | (0.95) |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 18,594 |  | $ | (6,135,518) |  | $ | (681,383) |
| Shares used in computation: |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  | 811,677 |  |  | 820,955 |  |  | 720,523 |
| Weighted-average ordinary share equivalents from |  |  |  |  |  |  |  |  |
| stock options and awards (1) |  | 9,435 |  |  | — |  |  | — |
| Weighted-average ordinary share equivalents from |  |  |  |  |  |  |  |  |
| convertible notes (2) |  | — |  |  | — |  |  | — |
| Weighted-average ordinary shares and ordinary share |  |  |  |  |  |  |  |  |
| equivalents outstanding |  | 821,112 |  |  | 820,955 |  |  | 720,523 |
| Diluted earnings (loss) per share | $ | 0.02 |  | $ | (7.47) |  | $ | (0.95) |

[0000950123-10-052098:notes:267]
| (1) | As a result of the Company's net loss, ordinary share equivalents from approximately 1.6 million and 5.7 million options and share bonus awards were excluded from the calculation of diluted earnings (loss) per share during the twelve-month period ended March 31, 2009 and 2008, respectively. Additionally, ordinary share equivalents from stock options to purchase approximately 38.1 million, 61.5 million and 39.4 million shares during fiscal years 2010, 2009 and 2008, respectively, were excluded from the computation of diluted earnings per share primarily because the exercise price of these options was greater than the average market price of the Company's ordinary shares during the respective periods. |
| (2) | On July 31, 2009, the principal amount of the Company's Zero Coupon Convertible Junior Subordinated Notes was settled in cash upon maturity. These notes carried conversion provisions to issue shares to settle any conversion spread (excess of the conversion value over the conversion price) in stock. The conversion price was $10.50 per share. On the maturity date the Company's stock price was less than the conversion price, and therefore no shares were issued. |
|  | During December 2008, the Company purchased an aggregate principal amount of $260.0 million of its outstanding 1% Convertible Subordinated Notes, which resulted in a reduction of the ordinary share equivalents into which such notes were convertible from approximately 32.2 million to approximately 15.5 million. As the Company has the positive intent and ability to settle the principal amount of these notes in cash, all ordinary share equivalents related to the principal portion of the Notes are excluded from the computation of diluted earnings per share for fiscal 2010, 2009 and 2008. The Company intends to settle any conversion spread (excess of the conversion value over conversion price) in stock. The conversion price is $15.525 per share (subject to certain adjustments). During fiscal years 2010, 2009 and 2008, the conversion obligation was less than the principal portion of these notes and accordingly, no additional shares were included as ordinary share equivalents. |

[0000950123-10-052098:notes:268]
Recent Accounting Pronouncements

[0000950123-10-052098:notes:269]
In June 2009, a new accounting standard was issued which amends the consolidation guidance applicable to variable interest entities ("VIEs"), the approach for determining the primary beneficiary of a VIE, and disclosure requirements of a company's involvement with VIEs.  This standard is effective for fiscal years beginning after November 15, 2009 and is required to be adopted by the Company in the first quarter of fiscal year 2011.  The adoption of this standard is not expected to have any impact on the Company's consolidated statement of operations. Upon adoption, sales of accounts receivable in the Global Asset Backed Securitization program will be to a VIE in which the Company is the primary beneficiary.  As a result, the Company will consolidate this VIE and the accounts receivable sold to it will remain on the Company's balance sheet.  Cash received from the program will be accounted for as a borrowing on the Company's balance sheet and as a financing activity in the statement of cash flows.  The North America Asset Backed Securitization program was amended such that sales of accounts receivable from this program will be to a VIE in which a third party financial institution is the primary beneficiary of the VIE and, as a result, the accounts receivable sold to the VIE will continue to be removed from the Company's Consolidated Balance Sheets. Accounts receivable sold and the Company's participation in the VIE will be reported as operating activities in the Consolidated Statements of Cash Flows (see Note 6).

[0000950123-10-052098:notes:270]
In June 2009, a new accounting standard was issued which removes the concept of a qualifying special-purpose entity, creates more stringent conditions for reporting a transfer of a portion of a financial asset as a sale, clarifies other sale-accounting criteria, and changes the initial measurement of a transferor's interest in transferred financial assets.  This guidance is effective for fiscal years beginning after November 15, 2009 and is required to be adopted by the Company in the first quarter of fiscal year 2011.  The adoption of this standard is not expected to have any impact on the Company's consolidated statement of operations.  Upon adoption, accounts receivable sold in the Global Asset Backed Securitization program, as currently structured, will be consolidated by the Company and will remain on its balance sheet ($217.1 million at March 31, 2010, net of the Company's participation interests which are already recorded in other current assets).  Cash received from the program will be treated as a bank borrowing on the Company's balance sheet and as a financing activity in the statement of cash flows.  The Company is currently investigating alternative structures to amend or replace the Global Asset Backed Securitization program such that sales of accounts receivable under the amended program will continue to be removed from the Consolidated Balance Sheet.  The North America Asset Backed Securitization program and the accounts receivable factoring program were amended such that sales of accounts receivable from these programs will continue to be removed from the Consolidated Balance Sheets. Accounts receivable sold will be reported as cash provided by operating activities in the Consolidated Statements of Cash Flows (see Note 6).

[0000950123-10-052098:notes:271]
In December 2007, the FASB issued a new accounting standard related to non-controlling interests of subsidiaries in Consolidated Financial Statements.  The new guidance establishes accounting and reporting standards for ownership interests in subsidiaries held by parties other than the parent, the amount of consolidated net income attributable to the parent and to the non-controlling interest, changes in a parent's ownership interest and the valuation of retained non-controlling equity investments when a subsidiary is deconsolidated. The Statement also establishes reporting requirements that provide sufficient disclosures that clearly identify and distinguish between the interests of the parent and the interests of the non-controlling owners. The standard was effective for fiscal years beginning after December 15, 2008, and was required to be adopted by the Company in the first quarter of fiscal year 2010.  The Company's minority interests, and associated minority owners' interest in the income or losses of the related companies has not been material to its results of operations for fiscal years 2010, 2009 and 2008.  Accordingly, the adoption of the new accounting guidance did not have a material impact on the Company's reported consolidated results of operations, financial condition and cash flows.

[0000950123-10-052098:notes:272]
In September 2006, the FASB issued a new accounting standard related to the accounting of fair value measurements, which defines fair value, establishes a framework for measuring fair value under generally accepted accounting principles, and expands the requisite disclosures for fair value measurements. The FASB provided for a one-year deferral of the new guidance for non-financial assets and liabilities that are recognized or disclosed at fair value in the consolidated financial statements on a non-recurring basis and is required to be applied prospectively, to fiscal years beginning after November 15, 2008. The Company's adoption of the net accounting guidance related to financial assets and liabilities, and other assets and liabilities that are carried at fair value on a recurring basis during fiscal year 2010 did not materially impact the Company's consolidated financial position, results of operations and cash flows.

[0000950123-10-052098:notes:273]
In December 2007, the FASB issued a new accounting standard related to assets acquired and liabilities assumed in business combinations. The new accounting guidance established principles and requirements for how an acquirer recognizes and measures in its financial statements the identifiable assets acquired, the liabilities assumed, any non-controlling interest in the acquiree and the goodwill acquired. The guidance also established disclosure requirements which are intended to enable users to evaluate the nature and financial effects of the business combination. This standard was effective for fiscal years that begin after December 15, 2008, and was required to be applied prospectively for all business combinations entered into after the date of adoption, which was April 1, 2009 for the Company. The Company's adoption of the new accounting guidance did not have a material impact on its reported consolidated results of operations, financial condition and cash flows.  Application of this standard to future acquisitions will result in the recognition of certain expenditures including transaction costs and costs related to exit activities to be treated as period expenses rather than as a component of the purchase price consideration. In addition, contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recognized in earnings.  Also included in the new accounting guidance was an amendment to the accounting for post acquisition adjustments to valuation allowances for acquired deferred tax assets and income tax positions to be recognized as an adjustment to the provision for, or benefit from, income taxes.  These requirements did not have a material impact on our fiscal 2010 results of operations.

[0000950123-10-052098:notes:274]
In May 2008, the FASB issued a new accounting standard related to accounting for convertible debt instruments which requires that issuers of convertible debt instruments that may be settled in cash upon conversion separately account for the liability and equity components in a manner that will reflect the entity's nonconvertible debt borrowing rate when the interest cost is recognized in subsequent periods.  The standard was effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2008 and was required to be adopted by the Company beginning April 1, 2009.  The standard required the Company to record the change in accounting principle retrospectively to all periods presented.

[0000950123-10-052098:notes:275]
The adoption of the new standard affected the accounting for the Company's 1% Convertible Subordinated Notes and Zero Coupon Convertible Junior Subordinated Notes (collectively referred to as the "Convertible Notes") by requiring the initial proceeds from their sale to be allocated between a liability component and an equity component in a manner that results in interest expense on the debt component at the Company's nonconvertible debt borrowing rate on the date of issuance.

[0000950123-10-052098:notes:276]
The standard required the Company to record the change in accounting principle retrospectively to all periods presented, which included cumulative effect adjustments as of March 31, 2009 to the opening balance of Accumulated deficit of approximately $225.0 million, an approximate $27.6 million reduction in the carrying value of the Convertible Notes, an increase in the recorded value of Ordinary shares of approximately $252.0 million, which represents the carrying amount of the equity component, and a reduction to deferred financing costs of approximately $525,000, which is included in Other assets.  The adjustment to Accumulated deficit represented imputed interest for the period from issuance of each convertible note to March 31, 2009, and a $5.8 million reduction in the gain recognized in the third quarter of fiscal year 2009, for the partial extinguishment of the 1% Convertible Subordinated Notes.  Coupon interest expense and discount amortization related to the original issuance costs were immaterial for all periods presented.

[0000950123-10-052098:notes:277]
The estimated fair value of the initial debt components of the Company's 1% Convertible Subordinated Notes and Zero Coupon Convertible Junior Subordinated Notes were $310.9 million and $111.3 million, respectively, based on the present value of the contractual cash flows discounted at an appropriate comparable market nonconvertible debt borrowing rate at the date of issuance.  The Company is amortizing the discounts using the effective interest method over the period the debt is expected to remain outstanding as additional interest expense.  The amortization of the discount resulted in effective interest rates of 8.21% for the 1% Convertible Subordinated Notes and 9.23% for the Zero Coupon Convertible Junior Subordinated Notes.  The adoption of the new standard had no impact on the Company's consolidated cash flows. Below is a summary of the financial statement effects of implementing the new standard:

[0000950123-10-052098:notes:278]
|  | 1% Convertible Subordinated Notes |  |  | Zero Coupon Convertible Junior Subordinated Notes |
| Balance Sheet: | March 31, 2010 |  | March 31, 2009 |  |  | March 31, 2010 |  | March 31, 2009 |
|  | (In thousands) |
| Previous carrying value - principal amount of Notes | $ 239,993 |  | $ 239,993 |  |  | $ - |  | $ 195,000 |
| Unamortized discount | (5,753) |  | (21,602) |  |  | - |  | (5,955) |
| Net carrying amount of Notes | $ 234,240 |  | $ 218,391 |  |  | $ - |  | $ 189,045 |

[0000950123-10-052098:notes:279]
|  | Twelve-Month Periods Ended March 31, |  | Twelve-Month Periods Ended March 31, |
| Income Statement: | 2010 |  | 2009 |  | 2008 |  | 2010 |  | 2009 |  | 2008 |
|  | (In thousands) |
| Amortization of discount net of |  |  |  |  |  |  |  |  |  |  |  |
| adjustments to deferred financing costs... | $ 15,440 |  | $ 27,173 |  | $ 27,258 |  | $ 5,976 |  | $ 16,375 |  | $ 14,755 |
| Gain on repurchase of 1% |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Subordinated Notes | — |  | 5,823 |  | — |  | — |  | — |  | — |
| Total | $ 15,440 |  | $ 32,996 |  | $ 27,258 |  | $ 5,976 |  | $ 16,375 |  | $ 14,755 |

[0000950123-10-052098:notes:280]
As a result of the new standard, basic and diluted net income per share decreased by $0.03 for the twelve-month period ended March 31, 2010. Basic and diluted net income per share decreased by $0.06 for the periods ended March 31, 2009 and 2008, respectively.
