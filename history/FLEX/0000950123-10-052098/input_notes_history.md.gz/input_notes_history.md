# FLEX note change history — 0000950123-09-056887 → 0000950123-10-007677


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2010-02-02):
[0000950123-10-007677:note_history:1]
The accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2009 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and nine-month periods ended December 31, 2009 are not necessarily indicative of the results that may be expected for the fiscal year ended March 31, 2010.  The Company evaluated subsequent events for disclosure through February 2, 2010.
  (was, 2009-11-03, similarity 0.9857):
[0000950123-09-056887:note_history:1]
The accompanying unaudited Condensed Consolidated Financial Statements have been prepared in
   accordance with accounting principles generally accepted in the United States of America (“U.S.
   GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule
   10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes
   required by U.S. GAAP for complete financial statements, and should be read in conjunction with the
   Company’s audited consolidated financial statements as of and for the fiscal year ended March 31,
   2009 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all
   adjustments (consisting only of normal recurring adjustments) considered necessary for a fair
   presentation have been included. Operating results for the three-month and six-month periods ended
   October 2, 2009 are not necessarily indicative of the results that may be expected for the fiscal
   year ended March 31, 2010. The Company evaluated subsequent events for disclosure through November
   2, 2009.

- added (2010-02-02):
[0000950123-10-007677:note_history:2]
During the three-month and nine-month periods ended December 31, 2008, the Company incurred $145.3 million and $262.7 million of charges, respectively, for Nortel and other customers that filed for bankruptcy or restructuring protection or otherwise were experiencing significant financial and liquidity difficulties.  Of these charges, the Company classified approximately $98.0 million and $194.7 million in cost of sales related to the write-down of inventory and associated contractual obligations and $47.3 million and $68.0 million as selling, general and administrative expenses for provisions for doubtful accounts and other claims, respectively.

- added (2010-02-02):
[0000950123-10-007677:note_history:3]
In November 2009, the Company agreed to a settlement with Nortel primarily related to pre-bankruptcy petition claims.  As a result, the Company revised its estimates related to the recovery of Nortel accounts receivable, certain retirement and contractual obligations and other claims.  In addition, the Company has continued to recover amounts related to previously reserved inventory as a result of continuing business with Nortel post bankruptcy. During the three-month period ended December 31, 2009, the Company recorded a net $2.3 million reduction to the original charge, which included a reduction to cost of sales of $26.3 million and an increase to selling, general and administrative expenses of $24.0 million.

- added (2010-02-02):
[0000950123-10-007677:note_history:4]
|  | As of |  | As of |
|  | December 31, 2009 |  | March 31, 2009 |
|  | (In thousands) |
| Raw materials .................................................................................................. | $ 1,762,563 |  | $ 1,907,584 |
| Work-in-progress .......................................................................................... | 474,581 |  | 524,038 |
| Finished goods .............................................................................................. | 544,563 |  | 565,163 |
|  | $ 2,781,707 |  | $ 2,996,785 |

- changed (2010-02-02):
[0000950123-10-007677:note_history:5]
Depreciation expense associated with property and equipment amounted to approximately $95.6 million and $281.5 million for the three-month and nine-month periods ended December 31, 2009, respectively, and $100.8 million and $284.6 million for the three-month and nine-month periods ended December 31, 2008, respectively. Proceeds from the disposition of property and equipment were $35.7 million and $36.7 million during the nine-month periods ended December 31, 2009 and December 31, 2008, respectively, and are presented net with purchases of property and equipment within cash flows from investing activities in the Condensed Consolidated Statements of Cash Flows.
  (was, 2009-11-03, similarity 0.9574):
[0000950123-09-056887:note_history:5]
Depreciation expense associated with property and equipment amounted to approximately $91.5
   million and $186.0 million for the three-month and six-month periods ended October 2, 2009,
       respectively, and $91.8 million and $183.8 million for the three-month and six-month periods ended
       September 26, 2008, respectively. Proceeds from the disposition of property and equipment were
   $15.7 million and $32.7 million during the six-month periods ended October 2, 2009 and September
       26, 2008, respectively, and are presented net with purchases of property and equipment within cash
       flows from investing activities in the Condensed Consolidated Statements of Cash Flows.

- changed (2010-02-02):
[0000950123-10-007677:note_history:6]
The following table summarizes the activity in the Company’s goodwill account during the nine-month period ended December 31, 2009:
  (was, 2009-11-03, similarity 0.952):
[0000950123-09-056887:note_history:6]
The following table summarizes the activity in the Company’s goodwill account during the
       six-month period ended October 2, 2009:

- added (2010-02-02):
[0000950123-10-007677:note_history:7]
|  | Amount |
|  | (In thousands) |
| Balance, beginning of the year.......................................................................................................... | $ 36,776 |
| Acquisition (1) ................................................................................................................................ | 12,482 |
| Purchase accounting adjustments (2) ......................................................................................... | 31,382 |
| Foreign currency translation adjustments .................................................................................. | (818) |
| Balance, end of the quarter ............................................................................................................... | $ 79,822 |

- added (2010-02-02):
[0000950123-10-007677:note_history:8]
__________

- added (2010-02-02):
[0000950123-10-007677:note_history:9]
| (1) | Balance is attributable to an acquisition that was not significant to the Company. Refer to the discussion of the Company’s acquisition in Note 12, “Business and Asset Acquisitions.” |
| (2) | Includes adjustments and reclassifications resulting from management’s review of the valuation of assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition, based on management's estimates. The amount was attributable to purchase accounting adjustments for certain historical acquisitions that were not individually, nor in the aggregate, significant to the Company. |

- added (2010-02-02):
[0000950123-10-007677:note_history:10]
|  | As of December 31, 2009 |  | As of March 31, 2009 |
|  | Gross |  |  |  |  | Net |  | Gross |  |  |  |  | Net |
|  | Carrying |  | Accumulated |  | Carrying |  | Carrying |  | Accumulated |  | Carrying |
|  | Amount |  | Amortization |  | Amount |  | Amount |  | Amortization |  | Amount |
|  | (In thousands) |  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related ...................... | $ | 502,790 |  | $ | (336,090) |  | $ | 166,700 |  | $ | 506,449 |  | $ | (280,046) |  | $ | 226,403 |
| Licenses and other .................... |  | 54,798 |  |  | (33,935) |  |  | 20,863 |  |  | 54,559 |  |  | (26,247) |  |  | 28,312 |
| Total ..................................... | $ | 557,588 |  | $ | (370,025) |  | $ | 187,563 |  | $ | 561,008 |  | $ | (306,293) |  | $ | 254,715 |

- changed (2010-02-02):
[0000950123-10-007677:note_history:11]
Total intangible amortization expense was $21.4 million and $67.5 million during the three-month and nine-month periods ended December 31, 2009, respectively, and $32.6 million and $108.2 million during the three-month and nine-month periods ended December 31, 2008, respectively. The estimated future annual amortization expense for acquired intangible assets is as follows:
  (was, 2009-11-03, similarity 0.9599):
[0000950123-09-056887:note_history:11]
Total intangible amortization expense was $22.7 million and $46.0 million during the
       three-month and six-month periods ended October 2, 2009, respectively, and $50.3 million and $75.6
   million during the three-month and six-month periods ended September 26, 2008, respectively. The
       estimated future annual amortization expense for acquired intangible assets is as follows:

- added (2010-02-02):
[0000950123-10-007677:note_history:12]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2010 (1) .................................................................................................................................................. |  | $ 20,886 |
| 2011 ........................................................................................................................................................ |  | 63,007 |
| 2012......................................................................................................................................................... |  | 41,526 |
| 2013......................................................................................................................................................... |  | 28,103 |
| 2014......................................................................................................................................................... |  | 18,314 |
| Thereafter ............................................................................................................................................... |  | 15,727 |
| Total amortization expense................................................................................................................. |  | $ 187,563 |

- changed (2010-02-02):
[0000950123-10-007677:note_history:13]
| (1) | Represents estimated amortization for the three-month period ending March 31, 2010. |
  (was, 2009-11-03, similarity 0.9425):
[0000950123-09-056887:note_history:13]
| (1) |  | Represents estimated amortization for the six-month period ending March 31, 2010. |

- changed (2010-02-02):
[0000950123-10-007677:note_history:14]
The Company has certain equity investments in, and notes receivable from, non-publicly traded companies, which are included within other assets in the Company’s Condensed Consolidated Balance Sheets. As of December 31, 2009 and March 31, 2009, the Company’s equity investments and notes receivable from these non-publicly traded companies totaled $27.6 million and $473.6 million respectively.  The Company monitors these investments and notes receivable for impairment and makes appropriate reductions in carrying values as required.
  (was, 2009-11-03, similarity 0.9913):
[0000950123-09-056887:note_history:14]
The Company has certain equity investments in, and notes receivable from, non-publicly traded
       companies, which are included within other assets in the Company’s Condensed Consolidated Balance
       Sheets. As of October 2, 2009 and March 31, 2009, the Company’s equity investments and notes
       receivable from these non-publicly traded companies totaled $30.7 million and $473.6 million
       respectively. The Company monitors these investments and notes receivable for impairment and makes
       appropriate reductions in carrying values as required.

- added (2010-02-02):
[0000950123-10-007677:note_history:15]
In August 2009, the Company sold one of its non-majority owned investments and related note receivable for approximately $252.5 million, net of closing costs.  In conjunction with this transaction the Company recognized an impairment charge of approximately $107.4 million during the first quarter of fiscal 2010.  During the second quarter of fiscal 2010, the Company recognized charges totaling approximately $92.0 million associated with the impairment of notes receivable from one affiliate and an equity investment in another affiliate.  Deterioration in the business prospects, cash flow expectations, and increased liquidity concerns of the affiliate and the equity investment resulted in the impairment of the carrying value to the estimated recoverable value.  Total impairment charges related to the Company’s equity investments and notes receivable for the nine-month period ended December 31, 2009 were approximately $199.4 million and are included in Other charges, net in the Condensed Consolidated Statements of Operations.

- changed (2010-02-02):
[0000950123-10-007677:note_history:16]
The Company has tax loss carryforwards attributable to continuing operations for which the Company has recognized deferred tax assets.  The Company’s policy is to provide a reserve against those deferred tax assets that in management’s estimate are not more likely than not to be realized.  During the three-month and nine-month periods ended December 31, 2009, the provision for income taxes includes a benefit of approximately $11.3 million and $86.5 million, respectively, for the net change in the liability for unrecognized tax benefits and settlements in various tax jurisdictions. During the nine-month period ended December 31, 2008, the provision for income taxes includes a benefit of approximately $57.9 million for the reversal of valuation allowances and other tax reserves.
  (was, 2009-11-03, similarity 0.9707):
[0000950123-09-056887:note_history:16]
The Company has tax loss carryforwards attributable to continuing operations for which the
       Company has recognized deferred tax assets. The Company’s policy is to provide a reserve against
       those deferred tax assets that in management’s estimate are not more likely than not to be
       realized. During the three-month and six-month periods ended October 2, 2009, the provision for
       income taxes includes a benefit of approximately $63.3 million and $75.2 million, respectively, for
       the net change in the liability for unrecognized tax benefits as a result of settlements in various
       tax jurisdictions. During the six-month period ended September 26, 2008, the provision for income
       taxes includes a benefit of approximately $38.5 million for the reversal of valuation allowances
       and other tax reserves.

- changed (2010-02-02):
[0000950123-10-007677:note_history:17]
In June 2009, a new accounting standard was issued which removes the concept of a qualifying special-purpose entity, creates more stringent conditions for reporting a transfer of a portion of a financial asset as a sale, clarifies other sale-accounting criteria, and changes the initial measurement of a transferor’s interest in transferred financial assets.  This guidance is effective for fiscal years beginning after November 15, 2009 and is required to be adopted by the Company in the first quarter of fiscal year 2011.  The adoption of this standard is not expected to have any impact on the Company’s consolidated statement of operations and the Company is continuing to evaluate whether it will require that future sales of accounts receivable be treated as a financing activity in the statement of cash flows and as a liability on the Company’s balance sheet (see Note 8).
  (was, 2009-11-03, similarity 0.9498):
[0000950123-09-056887:note_history:17]
In June 2009, a new accounting standard was issued which removes the concept of a qualifying
       special-purpose entity, creates more stringent conditions for reporting a transfer of a portion of
       a financial asset as a sale, clarifies other sale-accounting criteria, and changes the initial
       measurement of a transferor’s interest in transferred financial assets. This guidance is effective
       for fiscal years beginning after November 15, 2009 and is required to be adopted by the Company in
       the first quarter of fiscal year 2011. The adoption of this standard will not have any impact on
       the Company’s consolidated statement of operations and could require that future sales of accounts
       receivable be treated as a financing activity in the statement of cash flows and as a liability on
       the Company’s balance sheet (see Note 8).

- changed (2010-02-02):
[0000950123-10-007677:note_history:18]
In June 2009, a new accounting standard was issued which amends the consolidation guidance applicable to variable interest entities (“VIEs”), the approach for determining the primary beneficiary of a VIE, and disclosure requirements of a company’s involvement with VIEs.  This standard is effective for fiscal years beginning after November 15, 2009 and is required to be adopted by the Company in the first quarter of fiscal year 2011.  The adoption of this standard is not expected to have any impact on the Company’s consolidated statement of operations and the Company is continuing to evaluate whether it will require that future sales of accounts receivable be treated as a financing activity in the statement of cash flows and as a liability on the Company’s balance sheet (see Note 8).
  (was, 2009-11-03, similarity 0.9439):
[0000950123-09-056887:note_history:18]
In June 2009, a new accounting standard was issued which amends the consolidation guidance
       applicable to variable interest entities (“VIEs”), the approach for determining the primary
       beneficiary of a VIE, and disclosure requirements of a Company’s involvement with VIEs. This
       standard is effective for fiscal years beginning after November 15, 2009 and is required to be
       adopted by the Company in the first quarter of fiscal year 2011. The adoption of this standard
       will not have any impact on the Company’s consolidated statement of operations and could require
       that future sales of accounts receivable be treated as a financing activity in the statement of
       cash flows and as a liability on the Company’s balance sheet (see Note 8).

- removed (2010-02-02):
[0000950123-09-056887:note_history:19]
During the three-month and six-month periods ended September 26, 2008, the Company recognized
       approximately $117.4 million of charges associated with certain customers that were filing for
       bankruptcy or were experiencing significant financial and liquidity difficulties. The Company
       classified approximately $96.7 million of these charges in cost of sales related to the write-down
       of inventory and associated contractual obligations. Additionally, the Company recognized
       approximately $20.7 million as selling, general and administrative expenses for provisions for
       doubtful accounts.

- removed (2010-02-02):
[0000950123-09-056887:note_history:20]
|  |  | As of |  |  | As of |  |
|  |  | October 2, 2009 |  |  | March 31, 2009 |  |
|  |  | (In thousands) |  |
| Raw materials |  | $ | 1,649,106 |  |  | $ | 1,907,584 |  |
| Work-in-progress |  |  | 570,846 |  |  |  | 524,038 |  |
| Finished goods |  |  | 472,125 |  |  |  | 565,163 |  |
|  |  | $ | 2,692,077 |  |  | $ | 2,996,785 |  |

- removed (2010-02-02):
[0000950123-09-056887:note_history:21]
|  |  | Amount |  |
|  |  | (In thousands) |  |
| Balance, beginning of the year |  | $ | 36,776 |  |
| Purchase accounting adjustments (1) |  |  | 31,382 |  |
| Balance, end of the quarter |  | $ | 68,158 |  |

- removed (2010-02-02):
[0000950123-09-056887:note_history:22]
| (1) |  | Includes adjustments and reclassifications resulting from management’s review of the valuation of tangible and identifiable intangible assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition, based on management’s estimates. The amount was attributable to purchase accounting adjustments for certain historical acquisitions that were not individually, nor in the aggregate, significant to the Company. |

- removed (2010-02-02):
[0000950123-09-056887:note_history:23]
|  |  | As of October 2, 2009 |  |  | As of March 31, 2009 |  |
|  |  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  |  | Amount |  |  | Amortization |  |  | Amount |  |  | Amount |  |  | Amortization |  |  | Amount |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related |  | $ | 506,861 |  |  | $ | (320,143 | ) |  | $ | 186,718 |  |  | $ | 506,449 |  |  | $ | (280,046 | ) |  | $ | 226,403 |  |
| Licenses and other |  |  | 54,799 |  |  |  | (32,240 | ) |  |  | 22,559 |  |  |  | 54,559 |  |  |  | (26,247 | ) |  |  | 28,312 |  |
| Total |  | $ | 561,660 |  |  | $ | (352,383 | ) |  | $ | 209,277 |  |  | $ | 561,008 |  |  | $ | (306,293 | ) |  | $ | 254,715 |  |

- removed (2010-02-02):
[0000950123-09-056887:note_history:24]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2010 (1) |  | $ | 42,600 |  |
| 2011 |  |  | 63,007 |  |
| 2012 |  |  | 41,526 |  |
| 2013 |  |  | 28,103 |  |
| 2014 |  |  | 18,314 |  |
| Thereafter |  |  | 15,727 |  |
| Total amortization expense |  | $ | 209,277 |  |

- removed (2010-02-02):
[0000950123-09-056887:note_history:25]
During the second quarter of fiscal 2010, the Company recognized charges totaling
       approximately $92.0 million associated with the impairment of notes receivable from one affiliate
       and an equity investment in another affiliate, which are included in Other charges, net in the
       Condensed Consolidated Statements of Operations. The notes receivable were partially impaired
       during the fourth quarter of fiscal year 2009 based on discussions with a third party for the
       potential sale of the notes and the related expected recoverable value. Subsequent deterioration
       in the affiliate’s business prospects, cash flow expectations, and increased liquidity concerns has
       resulted in an additional impairment. Similarly, deterioration in the business prospects and
       liquidity concerns of the equity investment occurring in the six-month period ended October 2, 2009
   has resulted in an impairment of the carrying value to the estimated recoverable value.

- removed (2010-02-02):
[0000950123-09-056887:note_history:26]
In August 2009, the Company sold one of its non-majority owned investments and related note
       receivable for approximately $252.5 million, net of closing costs. In conjunction with this
       transaction the Company recognized an impairment charge of approximately $107.4 million in the
       three-month period ended July 3, 2009. Total impairment charges related to the Company’s equity
       investments and notes receivable for the six-month period ended October 2, 2009 were approximately
   $199.4 million and are included in Other charges, net in the Condensed Consolidated Statements of
       Operations.

- removed (2010-02-02):
[0000950123-09-056887:note_history:27]
During the three-month and six-month periods ended September 26, 2008, the Company recognized
   $11.9 million in charges for other-than-temporary impairment of certain of the Company’s
       investments primarily associated with a customer that was experiencing significant financial and
       liquidity difficulties.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2010-02-02):
[0000950123-10-007677:note_history:28]
|  | As of |  | As of |
|  | December 31, 2009 |  | March 31, 2009 |
|  | (In thousands) |
| 0.00% convertible junior subordinated notes due July 2009 | $ - |  | $ 189,045 |
| 1.00% convertible subordinated notes due August 2010 | 230,147 |  | 218,391 |
| 6.50% senior subordinated notes due May 2013 | 299,806 |  | 399,622 |
| 6.25% senior subordinated notes due November 2014 | 302,172 |  | 402,090 |
| Term Loan Agreement, including current portion, due in installments |  |  |  |
| through October 2014 | 1,696,110 |  | 1,709,116 |
| Other | 20,066 |  | 23,270 |
|  | 2,548,301 |  | 2,941,534 |
| Current portion | (255,273) |  | (207,991) |
| Non-current portion | $ 2,293,028 |  | $ 2,733,543 |
  (was, 2009-11-03, similarity 0.682):
[0000950123-09-056887:note_history:28]
|  |  | As of |  |  | As of |  |
|  |  | October 2, 2009 |  |  | March 31, 2009 |  |
|  |  | (In thousands) |  |
| Short term bank borrowings |  | $ | 1,719 |  |  | $ | 1,854 |  |
| 0.00% convertible junior subordinated notes due July 2009 |  |  | — |  |  |  | 189,045 |  |
| 1.00% convertible subordinated notes due August 2010 |  |  | 226,156 |  |  |  | 218,391 |  |
| 6.50% senior subordinated notes due May 2013 |  |  | 299,806 |  |  |  | 399,622 |  |
| 6.25% senior subordinated notes due November 2014 |  |  | 302,172 |  |  |  | 402,090 |  |
| Term Loan Agreement, including current portion, due in installments through October 2014 |  |  | 1,700,445 |  |  |  | 1,709,116 |  |
| Other |  |  | 20,028 |  |  |  | 21,416 |  |
|  |  |  | 2,550,326 |  |  |  | 2,941,534 |  |
| Current portion |  |  | (252,591 | ) |  |  | (207,991 | ) |
| Non-current portion |  | $ | 2,297,735 |  |  | $ | 2,733,543 |  |

- changed (2010-02-02):
[0000950123-10-007677:note_history:29]
As of December 31, 2009 and March 31, 2009, there were no borrowings outstanding under the Company’s $2.0 billion credit facility, and the Company was in compliance with the financial covenants under this credit facility.
  (was, 2009-11-03, similarity 0.9783):
[0000950123-09-056887:note_history:29]
As of October 2, 2009 and March 31, 2009, there were no borrowings outstanding under the
   Company’s $2.0 billion credit facility, and the Company was in compliance with the financial
   covenants under this credit facility.

- changed (2010-02-02):
[0000950123-10-007677:note_history:30]
On July 31, 2009, the Company paid $195.0 million to redeem the Zero Coupon Convertible Junior Subordinated Notes upon their maturity. These notes carried conversion provisions to issue shares to settle any conversion spread (excess of the conversion value over the conversion price) in stock.  The conversion price was $10.50 per share.  On the maturity date, the Company’s stock price was less than the conversion price, and therefore no shares were issued.
  (was, 2009-11-03, similarity 0.9171):
[0000950123-09-056887:note_history:30]
On
   July 31, 2009, the Company paid $195.0 million to redeem
   the Zero Coupon Convertible Junior
   Subordinated Notes upon their maturity. These notes carried conversion provisions to issue shares
   to settle any conversion spread (excess of the conversion value over the face value) in stock. The face value was $10.50 per share. On the
   maturity date, the Company’s stock price was less than the face
   value, and
   therefore no shares were issued.

- changed (2010-02-02):
[0000950123-10-007677:note_history:31]
During June 2009, the Company paid approximately $203.2 million to purchase an aggregate principal amount of $99.8 million of its outstanding 6.5% Senior Subordinated Notes due 2013 and an aggregate principal amount of $99.9 million of its outstanding 6.25% Senior Subordinated Notes due 2014 collectively referred to as the “Notes” in a cash tender offer (the “Offer”).  The cash paid included $8.8 million in consent fees (as discussed further below) paid to holders of the Notes that were tendered but not purchased as well as to holders that consented but did not tender, which were capitalized and are being recognized as a component of interest expense over the remaining life of the Notes.  The Company recognized an immaterial gain during the nine-month period ended December 31, 2009 associated with the partial extinguishment of the Notes, net of approximately $5.3 million for transaction costs and the write-down of related debt issuance costs, which is included in Other charges, net in the Condensed Consolidated Statement of Operations.
  (was, 2009-11-03, similarity 0.9615):
[0000950123-09-056887:note_history:31]
During June 2009, the Company paid approximately $203.2 million to purchase an aggregate
   principal amount of $99.8 million of its outstanding 6 1/2% Senior Subordinated Notes due 2013 (the
   “6 1/2% Notes”) and an aggregate
   principal amount of $99.9 million of its outstanding 6 1/4% Senior Subordinated Notes due 2014
   (the “6 1/4% Notes” and collectively referred to as the “Notes”) in a cash tender offer (the
   “Offer”). The cash paid included $8.8 million in consent fees (as discussed further below) paid to
   holders of the Notes that were tendered but not purchased as well as to holders that consented but
   did not tender, which were capitalized and will be recognized as a component of interest expense
   over the remaining life of the Notes. The Company recognized an immaterial gain during the
   six-month period ended October 2, 2009 associated with the partial extinguishment of the Notes, net
   of approximately $5.3 million for transaction costs and the write-down of related debt issuance
   costs, which is included in Other charges, net in the Condensed Consolidated Statement of
   Operations.

- changed (2010-02-02):
[0000950123-10-007677:note_history:32]
In conjunction with the Offer, the Company obtained consents to certain amendments to the restricted payments covenants and certain related definitions in each of the indentures (the “Indentures”) under which the Notes were issued.  The amendments permit the Company greater flexibility to purchase or make other payments in respect of its equity securities and debt that is subordinated to the Notes and to make certain other restricted payments under each Indenture.
  (was, 2009-11-03, similarity 0.8921):
[0000950123-09-056887:note_history:32]
In conjunction with the Offer, the Company obtained consents from the holders of Notes
       tendered but not purchased, as well as from holders that consented but did not tender, to certain
       amendments to the restricted payments covenants and certain related definitions in each of the
       indentures (the “Indentures”) under which the Notes were issued. The amendments permit the Company
       greater flexibility to purchase or make other payments in respect of its equity securities and debt
       that is subordinated to the Notes and to make certain other restricted payments under each
       Indenture.

- changed (2010-02-02):
[0000950123-10-007677:note_history:33]
The standard required the Company to record the change in accounting principle retrospectively to all periods presented, which included cumulative effect adjustments as of March 31, 2009 to the opening balance of Accumulated deficit of approximately $225.0 million, an approximate $27.6 million reduction in the carrying value of the Convertible Notes, an increase in the recorded value of Ordinary shares of approximately $252.0 million, which represents the carrying amount of the equity component, and a reduction to deferred financing costs of approximately $525,000, which is included in Other assets.  The adjustment to Accumulated deficit represented imputed interest for the period from issuance of each convertible note to March 31, 2009, and a $5.8 million reduction in the gain recognized during the three-month and nine-month periods ended December 31, 2008 for the partial extinguishment of the 1% Convertible Subordinated Notes.  Coupon interest expense and discount amortization related to the original issuance costs were immaterial for all periods presented.
  (was, 2009-11-03, similarity 0.984):
[0000950123-09-056887:note_history:33]
The standard required the Company to record the change in accounting principle retrospectively
       to all periods presented, which included cumulative effect adjustments as of March 31, 2009 to the
       opening balance of Accumulated deficit of approximately $225.0 million, an approximate $27.6
   million reduction in the carrying value of the Convertible Notes, an increase in the recorded value
       of Ordinary shares of approximately $252.0 million, which represents the carrying amount of the
       equity component, and a reduction to deferred financing costs of approximately $525,000, which is
       included in Other assets. The adjustment to Accumulated deficit represented imputed interest for
       the period from issuance of each convertible note to March 31, 2009, and a $5.8 million reduction
       in the gain recognized during the three-month period ended December 31, 2008 for the partial
       extinguishment of the 1% Convertible Subordinated Notes. Coupon interest expense and discount
       amortization related to the original issuance costs was immaterial for all periods presented.

- changed (2010-02-02):
[0000950123-10-007677:note_history:34]
The estimated fair value of the initial debt components of the Company’s 1% Convertible Subordinated Notes and Zero Coupon Convertible Junior Subordinated Notes were $310.9 million and $111.3 million, respectively, based on the present value of the contractual cash flows discounted at an appropriate comparable market nonconvertible debt borrowing rate at the date of issuance.  The Company is amortizing the discounts using the effective interest method over the period the debt is expected to remain outstanding as additional interest expense.  The amortization of the discount resulted in effective interest rates of 8.21% for the 1% Convertible Subordinated Notes and 9.23% for the Zero Coupon Convertible Junior Subordinated Notes.  The adoption of the new standard had no impact on the Company’s consolidated cash flows. Below is a summary of the financial statement effects of implementing the new standard:
  (was, 2009-11-03, similarity 0.9755):
[0000950123-09-056887:note_history:34]
The estimated fair value of the initial debt components of the Company’s 1% Convertible
       Subordinated Notes and Zero Coupon Convertible Junior Subordinated Notes were $310.9 million and
   $111.3 million, respectively, based on the present value of the contractual cash flows discounted
       at an appropriate comparable market nonconvertible debt borrowing rate at the date of issuance.
   The Company is amortizing the discounts using the effective interest method over the period the
       debt is expected to remain outstanding as additional interest expense. The amortization of the
       discount resulted in effective interest rates of 8.21% for the 1% Convertible Subordinated Notes
       and 9.23% for the Zero Coupon Convertible Junior Subordinated Notes. The adoption of the new
       standard had no impact on the Company’s consolidated cash flows. Below is a summary of the
       financial statement effects of implementing the new standard on the affected notes and interest
       expense.

- added (2010-02-02):
[0000950123-10-007677:note_history:35]
|  | 1% Convertible Subordinated Notes |  | Zero Coupon Convertible Junior Subordinated Notes |
| Balance Sheet: | December 31, 2009 |  | March 31, 2009 |  | December 31, 2009 |  | March 31, 2009 |
|  | (In thousands) |
| Principal amount of Notes......................................... | $ 239,993 |  | $ 239,993 |  | $ - |  | $ 195,000 |
| Unamortized discount................................................. | (9,846) |  | (21,602) |  | - |  | (5,955) |
| Net carrying amount of Notes.................................... | $ 230,147 |  | $ 218,391 |  | $ - |  | $ 189,045 |
| Income Statement: | Three-Month Periods Ended December 31, |  | Three-Month Periods Ended December 31, |
|  | 2009 |  | 2008 |  | 2009 |  | 2008 |
|  | (In thousands) |
| Amortization of discount net of |  |  |  |  |  |  |  |
| adjustments to deferred financing costs....................... | $ 3,889 |  | $ 7,465 |  | $ - |  | $ 4,127 |
| Gain on repurchase of 1% |  |  |  |  |  |  |  |
| Convertible Subordinated Notes.................................. | - |  | 5,823 |  | - |  | - |
| Total.......................................................................... | $ 3,889 |  | $ 13,288 |  | $ - |  | $ 4,127 |
|  | Nine-Month Periods Ended December 31, |  | Nine-Month Periods Ended December 31, |
|  | 2009 |  | 2008 |  | 2009 |  | 2008 |
|  | (In thousands) |
| Amortization of discount net of |  |  |  |  |  |  |  |
| adjustments to deferred financing costs....................... | $ 11,450 |  | $ 21,965 |  | $ 5,976 |  | $ 12,131 |
| Gain on repurchase of 1% |  |  |  |  |  |  |  |
| Convertible Subordinated Notes.................................. | - |  | 5,823 |  | - |  | - |
| Total.......................................................................... | $ 11,450 |  | $ 27,788 |  | $ 5,976 |  | $ 12,131 |

- changed (2010-02-02):
[0000950123-10-007677:note_history:36]
The new standard did not change basic and diluted net income per share for the three-month period ended December 31, 2009, however, for the nine-month period basic and diluted net income per share decreased by $0.02 per share.  For the three-month and nine-month periods ended December 31, 2008, basic and diluted net income per share decreased by $0.02 and $0.05, respectively.
  (was, 2009-11-03, similarity 0.6407):
[0000950123-09-056887:note_history:36]
As a result of the new standard, basic and diluted net income per share decreased by
   $0.01 for the three-month period and increased the net loss per share by $0.02 for the six-month
       period ended October 2, 2009. Basic and diluted net income per share decreased by $0.01 and $0.03
   for the three-month and six-month periods ended September 26, 2008, respectively.

- changed (2010-02-02):
[0000950123-10-007677:note_history:37]
As of December 31, 2009, the approximate fair values of the Company’s 6.5% Senior Subordinated Notes, 6.25% Senior Subordinated Notes, 1% Convertible Subordinated Notes and debt outstanding under its Term Loan Agreement were 100.125%, 98.375%, 98.5875% and 93.4% of the face values of the debt obligations, respectively, based on broker trading prices.
  (was, 2009-11-03, similarity 0.986):
[0000950123-09-056887:note_history:37]
As of October 2, 2009, the approximate fair values of the Company’s 6.5% Senior Subordinated
       Notes, 6.25% Senior Subordinated Notes, 1% Convertible Subordinated Notes and debt outstanding
       under its Term Loan Agreement were 97.0%, 96.0%, 97.1% and 91.3% of the face values of the debt
       obligations, respectively, based on broker trading prices.

- added (2010-02-02):
[0000950123-10-007677:note_history:38]
During the three-month and nine-month periods ended December 31, 2009, the Company recognized interest expense of $36.7 million and $122.2 million (including $3.9 million and $17.4 million for the retrospective application of the new accounting standard discussed above), respectively, on its debt obligations outstanding during the period.  During the three-month and nine-month periods ended December 31, 2008, the Company recognized interest expense of $63.5 million and $197.6 million (including $11.6 million and $34.1 million for the retrospective application of the new accounting standard), respectively, on its debt obligations.

- removed (2010-02-02):
[0000950123-09-056887:note_history:39]
|  |  |  |  |  |  |  |  |  |  | Zero Coupon Convertible Junior |  |
|  |  | 1% Convertible Subordinated Notes |  |  | Subordinated Notes |  |
|  |  | October 2, 2009 |  |  | March 31, 2009 |  |  | October 2, 2009 |  |  | March 31, 2009 |  |
|  |  | (In thousands) |  |
| Balance Sheet: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Principal amount of Notes |  | $ | 239,993 |  |  | $ | 239,993 |  |  | $ | — |  |  | $ | 195,000 |  |
| Unamortized discount |  |  | (13,837 | ) |  |  | (21,602 | ) |  |  | — |  |  |  | (5,955 | ) |
| Net carrying amount of Notes |  | $ | 226,156 |  |  | $ | 218,391 |  |  | $ | — |  |  | $ | 189,045 |  |

- removed (2010-02-02):
[0000950123-09-056887:note_history:40]
|  |  | Three-Month Periods Ended |  |  | Three-Month Periods Ended |  |
|  |  | October 2, 2009 |  |  | September 26, 2008 |  |  | October 2, 2009 |  |  | September 26, 2008 |  |
|  |  | (In thousands) |  |
| Income Statement: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of discount net of adjustments to deferred financing costs |  | $ | 3,829 |  |  | $ | 7,343 |  |  | $ | 1,659 |  |  | $ | 4,058 |  |

- removed (2010-02-02):
[0000950123-09-056887:note_history:41]
|  |  | Six-Month Periods Ended |  |  | Six-Month Periods Ended |  |
|  |  | October 2, 2009 |  |  | September 26, 2008 |  |  | October 2, 2009 |  |  | September 26, 2008 |  |
|  |  | (In thousands) |  |
| Amortization of discount net of adjustments to deferred financing costs |  | $ | 7,561 |  |  | $ | 14,500 |  |  | $ | 5,976 |  |  | $ | 8,004 |  |

- removed (2010-02-02):
[0000950123-09-056887:note_history:42]
During the three-month and six-month periods ended October 2, 2009, the Company recognized
       interest expense of $39.3 million and $85.5 million (including $5.5 million and $13.5 million for
       the application of the new accounting standard discussed above, respectively, on its debt
       obligations outstanding during the period. During the three-month and six-month periods ended
       September 26, 2008, the Company recognized interest expense of $64.8 million and $134.1 million
   (including $11.4 million and $22.5 million for the retrospective application of the new accounting
       standard), respectively, on its debt obligations.
