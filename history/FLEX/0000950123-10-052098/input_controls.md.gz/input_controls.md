# FLEX 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: no heading matched.


## item_9a
