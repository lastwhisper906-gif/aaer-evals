# FLEX 8-K — 0000950123-10-038853 filed 2010-04-27

## item codes, every 8-K on or before 2010-05-24

- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2010-05-24

- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0000950123-10-038853:8k_2_02:1]
EX-99.1
2
c99731exv99w1.htm
EXHIBIT 99.1

[0000950123-10-038853:8k_2_02:2]
Exhibit 99.1

[0000950123-10-038853:8k_2_02:3]
Exhibit 99.1

[0000950123-10-038853:8k_2_02:4]
Kevin Kessel

[0000950123-10-038853:8k_2_02:5]
Vice President, Investor Relations

[0000950123-10-038853:8k_2_02:6]
+1.408.576.7985

[0000950123-10-038853:8k_2_02:7]
kevin.kessel@flextronics.com

[0000950123-10-038853:8k_2_02:8]
Renee Brotherton

[0000950123-10-038853:8k_2_02:9]
Vice President, Corporate Communications

[0000950123-10-038853:8k_2_02:10]
+1.408.576.7189

[0000950123-10-038853:8k_2_02:11]
renee.brotherton@flextronics.com

[0000950123-10-038853:8k_2_02:12]
FLEXTRONICS ANNOUNCES SEASONALLY STRONG FOURTH QUARTER RESULTS

[0000950123-10-038853:8k_2_02:13]
Singapore, April 27, 2010 — Flextronics (NASDAQ: FLEX) today announced results for its fourth
quarter ended March 31, 2010.

[0000950123-10-038853:8k_2_02:14]
|  |  | Three Month Periods Ended |  |
|  |  | March 31, |  |  | December 31, |  |
| (US$ in millions, except EPS) |  | 2010 |  |  | 2009 |  |
| Net sales |  | $ | 5,940 |  |  | $ | 6,556 |  |
| GAAP operating income |  | $ | 135 |  |  | $ | 167 |  |
| Adjusted operating income (1) |  | $ | 170 |  |  | $ | 189 |  |
| GAAP net income |  | $ | 60 |  |  | $ | 93 |  |
| Adjusted net income (1) |  | $ | 130 |  |  | $ | 138 |  |
| GAAP EPS |  | $ | 0.07 |  |  | $ | 0.11 |  |
| Adjusted EPS (1) |  | $ | 0.16 |  |  | $ | 0.17 |  |

[0000950123-10-038853:8k_2_02:15]
| (1) |  | A reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release. |

[0000950123-10-038853:8k_2_02:16]
Fourth Quarter Results

[0000950123-10-038853:8k_2_02:17]
Net sales for the fourth quarter ended March 31, 2010 were $5.9 billion, compared to net sales
for the third quarter ended December 31, 2009 of $6.6 billion. Adjusted operating income for the
fourth quarter ended March 31, 2010 was $170 million with an adjusted operating margin of 2.9%,
compared to adjusted operating income of $189 million and an adjusted operating margin of 2.9% in
the prior quarter. Adjusted net income for the fourth quarter ended March 31, 2010 was $130
million and adjusted EPS was $0.16 compared to $138 million and $0.17, respectively, for the
prior quarter.

[0000950123-10-038853:8k_2_02:18]
“We experienced less March quarter seasonality this year than we have historically, despite more
component shortages than anticipated. More importantly, we remain very confident in our
positioning entering fiscal 2011, with a strong Q1 start as all our market segments are
forecasted to show sequential growth,” said Mike McNamara, CEO of Flextronics.

[0000950123-10-038853:8k_2_02:19]
Paul Read, CFO of Flextronics added, “This marks the 7th consecutive quarter of
positive cash flow generation. For the fiscal year, Flextronics generated $800 million in cash
flow from operations which includes the absorption of $190 million in cash restructuring charges.
This solid cash flow generation is supported by our industry leading 11 day cash conversion cycle
and provides flexibility for the company to continue to invest in its business. Flextronics’
asset management coupled with our improving margins has driven a strong adjusted ROIC of 28.8%.”

[0000950123-10-038853:8k_2_02:20]
Cash and cash equivalents were approximately $1.9 billion down $314 million versus the prior
quarter principally reflecting the redemption of the $300 million 6.5% Senior Subordinated Notes.
As a result, total debt declined $294 million to $2.26 billion at quarter end and has been
reduced by approximately $700 million since March 2009. Net debt, which is total debt less total
cash, ended the quarter at $329 million and has decreased by approximately $800 million from one
year ago.

[0000950123-10-038853:8k_2_02:21]
Guidance

[0000950123-10-038853:8k_2_02:22]
For the first quarter ending July 2, 2010, revenue is expected to be in the range of $6.1 billion
to $6.6 billion and adjusted EPS is expected to be in the range of $0.16 to $0.19 per share.

[0000950123-10-038853:8k_2_02:23]
GAAP earnings per share are expected to be lower than the guidance provided herein by
approximately $0.04 per diluted share for quarterly intangible amortization, stock-based
compensation expense and non-cash interest expense.

[0000950123-10-038853:8k_2_02:24]
Conference Calls and Web Casts

[0000950123-10-038853:8k_2_02:25]
A conference call hosted by Flextronics’s management will be held today at 5:00 p.m. EST / 2:00
p.m. PST to discuss the Company’s financial results for the fourth quarter ended March 31, 2010.

[0000950123-10-038853:8k_2_02:26]
The conference call will be broadcast via the Internet and may be accessed by logging on to the
Company’s website at www.flextronics.com. Additional information in the form of a slide
presentation may also be found on the Company’s site. A replay of the broadcast will remain
available on the Company’s website afterwards.

[0000950123-10-038853:8k_2_02:27]
Minimum requirements to listen to the broadcast are Microsoft Windows Media Player software (free
download at http://www.microsoft.com/windows/windowsmedia/download/default.asp) and at least a
28.8 Kbps bandwidth connection to the Internet.

[0000950123-10-038853:8k_2_02:28]
About Flextronics

[0000950123-10-038853:8k_2_02:29]
Headquartered in Singapore (Singapore Reg. No. 199002645H), Flextronics is a leading Electronics
Manufacturing Services (EMS) provider focused on delivering complete design, engineering and
manufacturing services to automotive, computing, consumer, industrial, infrastructure, medical
and mobile OEMs. Flextronics helps customers design, build, ship, and service electronics
products through a network of facilities in 31 countries on four continents. This global presence
provides design and engineering solutions that are combined with core electronics manufacturing
and logistics services, and vertically integrated with components technologies, to optimize
customer operations by lowering costs and reducing time to market. For more information, please
visit www.flextronics.com.

[0000950123-10-038853:8k_2_02:30]
# # #

[0000950123-10-038853:8k_2_02:31]
SCHEDULE I

[0000950123-10-038853:8k_2_02:32]
FLEXTRONICS INTERNATIONAL LTD. AND SUBSIDIARIES

[0000950123-10-038853:8k_2_02:33]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950123-10-038853:8k_2_02:34]
(In thousands, except per share amounts)

[0000950123-10-038853:8k_2_02:35]
|  |  | Three Month Periods Ended |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| GAAP: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,940,156 |  |  | $ | 6,556,137 |  |
| Cost of sales |  |  | 5,600,919 |  |  |  | 6,173,461 |  |
| Restructuring charges |  |  | 18,322 |  |  |  | 9,624 |  |
| Gross profit |  |  | 320,915 |  |  |  | 373,052 |  |
| Selling, general and administrative expenses |  |  | 183,582 |  |  |  | 205,614 |  |
| Restructuring charges |  |  | 1,991 |  |  |  | 162 |  |
| Operating income |  |  | 135,342 |  |  |  | 167,276 |  |
| Intangible amortization |  |  | 22,131 |  |  |  | 21,440 |  |
| Other expense, net |  |  | 10,478 |  |  |  | — |  |
| Interest and other expense, net |  |  | 37,090 |  |  |  | 40,555 |  |
| Income before income taxes |  |  | 65,643 |  |  |  | 105,281 |  |
| Provision for income taxes |  |  | 5,535 |  |  |  | 12,411 |  |
| Net income |  | $ | 60,108 |  |  | $ | 92,870 |  |
| EPS: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.07 |  |  | $ | 0.11 |  |
| Non-GAAP |  | $ | 0.16 |  |  | $ | 0.17 |  |
| Diluted Shares used in computing per share amounts |  |  | 826,721 |  |  |  | 825,545 |  |

[0000950123-10-038853:8k_2_02:36]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures.

[0000950123-10-038853:8k_2_02:37]
SCHEDULE II

[0000950123-10-038853:8k_2_02:38]
FLEXTRONICS INTERNATIONAL LTD. AND SUBSIDIARIES

[0000950123-10-038853:8k_2_02:39]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0000950123-10-038853:8k_2_02:40]
(In thousands, except per share amounts)

[0000950123-10-038853:8k_2_02:41]
(unaudited)

[0000950123-10-038853:8k_2_02:42]
|  |  |  |  |  |  | Three Month Periods Ended |  |
|  |  |  |  |  |  | March 31, |  |  | % of |  |  | December 31, |  |  | % of |  |
|  |  |  |  |  |  | 2010 |  |  | Sales |  |  | 2009 |  |  | Sales |  |
| Net Sales |  |  |  |  |  | $ | 5,940,156 |  |  |  |  |  |  | $ | 6,556,137 |  |  |  |  |  |
| GAAP gross profit |  |  |  |  |  | $ | 320,915 |  |  |  | 5.4 | % |  | $ | 373,052 |  |  |  | 5.7 | % |
| Stock-based compensation expense |  |  |  |  |  |  | 3,120 |  |  |  |  |  |  |  | 2,733 |  |  |  |  |  |
| Distressed customer charges |  |  | (2 | ) |  |  | — |  |  |  |  |  |  |  | (26,439 | ) |  |  |  |  |
| Restructuring charges |  |  | (3 | ) |  |  | 18,322 |  |  |  |  |  |  |  | 9,624 |  |  |  |  |  |
| Non-GAAP gross profit |  |  |  |  |  | $ | 342,357 |  |  |  | 5.8 | % |  | $ | 358,970 |  |  |  | 5.5 | % |
| GAAP SG&A expenses |  |  |  |  |  | $ | 183,582 |  |  |  | 3.1 | % |  | $ | 205,614 |  |  |  | 3.1 | % |
| Stock-based compensation expense |  |  |  |  |  |  | (11,169 | ) |  |  |  |  |  |  | (11,381 | ) |  |  |  |  |
| Distressed customer charges |  |  | (2 | ) |  |  | — |  |  |  |  |  |  |  | (24,093 | ) |  |  |  |  |
| Non-GAAP SG&A expenses |  |  |  |  |  | $ | 172,413 |  |  |  | 2.9 | % |  | $ | 170,140 |  |  |  | 2.6 | % |
| GAAP operating income |  |  |  |  |  | $ | 135,342 |  |  |  | 2.3 | % |  | $ | 167,276 |  |  |  | 2.6 | % |
| Stock-based compensation expense |  |  |  |  |  |  | 14,289 |  |  |  |  |  |  |  | 14,114 |  |  |  |  |  |
| Distressed customer charges |  |  | (2 | ) |  |  | — |  |  |  |  |  |  |  | (2,346 | ) |  |  |  |  |
| Restructuring charges |  |  | (3 | ) |  |  | 20,313 |  |  |  |  |  |  |  | 9,786 |  |  |  |  |  |
| Non-GAAP operating income |  |  |  |  |  | $ | 169,944 |  |  |  | 2.9 | % |  | $ | 188,830 |  |  |  | 2.9 | % |
| GAAP net income |  |  |  |  |  | $ | 60,108 |  |  |  | 1.0 | % |  | $ | 92,870 |  |  |  | 1.4 | % |
| Stock-based compensation expense |  |  |  |  |  |  | 14,289 |  |  |  |  |  |  |  | 14,114 |  |  |  |  |  |
| Distressed customer charges |  |  | (2 | ) |  |  | — |  |  |  |  |  |  |  | (2,346 | ) |  |  |  |  |
| Restructuring charges |  |  | (3 | ) |  |  | 20,313 |  |  |  |  |  |  |  | 9,786 |  |  |  |  |  |
| Extinguishment of debt |  |  | (4 | ) |  |  | 10,478 |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Non-cash convertible debt interest expense |  |  | (5 | ) |  |  | 3,990 |  |  |  |  |  |  |  | 3,889 |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | 22,131 |  |  |  |  |  |  |  | 21,440 |  |  |  |  |  |
| Adjustment for taxes |  |  |  |  |  |  | (1,307 | ) |  |  |  |  |  |  | (1,791 | ) |  |  |  |  |
| Non-GAAP net income |  |  |  |  |  | $ | 130,002 |  |  |  | 2.2 | % |  | $ | 137,962 |  |  |  | 2.1 | % |
| GAAP provision for income taxes |  |  |  |  |  | $ | 5,535 |  |  |  | 0.1 | % |  | $ | 12,411 |  |  |  | 0.2 | % |
| Restructuring charges |  |  |  |  |  |  | (619 | ) |  |  |  |  |  |  | 130 |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | 1,926 |  |  |  |  |  |  |  | 1,661 |  |  |  |  |  |
| Non-GAAP provision for income taxes |  |  |  |  |  | $ | 6,842 |  |  |  | 0.1 | % |  | $ | 14,202 |  |  |  | 0.2 | % |
| EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  |  |  |  |  | $ | 0.07 |  |  |  |  |  |  | $ | 0.11 |  |  |  |  |  |
| Non-GAAP |  |  |  |  |  | $ | 0.16 |  |  |  |  |  |  | $ | 0.17 |  |  |  |  |  |
| GAAP net cash flows provided by operating activities |  |  |  |  |  | $ | 49,208 |  |  |  |  |  |  | $ | 331,304 |  |  |  |  |  |
| Purchase of property & equipment, net of dispositions |  |  |  |  |  |  | (56,064 | ) |  |  |  |  |  |  | (40,236 | ) |  |  |  |  |
| Non-GAAP free cash flow |  |  |  |  |  | $ | (6,856 | ) |  |  |  |  |  | $ | 291,068 |  |  |  |  |  |

[0000950123-10-038853:8k_2_02:43]
See the accompanying notes on Schedule IV attached to this press release.

[0000950123-10-038853:8k_2_02:44]
SCHEDULE III

[0000950123-10-038853:8k_2_02:45]
FLEXTRONICS INTERNATIONAL LTD. AND SUBSIDIARIES

[0000950123-10-038853:8k_2_02:46]
UNAUDITED GAAP CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950123-10-038853:8k_2_02:47]
(In thousands)

[0000950123-10-038853:8k_2_02:48]
|  |  | March 31, 2010 |  |  | March 31, 2009 (5) |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,927,556 |  |  | $ | 1,821,886 |  |
| Accounts receivable, net |  |  | 2,438,950 |  |  |  | 2,316,939 |  |
| Inventories |  |  | 2,875,819 |  |  |  | 2,996,785 |  |
| Other current assets |  |  | 747,676 |  |  |  | 799,396 |  |
| Total current assets |  |  | 7,990,001 |  |  |  | 7,935,006 |  |
| Property and equipment, net |  |  | 2,118,576 |  |  |  | 2,333,781 |  |
| Goodwill and other intangibles, net |  |  | 254,717 |  |  |  | 291,491 |  |
| Other assets |  |  | 279,258 |  |  |  | 756,662 |  |
| Total assets |  | $ | 10,642,552 |  |  | $ | 11,316,940 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Bank borrowings, current portion of long-term debt and capital lease obligations |  | $ | 32,311 |  |  | $ | 19,358 |  |
| Zero Coupon Convertible Junior Subordinated Notes due 2009 |  |  | — |  |  |  | 189,045 |  |
| 1% Convertible Subordinated Notes due 2010 |  |  | 234,240 |  |  |  | — |  |
| Accounts payable |  |  | 4,447,968 |  |  |  | 4,049,534 |  |
| Other current liabilities |  |  | 1,632,692 |  |  |  | 2,150,834 |  |
| Total current liabilities |  |  | 6,347,211 |  |  |  | 6,408,771 |  |
| Long-term debt, net of current portion: |  |  |  |  |  |  |  |  |
| Acquisition Term Loan due 2012 and 2014 |  |  | 1,674,435 |  |  |  | 1,692,024 |  |
| 6 1/2% Senior Subordinated Notes due 2013 |  |  | — |  |  |  | 399,622 |  |
| 6 1/4% Senior Subordinated Notes due 2014 |  |  | 302,172 |  |  |  | 402,090 |  |
| 1% Convertible Subordinated Notes due 2010 |  |  | — |  |  |  | 218,391 |  |
| Other long-term debt and capital lease obligations |  |  | 13,651 |  |  |  | 21,553 |  |
| Other liabilities |  |  | 320,516 |  |  |  | 313,321 |  |
| Total shareholders’ equity |  |  | 1,984,567 |  |  |  | 1,861,168 |  |
| Total liabilities and shareholders’ equity |  | $ | 10,642,552 |  |  | $ | 11,316,940 |  |

[0000950123-10-038853:8k_2_02:49]
See the accompanying notes on schedule IV attached to this press release.

[0000950123-10-038853:8k_2_02:50]
SCHEDULE IV

[0000950123-10-038853:8k_2_02:51]
FLEXTRONICS INTERNATIONAL LTD. AND SUBSIDIARIES

[0000950123-10-038853:8k_2_02:52]
NOTES TO SCHEDULES I, II, & III

[0000950123-10-038853:8k_2_02:53]
| (1) |  | To supplement Flextronics’s unaudited selected financial data presented on a basis consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP selling, general and administrative expenses, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share. These supplemental measures exclude, among other items, stock-based compensation expense, restructuring charges, intangible amortization, financially distressed customer charges, non-cash convertible debt interest expense and certain other items. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies. We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flextronics’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flextronics’s results of operations in conjunction with the corresponding GAAP measures. The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures. We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of Company performance. |
|  |  | In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures. Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation. Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results. We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering: |

[0000950123-10-038853:8k_2_02:54]
|  | • |  | the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results; |

[0000950123-10-038853:8k_2_02:55]
|  | • |  | the ability to better identify trends in the Company’s underlying business and perform related trend analyses; |

[0000950123-10-038853:8k_2_02:56]
|  | • |  | a better understanding of how management plans and measures the Company’s underlying business; and |

[0000950123-10-038853:8k_2_02:57]
|  | • |  | an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures. |

[0000950123-10-038853:8k_2_02:58]
The following are explanations of each of the adjustments that we incorporate into non-GAAP
measures, as well as the reasons for excluding each of these individual items in the
reconciliations of these non-GAAP financial measures:

[0000950123-10-038853:8k_2_02:59]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of
stock options and unvested share bonus awards granted to employees and assumed in business
acquisitions. The Company believes that the exclusion of these charges provides for more
accurate comparisons of its operating results to peer companies due to the varying available
valuation methodologies, subjective assumptions and the variety of award types. In addition,
the Company believes it is useful to investors to understand the specific impact stock-based
compensation expense has on its operating results.

[0000950123-10-038853:8k_2_02:60]
Restructuring charges include severance, impairment, lease termination, exit costs and other
charges primarily related to the closures and consolidations of various manufacturing
facilities. These costs may vary in size based on the Company’s acquisition and
restructuring activities, are not directly related to ongoing or core business results, and
do not reflect expected future operating expenses. These costs are excluded by the Company’s
management in assessing current operating performance and forecasting its earnings trends,
and are therefore excluded by the Company from its non-GAAP measures.

[0000950123-10-038853:8k_2_02:61]
Distressed customer charges are comprised of additional provisions for doubtful accounts
receivable, inventory and other obligations for customers that are experiencing significant
financial difficulties. These costs are excluded by the Company’s management in assessing
its current operating performance and forecasting its earnings trends, and accordingly, are
excluded by the Company from its non-GAAP measures.

[0000950123-10-038853:8k_2_02:62]
Intangible amortization consists of non-cash charges that can be impacted by the timing and
magnitude of acquisitions. The Company considers its operating results without these
charges when evaluating its ongoing performance and forecasting its earnings trends, and
therefore excludes such charges when presenting non-GAAP financial measures. The Company
believes that the assessment of its operations excluding these costs is relevant to its
assessment of internal operations and comparisons to the performance of its competitors.

[0000950123-10-038853:8k_2_02:63]
Other charges or gains consists of various other types of items that are not directly related
to ongoing or core business results, such as impairment charges associated with non-core
investments and notes receivable and gains or losses on the extinguishment of debt. We
exclude these items because they are not related to the Company’s ongoing operating
performance or do not affect core operations. Excluding these amounts provide investors with
a basis to compare Company performance against the performance of other companies without
this variability.

[0000950123-10-038853:8k_2_02:64]
Non-cash convertible debt interest expense consists of interest expense recorded as a result
of new accounting for convertible debt instruments that may be settled in cash upon
conversion. The Company considers its operating results without these charges when
evaluating its ongoing performance and forecasting its earnings trends, and therefore
excludes such charges when presenting non-GAAP financial measures. The Company believes
that the assessment of its operations excluding theses costs is relevant to its assessment
of internal operations and comparisons to the performance of its competitors.

[0000950123-10-038853:8k_2_02:65]
Adjustment for taxes relates to the tax effects of the various adjustments that we
incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP
net income and certain adjustments related to tax contingencies.

[0000950123-10-038853:8k_2_02:66]
| (2) |  | During the three-month period ended December 31, 2008, the Company incurred a $145.3 million charge as a result of the previously announced Nortel bankruptcy. In November 2009, the Company agreed to a settlement with Nortel primarily related to pre-bankruptcy petition claims. As a result of this settlement, the Company revised its estimates related to the recovery of Nortel accounts receivable, certain retirement obligations and other claims. In addition, the Company has continued to recover amounts related to previously reserved inventory as a result of continuing business with Nortel post bankruptcy. During the three-month period ended December 31, 2009, we recorded a net $2.3 million reduction to the original charge which included a reduction to cost of sales of $26.3 million net of an increase to selling general and administrative expenses of $24 million. |
| (3) |  | During the three month periods ended March 31, 2010 and December 31, 2009, the Company recognized restructuring charges as a result of the difficult macroeconomic conditions. The global economic crisis and related decline in the Company’s customers’ products across all of the industries it serves, has caused the Company’s OEM customers to reduce their manufacturing and supply chain outsourcing negatively impacting the Company’s capacity utilization levels. The Company’s restructuring activities, which include employee severance, costs related to owned and leased facilities and equipment that are no longer in use and are to be disposed of, and other costs associated with the exit of certain contractual arrangements due to facility closures, are intended to improve its operational efficiencies by reducing excess workforce and capacity. In addition to the cost reductions, these activities will result in further shift of manufacturing capacity to locations with higher efficiencies and, in most instances, lower costs. |
| (4) |  | On March 19, 2010, the Company paid approximately $306.3 million to redeem the remaining aggregate principal balance of $299.8 million of its 6.5% Senior Subordinated Notes due 2013 at a redemption price of 102.167% of the principal amount. The Company recognized a loss associated with the early redemption of the notes of approximately $10.5 million during the three month period ended March 31, 2010, consisting of the redemption price premium of approximately $6.5 million, transaction costs and the write-off of unamortized debt costs totaling approximately $4.0 million. |
| (5) |  | On April 1, 2009, the Company adopted new accounting for convertible debt instruments that may be settled in cash upon conversion (including partial cash settlement) which was required to be applied retrospectively. The adoption affected the accounting for the Company’s 1% Convertible Subordinated Notes and Zero Coupon Convertible Junior Subordinated Notes by requiring the initial proceeds from their sale to be allocated between a liability component and an equity component in a manner that results in interest expense on the debt component at the Company’s nonconvertible debt borrowing rate on the date of issuance. Upon adoption the Company recorded the change in accounting principle as a cumulative effect adjustment to the opening balance of accumulated deficit as of March 31, 2009 totaling approximately $225 million and a discount to the carrying value of the convertible debt notes of $27.5 million. The corresponding increase in the recorded value of ordinary shares was approximately $252 million. The adoption had no impact on the Company’s consolidated cash flows. Below is a summary of the impacts to the financial statements and related notes and interest expense for the respective periods presented. |

[0000950123-10-038853:8k_2_02:67]
|  |  |  |  |  |  |  |  |  |  | Zero Coupon Convertible Junior |  |
|  |  | 1% Convertible Subordinated Notes |  |  | Subordinated Notes |  |
| Balance Sheet: |  | March 31, 2010 |  |  | March 31, 2009 |  |  | March 31, 2010 |  |  | March 31, 2009 |  |
|  |  | (In thousands) |  |
| Principal amount of Notes |  | $ | 239,993 |  |  | $ | 239,993 |  |  | $ | — |  |  | $ | 195,000 |  |
| Unamortized discount |  |  | (5,753 | ) |  |  | (21,602 | ) |  |  | — |  |  |  | (5,955 | ) |
| Net carrying amount of Notes |  | $ | 234,240 |  |  | $ | 218,391 |  |  | $ | — |  |  | $ | 189,045 |  |
|  |  | Three-Month Periods Ended |  |  | Three-Month Periods Ended |  |
| Income Statement: |  | March 31, 2010 |  |  | December 31, 2009 |  |  | March 31, 2010 |  |  | December 31, 2009 |  |
|  |  | (In thousands) |  |
| Amortization of discount net of adjustments to deferred financing costs |  | $ | 3,990 |  |  | $ | 3,889 |  |  | $ | — |  |  | $ | — |  |

[0000950123-10-038853:8k_2_02:68]
The adoption of the new accounting for convertible debt had less than a $0.01 negative impact on
basic and diluted GAAP earnings per share in both the three-month periods ended March 31, 2010 and
December 31, 2009.

[0000950123-10-038853:8k_2_02:69]
Free Cash Flow consists of GAAP net cash flows from operating activities less purchase of property
and equipment, net of dispositions. We believe free cash flow is an important liquidity metric
because it measures, during a given period, the amount of cash generated that is available to repay
debt obligations, make investments, fund acquisitions and for certain other activities. Since Free
Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is
useful in addition to the most directly comparable GAAP measure — “net cash flows provided by
operating activities.”

[0000950123-10-038853:8k_2_02:70]
Return on Invested Capital (ROIC) is calculated by annualizing the Company’s current quarter
after-tax non-GAAP operating income and dividing that by a two quarter average net invested capital
asset base. After-tax non-GAAP operating income excludes charges for financially distressed
customers, stock-based compensation expense, restructuring and other charges. Net invested capital
is defined as total assets less current liabilities and other long-term liabilities further
adjusted for non-operating assets and liabilities. Non-operating assets and liabilities are not
included in the net invested capital asset base because they do not affect non-GAAP operating
income. Non-operating assets and liabilities include, but are not limited to, cash and cash
equivalents, short-term investments, notes receivable, restructuring liabilities, accrued interest,
short-term bank borrowings and current and non-current debt. We believe ROIC is a useful measure in
providing investors with information regarding our performance. ROIC is a widely accepted measure
of earnings efficiency in relation to total capital employed. We believe that increasing the
return on total capital employed, as measured by ROIC, is an effective method to sustain and
increase shareholder value. ROIC is not a measure of financial performance under generally
accepted accounting principles in the U.S., and may not be defined and calculated by other
companies in the same manner. ROIC should not be considered in isolation or as an alternative to
net income or loss as an indicator of performance. The following table reconciles ROIC as
calculated using after-tax non-GAAP operating income to the same performance measure calculated
using the nearest GAAP measure, which is GAAP operating income adjusted for taxes:

[0000950123-10-038853:8k_2_02:71]
| ROIC |  | Q4 FY 2010 |  |  | Q3 FY 2010 |  |
| GAAP ROIC |  |  | 22.9 | % |  |  | 26.7 | % |
| Adjustments noted above |  |  | 5.9 | % |  |  | 3.4 | % |
| Non-GAAP ROIC |  |  | 28.8 | % |  |  | 30.1 | % |

[0000950123-10-038853:8k_2_02:72]
Cash Conversion Cycle (CCC) is defined as the sum of non-GAAP inventory turns in days and days
sales outstanding in accounts receivable less non-GAAP days payable outstanding in accounts
payable. We calculate non-GAAP inventory turns as annualized non-GAAP cost of sales (before
adjustments for financially distressed customers, stock-based compensation expense, restructuring
and other charges) divided by average inventory for the quarter. We calculate our days sales
outstanding as annualized revenues divided by average accounts receivable for the quarter. We
calculate non-GAAP days payable outstanding as annualized non-GAAP cost of sales (before
adjustments for financially distressed customers, stock-based compensation expense, restructuring
and other charges) divided by average accounts payable.

[0000950123-10-038853:8k_2_02:73]
We believe the Cash Conversion Cycle is a useful measure in providing investors with information
regarding our cash management performance and is a widely accepted measure of working capital
management efficiency. These are measures of financial performance under generally accepted
accounting principles in the U.S. when calculated using GAAP operating measures, but may not be
defined and calculated by other companies in the same manner. These should not be considered in
isolation or as an alternative to other GAAP metrics as an indicator of performance. For the
Quarter ended March 31, 2010, Cash Conversion Cycle of 11 days calculated using the non-GAAP
measures described above was the same as that calculated using cost of sales in accordance with
GAAP.
