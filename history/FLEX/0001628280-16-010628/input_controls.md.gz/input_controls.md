# FLEX 10-Q controls and the auditor's report


## item_4_controls

[0001628280-16-010628:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001628280-16-010628:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001628280-16-010628:item_4_controls:3]
Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we have evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 13a-15(e) of the Exchange Act) as of December 31, 2015, the end of the quarterly fiscal period covered by this quarterly report. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of December 31, 2015 such disclosure controls and procedures were effective in ensuring that information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended, is (i) recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms and (ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0001628280-16-010628:item_4_controls:4]
(b) Changes in Internal Control Over Financial Reporting

[0001628280-16-010628:item_4_controls:5]
There were no changes in our internal controls over financial reporting that occurred during our third quarter of fiscal year 2016 that have materially affected, or are reasonably likely to materially affect, our internal controls over financial reporting.
