# FLEX notes — 0001628280-16-010628


## flex:InterestAndOtherNetTextBlock

[0001628280-16-010628:notes:1]
[same as prior period, unchanged from 0001628280-15-007847:notes:1]

[0001628280-16-010628:notes:2]
During the three-month and nine-month periods ended December 31, 2015, the Company recognized interest expense of $26.2 million and $71.4 million, respectively, on its debt obligations outstanding during the periods. During the three-month and nine-month periods ended December 31, 2014, the Company recognized interest expense of $19.9 million and $57.5 million, respectively.

[0001628280-16-010628:notes:3]
During the three-month and nine-month periods ended December 31, 2015, the Company recognized interest income of $3.1 million and $10.9 million, respectively. During the three-month and nine-month periods ended December 31, 2014, the Company recognized interest income of $4.7 million and $14.7 million, respectively.

[0001628280-16-010628:notes:4]
During the three-month and nine-month periods ended December 31, 2015, the Company recognized gains on foreign exchange transactions of $4.4 million and $19.1 million, respectively. During the three-month and nine-month periods ended December 31, 2014, the Company recognized gains on foreign exchange transactions of $8.5 million and $13.9 million, respectively.

[0001628280-16-010628:notes:5]
During the nine-month periods ended December 31, 2015, the Company incurred $8.0 million of acquisition-related costs.


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0001628280-16-010628:notes:6]
[same as prior period, unchanged from 0001628280-15-007847:notes:6]

[0001628280-16-010628:notes:7]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Beginning balance | $ | 537,619 |  |  | $ | 426,057 |  |  | $ | 600,672 |  |  | $ | 470,908 |  |
| Transfers of receivables | 920,370 |  |  | 1,139,744 |  |  | 2,671,095 |  |  | 2,639,526 |  |
| Collections | (923,294 | ) |  | (891,159 | ) |  | (2,737,072 | ) |  | (2,435,792 | ) |
| Ending balance | $ | 534,695 |  |  | $ | 674,642 |  |  | $ | 534,695 |  |  | $ | 674,642 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001628280-16-010628:notes:8]
[same as prior period, unchanged from 0001628280-15-007847:notes:8]

[0001628280-16-010628:notes:9]
Flextronics International Ltd. (“Parent”) has three tranches of Notes of $500 million, $500 million, and $600 million, respectively, each outstanding, which mature on February 15, 2020, February 15, 2023 and June 15, 2025, respectively. These Notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company’s 100% owned subsidiaries (the “guarantor subsidiaries”). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade.

[0001628280-16-010628:notes:10]
In lieu of providing separate financial statements for the guarantor subsidiaries, the Company has included the accompanying condensed consolidating financial statements, which are presented using the equity method of accounting. The principal elimination entries relate to investment in subsidiaries and intercompany balances and transactions, including transactions with the Company’s non-guarantor subsidiaries. During the nine-month period ended December 31, 2015, and in conjunction with the new $600 million Notes, a new entity was added as a guarantor subsidiary for all three tranches of the Notes. Accordingly, the Company recast the condensed consolidating financial statements presented below to reflect this change.

[0001628280-16-010628:notes:11]
Condensed Consolidating Balance Sheets as of December 31, 2015

[0001628280-16-010628:notes:12]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 868,114 |  |  | $ | 188,540 |  |  | $ | 577,540 |  |  | $ | — |  |  | $ | 1,634,194 |  |
| Accounts receivable | — |  |  | 1,056,939 |  |  | 1,527,970 |  |  | — |  |  | 2,584,909 |  |
| Inventories | — |  |  | 1,487,706 |  |  | 2,003,027 |  |  | — |  |  | 3,490,733 |  |
| Inter company receivable | 9,102,531 |  |  | 5,282,669 |  |  | 12,479,607 |  |  | (26,864,807 | ) |  | — |  |
| Other current assets | 5,832 |  |  | 249,367 |  |  | 991,569 |  |  | — |  |  | 1,246,768 |  |
| Total current assets | 9,976,477 |  |  | 8,265,221 |  |  | 17,579,713 |  |  | (26,864,807 | ) |  | 8,956,604 |  |
| Property and equipment, net | — |  |  | 542,606 |  |  | 1,697,315 |  |  | — |  |  | 2,239,921 |  |
| Goodwill and other intangible assets, net | 250 |  |  | 66,969 |  |  | 1,249,798 |  |  | — |  |  | 1,317,017 |  |
| Other assets | 2,232,454 |  |  | 234,267 |  |  | 2,087,952 |  |  | (4,018,697 | ) |  | 535,976 |  |
| Investment in subsidiaries | 1,965,783 |  |  | 2,813,134 |  |  | 16,874,908 |  |  | (21,653,825 | ) |  | — |  |
| Total assets | $ | 14,174,964 |  |  | $ | 11,922,197 |  |  | $ | 39,489,686 |  |  | $ | (52,537,329 | ) |  | $ | 13,049,518 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 60,000 |  |  | $ | 917 |  |  | $ | 4,619 |  |  | $ | — |  |  | $ | 65,536 |  |
| Accounts payable | — |  |  | 1,538,397 |  |  | 3,263,797 |  |  | — |  |  | 4,802,194 |  |
| Accrued payroll | — |  |  | 109,299 |  |  | 250,710 |  |  | — |  |  | 360,009 |  |
| Inter company payable | 8,809,843 |  |  | 8,754,992 |  |  | 9,299,972 |  |  | (26,864,807 | ) |  | — |  |
| Other current liabilities | 47,572 |  |  | 804,571 |  |  | 1,072,389 |  |  | — |  |  | 1,924,532 |  |
| Total current liabilities | 8,917,415 |  |  | 11,208,176 |  |  | 13,891,487 |  |  | (26,864,807 | ) |  | 7,152,271 |  |
| Long term liabilities | 2,714,294 |  |  | 2,045,880 |  |  | 2,577,338 |  |  | (4,018,697 | ) |  | 3,318,815 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) | 2,543,255 |  |  | (1,331,859 | ) |  | 22,985,684 |  |  | (21,653,825 | ) |  | 2,543,255 |  |
| Noncontrolling interests | — |  |  | — |  |  | 35,177 |  |  | — |  |  | 35,177 |  |
| Total shareholders’ equity (deficit) | 2,543,255 |  |  | (1,331,859 | ) |  | 23,020,861 |  |  | (21,653,825 | ) |  | 2,578,432 |  |
| Total liabilities and shareholders’ equity | $ | 14,174,964 |  |  | $ | 11,922,197 |  |  | $ | 39,489,686 |  |  | $ | (52,537,329 | ) |  | $ | 13,049,518 |  |

[0001628280-16-010628:notes:13]
[same as prior period, unchanged from 0001628280-15-007847:notes:13]

[0001628280-16-010628:notes:14]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 608,971 |  |  | $ | 168,272 |  |  | $ | 851,165 |  |  | $ | — |  |  | $ | 1,628,408 |  |
| Accounts receivable | — |  |  | 1,208,632 |  |  | 1,128,883 |  |  | — |  |  | 2,337,515 |  |
| Inventories | — |  |  | 1,729,593 |  |  | 1,759,159 |  |  | — |  |  | 3,488,752 |  |
| Inter company receivable | 6,417,410 |  |  | 4,759,062 |  |  | 10,099,057 |  |  | (21,275,529 | ) |  | — |  |
| Other current assets | 8,143 |  |  | 202,160 |  |  | 1,075,922 |  |  | — |  |  | 1,286,225 |  |
| Total current assets | 7,034,524 |  |  | 8,067,719 |  |  | 14,914,186 |  |  | (21,275,529 | ) |  | 8,740,900 |  |
| Property and equipment, net | — |  |  | 471,052 |  |  | 1,621,115 |  |  | — |  |  | 2,092,167 |  |
| Goodwill and other intangible assets, net | 475 |  |  | 64,831 |  |  | 349,869 |  |  | — |  |  | 415,175 |  |
| Other assets | 2,223,402 |  |  | 155,172 |  |  | 2,131,523 |  |  | (4,092,715 | ) |  | 417,382 |  |
| Investment in subsidiaries | 1,799,956 |  |  | 1,658,387 |  |  | 16,641,212 |  |  | (20,099,555 | ) |  | — |  |
| Total assets | $ | 11,058,357 |  |  | $ | 10,417,161 |  |  | $ | 35,657,905 |  |  | $ | (45,467,799 | ) |  | $ | 11,665,624 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 40,000 |  |  | $ | 917 |  |  | $ | 5,245 |  |  | $ | — |  |  | $ | 46,162 |  |
| Accounts payable | — |  |  | 1,758,305 |  |  | 2,802,889 |  |  | — |  |  | 4,561,194 |  |
| Accrued payroll | — |  |  | 112,692 |  |  | 227,047 |  |  | — |  |  | 339,739 |  |
| Inter company payable | 6,559,569 |  |  | 7,250,235 |  |  | 7,465,725 |  |  | (21,275,529 | ) |  | — |  |
| Other current liabilities | 30,553 |  |  | 845,156 |  |  | 933,419 |  |  | — |  |  | 1,809,128 |  |
| Total current liabilities | 6,630,122 |  |  | 9,967,305 |  |  | 11,434,325 |  |  | (21,275,529 | ) |  | 6,756,223 |  |
| Long term liabilities | 2,067,421 |  |  | 2,102,483 |  |  | 2,435,962 |  |  | (4,092,715 | ) |  | 2,513,151 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) | 2,360,814 |  |  | (1,652,627 | ) |  | 21,752,182 |  |  | (20,099,555 | ) |  | 2,360,814 |  |
| Noncontrolling interests | — |  |  | — |  |  | 35,436 |  |  | — |  |  | 35,436 |  |
| Total shareholders’ equity (deficit) | 2,360,814 |  |  | (1,652,627 | ) |  | 21,787,618 |  |  | (20,099,555 | ) |  | 2,396,250 |  |
| Total liabilities and shareholders’ equity | $ | 11,058,357 |  |  | $ | 10,417,161 |  |  | $ | 35,657,905 |  |  | $ | (45,467,799 | ) |  | $ | 11,665,624 |  |

[0001628280-16-010628:notes:15]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended December 31, 2015

[0001628280-16-010628:notes:16]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 4,598,248 |  |  | $ | 5,717,609 |  |  | $ | (3,552,680 | ) |  | $ | 6,763,177 |  |
| Cost of sales | — |  |  | 4,186,909 |  |  | 5,676,481 |  |  | (3,552,680 | ) |  | 6,310,710 |  |
| Gross profit | — |  |  | 411,339 |  |  | 41,128 |  |  | — |  |  | 452,467 |  |
| Selling, general and administrative expenses | — |  |  | 83,750 |  |  | 156,867 |  |  | — |  |  | 240,617 |  |
| Intangible amortization | 75 |  |  | 960 |  |  | 18,284 |  |  | — |  |  | 19,319 |  |
| Interest and other, net | 49,358 |  |  | 318,367 |  |  | (301,744 | ) |  | — |  |  | 65,981 |  |
| Income (loss) from continuing operations before income taxes | (49,433 | ) |  | 8,262 |  |  | 167,721 |  |  | — |  |  | 126,550 |  |
| Provision for income taxes | — |  |  | (8,071 | ) |  | (14,289 | ) |  | — |  |  | (22,360 | ) |
| Equity in earnings in subsidiaries | 198,343 |  |  | (52,808 | ) |  | (12,229 | ) |  | (133,306 | ) |  | — |  |
| Net income (loss) | $ | 148,910 |  |  | $ | (36,475 | ) |  | $ | 169,781 |  |  | $ | (133,306 | ) |  | $ | 148,910 |  |

[0001628280-16-010628:notes:17]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended December 31, 2014

[0001628280-16-010628:notes:18]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 5,164,527 |  |  | $ | 5,437,970 |  |  | $ | (3,577,443 | ) |  | $ | 7,025,054 |  |
| Cost of sales | — |  |  | 4,757,332 |  |  | 5,436,508 |  |  | (3,577,443 | ) |  | 6,616,397 |  |
| Gross profit | — |  |  | 407,195 |  |  | 1,462 |  |  | — |  |  | 408,657 |  |
| Selling, general and administrative expenses | — |  |  | 64,161 |  |  | 151,832 |  |  | — |  |  | 215,993 |  |
| Intangible amortization | 75 |  |  | 937 |  |  | 7,033 |  |  | — |  |  | 8,045 |  |
| Interest and other, net | 27,876 |  |  | 249,948 |  |  | (263,722 | ) |  | — |  |  | 14,102 |  |
| Income (loss) from continuing operations before income taxes | (27,951 | ) |  | 92,149 |  |  | 106,319 |  |  | — |  |  | 170,517 |  |
| Provision for income taxes | — |  |  | (5,737 | ) |  | 23,355 |  |  | — |  |  | 17,618 |  |
| Equity in earnings in subsidiaries | 180,850 |  |  | (69,438 | ) |  | 61,337 |  |  | (172,749 | ) |  | — |  |
| Net income (loss) | $ | 152,899 |  |  | $ | 28,448 |  |  | $ | 144,301 |  |  | $ | (172,749 | ) |  | $ | 152,899 |  |

[0001628280-16-010628:notes:19]
Condensed Consolidating Statements of Operations for the Nine-Month Period Ended December 31, 2015

[0001628280-16-010628:notes:20]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 13,126,846 |  |  | $ | 15,167,659 |  |  | $ | (9,648,318 | ) |  | $ | 18,646,187 |  |
| Cost of sales | — |  |  | 11,972,222 |  |  | 15,120,559 |  |  | (9,648,318 | ) |  | 17,444,463 |  |
| Gross profit | — |  |  | 1,154,624 |  |  | 47,100 |  |  | — |  |  | 1,201,724 |  |
| Selling, general and administrative expenses | — |  |  | 214,015 |  |  | 452,783 |  |  | — |  |  | 666,798 |  |
| Intangible amortization | 225 |  |  | 2,881 |  |  | 40,011 |  |  | — |  |  | 43,117 |  |
| Interest and other, net | (347,663 | ) |  | 931,754 |  |  | (477,728 | ) |  | — |  |  | 106,363 |  |
| Income from continuing operations before income taxes | 347,438 |  |  | 5,974 |  |  | 32,034 |  |  | — |  |  | 385,446 |  |
| Provision for income taxes | — |  |  | (4,630 | ) |  | 7,339 |  |  | — |  |  | 2,709 |  |
| Equity in earnings in subsidiaries | 35,299 |  |  | (104,435 | ) |  | 40,531 |  |  | 28,605 |  |  | — |  |
| Net income (loss) | $ | 382,737 |  |  | $ | (93,831 | ) |  | $ | 65,226 |  |  | $ | 28,605 |  |  | $ | 382,737 |  |

[0001628280-16-010628:notes:21]
Condensed Consolidating Statements of Operations for the Nine-Month Period Ended December 31, 2014

[0001628280-16-010628:notes:22]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 14,702,071 |  |  | $ | 15,399,047 |  |  | $ | (9,904,802 | ) |  | $ | 20,196,316 |  |
| Cost of sales | — |  |  | 13,616,471 |  |  | 15,318,124 |  |  | (9,904,802 | ) |  | 19,029,793 |  |
| Gross profit | — |  |  | 1,085,600 |  |  | 80,923 |  |  | — |  |  | 1,166,523 |  |
| Selling, general and administrative expenses | — |  |  | 188,788 |  |  | 441,072 |  |  | — |  |  | 629,860 |  |
| Intangible amortization | 225 |  |  | 2,624 |  |  | 20,379 |  |  | — |  |  | 23,228 |  |
| Interest and other, net | (24,933 | ) |  | 797,142 |  |  | (773,557 | ) |  | — |  |  | (1,348 | ) |
| Income from continuing operations before income taxes | 24,708 |  |  | 97,046 |  |  | 393,029 |  |  | — |  |  | 514,783 |  |
| Provision for income taxes | — |  |  | 9,053 |  |  | 40,041 |  |  | — |  |  | 49,094 |  |
| Equity in earnings in subsidiaries | 440,981 |  |  | (55,992 | ) |  | 148,946 |  |  | (533,935 | ) |  | — |  |
| Net income | $ | 465,689 |  |  | $ | 32,001 |  |  | $ | 501,934 |  |  | $ | (533,935 | ) |  | $ | 465,689 |  |

[0001628280-16-010628:notes:23]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended December 31, 2015

[0001628280-16-010628:notes:24]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 148,910 |  |  | $ | (36,475 | ) |  | $ | 169,781 |  |  | $ | (133,306 | ) |  | $ | 148,910 |  |
| Other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 30,063 |  |  | 64,298 |  |  | 50,828 |  |  | (115,126 | ) |  | 30,063 |  |
| Unrealized gain on derivative instruments and other, net of zero tax | 10,497 |  |  | 4,099 |  |  | 10,497 |  |  | (14,596 | ) |  | 10,497 |  |
| Comprehensive income | $ | 189,470 |  |  | $ | 31,922 |  |  | $ | 231,106 |  |  | $ | (263,028 | ) |  | $ | 189,470 |  |

[0001628280-16-010628:notes:25]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended December 31, 2014

[0001628280-16-010628:notes:26]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income | $ | 152,899 |  |  | $ | 28,448 |  |  | $ | 144,301 |  |  | $ | (172,749 | ) |  | $ | 152,899 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (15,154 | ) |  | 96,645 |  |  | 37,167 |  |  | (133,812 | ) |  | (15,154 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax | (22,797 | ) |  | (5,936 | ) |  | (22,797 | ) |  | 28,733 |  |  | (22,797 | ) |
| Comprehensive income | $ | 114,948 |  |  | $ | 119,157 |  |  | $ | 158,671 |  |  | $ | (277,828 | ) |  | $ | 114,948 |  |

[0001628280-16-010628:notes:27]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Nine-Month Period Ended December 31, 2015

[0001628280-16-010628:notes:28]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 382,737 |  |  | $ | (93,831 | ) |  | $ | 65,226 |  |  | $ | 28,605 |  |  | $ | 382,737 |  |
| Other comprehensive income (loss): | 0 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 2,579 |  |  | 7,113 |  |  | (703 | ) |  | (6,410 | ) |  | 2,579 |  |
| Unrealized gain on derivative instruments and other, net of zero tax | 17,782 |  |  | 9,883 |  |  | 17,782 |  |  | (27,665 | ) |  | 17,782 |  |
| Comprehensive income (loss) | $ | 403,098 |  |  | $ | (76,835 | ) |  | $ | 82,305 |  |  | $ | (5,470 | ) |  | $ | 403,098 |  |

[0001628280-16-010628:notes:29]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Nine-Month Period Ended December 31, 2014

[0001628280-16-010628:notes:30]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income | $ | 465,689 |  |  | $ | 32,001 |  |  | $ | 501,934 |  |  | $ | (533,935 | ) |  | $ | 465,689 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (24,982 | ) |  | 190,307 |  |  | 108,504 |  |  | (298,811 | ) |  | (24,982 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax | (14,505 | ) |  | (6,164 | ) |  | (14,505 | ) |  | 20,669 |  |  | (14,505 | ) |
| Comprehensive income | $ | 426,202 |  |  | $ | 216,144 |  |  | $ | 595,933 |  |  | $ | (812,077 | ) |  | $ | 426,202 |  |

[0001628280-16-010628:notes:31]
Condensed Consolidating Statements of Cash Flows for the Nine-Month Period Ended December 31, 2015

[0001628280-16-010628:notes:32]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 343,182 |  |  | $ | (92,821 | ) |  | $ | 689,411 |  |  |  |  |  |  | $ | 939,772 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (128,011 | ) |  | (285,928 | ) |  | 5 |  |  | (413,934 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | (809,233 | ) |  | (91,009 | ) |  | — |  |  | (900,242 | ) |
| Investing cash flows to affiliates | (1,099,775 | ) |  | (994,387 | ) |  | (944,200 | ) |  | 3,038,362 |  |  | — |  |
| Other investing activities, net | (2,046 | ) |  | (23,270 | ) |  | 26,713 |  |  | — |  |  | 1,397 |  |
| Net cash used in investing activities | (1,101,821 | ) |  | (1,954,901 | ) |  | (1,294,424 | ) |  | 3,038,367 |  |  | (1,312,779 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 695,309 |  |  | — |  |  | 60,375 |  |  | — |  |  | 755,684 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (35,638 | ) |  | (1,333 | ) |  | (3,735 | ) |  | — |  |  | (40,706 | ) |
| Payments for repurchases of ordinary shares | (331,690 | ) |  | — |  |  | — |  |  | — |  |  | (331,690 | ) |
| Net proceeds from issuance of ordinary shares | 52,950 |  |  | — |  |  | — |  |  | — |  |  | 52,950 |  |
| Financing cash flows from affiliates | 632,750 |  |  | 2,065,092 |  |  | 340,525 |  |  | (3,038,367 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | (49,742 | ) |  | — |  |  | (49,742 | ) |
| Net cash provided by financing activities | 1,013,681 |  |  | 2,063,759 |  |  | 347,423 |  |  | (3,038,367 | ) |  | 386,496 |  |
| Effect of exchange rates on cash and cash equivalents | 4,101 |  |  | 4,231 |  |  | (16,035 | ) |  | — |  |  | (7,703 | ) |
| Net increase (decrease) in cash and cash equivalents | 259,143 |  |  | 20,268 |  |  | (273,625 | ) |  | — |  |  | 5,786 |  |
| Cash and cash equivalents, beginning of period | 608,971 |  |  | 168,272 |  |  | 851,165 |  |  | — |  |  | 1,628,408 |  |
| Cash and cash equivalents, end of period | $ | 868,114 |  |  | $ | 188,540 |  |  | $ | 577,540 |  |  | $ | — |  |  | $ | 1,634,194 |  |

[0001628280-16-010628:notes:33]
Condensed Consolidating Statements of Cash Flows for the Nine-Month Period Ended December 31, 2014

[0001628280-16-010628:notes:34]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | (4,319 | ) |  | $ | 11,083 |  |  | $ | 662,660 |  |  | $ | — |  |  | $ | 669,424 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (76,042 | ) |  | (88,340 | ) |  | (12 | ) |  | (164,394 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | (20,092 | ) |  | (38,040 | ) |  | — |  |  | (58,132 | ) |
| Investing cash flows from (to) affiliates | (1,163,617 | ) |  | (2,257,892 | ) |  | 370,504 |  |  | 3,051,005 |  |  | — |  |
| Other investing activities, net | (1,500 | ) |  | (10,597 | ) |  | 580 |  |  |  |  |  | (11,517 | ) |
| Net cash provided by (used in) investing activities | (1,165,117 | ) |  | (2,364,623 | ) |  | 244,704 |  |  | 3,050,993 |  |  | (234,043 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 223,000 |  |  | — |  |  | 11,523 |  |  | — |  |  | 234,523 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (245,500 | ) |  | (1,686 | ) |  | (4,151 | ) |  | — |  |  | (251,337 | ) |
| Payments for repurchases of ordinary shares | (290,752 | ) |  | — |  |  | — |  |  | — |  |  | (290,752 | ) |
| Net proceeds from issuance of ordinary shares | 12,341 |  |  | — |  |  | — |  |  | — |  |  | 12,341 |  |
| Financing cash flows from (to) affiliates | 1,575,271 |  |  | 2,340,819 |  |  | (865,097 | ) |  | (3,050,993 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | (29,135 | ) |  | — |  |  | (29,135 | ) |
| Net cash provided by (used in) financing activities | 1,274,360 |  |  | 2,339,133 |  |  | (886,860 | ) |  | (3,050,993 | ) |  | (324,360 | ) |
| Effect of exchange rates on cash and cash equivalents | (137,117 | ) |  | (5,893 | ) |  | 145,482 |  |  | — |  |  | 2,472 |  |
| Net decrease (increase) in cash and cash equivalents | (32,193 | ) |  | (20,300 | ) |  | 165,986 |  |  | — |  |  | 113,493 |  |
| Cash and cash equivalents, beginning of period | 638,714 |  |  | 210,462 |  |  | 744,552 |  |  | — |  |  | 1,593,728 |  |
| Cash and cash equivalents, end of period | $ | 606,521 |  |  | $ | 190,162 |  |  | $ | 910,538 |  |  | $ | — |  |  | $ | 1,707,221 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-16-010628:notes:35]
[same as prior period, unchanged from 0001628280-15-007847:notes:35]

[0001628280-16-010628:notes:36]
[same as prior period, unchanged from 0001628280-15-007847:notes:36]

[0001628280-16-010628:notes:37]
On June 29, 2015, the Company completed its acquisition of 100% of the outstanding share capital of MCi, and paid approximately $555.2 million, net of $27.7 million of cash acquired. This acquisition expanded the Company's capabilities in the automotive market, and was included in the HRS segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001628280-16-010628:notes:38]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities of MCi (in thousands):

[0001628280-16-010628:notes:39]
| Current assets: |  |
| Accounts receivable | $ | 41,392 |  |
| Inventories | 19,169 |  |
| Other current assets | 2,798 |  |
| Total current assets | 63,359 |  |
| Property and equipment, net | 38,875 |  |
| Other assets | 1,632 |  |
| Intangibles | 236,800 |  |
| Goodwill | 322,458 |  |
| Total assets | $ | 663,124 |  |
| Current liabilities: |  |
| Accounts payable | $ | 28,002 |  |
| Accrued liabilities & other current liabilities | 19,798 |  |
| Total current liabilities | 47,800 |  |
| Other liabilities | 60,166 |  |
| Total aggregate purchase price | $ | 555,158 |  |

[0001628280-16-010628:notes:40]
The intangible assets of $236.8 million is comprised of customer relationships of $75.5 million and licenses and other intangible assets of $161.3 million. Customer relationships and licenses and other intangibles are each amortized over a weighted-average estimated useful life of 10 years. In addition to accounts receivable and inventories, the Company acquired $38.9 million of machinery and equipment and assumed $60.2 million of other liabilities primarily comprised of deferred tax liabilities. The Company incurred $6.6 million in acquisition-related costs related to the acquisition of MCi during the nine-month period ended December 31, 2015.

[0001628280-16-010628:notes:41]
The above purchase price allocation includes certain purchase accounting adjustments recorded during the three-month period ended December 31, 2015, which approximately resulted in a net increase of $32.0 million to goodwill, a net decrease of deferred tax liabilities of $10.6 million, and a net decrease of $43.2 million to intangibles. The decrease in intangible assets was a result of the finalization of the valuation for acquired intangible assets, which also resulted in an update in the estimated useful life from 8 years to 10 years.  The impact resulted in a $2.3 million reduction in amortization expense during the three-month period ended December 31, 2015, which would have been the impact in the prior quarter if the final assumptions relating to the valuation for the acquired intangible assets were applied at the original acquisition date.

[0001628280-16-010628:notes:42]
[same as prior period, unchanged from 0001628280-15-007847:notes:41]

[0001628280-16-010628:notes:43]
On July 1, 2015, the Company acquired an optical transport facility from Alcatel-Lucent for approximately $67.5 million, which expanded its capabilities in the telecom market and was included in the INS segment. The Company acquired primarily $55.0 million of inventory, $10.0 million of property and equipment primarily comprised of a building and land, and recorded goodwill and intangible assets for a customer relationship of $3.6 million and $2.1 million, respectively, and assumed $3.2 million in other net liabilities in connection with this acquisition. The customer relationship intangible will amortize over a weighted-average estimated useful life of 5 years.

[0001628280-16-010628:notes:44]
Acquisition of NEXTracker

[0001628280-16-010628:notes:45]
On September 28, 2015, the Company acquired 100% of the outstanding share capital of NEXTracker, a provider of smart solar tracking solutions. The initial cash consideration was approximately $238.9 million, net of $13.2 million of cash acquired, with an additional $81.0 million of estimated potential contingent consideration, for a total purchase consideration of $319.9 million. This contingent consideration could reach a maximum of $97.2 million upon achievement of future revenue performance targets. The Company also acquired NEXTracker’s equity incentive plan. The financial results of NEXTracker were included in the IEI segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition and is subject to change as the Company finalizes the valuation of the intangible assets acquired. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001628280-16-010628:notes:46]
The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of NEXTracker (in thousands):

[0001628280-16-010628:notes:47]
| Current assets: |  |
| Accounts receivable | $ | 60,298 |  |
| Inventories | 3,235 |  |
| Other current assets | 19,272 |  |
| Total current assets | 82,805 |  |
| Property and equipment, net | 1,382 |  |
| Other assets | 70 |  |
| Intangibles | 100,500 |  |
| Goodwill | 250,330 |  |
| Total assets | $ | 435,087 |  |
| Current liabilities: |  |
| Accounts payable | $ | 17,226 |  |
| Other current liabilities | 57,075 |  |
| Total current liabilities | 74,301 |  |
| Other liabilities | 40,845 |  |
| Total aggregate purchase price | $ | 319,941 |  |

[0001628280-16-010628:notes:48]
The intangible assets of $100.5 million is comprised of customer relationships of $44.6 million and licenses and other intangible assets of $55.9 million. Customer relationships are amortized over a weighted-average estimated useful life of 5 years while licensed and other intangibles are amortized over a weighted-average estimated useful life of 6 years.

[0001628280-16-010628:notes:49]
[same as prior period, unchanged from 0001628280-15-007847:notes:43]

[0001628280-16-010628:notes:50]
Additionally, during the nine-month period ended December 31, 2015, the Company completed six acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company.  Three of the acquired businesses expanded the Company’s capabilities in the medical devices market, particularly precision plastics and molding within the HRS segment, two of them strengthened capabilities in the consumer electronics market within the CTG segment, and the last one strengthened capabilities in the household industrial and lifestyle market within the IEI segment. The Company paid $42.1 million, net of $0.7 million of cash held by the targets. The Company acquired $13.9 million of property and equipment, assumed liabilities of $27.3 million and recorded goodwill and intangibles of $39.6 million.

[0001628280-16-010628:notes:51]
The results of operations for each of the acquisitions completed in fiscal year 2016 were included in the Company’s consolidated financial results beginning on the date of each acquisition.  The total amount of net income for the acquisitions completed in fiscal year 2016, collectively, were $29.5 million and $34.4 million, for the three-month and nine-month periods ended December 31, 2015, respectively. The total amount of revenue of these acquisitions, collectively, was not material to the Company’s consolidated financial results for the three-month and nine-month periods ended December 31, 2015.

[0001628280-16-010628:notes:52]
On a pro-forma basis, and assuming the acquisitions occurred on the first day of the prior comparative period, or April 1, 2014, net income would have been estimated to be $116.6 million and $341.6 million for the three-month and nine-month periods ended December 31, 2015, respectively.  Pro-forma net income would have been estimated to be $146.9 million and $436.4 million for the three-month and nine-month periods ended December 31, 2014, respectively.  The estimated pro-forma net income for all periods presented does not include the $39.3 million tax benefit for the release of the valuation allowance on deferred tax assets relating to the NEXTracker acquisition, recognized in the three and nine-month period ended December 31, 2015 as discussed further in note 14, to promote comparability.  Pro-forma revenue for the acquisitions in fiscal year 2016 has not been presented because the effect, collectively, was not material to the Company’s consolidated revenues for all periods presented.

[0001628280-16-010628:notes:53]
[same as prior period, unchanged from 0001628280-15-007847:notes:46]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-16-010628:notes:54]
COMMITMENTS AND CONTINGENCIES

[0001628280-16-010628:notes:55]
Litigation and other legal matters

[0001628280-16-010628:notes:56]
During the fourth quarter of fiscal year 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010 for an alleged amount of 50 million Brazilian reals (approximately $12.8 million based on the exchange rate as of December 31, 2015) plus interest. This assessment is in the second stage of the review process at the administrative level, and the Company plans to continue to vigorously oppose it as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on these matters for several years.

[0001628280-16-010628:notes:57]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties. The Company believes there is no legal basis for the assessment and expects that any losses are remote. The Company plans to vigorously defend itself through the administrative and judicial processes.

[0001628280-16-010628:notes:58]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-16-010628:notes:59]
[same as prior period, unchanged from 0001628280-15-007847:notes:54]

[0001628280-16-010628:notes:60]
[same as prior period, unchanged from 0001628280-15-007847:notes:55]

[0001628280-16-010628:notes:61]
|  | Three-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (60,981 | ) |  | $ | (139,723 | ) |  | $ | (200,704 | ) |  | $ | (24,557 | ) |  | $ | (103,135 | ) |  | $ | (127,692 | ) |
| Other comprehensive gain (loss) before reclassifications | 5,941 |  |  | 9,224 |  |  | 15,165 |  |  | (29,287 | ) |  | (15,154 | ) |  | (44,441 | ) |
| Net losses reclassified from accumulated other comprehensive loss | 4,556 |  |  | 20,839 |  |  | 25,395 |  |  | 6,490 |  |  | — |  |  | 6,490 |  |
| Net current-period other comprehensive gain (loss) | 10,497 |  |  | 30,063 |  |  | 40,560 |  |  | (22,797 | ) |  | (15,154 | ) |  | (37,951 | ) |
| Ending balance | $ | (50,484 | ) |  | $ | (109,660 | ) |  | $ | (160,144 | ) |  | $ | (47,354 | ) |  | $ | (118,289 | ) |  | $ | (165,643 | ) |

[0001628280-16-010628:notes:62]
|  | Nine-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |  | $ | (32,849 | ) |  | $ | (93,307 | ) |  | $ | (126,156 | ) |
| Other comprehensive gain (loss) before reclassifications | (8,478 | ) |  | (18,412 | ) |  | (26,890 | ) |  | (31,252 | ) |  | (13,146 | ) |  | (44,398 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 26,260 |  |  | 20,991 |  |  | 47,251 |  |  | 16,747 |  |  | (11,836 | ) |  | 4,911 |  |
| Net current-period other comprehensive gain (loss) | 17,782 |  |  | 2,579 |  |  | 20,361 |  |  | (14,505 | ) |  | (24,982 | ) |  | (39,487 | ) |
| Ending balance | $ | (50,484 | ) |  | $ | (109,660 | ) |  | $ | (160,144 | ) |  | $ | (47,354 | ) |  | $ | (118,289 | ) |  | $ | (165,643 | ) |

[0001628280-16-010628:notes:63]
Net losses reclassified from accumulated other comprehensive loss during the nine-month period ended December 31, 2015 relating to derivative instruments and other includes $24.7 million attributable to the Company’s cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations. During the three-month ended December 31, 2015, the Company recognized a loss of $26.8 million in connection with the disposition of a non-strategic Western European manufacturing facility, which included a $25.3 million cumulative foreign currency translation loss. This loss was offset by the release of certain cumulative foreign currency translation gains of $4.2 million, which has been reclassified from accumulated other comprehensive loss during the period and is included in other charges (income), net in the condensed consolidated statement of operations.

[0001628280-16-010628:notes:64]
During the nine-month period ended December 31, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. This loss includes the settlement of unrealized losses of $4.2 million on an insignificant defined benefit plan associated with the disposed facility offset by the release of cumulative foreign currency translation gains of $9.3 million, both of which have been reclassified from accumulated other comprehensive loss during the period. The loss on sale is included in other charges (income), net in the condensed consolidated statement of operations.

[0001628280-16-010628:notes:65]
Additionally, net gains reclassified from accumulated other comprehensive loss during the nine-month period ended December 31, 2014 includes $2.6 million in connection with cumulative translation gains related to the liquidation of a foreign entity, which is included in other charges (income), net in the condensed consolidated statement of operations.

[0001628280-16-010628:notes:66]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month and nine-month periods ended December 31, 2014, was recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:DebtDisclosureTextBlock

[0001628280-16-010628:notes:67]
BANK BORROWINGS AND LONG TERM DEBT

[0001628280-16-010628:notes:68]
Bank borrowings and long-term debt are as follows:

[0001628280-16-010628:notes:69]
|  | As of December 31, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 585,000 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 555,000 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,494 |  |  | — |  |
| Other | 71,516 |  |  | 16,233 |  |
| Total | $ | 2,807,010 |  |  | $ | 2,083,733 |  |

[0001628280-16-010628:notes:70]
The weighted-average interest rates for the Company’s long-term debt were 3.4% and 3.2% as of December 31, 2015 and March 31, 2015, respectively.

[0001628280-16-010628:notes:71]
On June 8, 2015, the Company issued $600 million of 4.750% Notes ("Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at a discount of 99.213%, and an effective rate of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which will be used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.

[0001628280-16-010628:notes:72]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the Notes. The issuance costs were capitalized and will be amortized over the life of the Notes.

[0001628280-16-010628:notes:73]
Interest on the Notes is payable semi-annually, commencing on December 15, 2015. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Term Loan Agreement and Revolving Line of Credit.

[0001628280-16-010628:notes:74]
At any time prior to March 15, 2025, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0001628280-16-010628:notes:75]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of December 31, 2015, the Company was in compliance with the covenants in the indenture governing the Notes.

[0001628280-16-010628:notes:76]
On September 30, 2015, the Company amended its $2.0 billion credit facility to increase the $500 million term loan maturing in March 2019 by $100.0 million. Quarterly repayments of principal under this term loan were amended to $7.5 million up to March 31, 2016, and will be increased to $11.3 million thereafter with the remainder due upon maturity. All other terms remained unchanged.

[0001628280-16-010628:notes:77]
On October 1, 2015, the Company borrowed €50 million (approximately $54.6 million as of December 31, 2015), under a 5-year, unsecured, term-loan agreement due September 30, 2020. Borrowings under the term loan due September 30, 2020 bear interest at EURIBOR plus the applicable margin ranging between 0.80% and 2.00%, based on the Company’s credit ratings. The loan is repayable beginning December 30, 2016 in quarterly payments of €312,500 through June 30, 2020 with the remainder due upon maturity.  This loan is included in the "Other" category in the table above.

[0001628280-16-010628:notes:78]
This term loan agreement is unsecured, and is guaranteed by the Company.  This term contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2015, the Company was in compliance with the covenants under this term loan agreement.

[0001628280-16-010628:notes:79]
Repayment of the Company’s long term debt outstanding as of December 31, 2015 is as follows:

[0001628280-16-010628:notes:80]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 15,000 |  |
| 2017 | 60,669 |  |
| 2018 | 61,338 |  |
| 2019 | 1,006,338 |  |
| 2020 | 501,338 |  |
| Thereafter | 1,162,327 |  |
| Total | $ | 2,807,010 |  |

[0001628280-16-010628:notes:81]
____________________________________________________________

[0001628280-16-010628:notes:82]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2016. |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-16-010628:notes:83]
[same as prior period, unchanged from 0001628280-15-007847:notes:78]

[0001628280-16-010628:notes:84]
[same as prior period, unchanged from 0001628280-15-007847:notes:79]

[0001628280-16-010628:notes:85]
The Company primarily enters into forward contracts and foreign currency swap contracts to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions. The Company hedges committed exposures and does not engage in speculative transactions. As of December 31, 2015, the aggregate notional amount of the Company’s outstanding foreign currency contracts was $4.8 billion as summarized below:

[0001628280-16-010628:notes:86]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  |  |
| CNY |  | 1,200,000 |  |  | — |  |  | $ | 185,037 |  |  | $ | — |  |
| EUR |  | 7,620 |  |  | 84,326 |  |  | 8,310 |  |  | 94,578 |  |
| HUF |  | 13,942,000 |  |  | — |  |  | 48,497 |  |  | — |  |
| ILS |  | 101,200 |  |  | — |  |  | 25,952 |  |  | — |  |
| MXN |  | 1,500,000 |  |  | — |  |  | 87,165 |  |  | — |  |
| MYR |  | 176,000 |  |  | 38,364 |  |  | 41,040 |  |  | 8,946 |  |
| Other |  | N/A |  |  | N/A |  |  | 45,989 |  |  | — |  |
|  |  |  |  |  |  |  |  | 441,990 |  |  | 103,524 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 882,000 |  |  | — |  |  | 228,078 |  |
| CHF |  | 18,567 |  |  | 42,711 |  |  | 18,678 |  |  | 43,023 |  |
| CNY |  | 2,872,861 |  |  | 260,000 |  |  | 441,198 |  |  | 40,091 |  |
| DKK |  | 201,200 |  |  | 155,700 |  |  | 29,401 |  |  | 22,752 |  |
| EUR |  | 871,627 |  |  | 1,175,211 |  |  | 948,765 |  |  | 1,277,835 |  |
| GBP |  | 34,157 |  |  | 59,746 |  |  | 50,616 |  |  | 88,620 |  |
| HUF |  | 49,154,000 |  |  | 48,935,000 |  |  | 170,982 |  |  | 170,221 |  |
| INR |  | 2,100,628 |  |  | 106,646 |  |  | 31,502 |  |  | 1,600 |  |
| MXN |  | 1,905,960 |  |  | 818,430 |  |  | 110,756 |  |  | 47,559 |  |
| MYR |  | 377,341 |  |  | 78,800 |  |  | 87,989 |  |  | 18,375 |  |
| PLN |  | 97,018 |  |  | 52,401 |  |  | 25,011 |  |  | 13,509 |  |
| SEK |  | 675,375 |  |  | 999,944 |  |  | 79,732 |  |  | 117,772 |  |
| SGD |  | 42,071 |  |  | 9,360 |  |  | 29,745 |  |  | 6,618 |  |
| Other |  | N/A |  |  | N/A |  |  | 69,545 |  |  | 47,915 |  |
|  |  |  |  |  |  |  |  | 2,093,920 |  |  | 2,123,968 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  |  | $ | 2,535,910 |  |  | $ | 2,227,492 |  |

[0001628280-16-010628:notes:87]
As of December 31, 2015, the fair value of the Company’s short-term foreign currency contracts was not material and is included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of December 31, 2015 and March 31, 2015, the Company also has included net deferred losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to the effective portion of changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses were not material as of December 31, 2015, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0001628280-16-010628:notes:88]
[same as prior period, unchanged from 0001628280-15-007847:notes:83]

[0001628280-16-010628:notes:89]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31, 2015 |  | March 31, 2015 |  | Balance SheetLocation |  | December 31, 2015 |  | March 31, 2015 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 4,546 |  |  | $ | 2,896 |  |  | Other current liabilities |  | $ | 3,501 |  |  | $ | 19,729 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 16,689 |  |  | $ | 22,933 |  |  | Other current liabilities |  | $ | 20,153 |  |  | $ | 11,328 |  |

[0001628280-16-010628:notes:90]
[same as prior period, unchanged from 0001628280-15-007847:notes:85]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-010628:notes:91]
[same as prior period, unchanged from 0001628280-15-007847:notes:86]

[0001628280-16-010628:notes:92]
The Company's primary plan used for granting equity compensation awards is the 2010 Equity Incentive Plan (the "2010 Plan"). During the third quarter ended December 31, 2015, in conjunction with the acquisition of NEXTracker, the Company assumed all of the outstanding, unvested share bonus awards and outstanding, unvested options to purchase shares of common stock of NEXTracker, and converted all these shares into Flex awards. As a result, the Company offers an additional equity compensation plan as of December 31, 2015, the 2014 NEXTracker Equity Incentive Plan (the "NEXTracker Plan").

[0001628280-16-010628:notes:93]
[same as prior period, unchanged from 0001628280-15-007847:notes:87]

[0001628280-16-010628:notes:94]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Cost of sales | $ | 2,407 |  |  | $ | 2,083 |  |  | $ | 6,440 |  |  | $ | 5,562 |  |
| Selling, general and administrative expenses | 21,826 |  |  | 12,136 |  |  | 50,119 |  |  | 31,259 |  |
| Total share-based compensation expense | $ | 24,233 |  |  | $ | 14,219 |  |  | $ | 56,559 |  |  | $ | 36,821 |  |

[0001628280-16-010628:notes:95]
The 2010 Equity Incentive Plan

[0001628280-16-010628:notes:96]
Total unrecognized compensation expense related to share options under the 2010 Plan is not significant. As of December 31, 2015, the number of options outstanding and exercisable under the 2010 Plan was 4.2 million at a weighted-average exercise price of $6.58 per share and $6.57 per share, respectively.

[0001628280-16-010628:notes:97]
During the nine-month period ended December 31, 2015, the Company granted 6.4 million unvested share bonus awards under the 2010 Plan. Of this amount, approximately 5.5 million unvested share bonus awards have an average grant date price of $11.93 per share. Further, approximately 0.7 million of these unvested shares represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $14.96 per award and was calculated using a Monte Carlo simulation. The remaining 0.2 million of unvested shares bonus awards under the 2010 Plan have an average grant date price of $12.10 per share and represents the target amount of grants made to certain executive officers whereby vesting is contingent on meeting certain free cash flow targets. The number of shares under the 2010 Plan, contingent on market conditions that ultimately will vest range from zero up to a maximum of 1.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met. The number of shares under the 2010 Plan, contingent on free cash flow targets that ultimately will vest range from zero up to a maximum of 0.4 million of the target payment based on a measurement of cumulative three-year increase of free cash flow from operations of the Company, and will cliff vest after a period of three years.

[0001628280-16-010628:notes:98]
As of December 31, 2015, approximately 17.1 million unvested share bonus awards under the 2010 Plan were outstanding, of which vesting for a targeted amount of 3.6 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 7.2 million based on the achievement levels of the respective conditions. During the nine-month period ended December 31, 2015, 2.2 million shares under the 2010 Plan vested in connection with the share bonus awards with market conditions granted in fiscal year 2013, and 0.5 million shares under the 2010 Plan vested in connection with the share bonus awards with market conditions granted in fiscal year 2012.

[0001628280-16-010628:notes:99]
As of December 31, 2015, total unrecognized compensation expense related to unvested share bonus awards under the 2010 Plan is $110.3 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of 2.61 years. Approximately $16.7 million of the total unrecognized compensation cost, net of estimated forfeitures, is related to awards under the 2010 Plan whereby vesting is contingent on meeting certain market conditions.

[0001628280-16-010628:notes:100]
The 2014 NEXTracker Equity Incentive Plan

[0001628280-16-010628:notes:101]
During the third quarter ended December 31, 2015, the Company granted 2.7 million share options under the NEXTracker Plan, at an average grant date fair value price of $7.76 per share, and with a vesting period of two to four years from the vesting commencement date.

[0001628280-16-010628:notes:102]
Total unrecognized compensation expense related to share options under the NEXTracker Plan is $16.3 million, net of forfeitures, and will be recognized over a weighted-average remaining vesting period of 3.1 years. As of December 31, 2015, the number of options outstanding and exercisable was 2.5 million and 0.3 million, respectively, at a weighted-average exercise price of $3.90 per share and $2.84 per share, respectively.

[0001628280-16-010628:notes:103]
During the nine-month period ended December 31, 2015, the Company granted 2.9 million unvested share bonus awards under the NEXTracker Plan, at an average grant date fair value of $10.27 per share that vest over a period of two to three years from the vesting commencement date. Of this amount, approximately 1.4 million unvested shares bonus awards represents the target amount of grants made to certain NEXTracker employees whereby vesting is contingent on meeting certain performance targets over a three-year period commencing October 1, 2015.

[0001628280-16-010628:notes:104]
As of December 31, 2015, approximately 2.7 million unvested share bonus awards were outstanding.

[0001628280-16-010628:notes:105]
As of December 31, 2015, total unrecognized compensation expense related to unvested share bonus awards under the NEXTracker Plan is $24.4 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of 2.62 years.


## us-gaap:EarningsPerShareTextBlock

[0001628280-16-010628:notes:106]
[same as prior period, unchanged from 0001628280-15-007847:notes:94]

[0001628280-16-010628:notes:107]
[same as prior period, unchanged from 0001628280-15-007847:notes:95]

[0001628280-16-010628:notes:108]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands, except per share amounts) |
| Net income | $ | 148,910 |  |  | $ | 152,899 |  |  | $ | 382,737 |  |  | $ | 465,689 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 554,919 |  |  | 577,157 |  |  | 561,070 |  |  | 583,383 |  |
| Basic earnings per share | 0.27 |  |  | 0.26 |  |  | 0.68 |  |  | 0.80 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 148,910 |  |  | $ | 152,899 |  |  | $ | 382,737 |  |  | $ | 465,689 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 554,919 |  |  | 577,157 |  |  | 561,070 |  |  | 583,383 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) | 6,077 |  |  | 10,044 |  |  | 7,856 |  |  | 11,408 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 560,996 |  |  | 587,201 |  |  | 568,926 |  |  | 594,791 |  |
| Diluted earnings per share | 0.27 |  |  | 0.26 |  |  | 0.67 |  |  | 0.78 |  |

[0001628280-16-010628:notes:109]
(1)         Options to purchase ordinary shares of 2.1 million and 9.4 million during the three-month periods ended December 31, 2015 and December 31, 2014, respectively, and share bonus awards of 0.1 million and 0.2 million for the three-month periods ended December 31, 2015 and December 31, 2014, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.

[0001628280-16-010628:notes:110]
(2)         Options to purchase ordinary shares of 1.2 million and 11.2 million during the nine-month periods ended December 31, 2015 and December 31, 2014, respectively, and share bonus awards of 3.5 million and 0.1 million for the nine-month periods ended December 31, 2015 and December 31, 2014, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-16-010628:notes:111]
[same as prior period, unchanged from 0001628280-15-007847:notes:99]

[0001628280-16-010628:notes:112]
[same as prior period, unchanged from 0001628280-15-007847:notes:100]

[0001628280-16-010628:notes:113]
[same as prior period, unchanged from 0001628280-15-007847:notes:101]

[0001628280-16-010628:notes:114]
[same as prior period, unchanged from 0001628280-15-007847:notes:102]

[0001628280-16-010628:notes:115]
[same as prior period, unchanged from 0001628280-15-007847:notes:103]

[0001628280-16-010628:notes:116]
[same as prior period, unchanged from 0001628280-15-007847:notes:104]

[0001628280-16-010628:notes:117]
[same as prior period, unchanged from 0001628280-15-007847:notes:105]

[0001628280-16-010628:notes:118]
[same as prior period, unchanged from 0001628280-15-007847:notes:106]

[0001628280-16-010628:notes:119]
[same as prior period, unchanged from 0001628280-15-007847:notes:107]

[0001628280-16-010628:notes:120]
The Company has accrued for contingent consideration in connection with its business acquisitions, which is measured at fair value based on certain internal models and unobservable inputs.

[0001628280-16-010628:notes:121]
The Company accrued $81.0 million of contingent consideration related to the acquisition of NEXTracker on the date of acquisition. Additionally, an incremental fair value adjustment of $4.0 million related to this acquisition, was recorded during the three-month and nine-month periods ended December 31, 2015. The fair value of the liability was estimated using a simulation-based measurement technique with significant inputs that are not observable in the market and thus represents a level 3 fair value measurement. The significant inputs in the fair value measurement not supported by market activity included the Company's probability assessments of expected future revenue during the earn-out period and associated volatility, appropriately discounted considering the uncertainties associated with the obligation, and calculated in accordance with the terms of the Merger Agreement. Significant decreases in expected revenue during the earn-out period, or significant increases in the discount rate or volatility in isolation would result in lower fair value estimates. The interrelationship between these inputs is not considered significant.

[0001628280-16-010628:notes:122]
During the three-month period ended December 31, 2014, the Company paid $7.4 million of contingent consideration related to the acquisition of Saturn Electronics and Engineering Inc., included as other financing activities in the statement of cash flows for the nine-month period ended December 31, 2014.

[0001628280-16-010628:notes:123]
The following table summarizes the activities related to contingent consideration:

[0001628280-16-010628:notes:124]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Beginning balance | $ | 4,500 |  |  | $ | 15,800 |  |  | $ | 4,500 |  |  | $ | 11,300 |  |
| Additions to accrual | 81,000 |  |  | — |  |  | 81,000 |  |  | 4,500 |  |
| Payments | — |  |  | (7,398 | ) |  | — |  |  | (7,398 | ) |
| Fair value adjustments | 4,000 |  |  | — |  |  | 4,000 |  |  | — |  |
| Ending balance | $ | 89,500 |  |  | $ | 8,402 |  |  | $ | 89,500 |  |  | $ | 8,402 |  |

[0001628280-16-010628:notes:125]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not meaningful. The interrelationship between these inputs is also insignificant. Refer to note 10 for a reconciliation of the change in the deferred purchase price receivable during the three-month and nine-month periods ended December 31, 2015 and December 31, 2014.

[0001628280-16-010628:notes:126]
There were no transfers between levels in the fair value hierarchy during the three-month and nine-month periods ended December 31, 2015 and December 31, 2014.

[0001628280-16-010628:notes:127]
[same as prior period, unchanged from 0001628280-15-007847:notes:112]

[0001628280-16-010628:notes:128]
[same as prior period, unchanged from 0001628280-15-007847:notes:113]

[0001628280-16-010628:notes:129]
|  | Fair Value Measurements as of December 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 939,564 |  |  | $ | — |  |  | $ | 939,564 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 534,695 |  |  | 534,695 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 21,235 |  |  | — |  |  | 21,235 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 8,655 |  |  | 40,927 |  |  | — |  |  | 49,582 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (23,654 | ) |  | $ | — |  |  | $ | (23,654 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (89,500 | ) |  | (89,500 | ) |
|  | Fair Value Measurements as of March 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 674,859 |  |  | $ | — |  |  | $ | 674,859 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 600,672 |  |  | 600,672 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 25,829 |  |  | — |  |  | 25,829 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 9,068 |  |  | 37,041 |  |  | — |  |  | 46,109 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (31,057 | ) |  | $ | — |  |  | $ | (31,057 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (4,500 | ) |  | (4,500 | ) |

[0001628280-16-010628:notes:130]
[same as prior period, unchanged from 0001628280-15-007847:notes:115]

[0001628280-16-010628:notes:131]
[same as prior period, unchanged from 0001628280-15-007847:notes:116]

[0001628280-16-010628:notes:132]
|  | As of December 31, 2015 |  | As of March 31, 2015 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 585,000 |  |  | $ | 580,250 |  |  | $ | 592,500 |  |  | $ | 582,131 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 555,000 |  |  | 549,800 |  |  | 475,000 |  |  | 465,500 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 531,053 |  |  | 500,000 |  |  | 523,750 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 514,430 |  |  | 500,000 |  |  | 543,150 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,494 |  |  | 599,940 |  |  | — |  |  | — |  |  | Level 1 |
| Total | $ | 2,735,494 |  |  | $ | 2,775,473 |  |  | $ | 2,067,500 |  |  | $ | 2,114,531 |  |  |  |

[0001628280-16-010628:notes:133]
[same as prior period, unchanged from 0001628280-15-007847:notes:118]

[0001628280-16-010628:notes:134]
The Company values its €50 million (approximately $54.6 million as of December 31, 2015), 5-year, unsecured, term-loan due September 30, 2020 based on the current market rate, and as of December 31, 2015, the carrying amount approximates fair value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-010628:notes:135]
INCOME TAXES

[0001628280-16-010628:notes:136]
During the three-month and nine-month periods ended December 31, 2015, the Company released $39.3 million of a previously established valuation allowance on deferred tax assets because of its recognition of $39.3 million in net deferred tax liabilities in connection with the NEXTracker acquisition.

[0001628280-16-010628:notes:137]
In addition, during the nine-month period ended December 31, 2015, the Company released $37.2 million of liabilities for uncertain tax positions due to settlements, foreign exchanges and lapses of statutes of limitations in various jurisdictions.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-16-010628:notes:138]
[same as prior period, unchanged from 0001628280-15-007847:notes:119]

[0001628280-16-010628:notes:139]
[same as prior period, unchanged from 0001628280-15-007847:notes:120]

[0001628280-16-010628:notes:140]
Flextronics International Ltd. ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following reportable segments: High Reliability Solutions ("HRS"), which is comprised of medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group ("CTG"), which includes mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics, digital health, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computing, tablets, and printers; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions ("INS"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001628280-16-010628:notes:141]
[same as prior period, unchanged from 0001628280-15-007847:notes:122]

[0001628280-16-010628:notes:142]
[same as prior period, unchanged from 0001628280-15-007847:notes:123]

[0001628280-16-010628:notes:143]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2015 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and nine-month periods ended December 31, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016.

[0001628280-16-010628:notes:144]
The first quarters for fiscal year 2016 and fiscal year 2015 ended on June 26, 2015 and June 27, 2014, respectively. The second quarters for fiscal year 2016 and fiscal year 2015 ended on September 25, 2015 and September 26, 2014, respectively. The Company's third quarters end on December 31 of each year.

[0001628280-16-010628:notes:145]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority-owned subsidiary of the Company. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The operating results of the subsidiary attributable to the noncontrolling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

[0001628280-16-010628:notes:146]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting.  The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has an ownership percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%.  The equity in earnings (losses) of equity method investees are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

[0001628280-16-010628:notes:147]
[same as prior period, unchanged from 0001628280-15-007847:notes:127]

[0001628280-16-010628:notes:148]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued new guidance to eliminate the requirement for companies to separate deferred income tax liabilities and assets into current and noncurrent amounts on the balance sheet. Instead, companies will be required to classify all deferred tax liabilities and assets as noncurrent. The Company has elected to early adopt this new guidance during the third quarter of fiscal year 2016 on a prospective basis as permitted under the standard, resulting in the reclassification of $66.3 million of deferred income tax assets and $9.1 million of deferred income tax liabilities from current into noncurrent as of December 31, 2015. Prior periods were not retrospectively adjusted.

[0001628280-16-010628:notes:149]
In September 2015, the FASB issued new guidance to simplify the accounting for adjustments made to provisional amounts recognized in a business combination.  Under previous guidance, the acquirer retrospectively adjusted the provisional amounts recognized at the acquisition date with a corresponding adjustment to goodwill, and would have to revise comparative information for prior periods presented in financial statements as needed. The update requires an entity to present separately on the face of the income statement or disclose in the notes the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. The Company has elected to early adopt this new guidance which is effective for the Company beginning the third quarter of fiscal year 2016.

[0001628280-16-010628:notes:150]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018, with early application permitted as of the beginning of an interim or annual reporting period. The Company is currently assessing the impact of this update and the timing of adoption.

[0001628280-16-010628:notes:151]
[same as prior period, unchanged from 0001628280-15-007847:notes:130]


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001628280-16-010628:notes:152]
[same as prior period, unchanged from 0001628280-15-007847:notes:131]

[0001628280-16-010628:notes:153]
The Company incurred expenses of $44.4 million and $46.3 million during the three-month and nine-month periods ended December 31, 2015, respectively, primarily due to $26.8 million loss on disposition of a non-strategic Western European manufacturing facility, which included a non-cash foreign currency translation loss of $25.3 million, and $21.8 million from the impairment of a non-core investment. These were offset by currency translation gains of $4.2 million.

[0001628280-16-010628:notes:154]
During the nine-month period ended December 31, 2014, an amendment to a customer contract to reimburse a customer for certain performance provisions was executed which included the removal of a $55.0 million contractual obligation recognized during fiscal year 2014. Accordingly, the Company reversed the charge recognized in fiscal year 2014 with a corresponding credit to other charges (income), net in the consolidated statement of operations.

[0001628280-16-010628:notes:155]
Further, during the nine-month period ended December 31, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. The Company received $11.5 million in cash for the sale of $27.2 million in net assets of the facility. The loss also includes $4.6 million of transaction costs, partially offset by a credit of $9.3 million for the release of cumulative foreign translation gains triggered by the disposition.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-16-010628:notes:156]
[same as prior period, unchanged from 0001628280-15-007847:notes:135]

[0001628280-16-010628:notes:157]
|  | As of December 31, 2015 |  | As of March 31, 2015 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 258,079 |  |  | $ | (102,202 | ) |  | $ | 155,877 |  |  | $ | 133,853 |  |  | $ | (80,506 | ) |  | $ | 53,347 |  |
| Licenses and other intangibles | 275,322 |  |  | (30,416 | ) |  | 244,906 |  |  | 39,985 |  |  | (11,788 | ) |  | 28,197 |  |
| Total | $ | 533,401 |  |  | $ | (132,618 | ) |  | $ | 400,783 |  |  | $ | 173,838 |  |  | $ | (92,294 | ) |  | $ | 81,544 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001628280-16-010628:notes:158]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the nine-month period ended December 31, 2015:

[0001628280-16-010628:notes:159]
|  |  | HRS |  | CTG |  | IEI |  | INS |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year |  | $ | 93,138 |  |  | $ | 68,234 |  |  | $ | 64,221 |  |  | $ | 108,038 |  |  | $ | 333,631 |  |
| Additions (1) |  | 330,346 |  |  | — |  |  | 253,312 |  |  | 3,575 |  |  | 587,233 |  |
| Purchase accounting adjustments (2) |  | 125 |  |  | — |  |  | — |  |  | — |  |  | 125 |  |
| Foreign currency translation adjustments |  | (4,755 | ) |  | — |  |  | — |  |  | — |  |  | (4,755 | ) |
| Balance, end of the period |  | $ | 418,854 |  |  | $ | 68,234 |  |  | $ | 317,533 |  |  | $ | 111,613 |  |  | $ | 916,234 |  |

[0001628280-16-010628:notes:160]
| (1) | The goodwill generated from the Company’s business combinations completed during the nine-month period ended December 31, 2015 is primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired businesses. The goodwill is not deductible for income tax purposes. See note 12 for additional information. |

[0001628280-16-010628:notes:161]
| (2) | Includes adjustments to estimates resulting from the finalization of management's review of the valuation of assets acquired and liabilities assumed through certain business combinations completed in a period subsequent to the respective acquisition. These adjustments were not individually, nor in the aggregate, significant to the Company. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-16-010628:notes:162]
[same as prior period, unchanged from 0001628280-15-007847:notes:141]

[0001628280-16-010628:notes:163]
|  | As of December 31, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Raw materials | $ | 2,266,843 |  |  | $ | 2,330,428 |  |
| Work-in-progress | 553,686 |  |  | 557,786 |  |
| Finished goods | 670,204 |  |  | 600,538 |  |
|  | $ | 3,490,733 |  |  | $ | 3,488,752 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0001628280-16-010628:notes:164]
The financial results of NEXTracker were included in the IEI segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition and is subject to change as the Company finalizes the valuation of the intangible assets acquired. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-16-010628:notes:165]
[same as prior period, unchanged from 0001628280-15-007847:notes:143]

[0001628280-16-010628:notes:166]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| Integrated Network Solutions | $ | 2,469,099 |  |  | $ | 2,358,199 |  |  | $ | 6,640,626 |  |  | $ | 7,139,333 |  |
| Consumer Technology Group | 2,057,850 |  |  | 2,647,229 |  |  | 5,633,903 |  |  | 7,078,912 |  |
| Industrial & Emerging Industries | 1,214,225 |  |  | 1,105,992 |  |  | 3,490,205 |  |  | 3,327,660 |  |
| High Reliability Solutions | 1,022,003 |  |  | 913,634 |  |  | 2,881,453 |  |  | 2,650,411 |  |
|  | $ | 6,763,177 |  |  | $ | 7,025,054 |  |  | $ | 18,646,187 |  |  | $ | 20,196,316 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Integrated Network Solutions | $ | 75,578 |  |  | $ | 72,654 |  |  | $ | 198,400 |  |  | $ | 203,008 |  |
| Consumer Technology Group | 49,032 |  |  | 73,200 |  |  | 129,045 |  |  | 156,401 |  |
| Industrial & Emerging Industries | 49,230 |  |  | 21,730 |  |  | 110,498 |  |  | 104,636 |  |
| High Reliability Solutions | 82,806 |  |  | 56,124 |  |  | 213,890 |  |  | 159,068 |  |
| Corporate and Other | (20,563 | ) |  | (16,825 | ) |  | (60,348 | ) |  | (49,629 | ) |
| Total segment income | 236,083 |  |  | 206,883 |  |  | 591,485 |  |  | 573,484 |  |
| Reconciling items: |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 19,319 |  |  | 8,045 |  |  | 43,117 |  |  | 23,228 |  |
| Stock-based compensation | 24,233 |  |  | 14,219 |  |  | 56,559 |  |  | 36,821 |  |
| Other charges (income), net | 44,415 |  |  | 5,067 |  |  | 46,257 |  |  | (41,526 | ) |
| Interest and other, net | 21,566 |  |  | 9,035 |  |  | 60,106 |  |  | 40,178 |  |
| Income before income taxes | $ | 126,550 |  |  | $ | 170,517 |  |  | $ | 385,446 |  |  | $ | 514,783 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001628280-16-010628:notes:167]
[same as prior period, unchanged from 0001628280-15-007847:notes:145]

[0001628280-16-010628:notes:168]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 21,198 |  |
| 2017 | 71,986 |  |
| 2018 | 57,887 |  |
| 2019 | 51,556 |  |
| 2020 | 43,315 |  |
| Thereafter | 154,841 |  |
| Total amortization expense | $ | 400,783 |  |

[0001628280-16-010628:notes:169]
| (1) | Represents estimated amortization for the remaining three-month period ending March 31, 2016. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-010628:notes:170]
[same as prior period, unchanged from 0001628280-15-007847:notes:148]

[0001628280-16-010628:notes:171]
[same as prior period, unchanged from 0001628280-15-007847:notes:149]

[0001628280-16-010628:notes:172]
[same as prior period, unchanged from 0001628280-15-007847:notes:150]

[0001628280-16-010628:notes:173]
[same as prior period, unchanged from 0001628280-15-007847:notes:151]

[0001628280-16-010628:notes:174]
[same as prior period, unchanged from 0001628280-15-007847:notes:152]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-16-010628:notes:175]
[same as prior period, unchanged from 0001628280-15-007847:notes:153]

[0001628280-16-010628:notes:176]
[same as prior period, unchanged from 0001628280-15-007847:notes:154]

[0001628280-16-010628:notes:177]
[same as prior period, unchanged from 0001628280-15-007847:notes:155]

[0001628280-16-010628:notes:178]
The gross carrying amounts of intangible assets are removed when the recorded amounts have been fully amortized.  During the nine-month period ended December 31, 2015, the total value of intangible assets increased primarily in connection with the Company's acquisition of Mirror Controls International ("MCi") and NEXTracker Inc. ("NEXTracker"). The MCi acquisition contributed an additional $75.5 million in customer-related intangible assets, and $161.3 million in licenses and other intangible assets, and the NEXTracker acquisition contributed an additional $44.6 million in customer-related intangible assets and $55.9 million in licenses and other intangible assets. The assumptions used in the measurement of the intangible assets for the NEXTracker acquisition are subject to change upon the finalization of the valuation in the Company's fourth quarter ended March 31, 2016. See note 12 for additional information. The estimated future annual amortization expense for intangible assets is as follows:

[0001628280-16-010628:notes:179]
[same as prior period, unchanged from 0001628280-15-007847:notes:157]

[0001628280-16-010628:notes:180]
Other current assets includes approximately $534.7 million and $600.7 million as of December 31, 2015 and March 31, 2015, respectively, for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0001628280-16-010628:notes:181]
[same as prior period, unchanged from 0001628280-15-007847:notes:159]

[0001628280-16-010628:notes:182]
During fiscal year 2015, the Company ceased manufacturing of the product related to the financed equipment.  As a result, the Company as an agent on behalf of the customer is in the process of dispositioning the equipment and forwarding the proceeds to the third party banking institution reducing the outstanding obligation. Included in other current assets is the value of the certain assets purchased on behalf of a customer and financed by a third party banking institution in the amounts of $83.7 million and $169.2 million as of December 31, 2015 and March 31, 2015, respectively.  Additionally, other current assets as of December 31, 2015 includes an amount of $56.1 million relating to these assets that have been sold to third parties but not yet collected.

[0001628280-16-010628:notes:183]
During the nine-month period ended December 31, 2015, the Company disposed of all of the assets and the remaining amount of $83.7 million reflects the shortfall between the original purchase price of these assets and the amount recovered by selling them to third parties. The Company expects this amount to be funded by the customer, which in turn would be paid back to the third party banking institution.

[0001628280-16-010628:notes:184]
Subsequent to December 31, 2015, the Company agreed in principle to accept a return of previously shipped inventory from a customer of approximately $100.0 million. The inventory to be returned has been classified within other current assets, rather than inventory, as title had not transferred to the Company as of the end of the quarter. The revenue of approximately $17.9 million and cost of sales related to the return that had been recognized in prior periods was reversed in the quarter ended December 31, 2015. The Company believes the remaining uncollected amount as of December 31, 2015 from this customer is recoverable.

[0001628280-16-010628:notes:185]
[same as prior period, unchanged from 0001628280-15-007847:notes:162]

[0001628280-16-010628:notes:186]
Other current liabilities includes customer working capital advances of $181.7 million and $189.6 million, customer-related accruals of $472.6 million and $454.8 million, and deferred revenue of $329.4 million and $272.6 million as of December 31, 2015 and March 31, 2015, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Other current liabilities also includes the outstanding balance due to the third party banking institution related to the financed equipment discussed above of $149.4 million and $197.7 million as of December 31, 2015 and March 31, 2015, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001628280-16-010628:notes:187]
[same as prior period, unchanged from 0001628280-15-007847:notes:164]

[0001628280-16-010628:notes:188]
[same as prior period, unchanged from 0001628280-15-007847:notes:165]

[0001628280-16-010628:notes:189]
[same as prior period, unchanged from 0001628280-15-007847:notes:166]

[0001628280-16-010628:notes:190]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $761.0 million for the Global Program, of which $600.0 million is committed and $161.0 million is uncommitted, and $265.0 million for the North American Program, of which $225.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001628280-16-010628:notes:191]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month and nine-month periods ended December 31, 2015 and December 31, 2014 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0001628280-16-010628:notes:192]
As of December 31, 2015, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $971.3 million and deferred purchase price receivables of approximately $534.7 million. As of March 31, 2015, approximately $1.3 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $740.7 million and deferred purchase price receivables of approximately $600.7 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of December 31, 2015 and March 31, 2015, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0001628280-16-010628:notes:193]
As of December 31, 2015 and March 31, 2015, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0001628280-16-010628:notes:194]
For the nine-month periods ended December 31, 2015 and December 31, 2014, cash flows from sales of receivables under the ABS Programs consisted of approximately $3.9 billion and $3.3 billion, for transfers of receivables, respectively (of which approximately $355.1 million and $204.6 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0001628280-16-010628:notes:195]
[same as prior period, unchanged from 0001628280-15-007847:notes:172]

[0001628280-16-010628:notes:196]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $257.3 million and $485.6 million as of December 31, 2015 and March 31, 2015, respectively. For the nine-month periods ended December 31, 2015 and December 31, 2014, total accounts receivable sold to certain third party banking institutions was approximately $1.8 billion and $3.4 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0001628280-16-010628:notes:197]
[same as prior period, unchanged from 0001628280-15-007847:notes:174]

[0001628280-16-010628:notes:198]
During the three-month and nine-month periods ended December 31, 2015, the Company repurchased 8.5 million shares at an aggregate purchase price of $94.0 million, and 29.0 million shares at an aggregate purchase price of $326.4 million, respectively, and retired all of these shares.

[0001628280-16-010628:notes:199]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Extraordinary General Meeting held on August 20, 2015. As of December 31, 2015, shares in the aggregate amount of $328.5 million were available to be repurchased under the current plan.
