# FLEX note change history — 0001628280-15-007847 → 0001628280-16-010628


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001628280-16-010628:note_history:1]
During the fourth quarter of fiscal year 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010 for an alleged amount of 50 million Brazilian reals (approximately $12.8 million based on the exchange rate as of December 31, 2015) plus interest. This assessment is in the second stage of the review process at the administrative level, and the Company plans to continue to vigorously oppose it as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on these matters for several years.
  (was, 2015-10-26, similarity 0.9969):
[0001628280-15-007847:note_history:1]
During the fourth quarter of fiscal year 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010 for an alleged amount of 50 million Brazilian reals (approximately $12 million based on the exchange rate as of September 25, 2015) plus interest. This assessment is in the second stage of the review process at the administrative level, and the Company plans to continue to vigorously oppose it as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on these matters for several years.

- removed (2016-02-01):
[0001628280-15-007847:note_history:2]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431). The complaint asserted various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products. The plaintiff sought an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys' fees and costs. The parties settled this action in August 2015 and it has been dismissed; the terms of the settlement were not material to the Company’s financial statements as a whole.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001628280-16-010628:note_history:3]
Flextronics International Ltd. ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following reportable segments: High Reliability Solutions ("HRS"), which is comprised of medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group ("CTG"), which includes mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics, digital health, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computing, tablets, and printers; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions ("INS"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.
  (was, 2015-10-26, similarity 0.9992):
[0001628280-15-007847:note_history:3]
Flextronics International Ltd. ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following reportable segments: High Reliability Solutions ("HRS"), which is comprised of medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group ("CTG"), which includes mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics, digital health, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computing, tablets, and printers; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions ("INS"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables our OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

- changed (2016-02-01):
[0001628280-16-010628:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2015 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and nine-month periods ended December 31, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016.
  (was, 2015-10-26, similarity 0.9928):
[0001628280-15-007847:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2015 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and six-month periods ended September 25, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016.

- changed (2016-02-01):
[0001628280-16-010628:note_history:5]
The first quarters for fiscal year 2016 and fiscal year 2015 ended on June 26, 2015 and June 27, 2014, respectively. The second quarters for fiscal year 2016 and fiscal year 2015 ended on September 25, 2015 and September 26, 2014, respectively. The Company's third quarters end on December 31 of each year.
  (was, 2015-10-26, similarity 0.8732):
[0001628280-15-007847:note_history:5]
The first quarters for fiscal year 2016 and fiscal year 2015 ended on June 26, 2015 and June 27, 2014, respectively. The second quarters for fiscal year 2016 and fiscal year 2015 ended on September 25, 2015 and September 26, 2014, respectively.

- changed (2016-02-01):
[0001628280-16-010628:note_history:6]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority-owned subsidiary of the Company. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The operating results of the subsidiary attributable to the noncontrolling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.
  (was, 2015-10-26, similarity 0.9636):
[0001628280-15-007847:note_history:6]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority-owned subsidiary of the Company. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The operating results of the subsidiary attributable to the noncontrolling interests are immaterial for all of the periods presented, and are included in other charges (income), net in the condensed consolidated statements of operations.

- added (2016-02-01):
[0001628280-16-010628:note_history:7]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting.  The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has an ownership percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%.  The equity in earnings (losses) of equity method investees are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- added (2016-02-01):
[0001628280-16-010628:note_history:8]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued new guidance to eliminate the requirement for companies to separate deferred income tax liabilities and assets into current and noncurrent amounts on the balance sheet. Instead, companies will be required to classify all deferred tax liabilities and assets as noncurrent. The Company has elected to early adopt this new guidance during the third quarter of fiscal year 2016 on a prospective basis as permitted under the standard, resulting in the reclassification of $66.3 million of deferred income tax assets and $9.1 million of deferred income tax liabilities from current into noncurrent as of December 31, 2015. Prior periods were not retrospectively adjusted.

- changed (2016-02-01):
[0001628280-16-010628:note_history:9]
In September 2015, the FASB issued new guidance to simplify the accounting for adjustments made to provisional amounts recognized in a business combination.  Under previous guidance, the acquirer retrospectively adjusted the provisional amounts recognized at the acquisition date with a corresponding adjustment to goodwill, and would have to revise comparative information for prior periods presented in financial statements as needed. The update requires an entity to present separately on the face of the income statement or disclose in the notes the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. The Company has elected to early adopt this new guidance which is effective for the Company beginning the third quarter of fiscal year 2016.
  (was, 2015-10-26, similarity 0.823):
[0001628280-15-007847:note_history:9]
In September 2015, the Financial Accounting Standards Board (“FASB”) issued new guidance to simplify the accounting for adjustments made to provisional amounts recognized in a business combination.  Under previous guidance, the acquirer retrospectively adjusted the provisional amounts recognized at the acquisition date with a corresponding adjustment to goodwill, and would have to revise comparative information for prior periods presented in financial statements as needed. The update requires an entity to present separately on the face of the income statement or disclose in the notes the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. The new guidance is effective for the Company beginning fiscal year 2017, with early application permitted. The Company is currently assessing the impact of this update and the timing of adoption.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001628280-16-010628:note_history:10]
|  | As of December 31, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 585,000 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 555,000 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,494 |  |  | — |  |
| Other | 71,516 |  |  | 16,233 |  |
| Total | $ | 2,807,010 |  |  | $ | 2,083,733 |  |
  (was, 2015-10-26, similarity 0.992):
[0001628280-15-007847:note_history:10]
|  | As of September 25, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 588,750 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 468,750 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,402 |  |  | — |  |
| Other | 13,248 |  |  | 16,233 |  |
| Total | $ | 2,666,150 |  |  | $ | 2,083,733 |  |

- changed (2016-02-01):
[0001628280-16-010628:note_history:11]
The weighted-average interest rates for the Company’s long-term debt were 3.4% and 3.2% as of December 31, 2015 and March 31, 2015, respectively.
  (was, 2015-10-26, similarity 0.9732):
[0001628280-15-007847:note_history:11]
The weighted-average interest rates for the Company’s long-term debt were 3.5% and 3.2% as of September 25, 2015 and March 31, 2015, respectively,

- changed (2016-02-01):
[0001628280-16-010628:note_history:12]
On June 8, 2015, the Company issued $600 million of 4.750% Notes ("Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at a discount of 99.213%, and an effective rate of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which will be used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.
  (was, 2015-10-26, similarity 0.7902):
[0001628280-15-007847:note_history:12]
On June 8, 2015, the Company issued $600 million of 4.750% Notes ("Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at a discount of 99.213%, and an effective rate of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which will be used for general corporate purposes.

- changed (2016-02-01):
[0001628280-16-010628:note_history:13]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of December 31, 2015, the Company was in compliance with the covenants in the indenture governing the Notes.
  (was, 2015-10-26, similarity 0.9976):
[0001628280-15-007847:note_history:13]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of September 25, 2015, the Company was in compliance with the covenants in the indenture governing the Notes.

- added (2016-02-01):
[0001628280-16-010628:note_history:14]
On September 30, 2015, the Company amended its $2.0 billion credit facility to increase the $500 million term loan maturing in March 2019 by $100.0 million. Quarterly repayments of principal under this term loan were amended to $7.5 million up to March 31, 2016, and will be increased to $11.3 million thereafter with the remainder due upon maturity. All other terms remained unchanged.

- added (2016-02-01):
[0001628280-16-010628:note_history:15]
On October 1, 2015, the Company borrowed €50 million (approximately $54.6 million as of December 31, 2015), under a 5-year, unsecured, term-loan agreement due September 30, 2020. Borrowings under the term loan due September 30, 2020 bear interest at EURIBOR plus the applicable margin ranging between 0.80% and 2.00%, based on the Company’s credit ratings. The loan is repayable beginning December 30, 2016 in quarterly payments of €312,500 through June 30, 2020 with the remainder due upon maturity.  This loan is included in the "Other" category in the table above.

- added (2016-02-01):
[0001628280-16-010628:note_history:16]
This term loan agreement is unsecured, and is guaranteed by the Company.  This term contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2015, the Company was in compliance with the covenants under this term loan agreement.

- changed (2016-02-01):
[0001628280-16-010628:note_history:17]
Repayment of the Company’s long term debt outstanding as of December 31, 2015 is as follows:
  (was, 2015-10-26, similarity 0.9714):
[0001628280-15-007847:note_history:17]
Repayment of the Company’s long term debt outstanding as of September 25, 2015 is as follows:

- changed (2016-02-01):
[0001628280-16-010628:note_history:18]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2016. |
  (was, 2015-10-26, similarity 0.957):
[0001628280-15-007847:note_history:18]
| (1) | Represents scheduled repayment for the remaining six-month period ending March 31, 2016. |

- removed (2016-02-01):
[0001628280-15-007847:note_history:19]
In connection with the issuance of the Notes, the Company entered into a registration rights agreement under which it has agreed to consummate an offer registered with the Securities and Exchange Commission to issue new notes having terms substantially identical to the Notes (except that the new notes will not be subject to restrictions on transfer) in exchange for outstanding Notes. In some circumstances, the Company may be required to file a shelf registration statement to cover resale of the Notes. If the Company fails to satisfy these obligations, the Company may be required to pay additional interest to holders of the Notes under certain circumstances.

- removed (2016-02-01):
[0001628280-15-007847:note_history:20]
On September 30, 2015, the Company amended its $2.0 billion credit facility to increase the $500 million term loan maturing in March 2019 by an additional borrowing of $100.0 million. All other terms remained unchanged.

- removed (2016-02-01):
[0001628280-15-007847:note_history:21]
On October 1, 2015, the Company entered into a €50 million (approximately $56.0 million as of September 25, 2015), 5-year, unsecured, term-loan agreement due September 30, 2020.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001628280-16-010628:note_history:22]
|  | As of December 31, 2015 |  | As of March 31, 2015 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 585,000 |  |  | $ | 580,250 |  |  | $ | 592,500 |  |  | $ | 582,131 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 555,000 |  |  | 549,800 |  |  | 475,000 |  |  | 465,500 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 531,053 |  |  | 500,000 |  |  | 523,750 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 514,430 |  |  | 500,000 |  |  | 543,150 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,494 |  |  | 599,940 |  |  | — |  |  | — |  |  | Level 1 |
| Total | $ | 2,735,494 |  |  | $ | 2,775,473 |  |  | $ | 2,067,500 |  |  | $ | 2,114,531 |  |  |  |
  (was, 2015-10-26, similarity 0.9949):
[0001628280-15-007847:note_history:22]
|  | As of September 25, 2015 |  | As of March 31, 2015 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 588,750 |  |  | $ | 586,177 |  |  | $ | 592,500 |  |  | $ | 582,131 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 468,750 |  |  | 466,992 |  |  | 475,000 |  |  | 465,500 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 520,625 |  |  | 500,000 |  |  | 523,750 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 502,750 |  |  | 500,000 |  |  | 543,150 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,402 |  |  | 585,000 |  |  | — |  |  | — |  |  | Level 1 |
| Total | $ | 2,652,902 |  |  | $ | 2,661,544 |  |  | $ | 2,067,500 |  |  | $ | 2,114,531 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001628280-16-010628:note_history:23]
|  | As of December 31, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 585,000 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 555,000 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,494 |  |  | — |  |
| Other | 71,516 |  |  | 16,233 |  |
| Total | $ | 2,807,010 |  |  | $ | 2,083,733 |  |
  (was, 2015-10-26, similarity 0.992):
[0001628280-15-007847:note_history:23]
|  | As of September 25, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 588,750 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 468,750 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,402 |  |  | — |  |
| Other | 13,248 |  |  | 16,233 |  |
| Total | $ | 2,666,150 |  |  | $ | 2,083,733 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001628280-16-010628:note_history:24]
Repayment of the Company’s long term debt outstanding as of December 31, 2015 is as follows:
  (was, 2015-10-26, similarity 0.9714):
[0001628280-15-007847:note_history:24]
Repayment of the Company’s long term debt outstanding as of September 25, 2015 is as follows:

- changed (2016-02-01):
[0001628280-16-010628:note_history:25]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2016. |
  (was, 2015-10-26, similarity 0.957):
[0001628280-15-007847:note_history:25]
| (1) | Represents scheduled repayment for the remaining six-month period ending March 31, 2016. |
