# FLEX MD&A — 0001628280-16-010628


## mdna

[0001628280-16-010628:mdna:1]
[same as prior period, unchanged from 0001628280-15-007847:mdna:1]

[0001628280-16-010628:mdna:2]
[same as prior period, unchanged from 0001628280-15-007847:mdna:2]

[0001628280-16-010628:mdna:3]
[same as prior period, unchanged from 0001628280-15-007847:mdna:3]

[0001628280-16-010628:mdna:4]
[same as prior period, unchanged from 0001628280-15-007847:mdna:4]

[0001628280-16-010628:mdna:5]
On July 23, 2015, we introduced our new brand and website to help us more efficiently manage our business opportunities and explain our new product and service offerings. We are shortening our brand name from Flextronics to “Flex” to signify that our business continues to evolve past the boundaries and confines of electronics alone. Our new tag line, “Live Smarter” highlights our belief that all devices are becoming intelligent and that value will ultimately be created in the “intelligence of things” and the convergence of technologies and digitization of products across multiple industries and market segments.

[0001628280-16-010628:mdna:6]
[same as prior period, unchanged from 0001628280-15-007847:mdna:6]

[0001628280-16-010628:mdna:7]
[same as prior period, unchanged from 0001628280-15-007847:mdna:7]

[0001628280-16-010628:mdna:8]
[same as prior period, unchanged from 0001628280-15-007847:mdna:34]

[0001628280-16-010628:mdna:9]
[same as prior period, unchanged from 0001628280-15-007847:mdna:9]

[0001628280-16-010628:mdna:10]
During the past few years, we have made significant efforts to evolve our long-term portfolio towards a higher mix of businesses which possess longer product life cycles and higher segment operating margins such as reflected in our IEI and HRS businesses. During the last two fiscal years we launched several programs broadly across our portfolio of services and in some instances we deployed certain new technologies. Some of these programs have started to yield better results, as demonstrated by our segment operating margin improvement while our sales decreased compared to the prior year. We continue to invest in innovation and we have expanded our design and engineering relationships through our product innovation centers.

[0001628280-16-010628:mdna:11]
[same as prior period, unchanged from 0001628280-15-007847:mdna:11]

[0001628280-16-010628:mdna:12]
We are one of the world's largest providers of global supply chain solutions, with revenues of $18.6 billion for the nine-month period ended December 31, 2015 and $26.1 billion in fiscal year 2015. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0001628280-16-010628:mdna:13]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Net sales: |  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
|  |  | (In thousands) |
| China |  | $ | 2,466,098 |  |  | 37 | % |  | $ | 2,636,663 |  |  | 38 | % |  | $ | 6,642,761 |  |  | 35 | % |  | $ | 7,663,630 |  |  | 38 | % |
| Mexico |  | 945,360 |  |  | 14 | % |  | 909,767 |  |  | 13 | % |  | 2,795,863 |  |  | 15 | % |  | 2,635,704 |  |  | 13 | % |
| U.S. |  | 874,197 |  |  | 13 | % |  | 779,607 |  |  | 11 | % |  | 2,144,543 |  |  | 12 | % |  | 2,224,063 |  |  | 11 | % |
| Malaysia |  | 492,723 |  |  | 7 | % |  | 624,239 |  |  | 9 | % |  | 1,605,012 |  |  | 9 | % |  | 1,726,200 |  |  | 9 | % |
| Brazil |  | 477,577 |  |  | 7 | % |  | 749,261 |  |  | 11 | % |  | 1,460,404 |  |  | 8 | % |  | 1,891,292 |  |  | 9 | % |
| Other |  | 1,507,222 |  |  | 22 | % |  | 1,325,517 |  |  | 18 | % |  | 3,997,604 |  |  | 21 | % |  | 4,055,427 |  |  | 20 | % |
|  |  | $ | 6,763,177 |  |  |  |  |  | $ | 7,025,054 |  |  |  |  |  | $ | 18,646,187 |  |  |  |  |  | $ | 20,196,316 |  |  |  |  |

[0001628280-16-010628:mdna:14]
|  |  | As of |  | As of |
| Property and equipment, net: |  | December 31, 2015 |  | March 31, 2015 |
|  |  | (In thousands) |
| China |  | $ | 794,732 |  |  | 35 | % |  | $ | 776,914 |  |  | 37 | % |
| Mexico |  | 354,979 |  |  | 16 | % |  | 364,435 |  |  | 17 | % |
| U.S. |  | 334,098 |  |  | 15 | % |  | 314,613 |  |  | 15 | % |
| Malaysia |  | 165,045 |  |  | 7 | % |  | 165,779 |  |  | 8 | % |
| Brazil |  | 122,555 |  |  | 5 | % |  | 103,496 |  |  | 5 | % |
| Other |  | 468,512 |  |  | 21 | % |  | 366,930 |  |  | 18 | % |
|  |  | $ | 2,239,921 |  |  |  |  |  | $ | 2,092,167 |  |  |  |  |

[0001628280-16-010628:mdna:15]
[same as prior period, unchanged from 0001628280-15-007847:mdna:15]

[0001628280-16-010628:mdna:16]
[same as prior period, unchanged from 0001628280-15-007847:mdna:42]

[0001628280-16-010628:mdna:17]
[same as prior period, unchanged from 0001628280-15-007847:mdna:17]

[0001628280-16-010628:mdna:18]
[same as prior period, unchanged from 0001628280-15-007847:mdna:18]

[0001628280-16-010628:mdna:19]
[same as prior period, unchanged from 0001628280-15-007847:mdna:19]

[0001628280-16-010628:mdna:20]
[same as prior period, unchanged from 0001628280-15-007847:mdna:20]

[0001628280-16-010628:mdna:21]
[same as prior period, unchanged from 0001628280-15-007847:mdna:21]

[0001628280-16-010628:mdna:22]
[same as prior period, unchanged from 0001628280-15-007847:mdna:22]

[0001628280-16-010628:mdna:23]
[same as prior period, unchanged from 0001628280-15-007847:mdna:23]

[0001628280-16-010628:mdna:24]
[same as prior period, unchanged from 0001628280-15-007847:mdna:24]

[0001628280-16-010628:mdna:25]
[same as prior period, unchanged from 0001628280-15-007847:mdna:25]

[0001628280-16-010628:mdna:26]
[same as prior period, unchanged from 0001628280-15-007847:mdna:26]

[0001628280-16-010628:mdna:27]
[same as prior period, unchanged from 0001628280-15-007847:mdna:27]

[0001628280-16-010628:mdna:28]
[same as prior period, unchanged from 0001628280-15-007847:mdna:28]

[0001628280-16-010628:mdna:29]
[same as prior period, unchanged from 0001628280-15-007847:mdna:29]

[0001628280-16-010628:mdna:30]
[same as prior period, unchanged from 0001628280-15-007847:mdna:30]

[0001628280-16-010628:mdna:31]
[same as prior period, unchanged from 0001628280-15-007847:mdna:31]

[0001628280-16-010628:mdna:32]
[same as prior period, unchanged from 0001628280-15-007847:mdna:32]

[0001628280-16-010628:mdna:33]
[same as prior period, unchanged from 0001628280-15-007847:mdna:33]

[0001628280-16-010628:mdna:34]
[same as prior period, unchanged from 0001628280-15-007847:mdna:51]

[0001628280-16-010628:mdna:35]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.3 |  |  | 94.2 |  |  | 93.6 |  |  | 94.2 |  |
| Gross profit | 6.7 |  |  | 5.8 |  |  | 6.4 |  |  | 5.8 |  |
| Selling, general and administrative expenses | 3.6 |  |  | 3.1 |  |  | 3.6 |  |  | 3.1 |  |
| Intangible amortization | 0.3 |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |
| Interest and other, net | 0.3 |  |  | 0.1 |  |  | 0.3 |  |  | 0.2 |  |
| Other charges (income), net | 0.7 |  |  | 0.1 |  |  | 0.2 |  |  | (0.2 | ) |
| Income before income taxes | 1.8 |  |  | 2.4 |  |  | 2.1 |  |  | 2.6 |  |
| Provision for (benefit from) income taxes | (0.3 | ) |  | 0.3 |  |  | 0.0 |  |  | 0.2 |  |
| Net income | 2.1 | % |  | 2.1 | % |  | 2.1 | % |  | 2.4 | % |

[0001628280-16-010628:mdna:36]
[same as prior period, unchanged from 0001628280-15-007847:mdna:36]

[0001628280-16-010628:mdna:37]
[same as prior period, unchanged from 0001628280-15-007847:mdna:37]

[0001628280-16-010628:mdna:38]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Segments: |  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
|  |  | (In thousands) |
| INS |  | $ | 2,469,099 |  |  | 37 | % |  | $ | 2,358,199 |  |  | 34 | % |  | $ | 6,640,626 |  |  | 36 | % |  | $ | 7,139,333 |  |  | 35 | % |
| CTG |  | 2,057,850 |  |  | 30 | % |  | 2,647,229 |  |  | 37 | % |  | 5,633,903 |  |  | 30 | % |  | 7,078,912 |  |  | 35 | % |
| IEI |  | 1,214,225 |  |  | 18 | % |  | 1,105,992 |  |  | 16 | % |  | 3,490,205 |  |  | 19 | % |  | 3,327,660 |  |  | 17 | % |
| HRS |  | 1,022,003 |  |  | 15 | % |  | 913,634 |  |  | 13 | % |  | 2,881,453 |  |  | 15 | % |  | 2,650,411 |  |  | 13 | % |
|  |  | $ | 6,763,177 |  |  |  |  |  | $ | 7,025,054 |  |  |  |  |  | $ | 18,646,187 |  |  |  |  |  | $ | 20,196,316 |  |  |  |  |

[0001628280-16-010628:mdna:39]
Net sales during the three-month period ended December 31, 2015 totaled $6.8 billion, representing a decrease of approximately $0.3 billion, or 3.7% from $7.0 billion during the three-month period ended December 31, 2014. The decline in net sales was primarily due to a $0.6 billion decrease in our CTG segment. The drop in CTG was due to a decline in demand from our largest customer in our mobile business offset by expansion across wearables, connected home and gaming markets. The other segments each realized modest increases with $0.1 billion in our IEI segment primarily attributable to higher sales to our energy customers including the results from the NEXTracker acquisition, $0.1 billion in our INS segment and $0.1 billion in our HRS segment, primarily due to higher sales to our communication and automotive customers, respectively. Net sales decreased $194.0 million to $3.3 billion in Asia, and $82.2 million to $2.3 billion in the Americas, respectively. These decreases were offset by a small increase of $14.3 million in Europe.

[0001628280-16-010628:mdna:40]
Net sales during the nine-month period ended December 31, 2015 totaled $18.6 billion, representing a decrease of approximately $1.6 billion, or 7.7% from $20.2 billion during the nine-month period ended December 31, 2014. The decline in net sales was primarily due to softness in demand from our CTG and INS segments, primarily as a result of the same drivers listed above as well as from lower sales within our server and storage business. These decreases were offset by increases in our HRS and IEI segments attributable to an increase across multiple product categories and customers, most notably in our household, energy, automotive, and medical businesses. Net sales decreased $1.1 billion to $9.1 billion in Asia, $0.3 billion to $6.4 billion in the Americas and $0.2 billion to $3.1 billion in Europe, respectively.

[0001628280-16-010628:mdna:41]
39

[0001628280-16-010628:mdna:42]
Our ten largest customers, during the three-month and nine-month periods ended December 31, 2015, accounted for approximately 46% of net sales, respectively. Motorola Mobility (including net sales from its parent Lenovo) accounted for more than 10% of net sales during the three and nine-month periods ended December 31, 2015.

[0001628280-16-010628:mdna:43]
Our ten largest customers accounted for approximately 51% of net sales for both the three-month and the nine-month periods ended December 31, 2014, respectively. Motorola Mobility (including net sales from its former parent Google, up to the point in time when Motorola Mobility was acquired by Lenovo, and including net sales from Lenovo thereafter) accounted for more than 10% of net sales during the three-month and nine-month periods ended December 31, 2014.

[0001628280-16-010628:mdna:44]
[same as prior period, unchanged from 0001628280-15-007847:mdna:44]

[0001628280-16-010628:mdna:45]
[same as prior period, unchanged from 0001628280-15-007847:mdna:45]

[0001628280-16-010628:mdna:46]
Gross profit during the three-month period ended December 31, 2015 increased $43.8 million to $452.5 million, or 6.7% of net sales, from $408.7 million, or 5.8% of net sales, during the three-month period ended December 31, 2014. Gross profit during the nine-month period ended December 31, 2015 increased $35.2 million to $1.2 billion, or 6.4% of net sales from $1.2 billion, or 5.8% of net sales, during the nine-month period ended December 31, 2014. The increase in gross profit reflects a richer mix of business and improved operational execution while ramping new customers and programs during the nine-month period ended December 31, 2015.

[0001628280-16-010628:mdna:47]
Gross margins improved 90 and 60 basis points in the three-month and nine-month periods ended December 31, 2015, respectively, compared to that of the three-month and nine-month periods ended December 31, 2014. Our overall improved margins are the result of our strategic objective to move our long-term portfolio towards a greater mix of businesses that have longer product lifecycles and higher margins across all our segments. The increase from the prior three-month and nine-month periods are due primarily to the proportionate increased share of our total revenues attributable to our HRS and IEI segments coupled with their increased profitability primarily driven by our acquisitions of MCi and NEXTracker.  See below for further discussion on segment profitability.

[0001628280-16-010628:mdna:48]
[same as prior period, unchanged from 0001628280-15-007847:mdna:48]

[0001628280-16-010628:mdna:49]
[same as prior period, unchanged from 0001628280-15-007847:mdna:49]

[0001628280-16-010628:mdna:50]
[same as prior period, unchanged from 0001628280-15-007847:mdna:50]

[0001628280-16-010628:mdna:51]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |  |  |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| INS | $ | 75,578 |  |  | 3.1 | % |  | $ | 72,654 |  |  | 3.1 | % |  | $ | 198,400 |  |  | 3.0 | % |  | $ | 203,008 |  |  | 2.8 | % |
| CTG | 49,032 |  |  | 2.4 | % |  | 73,200 |  |  | 2.8 | % |  | 129,045 |  |  | 2.3 | % |  | 156,401 |  |  | 2.2 | % |
| IEI | 49,230 |  |  | 4.1 | % |  | 21,730 |  |  | 2.0 | % |  | 110,498 |  |  | 3.2 | % |  | 104,636 |  |  | 3.1 | % |
| HRS | 82,806 |  |  | 8.1 | % |  | 56,124 |  |  | 6.1 | % |  | 213,890 |  |  | 7.4 | % |  | 159,068 |  |  | 6.0 | % |
| Corporate and Other | (20,563 | ) |  |  |  | (16,825 | ) |  |  |  | (60,348 | ) |  |  |  | (49,629 | ) |  |  |
| Total segment income | 236,083 |  |  | 3.5 | % |  | 206,883 |  |  | 2.9 | % |  | 591,485 |  |  | 3.2 | % |  | 573,484 |  |  | 2.8 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 19,319 |  |  |  |  | 8,045 |  |  |  |  | 43,117 |  |  |  |  | 23,228 |  |  |  |
| Stock-based compensation | 24,233 |  |  |  |  | 14,219 |  |  |  |  | 56,559 |  |  |  |  | 36,821 |  |  |  |
| Other charges (income), net | 44,415 |  |  |  |  | 5,067 |  |  |  |  | 46,257 |  |  |  |  | (41,526 | ) |  |  |
| Interest and other, net | 21,566 |  |  |  |  | 9,035 |  |  |  |  | 60,106 |  |  |  |  | 40,178 |  |  |  |
| Income before income taxes | $ | 126,550 |  |  |  |  | $ | 170,517 |  |  |  |  | $ | 385,446 |  |  |  |  | $ | 514,783 |  |  |  |

[0001628280-16-010628:mdna:52]
INS segment margin remained consistent for the three-month periods ended December 31, 2015 and December 31, 2014, respectively, while increasing 20 basis points, for the nine-month period ended December 31, 2015, from 2.8% during the nine-month period ended December 31, 2014. The improvements are driven by favorable product mix changes, higher utilization levels and strong operational execution across multiple customers and facilities.

[0001628280-16-010628:mdna:53]
CTG segment margin decreased 40 basis points for the three-month period ended December 31, 2015, from 2.8% during the three-month period ended December 31, 2014, primarily driven by change in product mix in the consumer electronics market and further impacted by charges related to a distressed customer. CTG segment margin increased 10 basis points for the nine-month period ended December 31, 2015, from 2.2% during the nine-month period ended December 31, 2014, due to a portfolio shift within the CTG product mix focusing on higher margin consumer electronic products including wearables, coupled with operational efficiencies due to better execution in programs, offset by a charge related to a distressed customer and lower contribution from our mobile business driven by a decrease in volume.

[0001628280-16-010628:mdna:54]
IEI segment margin increased 210 and 10 basis points, to 4.1% and 3.2%, respectively, for the three-month and nine-month periods ended December 31, 2015, from 2.0% and 3.1% during the three-month and nine-month periods ended December 31, 2014, respectively. The increases are primarily due to operational improvements for some of our previously under-performing programs, and additional contribution from new program ramps, including the results from our NEXTracker acquisition.

[0001628280-16-010628:mdna:55]
HRS segment margin increased 200 and 140 basis points, to 8.1% and 7.4%, respectively, for the three-month and nine-month periods ended December 31, 2015, from 6.1% and 6.0% during the three-month and nine-month periods ended December 31, 2014, respectively. The improvements are primarily due to additional flow through from the increase in revenue from new programs and successful integration of MCi, coupled with greater value-added business engagements due to greater design and engineering solutions being provided.

[0001628280-16-010628:mdna:56]
[same as prior period, unchanged from 0001628280-15-007847:mdna:57]

[0001628280-16-010628:mdna:57]
Selling, general and administrative expenses (“SG&A”) amounted to $240.6 million, or 3.6% of net sales, during the three-month period ended December 31, 2015, increasing $24.6 million from $216.0 million, or 3.1% of net sales, during the three-month period ended December 31, 2014. SG&A was $666.8 million, or 3.6% of net sales, during the nine-month period ended December 31, 2015, increasing $36.9 million from $629.9 million, or 3.1% of net sales, during the nine-month period ended December 31, 2014. The increase in SG&A expenses compared to the prior year is primarily due to increases in stock-based compensation expense, incremental costs associated with our acquisitions of MCi and NEXTracker both of which drive a higher SG&A level with the higher operating profit margins, and to a lesser extent charges related to a distressed customer.

[0001628280-16-010628:mdna:58]
[same as prior period, unchanged from 0001628280-15-007847:mdna:60]

[0001628280-16-010628:mdna:59]
Amortization of intangible assets increased by $11.3 million during the three-month period ended December 31, 2015 to $19.3 million from $8.0 million for the three-month period ended December 31, 2014, and increased by $19.9 million during the nine-month period ended December 31, 2015 to $43.1 million from $23.2 million during the nine-month period ended December 31, 2014. The increase is primarily due to incremental amortization expense on intangible assets relating to our acquisitions completed during the first nine months of fiscal year 2016.

[0001628280-16-010628:mdna:60]
[same as prior period, unchanged from 0001628280-15-007847:mdna:63]

[0001628280-16-010628:mdna:61]
Interest and other, net was $21.6 million during the three-month period ended December 31, 2015 compared to $9.0 million during the three-month period ended December 31, 2014. The increase in interest and other, net of $12.6 million was primarily due to $6.7 million of interest expense from the new 4.750% Notes due June 15, 2025 as further discussed in note 5 to the condensed consolidated financial statements, as well as a decrease in foreign currency gains in the current period of $4.1 million.

[0001628280-16-010628:mdna:62]
Interest and other, net was $60.1 million during the nine-month period ended December 31, 2015 compared to $40.2 million during the nine-month period ended December 31, 2014. The increase in interest and other, net of $19.9 million was primarily as a result of the same factors listed above, as well as $8.0 million of acquisition-related costs incurred during the period, primarily for MCi.

[0001628280-16-010628:mdna:63]
[same as prior period, unchanged from 0001628280-15-007847:mdna:66]

[0001628280-16-010628:mdna:64]
Other charges (income), net was $44.4 million and $46.3 million of other expense during the three and nine-month periods ended December 31, 2015, respectively, primarily due to $26.8 million loss on disposition of a non-strategic Western European manufacturing facility which included a non-cash foreign currency translation loss of $25.3 million, and $21.8 million from the impairment of a non-core investment. These were offset by a non-cash foreign currency translation gain of $4.2 million, as further discussed in note 7 to the condensed consolidated financial statements.

[0001628280-16-010628:mdna:65]
Other charges (income), net was $41.5 million of other income during the nine-month period ended December 31, 2014 principally as a result of the reversal of a contractual obligation with a certain customer recognized during the fourth quarter of fiscal year 2014 in the amount of $55.0 million. This was partially offset by an $11.0 million loss in connection with the disposition of a manufacturing facility in Western Europe.

[0001628280-16-010628:mdna:66]
[same as prior period, unchanged from 0001628280-15-007847:mdna:68]

[0001628280-16-010628:mdna:67]
[same as prior period, unchanged from 0001628280-15-007847:mdna:69]

[0001628280-16-010628:mdna:68]
[same as prior period, unchanged from 0001628280-15-007847:mdna:70]

[0001628280-16-010628:mdna:69]
The consolidated effective tax rate was (17.7)% and 0.7% for the three-month and nine-month periods ended December 31, 2015, respectively, and 10.3% and 9.5% for the three-month and nine-month periods ended December 31, 2014, respectively, and varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions, operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. We generate most of our revenues and profits from operations outside of Singapore. The effective tax rate for the nine-month period ended December 31, 2015 of 0.7% was significantly below the effective tax rate for the nine-month period ended December 31, 2014 of 9.5%. This reduction was primarily driven by a $39.3 million release of a previously established valuation allowance on deferred tax assets because of the recognition of $39.3 million in net deferred tax liabilities recorded in connection with the NEXTracker acquisition, as well as a $37.2 million reduction in our liability for uncertain tax positions due to settlements, foreign exchange and lapses of statues of limitations in various jurisdictions. Additionally, the effective tax rate in fiscal year 2015 was lower as it included other income of $55.0 million for which no tax expense was recorded due to the nature of the income.

[0001628280-16-010628:mdna:70]
[same as prior period, unchanged from 0001628280-15-007847:mdna:72]

[0001628280-16-010628:mdna:71]
As of December 31, 2015, we had cash and cash equivalents of approximately $1.6 billion and bank and other borrowings of approximately $2.8 billion. We have a $1.5 billion revolving credit facility that expires in March 2019, under which there were no borrowings outstanding as of the end of the quarter. As of December 31, 2015, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0001628280-16-010628:mdna:72]
Cash provided by operating activities was $939.8 million during the nine-month period ended December 31, 2015. This resulted primarily from $382.7 million of net income for the period plus adjustments for $381.9 million of non-cash charges such as depreciation, amortization, and other impairment charges, and $175.1 million from changes in our operating assets and liabilities. These changes were mainly related to an increase in accounts payable due to timing of payments to suppliers, offset by an increase in accounts receivable driven by the increase in sales activity.

[0001628280-16-010628:mdna:73]
[same as prior period, unchanged from 0001628280-15-007847:mdna:76]

[0001628280-16-010628:mdna:74]
|  | Three-Month Periods Ended |
|  | December 31, 2015 |  | March 31, 2015 |  | December 31, 2014 |
| Days in trade accounts receivable | 42 days |  | 46 days |  | 39 days |
| Days in inventory | 51 days |  | 58 days |  | 50 days |
| Days in accounts payable | 69 days |  | 77 days |  | 66 days |
| Cash conversion cycle | 24 days |  | 27 days |  | 23 days |

[0001628280-16-010628:mdna:75]
Days in trade accounts receivable was calculated as average accounts receivable for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended December 31, 2015, days in trade accounts receivable increased by 3 days compared to the three-month period ended December 31, 2014 largely due to timing of invoicing customers during the current period. Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $534.7 million, $600.7 million, and $674.6 million for the quarters ended December 31, 2015, March 31, 2015 and December 31, 2014, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 10 to the condensed consolidated financial statements.

[0001628280-16-010628:mdna:76]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in inventory remained consistent during the three-month period ended December 31, 2015, compared to the three-month period ended December 31, 2014.

[0001628280-16-010628:mdna:77]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable increased by 3 days during the three-month period ended December 31, 2015, compared to the three-month period ended December 31, 2014, primarily due to timing of payments.

[0001628280-16-010628:mdna:78]
Our cash conversion cycle was calculated as the sum of days of inventory and days of account receivables outstanding less days payable outstanding. Our cash conversion cycle increased by 1 day during the three-month period ended December 31, 2015, compared to the three-month period ended December 31, 2014, due to the factors for each of the components in the calculation discussed above.

[0001628280-16-010628:mdna:79]
Cash used in investing activities amounted to $1.3 billion during the nine-month period ended December 31, 2015. This resulted primarily from $903.8 million paid for the acquisition of nine businesses completed during the nine-month period ended December 31, 2015, including approximately $555.2 million, net of cash acquired, related to the acquisition of MCi, $238.1 million, net of cash acquired, related to the acquisition of NEXTracker, and approximately $67.5 million to acquire an optical transport facility from Alcatel-Lucent. Investing activities also reflects $413.9 million of net capital expenditures for property and equipment to support certain programs. Other investing activities includes $38.4 million paid for the purchase of certain investments, offset by $38.2 million of proceeds from the sale of certain assets that were purchased on behalf of a customer and financed by a third party banking institution.

[0001628280-16-010628:mdna:80]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment.

[0001628280-16-010628:mdna:81]
Our free cash flows for the nine-month period ended December 31, 2015 was $525.8 million compared to $505.0 million for the nine-month period ended December 31, 2014. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0001628280-16-010628:mdna:82]
|  | Nine-Month Periods Ended |
|  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 939,772 |  |  | $ | 669,424 |  |
| Purchases of property and equipment | (418,561 | ) |  | (254,970 | ) |
| Proceeds from the disposition of property and equipment | 4,627 |  |  | 90,576 |  |
| Free cash flow | $ | 525,838 |  |  | $ | 505,030 |  |

[0001628280-16-010628:mdna:83]
Cash provided by financing activities was $386.5 million during the nine-month period ended December 31, 2015, which was primarily for net proceeds from bank borrowings and long-term debt of $755.7 million mainly resulting from our new debt issuance discussed further in note 5 to the condensed consolidated financial statements, and $53.0 million from the issuance of our shares for option exercises. These cash inflows were partially offset by cash paid for the repurchase of our ordinary shares in the amount of $331.7 million.

[0001628280-16-010628:mdna:84]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of December 31, 2015 and March 31, 2015, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $800.0 million as of March 31, 2015). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0001628280-16-010628:mdna:85]
[same as prior period, unchanged from 0001628280-15-007847:mdna:87]

[0001628280-16-010628:mdna:86]
[same as prior period, unchanged from 0001628280-15-007847:mdna:88]

[0001628280-16-010628:mdna:87]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0001628280-16-010628:mdna:88]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 20, 2015. During the nine-month period ended December 31, 2015, we paid $331.7 million to repurchase shares (under the current and prior repurchase plans) at an average price of $11.28 per share. As of December 31, 2015, shares in the aggregate amount of $328.5 million were available to be repurchased under the current plan.

[0001628280-16-010628:mdna:89]
[same as prior period, unchanged from 0001628280-15-007847:mdna:91]

[0001628280-16-010628:mdna:90]
[same as prior period, unchanged from 0001628280-15-007847:mdna:92]

[0001628280-16-010628:mdna:91]
[same as prior period, unchanged from 0001628280-15-007847:mdna:93]

[0001628280-16-010628:mdna:92]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of December 31, 2015 and March 31, 2015, the fair values of our deferred purchase price receivable were approximately $534.7 million and $600.7 million, respectively. As of December 31, 2015 and March 31, 2015, the outstanding balances on receivables sold for cash were $1.2 billion and $1.3 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information see note 10 to the condensed consolidated financial statements.
