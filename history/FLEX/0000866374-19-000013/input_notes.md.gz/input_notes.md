# FLEX notes — 0000866374-19-000013


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-19-000013:notes:1]
[same as prior period, unchanged from 0000866374-19-000010:notes:1]

[0000866374-19-000013:notes:2]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scale® services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and manages complete packaged consumer and enterprise products, from medical devices and connected automotive systems to sustainable lighting and cloud and data center solutions for companies of all sizes in various industries and end-markets, through its activities in the following segments:

[0000866374-19-000013:notes:3]
[same as prior period, unchanged from 0000866374-19-000010:notes:3]

[0000866374-19-000013:notes:4]
[same as prior period, unchanged from 0000866374-19-000010:notes:4]

[0000866374-19-000013:notes:5]
[same as prior period, unchanged from 0000866374-19-000010:notes:5]

[0000866374-19-000013:notes:6]
[same as prior period, unchanged from 0000866374-19-000010:notes:6]

[0000866374-19-000013:notes:7]
[same as prior period, unchanged from 0000866374-19-000010:notes:7]

[0000866374-19-000013:notes:8]
[same as prior period, unchanged from 0000866374-19-000010:notes:8]

[0000866374-19-000013:notes:9]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2019 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and six-month periods ended September 27, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020.

[0000866374-19-000013:notes:10]
The first quarters for fiscal years 2020 and 2019 ended on June 28, 2019, which is comprised of 89 days in the period, and June 29, 2018, which is comprised of 90 days in the period, respectively. The second quarters for fiscal years 2020 and 2019 ended on September 27, 2019 and September 28, 2018, which are comprised of 91 days in both periods.

[0000866374-19-000013:notes:11]
[same as prior period, unchanged from 0000866374-19-000010:notes:11]

[0000866374-19-000013:notes:12]
[same as prior period, unchanged from 0000866374-19-000010:notes:12]

[0000866374-19-000013:notes:13]
In the accompanying condensed consolidated statements of operations $26.8 million and $29.0 million of expenses incurred in the three-month and six-month periods ended September 28, 2018, respectively, that were previously included as cost of sales have been reclassified as restructuring charges to conform with the current period presentation. Also, as previously disclosed, the Company has made certain immaterial corrections to net sales previously reported for the first and second quarters of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result of correcting these errors, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month and six-month periods ended September 28, 2018 have been reduced by $48 million and $73 million, respectively, from previously reported amounts. These corrections had no impact on gross profit, segment income or net income for the periods presented. Amounts presented for the three-month and six-month periods ended September 28, 2018 related to the disaggregation of revenue in the CTG segment in Note 4, and CTG segment net sales and total net sales in Note 16, have also been restated accordingly. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to the previously issued financial statements.

[0000866374-19-000013:notes:14]
Recently Adopted Accounting Pronouncement

[0000866374-19-000013:notes:15]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU No. 2016-02, Leases, and subsequent updates (collectively, referred to as Accounting Standard Codification 842 or “ASC 842”). ASC 842 requires a lessee to recognize a right of use (“ROU”) asset and lease liability. Leases will be classified as finance or operating, with classification affecting the recognition of expense and presentation in the income statement.

[0000866374-19-000013:notes:16]
The Company adopted ASC 842 on April 1, 2019 using the modified retrospective method on the effective date. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before the Company's adoption date. The Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. In addition, the Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for its leases, the Company uses its estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company’s estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company’s leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-19-000013:notes:17]
[same as prior period, unchanged from 0000866374-19-000010:notes:17]

[0000866374-19-000013:notes:18]
As a result of adopting ASC 842 as of April 1, 2019, the Company recognized additional operating liabilities of $658 million with a corresponding ROU asset of $624 million and a deferred gain of $22 million for sale leaseback transactions to opening retained earnings.

[0000866374-19-000013:notes:19]
In October 2018, the FASB issued ASU 2018-16 “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” to expand the lists of eligible benchmark interest rates to include OIS based on SOFR to facilitate the marketplace transition from LIBOR. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.

[0000866374-19-000013:notes:20]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing

[0000866374-19-000013:notes:21]
arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company early adopted the guidance during the second quarter of fiscal year 2020 with an immaterial impact to its condensed consolidated financial statements.

[0000866374-19-000013:notes:22]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.

[0000866374-19-000013:notes:23]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

[0000866374-19-000013:notes:24]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

[0000866374-19-000013:notes:25]
Recently Issued Accounting Pronouncements

[0000866374-19-000013:notes:26]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04 and ASU 2019-05, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is currently assessing and expects the new guidance to have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-19-000013:notes:27]
In October 2018, the FASB issued ASU 2018-17 “Consolidation (Topic 810): Targeted Improvements to Related Party Guidance for Variable Interest Entities” to provide a new private company variable interest entity exemption and change how decision makers apply the variable interest criteria. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-19-000013:notes:28]
BALANCE SHEET ITEMS 
Inventories

[0000866374-19-000013:notes:29]
[same as prior period, unchanged from 0000866374-19-000010:notes:30]

[0000866374-19-000013:notes:30]
|  | As of September 27, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| Raw materials | $ | 2,780,646 |  |  | $ | 2,922,101 |  |
| Work-in-progress | 394,282 |  |  | 366,135 |  |
| Finished goods | 546,309 |  |  | 434,618 |  |
|  | $ | 3,721,237 |  |  | $ | 3,722,854 |  |

[0000866374-19-000013:notes:31]
[same as prior period, unchanged from 0000866374-19-000010:notes:32]

[0000866374-19-000013:notes:32]
The following table summarizes the activity in the Company’s goodwill account for each of its four reporting units (which align to the Company's reportable segments) during the six-month period ended September 27, 2019:

[0000866374-19-000013:notes:33]
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
|  | (In thousands) |
| Balance, beginning of the year | $ | 507,209 |  |  | $ | 333,257 |  |  | $ | 129,325 |  |  | $ | 103,264 |  |  | $ | 1,073,055 |  |
| Divestitures | (1,102 | ) |  | (137 | ) |  | — |  |  | — |  |  | (1,239 | ) |
| Foreign currency translation adjustments | (9,366 | ) |  | — |  |  | — |  |  | — |  |  | (9,366 | ) |
| Balance, end of the period | $ | 496,741 |  |  | $ | 333,120 |  |  | $ | 129,325 |  |  | $ | 103,264 |  |  | $ | 1,062,450 |  |

[0000866374-19-000013:notes:34]
[same as prior period, unchanged from 0000866374-19-000010:notes:35]

[0000866374-19-000013:notes:35]
|  | As of September 27, 2019 |  | As of March 31, 2019 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 282,006 |  |  | $ | (118,818 | ) |  | $ | 163,188 |  |  | $ | 297,306 |  |  | $ | (113,627 | ) |  | $ | 183,679 |  |
| Licenses and other intangibles | 254,797 |  |  | (125,806 | ) |  | 128,991 |  |  | 274,604 |  |  | (127,288 | ) |  | 147,316 |  |
| Total | $ | 536,803 |  |  | $ | (244,624 | ) |  | $ | 292,179 |  |  | $ | 571,910 |  |  | $ | (240,915 | ) |  | $ | 330,995 |  |

[0000866374-19-000013:notes:36]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that it is more likely than not that the fair value of a reporting unit is below its carrying value. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying value, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. As previously disclosed, the date of its most recent annual impairment test the fair value of the CTG reporting unit exceeded its carrying value by 22%. The Company has assessed whether an interim impairment test should be performed on the CTG reporting unit in light of recent shortfalls in CTG’s financial performance. Management has concluded that it is more likely than not that CTG’s fair value exceeds its carrying value as of September 27, 2019, thus an interim impairment test was not completed. As the Company continues to refine its long-term strategy for the CTG reporting unit, it is reasonably possible that changes in circumstances could require management to perform an impairment test for CTG prior to the next annual impairment test date of January 1, 2020. In the event that an interim test is performed and goodwill in CTG is determined to be impaired, the resulting charge could be material to the consolidated results of operations.

[0000866374-19-000013:notes:37]
[same as prior period, unchanged from 0000866374-19-000010:notes:37]

[0000866374-19-000013:notes:38]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2020 (1) | $ | 30,747 |  |
| 2021 | 59,573 |  |
| 2022 | 51,229 |  |
| 2023 | 43,667 |  |
| 2024 | 42,066 |  |
| Thereafter | 64,897 |  |
| Total amortization expense | $ | 292,179 |  |

[0000866374-19-000013:notes:39]
[same as prior period, unchanged from 0000866374-19-000010:notes:39]

[0000866374-19-000013:notes:40]
| (1) | Represents estimated amortization for the remaining six-month period ending March 31, 2020. |

[0000866374-19-000013:notes:41]
[same as prior period, unchanged from 0000866374-19-000010:notes:41]

[0000866374-19-000013:notes:42]
Other current assets include approximately $357.1 million and $292.5 million as of September 27, 2019 and March 31, 2019, respectively, for the deferred purchase price receivable from the Company's Asset-Backed Securitization programs. See note 12 for additional information.

[0000866374-19-000013:notes:43]
The Company participates in certain customers' supplier financing programs allowing Flex to sell its receivables to financial institutions identified by the customer. Under these programs, the financial institutions act as the customers' paying agent with respect to receivables due to the Company. Following the sale of the receivables to the financial institutions, the transferred receivables are isolated from the Company and its affiliates, and effective control of the transferred receivables is passed to the financial institutions, which have the right to pledge or sell the receivables.

[0000866374-19-000013:notes:44]
During the second quarter of fiscal year 2020, certain invoices were sold and transferred to certain financial institutions under a customer's supplier financing program, that had the right to pledge or sell the receivables as of September 27, 2019. However, under the governing law in the jurisdiction of sale, the assignment of receivables is effective against third-parties only upon registration of the transferred assets with a governmental agency. The Company was not able to complete the registration of the receivables before the end of the fiscal quarter and accordingly did not account for these transactions as true sales. As a result of these transactions the Company has recorded $336.1 million of other current assets, with a corresponding amount recorded as other current liabilities, in the condensed consolidated balance sheet as of September 27, 2019, and has recorded the same amount as “other financing activities, net” in the statement of cash flows. The Company subsequently registered all of the invoices in October 2019 and the receivables were considered sold at that time.

[0000866374-19-000013:notes:45]
[same as prior period, unchanged from 0000866374-19-000010:notes:43]

[0000866374-19-000013:notes:46]
Other current liabilities include customer working capital advances of $249.9 million and $266.3 million, customer-related accruals of $243.5 million and $260.1 million, and deferred revenue of $341.5 million and $271.8 million, as of September 27, 2019 and March 31, 2019, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Following the adoption of ASC 842, current operating lease liabilities were $119.6 million as of September 27, 2019. Further, other current liabilities include $336.1 million representing the arrangement with the financial institutions as of September 27, 2019, as further described above.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-19-000013:notes:47]
[same as prior period, unchanged from 0000866374-19-000010:notes:45]

[0000866374-19-000013:notes:48]
The components of lease cost were as follow (in thousands):

[0000866374-19-000013:notes:49]
| Lease cost | Three-Month Period Ended |  | Six-Month Period Ended |
|  | September 27, 2019 |  | September 27, 2019 |
| Operating lease cost | $ | 40,630 |  |  | $ | 81,306 |  |
| Total lease cost | $ | 40,630 |  |  | $ | 81,306 |  |

[0000866374-19-000013:notes:50]
Amounts reported in the Consolidated Balance Sheet as of the period ended September 27, 2019 were (in thousands, except weighted average lease term and discount rate):

[0000866374-19-000013:notes:51]
|  |  | As of September 27, 2019 |
| Operating Leases: |  |  |
| Operating lease right of use assets |  | $ | 588,474 |  |
| Operating lease liabilities |  | 631,701 |  |
| Weighted-average remaining lease term (In years) |  |  |
| Operating leases |  | 7.2 |  |
| Weighted-average discount rate |  |  |
| Operating leases |  | 4.3 | % |

[0000866374-19-000013:notes:52]
Other information related to leases was as follow (in thousands):

[0000866374-19-000013:notes:53]
|  |  | Six-Month Period Ended |
|  |  | September 27, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |
| Operating cash flows from operating leases |  | $ | 69,106 |  |

[0000866374-19-000013:notes:54]
Future lease payments under non-cancellable leases as of September 27, 2019 are as follows (in thousands):

[0000866374-19-000013:notes:55]
| Fiscal Year Ended March 31, |  | Operating Leases |
| 2020 (1) |  | $ | 77,710 |  |
| 2021 |  | 125,871 |  |
| 2022 |  | 106,230 |  |
| 2023 |  | 92,832 |  |
| 2024 |  | 79,096 |  |
| Thereafter |  | 259,559 |  |
| Total undiscounted lease payments |  | 741,298 |  |
| Less: imputed interest |  | 109,597 |  |
| Total lease liabilities |  | $ | 631,701 |  |

[0000866374-19-000013:notes:56]
| (1) | Represents estimated lease payments for the remaining six-month period ending March 31, 2020. |

[0000866374-19-000013:notes:57]
[same as prior period, unchanged from 0000866374-19-000010:notes:55]

[0000866374-19-000013:notes:58]
[same as prior period, unchanged from 0000866374-19-000010:notes:56]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-19-000013:notes:59]
REVENUE 
Revenue Recognition

[0000866374-19-000013:notes:60]
[same as prior period, unchanged from 0000866374-19-000010:notes:59]

[0000866374-19-000013:notes:61]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first

[0000866374-19-000013:notes:62]
required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-19-000013:notes:63]
[same as prior period, unchanged from 0000866374-19-000010:notes:61]

[0000866374-19-000013:notes:64]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-19-000013:notes:65]
[same as prior period, unchanged from 0000866374-19-000010:notes:63]

[0000866374-19-000013:notes:66]
[same as prior period, unchanged from 0000866374-19-000010:notes:64]

[0000866374-19-000013:notes:67]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-19-000013:notes:68]
[same as prior period, unchanged from 0000866374-19-000010:notes:67]

[0000866374-19-000013:notes:69]
[same as prior period, unchanged from 0000866374-19-000010:notes:68]

[0000866374-19-000013:notes:70]
[same as prior period, unchanged from 0000866374-19-000010:notes:69]

[0000866374-19-000013:notes:71]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $341.5 million and $271.8 million as of September 27, 2019 and March 31, 2019, respectively.

[0000866374-19-000013:notes:72]
[same as prior period, unchanged from 0000866374-19-000010:notes:71]

[0000866374-19-000013:notes:73]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended September 27, 2019 and September 28, 2018 (in thousands), respectively.

[0000866374-19-000013:notes:74]
|  | Three-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 942,113 |  |  | $ | 1,147,976 |  |  | $ | 1,390,059 |  |  | $ | 1,103,855 |  |  | $ | 4,584,003 |  |
| Over time | 246,518 |  |  | 637,592 |  |  | 338,538 |  |  | 281,403 |  |  | 1,504,051 |  |
| Total segment | $ | 1,188,631 |  |  | $ | 1,785,568 |  |  | $ | 1,728,597 |  |  | $ | 1,385,258 |  |  | $ | 6,088,054 |  |

[0000866374-19-000013:notes:75]
|  | Six-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,865,840 |  |  | $ | 2,263,035 |  |  | $ | 2,749,423 |  |  | $ | 2,128,481 |  |  | $ | 9,006,779 |  |
| Over time | 500,834 |  |  | 1,159,447 |  |  | 838,023 |  |  | 758,910 |  |  | 3,257,214 |  |
| Total segment | $ | 2,366,674 |  |  | $ | 3,422,482 |  |  | $ | 3,587,446 |  |  | $ | 2,887,391 |  |  | $ | 12,263,993 |  |

[0000866374-19-000013:notes:76]
|  | Three-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 893,141 |  |  | $ | 1,089,319 |  |  | $ | 1,519,041 |  |  | $ | 1,201,696 |  |  | $ | 4,703,197 |  |
| Over time | 314,830 |  |  | 476,634 |  |  | 621,756 |  |  | 546,187 |  |  | 1,959,407 |  |
| Total segment | $ | 1,207,971 |  |  | $ | 1,565,953 |  |  | $ | 2,140,797 |  |  | $ | 1,747,883 |  |  | $ | 6,662,604 |  |

[0000866374-19-000013:notes:77]
|  | Six-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,898,321 |  |  | $ | 2,153,218 |  |  | $ | 3,012,548 |  |  | $ | 2,499,833 |  |  | $ | 9,563,920 |  |
| Over time | 525,075 |  |  | 859,046 |  |  | 1,082,535 |  |  | 1,030,984 |  |  | 3,497,640 |  |
| Total segment | $ | 2,423,396 |  |  | $ | 3,012,264 |  |  | $ | 4,095,083 |  |  | $ | 3,530,817 |  |  | $ | 13,061,560 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-19-000013:notes:78]
[same as prior period, unchanged from 0000866374-19-000010:notes:75]

[0000866374-19-000013:notes:79]
[same as prior period, unchanged from 0000866374-19-000010:notes:76]

[0000866374-19-000013:notes:80]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2019 |  | September 28, 2018 |  | September 27, 2019 |  | September 28, 2018 |
|  | (In thousands) |
| Cost of sales | $ | 4,212 |  |  | $ | 4,767 |  |  | $ | 7,152 |  |  | $ | 10,171 |  |
| Selling, general and administrative expenses | 14,678 |  |  | 14,314 |  |  | 26,965 |  |  | 29,863 |  |
| Total share-based compensation expense | $ | 18,890 |  |  | $ | 19,081 |  |  | $ | 34,117 |  |  | $ | 40,034 |  |

[0000866374-19-000013:notes:81]
Total unrecognized compensation expense related to share options under all plans was $1.2 million and will be recognized over a weighted-average remaining vesting period of 1.5 years. As of September 27, 2019, the number of options outstanding

[0000866374-19-000013:notes:82]
and exercisable under all plans was 0.6 million and 0.5 million, respectively, at a weighted-average exercise price of $4.28 per share and $5.49 per share, respectively.

[0000866374-19-000013:notes:83]
During the six-month period ended September 27, 2019, the Company granted 8.1 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 6.3 million are plain-vanilla unvested RSU awards that vest over four years, with no performance or market conditions, and with an average grant date price of $9.19 per award. Further, approximately 1.8 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $11.92 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 3.6 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-19-000013:notes:84]
As of September 27, 2019, approximately 17.6 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 3.5 million awards is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 7.0 million based on the achievement levels of the respective conditions. During the six-month period ended September 27, 2019, no shares vested in connection with the awards with market conditions granted in fiscal year 2017.

[0000866374-19-000013:notes:85]
As of September 27, 2019, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $161.3 million, and will be recognized over a weighted-average remaining vesting period of 2.6 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-19-000013:notes:86]
EARNINGS (LOSSES) PER SHARE 
The following table reflects basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share attributable to the shareholders of Flex:

[0000866374-19-000013:notes:87]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2019 |  | September 28, 2018 |  | September 27, 2019 |  | September 28, 2018 |
|  | (In thousands, except per share amounts) |
| Basic earnings (losses) per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | (116,940 | ) |  | $ | 86,885 |  |  | $ | (72,068 | ) |  | $ | 202,920 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 512,692 |  |  | 531,503 |  |  | 513,448 |  |  | 530,426 |  |
| Basic earnings (losses) per share | $ | (0.23 | ) |  | $ | 0.16 |  |  | $ | (0.14 | ) |  | $ | 0.38 |  |
| Diluted earnings (losses) per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | (116,940 | ) |  | $ | 86,885 |  |  | $ | (72,068 | ) |  | $ | 202,920 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 512,692 |  |  | 531,503 |  |  | 513,448 |  |  | 530,426 |  |
| Weighted-average ordinary share equivalents from stock options and restricted share unit awards (1) (2) (3) | — |  |  | 2,955 |  |  | — |  |  | 4,601 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 512,692 |  |  | 534,458 |  |  | 513,448 |  |  | 535,027 |  |
| Diluted earnings (losses) per share | $ | (0.23 | ) |  | $ | 0.16 |  |  | $ | (0.14 | ) |  | $ | 0.38 |  |

[0000866374-19-000013:notes:88]
| (1) | As a result of the Company's net loss, ordinary shares equivalent from stock options and RSU awards of approximately 2.6 million for the three-month period ended September 27, 2019, and 3.3 million for the six-month period ended September 27, 2019, were excluded from the calculation of diluted earnings (losses) per share, due to their anti-dilutive impact on the weighted-average ordinary share equivalents. |

[0000866374-19-000013:notes:89]
| (2) | An immaterial number of options to purchase ordinary shares were excluded from the computation of diluted earnings (losses) per share during the three and six-month periods ended September 27, 2019 and September 28, 2018, respectively, due to their anti-dilutive impact on the weighted-average ordinary share equivalents. |

[0000866374-19-000013:notes:90]
(3)

[0000866374-19-000013:notes:91]
RSU awards of 5.9 million and 5.5 million for the three and six-month periods ended September 27, 2019 were excluded from the computation of diluted earnings (losses) per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. RSU awards of 3.1 million for the three and six-month periods ended September 28, 2018 were excluded from the computation of diluted earnings per share.


## us-gaap:DebtDisclosureTextBlock

[0000866374-19-000013:notes:92]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 27, 2019 are as follows:

[0000866374-19-000013:notes:93]
|  | As of September 27, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,224 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,037 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,277 |  |  | — |  |
| India Facilities | 110,258 |  |  | 170,206 |  |
| Other | 162,992 |  |  | 168,039 |  |
| Debt issuance costs | (13,273 | ) |  | (10,639 | ) |
|  | 2,990,328 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (32,450 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,957,878 |  |  | $ | 2,421,904 |  |

[0000866374-19-000013:notes:94]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.2% as of September 27, 2019 and March 31, 2019.

[0000866374-19-000013:notes:95]
During the first quarter of fiscal year 2020, and as further discussed below, the Company entered into a JPY33.525 billion term loan agreement due April 2024, in addition to issuing $450 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay the outstanding balance of the Company's existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021. As both transactions were determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during the three-month and six-month periods ended September 27, 2019, which was recorded in interest and other, net on the condensed consolidated statements of operations during the period.

[0000866374-19-000013:notes:96]
Scheduled repayments of the Company's long-term debt as of September 27, 2019 are as follows:

[0000866374-19-000013:notes:97]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2020 (1) |  | $ | 19,529 |  |
| 2021 |  | 98,849 |  |
| 2022 |  | 607,940 |  |
| 2023 |  | 857,571 |  |
| 2024 |  | 60,438 |  |
| Thereafter |  | 1,359,274 |  |
| Total |  | $ | 3,003,601 |  |

[0000866374-19-000013:notes:98]
| (1) | Represents estimated repayments for the remaining six-month period ending March 31, 2020. |

[0000866374-19-000013:notes:99]
Term Loan due April 2024

[0000866374-19-000013:notes:100]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency

[0000866374-19-000013:notes:101]
contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 10 for additional details.

[0000866374-19-000013:notes:102]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of September 27, 2019, the Company was in compliance with the covenants under this term loan agreement.

[0000866374-19-000013:notes:103]
Notes due June 2029

[0000866374-19-000013:notes:104]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “2029 Notes”), at 99.607% of face value. The Company received proceeds of approximately $448.2 million, net of discount, from the issuance which was used, together with available cash, to refinance certain other outstanding debt. The Company incurred and capitalized as a direct reduction to the carrying amount of the notes presented on the balance sheet approximately $4.3 million of costs in conjunction with the issuance of the 2029 Notes.

[0000866374-19-000013:notes:105]
Interest on the 2029 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2019. The 2029 Notes are senior unsecured obligations of the Company and rank equally with all of the Company’s other existing and future senior and unsecured indebtedness.

[0000866374-19-000013:notes:106]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of September 27, 2019, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.


## flex:InterestAndOtherNetTextBlock

[0000866374-19-000013:notes:107]
INTEREST AND OTHER, NET 
Interest and other, net for the three and six-month periods ended September 27, 2019 and September 28, 2018 are primarily composed of the following:

[0000866374-19-000013:notes:108]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2019 |  | September 28, 2018 |  | September 27, 2019 |  | September 28, 2018 |
|  | (In thousands) |
| Interest expenses on debt obligations (1) | $ | 38,461 |  |  | $ | 35,139 |  |  | $ | 78,889 |  |  | $ | 68,656 |  |
| ABS and AR sales programs related expenses | 11,658 |  |  | 11,109 |  |  | 24,639 |  |  | 20,589 |  |
| Interest income | (5,206 | ) |  | (4,751 | ) |  | (9,798 | ) |  | (9,872 | ) |
| (Gain) Loss on foreign exchange transactions | (3,167 | ) |  | 3,129 |  |  | (4,053 | ) |  | 5,186 |  |

[0000866374-19-000013:notes:109]
[same as prior period, unchanged from 0000866374-19-000010:notes:105]

[0000866374-19-000013:notes:110]
Interest expense on debt obligations for the three-month and six-month periods ended September 27, 2019 include debt extinguishment costs of $2.4 million and $6.5 million, respectively, related to the full repayment of the Notes due February 2020 and partial repayment of Term Loan due November 2021.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-19-000013:notes:111]
OTHER CHARGES (INCOME), NET 
During the six-month period ended September 28, 2018, the Company recognized other income of $80.4 million, primarily driven by an $87.3 million gain on the deconsolidation of Bright Machines.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-19-000013:notes:112]
FINANCIAL INSTRUMENTS
Foreign Currency Contracts

[0000866374-19-000013:notes:113]
[same as prior period, unchanged from 0000866374-19-000010:notes:110]

[0000866374-19-000013:notes:114]
As of September 27, 2019, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $9.1 billion as summarized below:

[0000866374-19-000013:notes:115]
|  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |
| CNY | 1,086,000 |  |  | — |  |  | $ | 152,447 |  |  | $ | — |  |
| EUR | 34,640 |  |  | 4,260 |  |  | 38,352 |  |  | 4,668 |  |
| HUF | 27,209,000 |  |  | — |  |  | 89,151 |  |  | — |  |
| ILS | 190,000 |  |  | — |  |  | 54,247 |  |  | — |  |
| JPY | 33,525,000 |  |  | — |  |  | 300,000 |  |  | — |  |
| MXN | 4,035,000 |  |  | — |  |  | 206,441 |  |  | — |  |
| MYR | 264,000 |  |  | 40,900 |  |  | 63,187 |  |  | 9,789 |  |
| PLN | 131,400 |  |  | — |  |  | 32,862 |  |  | — |  |
| RON | 192,000 |  |  | — |  |  | 44,333 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 46,353 |  |  | — |  |
|  |  |  |  |  |  |  | 1,027,373 |  |  | 14,457 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |
| BRL | — |  |  | 972,000 |  |  | — |  |  | 232,619 |  |
| CAD | 65,885 |  |  | 43,154 |  |  | 49,627 |  |  | 32,505 |  |
| CNY | 5,214,716 |  |  | 1,371,026 |  |  | 738,250 |  |  | 192,837 |  |
| EUR | 1,820,719 |  |  | 2,011,008 |  |  | 1,997,855 |  |  | 2,209,684 |  |
| GBP | 45,292 |  |  | 56,241 |  |  | 56,026 |  |  | 69,547 |  |
| HUF | 80,227,683 |  |  | 84,751,497 |  |  | 262,868 |  |  | 277,690 |  |
| ILS | 264,700 |  |  | 115,000 |  |  | 75,575 |  |  | 32,834 |  |
| INR | 6,807,200 |  |  | 6,411,000 |  |  | 95,825 |  |  | 90,248 |  |
| JPY | 3,195,245 |  |  | 2,596,970 |  |  | 29,736 |  |  | 24,233 |  |
| MXN | 4,450,330 |  |  | 2,690,978 |  |  | 227,691 |  |  | 137,678 |  |
| MYR | 2,142,120 |  |  | 1,799,000 |  |  | 512,702 |  |  | 430,579 |  |
| SEK | 455,420 |  |  | 538,295 |  |  | 46,934 |  |  | 55,304 |  |
| SGD | 90,548 |  |  | 53,439 |  |  | 65,686 |  |  | 38,766 |  |
| Other | N/A |  |  | N/A |  |  | 57,488 |  |  | 41,809 |  |
|  |  |  |  |  |  |  | 4,216,263 |  |  | 3,866,333 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  | $ | 5,243,636 |  |  | $ | 3,880,790 |  |

[0000866374-19-000013:notes:116]
As of September 27, 2019, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these

[0000866374-19-000013:notes:117]
instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of September 27, 2019 and March 31, 2019, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were immaterial as of September 27, 2019, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-19-000013:notes:118]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of September 27, 2019. The changes in fair value of the USD JPY cross currency swap are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also impacts the same line.

[0000866374-19-000013:notes:119]
[same as prior period, unchanged from 0000866374-19-000010:notes:116]

[0000866374-19-000013:notes:120]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 27, 2019 |  | March 31, 2019 |  | Balance SheetLocation |  | September 27, 2019 |  | March 31, 2019 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 2,492 |  |  | $ | 10,503 |  |  | Other current liabilities |  | $ | 22,800 |  |  | $ | 10,282 |  |
| Foreign currency contracts | Other assets |  | $ | 18,316 |  |  | $ | — |  |  | Other liabilities |  | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 24,508 |  |  | $ | 16,774 |  |  | Other current liabilities |  | $ | 23,327 |  |  | $ | 17,144 |  |

[0000866374-19-000013:notes:121]
[same as prior period, unchanged from 0000866374-19-000010:notes:118]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-19-000013:notes:122]
[same as prior period, unchanged from 0000866374-19-000010:notes:119]

[0000866374-19-000013:notes:123]
|  | Three-Month Periods Ended |
|  | September 27, 2019 |  | September 28, 2018 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (47,031 | ) |  | $ | (105,203 | ) |  | $ | (152,234 | ) |  | $ | (76,649 | ) |  | $ | (94,185 | ) |  | $ | (170,834 | ) |
| Other comprehensive gain (loss) before reclassifications | (2,883 | ) |  | (25,907 | ) |  | (28,790 | ) |  | 945 |  |  | (6,622 | ) |  | (5,677 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (8,740 | ) |  | — |  |  | (8,740 | ) |  | 20,130 |  |  | — |  |  | 20,130 |  |
| Net current-period other comprehensive gain (loss) | (11,623 | ) |  | (25,907 | ) |  | (37,530 | ) |  | 21,075 |  |  | (6,622 | ) |  | 14,453 |  |
| Ending balance | $ | (58,654 | ) |  | $ | (131,110 | ) |  | $ | (189,764 | ) |  | $ | (55,574 | ) |  | $ | (100,807 | ) |  | $ | (156,381 | ) |

[0000866374-19-000013:notes:124]
|  | Six-Month Periods Ended |
|  | September 27, 2019 |  | September 28, 2018 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (41,556 | ) |  | $ | (109,607 | ) |  | $ | (151,163 | ) |  | $ | (35,746 | ) |  | $ | (50,099 | ) |  | $ | (85,845 | ) |
| Other comprehensive gain (loss) before reclassifications | (8,951 | ) |  | (21,503 | ) |  | (30,454 | ) |  | (40,714 | ) |  | (50,708 | ) |  | (91,422 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (8,147 | ) |  | — |  |  | (8,147 | ) |  | 20,886 |  |  | — |  |  | 20,886 |  |
| Net current-period other comprehensive gain (loss) | (17,098 | ) |  | (21,503 | ) |  | (38,601 | ) |  | (19,828 | ) |  | (50,708 | ) |  | (70,536 | ) |
| Ending balance | $ | (58,654 | ) |  | $ | (131,110 | ) |  | $ | (189,764 | ) |  | $ | (55,574 | ) |  | $ | (100,807 | ) |  | $ | (156,381 | ) |

[0000866374-19-000013:notes:125]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month and six-month periods ended September 27, 2019 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-19-000013:notes:126]
[same as prior period, unchanged from 0000866374-19-000010:notes:122]

[0000866374-19-000013:notes:127]
[same as prior period, unchanged from 0000866374-19-000010:notes:123]

[0000866374-19-000013:notes:128]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred

[0000866374-19-000013:notes:129]
purchase price receivables, which are included in other current assets as of September 27, 2019 and March 31, 2019, were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables, and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-19-000013:notes:130]
[same as prior period, unchanged from 0000866374-19-000010:notes:125]

[0000866374-19-000013:notes:131]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month and six-month periods ended September 27, 2019 and September 28, 2018 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-19-000013:notes:132]
[same as prior period, unchanged from 0000866374-19-000010:notes:127]

[0000866374-19-000013:notes:133]
As of September 27, 2019 and March 31, 2019, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company during the six-month periods ended September 27, 2019 and September 28, 2018 were included as cash provided by operating activities in the condensed consolidated statements of cash flows. The Company recognizes these proceeds net of the deferred purchase price, consisting of a receivable from the purchasers that entitles the Company to certain collections on the receivable. The Company recognizes the collection of the deferred purchase price in net cash provided by investing activities in the condensed consolidated statements of cash flows separately as cash collections of deferred purchase price.

[0000866374-19-000013:notes:134]
As of September 27, 2019, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $0.8 billion and deferred purchase price receivables of $0.4 billion. As of March 31, 2019, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $0.9 billion and deferred purchase price receivables of $0.3 billion. The deferred purchase price balances as of September 27, 2019 and March 31, 2019, also represent the non-cash beneficial interest obtained in exchange for securitized receivables.

[0000866374-19-000013:notes:135]
For the six-month periods ended September 27, 2019 and September 28, 2018, cash flows from sales of receivables under the ABS Programs consisted of approximately $3.2 billion and $3.7 billion, respectively, for transfers of receivables, and approximately $1.8 billion, respectively, for collections on deferred purchase price receivables. The Company's cash flows from transfer of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-19-000013:notes:136]
Trade Accounts Receivable Sale Programs
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.4 billion and $0.5 billion as of September 27, 2019 and March 31, 2019, respectively. For the six-month periods ended September 27, 2019 and September 28, 2018, total accounts receivable sold to certain third-party banking institutions was approximately $0.9 billion and $1.4 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-19-000013:notes:137]
[same as prior period, unchanged from 0000866374-19-000010:notes:132]

[0000866374-19-000013:notes:138]
[same as prior period, unchanged from 0000866374-19-000010:notes:133]

[0000866374-19-000013:notes:139]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager. The Company’s deferred compensation plan assets are included in other noncurrent assets on the condensed consolidated balance sheets and include investments in equity securities that are valued using active market prices. There were no investments balance classified as level 1 in the fair value hierarchy as of September 27, 2019.

[0000866374-19-000013:notes:140]
[same as prior period, unchanged from 0000866374-19-000010:notes:135]

[0000866374-19-000013:notes:141]
[same as prior period, unchanged from 0000866374-19-000010:notes:136]

[0000866374-19-000013:notes:142]
[same as prior period, unchanged from 0000866374-19-000010:notes:137]

[0000866374-19-000013:notes:143]
[same as prior period, unchanged from 0000866374-19-000010:notes:138]

[0000866374-19-000013:notes:144]
[same as prior period, unchanged from 0000866374-19-000010:notes:139]

[0000866374-19-000013:notes:145]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of September 27, 2019 and March 31, 2019.

[0000866374-19-000013:notes:146]
There were no transfers between levels in the fair value hierarchy during the six-month periods ended September 27, 2019 and September 28, 2018.

[0000866374-19-000013:notes:147]
[same as prior period, unchanged from 0000866374-19-000010:notes:142]

[0000866374-19-000013:notes:148]
[same as prior period, unchanged from 0000866374-19-000010:notes:143]

[0000866374-19-000013:notes:149]
|  | Fair Value Measurements as of September 27, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 796,718 |  |  | $ | — |  |  | $ | 796,718 |  |
| Foreign exchange contracts (Note 10) | — |  |  | 45,316 |  |  | — |  |  | 45,316 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 56,351 |  |  | — |  |  | 56,351 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0.003 |  |
| Foreign exchange contracts (Note 10) | $ | — |  |  | $ | (46,127 | ) |  | $ | — |  |  | $ | (46,127 | ) |
|  | Fair Value Measurements as of March 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 473,888 |  |  | $ | — |  |  | $ | 473,888 |  |
| Foreign exchange contracts (Note 10) | — |  |  | 27,277 |  |  | — |  |  | 27,277 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 2,845 |  |  | 76,852 |  |  | — |  |  | 79,697 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 10) | $ | — |  |  | $ | (27,426 | ) |  | $ | — |  |  | $ | (27,426 | ) |

[0000866374-19-000013:notes:150]
[same as prior period, unchanged from 0000866374-19-000010:notes:145]

[0000866374-19-000013:notes:151]
[same as prior period, unchanged from 0000866374-19-000010:notes:146]

[0000866374-19-000013:notes:152]
|  | As of September 27, 2019 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | — |  |  | — |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due November 2021 | 421,563 |  |  | 423,671 |  |  | 671,563 |  |  | 670,724 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 453,946 |  |  | 458,531 |  |  | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 533,977 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,224 |  |  | 311,224 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,037 |  |  | 637,084 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 448,277 |  |  | 473,116 |  |  | — |  |  | — |  |  | Level 1 |
| India Facilities | 110,258 |  |  | 110,258 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |
| Euro Term Loan due September 2020 | 50,679 |  |  | 50,679 |  |  | 52,746 |  |  | 52,746 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 109,577 |  |  | 109,577 |  |  | 112,524 |  |  | 112,524 |  |  | Level 2 |
| Total | $ | 3,000,865 |  |  | $ | 3,103,532 |  |  | $ | 3,062,385 |  |  | $ | 3,063,998 |  |  |  |

[0000866374-19-000013:notes:153]
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans due September 2020 and January 2022 based on the current market rate, and as of September 27, 2019, the carrying amounts approximate fair values.
The Term Loans due November 2021 and June 2022, and the Notes due February 2020, February 2023, June 2025 and June 2029 are valued based on broker trading prices in active markets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-19-000013:notes:154]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-19-000013:notes:155]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-19-000013:notes:156]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-19-000013:notes:157]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

[0000866374-19-000013:notes:158]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. Lead plaintiff’s deadline to file a further amended complaint is November 8, 2019, and Defendants’ deadline to move to dismiss is December 4, 2019. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-19-000013:notes:159]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously

[0000866374-19-000013:notes:160]
shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-19-000013:notes:161]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There are six tax assessments totaling 360 million Brazilian reals (approximately USD $86.2 million based on the exchange rate as of September 27, 2019). The assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totally approximately 54 million Brazilian reals or USD $12.9 million), but that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-19-000013:notes:162]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter which is ongoing. The Company cannot predict how long it will take to complete the investigation or to what extent the Company could be subject to penalties.

[0000866374-19-000013:notes:163]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes. As the final resolution of the assessment remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-19-000013:notes:164]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-19-000013:notes:165]
SHARE REPURCHASES 
During the three and six-month periods ended September 27, 2019, the Company repurchased 5.9 million and 11.0 million shares at an aggregate purchase price of $60.2 million and $112.2 million, respectively, and retired all of these shares.

[0000866374-19-000013:notes:166]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 20, 2019. As of September 27, 2019, shares in the aggregate amount of $463.0 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-19-000013:notes:167]
[same as prior period, unchanged from 0000866374-19-000010:notes:164]

[0000866374-19-000013:notes:168]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include

[0000866374-19-000013:notes:169]
amortization of intangibles, stock-based compensation, customer related asset impairment charges, restructuring charges, the new revenue standard adoption impact, legal and other, interest and other, net and other charges (income), net.

[0000866374-19-000013:notes:170]
[same as prior period, unchanged from 0000866374-19-000010:notes:166]

[0000866374-19-000013:notes:171]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2019 |  | September 28, 2018 |  | September 27, 2019 |  | September 28, 2018 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| High Reliability Solutions | $ | 1,188,631 |  |  | $ | 1,207,971 |  |  | $ | 2,366,674 |  |  | $ | 2,423,396 |  |
| Industrial & Emerging Industries | 1,785,568 |  |  | 1,565,953 |  |  | 3,422,482 |  |  | 3,012,264 |  |
| Communications & Enterprise Compute | 1,728,597 |  |  | 2,140,797 |  |  | 3,587,446 |  |  | 4,095,083 |  |
| Consumer Technologies Group | 1,385,258 |  |  | 1,747,883 |  |  | 2,887,391 |  |  | 3,530,817 |  |
|  | $ | 6,088,054 |  |  | $ | 6,662,604 |  |  | $ | 12,263,993 |  |  | $ | 13,061,560 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| High Reliability Solutions | $ | 83,400 |  |  | $ | 89,589 |  |  | $ | 170,632 |  |  | $ | 183,123 |  |
| Industrial & Emerging Industries | 111,354 |  |  | 65,857 |  |  | 206,811 |  |  | 117,218 |  |
| Communications & Enterprise Compute | 31,634 |  |  | 62,855 |  |  | 57,781 |  |  | 108,873 |  |
| Consumer Technologies Group | 26,992 |  |  | 31,212 |  |  | 57,108 |  |  | 57,769 |  |
| Corporate and Other | (26,238 | ) |  | (25,983 | ) |  | (57,330 | ) |  | (55,745 | ) |
| Total segment income | 227,142 |  |  | 223,530 |  |  | 435,002 |  |  | 411,238 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 16,223 |  |  | 18,234 |  |  | 33,305 |  |  | 36,751 |  |
| Stock-based compensation | 18,890 |  |  | 19,081 |  |  | 34,117 |  |  | 40,034 |  |
| Customer related asset impairments (1) | 90,973 |  |  | — |  |  | 91,456 |  |  | 17,364 |  |
| Restructuring charges (Note 17) | 128,315 |  |  | 25,773 |  |  | 184,507 |  |  | 34,590 |  |
| New revenue standard adoption impact (Note 4) | — |  |  | — |  |  | — |  |  | 9,291 |  |
| Legal and other (2) | 19,538 |  |  | 4,058 |  |  | 21,148 |  |  | 20,369 |  |
| Interest and other, net | 47,749 |  |  | 41,060 |  |  | 99,443 |  |  | 82,802 |  |
| Other charges (income), net (Note 9) | 1,147 |  |  | 6,530 |  |  | 2,610 |  |  | (80,394 | ) |
| Income (loss) before income taxes | $ | (95,693 | ) |  | $ | 108,794 |  |  | $ | (31,584 | ) |  | $ | 250,431 |  |

[0000866374-19-000013:notes:172]
| (1) | Customer related asset impairments for the three-month and six-month periods ended September 27, 2019 primarily relate to additional provision for doubtful accounts receivable, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand as the Company reduces its exposure to certain higher volatility businesses. |

[0000866374-19-000013:notes:173]
Customer related asset impairments for the six-month period ended September 28, 2018 relate to additional provision for doubtful accounts receivable and reserves on inventory for certain customers experiencing financial difficulties.

[0000866374-19-000013:notes:174]
| (2) | Legal and other during the three-month and six-month periods ended September 27, 2019 primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India. |

[0000866374-19-000013:notes:175]
Legal and other during the three and six-month periods ended September 28, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018.

[0000866374-19-000013:notes:176]
[same as prior period, unchanged from 0000866374-19-000010:notes:170]

[0000866374-19-000013:notes:177]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled on the

[0000866374-19-000013:notes:178]
operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segments nor reported by segment to the Company's CODM.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-19-000013:notes:179]
RESTRUCTURING CHARGES
During fiscal year 2019, the Company took actions to optimize its portfolio with greater focus to be placed on higher margin, less volatile businesses. During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and streamline its cost structure. During the three and six-month periods ended September 27, 2019, the Company recognized $128.3 million and $184.5 million, respectively, of restructuring charges. The Company incurred cash charges of approximately $97.0 million and $127.8 million, respectively, that were predominantly for employee severance, and non-cash charges of $31.3 million and $56.7 million, respectively, primarily related to asset impairments during the three and six-month periods ended September 27, 2019. The Company expects to complete these activities during fiscal year 2020.

[0000866374-19-000013:notes:180]
During the three and six-month periods ended September 28, 2018, the Company recognized $25.8 million and $34.6 million, respectively, for charges primarily associated with the wind down of its NIKE operations in Mexico, the majority of which were for non-cash asset impairments.

[0000866374-19-000013:notes:181]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of September 27, 2019 for charges incurred during the six-month period ended September 27, 2019:

[0000866374-19-000013:notes:182]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In thousands) |
| Balance as of March 31, 2019 | $ | 23,234 |  |  | $ | — |  |  | $ | 9,200 |  |  | $ | 32,434 |  |
| Provision for charges incurred during the six-month period ended September 27, 2019 | 91,857 |  |  | 44,621 |  |  | 48,029 |  |  | 184,507 |  |
| Cash payments for charges incurred in the fiscal year 2019 and prior | (10,899 | ) |  | — |  |  | (2,260 | ) |  | (13,159 | ) |
| Cash payments for charges incurred during the six-month period ended September 27, 2019 | (76,453 | ) |  | — |  |  | (552 | ) |  | (77,005 | ) |
| Non-cash charges incurred during the six-month period ended September 27, 2019 | — |  |  | (44,621 | ) |  | (13,073 | ) |  | (57,694 | ) |
| Balance as of September 27, 2019 | 27,739 |  |  | — |  |  | 41,344 |  |  | 69,083 |  |
| Less: Current portion (classified as other current liabilities) | 27,739 |  |  | — |  |  | 41,344 |  |  | 69,083 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
