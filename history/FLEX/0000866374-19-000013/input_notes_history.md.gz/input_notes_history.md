# FLEX note change history — 0000866374-19-000010 → 0000866374-19-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000866374-19-000013:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters
  (was, 2019-07-26, similarity 0.6939):
[0000866374-19-000010:note_history:1]
Litigation and other legal matters

- added (2019-10-30):
[0000866374-19-000013:note_history:2]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

- added (2019-10-30):
[0000866374-19-000013:note_history:3]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

- changed (2019-10-30):
[0000866374-19-000013:note_history:4]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. Lead plaintiff’s deadline to file a further amended complaint is November 8, 2019, and Defendants’ deadline to move to dismiss is December 4, 2019. The Company believes that the claims are without merit and intends to vigorously defend this case.
  (was, 2019-07-26, similarity 0.7853):
[0000866374-19-000010:note_history:4]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process.   A hearing on the motions to serve as lead plaintiff is scheduled for September 26, 2019. A case management conference is scheduled for October 9, 2019. The Company believes that the claims are without merit and intends to vigorously defend this case.

- added (2019-10-30):
[0000866374-19-000013:note_history:5]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously

- changed (2019-10-30):
[0000866374-19-000013:note_history:6]
shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.
  (was, 2019-07-26, similarity 0.745):
[0000866374-19-000010:note_history:6]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- added (2019-10-30):
[0000866374-19-000013:note_history:7]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There are six tax assessments totaling 360 million Brazilian reals (approximately USD $86.2 million based on the exchange rate as of September 27, 2019). The assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totally approximately 54 million Brazilian reals or USD $12.9 million), but that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

- changed (2019-10-30):
[0000866374-19-000013:note_history:8]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter which is ongoing. The Company cannot predict how long it will take to complete the investigation or to what extent the Company could be subject to penalties.
  (was, 2019-07-26, similarity 0.9442):
[0000866374-19-000010:note_history:8]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter. The matter is at a very preliminary stage. The Company cannot predict how long it will take to complete the investigation or to what extent the Company could be subject to penalties.

- changed (2019-10-30):
[0000866374-19-000013:note_history:9]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes. As the final resolution of the assessment remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.
  (was, 2019-07-26, similarity 0.8645):
[0000866374-19-000010:note_history:9]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes. As the final resolution of the assessment remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which

- removed (2019-10-30):
[0000866374-19-000010:note_history:10]
COMMITMENTS AND CONTINGENCIES

- removed (2019-10-30):
[0000866374-19-000010:note_history:11]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

- removed (2019-10-30):
[0000866374-19-000010:note_history:12]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have

- removed (2019-10-30):
[0000866374-19-000010:note_history:13]
licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

- removed (2019-10-30):
[0000866374-19-000010:note_history:14]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 360 million Brazilian reals (approximately USD $93.6 million based on the exchange rate as of June 28, 2019). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

- removed (2019-10-30):
[0000866374-19-000010:note_history:15]
may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000866374-19-000013:note_history:16]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2019 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and six-month periods ended September 27, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020.
  (was, 2019-07-26, similarity 0.8605):
[0000866374-19-000010:note_history:16]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2019 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month periods ended June 28, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020.

- changed (2019-10-30):
[0000866374-19-000013:note_history:17]
The first quarters for fiscal years 2020 and 2019 ended on June 28, 2019, which is comprised of 89 days in the period, and June 29, 2018, which is comprised of 90 days in the period, respectively. The second quarters for fiscal years 2020 and 2019 ended on September 27, 2019 and September 28, 2018, which are comprised of 91 days in both periods.
  (was, 2019-07-26, similarity 0.7258):
[0000866374-19-000010:note_history:17]
The first quarters for fiscal years 2020 and 2019 ended on June 28, 2019, which is comprised of 89 days in the period, and June 29, 2018, which is comprised of 90 days in the period, respectively.

- added (2019-10-30):
[0000866374-19-000013:note_history:18]
In the accompanying condensed consolidated statements of operations $26.8 million and $29.0 million of expenses incurred in the three-month and six-month periods ended September 28, 2018, respectively, that were previously included as cost of sales have been reclassified as restructuring charges to conform with the current period presentation. Also, as previously disclosed, the Company has made certain immaterial corrections to net sales previously reported for the first and second quarters of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result of correcting these errors, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month and six-month periods ended September 28, 2018 have been reduced by $48 million and $73 million, respectively, from previously reported amounts. These corrections had no impact on gross profit, segment income or net income for the periods presented. Amounts presented for the three-month and six-month periods ended September 28, 2018 related to the disaggregation of revenue in the CTG segment in Note 4, and CTG segment net sales and total net sales in Note 16, have also been restated accordingly. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to the previously issued financial statements.

- changed (2019-10-30):
[0000866374-19-000013:note_history:19]
The Company adopted ASC 842 on April 1, 2019 using the modified retrospective method on the effective date. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before the Company's adoption date. The Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. In addition, the Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for its leases, the Company uses its estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company’s estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company’s leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.
  (was, 2019-07-26, similarity 0.9938):
[0000866374-19-000010:note_history:19]
The Company adopted ASC 842 on April 1, 2019 using the modified retrospective method on the effective date. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before our adoption date. The Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. In addition, the Company has elected the short term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date).As the Company cannot determine the interest rate implicit in the lease for its leases, as such the Company uses its estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company’s estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company’s leases includes the noncancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

- changed (2019-10-30):
[0000866374-19-000013:note_history:20]
As a result of adopting ASC 842 as of April 1, 2019, the Company recognized additional operating liabilities of $658 million with a corresponding ROU asset of $624 million and a deferred gain of $22 million for sale leaseback transactions to opening retained earnings.
  (was, 2019-07-26, similarity 0.967):
[0000866374-19-000010:note_history:20]
As a result of adopting ASC 842 as of April 1, 2019, the Company recognized additional operating liabilities of $705 million with a corresponding ROU asset of $669 million and a deferred gain of $22 million for sale leaseback transactions to prior year retained earnings.

- added (2019-10-30):
[0000866374-19-000013:note_history:21]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing

- changed (2019-10-30):
[0000866374-19-000013:note_history:22]
arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company early adopted the guidance during the second quarter of fiscal year 2020 with an immaterial impact to its condensed consolidated financial statements.
  (was, 2019-07-26, similarity 0.7535):
[0000866374-19-000010:note_history:22]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects to early adopt the guidance, during fiscal year 2020, and does not expect a material impact to its condensed consolidated financial statements.

- changed (2019-10-30):
[0000866374-19-000013:note_history:23]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.
  (was, 2019-07-26, similarity 0.6709):
[0000866374-19-000010:note_history:23]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for

- added (2019-10-30):
[0000866374-19-000013:note_history:24]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04 and ASU 2019-05, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is currently assessing and expects the new guidance to have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

- removed (2019-10-30):
[0000866374-19-000010:note_history:25]
As previously disclosed, the Company has made certain immaterial corrections to net sales previously reported for the first quarter of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month period ended June 29, 2018 are $25 million lower than previously reported for the first quarter of fiscal year 2019. These corrections had no impact on gross profit, segment income or net income for the period presented. Amounts presented for the first quarter of fiscal year 2019 related to the disaggregation of revenue in the CTG segment in Note 4, and CTG segment net sales and total net sales in Note 16, have also been restated accordingly. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to the previously issued financial statements.

- removed (2019-10-30):
[0000866374-19-000010:note_history:26]
nonemployee share-based payment transactions in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

- removed (2019-10-30):
[0000866374-19-000010:note_history:27]
In November 2018, the FASB issued ASU 2018-19 “Codification Improvements to Topic 326: Financial Instruments - Credit Losses” to introduce an expected credit loss methodology for the impairment of financial assets measured at amortized cost basis. That methodology replaces the probable, incurred loss model for those assets. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is currently assessing and expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000866374-19-000013:note_history:28]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 27, 2019 are as follows:
  (was, 2019-07-26, similarity 0.9463):
[0000866374-19-000010:note_history:28]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 28, 2019 are as follows:

- changed (2019-10-30):
[0000866374-19-000013:note_history:29]
|  | As of September 27, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,224 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,037 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,277 |  |  | — |  |
| India Facilities | 110,258 |  |  | 170,206 |  |
| Other | 162,992 |  |  | 168,039 |  |
| Debt issuance costs | (13,273 | ) |  | (10,639 | ) |
|  | 2,990,328 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (32,450 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,957,878 |  |  | $ | 2,421,904 |  |
  (was, 2019-07-26, similarity 0.8139):
[0000866374-19-000010:note_history:29]
|  | As of June 28, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 250,008 |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,455 |  |  | — |  |
| 4.75% Notes due June 2025 | 596,925 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,232 |  |  | — |  |
| India Facilities (1) | 102,108 |  |  | 170,206 |  |
| Other | 169,385 |  |  | 168,039 |  |
| Debt issuance costs | (14,195 | ) |  | (10,639 | ) |
|  | 3,237,731 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (275,937 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,961,794 |  |  | $ | 2,421,904 |  |

- changed (2019-10-30):
[0000866374-19-000013:note_history:30]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.2% as of September 27, 2019 and March 31, 2019.
  (was, 2019-07-26, similarity 0.9174):
[0000866374-19-000010:note_history:30]
The weighted-average interest rate for the Company's long-term debt was 4.2% as of June 28, 2019 and March 31, 2019.

- changed (2019-10-30):
[0000866374-19-000013:note_history:31]
During the first quarter of fiscal year 2020, and as further discussed below, the Company entered into a JPY33.525 billion term loan agreement due April 2024, in addition to issuing $450 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay the outstanding balance of the Company's existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021. As both transactions were determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during the three-month and six-month periods ended September 27, 2019, which was recorded in interest and other, net on the condensed consolidated statements of operations during the period.
  (was, 2019-07-26, similarity 0.9361):
[0000866374-19-000010:note_history:31]
During the first quarter of fiscal year 2020, and as further discussed below, the Company entered into a JPY33.525 billion term loan agreement due April 2024, in addition to issuing $450 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay $250 million of the Company's existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021. As both transactions were determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during the three-month period ended June 28, 2019, which was recorded in interest and other, net on the condensed consolidated statements of operations during the period.

- changed (2019-10-30):
[0000866374-19-000013:note_history:32]
Scheduled repayments of the Company's long-term debt as of September 27, 2019 are as follows:
  (was, 2019-07-26, similarity 0.9357):
[0000866374-19-000010:note_history:32]
Scheduled repayments of the Company's long-term debt as of June 28, 2019 are as follows:

- changed (2019-10-30):
[0000866374-19-000013:note_history:33]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2020 (1) |  | $ | 19,529 |  |
| 2021 |  | 98,849 |  |
| 2022 |  | 607,940 |  |
| 2023 |  | 857,571 |  |
| 2024 |  | 60,438 |  |
| Thereafter |  | 1,359,274 |  |
| Total |  | $ | 3,003,601 |  |
  (was, 2019-07-26, similarity 0.9494):
[0000866374-19-000010:note_history:33]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2020 (1) | $ | 269,918 |  |
| 2021 | 100,761 |  |
| 2022 | 603,979 |  |
| 2023 | 857,571 |  |
| 2024 | 60,438 |  |
| Thereafter | 1,359,259 |  |
| Total | $ | 3,251,926 |  |

- changed (2019-10-30):
[0000866374-19-000013:note_history:34]
| (1) | Represents estimated repayments for the remaining six-month period ending March 31, 2020. |
  (was, 2019-07-26, similarity 0.9733):
[0000866374-19-000010:note_history:34]
| (1) | Represents estimated repayments for the remaining nine-month period ending March 31, 2020. |

- changed (2019-10-30):
[0000866374-19-000013:note_history:35]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency
  (was, 2019-07-26, similarity 0.8543):
[0000866374-19-000010:note_history:35]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is

- changed (2019-10-30):
[0000866374-19-000013:note_history:36]
contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 10 for additional details.
  (was, 2019-07-26, similarity 0.688):
[0000866374-19-000010:note_history:36]
denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 10 for additional details.

- changed (2019-10-30):
[0000866374-19-000013:note_history:37]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of September 27, 2019, the Company was in compliance with the covenants under this term loan agreement.
  (was, 2019-07-26, similarity 0.9326):
[0000866374-19-000010:note_history:37]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term.

- changed (2019-10-30):
[0000866374-19-000013:note_history:38]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of September 27, 2019, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.
  (was, 2019-07-26, similarity 0.9954):
[0000866374-19-000010:note_history:38]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of June 28, 2019, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.

- removed (2019-10-30):
[0000866374-19-000010:note_history:39]
| (1) | The balance as of June 28, 2019 reflects the outstanding drawdown from the $200 million term loan facility entered in July 2018. There was no outstanding balance as of June 28, 2019 related to the short-term bank borrowings facility entered in February 2019. |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000866374-19-000013:note_history:40]
|  | As of September 27, 2019 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | — |  |  | — |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due November 2021 | 421,563 |  |  | 423,671 |  |  | 671,563 |  |  | 670,724 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 453,946 |  |  | 458,531 |  |  | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 533,977 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,224 |  |  | 311,224 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,037 |  |  | 637,084 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 448,277 |  |  | 473,116 |  |  | — |  |  | — |  |  | Level 1 |
| India Facilities | 110,258 |  |  | 110,258 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |
| Euro Term Loan due September 2020 | 50,679 |  |  | 50,679 |  |  | 52,746 |  |  | 52,746 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 109,577 |  |  | 109,577 |  |  | 112,524 |  |  | 112,524 |  |  | Level 2 |
| Total | $ | 3,000,865 |  |  | $ | 3,103,532 |  |  | $ | 3,062,385 |  |  | $ | 3,063,998 |  |  |  |
  (was, 2019-07-26, similarity 0.9647):
[0000866374-19-000010:note_history:40]
|  | As of June 28, 2019 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 250,008 |  |  | $ | 252,819 |  |  | $ | 500,000 |  |  | $ | 499,950 |  |  | Level 1 |
| Term Loan due November 2021 | 421,563 |  |  | 424,725 |  |  | 671,563 |  |  | 670,724 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 454,511 |  |  | 458,531 |  |  | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 526,881 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,455 |  |  | 311,455 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 596,925 |  |  | 619,267 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 448,232 |  |  | 455,449 |  |  | — |  |  | — |  |  | Level 1 |
| India Facilities | 102,108 |  |  | 102,108 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |
| Euro Term Loan due September 2020 | 52,972 |  |  | 52,972 |  |  | 52,746 |  |  | 52,746 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 113,766 |  |  | 113,766 |  |  | 112,524 |  |  | 112,524 |  |  | Level 2 |
| Total | $ | 3,249,279 |  |  | $ | 3,313,953 |  |  | $ | 3,062,385 |  |  | $ | 3,063,998 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000866374-19-000013:note_history:41]
Bank borrowings and long-term debt as of September 27, 2019 are as follows:
  (was, 2019-07-26, similarity 0.9185):
[0000866374-19-000010:note_history:41]
Bank borrowings and long-term debt as of June 28, 2019 are as follows:

- changed (2019-10-30):
[0000866374-19-000013:note_history:42]
|  | As of September 27, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,224 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,037 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,277 |  |  | — |  |
| India Facilities | 110,258 |  |  | 170,206 |  |
| Other | 162,992 |  |  | 168,039 |  |
| Debt issuance costs | (13,273 | ) |  | (10,639 | ) |
|  | 2,990,328 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (32,450 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,957,878 |  |  | $ | 2,421,904 |  |
  (was, 2019-07-26, similarity 0.8139):
[0000866374-19-000010:note_history:42]
|  | As of June 28, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 250,008 |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,455 |  |  | — |  |
| 4.75% Notes due June 2025 | 596,925 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,232 |  |  | — |  |
| India Facilities (1) | 102,108 |  |  | 170,206 |  |
| Other | 169,385 |  |  | 168,039 |  |
| Debt issuance costs | (14,195 | ) |  | (10,639 | ) |
|  | 3,237,731 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (275,937 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,961,794 |  |  | $ | 2,421,904 |  |

- removed (2019-10-30):
[0000866374-19-000010:note_history:43]
(1)

- removed (2019-10-30):
[0000866374-19-000010:note_history:44]
The balance as of June 28, 2019 reflects the outstanding drawdown from the $200 million term loan facility entered in July 2018. There was no outstanding balance as of June 28, 2019 related to the short-term bank borrowings facility entered in February 2019.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000866374-19-000013:note_history:45]
Scheduled repayments of the Company's long-term debt as of September 27, 2019 are as follows:
  (was, 2019-07-26, similarity 0.9357):
[0000866374-19-000010:note_history:45]
Scheduled repayments of the Company's long-term debt as of June 28, 2019 are as follows:

- changed (2019-10-30):
[0000866374-19-000013:note_history:46]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2020 (1) |  | $ | 19,529 |  |
| 2021 |  | 98,849 |  |
| 2022 |  | 607,940 |  |
| 2023 |  | 857,571 |  |
| 2024 |  | 60,438 |  |
| Thereafter |  | 1,359,274 |  |
| Total |  | $ | 3,003,601 |  |
  (was, 2019-07-26, similarity 0.9494):
[0000866374-19-000010:note_history:46]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2020 (1) | $ | 269,918 |  |
| 2021 | 100,761 |  |
| 2022 | 603,979 |  |
| 2023 | 857,571 |  |
| 2024 | 60,438 |  |
| Thereafter | 1,359,259 |  |
| Total | $ | 3,251,926 |  |

- changed (2019-10-30):
[0000866374-19-000013:note_history:47]
Represents estimated repayments for the remaining six-month period ending March 31, 2020.
  (was, 2019-07-26, similarity 0.9701):
[0000866374-19-000010:note_history:47]
Represents estimated repayments for the remaining nine-month period ending March 31, 2020.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000866374-19-000013:note_history:48]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended September 27, 2019 and September 28, 2018 (in thousands), respectively.
  (was, 2019-07-26, similarity 0.8813):
[0000866374-19-000010:note_history:48]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 28, 2019 and June 29, 2018 (in thousands), respectively.

- changed (2019-10-30):
[0000866374-19-000013:note_history:49]
|  | Three-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 942,113 |  |  | $ | 1,147,976 |  |  | $ | 1,390,059 |  |  | $ | 1,103,855 |  |  | $ | 4,584,003 |  |
| Over time | 246,518 |  |  | 637,592 |  |  | 338,538 |  |  | 281,403 |  |  | 1,504,051 |  |
| Total segment | $ | 1,188,631 |  |  | $ | 1,785,568 |  |  | $ | 1,728,597 |  |  | $ | 1,385,258 |  |  | $ | 6,088,054 |  |
  (was, 2019-07-26, similarity 0.9803):
[0000866374-19-000010:note_history:49]
|  | Three-Month Period Ended June 28, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 923,727 |  |  | $ | 1,115,059 |  |  | $ | 1,359,365 |  |  | $ | 1,024,626 |  |  | $ | 4,422,777 |  |
| Over time | 254,316 |  |  | 521,855 |  |  | 499,484 |  |  | 477,507 |  |  | 1,753,162 |  |
| Total segment | $ | 1,178,043 |  |  | $ | 1,636,914 |  |  | $ | 1,858,849 |  |  | $ | 1,502,133 |  |  | $ | 6,175,939 |  |

- changed (2019-10-30):
[0000866374-19-000013:note_history:50]
|  | Six-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,865,840 |  |  | $ | 2,263,035 |  |  | $ | 2,749,423 |  |  | $ | 2,128,481 |  |  | $ | 9,006,779 |  |
| Over time | 500,834 |  |  | 1,159,447 |  |  | 838,023 |  |  | 758,910 |  |  | 3,257,214 |  |
| Total segment | $ | 2,366,674 |  |  | $ | 3,422,482 |  |  | $ | 3,587,446 |  |  | $ | 2,887,391 |  |  | $ | 12,263,993 |  |
  (was, 2019-07-26, similarity 0.9681):
[0000866374-19-000010:note_history:50]
|  | Three-Month Period Ended June 29, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 1,298,137 |  |  | $ | 4,860,722 |  |
| Over time | 210,245 |  |  | 382,413 |  |  | 460,779 |  |  | 484,797 |  |  | 1,538,234 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 1,782,934 |  |  | $ | 6,398,956 |  |

- added (2019-10-30):
[0000866374-19-000013:note_history:51]
|  | Three-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 893,141 |  |  | $ | 1,089,319 |  |  | $ | 1,519,041 |  |  | $ | 1,201,696 |  |  | $ | 4,703,197 |  |
| Over time | 314,830 |  |  | 476,634 |  |  | 621,756 |  |  | 546,187 |  |  | 1,959,407 |  |
| Total segment | $ | 1,207,971 |  |  | $ | 1,565,953 |  |  | $ | 2,140,797 |  |  | $ | 1,747,883 |  |  | $ | 6,662,604 |  |

- added (2019-10-30):
[0000866374-19-000013:note_history:52]
|  | Six-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,898,321 |  |  | $ | 2,153,218 |  |  | $ | 3,012,548 |  |  | $ | 2,499,833 |  |  | $ | 9,563,920 |  |
| Over time | 525,075 |  |  | 859,046 |  |  | 1,082,535 |  |  | 1,030,984 |  |  | 3,497,640 |  |
| Total segment | $ | 2,423,396 |  |  | $ | 3,012,264 |  |  | $ | 4,095,083 |  |  | $ | 3,530,817 |  |  | $ | 13,061,560 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000866374-19-000013:note_history:53]
REVENUE 
Revenue Recognition
  (was, 2019-07-26, similarity 0.8261):
[0000866374-19-000010:note_history:53]
Revenue Recognition

- added (2019-10-30):
[0000866374-19-000013:note_history:54]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first

- changed (2019-10-30):
[0000866374-19-000013:note_history:55]
required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.
  (was, 2019-07-26, similarity 0.7588):
[0000866374-19-000010:note_history:55]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- changed (2019-10-30):
[0000866374-19-000013:note_history:56]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.
  (was, 2019-07-26, similarity 0.9995):
[0000866374-19-000010:note_history:56]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer related accruals in note 2.

- changed (2019-10-30):
[0000866374-19-000013:note_history:57]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).
  (was, 2019-07-26, similarity 0.9172):
[0000866374-19-000010:note_history:57]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to

- changed (2019-10-30):
[0000866374-19-000013:note_history:58]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $341.5 million and $271.8 million as of September 27, 2019 and March 31, 2019, respectively.
  (was, 2019-07-26, similarity 0.9786):
[0000866374-19-000010:note_history:58]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $329.8 million and $271.8 million as of June 28, 2019 and March 31, 2019, respectively.

- changed (2019-10-30):
[0000866374-19-000013:note_history:59]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended September 27, 2019 and September 28, 2018 (in thousands), respectively.
  (was, 2019-07-26, similarity 0.8813):
[0000866374-19-000010:note_history:59]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 28, 2019 and June 29, 2018 (in thousands), respectively.

- changed (2019-10-30):
[0000866374-19-000013:note_history:60]
|  | Three-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 942,113 |  |  | $ | 1,147,976 |  |  | $ | 1,390,059 |  |  | $ | 1,103,855 |  |  | $ | 4,584,003 |  |
| Over time | 246,518 |  |  | 637,592 |  |  | 338,538 |  |  | 281,403 |  |  | 1,504,051 |  |
| Total segment | $ | 1,188,631 |  |  | $ | 1,785,568 |  |  | $ | 1,728,597 |  |  | $ | 1,385,258 |  |  | $ | 6,088,054 |  |
  (was, 2019-07-26, similarity 0.9803):
[0000866374-19-000010:note_history:60]
|  | Three-Month Period Ended June 28, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 923,727 |  |  | $ | 1,115,059 |  |  | $ | 1,359,365 |  |  | $ | 1,024,626 |  |  | $ | 4,422,777 |  |
| Over time | 254,316 |  |  | 521,855 |  |  | 499,484 |  |  | 477,507 |  |  | 1,753,162 |  |
| Total segment | $ | 1,178,043 |  |  | $ | 1,636,914 |  |  | $ | 1,858,849 |  |  | $ | 1,502,133 |  |  | $ | 6,175,939 |  |

- changed (2019-10-30):
[0000866374-19-000013:note_history:61]
|  | Six-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,865,840 |  |  | $ | 2,263,035 |  |  | $ | 2,749,423 |  |  | $ | 2,128,481 |  |  | $ | 9,006,779 |  |
| Over time | 500,834 |  |  | 1,159,447 |  |  | 838,023 |  |  | 758,910 |  |  | 3,257,214 |  |
| Total segment | $ | 2,366,674 |  |  | $ | 3,422,482 |  |  | $ | 3,587,446 |  |  | $ | 2,887,391 |  |  | $ | 12,263,993 |  |
  (was, 2019-07-26, similarity 0.9681):
[0000866374-19-000010:note_history:61]
|  | Three-Month Period Ended June 29, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 1,298,137 |  |  | $ | 4,860,722 |  |
| Over time | 210,245 |  |  | 382,413 |  |  | 460,779 |  |  | 484,797 |  |  | 1,538,234 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 1,782,934 |  |  | $ | 6,398,956 |  |

- added (2019-10-30):
[0000866374-19-000013:note_history:62]
|  | Three-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 893,141 |  |  | $ | 1,089,319 |  |  | $ | 1,519,041 |  |  | $ | 1,201,696 |  |  | $ | 4,703,197 |  |
| Over time | 314,830 |  |  | 476,634 |  |  | 621,756 |  |  | 546,187 |  |  | 1,959,407 |  |
| Total segment | $ | 1,207,971 |  |  | $ | 1,565,953 |  |  | $ | 2,140,797 |  |  | $ | 1,747,883 |  |  | $ | 6,662,604 |  |

- added (2019-10-30):
[0000866374-19-000013:note_history:63]
|  | Six-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,898,321 |  |  | $ | 2,153,218 |  |  | $ | 3,012,548 |  |  | $ | 2,499,833 |  |  | $ | 9,563,920 |  |
| Over time | 525,075 |  |  | 859,046 |  |  | 1,082,535 |  |  | 1,030,984 |  |  | 3,497,640 |  |
| Total segment | $ | 2,423,396 |  |  | $ | 3,012,264 |  |  | $ | 4,095,083 |  |  | $ | 3,530,817 |  |  | $ | 13,061,560 |  |

- removed (2019-10-30):
[0000866374-19-000010:note_history:64]
REVENUE

- removed (2019-10-30):
[0000866374-19-000010:note_history:65]
transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g.: procurement of materials and standard workmanship warranty).
