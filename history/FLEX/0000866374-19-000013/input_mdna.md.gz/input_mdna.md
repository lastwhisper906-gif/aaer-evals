# FLEX MD&A — 0000866374-19-000013


## mdna

[0000866374-19-000013:mdna:1]
[same as prior period, unchanged from 0000866374-19-000010:mdna:1]

[0000866374-19-000013:mdna:2]
[same as prior period, unchanged from 0000866374-19-000010:mdna:2]

[0000866374-19-000013:mdna:3]
32

[0000866374-19-000013:mdna:4]
risks emerge from time to time and it is not possible for management to predict all such risk factors or to assess the impact of such risk factors on our business. Accordingly, our future results may differ materially from historical results or from those discussed or implied by these forward-looking statements. Given these risks and uncertainties, the reader should not place undue reliance on these forward-looking statements.

[0000866374-19-000013:mdna:5]
[same as prior period, unchanged from 0000866374-19-000010:mdna:3]

[0000866374-19-000013:mdna:6]
[same as prior period, unchanged from 0000866374-19-000010:mdna:4]

[0000866374-19-000013:mdna:7]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including surgical equipment, drug delivery, diagnostics, telemedicine, disposable devices, imaging and monitoring, patient mobility and ophthalmology; and our automotive business, including vehicle electrification, connectivity, autonomous, and smart technologies; |

[0000866374-19-000013:mdna:8]
[same as prior period, unchanged from 0000866374-19-000010:mdna:8]

[0000866374-19-000013:mdna:9]
[same as prior period, unchanged from 0000866374-19-000010:mdna:9]

[0000866374-19-000013:mdna:10]
[same as prior period, unchanged from 0000866374-19-000010:mdna:10]

[0000866374-19-000013:mdna:11]
[same as prior period, unchanged from 0000866374-19-000010:mdna:11]

[0000866374-19-000013:mdna:12]
[same as prior period, unchanged from 0000866374-19-000010:mdna:12]

[0000866374-19-000013:mdna:13]
[same as prior period, unchanged from 0000866374-19-000010:mdna:13]

[0000866374-19-000013:mdna:14]
[same as prior period, unchanged from 0000866374-19-000010:mdna:14]

[0000866374-19-000013:mdna:15]
During fiscal year 2019, we took actions to optimize our portfolio with greater focus to be placed on higher margin, less volatile businesses. During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. We recognized $185 million of charges during the first half of fiscal year 2020, comprised of approximately $128 million of cash charges predominantly for employee severance, and $57 million of non-cash charges primarily related to asset impairments. While the bulk of the restructuring charges were executed in the first half of fiscal year 2020, we expect to incur

[0000866374-19-000013:mdna:16]
33

[0000866374-19-000013:mdna:17]
additional restructuring charges throughout the remainder of fiscal year 2020, with the expectation to complete these activities by the end of the fiscal year.

[0000866374-19-000013:mdna:18]
[same as prior period, unchanged from 0000866374-19-000010:mdna:17]

[0000866374-19-000013:mdna:19]
We are one of the world's largest providers of global supply chain solutions, with revenues of $12.3 billion for the six-month period ended September 27, 2019 and $26.2 billion in fiscal year 2019. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-19-000013:mdna:20]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Net sales: | September 27, 2019 |  | September 28, 2018 |  | September 27, 2019 |  | September 28, 2018 |
|  | (In millions) |
| China | $ | 1,446 |  |  | 24 | % |  | $ | 1,730 |  |  | 26 | % |  | $ | 2,897 |  |  | 24 | % |  | $ | 3,400 |  |  | 26 | % |
| Mexico | 1,158 |  |  | 19 | % |  | 1,179 |  |  | 18 | % |  | 2,237 |  |  | 18 | % |  | 2,291 |  |  | 18 | % |
| U.S. | 907 |  |  | 15 | % |  | 782 |  |  | 12 | % |  | 1,711 |  |  | 14 | % |  | 1,288 |  |  | 10 | % |
| Brazil | 489 |  |  | 8 | % |  | 533 |  |  | 8 | % |  | 1,044 |  |  | 9 | % |  | 1,120 |  |  | 9 | % |
| Malaysia | 408 |  |  | 7 | % |  | 550 |  |  | 8 | % |  | 834 |  |  | 7 | % |  | 1,018 |  |  | 8 | % |
| India | 304 |  |  | 5 | % |  | 421 |  |  | 6 | % |  | 793 |  |  | 6 | % |  | 884 |  |  | 7 | % |
| Other | 1,376 |  |  | 22 | % |  | 1,468 |  |  | 22 | % |  | 2,748 |  |  | 22 | % |  | 3,061 |  |  | 22 | % |
|  | $ | 6,088 |  |  |  |  |  | $ | 6,663 |  |  |  |  |  | $ | 12,264 |  |  |  |  |  | $ | 13,062 |  |  |  |  |

[0000866374-19-000013:mdna:21]
[same as prior period, unchanged from 0000866374-19-000010:mdna:21]

[0000866374-19-000013:mdna:22]
In the accompanying condensed consolidated statements of operations $26.8 million and $29.0 million of expenses incurred in the three-month and six-month periods ended September 28, 2018, respectively, that were previously included as cost of sales have been reclassified as restructuring charges to conform with the current period presentation. Also, as previously disclosed, we have made certain immaterial corrections to net sales previously reported for the first and second quarters of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result of correcting these errors, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month and six-month periods ended September 28, 2018 have been reduced by $48 million and $73 million, respectively, from previously reported amounts. These corrections had no impact on gross profit, segment income or net income for the periods presented.

[0000866374-19-000013:mdna:23]
|  | As of |  | As of |
| Property and equipment, net: | September 27, 2019 |  | March 31, 2019 |
|  | (In millions) |
| Mexico | $ | 548 |  |  | 25 | % |  | $ | 537 |  |  | 23 | % |
| China | 419 |  |  | 19 | % |  | 523 |  |  | 22 | % |
| U.S. | 378 |  |  | 17 | % |  | 361 |  |  | 15 | % |
| India | 216 |  |  | 10 | % |  | 219 |  |  | 9 | % |
| Malaysia | 127 |  |  | 6 | % |  | 138 |  |  | 6 | % |
| Hungary | 99 |  |  | 4 | % |  | 103 |  |  | 4 | % |
| Other | 430 |  |  | 19 | % |  | 454 |  |  | 21 | % |
|  | $ | 2,217 |  |  |  |  |  | $ | 2,336 |  |  |  |  |

[0000866374-19-000013:mdna:24]
[same as prior period, unchanged from 0000866374-19-000010:mdna:24]

[0000866374-19-000013:mdna:25]
[same as prior period, unchanged from 0000866374-19-000010:mdna:25]

[0000866374-19-000013:mdna:26]
[same as prior period, unchanged from 0000866374-19-000010:mdna:26]

[0000866374-19-000013:mdna:27]
[same as prior period, unchanged from 0000866374-19-000010:mdna:27]

[0000866374-19-000013:mdna:28]
34

[0000866374-19-000013:mdna:29]
[same as prior period, unchanged from 0000866374-19-000010:mdna:28]

[0000866374-19-000013:mdna:30]
[same as prior period, unchanged from 0000866374-19-000010:mdna:29]

[0000866374-19-000013:mdna:31]
[same as prior period, unchanged from 0000866374-19-000010:mdna:30]

[0000866374-19-000013:mdna:32]
[same as prior period, unchanged from 0000866374-19-000010:mdna:31]

[0000866374-19-000013:mdna:33]
[same as prior period, unchanged from 0000866374-19-000010:mdna:32]

[0000866374-19-000013:mdna:34]
[same as prior period, unchanged from 0000866374-19-000010:mdna:33]

[0000866374-19-000013:mdna:35]
[same as prior period, unchanged from 0000866374-19-000010:mdna:34]

[0000866374-19-000013:mdna:36]
[same as prior period, unchanged from 0000866374-19-000010:mdna:35]

[0000866374-19-000013:mdna:37]
[same as prior period, unchanged from 0000866374-19-000010:mdna:36]

[0000866374-19-000013:mdna:38]
[same as prior period, unchanged from 0000866374-19-000010:mdna:37]

[0000866374-19-000013:mdna:39]
[same as prior period, unchanged from 0000866374-19-000010:mdna:38]

[0000866374-19-000013:mdna:40]
[same as prior period, unchanged from 0000866374-19-000010:mdna:39]

[0000866374-19-000013:mdna:41]
We are also subject to other risks as outline in Part II, Item 1A, “Risk Factors” and Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

[0000866374-19-000013:mdna:42]
[same as prior period, unchanged from 0000866374-19-000010:mdna:40]

[0000866374-19-000013:mdna:43]
[same as prior period, unchanged from 0000866374-19-000010:mdna:41]

[0000866374-19-000013:mdna:44]
[same as prior period, unchanged from 0000866374-19-000010:mdna:42]

[0000866374-19-000013:mdna:45]
[same as prior period, unchanged from 0000866374-19-000010:mdna:43]

[0000866374-19-000013:mdna:46]
We are a lessee with several non-cancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. We determine if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the customer has the right to control the use of the identified asset.

[0000866374-19-000013:mdna:47]
Beginning with the adoption of ASC 842 on April 1, 2019, we recognize a right-of-use (“ROU”) asset and a lease liability at the lease commencement date for our operating leases. For operating leases, the lease liability is initially and subsequently measured at the present value of the unpaid lease payments at the lease commencement date. We have elected the short-term lease recognition and measurement exemption for all classes of assets, which allows us to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option we are reasonably certain of exercising. We have also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As we cannot determine the interest rate implicit in the lease for our leases, as such we use our estimate of the incremental borrowing rate as of the commencement date in determining the present

[0000866374-19-000013:mdna:48]
35

[0000866374-19-000013:mdna:49]
value of lease payments. Our estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of our leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that we are reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-19-000013:mdna:50]
[same as prior period, unchanged from 0000866374-19-000010:mdna:46]

[0000866374-19-000013:mdna:51]
[same as prior period, unchanged from 0000866374-19-000010:mdna:47]

[0000866374-19-000013:mdna:52]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2019 |  | September 28, 2018 |  | September 27, 2019 |  | September 28, 2018 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 95.0 |  |  | 93.6 |  |  | 94.3 |  |  | 93.9 |  |
| Restructuring charges | 1.9 |  |  | 0.4 |  |  | 1.3 |  |  | 0.2 |  |
| Gross profit | 3.1 |  |  | 6.0 |  |  | 4.4 |  |  | 5.9 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.4 |  |  | 3.4 |  |  | 3.6 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges (recoveries) | 0.2 |  |  | 0.0 |  |  | 0.2 |  |  | 0.0 |  |
| Interest and other, net | 0.8 |  |  | 0.6 |  |  | 0.8 |  |  | 0.6 |  |
| Other charges (income), net | 0.0 |  |  | 0.1 |  |  | 0.0 |  |  | (0.6 | ) |
| Income (loss) before income taxes | (1.6 | ) |  | 1.6 |  |  | (0.3 | ) |  | 2.0 |  |
| Provision for income taxes | 0.3 |  |  | 0.3 |  |  | 0.3 |  |  | 0.4 |  |
| Net income (loss) | (1.9 | )% |  | 1.3 | % |  | (0.6 | )% |  | 1.6 | % |

[0000866374-19-000013:mdna:53]
[same as prior period, unchanged from 0000866374-19-000010:mdna:49]

[0000866374-19-000013:mdna:54]
[same as prior period, unchanged from 0000866374-19-000010:mdna:50]

[0000866374-19-000013:mdna:55]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Segments: | September 27, 2019 |  | September 28, 2018 |  | September 27, 2019 |  | September 28, 2018 |
|  | (In millions) |
| High Reliability Solutions | $ | 1,189 |  |  | 20 | % |  | $ | 1,208 |  |  | 18 | % |  | $ | 2,367 |  |  | 19 | % |  | $ | 2,423 |  |  | 19 | % |
| Industrial & Emerging Industries | 1,786 |  |  | 29 | % |  | 1,566 |  |  | 24 | % |  | 3,422 |  |  | 28 | % |  | 3,012 |  |  | 23 | % |
| Communications & Enterprise Compute | 1,729 |  |  | 28 | % |  | 2,141 |  |  | 32 | % |  | 3,587 |  |  | 29 | % |  | 4,095 |  |  | 31 | % |
| Consumer Technologies Group | 1,385 |  |  | 23 | % |  | 1,748 |  |  | 26 | % |  | 2,887 |  |  | 24 | % |  | 3,531 |  |  | 27 | % |
|  | $ | 6,088 |  |  |  |  | $ | 6,663 |  |  |  |  | $ | 12,264 |  |  |  |  | $ | 13,062 |  |  |  |

[0000866374-19-000013:mdna:56]
[same as prior period, unchanged from 0000866374-19-000010:mdna:52]

[0000866374-19-000013:mdna:57]
Net sales during the three-month period ended September 27, 2019 totaled $6.1 billion, representing a decrease of approximately $575 million, or 9% from $6.7 billion during the three-month period ended September 28, 2018. The decrease in sales was driven by softness across our segments with the exception of our IEI segment. Our CTG segment decreased $363 million, primarily resulting from our continued active pruning of underperforming customers and product categories coupled with a reduction and delay in demand with certain customers in India. Our CEC segment decreased $412 million, driven by reduced demand in our networking and telecommunication businesses due to the slower roll-out of 5G technology and our previously announced disengagement with a customer primarily in China and India. Our HRS segment decreased $19 million primarily due to lower demand in our health solution business, partially offset by ramps in our automotive business. These declines were offset by a $220 million increase in our IEI segment, mainly driven by strong sales within our home and lifestyle business in addition to growth in our solar energy business that more than offset declines in capital equipment demand. Net sales decreased $597 million to $2.4 billion in Asia, $47 million to $1.1 billion in Europe, offset by a modest increase of $70 million to $2.6 billion in the Americas.

[0000866374-19-000013:mdna:58]
Net sales during the six-month period ended September 27, 2019 totaled $12.3 billion, representing a decrease of approximately $798 million, or 6% from $13.1 billion during the six-month period ended September 28, 2018. As noted above, the decrease in net sales was notable across all our segments with the exception of our IEI segment, driven by a $0.6 billion decrease in CTG, a $0.5 billion decrease in CEC and a $0.4 billion increase in IEI due to the same factors described above. Net sales decreased $891 million to $4.9 billion in Asia, and $88 million to $2.3 billion in Europe, offset by an increase of $181 million to $5.0 billion in the Americas.

[0000866374-19-000013:mdna:59]
Our ten largest customers, during the three and six-month periods ended September 27, 2019, accounted for approximately 39% of net sales, respectively. Our ten largest customers, during the three and six-month periods ended September 28, 2018, accounted for approximately 43% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and six-month periods ended September 27, 2019 or September 28, 2018.

[0000866374-19-000013:mdna:60]
[same as prior period, unchanged from 0000866374-19-000010:mdna:55]

[0000866374-19-000013:mdna:61]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-19-000013:mdna:62]
Gross profit during the three-month period ended September 27, 2019 decreased $213 million to $189 million, or 3.1% of net sales, from $402 million, or 6.0% of net sales, during the three-month period ended September 28, 2018. Gross profit during the six-month period ended September 27, 2019 decreased $238 million to $542 million, or 4.4% of net sales, from $780 million, or 5.9% of net sales, during the six-month period ended September 28, 2018. Gross margin deteriorated 290 basis points and 150 basis points, respectively, during the three-month and six-month periods ended September 27, 2019. The decrease in both gross profit and gross margin is primarily due to the geopolitical challenges and uncertainties which impacted specific customers resulting in restructuring charges recorded in the first half of fiscal year 2020 as well as the current quarter write down of inventory that will not be recovered due to significant reductions in future customer demand as we reduce our exposure to certain higher volatility businesses. These were partially offset by the favorable product mix and the increased revenues from our IEI segment, the wind-down of our NIKE Mexico operations in the second half of fiscal year 2019, and benefits realized from our earlier restructuring activities initiated in fiscal year 2019.

[0000866374-19-000013:mdna:63]
[same as prior period, unchanged from 0000866374-19-000010:mdna:59]

[0000866374-19-000013:mdna:64]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment charges, restructuring charges, the new revenue standard adoption impact, legal and other, interest and other, net and other charges (income), net.  A portion of depreciation is allocated to the respective segment, together with other general corporate research and development and administrative expenses.

[0000866374-19-000013:mdna:65]
37

[0000866374-19-000013:mdna:66]
[same as prior period, unchanged from 0000866374-19-000010:mdna:61]

[0000866374-19-000013:mdna:67]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2019 |  | September 28, 2018 |  | September 27, 2019 |  | September 28, 2018 |
|  | (In millions) |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High Reliability Solutions | $ | 83 |  |  | 7.0 | % |  | $ | 90 |  |  | 7.4 | % |  | $ | 171 |  |  | 7.2 | % |  | $ | 183 |  |  | 7.6 | % |
| Industrial & Emerging Industries | 111 |  |  | 6.2 | % |  | 66 |  |  | 4.2 | % |  | 207 |  |  | 6.0 | % |  | 117 |  |  | 3.9 | % |
| Communications & Enterprise Compute | 32 |  |  | 1.8 | % |  | 63 |  |  | 2.9 | % |  | 58 |  |  | 1.6 | % |  | 109 |  |  | 2.7 | % |
| Consumer Technologies Group | 27 |  |  | 1.9 | % |  | 31 |  |  | 1.7 | % |  | 57 |  |  | 2.0 | % |  | 58 |  |  | 1.6 | % |
| Corporate and Other | (26 | ) |  |  |  | (26 | ) |  |  |  | (57 | ) |  |  |  | (56 | ) |  |  |
| Total segment income | 227 |  |  | 3.7 | % |  | 224 |  |  | 3.3 | % |  | 435 |  |  | 3.5 | % |  | 411 |  |  | 3.1 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 16 |  |  |  |  | 18 |  |  |  |  | 33 |  |  |  |  | 37 |  |  |  |
| Stock-based compensation | 19 |  |  |  |  | 19 |  |  |  |  | 34 |  |  |  |  | 40 |  |  |  |
| Customer related asset impairments (1) | 91 |  |  |  |  | — |  |  |  |  | 91 |  |  |  |  | 17 |  |  |  |
| Restructuring charges (Note 17) | 128 |  |  |  |  | 26 |  |  |  |  | 185 |  |  |  |  | 35 |  |  |  |
| New revenue standard adoption impact (Note 4) | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 9 |  |  |  |
| Legal and other (2) | 20 |  |  |  |  | 4 |  |  |  |  | 21 |  |  |  |  | 20 |  |  |  |
| Interest and other, net | 48 |  |  |  |  | 41 |  |  |  |  | 99 |  |  |  |  | 83 |  |  |  |
| Other charges (income), net (Note 9) | 1 |  |  |  |  | 7 |  |  |  |  | 3 |  |  |  |  | (80 | ) |  |  |
| Income (loss) before income taxes | $ | (96 | ) |  |  |  | $ | 109 |  |  |  |  | $ | (32 | ) |  |  |  | $ | 250 |  |  |  |
| Amounts may not sum due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-19-000013:mdna:68]
| (1) | Customer related asset impairments for the three-month and six-month periods ended September 27, 2019 primarily relate to additional provision for doubtful accounts receivable, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand as the Company reduces its exposure to certain higher volatility businesses. |

[0000866374-19-000013:mdna:69]
Customer related asset impairments for the six-month period ended September 28, 2018 relate to additional provision for doubtful accounts receivable and reserves on inventory for certain customers experiencing financial difficulties.

[0000866374-19-000013:mdna:70]
| (2) | Legal and other during the three-month and six-month periods ended September 27, 2019 primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India. |

[0000866374-19-000013:mdna:71]
Legal and other during the three and six-month periods ended September 28, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018.

[0000866374-19-000013:mdna:72]
HRS segment margin decreased 40 basis points, to 7.0% for the three-month period ended September 27, 2019, from 7.4% during the three-month period ended September 28, 2018. HRS segment margin decreased 40 basis points, to 7.2% for the six-month period ended September 27, 2019, from 7.6% for the six-month period ended September 28, 2018. The decrease in HRS segment margin during the period is primarily the result of accelerated investments for new program ramp, coupled with demand softness in our health solution business.

[0000866374-19-000013:mdna:73]
IEI segment margin increased 200 basis points, to 6.2% for the three-month period ended September 27, 2019, from 4.2% during the three-month period ended September 28, 2018.  IEI segment margin increased 210 basis points, to 6.0% for the six-month period ended September 27, 2019, from 3.9% for the six-month period ended September 28, 2018. The increase in IEI's margin during the period is primarily due to a favorable mix resulting from operational execution on the new business that is ramping particularly in Energy, greater levels of design and engineering led engagements and increased demand in Home & Lifestyle.

[0000866374-19-000013:mdna:74]
[same as prior period, unchanged from 0000866374-19-000010:mdna:97]

[0000866374-19-000013:mdna:75]
CEC segment margin decreased 110 basis points, to 1.8% for the three-month period ended September 27, 2019, from 2.9% during the three-month period ended September 28, 2018. CEC segment margin decreased 110 basis points, to 1.6% for the six-month period ended September 27, 2019, from 2.7% for the six-month period ended September 28, 2018. The decrease in CEC's margin during the period is primarily due to geopolitical challenges and uncertainties which impacted demand from specific customers as well as a drop in demand in our networking and telecommunication businesses due to the slower roll-out of 5G technology which created elevated levels of unabsorbed manufacturing overhead costs and finished goods inventory.

[0000866374-19-000013:mdna:76]
CTG segment margin increased 20 basis points to 1.9% for the three-month period ended September 27, 2019, from 1.7% during the three-month period ended September 28, 2018. CTG segment margin increased 40 basis points, to 2.0% for the six-month period ended September 27, 2019, from 1.6% for the six-month period ended September 28, 2018. The increase in CTG's margin during the period reflected lesser losses from our former strategic partnership with NIKE versus the six-month period ended September 28, 2018 and mix improvements as we continued to rationalize and prune underperforming accounts to improve our portfolio mix.

[0000866374-19-000013:mdna:77]
[same as prior period, unchanged from 0000866374-19-000010:mdna:69]

[0000866374-19-000013:mdna:78]
During fiscal year 2019, we took actions to optimize our portfolio with greater focus to be placed on higher margin, less volatile businesses. During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During the three and six-month periods ended September 27, 2019, we recognized $128 million and $185 million, respectively, of restructuring charges. We incurred cash charges of approximately $97 million and $128 million, respectively, that were predominantly for employee severance, and non-cash charges of $31 million and $57 million, respectively, primarily related to asset impairments. While the bulk of the restructuring charges were executed in the first half of fiscal year 2020, we expect to incur additional restructuring charges throughout the remainder of fiscal year 2020, with the expectation to complete these activities by the end of the fiscal year.

[0000866374-19-000013:mdna:79]
During the three and six-month periods ended September 28, 2018, we recognized $26 million and $35 million, respectively, for charges primarily associated with the wind down of our NIKE operations in Mexico, the majority of which were for non-cash asset impairments.

[0000866374-19-000013:mdna:80]
[same as prior period, unchanged from 0000866374-19-000010:mdna:73]

[0000866374-19-000013:mdna:81]
Selling, general and administrative expenses (“SG&A”) was $205 million, or 3.4% of net sales, during the three-month period ended September 27, 2019, decreasing $23 million from $229 million, or 3.4% of net sales, during the three-month period ended September 28, 2018. SG&A was $415 million, or 3.4% of net sales, during the six-month period ended September 27, 2019, decreasing $70 million from $485 million, or 3.6% of net sales, during the six-month period ended September 28, 2018. This decrease was primarily due to strong cost discipline focused on driving further productivity improvements and a refined cost structure benefiting from prior restructuring initiatives.

[0000866374-19-000013:mdna:82]
[same as prior period, unchanged from 0000866374-19-000010:mdna:75]

[0000866374-19-000013:mdna:83]
Amortization of intangible assets was $16 million during the three-month period ended September 27, 2019, compared to $18 million for the three-month period ended September 28, 2018, and $33 million during the six-month period ended September 27, 2019, compared to $37 million for the six-month period ended September 28, 2018. The decline in both periods was primarily due to certain intangibles now being fully amortized.

[0000866374-19-000013:mdna:84]
[same as prior period, unchanged from 0000866374-19-000010:mdna:77]

[0000866374-19-000013:mdna:85]
Interest and other, net was $48 million during the three-month period ended September 27, 2019 compared to $41 million during the three-month period ended September 28, 2018, and $99 million during the six-month period ended September 27, 2019 compared to $83 million during the six-month period ended September 28, 2018. The increase in interest and other, net was primarily a result of higher expenses from our asset-backed securitization programs, coupled with incremental interest expenses from our new borrowings.

[0000866374-19-000013:mdna:86]
[same as prior period, unchanged from 0000866374-19-000010:mdna:79]

[0000866374-19-000013:mdna:87]
Other charges (income), net was $1 million and $3 million of net expense during the three and six-month periods ended September 27, 2019, respectively, compared to $7 million of net expense and $80 million of income during the three and six-month periods ended September 28, 2018, respectively, primarily a result of the non-cash gain from the deconsolidation of Bright Machines recognized in fiscal year 2019.

[0000866374-19-000013:mdna:88]
[same as prior period, unchanged from 0000866374-19-000010:mdna:81]

[0000866374-19-000013:mdna:89]
Certain of our subsidiaries, at various times, have been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 13, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2019 for further discussion.

[0000866374-19-000013:mdna:90]
[same as prior period, unchanged from 0000866374-19-000010:mdna:83]

[0000866374-19-000013:mdna:91]
The consolidated effective tax rate was (22)% and (128)% for the three-month and six-month periods ended September 27, 2019 and 20% and 19% for the three-month and six-month periods ended September 28, 2018. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, India, the Netherlands and Israel. The effective tax rate for the three-month and six-month periods ended September 27, 2019 is significantly lower than the effective tax rate for the three-month and six-month periods ended September 28, 2018, due to a changing jurisdictional mix of income, and our recognition of approximately $242 million and $308 million in restructuring charges, impairment of non-core investment, and customer related asset impairments with minimal associated tax benefit, respectively. This resulted in tax expense recorded on a US GAAP loss for the period.

[0000866374-19-000013:mdna:92]
[same as prior period, unchanged from 0000866374-19-000010:mdna:85]

[0000866374-19-000013:mdna:93]
As of September 27, 2019, we had cash and cash equivalents of approximately $1.8 billion and bank and other borrowings of approximately $3.0 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. We also entered into a JPY 33.525 billion term loan due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. In addition, we issued $450 million of 4.875% Notes in June 2019. The proceeds were used to repay the outstanding balance of our existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021. Refer to note 7 to the condensed consolidated financial statement for details. As of September 27, 2019, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-19-000013:mdna:94]
Cash used in operating activities was $1.6 billion during the six-month period ended September 27, 2019, primarily driven by cash outflows related to accounts receivable. Cash collections from the deferred purchase price on our ABS sales program of $1.8 billion are now included in cash from investing activities. This was coupled with $72 million of net loss for the period, partially offset by $400 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation.

[0000866374-19-000013:mdna:95]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital position was calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. Net working capital decreased $217 million as of September 27, 2019, from $1.7 billion as of March 31, 2019. This decrease is primarily driven by a $134 million decrease in net receivables, coupled with an $80 million increase in accounts payable. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended September 27, 2019, decreased slightly to 6.0% from 6.7% of annualized net sales for the quarter ended March 31, 2019. We generally operate in a net working capital targeted range between 6% to 8% of annualized revenue for the quarter.

[0000866374-19-000013:mdna:96]
Cash provided by investing activities was $1.6 billion during the six-month period ended September 27, 2019. This was primarily driven by $1.8 billion of cash collections on deferred purchase price from our ABS programs during the six-month period ended September 27, 2019, offset by approximately $218 million of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding IEI and HRS businesses.

[0000866374-19-000013:mdna:97]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares

[0000866374-19-000013:mdna:98]
40

[0000866374-19-000013:mdna:99]
and for certain other activities. Our adjusted free cash flow is defined as cash from operations, plus cash collections of deferred purchase price, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. We also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation. In addition, for the six-month period ended September 27, 2019, we added the cash inflows related to the receivable sold to certain financial institutions as described in more details in note 2 to the condensed consolidated financial statements in our adjusted free cash flow calculation. Our adjusted free cash flows for the six-month period ended September 27, 2019 was $301 million compared to a use of $245 million for the six-month period ended September 28, 2018. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-19-000013:mdna:100]
|  | Six-Month Periods Ended |
|  | September 27, 2019 |  | September 28, 2018 |
|  | (In millions) |
| Net cash used in operating activities | (1,648 | ) |  | $ | (1,708 | ) |
| Cash collection of deferred purchase price and other | 2,167 |  |  | 1,813 |  |
| Purchases of property and equipment | (271 | ) |  | (363 | ) |
| Proceeds from the disposition of property and equipment | 53 |  |  | 13 |  |
| Adjusted free cash flow | $ | 301 |  |  | $ | (245 | ) |

[0000866374-19-000013:mdna:101]
Cash provided by financing activities was $132 million during the six-month period ended September 27, 2019, which was primarily driven by $448 million of proceeds, net of discount, received following the issuance of the 2029 Notes, $300 million of proceeds following the execution of our term loan agreement due April 2024 during the first quarter of fiscal year 2020, coupled with $336 million of proceeds from the sale of receivables to certain financial institutions (as further described in note 2 to the condensed consolidated financial statements) and $31 million of proceeds from drawdowns from our India term loan facility. For further information on the 2029 Notes and the Term Loan due 2024, see note 7 to the condensed consolidated financial statements. Partially offsetting the proceeds described above were i) $500 million of cash paid for the repurchase of the outstanding balance of our 4.625% Notes due February 2020, ii) $250 million of cash paid for the partial prepayment of the term loan due November 2021, iii) $91 million of cash paid for the outstanding balance of our short-term bank borrowings facility in India, and iv) $112 million of cash paid for the repurchase of our ordinary shares.

[0000866374-19-000013:mdna:102]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of September 27, 2019, and March 31, 2019, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2019). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-19-000013:mdna:103]
[same as prior period, unchanged from 0000866374-19-000010:mdna:95]

[0000866374-19-000013:mdna:104]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs

[0000866374-19-000013:mdna:105]
41

[0000866374-19-000013:mdna:106]
amounted to approximately $0.2 billion and $0.3 billion for the three and six-month periods ended September 27, 2019, respectively, and approximately $0.1 billion and $0.2 billion for the three and six-month periods ended September 28, 2018, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-19-000013:mdna:107]
[same as prior period, unchanged from 0000866374-19-000010:mdna:98]

[0000866374-19-000013:mdna:108]
[same as prior period, unchanged from 0000866374-19-000010:mdna:99]

[0000866374-19-000013:mdna:109]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-19-000013:mdna:110]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 20, 2019. During the six-month period ended September 27, 2019, we paid $112 million to repurchase shares under the current and prior repurchase plans at an average price of $10.24 per share. As of September 27, 2019, shares in the aggregate amount of $463 million were available to be repurchased under the current plan.

[0000866374-19-000013:mdna:111]
[same as prior period, unchanged from 0000866374-19-000010:mdna:102]

[0000866374-19-000013:mdna:112]
[same as prior period, unchanged from 0000866374-19-000010:mdna:103]

[0000866374-19-000013:mdna:113]
During the first quarter of fiscal year 2020, we entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. In addition, we issued $450 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay the outstanding balance of our existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021.

[0000866374-19-000013:mdna:114]
[same as prior period, unchanged from 0000866374-19-000010:mdna:105]

[0000866374-19-000013:mdna:115]
[same as prior period, unchanged from 0000866374-19-000010:mdna:106]

[0000866374-19-000013:mdna:116]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of September 27, 2019, and March 31, 2019, the fair values of our deferred purchase price receivable were approximately $357 million and $293 million, respectively. As of September 27, 2019, and March 31, 2019, the outstanding balance on receivables sold for cash was $1.3 billion under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information, see note 12 to the condensed consolidated financial statements.
