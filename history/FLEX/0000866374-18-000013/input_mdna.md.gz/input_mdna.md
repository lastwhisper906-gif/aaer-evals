# FLEX MD&A — 0000866374-18-000013


## mdna

[0000866374-18-000013:mdna:1]
[same as prior period, unchanged from 0000866374-18-000010:mdna:1]

[0000866374-18-000013:mdna:2]
[same as prior period, unchanged from 0000866374-18-000010:mdna:2]

[0000866374-18-000013:mdna:3]
[same as prior period, unchanged from 0000866374-18-000010:mdna:3]

[0000866374-18-000013:mdna:4]
We are a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer and enterprise products, for companies of all sizes in various industries and end-markets, through our activities in the following segments:

[0000866374-18-000013:mdna:5]
[same as prior period, unchanged from 0000866374-18-000010:mdna:5]

[0000866374-18-000013:mdna:6]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

[0000866374-18-000013:mdna:7]
[same as prior period, unchanged from 0000866374-18-000010:mdna:7]

[0000866374-18-000013:mdna:8]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging |

[0000866374-18-000013:mdna:9]
[same as prior period, unchanged from 0000866374-18-000010:mdna:36]

[0000866374-18-000013:mdna:10]
equipment; our automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies.

[0000866374-18-000013:mdna:11]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-18-000013:mdna:12]
[same as prior period, unchanged from 0000866374-18-000010:mdna:12]

[0000866374-18-000013:mdna:13]
[same as prior period, unchanged from 0000866374-18-000010:mdna:13]

[0000866374-18-000013:mdna:14]
[same as prior period, unchanged from 0000866374-18-000010:mdna:14]

[0000866374-18-000013:mdna:15]
[same as prior period, unchanged from 0000866374-18-000010:mdna:15]

[0000866374-18-000013:mdna:16]
We are one of the world's largest providers of global supply chain solutions, with revenues of $13.1 billion for the six-month period ended September 28, 2018 and $25.4 billion in fiscal year 2018. On April 1, 2018, the Company adopted the new revenue standard and as a result we recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings, as further described in note 1 to the condensed consolidated financial statements. The comparative information has not been restated and continues to be reported under the accounting standards in effect at the time. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-18-000013:mdna:17]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Net sales: |  | September 28, 2018 |  | September 29, 2017 |  | September 28, 2018 |  | September 29, 2017 |
|  |  | (In millions) |
| China |  | $ | 1,730 |  |  | 26 | % |  | $ | 1,752 |  |  | 28 | % |  | $ | 3,400 |  |  | 26 | % |  | $ | 3,497 |  |  | 28 | % |
| Mexico |  | 1,197 |  |  | 18 | % |  | 1,079 |  |  | 17 | % |  | 2,320 |  |  | 18 | % |  | 2,119 |  |  | 17 | % |
| U.S. |  | 782 |  |  | 12 | % |  | 740 |  |  | 12 | % |  | 1,288 |  |  | 10 | % |  | 1,435 |  |  | 12 | % |
| Malaysia |  | 561 |  |  | 8 | % |  | 515 |  |  | 8 | % |  | 1,038 |  |  | 8 | % |  | 1,020 |  |  | 8 | % |
| Brazil |  | 533 |  |  | 8 | % |  | 642 |  |  | 10 | % |  | 1,120 |  |  | 9 | % |  | 1,240 |  |  | 10 | % |
| India |  | 440 |  |  | 7 | % |  | 146 |  |  | 2 | % |  | 908 |  |  | 7 | % |  | 256 |  |  | 2 | % |
| Other |  | 1,468 |  |  | 22 | % |  | 1,396 |  |  | 22 | % |  | 3,061 |  |  | 23 | % |  | 2,712 |  |  | 22 | % |
|  |  | $ | 6,711 |  |  |  |  |  | $ | 6,270 |  |  |  |  |  | $ | 13,135 |  |  |  |  |  | $ | 12,279 |  |  |  |  |

[0000866374-18-000013:mdna:18]
31

[0000866374-18-000013:mdna:19]
|  | As of |  | As of |
| Property and equipment, net: | September 28, 2018 |  | March 31, 2018 |
|  | (In millions) |
| China | $ | 524 |  |  | 23 | % |  | $ | 492 |  |  | 22 | % |
| Mexico | 519 |  |  | 23 | % |  | 587 |  |  | 26 | % |
| U.S. | 325 |  |  | 14 | % |  | 305 |  |  | 14 | % |
| India | 167 |  |  | 7 | % |  | 78 |  |  | 3 | % |
| Malaysia | 147 |  |  | 6 | % |  | 153 |  |  | 7 | % |
| Hungary | 138 |  |  | 6 | % |  | 150 |  |  | 7 | % |
| Other | 458 |  |  | 20 | % |  | 475 |  |  | 21 | % |
|  | $ | 2,278 |  |  |  |  |  | $ | 2,240 |  |  |  |  |

[0000866374-18-000013:mdna:20]
[same as prior period, unchanged from 0000866374-18-000010:mdna:20]

[0000866374-18-000013:mdna:21]
[same as prior period, unchanged from 0000866374-18-000010:mdna:21]

[0000866374-18-000013:mdna:22]
[same as prior period, unchanged from 0000866374-18-000010:mdna:22]

[0000866374-18-000013:mdna:23]
[same as prior period, unchanged from 0000866374-18-000010:mdna:23]

[0000866374-18-000013:mdna:24]
[same as prior period, unchanged from 0000866374-18-000010:mdna:24]

[0000866374-18-000013:mdna:25]
[same as prior period, unchanged from 0000866374-18-000010:mdna:25]

[0000866374-18-000013:mdna:26]
[same as prior period, unchanged from 0000866374-18-000010:mdna:26]

[0000866374-18-000013:mdna:27]
[same as prior period, unchanged from 0000866374-18-000010:mdna:27]

[0000866374-18-000013:mdna:28]
[same as prior period, unchanged from 0000866374-18-000010:mdna:28]

[0000866374-18-000013:mdna:29]
[same as prior period, unchanged from 0000866374-18-000010:mdna:29]

[0000866374-18-000013:mdna:30]
[same as prior period, unchanged from 0000866374-18-000010:mdna:30]

[0000866374-18-000013:mdna:31]
[same as prior period, unchanged from 0000866374-18-000010:mdna:31]

[0000866374-18-000013:mdna:32]
| • | the impacts on our business due to capacity constraints in certain location; |

[0000866374-18-000013:mdna:33]
| • | the impacts on our business due to component shortages; |

[0000866374-18-000013:mdna:34]
[same as prior period, unchanged from 0000866374-18-000010:mdna:32]

[0000866374-18-000013:mdna:35]
[same as prior period, unchanged from 0000866374-18-000010:mdna:33]

[0000866374-18-000013:mdna:36]
[same as prior period, unchanged from 0000866374-18-000010:mdna:34]

[0000866374-18-000013:mdna:37]
32

[0000866374-18-000013:mdna:38]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results may differ from those estimates and assumptions.

[0000866374-18-000013:mdna:39]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2018, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There were no changes to our accounting policies other than the adoption of ASC 606, as discussed below. In addition, due to the recent stock price decline, we believe the significant drop in market value constitutes a "triggering event" in accordance with the applicable accounting literature, and accordingly commenced an interim impairment test as noted below.

[0000866374-18-000013:mdna:40]
[same as prior period, unchanged from 0000866374-18-000010:mdna:39]

[0000866374-18-000013:mdna:41]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assess whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to notes 1 and 3 to the condensed consolidated financial statements for further details.

[0000866374-18-000013:mdna:42]
Carrying Value of Long-Lived Assets

[0000866374-18-000013:mdna:43]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. Due to the recent decline in the Company's market capitalization, we believe this constitutes a "triggering event" in accordance with the applicable accounting literature and accordingly commenced an interim impairment test. We are in the process of completing the first step of the goodwill impairment test which includes comparing the fair value of a reporting unit with its carrying amount, including goodwill. Based on preliminary results, the Company believes that it is probable that the fair value of the CTG reporting unit is lower than its carrying value. The carrying value of CTG's goodwill as of September 28, 2018 is $103 million. The Company is in the process of finalizing the long-term financial projections necessary to complete the first step of the goodwill impairment test. If it is determined that the goodwill of any of the reporting units is in fact impaired, the Company will then proceed to the second step of the impairment test in which it will measure the fair value of such reporting unit’s identified tangible and intangible assets and liabilities in order to determine the implied fair value of its goodwill and any resulting goodwill impairment. Refer to note 2 to the condensed consolidated financial statements for further details.

[0000866374-18-000013:mdna:44]
[same as prior period, unchanged from 0000866374-18-000010:mdna:41]

[0000866374-18-000013:mdna:45]
[same as prior period, unchanged from 0000866374-18-000010:mdna:42]

[0000866374-18-000013:mdna:46]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 28, 2018 |  | September 29, 2017 |  | September 28, 2018 |  | September 29, 2017 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 94.0 |  |  | 93.7 |  |  | 94.1 |  |  | 93.5 |  |
| Gross profit | 6.0 |  |  | 6.3 |  |  | 5.9 |  |  | 6.5 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 4.4 |  |  | 3.7 |  |  | 4.3 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Interest and other, net | 0.6 |  |  | 0.4 |  |  | 0.6 |  |  | 0.4 |  |
| Other charges (income), net | 0.1 |  |  | (2.3 | ) |  | (0.6 | ) |  | (1.5 | ) |
| Income before income taxes | 1.6 |  |  | 3.5 |  |  | 1.9 |  |  | 3.0 |  |
| Provision for income taxes | 0.3 |  |  | 0.2 |  |  | 0.4 |  |  | 0.3 |  |
| Net income | 1.3 | % |  | 3.3 | % |  | 1.5 | % |  | 2.7 | % |

[0000866374-18-000013:mdna:47]
[same as prior period, unchanged from 0000866374-18-000010:mdna:44]

[0000866374-18-000013:mdna:48]
[same as prior period, unchanged from 0000866374-18-000010:mdna:45]

[0000866374-18-000013:mdna:49]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Segments: | September 28, 2018 |  | September 29, 2017 |  | September 28, 2018 |  | September 29, 2017 |
|  | (In millions) |  |  |
| Communications & Enterprise Compute | $ | 2,141 |  |  | 32 | % |  | $ | 1,901 |  |  | 30 | % |  | $ | 4,095 |  |  | 31 | % |  | $ | 3,874 |  |  | 32 | % |
| Consumer Technologies Group | 1,796 |  |  | 27 | % |  | 1,755 |  |  | 28 | % |  | 3,604 |  |  | 27 | % |  | 3,267 |  |  | 27 | % |
| Industrial & Emerging Industries | 1,566 |  |  | 23 | % |  | 1,455 |  |  | 23 | % |  | 3,012 |  |  | 23 | % |  | 2,845 |  |  | 23 | % |
| High Reliability Solutions | 1,208 |  |  | 18 | % |  | 1,160 |  |  | 18 | % |  | 2,423 |  |  | 18 | % |  | 2,292 |  |  | 19 | % |
|  | $ | 6,711 |  |  |  |  | $ | 6,270 |  |  |  |  | $ | 13,135 |  |  |  |  | $ | 12,279 |  |  |  |

[0000866374-18-000013:mdna:50]
Net sales during the three-month period ended September 28, 2018 totaled $6.7 billion, representing an increase of approximately $0.4 billion, or 7% from $6.3 billion during the three-month period ended September 29, 2017. The overall increase in sales was driven by increases across all of our segments. Our CTG segment increased $41 million, primarily because of new customer program launches in our mobile devices businesses, offset by declines due to certain exiting customers and end of life programs within the legacy consumer sectors of the segment. Our HRS segment increased $48 million primarily from higher sales in our medical businesses as we ramp new programs. Our IEI segment increased $111 million, mainly driven by new programs and customer launches within our industrial, home and lifestyle business, offset by modest declines in our capital equipment and energy business. Our CEC segment increased $240 million, driven by momentum from our cloud and data center business as well as the expansion of network infrastructure programs to support 5G technology, offset by declines in our legacy communications business. Net sales increased across all our regions with increases of $278 million to $3.0 billion in Asia, $122 million to $1.2 billion in Europe, and $40 million to $2.5 billion in the Americas.

[0000866374-18-000013:mdna:51]
Net sales during the six-month period ended September 28, 2018 totaled $13.1 billion, representing an increase of approximately $0.9 billion, or 7% from $12.3 billion during the six-month period ended September 29, 2017. The increase in net sales during the period was notable across all of our segments, driven by the same factors described above. Net sales increased across all our regions with increases of $47 million to $4.9 billion in the Americas, $529 million to $5.9 billion in Asia, and $280 million to $2.4 billion in Europe.

[0000866374-18-000013:mdna:52]
Our ten largest customers, during the three and six-month periods ended September 28, 2018, accounted for approximately 43% of net sales. Our ten largest customers, during the three and six-month periods ended September 29, 2017, accounted for approximately 42% of net sales. No customer accounted for more than 10% of net sales during the three and six-month periods ended September 28, 2018 or September 29, 2017.

[0000866374-18-000013:mdna:53]
[same as prior period, unchanged from 0000866374-18-000010:mdna:49]

[0000866374-18-000013:mdna:54]
[same as prior period, unchanged from 0000866374-18-000010:mdna:50]

[0000866374-18-000013:mdna:55]
Gross profit during the three-month period ended September 28, 2018 increased $9 million to $402 million, or 6.0% of net sales, from $393 million, or 6.3% of net sales, during the three-month period ended September 29, 2017. This was as a result of the additional gross profit from increased revenue offset as noted above by $30.1 million of exit costs primarily related to our estimated impairment of fixed assets considered not recoverable in conjunction with the wind-down of our NIKE footwear manufacturing operations in Mexico in the second quarter of fiscal year 2019.  Gross profit during the six-month period ended September 28, 2018 decreased $20 million to $780 million, or 5.9% of net sales, from $800 million, or 6.5% of net sales, during the six-month period ended September 29, 2017. Gross margin deteriorated 30 basis points during the same period. The decrease in both gross profit and gross margin is primarily due to additional charge recorded in the three-month period ended September 28, 2018 related to the wind-down of our NIKE operations in Mexico along with unfavorable mix shifts, most notably inside our CTG business.

[0000866374-18-000013:mdna:56]
[same as prior period, unchanged from 0000866374-18-000010:mdna:52]

[0000866374-18-000013:mdna:57]
An operating segment’s performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairments, the new revenue standard adoption impact, contingencies and other, other charges (income), net and interest and other, net. A portion of depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-18-000013:mdna:58]
[same as prior period, unchanged from 0000866374-18-000010:mdna:54]

[0000866374-18-000013:mdna:59]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 28, 2018 |  | September 29, 2017 |  | September 28, 2018 |  | September 29, 2017 |
|  | (In millions) |  |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 63 |  |  | 2.9 | % |  | $ | 43 |  |  | 2.2 | % |  | 109 |  |  | 2.7 | % |  | $ | 91 |  |  | 2.4 | % |
| Consumer Technologies Group | 31 |  |  | 1.7 | % |  | 31 |  |  | 1.8 | % |  | 58 |  |  | 1.6 | % |  | 49 |  |  | 1.5 | % |
| Industrial & Emerging Industries | 66 |  |  | 4.2 | % |  | 51 |  |  | 3.5 | % |  | 117 |  |  | 3.9 | % |  | 106 |  |  | 3.7 | % |
| High Reliability Solutions | 90 |  |  | 7.4 | % |  | 92 |  |  | 8.0 | % |  | 183 |  |  | 7.6 | % |  | 183 |  |  | 8.0 | % |
| Corporate and Other | (26 | ) |  |  |  | (28 | ) |  |  |  | (56 | ) |  |  |  | (63 | ) |  |  |
| Total segment income | 224 |  |  | 3.3 | % |  | 188 |  |  | 3.0 | % |  | 411 |  |  | 3.1 | % |  | 366 |  |  | 3.0 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 18 |  |  |  |  | 16 |  |  |  |  | 37 |  |  |  |  | 36 |  |  |  |
| Stock-based compensation | 19 |  |  |  |  | 20 |  |  |  |  | 40 |  |  |  |  | 42 |  |  |  |
| Customer related asset impairments (1) | 30 |  |  |  |  | 5 |  |  |  |  | 47 |  |  |  |  | 5 |  |  |  |
| New revenue standard adoption impact (Note 1 & Note 3) | — |  |  |  |  | — |  |  |  |  | 9 |  |  |  |  | — |  |  |  |
| Contingencies and other (2) | — |  |  |  |  | 44 |  |  |  |  | 25 |  |  |  |  | 44 |  |  |  |
| Other charges (income), net (Note 7) | 7 |  |  |  |  | (143 | ) |  |  |  | (80 | ) |  |  |  | (179 | ) |  |  |
| Interest and other, net | 41 |  |  |  |  | 28 |  |  |  |  | 83 |  |  |  |  | 54 |  |  |  |
| Income before income taxes | $ | 109 |  |  |  |  | $ | 218 |  |  |  |  | $ | 250 |  |  |  |  | $ | 364 |  |  |  |

[0000866374-18-000013:mdna:60]
| (1) | Customer related asset impairments for the three and six-month periods ended September 28, 2018 relate to additional provision for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties as well as $30 |

[0000866374-18-000013:mdna:61]
[same as prior period, unchanged from 0000866374-18-000010:mdna:84]

[0000866374-18-000013:mdna:62]
million of exit costs primarily related to our estimated impairment of fixed assets considered not recoverable in conjunction with the wind-down of our NIKE footwear manufacturing operations in Mexico.

[0000866374-18-000013:mdna:63]
| (2) | Contingencies and other during the three and six-month periods ended September 28, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018, along with certain restructuring charges incurred during our first quarter of fiscal year 2019 offset by certain immaterial reversals in the second quarter of fiscal year 2019. |

[0000866374-18-000013:mdna:64]
During the three and six-month periods ended September 29, 2017, the Company incurred charges in connection with certain legal matters, for loss contingencies where it believed that losses were probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility, along with certain restructuring charges primarily related to severance for rationalization at existing sites and corporate functions.

[0000866374-18-000013:mdna:65]
CEC segment margin increased 70 basis points, to 2.9% for the three-month period ended September 28, 2018, from 2.2% during the three-month period ended September 29, 2017. CEC segment margin increased 30 basis points, to 2.7% for the six-month period ended September 28, 2018, from 2.4% for the six-month period ended September 29, 2017. The increase in CEC's margin during the period is primarily due to better absorption of our cost structure from its higher revenue as well as an improved margin mix with greater concentration of cloud data center solutions and 5G related programs.

[0000866374-18-000013:mdna:66]
CTG segment margin decreased 10 basis points to 1.7% for the three-month period ended September 28, 2018, from 1.8% during the three-month period ended September 29, 2017 as a result of negative impacts from mix shifts within the segment to lower margin customers, and lower than expected revenue from certain mobile customers due to capacity constraints primarily in India, offset by lower losses from NIKE compared to the same period in the prior year. CTG segment margin increased 10 basis points, to 1.6% for the six-month period ended September 28, 2018, from 1.5% for the six-month period ended September 29, 2017 primarily due to lesser losses from NIKE compared to the same period in the prior year.

[0000866374-18-000013:mdna:67]
IEI segment margin increased 70 basis points, to 4.2% for the three-month period ended September 28, 2018, from 3.5% during the three-month period ended September 29, 2017. IEI segment margin increased 20 basis points, to 3.9% for the six-month period ended September 28, 2018, from 3.7% for the six-month period ended September 29, 2017. The increase in IEI's margin during the period is primarily due to improved overhead absorption benefits from the increased revenues from new programs ramps in our industrial, home and lifestyle business offset by reduced demand in capital equipment and energy businesses.

[0000866374-18-000013:mdna:68]
HRS segment margin decreased 60 basis points, to 7.4% for the three-month period ended September 28, 2018, from 8.0% during the three-month period ended September 29, 2017. HRS segment margin decreased 40 basis points, to 7.6% for the six-month period ended September 28, 2018, from 8.0% for the six-month period ended September 29, 2017 primarily as a result of margin pressure in certain parts of our automotive business offset by increases in our medical business that carry slightly lower margin profiles.

[0000866374-18-000013:mdna:69]
[same as prior period, unchanged from 0000866374-18-000010:mdna:62]

[0000866374-18-000013:mdna:70]
Selling, general and administrative expenses (“SG&A”) was $228 million, or 3.4% of net sales, during the three-month period ended September 28, 2018, decreasing $46 million from $274 million, or 4.4% of net sales, during the three-month period ended September 29, 2017. SG&A was $491 million, or 3.7% of net sales, during the six-month period ended September 28, 2018, decreasing $34 million from 525 million, or 4.3% of net sales, during the six-month period ended September 29, 2017. This decrease was primarily due to lesser incremental costs from acquisitions compared to those incurred during fiscal year 2018 as well as additional benefits realized in the three and six-month periods ended fiscal year 2019 from reduced headcount costs resulting from prior restructuring programs. In addition, we recorded certain contingencies that are probable and estimable of payout in the same period last year.

[0000866374-18-000013:mdna:71]
[same as prior period, unchanged from 0000866374-18-000010:mdna:65]

[0000866374-18-000013:mdna:72]
Amortization of intangible assets marginally increased during the three-month period ended September 28, 2018 to $18 million, from $16 million for the three-month period ended September 29, 2017 primarily due to incremental amortization expenses on intangible assets relating to our acquisition completed during the latter part of fiscal year 2018. Amortization of intangible assets for the six-month periods ended September 28, 2018 and September 29, 2017 remained consistent at approximately $36 million.

[0000866374-18-000013:mdna:73]
36

[0000866374-18-000013:mdna:74]
[same as prior period, unchanged from 0000866374-18-000010:mdna:67]

[0000866374-18-000013:mdna:75]
Interest and other, net was $41 million during the three-month period ended September 28, 2018 compared to $28 million during the three-month period ended September 29, 2017, and $83 million during the six-month period ended September 28, 2018 compared to $54 million during the six-month period ended September 29, 2017. The increase in interest and other, net was primarily a result of higher interest expense due to higher interest rates and a higher average borrowing level, increases in foreign exchange losses, coupled with a higher absorption of losses associated with certain of our strategic investments in privately held companies accounted for under the equity method of accounting.

[0000866374-18-000013:mdna:76]
Other charges (income), net

[0000866374-18-000013:mdna:77]
Other charges (income), net was $7 million of net expense and $80 million of income during the three and six-month periods ended September 28, 2018, respectively, compared to $143 million and $179 million of income during the three and six-month periods ended September 29, 2017, respectively. The decrease is primarily due to a lower non-cash gain recognized in fiscal year 2019 as result of the deconsolidation of AutoLab AI ("AutoLab", now known as Bright Machines), or $87 million, compared to the $151.6 million non-cash gain recognized during fiscal year 2018 as a result of the deconsolidation of Elementum SCM (Cayman) Ltd.  For further description on the deconsolidation of AutoLab, refer to note 2 of the condensed consolidated financial statements.

[0000866374-18-000013:mdna:78]
[same as prior period, unchanged from 0000866374-18-000010:mdna:71]

[0000866374-18-000013:mdna:79]
[same as prior period, unchanged from 0000866374-18-000010:mdna:72]

[0000866374-18-000013:mdna:80]
[same as prior period, unchanged from 0000866374-18-000010:mdna:73]

[0000866374-18-000013:mdna:81]
The consolidated effective tax rate was 20.1% and 19.0% for the three and six-month periods ended September 28, 2018 and 6.1% and 9.4% for the three and six-month periods ended September 29, 2017. The effective rate varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, the Netherlands and Israel. The effective tax rate for the three and six-month periods ended September 28, 2018 is higher than the effective tax rate for the three and six-month periods ended September 29, 2017, due to a changing jurisdictional mix of income, the Company's recognition of an approximately $151.6 million gain on deconsolidation of one of its subsidiaries during the three and six-month periods ended September 29, 2017 with no related tax impact, and the current period's asset impairment charge of $30.1 million related to the wind-down of the NIKE footwear manufacturing operations in Mexico with no related tax impact.

[0000866374-18-000013:mdna:82]
[same as prior period, unchanged from 0000866374-18-000010:mdna:75]

[0000866374-18-000013:mdna:83]
As of September 28, 2018, we had cash and cash equivalents of approximately $1.4 billion and bank and other borrowings of approximately $2.9 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. We have also entered into a new $200 million term loan facility in July 2018, under which there were no significant borrowings outstanding as of the end of the quarter. Refer to note 16 for details. As of September 28, 2018, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-18-000013:mdna:84]
Cash used in operating activities was $1.7 billion during the six-month period ended September 28, 2018. As further discussed below, cash collections from the deferred purchase price on our ABS sales program of $1.8 billion are included in cash from investing activities in accordance with new accounting guidance. Overall, the Company's net operating assets, primarily accounts receivable, inventory and contract asset, have increased to support increased operations and new ramps. The increased asset base has not been fully offset by the increase in accounts payable. The increased net asset position, further discussed below, was partially offset by $203 million of net income for the period plus $308 million of non-cash charges such as depreciation, amortization, and stock-based compensation, net of an $87 million gain from the deconsolidation of AutoLab, which is included in the determination of net income.

[0000866374-18-000013:mdna:85]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure the Company’s liquidity. Net working capital position was calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories, less accounts payable as of March 31, 2018. As part of the adoption of ASC 606, as further described in note 1 to

[0000866374-18-000013:mdna:86]
37

[0000866374-18-000013:mdna:87]
the condensed consolidated financial statements, we expanded net working capital to include contract assets on a going forward basis. Net working capital increased $148 million to $1.8 billion as of September 28, 2018, from $1.6 billion as of March 31, 2018. This increase is primarily driven by (i) a $643 million increase in our inventory levels from March 31, 2018, as we are carrying elevated levels due to certain component shortages as well as capacity constraints in certain locations coupled with the positioning of inventory for multiple large ramps, (ii) an increase of $418 million in contract assets upon adoption of ASC 606, (iii) a $201 million increase in accounts receivable adding back reductions from non-cash accounts receivable sales, offset by approximately $1 billion increase in accounts payable. Despite the increase in our net working capital position from March 31, 2018, current quarter net working capital as a percentage of annualized net sales for the quarter then ended remained relatively consistent at 6.7% as compared to 6.6% of annualized net sales for the quarter ended September 29, 2017. The Company generally operates in a net working capital targeted range between 6%-8% of annualized revenue for the quarter.

[0000866374-18-000013:mdna:88]
Cash provided by investing activities was $1.7 billion during the six-month period ended September 28, 2018. This was primarily driven by the impact of our adoption of ASU 2016-15 during the current fiscal year, which requires us to classify cash collections on deferred purchase price that were previously classified as operating cash inflows as cash flows from investing activities. Refer to note 1 to the condensed consolidated financial statements for further description of the ASU. In addition, we received $264 million of proceeds, net of cash and escrow held, in connection to the divestitures of our China-based Multek Operations as further described in note 12 to the condensed consolidated financial statements. During the six-month period ended September 28, 2018, we also invested $350 million of net capital expenditures for property and equipment to expand capabilities and capacity in support of our expanding IEI and HRS businesses as well as building out capacity in India, which was higher by $122 million from the same period in the prior year. In addition, other investing activities includes $128 million of non-cash outflow representing our investment in AutoLab following the deconsolidation.

[0000866374-18-000013:mdna:89]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Upon adoption of ASU 2016-15 during the first quarter of fiscal year 2019, our free cash flow is redefined as cash from operations, plus cash collections of deferred purchase price, less net purchases of property and equipment to present cash flows on a consistent basis for investor transparency. Our free cash flows for the six-month period ended September 28, 2018 was a use of $245 million compared to an inflow of $54 million for the six-month period ended September 29, 2017. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-18-000013:mdna:90]
|  | Six-Month Periods Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (In millions) |
| Net cash used in operating activities | $ | (1,708 | ) |  | $ | (2,172 | ) |
| Cash collection of deferred purchase price | 1,813 |  |  | 2,453 |  |
| Purchases of property and equipment | (363 | ) |  | (264 | ) |
| Proceeds from the disposition of property and equipment | 13 |  |  | 37 |  |
| Free cash flow | $ | (245 | ) |  | $ | 54 |  |

[0000866374-18-000013:mdna:91]
Cash used in financing activities was $62 million during the six-month period ended September 28, 2018, which was primarily for the repurchase of our ordinary shares in the amount of $60 million.

[0000866374-18-000013:mdna:92]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of September 28, 2018, and March 31, 2018, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2018). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our

[0000866374-18-000013:mdna:93]
38

[0000866374-18-000013:mdna:94]
operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-18-000013:mdna:95]
[same as prior period, unchanged from 0000866374-18-000010:mdna:86]

[0000866374-18-000013:mdna:96]
[same as prior period, unchanged from 0000866374-18-000010:mdna:87]

[0000866374-18-000013:mdna:97]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-18-000013:mdna:98]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 16, 2018. During the six-month period ended September 28, 2018, the Company paid $60 million to repurchase shares under the current and prior repurchase plans at an average price of $13.54 per share. As of September 28, 2018, shares in the aggregate amount of $454 million were available to be repurchased under the current plan.

[0000866374-18-000013:mdna:99]
[same as prior period, unchanged from 0000866374-18-000010:mdna:90]

[0000866374-18-000013:mdna:100]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2018. There have been no material changes in our contractual obligations and commitments since March 31, 2018, except for a 20-year lease we entered into for certain new China facility. The total amount of future minimum lease payments is estimated to be $82 million.

[0000866374-18-000013:mdna:101]
[same as prior period, unchanged from 0000866374-18-000010:mdna:92]

[0000866374-18-000013:mdna:102]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of September 28, 2018, and March 31, 2018, the fair values of our deferred purchase price receivable were approximately $304 million and $445 million, respectively. As of September 28, 2018, and March 31, 2018, the outstanding balance on receivables sold for cash was $1.4 billion and $1.3 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information, see note 10 to the condensed consolidated financial statements.
