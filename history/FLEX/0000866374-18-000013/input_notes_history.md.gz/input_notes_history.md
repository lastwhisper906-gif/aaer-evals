# FLEX note change history — 0000866374-18-000010 → 0000866374-18-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000866374-18-000013:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.
  (was, 2018-08-02, similarity 0.9657):
[0000866374-18-000010:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The Company does not believe that the amounts accrued are material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- changed (2018-11-02):
[0000866374-18-000013:note_history:2]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.
  (was, 2018-08-02, similarity 0.9996):
[0000866374-18-000010:note_history:2]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conduct it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

- added (2018-11-02):
[0000866374-18-000013:note_history:3]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On October 15, 2018, the Court issued an order providing that lead plaintiff shall file an amended complaint by November 30, 2018 and that defendants shall respond to the amended complaint by January 10, 2019, and setting the hearing on defendants’ motion to dismiss for March 21, 2019. The Court also set a case management conference for December 12, 2018. The Company believes that the claims are without merit and intends to vigorously defend this case.

- changed (2018-11-02):
[0000866374-18-000013:note_history:4]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 346 million Brazilian reals (approximately USD $85.24 million based on the exchange rate as of September 28, 2018). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.
  (was, 2018-08-02, similarity 0.9905):
[0000866374-18-000010:note_history:4]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 346 million Brazilian reals (approximately USD $90 million based on the exchange rate as of June 29, 2018). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

- removed (2018-11-02):
[0000866374-18-000010:note_history:5]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. The deadline for applications for appointment as lead plaintiff was July 9, 2018. There are two pending motions for appointment as lead plaintiff, which are scheduled to be heard by the Court on October 11, 2018.  The Court has extended the time for Defendants to respond to the complaint until after a lead plaintiff is appointed and an amended complaint is filed by the lead plaintiff.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000866374-18-000013:note_history:6]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and enterprise products, for companies of all sizes in various industries and end-markets, through its activities in the following segments:
  (was, 2018-08-02, similarity 0.9724):
[0000866374-18-000010:note_history:6]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and enterprise products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

- changed (2018-11-02):
[0000866374-18-000013:note_history:7]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |
  (was, 2018-08-02, similarity 0.9637):
[0000866374-18-000010:note_history:7]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion and apparel, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

- changed (2018-11-02):
[0000866374-18-000013:note_history:8]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).
  (was, 2018-08-02, similarity 0.993):
[0000866374-18-000010:note_history:8]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).

- changed (2018-11-02):
[0000866374-18-000013:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2018 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and six-month periods ended September 28, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019.
  (was, 2018-08-02, similarity 0.861):
[0000866374-18-000010:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2018 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 29, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019.

- changed (2018-11-02):
[0000866374-18-000013:note_history:10]
The first quarters for fiscal years 2019 and 2018 ended on June 29, 2018, which is comprised of 90 days in the period, and June 30, 2017, which is comprised of 91 days in the period, respectively. The second quarters for fiscal years 2019 and 2018 ended on September 28, 2018 and September 29, 2017, which are comprised of 91 days in both periods.
  (was, 2018-08-02, similarity 0.7056):
[0000866374-18-000010:note_history:10]
The first quarters for fiscal year 2019 and fiscal year 2018 ended on June 29, 2018, which is comprised of 90 days in the period, and June 30, 2017, which is comprised of 91 days in the period, respectively.

- changed (2018-11-02):
[0000866374-18-000013:note_history:11]
In August 2016, the FASB issued ASU 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force)." The ASU is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 is consistent with our current cash flow classification. However, cash receipts on the deferred purchase price from the Company's asset-backed securitization programs described in note 10 will be classified as cash flows from investing activities instead of the Company's former presentation as cash flows from operations. The Company adopted the guidance during the first quarter of fiscal year 2019 using a monthly approach to track cash flows on deferred purchase price and retrospectively adjusted cash flows from operating and investing activities for fiscal year 2018. Commencing with the quarter ending September 28, 2018, the Company changed to a method based on daily activity and retrospectively adjusted cash flows from operating and investing activities for the six-month period ended September 29, 2017. The Company recorded $1.8 billion of cash receipts on the deferred purchase price from the Company's asset-backed securitization programs for the six-month period ended September 28, 2018 and reclassified $2.5 billion of cash receipts on the deferred purchase price for the six-month period ended September 29, 2017, from cash flows from operating activities to cash flows from investing activities.
  (was, 2018-08-02, similarity 0.6543):
[0000866374-18-000010:note_history:11]
In August 2016, the FASB issued ASU 2016-15, "Statement of Cash Flows (Topic 2030): Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force)." The ASU is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 is consistent with our current cash flow classification. However, cash receipts on the deferred purchase price from the Company's asset-backed securitization programs described in note 10 will be classified as cash flows from investing activities instead of the Company's former presentation as cash flows from operations. The Company adopted the guidance during the first quarter of fiscal year 2019 and retrospectively adjusted cash flows from operating and investing activities for three-month period ended June 30, 2017. Upon adoption of the standard, the Company recorded $0.7 billion of cash receipts on the deferred purchase price from the Company's asset-backed securitization programs for the three-month period ended June 29, 2018 and reclassified $0.8 billion of cash receipts on the deferred purchase price for the three-month period ended June 30, 2017, from cash flows from operating activities to cash flows from investing activities and the Company’s condensed consolidated statement of cash flows for the three-months ended June 30, 2017 has been restated to reflect this adjustment.

- changed (2018-11-02):
[0000866374-18-000013:note_history:12]
In February 2018, the FASB issued ASU 2018-03 "Technical Corrections and Improvements to Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This standard comes as an addition to ASU 2016-01 which the Company adopted in the first quarter of fiscal year 2019.  This update includes amendments to clarify certain aspects of the guidance issued in Update 2016-01. The Company adopted this guidance during the second quarter of fiscal year 2019 with an immaterial impact on its consolidated financial statements.
  (was, 2018-08-02, similarity 0.9549):
[0000866374-18-000010:note_history:12]
In February 2018, the FASB issued ASU 2018-03 "Technical Corrections and Improvements to Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This standard comes as an addition to ASU 2016-01which the Company adopted in the first quarter of fiscal year 2019.  This update includes amendments to clarify certain aspects of the guidance issued in Update 2016-01. The Company will adopt the guidance during the second quarter of fiscal year 2019, and expects it will have an immaterial impact on its consolidated financial statements.

- changed (2018-11-02):
[0000866374-18-000013:note_history:13]
As part of adopting ASC 606, revenue for certain customer contracts where the Company is manufacturing products for which there is no alternative use and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory will be recognized over time (i.e., as we manufacture the product) instead of upon shipment of products.  In addition to the following disclosures, note 3 provides further disclosures required by the new standard.
  (was, 2018-08-02, similarity 0.9989):
[0000866374-18-000010:note_history:13]
As part of adopting ASC 606, revenue for certain customer contracts where the Company is manufacturing products for which there is no alternative use and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory will be recognized over time (i.e. as we manufacture the product) instead of upon shipment of products.  In addition to the following disclosures, note 3 provides further disclosures required by the new standard.

- changed (2018-11-02):
[0000866374-18-000013:note_history:14]
| Condensed Consolidated Balance Sheet |  |  |  |
| As of September 28, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| ASSETS |  |  |  |
| Contract assets | 418,158 |  | (418,158 | ) | — |  |
| Inventories | 4,442,855 |  | 415,623 |  | 4,858,478 |  |
| Other current assets | 935,030 |  | 8,059 |  | 943,089 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,456,519 |  | 34,327 |  | 1,490,846 |  |
| Accumulated deficit | (2,902,492 | ) | (38,520 | ) | (2,941,012 | ) |
  (was, 2018-08-02, similarity 0.9864):
[0000866374-18-000010:note_history:14]
| Condensed Consolidated Balance Sheet |  |  |  |
| As of June 29, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| ASSETS |  |  |  |
| Contract assets | 323,599 |  | (323,599 | ) | — |  |
| Inventories | 3,984,571 |  | 321,710 |  | 4,306,281 |  |
| Other current assets | 1,231,773 |  | 39,184 |  | 1,270,957 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,665,432 |  | 70,317 |  | 1,735,749 |  |
| Accumulated deficit | (2,989,377 | ) | (33,022 | ) | (3,022,399 | ) |

- added (2018-11-02):
[0000866374-18-000013:note_history:15]
| Condensed Consolidated Statement of Operations |  |  |  |  |  |  |  |
|  | Impact of Adopting ASC 606 |
|  | Three-months ended September 28, 2018 |  | Six-months ended September 28, 2018 |
| (In thousands, except per share amounts)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |  | As Reported | Adjustments | Balance without ASC 606 Adoption |
| Net sales | $ | 6,710,604 |  | $ | (115,533 | ) | $ | 6,595,071 |  |  | $ | 13,134,560 |  | $ | (27,237 | ) | $ | 13,107,323 |  |
| Cost of sales | 6,308,303 |  | (111,917 | ) | 6,196,386 |  |  | 12,354,405 |  | (26,573 | ) | 12,327,832 |  |
| Gross profit | 402,301 |  | (3,616 | ) | 398,685 |  |  | 780,155 |  | (664 | ) | 779,491 |  |
| Net income | $ | 86,885 |  | $ | (3,616 | ) | $ | 83,269 |  |  | $ | 202,920 |  | $ | (664 | ) | $ | 202,256 |  |

- added (2018-11-02):
[0000866374-18-000013:note_history:16]
To align contractual terms across the vast majority of customers to allow the Company to efficiently and accurately manage its contracts, in the first quarter of fiscal year 2019, the Company waived certain contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. These modifications resulted in revenue from these customers being recognized upon shipment of products, rather than over time (i.e., as we manufacture products) as further explained in note 3. The result of the amendments for the six-month period ended September 28, 2018, was to reduce revenue and gross profit by approximately $132.7 million and $9.3 million, respectively, compared to amounts that would have been reported both (i) under ASC 606 had we not amended the contracts, and (ii) had we not adopted ASC 606.

- added (2018-11-02):
[0000866374-18-000013:note_history:17]
For the three-month period ended September 28, 2018 the as reported revenue was approximately $115.5 million higher, and the gross profit $3.6 million higher, than they would have been without ASC 606 adoption primarily due to additional inventory build up as of September 28, 2018 for those customer contracts that meet the criteria for over-time recognition (see note 3) partially offset by a decline in the aggregate average gross profit margin for those customers due to the increasing mix of lower margin customers included in the CTG segment.

- added (2018-11-02):
[0000866374-18-000013:note_history:18]
For the six-month period ended September 28, 2018 the as reported revenue was approximately $27.2 million higher and the gross profit approximately $0.7 million higher than it would have been without ASC 606 adoption. Additional revenue of $160.0 million was reported under ASC 606 due to the accelerated timing of recognition of revenue for contracts which meet the criteria for over-time recognition (see note 3). Approximately $10.0 million of additional gross profit was recognized on the customers qualifying for accelerated revenue recognition. These increases were offset by reductions of $132.7 million of revenue and $9.3 million of gross profit respectively as a result of the waiver of contracts noted above. There was no material tax impact for the three and six-month periods ended September 28, 2018 from adopting ASC 606.

- changed (2018-11-02):
[0000866374-18-000013:note_history:19]
| • | The Company elected to not disclose information about remaining performance obligations as its performance obligations generally have an expected duration of one year or less. |
  (was, 2018-08-02, similarity 0.9973):
[0000866374-18-000010:note_history:19]
| • | The Company elected to not disclose information about remaining performance obligations as its performance obligations generally have an expected durations of one year or less. |

- added (2018-11-02):
[0000866374-18-000013:note_history:20]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing arrangement that is hosted by the vendor, i.e. a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company is still evaluating the impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- added (2018-11-02):
[0000866374-18-000013:note_history:21]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- added (2018-11-02):
[0000866374-18-000013:note_history:22]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. In July 2018, the FASB issued ASU 2018-11, "Leases (Topic 842): Targeted Improvements", which provides entities with relief from the costs of implementing certain aspects of the new leasing standard, ASC 842. Specifically, under the amendments in ASU 2018-11, (1) entities may elect not to recast the comparative periods presented when transitioning to ASC 842 and (2) lessors may elect not to separate lease and nonlease components when certain conditions are met. Also in July 2018, the FASB issued ASU 2018-10, "Codification Improvements to Topic 842, Leases", which clarifies how to apply certain aspects of the new leases standard, ASC 842. The amendments address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options, variable payments that depend on an index or rate and certain transition adjustments, among other things. The amendments have the same effective date and transition requirements as the new leases standard. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach. The Company believes the new guidance will have a material impact on its consolidated balance sheets upon adoption.

- removed (2018-11-02):
[0000866374-18-000010:note_history:23]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- removed (2018-11-02):
[0000866374-18-000010:note_history:24]
The Company adopted this new guidance using a method which allocates cash flows between operating and investing activities based on monthly receivables sales and collection data.  Commencing with the quarter ending September 28, 2018, the Company will change to a method based on daily activity, and will apply this new method retrospectively.  Management expects this change to result in a decrease in cash flows from operating activities and a corresponding increase in cash flows from investing activities, and that the amount of such change could be material, though no amounts have yet been quantified for any period presented.

- removed (2018-11-02):
[0000866374-18-000010:note_history:25]
| Condensed Consolidated Statement of Operations |  |  |  |
| Three-months ended June 29, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| Net sales | $ | 6,423,956 |  | $ | 101,974 |  | $ | 6,525,930 |  |
| Cost of sales | 6,046,102 |  | 97,141 |  | 6,143,243 |  |
| Gross profit | 377,854 |  | 4,833 |  | 382,687 |  |
| Net income | $ | 116,035 |  | $ | 4,833 |  | $ | 120,868 |  |

- removed (2018-11-02):
[0000866374-18-000010:note_history:26]
The as reported revenue and gross profit for the period ended June 29, 2018 were approximately $102.0 million, and $4.8 million less than they would have been without ASC 606 adoption primarily due to certain contract amendments for a portion of the Company's customers executed in the quarter. To align contractual terms across the vast majority of customers to allow the Company to efficiently and accurately manage its contracts, the Company waived certain contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. These modifications will result in revenue from these customers being recognized upon shipment of products, rather than over time (i.e. as we manufacture products) as further explained in note 3. The result of the amendments was to reduce revenue and gross profit by approximately $132.7 million and $9.3 million, respectively, compared to amounts that would have been reported both (i) under ASC 606 had we not amended the contracts, and (ii) had we not adopted ASC 606.  Offsetting the impact of the one-time contract amendments noted above was approximately $30.7 million of additional revenue and $4.5 million of gross profit recognized in the "as reported" amounts due to the accelerated timing of recognition of revenue for contracts which meet the criteria for over-time recognition (see note 3). There was no material tax impact for the three months period ended June 29, 2018 from adopting ASC 606.

- removed (2018-11-02):
[0000866374-18-000010:note_history:27]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach. The Company believes the new guidance will have a material impact on its consolidated balance sheets upon adoption.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2018-11-02):
[0000866374-18-000013:note_history:28]
BANK BORROWINGS AND LONG TERM DEBT

- added (2018-11-02):
[0000866374-18-000013:note_history:29]
Term Loan Facility due September 2023

- added (2018-11-02):
[0000866374-18-000013:note_history:30]
In July 2018, the Company entered into a $200 million term loan facility (the "Facility"). The Facility will be used to fund capital expenditure to support our expansion plan for India. The availability period during which drawdown can be made will be from the date of the agreement to and including June 30, 2019. The maximum maturity of each drawdown will be 5 years from the funded Capex shipment date. As a result, the longest maturity date of any future drawdown under the Facility will be June 30, 2024. Borrowings under this term loan bear interest at LIBOR plus a margin of 1.15%. The Facility is unsecured, guaranteed by the Company, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to certain exceptions and limitations. This Facility agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of September 28, 2018, the Company was in compliance with the covenants under this term loan agreement.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000866374-18-000013:note_history:31]
|  | As of September 28, 2018 |  | As of March 31, 2018 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 507,031 |  |  | $ | 500,000 |  |  | $ | 513,596 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 679,688 |  |  | 683,086 |  |  | 687,813 |  |  | 689,966 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 471,094 |  |  | 473,449 |  |  | 483,656 |  |  | 485,470 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 513,830 |  |  | 500,000 |  |  | 525,292 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,599 |  |  | 605,146 |  |  | 596,387 |  |  | 627,407 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 55,804 |  |  | 55,804 |  |  | 59,443 |  |  | 59,443 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 117,481 |  |  | 117,481 |  |  | 123,518 |  |  | 123,518 |  |  | Level 1 |
| Total | $ | 2,920,666 |  |  | $ | 2,955,827 |  |  | $ | 2,950,817 |  |  | $ | 3,024,692 |  |  |  |
  (was, 2018-08-02, similarity 0.9922):
[0000866374-18-000010:note_history:31]
|  | As of June 29, 2018 |  | As of March 31, 2018 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 499,950 |  |  | $ | 500,000 |  |  | $ | 513,596 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 683,750 |  |  | 686,314 |  |  | 687,813 |  |  | 689,966 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 477,375 |  |  | 477,375 |  |  | 483,656 |  |  | 485,470 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 499,950 |  |  | 500,000 |  |  | 525,292 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,492 |  |  | 599,940 |  |  | 596,387 |  |  | 627,407 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 55,797 |  |  | 55,797 |  |  | 59,443 |  |  | 59,443 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 115,942 |  |  | 115,942 |  |  | 123,518 |  |  | 123,518 |  |  | Level 1 |
| Total | $ | 2,929,356 |  |  | $ | 2,935,268 |  |  | $ | 2,950,817 |  |  | $ | 3,024,692 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000866374-18-000013:note_history:32]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and overtime - for the three-month and six-month periods ended September 28, 2018 (in thousands), respectively:
  (was, 2018-08-02, similarity 0.899):
[0000866374-18-000010:note_history:32]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and overtime - for the three-month period ended June 29, 2018 (in thousands):

- changed (2018-11-02):
[0000866374-18-000013:note_history:33]
| Three-month Period Ended September 28, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 893,141 |  |  | $ | 1,203,696 |  |  | $ | 1,089,319 |  |  | $ | 1,519,041 |  |  | $ | 4,705,197 |  |
| Over time | 314,830 |  |  | 592,187 |  |  | 476,634 |  |  | 621,756 |  |  | 2,005,407 |  |
| Total segment | $ | 1,207,971 |  |  | $ | 1,795,883 |  |  | $ | 1,565,953 |  |  | $ | 2,140,797 |  |  | $ | 6,710,604 |  |
  (was, 2018-08-02, similarity 0.9305):
[0000866374-18-000010:note_history:33]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,300,637 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 4,863,222 |  |
| Over time | 210,245 |  |  | 507,297 |  |  | 382,413 |  |  | 460,779 |  |  | 1,560,734 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,807,934 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 6,423,956 |  |

- added (2018-11-02):
[0000866374-18-000013:note_history:34]
| Six-month Period Ended September 28, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,898,321 |  |  | $ | 2,504,333 |  |  | $ | 2,153,218 |  |  | $ | 3,012,548 |  |  | $ | 9,568,420 |  |
| Over time | 525,075 |  |  | 1,099,484 |  |  | 859,046 |  |  | 1,082,535 |  |  | 3,566,140 |  |
| Total segment | $ | 2,423,396 |  |  | $ | 3,603,817 |  |  | $ | 3,012,264 |  |  | $ | 4,095,083 |  |  | $ | 13,134,560 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000866374-18-000013:note_history:35]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that create enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, we bid on a program-by-program basis and typically receive customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.
  (was, 2018-08-02, similarity 0.6033):
[0000866374-18-000010:note_history:35]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that create enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc, and the level of business under those agreements may not be guaranteed. In those instances, we bid on a program-by-program basis and typically receive customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

- changed (2018-11-02):
[0000866374-18-000013:note_history:36]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises).  The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).
  (was, 2018-08-02, similarity 0.9987):
[0000866374-18-000010:note_history:36]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises).  The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g.: procurement of materials and standard workmanship warranty).

- changed (2018-11-02):
[0000866374-18-000013:note_history:37]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that Flex would sell similar goods or services separately.
  (was, 2018-08-02, similarity 0.9915):
[0000866374-18-000010:note_history:37]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of our contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that Flex would sell similar goods or services separately.

- changed (2018-11-02):
[0000866374-18-000013:note_history:38]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheet and transferred to receivables when rights to payment become unconditional. The following table summarizes the activity in the Company's contract assets during the six-month period ended September 28, 2018 (in thousands):
  (was, 2018-08-02, similarity 0.9745):
[0000866374-18-000010:note_history:38]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheet and transferred to receivables when rights to payment become unconditional. The following table summarizes the activity in the Company's contract assets during the three-month period ended June 29, 2018 (in thousands):

- changed (2018-11-02):
[0000866374-18-000013:note_history:39]
|  | Contract Assets |
| Beginning balance, April 1, 2018 | $ | — |  |
| Cumulative effect adjustment at April 1, 2018 | 412,787 |  |
| Revenue recognized | 3,566,140 |  |
| Amounts collected or invoiced | (3,560,769 | ) |
| Ending balance, September 28, 2018 | $ | 418,158 |  |
  (was, 2018-08-02, similarity 0.9717):
[0000866374-18-000010:note_history:39]
|  | Contract Assets |
| Beginning balance, April 1, 2018 | $ | — |  |
| Cumulative effect adjustment at April 1, 2018 | 412,787 |  |
| Revenue recognized | 1,560,734 |  |
| Amounts collected or invoiced | (1,649,922 | ) |
| Ending balance, June 29, 2018 | $ | 323,599 |  |

- changed (2018-11-02):
[0000866374-18-000013:note_history:40]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $247.1 million and $265.3 million as of September 28, 2018 and April 1, 2018, respectively.
  (was, 2018-08-02, similarity 0.9704):
[0000866374-18-000010:note_history:40]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and are included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $270.6 million and $265.3 million as of June 29, 2018 and April 1, 2018, respectively.

- changed (2018-11-02):
[0000866374-18-000013:note_history:41]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and overtime - for the three-month and six-month periods ended September 28, 2018 (in thousands), respectively:
  (was, 2018-08-02, similarity 0.899):
[0000866374-18-000010:note_history:41]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and overtime - for the three-month period ended June 29, 2018 (in thousands):

- changed (2018-11-02):
[0000866374-18-000013:note_history:42]
| Three-month Period Ended September 28, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 893,141 |  |  | $ | 1,203,696 |  |  | $ | 1,089,319 |  |  | $ | 1,519,041 |  |  | $ | 4,705,197 |  |
| Over time | 314,830 |  |  | 592,187 |  |  | 476,634 |  |  | 621,756 |  |  | 2,005,407 |  |
| Total segment | $ | 1,207,971 |  |  | $ | 1,795,883 |  |  | $ | 1,565,953 |  |  | $ | 2,140,797 |  |  | $ | 6,710,604 |  |
  (was, 2018-08-02, similarity 0.9305):
[0000866374-18-000010:note_history:42]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,300,637 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 4,863,222 |  |
| Over time | 210,245 |  |  | 507,297 |  |  | 382,413 |  |  | 460,779 |  |  | 1,560,734 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,807,934 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 6,423,956 |  |

- added (2018-11-02):
[0000866374-18-000013:note_history:43]
| Six-month Period Ended September 28, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,898,321 |  |  | $ | 2,504,333 |  |  | $ | 2,153,218 |  |  | $ | 3,012,548 |  |  | $ | 9,568,420 |  |
| Over time | 525,075 |  |  | 1,099,484 |  |  | 859,046 |  |  | 1,082,535 |  |  | 3,566,140 |  |
| Total segment | $ | 2,423,396 |  |  | $ | 3,603,817 |  |  | $ | 3,012,264 |  |  | $ | 4,095,083 |  |  | $ | 13,134,560 |  |
