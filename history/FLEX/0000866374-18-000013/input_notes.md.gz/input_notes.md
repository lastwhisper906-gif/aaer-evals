# FLEX notes — 0000866374-18-000013


## flex:InterestAndOtherNetTextBlock

[0000866374-18-000013:notes:1]
[same as prior period, unchanged from 0000866374-18-000010:notes:1]

[0000866374-18-000013:notes:2]
During the three and six-month periods ended September 28, 2018, the Company recognized interest expense of $35.1 million and $68.7 million, respectively, on its debt obligations outstanding during the periods. During the three and six-month periods ended September 29, 2017, the Company recognized interest expense of $29.6 million and $58.6 million, respectively, on its debt obligations outstanding during the periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-18-000013:notes:3]
[same as prior period, unchanged from 0000866374-18-000010:notes:3]

[0000866374-18-000013:notes:4]
During the three-month period ended September 28, 2018, the Company divested its China-based Multek operations, for proceeds of approximately $264.4 million, net of cash. The Company transferred approximately $231.4 million of net assets, primarily property and equipment, accounts receivable, and accounts payable. Further, the Company incurred various selling transaction costs as part of this divestiture and allocated approximately $19.0 million of goodwill to the divested business. This transaction resulted in the recognition of an immaterial loss which is included in other charges (income), net in the condensed consolidated statements of operations as of September 28, 2018.

[0000866374-18-000013:notes:5]
Pro-forma results of operations for this divestiture have not been presented because the effect was not material to the Company's consolidated financial results for all periods presented.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-18-000013:notes:6]
COMMITMENTS AND CONTINGENCIES

[0000866374-18-000013:notes:7]
Litigation and other legal matters

[0000866374-18-000013:notes:8]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-18-000013:notes:9]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-18-000013:notes:10]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable our use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g. base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing a patent license agreement, and requesting information relating to royalties for products that it assembles for a customer in China. If any of these inquiries result in a claim, the Company intends to contest and defend against any such claim vigorously. If a claim is asserted and the Company is unsuccessful in its defense, a material loss is reasonably possible. The Company cannot predict or estimate an amount or reasonable range of outcomes with respect to the matter.

[0000866374-18-000013:notes:11]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On October 15, 2018, the Court issued an order providing that lead plaintiff shall file an amended complaint by November 30, 2018 and that defendants shall respond to the amended complaint by January 10, 2019, and setting the hearing on defendants’ motion to dismiss for March 21, 2019. The Court also set a case management conference for December 12, 2018. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-18-000013:notes:12]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-18-000013:notes:13]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 346 million Brazilian reals (approximately USD $85.24 million based on the exchange rate as of September 28, 2018). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-18-000013:notes:14]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-18-000013:notes:15]
[same as prior period, unchanged from 0000866374-18-000010:notes:15]

[0000866374-18-000013:notes:16]
[same as prior period, unchanged from 0000866374-18-000010:notes:16]

[0000866374-18-000013:notes:17]
|  | Three-Month Periods Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (76,649 | ) |  | $ | (94,185 | ) |  | $ | (170,834 | ) |  | $ | (34,595 | ) |  | $ | (84,881 | ) |  | $ | (119,476 | ) |
| Other comprehensive gain (loss) before reclassifications | 945 |  |  | (6,622 | ) |  | (5,677 | ) |  | (3,865 | ) |  | 9,478 |  |  | 5,613 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 20,130 |  |  | — |  |  | 20,130 |  |  | (10,010 | ) |  | — |  |  | (10,010 | ) |
| Net current-period other comprehensive gain (loss) | 21,075 |  |  | (6,622 | ) |  | 14,453 |  |  | (13,875 | ) |  | 9,478 |  |  | (4,397 | ) |
| Ending balance | $ | (55,574 | ) |  | $ | (100,807 | ) |  | $ | (156,381 | ) |  | $ | (48,470 | ) |  | $ | (75,403 | ) |  | $ | (123,873 | ) |

[0000866374-18-000013:notes:18]
|  | Six-Month Periods Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (35,746 | ) |  |  | $ | (50,099 | ) |  | $ | (85,845 | ) |  | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |
| Other comprehensive gain (loss) before reclassifications | (40,714 | ) |  |  | (50,708 | ) |  | (91,422 | ) |  | (845 | ) |  | 20,314 |  |  | 19,469 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 20,886 |  | — |  | — |  |  | 20,886 |  |  | (15,199 | ) |  | — |  |  | (15,199 | ) |
| Net current-period other comprehensive gain (loss) | (19,828 | ) |  |  | (50,708 | ) |  | (70,536 | ) |  | (16,044 | ) |  | 20,314 |  |  | 4,270 |  |
| Ending balance | $ | (55,574 | ) |  |  | $ | (100,807 | ) |  | $ | (156,381 | ) |  | $ | (48,470 | ) |  | $ | (75,403 | ) |  | $ | (123,873 | ) |

[0000866374-18-000013:notes:19]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and six-month periods ended September 28, 2018 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:ConsolidationPolicyTextBlock

[0000866374-18-000013:notes:20]
[same as prior period, unchanged from 0000866374-18-000010:notes:19]

[0000866374-18-000013:notes:21]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and enterprise products, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

[0000866374-18-000013:notes:22]
[same as prior period, unchanged from 0000866374-18-000010:notes:21]

[0000866374-18-000013:notes:23]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

[0000866374-18-000013:notes:24]
[same as prior period, unchanged from 0000866374-18-000010:notes:23]

[0000866374-18-000013:notes:25]
[same as prior period, unchanged from 0000866374-18-000010:notes:24]

[0000866374-18-000013:notes:26]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).

[0000866374-18-000013:notes:27]
[same as prior period, unchanged from 0000866374-18-000010:notes:26]

[0000866374-18-000013:notes:28]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2018 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and six-month periods ended September 28, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019.

[0000866374-18-000013:notes:29]
The first quarters for fiscal years 2019 and 2018 ended on June 29, 2018, which is comprised of 90 days in the period, and June 30, 2017, which is comprised of 91 days in the period, respectively. The second quarters for fiscal years 2019 and 2018 ended on September 28, 2018 and September 29, 2017, which are comprised of 91 days in both periods.

[0000866374-18-000013:notes:30]
[same as prior period, unchanged from 0000866374-18-000010:notes:29]


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000866374-18-000013:notes:31]
The following table summarizes the activity in the Company's contract assets during the six-month period ended September 28, 2018 (in thousands):

[0000866374-18-000013:notes:32]
|  | Contract Assets |
| Beginning balance, April 1, 2018 | $ | — |  |
| Cumulative effect adjustment at April 1, 2018 | 412,787 |  |
| Revenue recognized | 3,566,140 |  |
| Amounts collected or invoiced | (3,560,769 | ) |
| Ending balance, September 28, 2018 | $ | 418,158 |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-18-000013:notes:33]
BANK BORROWINGS AND LONG TERM DEBT

[0000866374-18-000013:notes:34]
Term Loan Facility due September 2023

[0000866374-18-000013:notes:35]
In July 2018, the Company entered into a $200 million term loan facility (the "Facility"). The Facility will be used to fund capital expenditure to support our expansion plan for India. The availability period during which drawdown can be made will be from the date of the agreement to and including June 30, 2019. The maximum maturity of each drawdown will be 5 years from the funded Capex shipment date. As a result, the longest maturity date of any future drawdown under the Facility will be June 30, 2024. Borrowings under this term loan bear interest at LIBOR plus a margin of 1.15%. The Facility is unsecured, guaranteed by the Company, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to certain exceptions and limitations. This Facility agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of September 28, 2018, the Company was in compliance with the covenants under this term loan agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-18-000013:notes:36]
[same as prior period, unchanged from 0000866374-18-000010:notes:33]

[0000866374-18-000013:notes:37]
[same as prior period, unchanged from 0000866374-18-000010:notes:34]

[0000866374-18-000013:notes:38]
[same as prior period, unchanged from 0000866374-18-000010:notes:35]

[0000866374-18-000013:notes:39]
As of September 28, 2018, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $8.3 billion as summarized below:

[0000866374-18-000013:notes:40]
|  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |
| CNY | 2,258,000 |  |  | — |  |  | $ | 328,494 |  |  | $ | — |  |
| EUR | 74,296 |  |  | 38,747 |  |  | 87,302 |  |  | 45,635 |  |
| HUF | 27,835,000 |  |  | — |  |  | 101,026 |  |  | — |  |
| ILS | 179,000 |  |  | 5,250 |  |  | 49,890 |  |  | 1,463 |  |
| MXN | 4,590,000 |  |  | — |  |  | 242,508 |  |  | — |  |
| MYR | 405,700 |  |  | 45,000 |  |  | 98,135 |  |  | 10,885 |  |
| RON | 180,700 |  |  | — |  |  | 45,570 |  |  | — |  |
| SGD | 47,500 |  |  | — |  |  | 34,799 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 37,295 |  |  | 5,436 |  |
|  |  |  |  |  |  |  | 1,025,019 |  |  | 63,419 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |
| CAD | 394,519 |  |  | 416,218 |  |  | 304,213 |  |  | 320,945 |  |
| CNY | 1,552,000 |  |  | — |  |  | 226,025 |  |  | — |  |
| EUR | 1,722,006 |  |  | 1,884,924 |  |  | 2,023,008 |  |  | 2,214,953 |  |
| GBP | 36,557 |  |  | 64,161 |  |  | 48,180 |  |  | 84,499 |  |
| HUF | 89,504,773 |  |  | 97,417,006 |  |  | 324,854 |  |  | 353,571 |  |
| ILS | 224,300 |  |  | — |  |  | 62,516 |  |  | — |  |
| INR | 5,735,497 |  |  | 8,205,341 |  |  | 79,226 |  |  | 113,127 |  |
| MXN | 2,611,896 |  |  | 2,050,476 |  |  | 137,997 |  |  | 108,335 |  |
| MYR | 643,720 |  |  | 341,430 |  |  | 155,710 |  |  | 82,589 |  |
| SEK | 467,158 |  |  | 546,573 |  |  | 52,141 |  |  | 62,010 |  |
| SGD | 88,850 |  |  | 49,740 |  |  | 65,092 |  |  | 36,440 |  |
| Other | N/A |  |  | N/A |  |  | 89,580 |  |  | 256,393 |  |
|  |  |  |  |  |  |  | 3,568,542 |  |  | 3,632,862 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  | $ | 4,593,561 |  |  | $ | 3,696,281 |  |

[0000866374-18-000013:notes:41]
As of September 28, 2018, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of September 28, 2018, and March 31, 2018, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred losses were $11.8 million as of September 28, 2018, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0000866374-18-000013:notes:42]
[same as prior period, unchanged from 0000866374-18-000010:notes:39]

[0000866374-18-000013:notes:43]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 28, 2018 |  | March 31, 2018 |  | Balance SheetLocation |  | September 28, 2018 |  | March 31, 2018 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 10,317 |  |  | $ | 19,422 |  |  | Other current liabilities |  | $ | 24,621 |  |  | $ | 7,065 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 9,970 |  |  | $ | 23,912 |  |  | Other current liabilities |  | $ | 8,259 |  |  | $ | 18,246 |  |

[0000866374-18-000013:notes:44]
[same as prior period, unchanged from 0000866374-18-000010:notes:41]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000866374-18-000013:notes:45]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and overtime - for the three-month and six-month periods ended September 28, 2018 (in thousands), respectively:

[0000866374-18-000013:notes:46]
| Three-month Period Ended September 28, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 893,141 |  |  | $ | 1,203,696 |  |  | $ | 1,089,319 |  |  | $ | 1,519,041 |  |  | $ | 4,705,197 |  |
| Over time | 314,830 |  |  | 592,187 |  |  | 476,634 |  |  | 621,756 |  |  | 2,005,407 |  |
| Total segment | $ | 1,207,971 |  |  | $ | 1,795,883 |  |  | $ | 1,565,953 |  |  | $ | 2,140,797 |  |  | $ | 6,710,604 |  |

[0000866374-18-000013:notes:47]
| Six-month Period Ended September 28, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,898,321 |  |  | $ | 2,504,333 |  |  | $ | 2,153,218 |  |  | $ | 3,012,548 |  |  | $ | 9,568,420 |  |
| Over time | 525,075 |  |  | 1,099,484 |  |  | 859,046 |  |  | 1,082,535 |  |  | 3,566,140 |  |
| Total segment | $ | 2,423,396 |  |  | $ | 3,603,817 |  |  | $ | 3,012,264 |  |  | $ | 4,095,083 |  |  | $ | 13,134,560 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-18-000013:notes:48]
[same as prior period, unchanged from 0000866374-18-000010:notes:44]

[0000866374-18-000013:notes:49]
[same as prior period, unchanged from 0000866374-18-000010:notes:45]

[0000866374-18-000013:notes:50]
[same as prior period, unchanged from 0000866374-18-000010:notes:46]

[0000866374-18-000013:notes:51]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 28, 2018 |  | September 29, 2017 |  | September 28, 2018 |  | September 29, 2017 |
|  | (In thousands) |
| Cost of sales | $ | 4,767 |  |  | $ | 4,985 |  |  | $ | 10,171 |  |  | $ | 8,304 |  |
| Selling, general and administrative expenses | 14,314 |  |  | 15,479 |  |  | 29,863 |  |  | 33,956 |  |
| Total share-based compensation expense | $ | 19,081 |  |  | $ | 20,464 |  |  | $ | 40,034 |  |  | $ | 42,260 |  |

[0000866374-18-000013:notes:52]
Total unrecognized compensation expense related to share options under all plans was $4.3 million and will be recognized over a weighted-average remaining vesting period of 1.9 years. As of September 28, 2018, the number of options outstanding and exercisable under all plans was 1.1 million and 0.6 million, respectively, at a weighted-average exercise price of $3.40 per share and $4.02 per share, respectively.

[0000866374-18-000013:notes:53]
During the six-month period ended September 28, 2018, the Company granted 5.5 million unvested restricted share unit awards. Of this amount, approximately 4.2 million are plain-vanilla unvested restricted share unit awards with no performance or market conditions with an average grant date price of $14.02 per award and will vest over four years. Further, approximately 1.3 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $14.00 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 2.6 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met.

[0000866374-18-000013:notes:54]
As of September 28, 2018, approximately 14.1 million unvested restricted share unit awards under all plans were outstanding, of which vesting for a targeted amount of 2.6 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 5.2 million based on the achievement levels of the respective conditions. During the six-month period ended September 28, 2018, 0.6 million shares vested in connection with the restricted share unit awards with market conditions granted in fiscal year 2016.

[0000866374-18-000013:notes:55]
As of September 28, 2018, total unrecognized compensation expense related to unvested restricted share unit awards under all plans was approximately $168.6 million, and will be recognized over a weighted-average remaining vesting period of 2.7 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-18-000013:notes:56]
[same as prior period, unchanged from 0000866374-18-000010:notes:52]

[0000866374-18-000013:notes:57]
[same as prior period, unchanged from 0000866374-18-000010:notes:53]

[0000866374-18-000013:notes:58]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 28, 2018 |  | September 29, 2017 |  | September 28, 2018 |  | September 29, 2017 |
|  | (In thousands, except per share amounts) |
| Basic earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 86,885 |  |  | $ | 205,086 |  |  | $ | 202,920 |  |  | $ | 329,796 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 531,503 |  |  | 531,313 |  |  | 530,426 |  |  | 530,790 |  |
| Basic earnings per share | 0.16 |  |  | 0.39 |  |  | 0.38 |  |  | 0.62 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 86,885 |  |  | $ | 205,086 |  |  | $ | 202,920 |  |  | $ | 329,796 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 531,503 |  |  | 531,313 |  |  | 530,426 |  |  | 530,790 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) | 2,955 |  |  | 4,706 |  |  | 4,601 |  |  | 5,521 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 534,458 |  |  | 536,019 |  |  | 535,027 |  |  | 536,311 |  |
| Diluted earnings per share | 0.16 |  |  | 0.38 |  |  | 0.38 |  |  | 0.61 |  |

[0000866374-18-000013:notes:59]
[same as prior period, unchanged from 0000866374-18-000010:notes:55]

[0000866374-18-000013:notes:60]
| (1) | An immaterial amount of options to purchase ordinary shares were excluded from the computation of diluted earnings per share during the three-month and six-month periods ended September 28, 2018 and September 29, 2017, respectively, due to their anti-dilutive impact on the weighted-average ordinary share equivalents. |

[0000866374-18-000013:notes:61]
| (2) | Restricted share unit awards of 3.1 million for the three-month and six-month periods ended September 28, 2018 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. An immaterial amount of anti-dilutive restricted share unit awards was excluded for the three-month and six-month periods ended September 29, 2017. |


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-18-000013:notes:62]
[same as prior period, unchanged from 0000866374-18-000010:notes:58]

[0000866374-18-000013:notes:63]
[same as prior period, unchanged from 0000866374-18-000010:notes:59]

[0000866374-18-000013:notes:64]
[same as prior period, unchanged from 0000866374-18-000010:notes:60]

[0000866374-18-000013:notes:65]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager. The Company’s deferred compensation plan assets are for the most part included in other noncurrent assets on the condensed consolidated balance sheets and primarily include investments in equity securities that are valued using active market prices.

[0000866374-18-000013:notes:66]
[same as prior period, unchanged from 0000866374-18-000010:notes:62]

[0000866374-18-000013:notes:67]
[same as prior period, unchanged from 0000866374-18-000010:notes:63]

[0000866374-18-000013:notes:68]
[same as prior period, unchanged from 0000866374-18-000010:notes:64]

[0000866374-18-000013:notes:69]
[same as prior period, unchanged from 0000866374-18-000010:notes:65]

[0000866374-18-000013:notes:70]
[same as prior period, unchanged from 0000866374-18-000010:notes:66]

[0000866374-18-000013:notes:71]
[same as prior period, unchanged from 0000866374-18-000010:notes:67]

[0000866374-18-000013:notes:72]
There were no transfers between levels in the fair value hierarchy during the six-month periods ended September 28, 2018 and September 29, 2017.

[0000866374-18-000013:notes:73]
[same as prior period, unchanged from 0000866374-18-000010:notes:69]

[0000866374-18-000013:notes:74]
[same as prior period, unchanged from 0000866374-18-000010:notes:70]

[0000866374-18-000013:notes:75]
|  | Fair Value Measurements as of September 28, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 451,551 |  |  | $ | — |  |  | $ | 451,551 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 20,287 |  |  | — |  |  | 20,287 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 6,267 |  |  | 76,021 |  |  | — |  |  | 82,288 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0.003 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (32,880 | ) |  | $ | — |  |  | $ | (32,880 | ) |
|  | Fair Value Measurements as of March 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 452,622 |  |  | $ | — |  |  | $ | 452,622 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 43,334 |  |  | — |  |  | 43,334 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,196 |  |  | 67,532 |  |  | — |  |  | 74,728 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (25,311 | ) |  | $ | — |  |  | $ | (25,311 | ) |

[0000866374-18-000013:notes:76]
[same as prior period, unchanged from 0000866374-18-000010:notes:72]

[0000866374-18-000013:notes:77]
[same as prior period, unchanged from 0000866374-18-000010:notes:73]

[0000866374-18-000013:notes:78]
|  | As of September 28, 2018 |  | As of March 31, 2018 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 507,031 |  |  | $ | 500,000 |  |  | $ | 513,596 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 679,688 |  |  | 683,086 |  |  | 687,813 |  |  | 689,966 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 471,094 |  |  | 473,449 |  |  | 483,656 |  |  | 485,470 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 513,830 |  |  | 500,000 |  |  | 525,292 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,599 |  |  | 605,146 |  |  | 596,387 |  |  | 627,407 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 55,804 |  |  | 55,804 |  |  | 59,443 |  |  | 59,443 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 117,481 |  |  | 117,481 |  |  | 123,518 |  |  | 123,518 |  |  | Level 1 |
| Total | $ | 2,920,666 |  |  | $ | 2,955,827 |  |  | $ | 2,950,817 |  |  | $ | 3,024,692 |  |  |  |

[0000866374-18-000013:notes:79]
The Company values its Euro Term Loans due September 2020 and January 2022 based on the current market rate, and as of September 28, 2018, the carrying amounts approximate fair values.

[0000866374-18-000013:notes:80]
[same as prior period, unchanged from 0000866374-18-000010:notes:76]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000866374-18-000013:notes:81]
Recently Adopted Accounting Pronouncement

[0000866374-18-000013:notes:82]
In January 2017, the FASB issued Accounting Standard Update (ASU) No. 2017-01 “Business Combinations (Topic 805): Clarifying the Definition of a Business” to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The Company adopted the guidance on a prospective basis during the first quarter of fiscal year 2019, which did not have a material impact to its financial position as there were no acquisitions during the period.

[0000866374-18-000013:notes:83]
In August 2016, the FASB issued ASU 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force)." The ASU is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 is consistent with our current cash flow classification. However, cash receipts on the deferred purchase price from the Company's asset-backed securitization programs described in note 10 will be classified as cash flows from investing activities instead of the Company's former presentation as cash flows from operations. The Company adopted the guidance during the first quarter of fiscal year 2019 using a monthly approach to track cash flows on deferred purchase price and retrospectively adjusted cash flows from operating and investing activities for fiscal year 2018. Commencing with the quarter ending September 28, 2018, the Company changed to a method based on daily activity and retrospectively adjusted cash flows from operating and investing activities for the six-month period ended September 29, 2017. The Company recorded $1.8 billion of cash receipts on the deferred purchase price from the Company's asset-backed securitization programs for the six-month period ended September 28, 2018 and reclassified $2.5 billion of cash receipts on the deferred purchase price for the six-month period ended September 29, 2017, from cash flows from operating activities to cash flows from investing activities.

[0000866374-18-000013:notes:84]
In January 2016, the FASB issued ASU 2016-01 "Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This guidance generally requires equity investments, except those accounted for under the equity method of accounting or those that result in consolidation of the investee, to be measured at fair value with changes in fair value recognized in net income. This guidance also requires the separate presentation of financial assets and financial liabilities by measurement category and form of financial asset on the balance sheet or in the accompanying notes to the financial statements. The Company adopted this guidance on April 1, 2018 with an insignificant impact on the Company's financial position, results of operations or cash flows.

[0000866374-18-000013:notes:85]
In February 2018, the FASB issued ASU 2018-03 "Technical Corrections and Improvements to Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This standard comes as an addition to ASU 2016-01 which the Company adopted in the first quarter of fiscal year 2019.  This update includes amendments to clarify certain aspects of the guidance issued in Update 2016-01. The Company adopted this guidance during the second quarter of fiscal year 2019 with an immaterial impact on its consolidated financial statements.

[0000866374-18-000013:notes:86]
In May 2014, the FASB issued ASU 2014-09 "Revenue from Contracts with Customers (Topic 606)" (also referred to as Accounting Standard Codification 606 ("ASC 606")) which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract.

[0000866374-18-000013:notes:87]
The Company adopted the standard on April 1, 2018 using the modified retrospective approach by applying the guidance to all open contracts at the adoption date and has implemented revised accounting policies, new operational and financial reporting processes, enhanced systems capabilities and relevant internal controls.

[0000866374-18-000013:notes:88]
As part of adopting ASC 606, revenue for certain customer contracts where the Company is manufacturing products for which there is no alternative use and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory will be recognized over time (i.e., as we manufacture the product) instead of upon shipment of products.  In addition to the following disclosures, note 3 provides further disclosures required by the new standard.

[0000866374-18-000013:notes:89]
The cumulative effect of change made to our April 1, 2018 consolidated balance sheet for the adoption of ASC 606 was as follows:

[0000866374-18-000013:notes:90]
| Condensed Consolidated Balance Sheet |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | Balance at March 31, 2018 | Adjustments | Balance at April 1, 2018 |
| ASSETS |  |  |  |
| Contract assets | — |  | 412,787 |  | 412,787 |  |
| Inventories | 3,799,829 |  | (409,252 | ) | 3,390,577 |  |
| Other current assets | 1,380,466 |  | (51,479 | ) | 1,328,987 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,719,418 |  | (87,897 | ) | 1,631,521 |  |
| Other liabilities | 531,587 |  | 2,098 |  | 533,685 |  |
| Accumulated deficit | (3,144,114 | ) | (37,855 | ) | (3,181,969 | ) |

[0000866374-18-000013:notes:91]
The adoption of ASC 606 resulted in the establishment of contract asset and contract liability balance sheet accounts and in the reclassification to these new accounts from certain asset and liability accounts, primarily inventories. The increase in accumulated deficit in the table above reflects $37.9 million of net adjustments to the balance sheet as of April 1, 2018, resulting from the adoption of ASC 606 primarily related to certain customer contracts requiring an over-time method of revenue recognition. The declines in inventories and other current asset reflect reclassifications to contract assets due to the earlier recognition of certain costs of products sold for over-time contracts. The decline in other current liabilities is primarily due to the reclassification of payments from customers in advance of work performed to contract assets to reflect the net position of the related over-time contracts.

[0000866374-18-000013:notes:92]
The following tables summarize the impacts of ASC 606 adoption on the Company’s condensed consolidated balance sheets and condensed consolidated statements of operations:

[0000866374-18-000013:notes:93]
| Condensed Consolidated Balance Sheet |  |  |  |
| As of September 28, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| ASSETS |  |  |  |
| Contract assets | 418,158 |  | (418,158 | ) | — |  |
| Inventories | 4,442,855 |  | 415,623 |  | 4,858,478 |  |
| Other current assets | 935,030 |  | 8,059 |  | 943,089 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,456,519 |  | 34,327 |  | 1,490,846 |  |
| Accumulated deficit | (2,902,492 | ) | (38,520 | ) | (2,941,012 | ) |

[0000866374-18-000013:notes:94]
| Condensed Consolidated Statement of Operations |  |  |  |  |  |  |  |
|  | Impact of Adopting ASC 606 |
|  | Three-months ended September 28, 2018 |  | Six-months ended September 28, 2018 |
| (In thousands, except per share amounts)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |  | As Reported | Adjustments | Balance without ASC 606 Adoption |
| Net sales | $ | 6,710,604 |  | $ | (115,533 | ) | $ | 6,595,071 |  |  | $ | 13,134,560 |  | $ | (27,237 | ) | $ | 13,107,323 |  |
| Cost of sales | 6,308,303 |  | (111,917 | ) | 6,196,386 |  |  | 12,354,405 |  | (26,573 | ) | 12,327,832 |  |
| Gross profit | 402,301 |  | (3,616 | ) | 398,685 |  |  | 780,155 |  | (664 | ) | 779,491 |  |
| Net income | $ | 86,885 |  | $ | (3,616 | ) | $ | 83,269 |  |  | $ | 202,920 |  | $ | (664 | ) | $ | 202,256 |  |

[0000866374-18-000013:notes:95]
To align contractual terms across the vast majority of customers to allow the Company to efficiently and accurately manage its contracts, in the first quarter of fiscal year 2019, the Company waived certain contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. These modifications resulted in revenue from these customers being recognized upon shipment of products, rather than over time (i.e., as we manufacture products) as further explained in note 3. The result of the amendments for the six-month period ended September 28, 2018, was to reduce revenue and gross profit by approximately $132.7 million and $9.3 million, respectively, compared to amounts that would have been reported both (i) under ASC 606 had we not amended the contracts, and (ii) had we not adopted ASC 606.

[0000866374-18-000013:notes:96]
For the three-month period ended September 28, 2018 the as reported revenue was approximately $115.5 million higher, and the gross profit $3.6 million higher, than they would have been without ASC 606 adoption primarily due to additional inventory build up as of September 28, 2018 for those customer contracts that meet the criteria for over-time recognition (see note 3) partially offset by a decline in the aggregate average gross profit margin for those customers due to the increasing mix of lower margin customers included in the CTG segment.

[0000866374-18-000013:notes:97]
For the six-month period ended September 28, 2018 the as reported revenue was approximately $27.2 million higher and the gross profit approximately $0.7 million higher than it would have been without ASC 606 adoption. Additional revenue of $160.0 million was reported under ASC 606 due to the accelerated timing of recognition of revenue for contracts which meet the criteria for over-time recognition (see note 3). Approximately $10.0 million of additional gross profit was recognized on the customers qualifying for accelerated revenue recognition. These increases were offset by reductions of $132.7 million of revenue and $9.3 million of gross profit respectively as a result of the waiver of contracts noted above. There was no material tax impact for the three and six-month periods ended September 28, 2018 from adopting ASC 606.

[0000866374-18-000013:notes:98]
The Company applies the following practical expedients:

[0000866374-18-000013:notes:99]
| • | The Company elected to not disclose information about remaining performance obligations as its performance obligations generally have an expected duration of one year or less. |

[0000866374-18-000013:notes:100]
| • | In accordance with ASC 606-10-25-18B the Company will account for certain shipping and handling as activities to fulfill the promise to transfer the good, instead of a promised service to its customer. |

[0000866374-18-000013:notes:101]
| • | In accordance with ASC 606-10-32-18 the Company elected to not adjust the promised amount of consideration for the effects of a significant financing component as the Company expects, at contract inception, that the period between when the entity transfers a promised good or service to a customer and when the customer pays for that good or service will generally be one year or less. |

[0000866374-18-000013:notes:102]
Recently Issued Accounting Pronouncements

[0000866374-18-000013:notes:103]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing arrangement that is hosted by the vendor, i.e. a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company is still evaluating the impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-18-000013:notes:104]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-18-000013:notes:105]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-18-000013:notes:106]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-18-000013:notes:107]
In January 2017, the FASB issued ASU 2017-04 "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment" to simplify the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. This guidance requires that the change be applied on a prospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2021, with early application permitted. The Company is currently assessing the impact of the new guidance and the timing of adoption.

[0000866374-18-000013:notes:108]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. In July 2018, the FASB issued ASU 2018-11, "Leases (Topic 842): Targeted Improvements", which provides entities with relief from the costs of implementing certain aspects of the new leasing standard, ASC 842. Specifically, under the amendments in ASU 2018-11, (1) entities may elect not to recast the comparative periods presented when transitioning to ASC 842 and (2) lessors may elect not to separate lease and nonlease components when certain conditions are met. Also in July 2018, the FASB issued ASU 2018-10, "Codification Improvements to Topic 842, Leases", which clarifies how to apply certain aspects of the new leases standard, ASC 842. The amendments address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options, variable payments that depend on an index or rate and certain transition adjustments, among other things. The amendments have the same effective date and transition requirements as the new leases standard. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach. The Company believes the new guidance will have a material impact on its consolidated balance sheets upon adoption.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-18-000013:notes:109]
[same as prior period, unchanged from 0000866374-18-000010:notes:102]


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-18-000013:notes:110]
OTHER CHARGES (INCOME), NET

[0000866374-18-000013:notes:111]
During the six-month period ended September 28, 2018, the Company recognized other income of $80.4 million, primarily driven by a $87.3 million gain on the deconsolidation of AutoLab. Refer to note 2 for further details of the deconsolidation.

[0000866374-18-000013:notes:112]
During the six-month period ended September 29, 2017, the Company deconsolidated Elementum SCM (Cayman) Ltd and recognized a gain on deconsolidation of approximately $151.6 million with no related tax impact, which is included in other charges (income), net on the condensed consolidated statement of operations.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-18-000013:notes:113]
[same as prior period, unchanged from 0000866374-18-000010:notes:106]

[0000866374-18-000013:notes:114]
[same as prior period, unchanged from 0000866374-18-000010:notes:107]

[0000866374-18-000013:notes:115]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that create enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, we bid on a program-by-program basis and typically receive customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

[0000866374-18-000013:notes:116]
[same as prior period, unchanged from 0000866374-18-000010:notes:109]

[0000866374-18-000013:notes:117]
[same as prior period, unchanged from 0000866374-18-000010:notes:110]

[0000866374-18-000013:notes:118]
[same as prior period, unchanged from 0000866374-18-000010:notes:111]

[0000866374-18-000013:notes:119]
[same as prior period, unchanged from 0000866374-18-000010:notes:112]

[0000866374-18-000013:notes:120]
[same as prior period, unchanged from 0000866374-18-000010:notes:113]

[0000866374-18-000013:notes:121]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises).  The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-18-000013:notes:122]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that Flex would sell similar goods or services separately.

[0000866374-18-000013:notes:123]
[same as prior period, unchanged from 0000866374-18-000010:notes:116]

[0000866374-18-000013:notes:124]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheet and transferred to receivables when rights to payment become unconditional. The following table summarizes the activity in the Company's contract assets during the six-month period ended September 28, 2018 (in thousands):

[0000866374-18-000013:notes:125]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $247.1 million and $265.3 million as of September 28, 2018 and April 1, 2018, respectively.

[0000866374-18-000013:notes:126]
[same as prior period, unchanged from 0000866374-18-000010:notes:119]


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000866374-18-000013:notes:127]
[same as prior period, unchanged from 0000866374-18-000010:notes:120]

[0000866374-18-000013:notes:128]
|  | As of September 28, 2018 |  | As of March 31, 2018 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 303,361 |  |  | $ | (98,112 | ) |  | $ | 205,249 |  |  | $ | 306,943 |  |  | $ | (79,051 | ) |  | $ | 227,892 |  |
| Licenses and other intangibles | 287,024 |  |  | (116,866 | ) |  | 170,158 |  |  | 304,007 |  |  | (107,466 | ) |  | 196,541 |  |
| Total | $ | 590,385 |  |  | $ | (214,978 | ) |  | $ | 375,407 |  |  | $ | 610,950 |  |  | $ | (186,517 | ) |  | $ | 424,433 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000866374-18-000013:notes:129]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the six-month period ended September 28, 2018:

[0000866374-18-000013:notes:130]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year | $ | 550,983 |  |  | $ | 107,748 |  |  | $ | 337,707 |  |  | $ | 124,732 |  |  | $ | 1,121,170 |  |
| Divestitures (1) | (4,006 | ) |  | (4,412 | ) |  | (4,120 | ) |  | (6,391 | ) |  | (18,929 | ) |
| Foreign currency translation adjustments (2) | (19,718 | ) |  | — |  |  | — |  |  | — |  |  | (19,718 | ) |
| Balance, end of the period | $ | 527,259 |  |  | $ | 103,336 |  |  | $ | 333,587 |  |  | $ | 118,341 |  |  | $ | 1,082,523 |  |

[0000866374-18-000013:notes:131]
| (1) | During the six-month period ended September 28, 2018, the Company divested its China-based Multek operations, and as a result, recorded an aggregate reduction of goodwill of $18.9 million, which is included in the loss on sale recorded in other charges (income), net on the condensed consolidated statement of operation. See note 12 for additional information. |

[0000866374-18-000013:notes:132]
| (2) | During the six-month period ended September 28, 2018, the Company recorded $19.7 million of foreign currency translation adjustments primarily related to the goodwill associated with the acquisition of Mirror Controls International ("MCi") and AGM Automotive ("AGM"), as the U.S. Dollar fluctuated against foreign currencies. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000866374-18-000013:notes:133]
[same as prior period, unchanged from 0000866374-18-000010:notes:125]

[0000866374-18-000013:notes:134]
|  | As of September 28, 2018 |  | As of March 31, 2018 |
|  | (In thousands) |
| Raw materials | $ | 3,512,523 |  |  | $ | 2,760,410 |  |
| Work-in-progress | 407,998 |  |  | 450,569 |  |
| Finished goods | 522,334 |  |  | 588,850 |  |
|  | $ | 4,442,855 |  |  | $ | 3,799,829 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-18-000013:notes:135]
Selected financial information by segment is in the table below. For the six-month period ended September 28, 2018, we recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings, as further described in note 1 to the condensed consolidated financial statements. The comparative information for the three and six-month periods ended September 29, 2017 has not been restated and continues to be reported under the accounting standards in effect at the time:

[0000866374-18-000013:notes:136]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 28, 2018 |  | September 29, 2017 |  | September 28, 2018 |  | September 29, 2017 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 2,140,797 |  |  | $ | 1,901,057 |  |  | $ | 4,095,083 |  |  | $ | 3,874,390 |  |
| Consumer Technologies Group | 1,795,883 |  |  | 1,755,143 |  |  | 3,603,817 |  |  | 3,267,112 |  |
| Industrial & Emerging Industries | 1,565,953 |  |  | 1,454,539 |  |  | 3,012,264 |  |  | 2,845,138 |  |
| High Reliability Solutions | 1,207,971 |  |  | 1,159,681 |  |  | 2,423,396 |  |  | 2,292,052 |  |
|  | $ | 6,710,604 |  |  | $ | 6,270,420 |  |  | $ | 13,134,560 |  |  | $ | 12,278,692 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 62,855 |  |  | $ | 42,733 |  |  | $ | 108,873 |  |  | $ | 91,335 |  |
| Consumer Technologies Group | 31,212 |  |  | 30,722 |  |  | 57,769 |  |  | 48,726 |  |
| Industrial & Emerging Industries | 65,857 |  |  | 50,945 |  |  | 117,218 |  |  | 106,322 |  |
| High Reliability Solutions | 89,589 |  |  | 92,364 |  |  | 183,123 |  |  | 182,576 |  |
| Corporate and Other | (25,983 | ) |  | (28,438 | ) |  | (55,745 | ) |  | (62,716 | ) |
| Total segment income | 223,530 |  |  | 188,326 |  |  | 411,238 |  |  | 366,243 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 18,234 |  |  | 16,376 |  |  | 36,751 |  |  | 36,277 |  |
| Stock-based compensation | 19,081 |  |  | 20,464 |  |  | 40,034 |  |  | 42,260 |  |
| Customer related asset impairments (1) | 30,100 |  |  | 4,753 |  |  | 47,464 |  |  | 4,753 |  |
| New revenue standard adoption impact (Note 1 & Note 3) | — |  |  | — |  |  | 9,291 |  |  | — |  |
| Contingencies and other (2) | (269 | ) |  | 43,933 |  |  | 24,859 |  |  | 43,933 |  |
| Other charges (income), net (Note 7) | 6,530 |  |  | (143,167 | ) |  | (80,394 | ) |  | (179,332 | ) |
| Interest and other, net | 41,060 |  |  | 27,554 |  |  | 82,802 |  |  | 54,430 |  |
| Income before income taxes | $ | 108,794 |  |  | $ | 218,413 |  |  | $ | 250,431 |  |  | $ | 363,922 |  |

[0000866374-18-000013:notes:137]
| (1) | Customer related asset impairments for the three and six-month periods ended September 28, 2018 relate to additional provision for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties as well as $30 million of exit costs primarily related to our estimated impairment of fixed assets considered not recoverable in conjunction with the wind-down of our NIKE footwear manufacturing operations in Mexico. |

[0000866374-18-000013:notes:138]
| (2) | Contingencies and other during the three and six-month periods ended September 28, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018, along with certain restructuring charges incurred during our first quarter of fiscal year 2019 offset by certain immaterial reversals in the second quarter of fiscal year 2019. |

[0000866374-18-000013:notes:139]
During the three and six-month periods ended September 29, 2017, the Company incurred charges in connection with certain legal matters, for loss contingencies where it believed that losses were probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility, along with certain restructuring charges primarily related to severance for rationalization at existing sites and corporate functions.


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0000866374-18-000013:notes:140]
[same as prior period, unchanged from 0000866374-18-000010:notes:131]

[0000866374-18-000013:notes:141]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2019 (1) | $ | 35,987 |  |
| 2020 | 66,906 |  |
| 2021 | 62,515 |  |
| 2022 | 53,678 |  |
| 2023 | 45,421 |  |
| Thereafter | 110,900 |  |
| Total amortization expense | $ | 375,407 |  |

[0000866374-18-000013:notes:142]
| (1) | Represents estimated amortization for the remaining six-month period ending March 31, 2019. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-18-000013:notes:143]
[same as prior period, unchanged from 0000866374-18-000010:notes:134]

[0000866374-18-000013:notes:144]
[same as prior period, unchanged from 0000866374-18-000010:notes:135]

[0000866374-18-000013:notes:145]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairments charges, the new revenue standard adoption impact, contingencies and other, other charges (income), net and interest and other, net.

[0000866374-18-000013:notes:146]
[same as prior period, unchanged from 0000866374-18-000010:notes:137]

[0000866374-18-000013:notes:147]
[same as prior period, unchanged from 0000866374-18-000010:notes:138]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-18-000013:notes:148]
[same as prior period, unchanged from 0000866374-18-000010:notes:139]

[0000866374-18-000013:notes:149]
[same as prior period, unchanged from 0000866374-18-000010:notes:140]

[0000866374-18-000013:notes:150]
Due to the adoption of ASC 606, amounts that would have been reported as inventory under prior guidance are now included in contract assets or liabilities, depending on the net position of the contract, as disclosed in note 1.  As a result of this accounting change, work-in-progress and finished goods as of September 28, 2018 are $415.6 million less than they would have been, had we not adopted ASC 606. The comparative information as of March 31, 2018, has not been restated and continues to be reported under the accounting standards in effect at that time.

[0000866374-18-000013:notes:151]
[same as prior period, unchanged from 0000866374-18-000010:notes:142]

[0000866374-18-000013:notes:152]
In accordance with accounting guidance on goodwill and other intangible assets, the Company evaluates goodwill for impairment at the reporting unit level annually, and whenever circumstances occur indicating that goodwill might be impaired. The performance of the test involves a two-step process. The first step of the impairment test involves comparing the fair value of each of the Company's reporting units with the reporting unit's carrying amount, including goodwill. The Company generally determines the fair value of its reporting units based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. If the carrying amount of a reporting unit exceeds the reporting unit's fair value using these approaches, the Company performs the second step of the goodwill impairment test to determine the amount of impairment loss. The second step of the goodwill impairment test involves comparing the implied fair value of the Company's reporting unit's goodwill with the carrying amount of that goodwill.

[0000866374-18-000013:notes:153]
During October 2018, the Company's market capitalization declined significantly. The Company believes the significant drop in market value constitutes a “triggering event” in accordance with the applicable accounting literature, and accordingly commenced an interim impairment test. The Company is in the process of completing the first step of the test, and based on preliminary results believes that it is probable that the fair value of the CTG reporting unit is lower than its carrying value. The Company is in the process of finalizing the long-term financial projections necessary to complete the first step of the goodwill impairment test. If it is determined that the goodwill of any of the reporting units is in fact impaired, the Company will then proceed to the second step of the impairment test in which it will measure the fair value of such reporting unit’s identified tangible and intangible assets and liabilities in order to determine the implied fair value of its goodwill and any resulting goodwill impairment.

[0000866374-18-000013:notes:154]
As of the date of the filing of this Form 10-Q, the Company has not finalized its impairment analysis due to the limited time period from the first indication of potential impairment to the date of this filing and the complexities involved in developing long-term cash flow forecasts and in estimating the fair value of each reporting unit’s assets and liabilities. Accounting guidance provides that in circumstances in which step two of the impairment analysis has not been completed, a company should recognize an estimated impairment charge to the extent that it determines that it is probable that an impairment loss has occurred and such impairment loss can be reasonably estimated. As of the date of the filing of this Form 10-Q, such impairment loss is not reasonably estimable and thus no impairment charge has been recognized by the Company. The Company will complete its impairment analysis during the quarter ending December 31, 2018, which may result in a material impairment of its recorded goodwill.

[0000866374-18-000013:notes:155]
[same as prior period, unchanged from 0000866374-18-000010:notes:143]

[0000866374-18-000013:notes:156]
[same as prior period, unchanged from 0000866374-18-000010:notes:144]

[0000866374-18-000013:notes:157]
Other current assets include approximately $304.3 million and $445.4 million as of September 28, 2018 and March 31, 2018, respectively, for the deferred purchase price receivable from the Company's Asset-Backed Securitization programs. See note 10 for additional information. Assets held for sale related to the China-based Multek operations previously recorded in other current assets have been removed from the condensed consolidated balance sheet as of September 28, 2018, following the execution of the divestiture. See note 12 for additional information.

[0000866374-18-000013:notes:158]
Investments

[0000866374-18-000013:notes:159]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other assets. These privately held companies range from startups to more mature companies with established revenue streams and business models. The primary purpose of these investments is to create an ecosystem of partnerships with customers developing emerging technologies aligned to the Company's corporate strategy with bringing in future opportunities for exclusive manufacturing.

[0000866374-18-000013:notes:160]
Non-majority-owned investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the condensed consolidated statements of operations. Cost method is used for investments which the Company does not have the ability to significantly influence the operating decisions of the investee.

[0000866374-18-000013:notes:161]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, primarily comparable company multiples and discounted cash flow projections. For investments accounted for under cost method that do not have readily determinable fair values, the Company has elected, per ASU 2016-01, to measure them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-18-000013:notes:162]
AutoLab AI (now known as Bright Machines)

[0000866374-18-000013:notes:163]
[same as prior period, unchanged from 0000866374-18-000010:notes:149]

[0000866374-18-000013:notes:164]
[same as prior period, unchanged from 0000866374-18-000010:notes:150]

[0000866374-18-000013:notes:165]
The fair value of the Company’s non-controlling interest in AutoLab upon deconsolidation was approximately $127.6 million as of the date of deconsolidation. The Company accounts for its investment in AutoLab under the equity method, with the carrying amount included in other assets on the condensed consolidated balance sheet. The value of the Company’s interest on the date of deconsolidation was based on management’s estimate of the fair value of AutoLab at that time. Management relied on a multi-stage process which involved calculating the enterprise and equity value of AutoLab, then allocating the equity value of the entity to the Company’s securities. The enterprise value of AutoLab was estimated based on the value implied by the equity funding AutoLab received from third parties in the same period (i.e., level 2 inputs). The Company recognized a gain on deconsolidation of approximately $87.3 million with no material tax impact, which is included in other charges (income), net on the condensed consolidated statement of operations.

[0000866374-18-000013:notes:166]
In addition, during the first quarter of fiscal year 2019, the Company leased approximately $76.5 million of fixed assets to AutoLab under a five-year lease term based on an interest rate of 4.20% per year. The leases were concluded to be sales-type leases and as such, the Company derecognized the associated assets from property and equipment, net and recorded a total net investment in the lease of $88.2 million in other current assets and other assets, based on the present value of lease receivables. The Company recorded an immaterial gain related to this leasing transaction, which is included in cost of sales on the condensed consolidated statement of operations.

[0000866374-18-000013:notes:167]
Pro-forma financials have not been presented because the effects were not material to the Company’s condensed consolidated financial position and results of operation for all periods presented. AutoLab became a related party to the Company starting on the date of deconsolidation. The Company has engaged AutoLab as a strategic partner to develop and deploy automation solutions for Flex and has entered into a 5-year subscription agreement. Subscription fees under the AutoLab agreement were immaterial for the six-month period ended September 28, 2018.

[0000866374-18-000013:notes:168]
As of September 28, 2018, and March 31, 2018, the Company's investments in non-majority owned companies totaled $557.2 million and $411.1 million, respectively. The equity in the earnings or losses of the Company's equity method investments, including AutoLab, was not material to the consolidated results of operations for any period presented and is included in interest and other, net.

[0000866374-18-000013:notes:169]
[same as prior period, unchanged from 0000866374-18-000010:notes:155]

[0000866374-18-000013:notes:170]
Other current liabilities include customer working capital advances of $226.5 million and $153.6 million, customer-related accruals of $369.8 million and $439.0 million, and deferred revenue of $247.1 million and $329.0 million as of September 28, 2018 and March 31, 2018, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Liabilities held for sale related to the China-based Multek operations previously recorded in other current liabilities have been removed from the condensed consolidated balance sheet as of September 28, 2018, following the execution of the divestiture. See note 12 for additional information.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-18-000013:notes:171]
[same as prior period, unchanged from 0000866374-18-000010:notes:157]

[0000866374-18-000013:notes:172]
[same as prior period, unchanged from 0000866374-18-000010:notes:158]

[0000866374-18-000013:notes:173]
[same as prior period, unchanged from 0000866374-18-000010:notes:159]

[0000866374-18-000013:notes:174]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables, which are included in other current assets as of September 28, 2018 and March 31, 2018, were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables, and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-18-000013:notes:175]
[same as prior period, unchanged from 0000866374-18-000010:notes:161]

[0000866374-18-000013:notes:176]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month and six-month periods ended September 28, 2018, and September 29, 2017 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0000866374-18-000013:notes:177]
[same as prior period, unchanged from 0000866374-18-000010:notes:163]

[0000866374-18-000013:notes:178]
As of September 28, 2018, and March 31, 2018, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company during the six-month periods ended September 28, 2018 and September 29, 2017 were included as cash provided by operating activities in the condensed consolidated statements of cash flows. We recognize these proceeds net of the deferred purchase price, consisting of a receivable from the purchasers that entitles us to certain collections on the receivable. We recognize the collection of the deferred purchase price in net cash provided by investing activities in the condensed consolidated statements of cash flows as cash collections of deferred purchase price.

[0000866374-18-000013:notes:179]
As of September 28, 2018, approximately $1.3 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $1.0 billion and deferred purchase price receivables of $304.3 million. As of March 31, 2018, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $1.1 billion and deferred purchase price receivables of $445.4 million. The deferred purchase price balances as of September 28, 2018 and March 31, 2018, also represent the non-cash beneficial interest obtained in exchange for securitized receivables.

[0000866374-18-000013:notes:180]
For the six-month periods ended September 28, 2018 and September 29, 2017, cash flows from sales of receivables under the ABS Programs consisted of approximately $3.7 billion and $4.0 billion, respectively, for transfers of receivables, and approximately $1.8 billion and $2.5 billion, respectively, for collection on deferred purchase price receivables. The Company's cash flows from transfer of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-18-000013:notes:181]
[same as prior period, unchanged from 0000866374-18-000010:notes:167]

[0000866374-18-000013:notes:182]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $463.2 million and $286.4 million as of September 28, 2018 and March 31, 2018, respectively. For the six-month periods ended September 28, 2018 and September 29, 2017, total accounts receivable sold to certain third-party banking institutions was approximately $1.4 billion and $0.6 billion, respectively, primarily due to certain customers transferring from the ABS Programs to the Trade Account Receivable Sale Program. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-18-000013:notes:183]
[same as prior period, unchanged from 0000866374-18-000010:notes:169]

[0000866374-18-000013:notes:184]
During the three-month and six-month periods ended September 28, 2018, the Company repurchased 4.4 million shares at an aggregate purchase price of $60.0 million, and retired all of these shares.

[0000866374-18-000013:notes:185]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 16, 2018. As of September 28, 2018, shares in the aggregate amount of $453.5 million were available to be repurchased under the current plan.
