# FLEX 8-K — 0001104659-18-063948 filed 2018-10-25

## item codes, every 8-K on or before 2018-11-02

- 2018-10-25 0001104659-18-063948 — 2.02, 9.01
- 2018-10-25 0001104659-18-063944 — 5.02, 9.01
- 2018-08-21 0001104659-18-053031 — 5.07, 8.01, 9.01
- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2018-11-02

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-18-063948:8k_2_02:1]
EX-99.1
2
a18-37071_1ex99d1.htm
EX-99.1

[0001104659-18-063948:8k_2_02:2]
Exhibit 99.1

[0001104659-18-063948:8k_2_02:3]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:4]
FLEX REPORTS SECOND QUARTER FISCAL 2019 RESULTS

[0001104659-18-063948:8k_2_02:5]
·                  Quarterly revenue of $6.7 billion, increased 7% year-over-year

[0001104659-18-063948:8k_2_02:6]
·                  GAAP diluted EPS of $0.16, Non-GAAP diluted EPS of $0.29

[0001104659-18-063948:8k_2_02:7]
·                  Repurchased 4.4 million shares for approximately $60 million.

[0001104659-18-063948:8k_2_02:8]
·                  Winding down NIKE Mexico Operation

[0001104659-18-063948:8k_2_02:9]
San Jose, CA, October 25, 2018 — Flex (NASDAQ: FLEX), the Sketch-to-Scale® solutions provider that designs and builds Intelligent Products for a Connected World®, today announced results for its second quarter ended September 28, 2018.

[0001104659-18-063948:8k_2_02:10]
|  |  | Three-Month Periods Ended |  |
| US$ in millions, except earnings per share |  | September 28, 2018 |  | September 29, 2017 |  |
| Net sales |  | $ | 6,711 |  | $ | 6,270 |  |
| GAAP income before income taxes |  | 109 |  | 218 |  |
| Adjusted operating income |  | 224 |  | 188 |  |
| GAAP net income |  | 87 |  | 205 |  |
| Adjusted net income |  | 153 |  | 142 |  |
| GAAP EPS |  | 0.16 |  | 0.38 |  |
| Adjusted EPS |  | 0.29 |  | 0.27 |  |

[0001104659-18-063948:8k_2_02:11]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release.

[0001104659-18-063948:8k_2_02:12]
Second Quarter Fiscal 2019 Results of Operations

[0001104659-18-063948:8k_2_02:13]
Net sales for the second quarter ended September 28, 2018 were $6.7 billion, growing 7% year-over-year, and within the guidance range of $6.6 to $7.0 billion. GAAP income before income taxes was $109 million for the quarter and adjusted operating income was $224 million, above the midpoint of the guidance range of $200 million to $230 million. GAAP net income was $87 million and adjusted net income for the quarter was $153 million. GAAP net income per share was $0.16 for the quarter and adjusted EPS was $0.29 for the quarter.

[0001104659-18-063948:8k_2_02:14]
NIKE Update

[0001104659-18-063948:8k_2_02:15]
The Company has worked hard with NIKE to make the footwear manufacturing operations in Mexico technically and commercially successful. In recent weeks, however, it became clear that the Company would be unable to reach a commercially viable solution. Accordingly, Flex and NIKE have mutually agreed to wind-down the footwear manufacturing operations in Guadalajara by December 31, 2018. The Company is in the process of finalizing the terms and details of the wind-down and is striving hard to retain many of the affected employees and repurpose the facility. In connection with the wind-down of the operation, the Company recognized $30 million of exit costs primarily related to an estimated impairment of fixed assets. The Company may incur additional costs to complete the wind-down.

[0001104659-18-063948:8k_2_02:16]
Balance Sheet and Cash Flow Highlights

[0001104659-18-063948:8k_2_02:17]
Flex ended the quarter with approximately $1.38 billion of cash on hand and total debt of approximately $2.9 billion. The balance sheet remains well positioned to support the business over the long term.

[0001104659-18-063948:8k_2_02:18]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:19]
Flex’s cash from operations was negative $764 million and negative $1.7 billion for the three and six-month periods ended September 28, 2018, respectively, and reflects the impacts due to cash collections under our ABS programs of the deferred purchase price for receivables sold of $885 million and $1.8 billion for those respective periods that due to a recent accounting change are now included as investing cash activities. Adjusted to exclude the impacts from the new accounting noted above, cash from operations was $120 million and $105 million for the three and six-month periods ended September 28, 2018, respectively.

[0001104659-18-063948:8k_2_02:20]
The Company remains committed to return over 50% of annual free cash flow to its shareholders as it repurchased ordinary shares for approximately $60 million during the three-month period ended September 28, 2018.

[0001104659-18-063948:8k_2_02:21]
Third Quarter Fiscal Year 2019 Guidance

[0001104659-18-063948:8k_2_02:22]
For the third quarter ending December 31, 2018, revenue is expected to be in the range of $6.6 to $7.0 billion. Adjusted EPS is expected to be in the range of $0.29 to $0.33 per diluted share. GAAP EPS is expected to be in the range of $0.19 to $0.23 and includes primarily stock-based compensation expense and intangible amortization.

[0001104659-18-063948:8k_2_02:23]
Updated Fiscal Year 2019 Guidance

[0001104659-18-063948:8k_2_02:24]
The Company is updating its fiscal 2019 guidance originally established at its May Investor and Analyst Day. This guidance has been updated for impacts from component shortages and incremental reductions from the India ramp due to capacity constraints as well as incremental pressures in both the automotive and industrial businesses. Our CTG performance has severely impacted our forecast and accounts for the majority of the downward guidance, which we are reducing to the following: revenue is expected to be in the range of $26.0 to $27.0 billion. Adjusted EPS is expected to be in the range of $1.05 to $1.15 per diluted share. GAAP EPS is expected to be in the range of $0.75 to $0.85 and includes stock-based compensation expense, intangible amortization, and other charges.

[0001104659-18-063948:8k_2_02:25]
Retirement of CEO, Mike McNamara

[0001104659-18-063948:8k_2_02:26]
The Company has published a separate press release that announced that Michael M. McNamara, the Company’s Chief Executive Officer and a member of the Company’s Board of Directors, has decided to retire as Chief Executive Officer, effective December 31, 2018. The Board has engaged Heidrick & Struggles International, Inc. to conduct a search for a new Chief Executive Officer and will be considering both internal and external candidates. Michael D. Capellas, Chairman of the Board, will actively assist the Company’s management with the Chief Executive Officer transition.

[0001104659-18-063948:8k_2_02:27]
Other Items

[0001104659-18-063948:8k_2_02:28]
The Company continues to undertake measures to improve our internal control over financial reporting to address and remediate the material weaknesses described further in Item 9A “Controls and Procedures” of our fiscal 2018 Form 10-K. Many of our remediation efforts have been implemented already or are in the process of implementation. Our initiatives are focused on enhancing site level controls, designing and implementing centralized reporting controls and enhancing the quality and frequency of training. While our remediation plan is being executed, we also have engaged and will continue to engage additional resources to support and supplement the Company’s existing internal resources. We are working to have the material weaknesses remediated as soon as possible.

[0001104659-18-063948:8k_2_02:29]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:30]
Webcast and Conference Call

[0001104659-18-063948:8k_2_02:31]
The Flex management team will host a conference call today at 2:00 PM (PT) / 5:00 PM (ET), to review second quarter fiscal 2019 results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com. An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0001104659-18-063948:8k_2_02:32]
About Flex

[0001104659-18-063948:8k_2_02:33]
Flex Ltd. (Reg. No. 199002645H) is the Sketch-to-Scale® solutions provider that designs and builds Intelligent Products for a Connected World®. With approximately 200,000 professionals across 30 countries, Flex provides innovative design, engineering, manufacturing, real-time supply chain insight and logistics services to companies of all sizes in various industries and end-markets. For more information, visit flex.com or follow us on Twitter @Flexintl. Flex — Live Smarter®

[0001104659-18-063948:8k_2_02:34]
Contacts

[0001104659-18-063948:8k_2_02:35]
Investors & Analysts
 Kevin Kessel, CFA

[0001104659-18-063948:8k_2_02:36]
(408) 576-7985

[0001104659-18-063948:8k_2_02:37]
kevin.kessel@flex.com

[0001104659-18-063948:8k_2_02:38]
Media & Press

[0001104659-18-063948:8k_2_02:39]
Paul Brunato

[0001104659-18-063948:8k_2_02:40]
(408) 576-7534

[0001104659-18-063948:8k_2_02:41]
paul.brunato@flex.com

[0001104659-18-063948:8k_2_02:42]
Forward-Looking Statements

[0001104659-18-063948:8k_2_02:43]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:44]
Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our reports on Forms 10-K and 10-Q that we file with the U.S. Securities and Exchange Commission. The forward-looking statements in this press release are based on current expectations and Flex assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0001104659-18-063948:8k_2_02:45]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:46]
SCHEDULE I

[0001104659-18-063948:8k_2_02:47]
FLEX

[0001104659-18-063948:8k_2_02:48]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-18-063948:8k_2_02:49]
(In thousands, except per share amounts)

[0001104659-18-063948:8k_2_02:50]
|  |  | Three-Month Periods Ended |  |
|  |  | September 28, 2018 |  | September 29, 2017 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 6,710,604 |  | $ | 6,270,420 |  |
| Cost of sales |  | 6,308,303 |  | 5,877,095 |  |
| Gross profit |  | 402,301 |  | 393,325 |  |
| Selling, general and administrative expenses |  | 227,683 |  | 274,149 |  |
| Intangible amortization |  | 18,234 |  | 16,376 |  |
| Interest and other, net |  | 41,060 |  | 27,554 |  |
| Other charges (income), net |  | 6,530 |  | (143,167 | ) |
| Income before income taxes |  | 108,794 |  | 218,413 |  |
| Provision for income taxes |  | 21,909 |  | 13,327 |  |
| Net income |  | $ | 86,885 |  | $ | 205,086 |  |
| Earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.16 |  | $ | 0.38 |  |
| Non-GAAP |  | $ | 0.29 |  | $ | 0.27 |  |
| Diluted shares used in computing per share amounts |  | 534,458 |  | 536,019 |  |

[0001104659-18-063948:8k_2_02:51]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release.

[0001104659-18-063948:8k_2_02:52]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:53]
FLEX

[0001104659-18-063948:8k_2_02:54]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-18-063948:8k_2_02:55]
(In thousands, except per share amounts)

[0001104659-18-063948:8k_2_02:56]
|  |  | Six-Month Periods Ended |  |
|  |  | September 28, 2018 |  | September 29, 2017 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 13,134,560 |  | $ | 12,278,692 |  |
| Cost of sales |  | 12,354,405 |  | 11,478,435 |  |
| Gross profit |  | 780,155 |  | 800,257 |  |
| Selling, general and administrative expenses |  | 490,565 |  | 524,960 |  |
| Intangible amortization |  | 36,751 |  | 36,277 |  |
| Interest and other, net |  | 82,802 |  | 54,430 |  |
| Other income, net |  | (80,394 | ) | (179,332 | ) |
| Income before income taxes |  | 250,431 |  | 363,922 |  |
| Provision for income taxes |  | 47,511 |  | 34,126 |  |
| Net income |  | $ | 202,920 |  | $ | 329,796 |  |
| Earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.38 |  | $ | 0.61 |  |
| Non-GAAP |  | $ | 0.53 |  | $ | 0.51 |  |
| Diluted shares used in computing per share amounts |  | 535,027 |  | 536,311 |  |

[0001104659-18-063948:8k_2_02:57]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release.

[0001104659-18-063948:8k_2_02:58]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:59]
SCHEDULE II

[0001104659-18-063948:8k_2_02:60]
FLEX

[0001104659-18-063948:8k_2_02:61]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-18-063948:8k_2_02:62]
(In thousands, except per share amounts)

[0001104659-18-063948:8k_2_02:63]
|  |  | Three-Month Periods Ended |  |
|  |  | September 28, 2018 |  | September 29, 2017 |  |
| GAAP gross profit |  | $ | 402,301 |  | $ | 393,325 |  |
| Stock-based compensation expense |  | 4,767 |  | 4,985 |  |
| Customer related asset impairments (2) |  | 30,100 |  | — |  |
| Contingencies and other (4) |  | (3,679 | ) | 18,933 |  |
| Non-GAAP gross profit |  | $ | 433,489 |  | $ | 417,243 |  |
| GAAP income before income taxes |  | $ | 108,794 |  | $ | 218,413 |  |
| Intangible amortization |  | 18,234 |  | 16,376 |  |
| Stock-based compensation expense |  | 19,081 |  | 20,464 |  |
| Customer related asset impairments (2) |  | 30,100 |  | 4,753 |  |
| Contingencies and other (4) |  | (269 | ) | 43,933 |  |
| Other charges (income), net (5) |  | 6,530 |  | (143,167 | ) |
| Interest and other, net |  | 41,060 |  | 27,554 |  |
| Non-GAAP operating income |  | $ | 223,530 |  | $ | 188,326 |  |
| GAAP provision for income taxes |  | $ | 21,909 |  | $ | 13,327 |  |
| Intangible amortization benefit |  | 2,225 |  | 2,250 |  |
| Other adjustments for taxes (6) |  | 1,387 |  | 2,738 |  |
| Non-GAAP provision for income taxes |  | $ | 25,521 |  | $ | 18,315 |  |
| GAAP net income |  | $ | 86,885 |  | $ | 205,086 |  |
| Intangible amortization |  | 18,234 |  | 16,376 |  |
| Stock-based compensation expense |  | 19,081 |  | 20,464 |  |
| Customer related asset impairments (2) |  | 30,100 |  | 4,753 |  |
| Contingencies and other (4) |  | (269 | ) | 43,933 |  |
| Elementum deconsolidation (5) |  | — |  | (151,574 | ) |
| Other charges, net |  | 2,905 |  | 8,407 |  |
| Adjustments for taxes (6) |  | (3,612 | ) | (4,988 | ) |
| Non-GAAP net income |  | $ | 153,324 |  | $ | 142,457 |  |
| Diluted earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.16 |  | $ | 0.38 |  |
| Non-GAAP |  | $ | 0.29 |  | $ | 0.27 |  |

[0001104659-18-063948:8k_2_02:64]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:65]
FLEX

[0001104659-18-063948:8k_2_02:66]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-18-063948:8k_2_02:67]
(In thousands, except per share amounts)

[0001104659-18-063948:8k_2_02:68]
|  |  | Six-Month Periods Ended |  |
|  |  | September 28, 2018 |  | September 29, 2017 |  |
| GAAP gross profit |  | $ | 780,155 |  | $ | 800,257 |  |
| Stock-based compensation expense |  | 10,171 |  | 8,304 |  |
| Customer related asset impairments (2) |  | 42,452 |  | — |  |
| New revenue standard adoption impact (3) |  | 9,291 |  | — |  |
| Contingencies and other (4) |  | 4,212 |  | 18,933 |  |
| Non-GAAP gross profit |  | $ | 846,281 |  | $ | 827,494 |  |
| GAAP income before income taxes |  | $ | 250,431 |  | $ | 363,922 |  |
| Intangible amortization |  | 36,751 |  | 36,277 |  |
| Stock-based compensation expense |  | 40,034 |  | 42,260 |  |
| Customer related asset impairments (2) |  | 47,464 |  | 4,753 |  |
| New revenue standard adoption impact (3) |  | 9,291 |  | — |  |
| Contingencies and other (4) |  | 24,859 |  | 43,933 |  |
| Other income, net (5) |  | (80,394 | ) | (179,332 | ) |
| Interest and other, net |  | 82,802 |  | 54,430 |  |
| Non-GAAP operating income |  | $ | 411,238 |  | $ | 366,243 |  |
| GAAP provision for income taxes |  | $ | 47,511 |  | $ | 34,126 |  |
| Intangible amortization benefit |  | 4,517 |  | 4,016 |  |
| Other adjustments for taxes (6) |  | (7,709 | ) | 2,738 |  |
| Non-GAAP provision for income taxes |  | $ | 44,319 |  | $ | 40,880 |  |
| GAAP net income |  | $ | 202,920 |  | $ | 329,796 |  |
| Intangible amortization |  | 36,751 |  | 36,277 |  |
| Stock-based compensation expense |  | 40,034 |  | 42,260 |  |
| Customer related asset impairments (2) |  | 47,464 |  | 4,753 |  |
| New revenue standard adoption impact (3) |  | 9,291 |  | — |  |
| Contingencies and other (4) |  | 24,859 |  | 43,933 |  |
| Elementum deconsolidation (5) |  | — |  | (151,574 | ) |
| AutoLab deconsolidation (5) |  | (87,348 | ) | — |  |
| Other charges (income), net (5) |  | 4,132 |  | (27,758 | ) |
| Adjustments for taxes (6) |  | 3,192 |  | (6,754 | ) |
| Non-GAAP net income |  | $ | 281,295 |  | $ | 270,933 |  |
| Diluted earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.38 |  | $ | 0.61 |  |
| Non-GAAP |  | $ | 0.53 |  | $ | 0.51 |  |

[0001104659-18-063948:8k_2_02:69]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:70]
SCHEDULE III

[0001104659-18-063948:8k_2_02:71]
FLEX

[0001104659-18-063948:8k_2_02:72]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-18-063948:8k_2_02:73]
(In thousands)

[0001104659-18-063948:8k_2_02:74]
|  |  | As of September 28, 2018 |  | As of March 31, 2018 |  |
| ASSETS |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,377,720 |  | $ | 1,472,424 |  |
| Accounts receivable, net of allowance for doubtful accounts |  | 2,859,409 |  | 2,517,695 |  |
| Contract assets |  | 418,158 |  | — |  |
| Inventories |  | 4,442,855 |  | 3,799,829 |  |
| Other current assets |  | 935,030 |  | 1,380,466 |  |
| Total current assets |  | 10,033,172 |  | 9,170,414 |  |
| Property and equipment, net |  | 2,277,885 |  | 2,239,506 |  |
| Goodwill |  | 1,082,523 |  | 1,121,170 |  |
| Other intangible assets, net |  | 375,407 |  | 424,433 |  |
| Other assets |  | 957,217 |  | 760,332 |  |
| Total assets |  | $ | 14,726,204 |  | $ | 13,715,855 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 55,640 |  | $ | 43,011 |  |
| Accounts payable |  | 6,236,018 |  | 5,122,303 |  |
| Accrued payroll |  | 406,368 |  | 383,332 |  |
| Other current liabilities |  | 1,456,519 |  | 1,719,418 |  |
| Total current liabilities |  | 8,154,545 |  | 7,268,064 |  |
| Long-term debt, net of current portion |  | 2,869,551 |  | 2,897,631 |  |
| Other liabilities |  | 532,561 |  | 531,587 |  |
| Total shareholders’ equity |  | 3,169,547 |  | 3,018,573 |  |
| Total liabilities and shareholders’ equity |  | $ | 14,726,204 |  | $ | 13,715,855 |  |

[0001104659-18-063948:8k_2_02:75]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:76]
SCHEDULE IV

[0001104659-18-063948:8k_2_02:77]
FLEX

[0001104659-18-063948:8k_2_02:78]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-18-063948:8k_2_02:79]
(In thousands)

[0001104659-18-063948:8k_2_02:80]
|  |  | Six-Month Periods Ended |  |
|  |  | September 28, 2018 |  | September 29, 2017 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income |  | $ | 202,920 |  | $ | 329,796 |  |
| Depreciation, amortization and other impairment charges |  | 269,062 |  | 264,718 |  |
| Gain from deconsolidation of AutoLab |  | (86,614 | ) | — |  |
| Gain from deconsolidation of Elementum |  | — |  | (151,574 | ) |
| Changes in working capital and other |  | (2,092,964 | ) | (2,614,917 | ) |
| Net cash used in operating activities |  | (1,707,596 | ) | (2,171,977 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property and equipment |  | (363,373 | ) | (264,030 | ) |
| Proceeds from the disposition of property and equipment |  | 12,973 |  | 36,123 |  |
| Acquisition of businesses, net of cash acquired |  | — |  | (273,167 | ) |
| Proceeds from divestiture of businesses, net of cash held in divested businesses |  | 264,438 |  | (2,949 | ) |
| Cash collections of deferred purchase price |  | 1,812,945 |  | 2,452,782 |  |
| Other investing activities, net |  | (24,411 | ) | (114,063 | ) |
| Net cash provided by investing activities |  | 1,702,572 |  | 1,834,696 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 650,023 |  | — |  |
| Repayments of bank borrowings and long-term debt |  | (652,600 | ) | (26,483 | ) |
| Payments for repurchases of ordinary shares |  | (59,980 | ) | (145,005 | ) |
| Net proceeds from issuance of ordinary shares |  | 131 |  | 1,211 |  |
| Other financing activities, net |  | — |  | 60,591 |  |
| Net cash provided used in financing activities |  | (62,426 | ) | (109,686 | ) |
| Effect of exchange rates on cash and cash equivalents |  | (27,254 | ) | (14,206 | ) |
| Net change in cash and cash equivalents |  | (94,704 | ) | (461,173 | ) |
| Cash and cash equivalents, beginning of period |  | 1,472,424 |  | 1,830,675 |  |
| Cash and cash equivalents, end of period |  | $ | 1,377,720 |  | $ | 1,369,502 |  |
| Reconciliation of GAAP to Non-GAAP Financial Measures (1) |  |  |  |  |  |
| Net cash used in operating activities |  | $ | (1,707,596 | ) | $ | (2,171,977 | ) |
| Cash collections of deferred purchase price |  | 1,812,945 |  | 2,452,782 |  |
| Adjusted net cash provided by operating activities |  | 105,349 |  | 280,805 |  |
| Net Capital Expenditures |  | (350,400 | ) | (227,907 | ) |
| Free Cash Flow |  | $ | (245,051 | ) | $ | 52,898 |  |

[0001104659-18-063948:8k_2_02:81]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:82]
SCHEDULE V

[0001104659-18-063948:8k_2_02:83]
FLEX AND SUBSIDIARIES

[0001104659-18-063948:8k_2_02:84]
NOTES TO SCHEDULES I, II, III, & IV

[0001104659-18-063948:8k_2_02:85]
(1)   To supplement Flex’s unaudited selected financial data presented consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude restructuring charges, stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies.  We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-18-063948:8k_2_02:86]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-18-063948:8k_2_02:87]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-18-063948:8k_2_02:88]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-18-063948:8k_2_02:89]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-18-063948:8k_2_02:90]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-18-063948:8k_2_02:91]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-18-063948:8k_2_02:92]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types.  In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-18-063948:8k_2_02:93]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions.  The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-18-063948:8k_2_02:94]
Customer related asset impairments consist primarily of non-cash impairments of certain property and equipment to estimated fair value for customers we are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing significant financial

[0001104659-18-063948:8k_2_02:95]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:96]
difficulties. Certain inventory on hand could be subject to impairment to net realizable value for these customers as well. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-18-063948:8k_2_02:97]
Contingencies and other consists primarily of costs not directly related to ongoing or core business results such as (1) costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors completed in June 2018, (2) certain charges related to Multek China that was divested in the second quarter of fiscal year 2019, (3) damages incurred from a typhoon that impacted a China facility in the second quarter of fiscal year 2018, and (4) certain legal matters for which loss contingencies are believed to be probable and estimable in the second quarter of fiscal year 2018. It also includes certain restructuring charges primarily related to severance for rationalization at existing sites and corporate functions. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-18-063948:8k_2_02:98]
Other charges (income), net consists of various other types of items that are not directly related to ongoing or core business results, such as the gain or loss from certain divestitures and impairment charges associated with non-core investments. We exclude these items because they are not related to the Company’s ongoing operating performance or do not affect core operations.  Excluding these amounts provide investors with a basis to compare Company performance against the performance of other companies without this variability.

[0001104659-18-063948:8k_2_02:99]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies or other non-recurring tax charges, when applicable.

[0001104659-18-063948:8k_2_02:100]
Adjustment for operating cash flows and free cash flow metrics due to a recently issued accounting standard.   In Q1 fiscal year 2019, the adoption of the new cash flow accounting standard resulted in a reclassification of cash flows related to the collection of certain receivables sold through the Company’s asset-backed receivable securitization program from operating activities to investing activities. The Company utilizes net cash flow from its various A/R sales programs as a low-cost source to fund operations and as a critical net working capital management tool.  Cash flow from operations is also a critical metric that investors use to evaluate a company’s earnings power. The Company views and manages all collections under the program similarly without bifurcation and accordingly provides the adjustment to reflect cash flows from operations inclusive of all collections of receivables sold through the programs.

[0001104659-18-063948:8k_2_02:101]
In addition, we define our free cash flow metric to be GAAP net cash flows from operating activities, plus cash collection of deferred purchase price, less purchases of property and equipment net of proceeds from dispositions to reflect this change and present cash flows on a consistent basis for investor transparency.  We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash used in operating activities.”

[0001104659-18-063948:8k_2_02:102]
P R E S S   R E L E A S E

[0001104659-18-063948:8k_2_02:103]
(2) Customer related asset impairments for the three-month and six-month periods ended September 28, 2018 relate to additional provisions for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties as well as $30 million of exit costs primarily related to our estimated impairment of fixed assets considered not recoverable in conjunction with the wind-down of our NIKE footwear manufacturing operations in Guadalajara.

[0001104659-18-063948:8k_2_02:104]
(3) During the first quarter of fiscal year 2019, the Company amended certain non-substantive terms of its existing contracts for its smaller customers. The amendments removed the consideration regarding over-time recognition under ASC 606. Accordingly, these customer contracts are now accounted for consistent with prior accounting and revenue is recognized upon shipment of product.

[0001104659-18-063948:8k_2_02:105]
(4) Contingencies and other during the three and six-month periods ended September 28, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018 and certain charges of the China based Multek operation that was divested in the second quarter of fiscal year 2019.

[0001104659-18-063948:8k_2_02:106]
During the second quarter of fiscal year 2018, the Company incurred charges in connection with certain legal matters where it believed losses were probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility.

[0001104659-18-063948:8k_2_02:107]
During the six-month period ended September 29, 2017 and September 28, 2018, the Company also incurred certain restructuring charges primarily related to severance for rationalization at existing sites and corporate functions.

[0001104659-18-063948:8k_2_02:108]
(5) During the first quarter of fiscal year 2019, the Company transferred employees and equipment along with certain related software and IP, into AutoLab AI which later received additional equity funding from third party investors and changed the composition of the Board of directors removing Flex’s control.  As such, we deconsolidated the entity and recognized a gain of approximately $92 million in other income, net for the quarter ended June 29, 2018. During the second quarter of fiscal year 2019, the Company reduced the gain recognized in the first quarter by $4 million based on the final fair value provided by an independent valuation firm.

[0001104659-18-063948:8k_2_02:109]
The Company sold its Wink business during the first quarter of fiscal year 2018 to an unrelated third-party venture backed company in exchange for contingent consideration fair valued at $59 million and recognized a gain on sale of $38.7 million.

[0001104659-18-063948:8k_2_02:110]
During the second quarter of fiscal year 2018, the Company and other minority shareholders of Elementum amended certain agreements and as a result, the Company concluded it no longer had majority control and accordingly, deconsolidated the entity. As part of the deconsolidation, the Company recognized a gain of $151.6 million.

[0001104659-18-063948:8k_2_02:111]
(6) Primarily related to adjustment for exchange rate fluctuation on income tax receivable position of an operating subsidiary recognized in a prior period and tax effects of the various adjustments that we incorporate into Non-GAAP measures.
