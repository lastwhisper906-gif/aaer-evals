# FLEX note change history — 0000866374-24-000034 → 0000866374-24-000053


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000866374-24-000053:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated,
  (was, 2024-07-26, similarity 0.828):
[0000866374-24-000034:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a

- added (2024-10-31):
[0000866374-24-000053:note_history:2]
(iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- changed (2024-10-31):
[0000866374-24-000053:note_history:3]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $285 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. Subsequent to the quarter ended September 27, 2024, approximately $118 million of the approximate $285 million assessment was abated by the Tax Authority, leaving approximately $167 million remaining. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.
  (was, 2024-07-26, similarity 0.6144):
[0000866374-24-000034:note_history:3]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $285 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

- removed (2024-10-31):
[0000866374-24-000034:note_history:4]
material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000866374-24-000053:note_history:5]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of September 27, 2024, Flex's two operating and reportable segments were as follows:
  (was, 2024-07-26, similarity 0.9919):
[0000866374-24-000034:note_history:5]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities include design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of June 28, 2024, Flex's two operating and reportable segments were as follows:

- changed (2024-10-31):
[0000866374-24-000053:note_history:6]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings and renewables and grid edge.
  (was, 2024-07-26, similarity 0.9961):
[0000866374-24-000034:note_history:6]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings, and renewables and grid edge.

- changed (2024-10-31):
[0000866374-24-000053:note_history:7]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2024 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 27, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025.
  (was, 2024-07-26, similarity 0.8606):
[0000866374-24-000034:note_history:7]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2024 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 28, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025.

- changed (2024-10-31):
[0000866374-24-000053:note_history:8]
The first quarters for fiscal years 2025 and 2024 ended on June 28, 2024, which is comprised of 89 days in the period, and June 30, 2023, which is comprised of 91 days, respectively. The second quarters for fiscal years 2025 and 2024 ended on September 27, 2024 and September 29, 2023, respectively, which are comprised of 91 days in both periods.
  (was, 2024-07-26, similarity 0.6879):
[0000866374-24-000034:note_history:8]
The first quarters for fiscal years 2025 and 2024 ended on June 28, 2024, which is comprised of 89 days in the period, and June 30, 2023, which is comprised of 91 days, respectively.

- changed (2024-10-31):
[0000866374-24-000053:note_history:9]
On January 2, 2024, Flex completed its spin-off (the "Spin-off") of its remaining interest in Nextracker Inc. ("Nextracker"). After the Spin-off, Flex no longer consolidates the financial results of Nextracker within its financial results of continuing operations. For all the periods prior to the Spin-off, the financial results of Nextracker are presented as net earnings from
  (was, 2024-07-26, similarity 0.7551):
[0000866374-24-000034:note_history:9]
On January 2, 2024, Flex completed its spin-off (the "Spin-off") of its remaining interest in Nextracker Inc. ("Nextracker"). After the Spin-off, Flex no longer consolidates the financial results of Nextracker within its financial results of continuing operations. For all the periods prior to the Spin-off, the financial results of Nextracker are presented as net earnings from discontinued operations in the condensed consolidated statements of operations and unless otherwise indicated Flex's disclosures are presented on a continuing operations basis. The historical statements of comprehensive income and cash flows

- added (2024-10-31):
[0000866374-24-000053:note_history:10]
discontinued operations in the condensed consolidated statements of operations and unless otherwise indicated Flex's disclosures are presented on a continuing operations basis. The historical statements of comprehensive income and cash flows and the balances related to shareholders' equity have not been revised to reflect the Spin-off. See note 6 "Discontinued Operations" for additional information.

- changed (2024-10-31):
[0000866374-24-000053:note_history:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2024-07-26, similarity 0.9955):
[0000866374-24-000034:note_history:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- changed (2024-10-31):
[0000866374-24-000053:note_history:12]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due dates. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. We have no economic interest in a supplier’s decision to participate in the supplier finance programs.
  (was, 2024-07-26, similarity 0.9997):
[0000866374-24-000034:note_history:12]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due date. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. We have no economic interest in a supplier’s decision to participate in the supplier finance programs.

- changed (2024-10-31):
[0000866374-24-000053:note_history:13]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of September 27, 2024 and March 31, 2024 were $133 million and $123 million, respectively.
  (was, 2024-07-26, similarity 0.9844):
[0000866374-24-000034:note_history:13]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of June 28, 2024 and March 31, 2024 were $129 million and $123 million, respectively.

- removed (2024-10-31):
[0000866374-24-000034:note_history:14]
and the balances related to shareholders' equity have not been revised to reflect the Spin-off. See note 6 "Discontinued Operations" for additional information.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000866374-24-000053:note_history:15]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 27, 2024 and March 31, 2024 are as follows:
  (was, 2024-07-26, similarity 0.9528):
[0000866374-24-000034:note_history:15]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 28, 2024 and March 31, 2024 are as follows:

- added (2024-10-31):
[0000866374-24-000053:note_history:16]
|  | Maturity Date |  | As of September 27, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 680 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 678 |  |  | 681 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (2) | December 2031 |  | 283 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (17) |  |  | (15) |  |
|  |  |  | 3,709 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (531) |  |  | — |  |
| Non-current portion |  |  | $ | 3,178 |  |  | $ | 3,261 |  |

- changed (2024-10-31):
[0000866374-24-000053:note_history:17]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.
  (was, 2024-07-26, similarity 0.9982):
[0000866374-24-000034:note_history:17]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations

- added (2024-10-31):
[0000866374-24-000053:note_history:18]
(2)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

- changed (2024-10-31):
[0000866374-24-000053:note_history:19]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.5% as of September 27, 2024 and March 31, 2024, respectively.
  (was, 2024-07-26, similarity 0.9565):
[0000866374-24-000034:note_history:19]
The weighted-average interest rate for the Company's long-term debt was 4.4% and 4.5% as of June 28, 2024 and March 31, 2024, respectively.

- changed (2024-10-31):
[0000866374-24-000053:note_history:20]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 27, 2024 are as follows:
  (was, 2024-07-26, similarity 0.9479):
[0000866374-24-000034:note_history:20]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 28, 2024 are as follows:

- changed (2024-10-31):
[0000866374-24-000053:note_history:21]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2025.
  (was, 2024-07-26, similarity 0.9733):
[0000866374-24-000034:note_history:21]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2025.

- added (2024-10-31):
[0000866374-24-000053:note_history:22]
Notes due January 2032

- added (2024-10-31):
[0000866374-24-000053:note_history:23]
In August 2024, the Company issued $500 million of 5.250% Notes due 2032 (the “Notes”). The Company received proceeds of approximately $496 million, net of discount and certain issuance costs. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet of approximately $5 million of costs incurred in conjunction with the Notes issuance. Interest on the Notes is payable on January 15 and July 15 of each year, beginning on January 15, 2025.

- added (2024-10-31):
[0000866374-24-000053:note_history:24]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries.

- added (2024-10-31):
[0000866374-24-000053:note_history:25]
In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare the entire principal of Notes, together with all accrued and unpaid interest, if any, to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of September 27, 2024, the Company was in compliance with the covenants in the indenture governing the Notes.

- removed (2024-10-31):
[0000866374-24-000034:note_history:26]
|  | Maturity Date |  | As of June 28, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 543 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 681 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 680 |  |  | 681 |  |
| 3.600% HUF Bonds | December 2031 |  | 269 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (12) |  |  | (15) |  |
|  |  |  | 3,215 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (543) |  |  | — |  |
| Non-current portion |  |  | $ | 2,672 |  |  | $ | 3,261 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000866374-24-000053:note_history:27]
|  | As of September 27, 2024 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | 532 |  |  | $ | 531 |  |  | $ | 584 |  |  | $ | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 680 |  |  | 673 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 411 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 656 |  |  | 658 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 678 |  |  | 679 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 503 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 283 |  |  | 226 |  |  | 274 |  |  | 219 |  |  | Level 2 |
  (was, 2024-07-26, similarity 0.9343):
[0000866374-24-000034:note_history:27]
|  | As of June 28, 2024 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | 543 |  |  | $ | 538 |  |  | $ | 584 |  |  | $ | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 681 |  |  | 661 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 403 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 656 |  |  | 638 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 680 |  |  | 659 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 269 |  |  | 215 |  |  | 274 |  |  | 219 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000866374-24-000053:note_history:28]
Bank borrowings and long-term debt as of September 27, 2024 and March 31, 2024 are as follows:
  (was, 2024-07-26, similarity 0.9325):
[0000866374-24-000034:note_history:28]
Bank borrowings and long-term debt as of June 28, 2024 and March 31, 2024 are as follows:

- added (2024-10-31):
[0000866374-24-000053:note_history:29]
|  | Maturity Date |  | As of September 27, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 680 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 678 |  |  | 681 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (2) | December 2031 |  | 283 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (17) |  |  | (15) |  |
|  |  |  | 3,709 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (531) |  |  | — |  |
| Non-current portion |  |  | $ | 3,178 |  |  | $ | 3,261 |  |

- changed (2024-10-31):
[0000866374-24-000053:note_history:30]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.
(2)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.
  (was, 2024-07-26, similarity 0.7201):
[0000866374-24-000034:note_history:30]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations

- removed (2024-10-31):
[0000866374-24-000034:note_history:31]
|  | Maturity Date |  | As of June 28, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 543 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 681 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 680 |  |  | 681 |  |
| 3.600% HUF Bonds | December 2031 |  | 269 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (12) |  |  | (15) |  |
|  |  |  | 3,215 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (543) |  |  | — |  |
| Non-current portion |  |  | $ | 2,672 |  |  | $ | 3,261 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000866374-24-000053:note_history:32]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 27, 2024 are as follows:
  (was, 2024-07-26, similarity 0.9479):
[0000866374-24-000034:note_history:32]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 28, 2024 are as follows:

- changed (2024-10-31):
[0000866374-24-000053:note_history:33]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2025.
  (was, 2024-07-26, similarity 0.9733):
[0000866374-24-000034:note_history:33]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2025.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000866374-24-000053:note_history:34]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 27, 2024 and September 29, 2023, respectively.
  (was, 2024-07-26, similarity 0.925):
[0000866374-24-000034:note_history:34]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 28, 2024 and June 30, 2023, respectively.

- added (2024-10-31):
[0000866374-24-000053:note_history:35]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,924 |  |  | $ | 3,280 |  |  | $ | 5,797 |  |  | $ | 6,716 |  |
| Over time | 682 |  |  | 338 |  |  | 1,174 |  |  | 503 |  |
| Total | 3,606 |  |  | 3,618 |  |  | 6,971 |  |  | 7,219 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,237 |  |  | 3,145 |  |  | 4,870 |  |  | 6,277 |  |
| Over time | 702 |  |  | 170 |  |  | 1,018 |  |  | 329 |  |
| Total | 2,939 |  |  | 3,315 |  |  | 5,888 |  |  | 6,606 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,161 |  |  | 6,425 |  |  | 10,667 |  |  | 12,993 |  |
| Over time | 1,384 |  |  | 508 |  |  | 2,192 |  |  | 832 |  |
| Total | $ | 6,545 |  |  | $ | 6,933 |  |  | $ | 12,859 |  |  | $ | 13,825 |  |

- removed (2024-10-31):
[0000866374-24-000034:note_history:36]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |
| Point in time | $ | 2,873 |  |  | $ | 3,436 |  |
| Over time | 492 |  |  | 165 |  |
| Total | 3,365 |  |  | 3,601 |  |
| FRS |  |  |  |
| Point in time | 2,633 |  |  | 3,132 |  |
| Over time | 316 |  |  | 159 |  |
| Total | 2,949 |  |  | 3,291 |  |
| Flex |  |  |  |
| Point in time | 5,506 |  |  | 6,568 |  |
| Over time | 808 |  |  | 324 |  |
| Total | $ | 6,314 |  |  | $ | 6,892 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-10-31):
[0000866374-24-000053:note_history:37]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $372 million and $490 million as of September 27, 2024 and March 31, 2024, respectively, of which $334 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2024-10-31):
[0000866374-24-000053:note_history:38]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 27, 2024 and September 29, 2023, respectively.
  (was, 2024-07-26, similarity 0.925):
[0000866374-24-000034:note_history:38]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 28, 2024 and June 30, 2023, respectively.

- added (2024-10-31):
[0000866374-24-000053:note_history:39]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,924 |  |  | $ | 3,280 |  |  | $ | 5,797 |  |  | $ | 6,716 |  |
| Over time | 682 |  |  | 338 |  |  | 1,174 |  |  | 503 |  |
| Total | 3,606 |  |  | 3,618 |  |  | 6,971 |  |  | 7,219 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,237 |  |  | 3,145 |  |  | 4,870 |  |  | 6,277 |  |
| Over time | 702 |  |  | 170 |  |  | 1,018 |  |  | 329 |  |
| Total | 2,939 |  |  | 3,315 |  |  | 5,888 |  |  | 6,606 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,161 |  |  | 6,425 |  |  | 10,667 |  |  | 12,993 |  |
| Over time | 1,384 |  |  | 508 |  |  | 2,192 |  |  | 832 |  |
| Total | $ | 6,545 |  |  | $ | 6,933 |  |  | $ | 12,859 |  |  | $ | 13,825 |  |

- removed (2024-10-31):
[0000866374-24-000034:note_history:40]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $395 million and $490 million as of June 28, 2024 and March 31, 2024, respectively, of which $355 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- removed (2024-10-31):
[0000866374-24-000034:note_history:41]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |
| Point in time | $ | 2,873 |  |  | $ | 3,436 |  |
| Over time | 492 |  |  | 165 |  |
| Total | 3,365 |  |  | 3,601 |  |
| FRS |  |  |  |
| Point in time | 2,633 |  |  | 3,132 |  |
| Over time | 316 |  |  | 159 |  |
| Total | 2,949 |  |  | 3,291 |  |
| Flex |  |  |  |
| Point in time | 5,506 |  |  | 6,568 |  |
| Over time | 808 |  |  | 324 |  |
| Total | $ | 6,314 |  |  | $ | 6,892 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2024-10-31):
[0000866374-24-000053:note_history:42]
SUBSEQUENT EVENTS
On October 16, 2024, the Company entered into a definitive agreement to acquire 100% ownership of Crown Technical Systems (“Crown”), a U.S. leader in critical power solutions for $325 million in an all-cash transaction. The acquisition will add to the Company' portfolio of power products and expand its offering in the utility and data center markets and is expected to close in the third quarter of fiscal year 2025, subject to customary closing conditions, including regulatory approval. For reporting purposes, Crown will be included in the Industrial reporting unit within the FRS segment.
