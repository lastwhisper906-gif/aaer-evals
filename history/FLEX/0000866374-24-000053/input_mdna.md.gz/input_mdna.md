# FLEX MD&A — 0000866374-24-000053


## mdna

[0000866374-24-000053:mdna:1]
[same as prior period, unchanged from 0000866374-24-000034:mdna:1]

[0000866374-24-000053:mdna:2]
[same as prior period, unchanged from 0000866374-24-000034:mdna:2]

[0000866374-24-000053:mdna:3]
[same as prior period, unchanged from 0000866374-24-000034:mdna:3]

[0000866374-24-000053:mdna:4]
We are the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we support our customers' entire product lifecycle with a broad array of services in every major region. Our full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. We partner with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of September 27, 2024, our two operating and reportable segments were as follows:

[0000866374-24-000053:mdna:5]
[same as prior period, unchanged from 0000866374-24-000034:mdna:5]

[0000866374-24-000053:mdna:6]
[same as prior period, unchanged from 0000866374-24-000034:mdna:6]

[0000866374-24-000053:mdna:7]
[same as prior period, unchanged from 0000866374-24-000034:mdna:7]

[0000866374-24-000053:mdna:8]
[same as prior period, unchanged from 0000866374-24-000034:mdna:8]

[0000866374-24-000053:mdna:9]
[same as prior period, unchanged from 0000866374-24-000034:mdna:9]

[0000866374-24-000053:mdna:10]
[same as prior period, unchanged from 0000866374-24-000034:mdna:10]

[0000866374-24-000053:mdna:11]
[same as prior period, unchanged from 0000866374-24-000034:mdna:11]

[0000866374-24-000053:mdna:12]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings and renewables and grid edge.

[0000866374-24-000053:mdna:13]
[same as prior period, unchanged from 0000866374-24-000034:mdna:13]

[0000866374-24-000053:mdna:14]
[same as prior period, unchanged from 0000866374-24-000034:mdna:14]

[0000866374-24-000053:mdna:15]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-24-000053:mdna:16]
26

[0000866374-24-000053:mdna:17]
[same as prior period, unchanged from 0000866374-24-000034:mdna:17]

[0000866374-24-000053:mdna:18]
[same as prior period, unchanged from 0000866374-24-000034:mdna:18]

[0000866374-24-000053:mdna:19]
[same as prior period, unchanged from 0000866374-24-000034:mdna:19]

[0000866374-24-000053:mdna:20]
Component shortages experienced in the recent past have largely subsided, however, logistical constraints exist which have increased freight costs. We continue to monitor potential supply chain disruptions, including disruptions in international commerce as a result of attacks on shipping vessels in the Red Sea and other emerging and evolving geopolitical conflicts and tensions. Refer to “Risk Factors - Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, have in the past affected, and may in the future affect, our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory.” as disclosed in Part I, “Item 1A. Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0000866374-24-000053:mdna:21]
[same as prior period, unchanged from 0000866374-24-000034:mdna:21]

[0000866374-24-000053:mdna:22]
We continue to monitor and respond to the conflict in Ukraine and the associated sanctions and other restrictions. We also are monitoring and responding to the ongoing conflicts in the Middle East, including Israel-Hamas war. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine and Israel. The full impact of the conflicts on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflicts and their impact on regional and global economic conditions. We will continue to monitor the conflicts and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-24-000053:mdna:23]
[same as prior period, unchanged from 0000866374-24-000034:mdna:24]

[0000866374-24-000053:mdna:24]
We are one of the world's largest providers of global supply chain solutions, with revenues of $12.9 billion for the six-month period ended September 27, 2024 and $26.4 billion in the fiscal year ended March 31, 2024. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of approximately 100 facilities in approximately 30 countries across four continents. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites:

[0000866374-24-000053:mdna:25]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 3,147 |  |  | 48 | % |  | $ | 3,141 |  |  | 45 | % |  | $ | 6,165 |  |  | 48 | % |  | $ | 6,174 |  |  | 45 | % |
| Asia | 2,020 |  |  | 31 | % |  | 2,377 |  |  | 34 | % |  | 3,927 |  |  | 31 | % |  | 4,699 |  |  | 34 | % |
| Europe | 1,378 |  |  | 21 | % |  | 1,415 |  |  | 21 | % |  | 2,767 |  |  | 21 | % |  | 2,952 |  |  | 21 | % |
|  | $ | 6,545 |  |  |  |  | $ | 6,933 |  |  |  |  | $ | 12,859 |  |  |  |  | $ | 13,825 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 1,734 |  |  | 26 | % |  | $ | 1,824 |  |  | 26 | % |  | $ | 3,321 |  |  | 26 | % |  | $ | 3,579 |  |  | 26 | % |
| China | 1,109 |  |  | 17 | % |  | 1,375 |  |  | 20 | % |  | 2,177 |  |  | 17 | % |  | 2,794 |  |  | 20 | % |
| U.S. | 978 |  |  | 15 | % |  | 931 |  |  | 13 | % |  | 1,982 |  |  | 15 | % |  | 1,823 |  |  | 13 | % |
| Malaysia | 608 |  |  | 9 | % |  | 555 |  |  | 8 | % |  | 1,199 |  |  | 9 | % |  | 1,101 |  |  | 8 | % |
| Brazil | 412 |  |  | 6 | % |  | 375 |  |  | 5 | % |  | 812 |  |  | 6 | % |  | 737 |  |  | 5 | % |
| Hungary | 328 |  |  | 5 | % |  | 363 |  |  | 5 | % |  | 671 |  |  | 5 | % |  | 714 |  |  | 5 | % |
| Other | 1,376 |  |  | 22 | % |  | 1,510 |  |  | 23 | % |  | 2,697 |  |  | 22 | % |  | 3,077 |  |  | 23 | % |
|  | $ | 6,545 |  |  |  |  | $ | 6,933 |  |  |  |  | $ | 12,859 |  |  |  |  | $ | 13,825 |  |  |  |

[0000866374-24-000053:mdna:26]
|  | As of |  | As of |
| Property and equipment, net: | September 27, 2024 |  | March 31, 2024 |
|  | (In millions) |
| Mexico | $ | 802 |  |  | 36 | % |  | $ | 793 |  |  | 35 | % |
| U.S. | 328 |  |  | 15 | % |  | 334 |  |  | 15 | % |
| China | 294 |  |  | 13 | % |  | 307 |  |  | 14 | % |
| Malaysia | 141 |  |  | 6 | % |  | 142 |  |  | 6 | % |
| Hungary | 131 |  |  | 6 | % |  | 124 |  |  | 5 | % |
| Brazil | 86 |  |  | 4 | % |  | 88 |  |  | 4 | % |
| Other | 472 |  |  | 20 | % |  | 481 |  |  | 21 | % |
|  | $ | 2,254 |  |  |  |  | $ | 2,269 |  |  |  |

[0000866374-24-000053:mdna:27]
[same as prior period, unchanged from 0000866374-24-000034:mdna:28]

[0000866374-24-000053:mdna:28]
[same as prior period, unchanged from 0000866374-24-000034:mdna:29]

[0000866374-24-000053:mdna:29]
•global economic conditions, including inflationary pressures, currency volatility, slower growth or recession, higher interest rates, and geopolitical uncertainty (including arising from ongoing conflict between Russia and Ukraine and the Israel-Hamas war);

[0000866374-24-000053:mdna:30]
[same as prior period, unchanged from 0000866374-24-000034:mdna:53]

[0000866374-24-000053:mdna:31]
[same as prior period, unchanged from 0000866374-24-000034:mdna:31]

[0000866374-24-000053:mdna:32]
[same as prior period, unchanged from 0000866374-24-000034:mdna:32]

[0000866374-24-000053:mdna:33]
[same as prior period, unchanged from 0000866374-24-000034:mdna:33]

[0000866374-24-000053:mdna:34]
[same as prior period, unchanged from 0000866374-24-000034:mdna:34]

[0000866374-24-000053:mdna:35]
[same as prior period, unchanged from 0000866374-24-000034:mdna:35]

[0000866374-24-000053:mdna:36]
[same as prior period, unchanged from 0000866374-24-000034:mdna:36]

[0000866374-24-000053:mdna:37]
[same as prior period, unchanged from 0000866374-24-000034:mdna:37]

[0000866374-24-000053:mdna:38]
[same as prior period, unchanged from 0000866374-24-000034:mdna:38]

[0000866374-24-000053:mdna:39]
[same as prior period, unchanged from 0000866374-24-000034:mdna:39]

[0000866374-24-000053:mdna:40]
[same as prior period, unchanged from 0000866374-24-000034:mdna:40]

[0000866374-24-000053:mdna:41]
[same as prior period, unchanged from 0000866374-24-000034:mdna:41]

[0000866374-24-000053:mdna:42]
[same as prior period, unchanged from 0000866374-24-000034:mdna:42]

[0000866374-24-000053:mdna:43]
[same as prior period, unchanged from 0000866374-24-000034:mdna:43]

[0000866374-24-000053:mdna:44]
[same as prior period, unchanged from 0000866374-24-000034:mdna:44]

[0000866374-24-000053:mdna:45]
[same as prior period, unchanged from 0000866374-24-000034:mdna:45]

[0000866374-24-000053:mdna:46]
[same as prior period, unchanged from 0000866374-24-000034:mdna:46]

[0000866374-24-000053:mdna:47]
[same as prior period, unchanged from 0000866374-24-000034:mdna:47]

[0000866374-24-000053:mdna:48]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 91.6 |  |  | 92.5 |  |  | 92.0 |  |  | 92.7 |  |
| Restructuring charges | 0.3 |  |  | — |  |  | 0.2 |  |  | 0.1 |  |
| Gross profit | 8.1 |  |  | 7.5 |  |  | 7.8 |  |  | 7.2 |  |
| Selling, general and administrative expenses | 3.3 |  |  | 3.2 |  |  | 3.3 |  |  | 3.3 |  |
| Restructuring charges | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Intangible amortization | 0.3 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Operating income | 4.5 |  |  | 4.1 |  |  | 4.1 |  |  | 3.6 |  |
| Interest expense | 0.8 |  |  | 0.7 |  |  | 0.8 |  |  | 0.8 |  |
| Interest income | 0.2 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Other charges (income), net | (0.1) |  |  | 0.2 |  |  | — |  |  | 0.1 |  |
| Income from continuing operations before income taxes | 4.0 |  |  | 3.4 |  |  | 3.5 |  |  | 2.9 |  |
| Provision for (benefit from) income taxes | 0.7 |  |  | 0.5 |  |  | 0.8 |  |  | 0.4 |  |
| Net income from continuing operations | 3.3 |  |  | 2.9 |  |  | 2.7 |  |  | 2.5 |  |
| Net income from discontinued operations, net of tax | — |  |  | 3.0 |  |  | — |  |  | 2.0 |  |
| Net income | 3.3 |  |  | 5.9 |  |  | 2.7 |  |  | 4.5 |  |
| Net income attributable to noncontrolling interest | — |  |  | 2.6 |  |  | — |  |  | 1.5 |  |
| Net income attributable to Flex Ltd. | 3.3 | % |  | 3.3 | % |  | 2.7 | % |  | 3.0 | % |

[0000866374-24-000053:mdna:49]
[same as prior period, unchanged from 0000866374-24-000034:mdna:49]

[0000866374-24-000053:mdna:50]
[same as prior period, unchanged from 0000866374-24-000034:mdna:50]

[0000866374-24-000053:mdna:51]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,606 |  |  | 55 | % |  | $ | 3,618 |  |  | 52 | % |  | $ | 6,971 |  |  | 54 | % |  | $ | 7,219 |  |  | 52 | % |
| Flex Reliability Solutions | 2,939 |  |  | 45 | % |  | 3,315 |  |  | 48 | % |  | 5,888 |  |  | 46 | % |  | 6,606 |  |  | 48 | % |
|  | $ | 6,545 |  |  |  |  | $ | 6,933 |  |  |  |  | $ | 12,859 |  |  |  |  | $ | 13,825 |  |  |  |

[0000866374-24-000053:mdna:52]
Net sales during the three-month period ended September 27, 2024 totaled $6.5 billion, representing a decrease of approximately $0.4 billion, or 6% from $6.9 billion during the three-month period ended September 29, 2023. Net sales for our FAS segment decreased approximately $12 million from the three-month period ended September 29, 2023, primarily driven by a low single-digit percentage decrease in our Communication, Enterprise, and Cloud ("CEC") business and a mid single-digit decrease in our Lifestyle business due to softer demand in certain markets, offset by a strong increase in our Consumer Devices business as a result of higher customer demand. Net sales for our FRS segment decreased approximately $0.4 billion, or 11% from the three-month period ended September 29, 2023, primarily driven by a high-teen percentage decrease in our Industrial business and a mid single-digit percentage decrease in our Automotive business due to lower customer demand. This was partially offset by a low single-digit percentage increase in our Health Solutions business due to higher customer demand. The factors described above that decreased FAS and FRS revenues were also partially offset by the effect of certain customer arrangements transitioning from point in time to over time revenue recognition during the quarter which also contributed to an

[0000866374-24-000053:mdna:53]
[same as prior period, unchanged from 0000866374-24-000034:mdna:84]

[0000866374-24-000053:mdna:54]
increase in contract assets at September 27, 2024. Net sales decreased $0.4 billion to $2.0 billion in Asia, decreased $37 million to $1.4 billion in Europe, and increased $6 million to $3.1 billion in the Americas.

[0000866374-24-000053:mdna:55]
Net sales during the six-month period ended September 27, 2024 totaled $12.9 billion, representing a decrease of approximately $1.0 billion, or 7% from $13.8 billion during the six-month period ended September 29, 2023. Net sales for our FAS segment decreased approximately $0.2 billion, or 3% from the six-month period ended September 29, 2023, primarily driven by a high single-digit percentage decrease in our CEC business and a mid single-digit percentage decrease in our Lifestyle business, offset by a strong increase in our Consumer Devices business due to the same factors as for the three-month period discussion above. Net sales for our FRS segment decreased approximately $0.7 billion, or 11% from the six-month period ended September 29, 2023, primarily driven by a high-teen percentage decrease in our Industrial business, along with a low single-digit percentage decrease in both our Automotive and Health Solutions businesses, due principally to the same factors as for the three-month period discussion above. Net sales decreased $0.8 billion to $3.9 billion in Asia, decreased $0.2 billion to $2.8 billion in Europe, and decreased $9 million to $6.2 billion in the Americas.

[0000866374-24-000053:mdna:56]
Our ten largest customers during the three and six-month periods ended September 27, 2024 accounted for approximately 44% and 43% of net sales, respectively. Our ten largest customers during the three and six-month periods ended September 29, 2023 accounted for approximately 36% of net sales. No customer accounted for more than 10% of net sales during the three or six-month periods ended September 27, 2024 or September 29, 2023.

[0000866374-24-000053:mdna:57]
[same as prior period, unchanged from 0000866374-24-000034:mdna:55]

[0000866374-24-000053:mdna:58]
[same as prior period, unchanged from 0000866374-24-000034:mdna:56]

[0000866374-24-000053:mdna:59]
Cost of sales during the three-month period ended September 27, 2024 totaled $6.0 billion, representing a decrease of approximately $0.4 billion, or 6% from $6.4 billion during the three-month period ended September 29, 2023. The lower cost of sales for the three-month period ended September 27, 2024 was primarily driven by decreased consolidated sales of $0.4 billion or 6%. Cost of sales in our FAS segment for the three-month period ended September 27, 2024 decreased approximately $0.1 billion, or 2% from the three-month period ended September 29, 2023, which is relatively in line with the overall decrease in FAS revenue during the same period primarily as a result of lower revenue in our Lifestyle and CEC businesses. Cost of sales in our FRS segment for the three-month period ended September 27, 2024 decreased approximately $0.4 billion, or 12% from the three-month period ended September 29, 2023, which is in line with the overall decrease in FRS revenue during the same period, primarily as a result of lower revenue in our Industrial business.

[0000866374-24-000053:mdna:60]
Cost of sales during the six-month period ended September 27, 2024 totaled $11.8 billion, representing a decrease of approximately $1.0 billion, or 8% from $12.8 billion during the six-month period ended September 29, 2023. The lower cost of sales for the six-month period ended September 27, 2024 was primarily driven by decreased consolidated sales of $1.0 billion or 7%. Cost of sales in our FAS segment for the six-month period ended September 27, 2024 decreased approximately $0.3 billion, or 5% from the six-month period ended September 29, 2023, which is aligned with the overall decrease in FAS revenue during the same period primarily due to the drivers noted in the discussion above for the three-month period. Cost of sales in our FRS segment for the six-month period ended September 27, 2024 decreased approximately $0.7 billion, or 11% from the six-month period ended September 29, 2023, which is in line with the overall decrease in FRS revenue during the same period primarily due to the drivers noted in the discussion above for the three-month period.

[0000866374-24-000053:mdna:61]
[same as prior period, unchanged from 0000866374-24-000034:mdna:58]

[0000866374-24-000053:mdna:62]
Gross profit is affected by fluctuations in cost of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all markets. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-24-000053:mdna:63]
Gross profit during the three-month period ended September 27, 2024 increased $12 million to $0.5 billion, or 8.1% of net sales, from $0.5 billion, or 7.5% of net sales, during the three-month period ended September 29, 2023. Gross margin improved 60 basis points during the three-month period ended September 27, 2024 primarily due to favorable mix in our FAS segment combined with savings from restructuring actions.

[0000866374-24-000053:mdna:64]
31

[0000866374-24-000053:mdna:65]
Gross profit during the six-month period ended September 27, 2024 increased $7 million to $1.0 billion, or 7.8% of net sales, from $1.0 billion, or 7.2% of net sales, during the six-month period ended September 29, 2023. Gross margin improved 60 basis points during the same period due to the same factors noted above in the three-month period discussion.

[0000866374-24-000053:mdna:66]
[same as prior period, unchanged from 0000866374-24-000034:mdna:61]

[0000866374-24-000053:mdna:67]
[same as prior period, unchanged from 0000866374-24-000034:mdna:62]

[0000866374-24-000053:mdna:68]
[same as prior period, unchanged from 0000866374-24-000034:mdna:63]

[0000866374-24-000053:mdna:69]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 218 |  |  | 6.1 | % |  | $ | 167 |  |  | 4.6 | % |  | $ | 397 |  |  | 5.7 | % |  | $ | 313 |  |  | 4.3 | % |
| Flex Reliability Solutions | 159 |  |  | 5.4 | % |  | 171 |  |  | 5.2 | % |  | 306 |  |  | 5.2 | % |  | 336 |  |  | 5.1 | % |

[0000866374-24-000053:mdna:70]
FAS segment margin increased approximately 150 basis points, to 6.1%, for the three-month period ended September 27, 2024, from 4.6% for the three-month period ended September 29, 2023. The margin increase was primarily due to strong execution, product mix and cost savings actions taken. The FAS segment margin increased approximately 140 basis points, to 5.7% for the six-month period ended September 27, 2024, from 4.3% for the six-month period ended September 29, 2023. This was primarily due to the same factors as noted for the three-month period.

[0000866374-24-000053:mdna:71]
FRS segment margin increased approximately 20 basis points, to 5.4% for the three-month period ended September 27, 2024, from 5.2% for the three-month period ended September 29, 2023. This was primarily driven by product mix and solid execution. FRS segment margin increased approximately 10 basis points, to 5.2% for the six-month period ended September 27, 2024 from 5.1% for the six-month period ended September 29, 2023. This was primarily due to the same factors as noted for the three-month period.

[0000866374-24-000053:mdna:72]
[same as prior period, unchanged from 0000866374-24-000034:mdna:67]

[0000866374-24-000053:mdna:73]
We committed to targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. During the three and six-month periods ended September 27, 2024, we recognized approximately $18 million and $43 million of restructuring charges, respectively, primarily related to employee severance.

[0000866374-24-000053:mdna:74]
[same as prior period, unchanged from 0000866374-24-000034:mdna:69]

[0000866374-24-000053:mdna:75]
Selling, general and administrative expenses (“SG&A”) was approximately $0.2 billion, or 3.3% of net sales, during the three-month period ended September 27, 2024, decreasing $5 million from approximately $0.2 billion or 3.2% of net sales, during the three-month period ended September 29, 2023. SG&A was $0.4 billion, or 3.3% of net sales, during the six-month period ended September 27, 2024, decreasing $27 million from $0.5 billion or 3.3% of net sales, during the six-month period ended September 29, 2023. The decreases reflect our enhanced cost control efforts to keep SG&A expenses relatively flat.

[0000866374-24-000053:mdna:76]
[same as prior period, unchanged from 0000866374-24-000034:mdna:71]

[0000866374-24-000053:mdna:77]
Amortization of intangible assets decreased to $16 million during the three-month period ended September 27, 2024, from $17 million for the three-month period ended September 29, 2023, and decreased to $32 million during the six-month period ended September 27, 2024, from $37 million for the six-month period ended September 29, 2023, primarily due to certain intangibles now being fully amortized.

[0000866374-24-000053:mdna:78]
[same as prior period, unchanged from 0000866374-24-000034:mdna:73]

[0000866374-24-000053:mdna:79]
Interest expense was $53 million during the three-month period ended September 27, 2024 compared to $49 million during the three-month period ended September 29, 2023. Interest expense was $109 million during the six-month period ended September 27, 2024 compared to $105 million during the six-month period ended September 29, 2023. The higher interest expense was primarily due to the effects of higher short-term borrowings and a new debt issuance in the second quarter of fiscal year 2025 partially offset by interest savings from debt repurchases and repayments.

[0000866374-24-000053:mdna:80]
[same as prior period, unchanged from 0000866374-24-000034:mdna:75]

[0000866374-24-000053:mdna:81]
Interest income was $16 million during the three-month period ended September 27, 2024, and $32 million during the six-month period ended September 27, 2024 which remains consistent with the equivalent prior year periods.

[0000866374-24-000053:mdna:82]
[same as prior period, unchanged from 0000866374-24-000034:mdna:77]

[0000866374-24-000053:mdna:83]
Other income, net was $4 million during the three-month period ended September 27, 2024 compared to an expense of $14 million during the three-month period ended September 29, 2023, primarily due to a gain from a tax receivable agreement payment from Nextracker partially offset by higher losses from certain non-core equity method investments compared to the prior period.

[0000866374-24-000053:mdna:84]
Other income, net was $3 million during the six-month period ended September 27, 2024 compared to an expense of $25 million during the six-month period ended September 29, 2023, primarily due to the same factors as noted for the three-month period, along with lower foreign exchange transaction losses compared to the prior period.

[0000866374-24-000053:mdna:85]
[same as prior period, unchanged from 0000866374-24-000034:mdna:79]

[0000866374-24-000053:mdna:86]
Certain of our subsidiaries, at various times, have been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 15, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024 for further discussion.

[0000866374-24-000053:mdna:87]
The consolidated effective tax rate was 19% and 23% for the three and six-month periods ended September 27, 2024, and 14% and 12% for the three and six-month periods ended September 29, 2023, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effects of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, the Netherlands and Israel. The effective tax rate for the three-month and six-month periods ended September 27, 2024 was higher than the effective tax rate for the three and six-month periods ended September 29, 2023 primarily due to the tax accrual required for our U.S. tax group after the U.S. tax group valuation allowance release in the fiscal year ended March 31, 2024, the recognition of a withholding tax accrual on the undistributed earnings of our Chinese subsidiaries due to the decision in the fiscal year ended March 31, 2024 to not indefinitely reinvest our China earnings in China, and unfavorable foreign exchange impacts.

[0000866374-24-000053:mdna:88]
The OECD Pillar Two Global Anti-Base Erosion (“GloBE”) model rules, issued under the OECD Inclusive Framework on Base Erosion and Profit Shifting, introduce a global minimum tax of 15% applicable to multinational enterprise groups with consolidated financial statement revenue in excess of €750 million. Numerous foreign jurisdictions have already enacted tax legislation based on the GloBE rules, with some effective as early as January 1, 2024. As of September 27, 2024, we recognized a nominal income tax expense for Pillar Two GloBE minimum tax. The Company is continuously monitoring the evolving application of this legislation and assessing its potential impact on our future tax liability.

[0000866374-24-000053:mdna:89]
[same as prior period, unchanged from 0000866374-24-000034:mdna:83]

[0000866374-24-000053:mdna:90]
[same as prior period, unchanged from 0000866374-24-000034:mdna:85]

[0000866374-24-000053:mdna:91]
Net income from continuing operations was $214 million during the three-month period ended September 27, 2024, compared to $201 million during the three-month period ended September 29, 2023; net income from continuing operations was $353 million during the six-month period ended September 27, 2024 compared to $348 million during the six-month period ended September 29, 2023, driven by the factors discussed above.

[0000866374-24-000053:mdna:92]
[same as prior period, unchanged from 0000866374-24-000034:mdna:87]

[0000866374-24-000053:mdna:93]
Net income from discontinued operations was zero during the three-month period ended September 27, 2024, compared to $205 million during the three-month period ended September 29, 2023; net income from discontinued operations was zero during the six-month period ended September 27, 2024 compared to $269 million during the six-month period ended September 29, 2023, as Nextracker was spun off during the fourth quarter of fiscal year 2024.

[0000866374-24-000053:mdna:94]
[same as prior period, unchanged from 0000866374-24-000034:mdna:89]

[0000866374-24-000053:mdna:95]
Net income attributable to noncontrolling interest was zero during the three-month period ended September 27, 2024, compared to $178 million during the three-month period ended September 29, 2023; net income attribute to noncontrolling interest was zero during the six-month period ended September 27, 2024 compared to $203 million during the six-month period ended September 29, 2023, as Nextracker was spun off during the fourth quarter of fiscal year 2024.

[0000866374-24-000053:mdna:96]
[same as prior period, unchanged from 0000866374-24-000034:mdna:91]

[0000866374-24-000053:mdna:97]
We continuously evaluate our ability to meet our obligations over the next 12 months and beyond and proactively reset our capital structure to improve maturities and liquidity. We expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of September 27, 2024, we had cash and cash equivalents of approximately $2.6 billion and bank and other borrowings of approximately $3.7 billion. We have a $2.5 billion revolving credit facility that is due to mature in July 2027, under which we had no borrowings outstanding as of September 27, 2024. We also issued $500 million of 5.250% Notes due January 2032 (the "2032 Senior Notes") in the second quarter of fiscal year 2025. As of September 27, 2024, we were in compliance with the covenants under all of our credit facilities and indentures; we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-24-000053:mdna:98]
During the six-month period ended September 27, 2024, we repurchased approximately $53 million of our 4.750% Notes due June 2025 under our 10b5-1 bond buyback program, resulting in an immaterial gain on our condensed consolidated statement of operations.

[0000866374-24-000053:mdna:99]
Cash provided by operating activities was $0.7 billion during the six-month period ended September 27, 2024, primarily driven by $0.4 billion of net income for the period plus $0.3 billion of non-cash charges such as depreciation, amortization, and stock-based compensation.

[0000866374-24-000053:mdna:100]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital decreased approximately $0.5 billion to $4.0 billion as of September 27, 2024, from $4.5 billion as of March 31, 2024. The decrease was primarily the result of the effect of an increase  in current portion of long-term debt of $0.5 billion.

[0000866374-24-000053:mdna:101]
Cash used in investing activities was $0.2 billion during the six-month period ended September 27, 2024. This was primarily driven by $0.2 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of primarily our Automotive, CEC, and Industrial businesses.

[0000866374-24-000053:mdna:102]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investors. Our adjusted free cash flow for the six-month periods ended September 27, 2024 and September 29, 2023 was an inflow of $0.5 billion and $0.1 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-24-000053:mdna:103]
|  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 659 |  |  | $ | 363 |  |
| Purchases of property and equipment | (214) |  |  | (319) |  |
| Proceeds from the disposition of property and equipment | 6 |  |  | 19 |  |
| Adjusted free cash flow | $ | 451 |  |  | $ | 63 |  |

[0000866374-24-000053:mdna:104]
Cash used by financing activities was $0.3 billion during the six-month period ended September 27, 2024, which was primarily driven by $0.8 billion of cash paid for the repurchase of our ordinary shares offset by $0.5 billion of proceeds from the issuance of the 2032 Senior Notes.

[0000866374-24-000053:mdna:105]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit

[0000866374-24-000053:mdna:106]
34

[0000866374-24-000053:mdna:107]
facilities, will be sufficient to fund our operations through at least the next twelve months and beyond. As of September 27, 2024 and March 31, 2024, approximately 70% and 55%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $0.7 billion as of March 31, 2024). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-24-000053:mdna:108]
[same as prior period, unchanged from 0000866374-24-000034:mdna:101]

[0000866374-24-000053:mdna:109]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of September 27, 2024.

[0000866374-24-000053:mdna:110]
[same as prior period, unchanged from 0000866374-24-000034:mdna:103]

[0000866374-24-000053:mdna:111]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-24-000053:mdna:112]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1.7 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 8, 2024. During the six-month period ended September 27, 2024, we paid $757 million to repurchase shares under the current and prior repurchase plans at an average price of $30.19 per share. As of September 27, 2024, shares in the aggregate amount of $1.5 billion were available to be repurchased under the current plan.

[0000866374-24-000053:mdna:113]
[same as prior period, unchanged from 0000866374-24-000034:mdna:106]

[0000866374-24-000053:mdna:114]
[same as prior period, unchanged from 0000866374-24-000034:mdna:107]

[0000866374-24-000053:mdna:115]
In August 2024, we issued the 2032 Senior Notes, and other than such issuance, there were no material changes in our contractual obligations and commitments as of September 27, 2024.
