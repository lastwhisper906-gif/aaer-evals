# FLEX notes — 0000866374-24-000053


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-24-000053:notes:1]
[same as prior period, unchanged from 0000866374-24-000034:notes:1]

[0000866374-24-000053:notes:2]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of September 27, 2024, Flex's two operating and reportable segments were as follows:

[0000866374-24-000053:notes:3]
[same as prior period, unchanged from 0000866374-24-000034:notes:3]

[0000866374-24-000053:notes:4]
[same as prior period, unchanged from 0000866374-24-000034:notes:4]

[0000866374-24-000053:notes:5]
[same as prior period, unchanged from 0000866374-24-000034:notes:5]

[0000866374-24-000053:notes:6]
[same as prior period, unchanged from 0000866374-24-000034:notes:6]

[0000866374-24-000053:notes:7]
[same as prior period, unchanged from 0000866374-24-000034:notes:7]

[0000866374-24-000053:notes:8]
[same as prior period, unchanged from 0000866374-24-000034:notes:8]

[0000866374-24-000053:notes:9]
[same as prior period, unchanged from 0000866374-24-000034:notes:9]

[0000866374-24-000053:notes:10]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings and renewables and grid edge.

[0000866374-24-000053:notes:11]
[same as prior period, unchanged from 0000866374-24-000034:notes:11]

[0000866374-24-000053:notes:12]
[same as prior period, unchanged from 0000866374-24-000034:notes:12]

[0000866374-24-000053:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2024 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 27, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025.

[0000866374-24-000053:notes:14]
The first quarters for fiscal years 2025 and 2024 ended on June 28, 2024, which is comprised of 89 days in the period, and June 30, 2023, which is comprised of 91 days, respectively. The second quarters for fiscal years 2025 and 2024 ended on September 27, 2024 and September 29, 2023, respectively, which are comprised of 91 days in both periods.

[0000866374-24-000053:notes:15]
[same as prior period, unchanged from 0000866374-24-000034:notes:15]

[0000866374-24-000053:notes:16]
On January 2, 2024, Flex completed its spin-off (the "Spin-off") of its remaining interest in Nextracker Inc. ("Nextracker"). After the Spin-off, Flex no longer consolidates the financial results of Nextracker within its financial results of continuing operations. For all the periods prior to the Spin-off, the financial results of Nextracker are presented as net earnings from

[0000866374-24-000053:notes:17]
discontinued operations in the condensed consolidated statements of operations and unless otherwise indicated Flex's disclosures are presented on a continuing operations basis. The historical statements of comprehensive income and cash flows and the balances related to shareholders' equity have not been revised to reflect the Spin-off. See note 6 "Discontinued Operations" for additional information.

[0000866374-24-000053:notes:18]
[same as prior period, unchanged from 0000866374-24-000034:notes:18]

[0000866374-24-000053:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-24-000053:notes:20]
[same as prior period, unchanged from 0000866374-24-000034:notes:20]

[0000866374-24-000053:notes:21]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due dates. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. We have no economic interest in a supplier’s decision to participate in the supplier finance programs.

[0000866374-24-000053:notes:22]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of September 27, 2024 and March 31, 2024 were $133 million and $123 million, respectively.

[0000866374-24-000053:notes:23]
Recently Issued Accounting Pronouncements

[0000866374-24-000053:notes:24]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

[0000866374-24-000053:notes:25]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company is currently assessing the impact of ASU 2023-07 on its consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the fourth quarter of fiscal year 2025.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-24-000053:notes:26]
[same as prior period, unchanged from 0000866374-24-000034:notes:26]

[0000866374-24-000053:notes:27]
[same as prior period, unchanged from 0000866374-24-000034:notes:27]

[0000866374-24-000053:notes:28]
|  | As of September 27, 2024 |  | As of March 31, 2024 |
|  | (In millions) |
| Raw materials | $ | 4,569 |  |  | $ | 5,045 |  |
| Work-in-progress | 460 |  |  | 623 |  |
| Finished goods | 437 |  |  | 537 |  |
|  | $ | 5,466 |  |  | $ | 6,205 |  |

[0000866374-24-000053:notes:29]
[same as prior period, unchanged from 0000866374-24-000034:notes:29]

[0000866374-24-000053:notes:30]
During the six-month period ended September 27, 2024, the activity in the Company's goodwill account included approximately $3 million of foreign currency translation and an approximately $8 million goodwill addition from an acquisition in the first quarter of fiscal year 2025.

[0000866374-24-000053:notes:31]
[same as prior period, unchanged from 0000866374-24-000034:notes:31]

[0000866374-24-000053:notes:32]
|  | As of September 27, 2024 |  | As of March 31, 2024 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 292 |  |  | $ | (172) |  |  | $ | 120 |  |  | $ | 316 |  |  | $ | (186) |  |  | $ | 130 |  |
| Licenses and other intangibles | 309 |  |  | (206) |  |  | 103 |  |  | 298 |  |  | (183) |  |  | 115 |  |
| Total | $ | 601 |  |  | $ | (378) |  |  | $ | 223 |  |  | $ | 614 |  |  | $ | (369) |  |  | $ | 245 |  |

[0000866374-24-000053:notes:33]
[same as prior period, unchanged from 0000866374-24-000034:notes:33]

[0000866374-24-000053:notes:34]
[same as prior period, unchanged from 0000866374-24-000034:notes:34]

[0000866374-24-000053:notes:35]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | 32 |  |
| 2026 |  | 45 |  |
| 2027 |  | 37 |  |
| 2028 |  | 28 |  |
| 2029 |  | 25 |  |
| Thereafter |  | 56 |  |
| Total amortization expense |  | $ | 223 |  |

[0000866374-24-000053:notes:36]
[same as prior period, unchanged from 0000866374-24-000034:notes:36]

[0000866374-24-000053:notes:37]
(1)Represents estimated amortization for the remaining fiscal six-month period ending March 31, 2025.

[0000866374-24-000053:notes:38]
[same as prior period, unchanged from 0000866374-24-000034:notes:38]

[0000866374-24-000053:notes:39]
Customer working capital advances were $1.8 billion and $2.2 billion as of September 27, 2024 and March 31, 2024, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-24-000053:notes:40]
[same as prior period, unchanged from 0000866374-24-000034:notes:40]

[0000866374-24-000053:notes:41]
Other non-current assets include deferred tax assets of $657 million and $644 million as of September 27, 2024 and March 31, 2024, respectively.

[0000866374-24-000053:notes:42]
[same as prior period, unchanged from 0000866374-24-000034:notes:42]

[0000866374-24-000053:notes:43]
Other current liabilities include customer-related accruals of $245 million and $277 million as of September 27, 2024 and March 31, 2024, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-24-000053:notes:44]
[same as prior period, unchanged from 0000866374-24-000034:notes:44]

[0000866374-24-000053:notes:45]
[same as prior period, unchanged from 0000866374-24-000034:notes:45]

[0000866374-24-000053:notes:46]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $372 million and $490 million as of September 27, 2024 and March 31, 2024, respectively, of which $334 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-24-000053:notes:47]
[same as prior period, unchanged from 0000866374-24-000034:notes:47]

[0000866374-24-000053:notes:48]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 27, 2024 and September 29, 2023, respectively.

[0000866374-24-000053:notes:49]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,924 |  |  | $ | 3,280 |  |  | $ | 5,797 |  |  | $ | 6,716 |  |
| Over time | 682 |  |  | 338 |  |  | 1,174 |  |  | 503 |  |
| Total | 3,606 |  |  | 3,618 |  |  | 6,971 |  |  | 7,219 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,237 |  |  | 3,145 |  |  | 4,870 |  |  | 6,277 |  |
| Over time | 702 |  |  | 170 |  |  | 1,018 |  |  | 329 |  |
| Total | 2,939 |  |  | 3,315 |  |  | 5,888 |  |  | 6,606 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,161 |  |  | 6,425 |  |  | 10,667 |  |  | 12,993 |  |
| Over time | 1,384 |  |  | 508 |  |  | 2,192 |  |  | 832 |  |
| Total | $ | 6,545 |  |  | $ | 6,933 |  |  | $ | 12,859 |  |  | $ | 13,825 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-24-000053:notes:50]
STOCK-BASED COMPENSATION
Flex historically maintains stock-based compensation plans at a corporate level. The Company grants equity compensation awards under its 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-24-000053:notes:51]
[same as prior period, unchanged from 0000866374-24-000034:notes:52]

[0000866374-24-000053:notes:52]
The following table summarizes the Company’s share-based compensation expense for the 2017 Plan:

[0000866374-24-000053:notes:53]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
|  | (In millions) |
| Cost of sales | $ | 8 |  |  | $ | 7 |  |  | $ | 16 |  |  | $ | 14 |  |
| Selling, general and administrative expenses | 20 |  |  | 21 |  |  | 44 |  |  | 46 |  |
| Total share-based compensation expense | $ | 28 |  |  | $ | 28 |  |  | $ | 60 |  |  | $ | 60 |  |

[0000866374-24-000053:notes:54]
[same as prior period, unchanged from 0000866374-24-000034:notes:55]

[0000866374-24-000053:notes:55]
During the six-month period ended September 27, 2024, the Company granted approximately 4.6 million restricted share unit ("RSU") awards. Of this amount, approximately 2.9 million are plain-vanilla unvested RSU awards that vest over a period

[0000866374-24-000053:notes:56]
of three years, with no performance or market conditions, and with an average grant date price of $31.86 per award. In addition, approximately 0.7 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $31.04 per award. These performance-based RSUs include awards tied to the Company's adjusted earnings per share growth and awards tied to operating profit goals. The number of shares that will ultimately vest will range from zero up to a maximum of approximately 1.2 million based on the level of achievement of these performance conditions. The awards will cliff vest after a period of one to three years, depending on the specific performance metrics, to the extent such performance conditions have been met. Further, approximately 0.3 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $42.36 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 0.6 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met. Finally, the remaining balance of approximately 0.7 million represents the number of shares issued upon the vesting of RSU awards above target levels based on the achievement of certain market and performance conditions for awards granted in fiscal year 2022. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-24-000053:notes:57]
As of September 27, 2024, approximately 12.4 million unvested RSU awards under the 2017 Plan were outstanding, of which vesting for a targeted amount of approximately 1.2 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of approximately 1.6 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to approximately 2.4 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to approximately 3.0 million based on the achievement levels. During the six-month period ended September 27, 2024, approximately 1.6 million shares vested in connection with the awards with market and performance conditions granted in fiscal year 2022.

[0000866374-24-000053:notes:58]
As of September 27, 2024, total unrecognized compensation expense related to unvested RSU awards under the 2017 Plan was approximately $221 million, and will be recognized over a weighted-average remaining vesting period of 2.0 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-24-000053:notes:59]
[same as prior period, unchanged from 0000866374-24-000034:notes:59]

[0000866374-24-000053:notes:60]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
|  | (In millions, except per share amounts) |
| Numerator: |  |  |  |  |  |  |  |
| Net income from continuing operations | $ | 214 |  |  | $ | 201 |  |  | $ | 353 |  |  | $ | 348 |  |
| Net income from discontinued operations, net of tax | — |  |  | 205 |  |  | — |  |  | 269 |  |
| Less: Net income attributable to noncontrolling interest | — |  |  | 178 |  |  | — |  |  | 203 |  |
| Net income from discontinued operations attributable to Flex Ltd. | — |  |  | 27 |  |  | — |  |  | 66 |  |
| Total net income attributable to Flex Ltd. | $ | 214 |  |  | $ | 228 |  |  | $ | 353 |  |  | $ | 414 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding - basic | 394 |  |  | 443 |  |  | 398 |  |  | 445 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 6 |  |  | 5 |  |  | 7 |  |  | 7 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding - diluted | 400 |  |  | 448 |  |  | 405 |  |  | 452 |  |
| Earnings per share - basic |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.54 |  |  | $ | 0.45 |  |  | $ | 0.89 |  |  | $ | 0.78 |  |
| Discontinued operations, net of tax | — |  |  | 0.06 |  |  | — |  |  | 0.15 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.54 |  |  | $ | 0.51 |  |  | $ | 0.89 |  |  | $ | 0.93 |  |
| Earnings per share - diluted |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.54 |  |  | $ | 0.45 |  |  | $ | 0.87 |  |  | $ | 0.77 |  |
| Discontinued operations, net of tax | — |  |  | 0.06 |  |  | — |  |  | 0.15 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.54 |  |  | $ | 0.51 |  |  | $ | 0.87 |  |  | $ | 0.92 |  |

[0000866374-24-000053:notes:61]
(1)An immaterial amount of RSU awards and 1.9 million RSU awards for the three and six-month periods ended September 27, 2024, respectively, and an immaterial amount of RSU awards and 2.1 million RSU awards for the three and six-month periods ended September 29, 2023, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000866374-24-000053:notes:62]
DISCONTINUED OPERATIONS  
On January 2, 2024, the Company completed the Spin-off of its remaining interests in Nextracker. For additional details on the Spin-off, refer to Part I, Item 1, “Business” and note 1, "Organization of The Company" and note 7, “Discontinued Operations” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024. Nextracker's financial results for periods prior to the Spin-off have been reflected in our condensed consolidated statement of operations, retrospectively, as discontinued operations.

[0000866374-24-000053:notes:63]
The key components of net income from discontinued operations for the three and six-month periods ended September 29, 2023 were as follows:

[0000866374-24-000053:notes:64]
|  |  | Three-month period ended |  | Six-month period ended |
|  |  | September 29, 2023 |  | September 29, 2023 |
|  |  | (In millions) |
| Net sales (1) |  | $ | 538 |  |  | $ | 982 |  |
| Cost of sales (1) |  | 392 |  |  | 725 |  |
| Gross Profit |  | 146 |  |  | 257 |  |
| Selling, general and administrative expenses |  | 51 |  |  | 86 |  |
| Operating income |  | 95 |  |  | 171 |  |
| Interest and other, net |  | 3 |  |  | 4 |  |
| Income before income taxes |  | 92 |  |  | 167 |  |
| Provision for income taxes |  | (113) |  |  | (102) |  |
| Net income from discontinued operations |  | 205 |  |  | 269 |  |
| Net income from discontinued operations attributable to noncontrolling interest (2) |  | 178 |  |  | 203 |  |
| Net income from discontinued operations attributable to Flex Ltd. |  | $ | 27 |  |  | $ | 66 |  |

[0000866374-24-000053:notes:65]
(1)    Both net sales and cost of sales from discontinued operations includes the effect of intercompany transactions that were eliminated from Flex's condensed consolidated statements of operations of approximately $34 million and $70 million for the three and six-month periods ended September 29, 2023, respectively.

[0000866374-24-000053:notes:66]
(2)    Net income from discontinued operations attributable to noncontrolling interest represented a share of pre-tax income of $40 million and $69 million and of income tax expense of $2 million and $6 million for the three and six-month periods ended September 29, 2023. As such, pre-tax income attributable to Flex Ltd. from discontinued operations was $52 million and $98 million for the same periods. In addition, during the three-month period ended September 29, 2023, a $140 million deferred tax asset was recorded, with an offsetting entry to income tax benefit fully attributable to noncontrolling interest in connection with Nextracker's follow-on public offering.

[0000866374-24-000053:notes:67]
Details of cash flows from discontinued operations for the six-month period ended September 29, 2023 were as follows:

[0000866374-24-000053:notes:68]
|  |  |  |  | Six-month period ended |
|  |  |  |  | September 29, 2023 |
|  |  |  | (In millions) |
| Net cash provided by discontinued operations operating activities (1) |  |  |  | $ | 253 |  |
| Net cash used in discontinued operations investing activities |  |  |  | (1) |  |

[0000866374-24-000053:notes:69]
(1)    Cash flows from discontinued operations operating activities includes an inflow from intercompany transactions that were eliminated from Flex's consolidated operations of $(4) million for the six-month period ended September 29, 2023.


## us-gaap:DebtDisclosureTextBlock

[0000866374-24-000053:notes:70]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 27, 2024 and March 31, 2024 are as follows:

[0000866374-24-000053:notes:71]
|  | Maturity Date |  | As of September 27, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 680 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 678 |  |  | 681 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (2) | December 2031 |  | 283 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (17) |  |  | (15) |  |
|  |  |  | 3,709 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (531) |  |  | — |  |
| Non-current portion |  |  | $ | 3,178 |  |  | $ | 3,261 |  |

[0000866374-24-000053:notes:72]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

[0000866374-24-000053:notes:73]
(2)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

[0000866374-24-000053:notes:74]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.5% as of September 27, 2024 and March 31, 2024, respectively.

[0000866374-24-000053:notes:75]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 27, 2024 are as follows:

[0000866374-24-000053:notes:76]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | — |  |
| 2026 |  | 1,212 |  |
| 2027 |  | — |  |
| 2028 |  | 397 |  |
| 2029 |  | 28 |  |
| Thereafter |  | 2,089 |  |
| Total |  | $ | 3,726 |  |

[0000866374-24-000053:notes:77]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2025.

[0000866374-24-000053:notes:78]
Notes due January 2032

[0000866374-24-000053:notes:79]
In August 2024, the Company issued $500 million of 5.250% Notes due 2032 (the “Notes”). The Company received proceeds of approximately $496 million, net of discount and certain issuance costs. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet of approximately $5 million of costs incurred in conjunction with the Notes issuance. Interest on the Notes is payable on January 15 and July 15 of each year, beginning on January 15, 2025.

[0000866374-24-000053:notes:80]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries.

[0000866374-24-000053:notes:81]
In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare the entire principal of Notes, together with all accrued and unpaid interest, if any, to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of September 27, 2024, the Company was in compliance with the covenants in the indenture governing the Notes.


## flex:InterestAndOtherNetTextBlock

[0000866374-24-000053:notes:82]
INTEREST EXPENSE AND INTEREST INCOME
Interest expense and interest income for the three and six-month periods ended September 27, 2024 and September 29, 2023 are composed of the following:

[0000866374-24-000053:notes:83]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 46 |  |  | $ | 38 |  |  | $ | 89 |  |  | $ | 82 |  |
| AR sale program related expenses | 7 |  |  | 11 |  |  | 20 |  |  | 23 |  |
| Interest income | (16) |  |  | (15) |  |  | (32) |  |  | (31) |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-24-000053:notes:84]
[same as prior period, unchanged from 0000866374-24-000034:notes:79]

[0000866374-24-000053:notes:85]
[same as prior period, unchanged from 0000866374-24-000034:notes:80]

[0000866374-24-000053:notes:86]
As of September 27, 2024, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $8.1 billion as summarized below:

[0000866374-24-000053:notes:87]
|  |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  | p |
| HUF |  | $ | 446 |  |  | $ | — |  |
| MXN |  | 487 |  |  | — |  |
| Other |  | 696 |  |  | 12 |  |
|  |  | 1,629 |  |  | 12 |  |
| Other Foreign Currency Contracts |  |  |  |  |
| CNY |  | 475 |  |  | 318 |  |
| EUR |  | 1,484 |  |  | 1,364 |  |
| JPY |  | 14 |  |  | 270 |  |
| MXN |  | 391 |  |  | 316 |  |
| MYR |  | 286 |  |  | 121 |  |
| Other |  | 690 |  |  | 769 |  |
|  |  | 3,340 |  |  | 3,158 |  |
| Total Notional Contract Value in USD |  | $ | 4,969 |  |  | $ | 3,170 |  |

[0000866374-24-000053:notes:88]
As of September 27, 2024, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts

[0000866374-24-000053:notes:89]
are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the condensed consolidated statements of operations. As of September 27, 2024 and March 31, 2024, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred loss was immaterial as of September 27, 2024, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations over the next twelve-month period, except for the USD HUF cross currency swaps.

[0000866374-24-000053:notes:90]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031. The fair value of the cross currency swaps was included in other current liabilities and other non-current liabilities as of September 27, 2024, and in other current assets and other non-current liabilities as of March 31, 2024. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-24-000053:notes:91]
[same as prior period, unchanged from 0000866374-24-000034:notes:85]

[0000866374-24-000053:notes:92]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 27,2024 |  | March 31,2024 |  | Balance SheetLocation |  | September 27,2024 |  | March 31,2024 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 23 |  |  | $ | 45 |  |  | Other current liabilities |  | $ | (36) |  |  | $ | (9) |  |
| Foreign currency contracts | Other non-current assets |  | $ | — |  |  | $ | — |  |  | Other liabilities |  | $ | (19) |  |  | $ | (33) |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 22 |  |  | $ | 14 |  |  | Other current liabilities |  | $ | (15) |  |  | $ | (10) |  |

[0000866374-24-000053:notes:93]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with certain counterparties. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-24-000053:notes:94]
[same as prior period, unchanged from 0000866374-24-000034:notes:88]

[0000866374-24-000053:notes:95]
|  | Three-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (23) |  |  | $ | (215) |  |  | $ | (238) |  |  | $ | 20 |  |  | $ | (189) |  |  | $ | (169) |  |
| Other comprehensive gain (loss) before reclassifications | 8 |  |  | 55 |  |  | 63 |  |  | (38) |  |  | (38) |  |  | (76) |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | 2 |  |  | — |  |  | 2 |  |  | 5 |  |  | — |  |  | 5 |  |
| Net current-period other comprehensive gain (loss) | 10 |  |  | 55 |  |  | 65 |  |  | (33) |  |  | (38) |  |  | (71) |  |
| Ending balance | $ | (13) |  |  | $ | (160) |  |  | $ | (173) |  |  | $ | (13) |  |  | $ | (227) |  |  | $ | (240) |  |

[0000866374-24-000053:notes:96]
|  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | 4 |  |  | $ | (199) |  |  | $ | (195) |  |  | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |
| Other comprehensive gain (loss) before reclassifications | (22) |  |  | 39 |  |  | 17 |  |  | 63 |  |  | (47) |  |  | 16 |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | 5 |  |  | — |  |  | 5 |  |  | (62) |  |  | — |  |  | (62) |  |
| Net current-period other comprehensive gain (loss) | (17) |  |  | 39 |  |  | 22 |  |  | 1 |  |  | (47) |  |  | (46) |  |
| Ending balance | $ | (13) |  |  | $ | (160) |  |  | $ | (173) |  |  | $ | (13) |  |  | $ | (227) |  |  | $ | (240) |  |

[0000866374-24-000053:notes:97]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and six-month periods ended September 27, 2024 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in accumulated other comprehensive loss for the three-month periods ended September 27, 2024 and September 29, 2023 were $2 million and $11 million, respectively. The tax impacts on the changes in accumulated other comprehensive loss for the six-month periods ended September 27, 2024 and September 29, 2023 were $11 million and $9 million, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-24-000053:notes:98]
TRADE RECEIVABLES SALES PROGRAMSThe Company sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.7 billion and $0.8 billion as of September 27, 2024 and March 31, 2024, respectively. For the six-month periods ended September 27, 2024 and September 29, 2023, total accounts receivable sold to certain third-party banking institutions was approximately $2.1 billion and $1.7 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-24-000053:notes:99]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES 
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence

[0000866374-24-000053:notes:100]
surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-24-000053:notes:101]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of September 27, 2024 and March 31, 2024.

[0000866374-24-000053:notes:102]
[same as prior period, unchanged from 0000866374-24-000034:notes:94]

[0000866374-24-000053:notes:103]
[same as prior period, unchanged from 0000866374-24-000034:notes:95]

[0000866374-24-000053:notes:104]
[same as prior period, unchanged from 0000866374-24-000034:notes:96]

[0000866374-24-000053:notes:105]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other non-current assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-24-000053:notes:106]
[same as prior period, unchanged from 0000866374-24-000034:notes:98]

[0000866374-24-000053:notes:107]
There were no transfers between levels in the fair value hierarchy during the six-month periods ended September 27, 2024 and September 29, 2023.

[0000866374-24-000053:notes:108]
[same as prior period, unchanged from 0000866374-24-000034:notes:100]

[0000866374-24-000053:notes:109]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of September 27, 2024 and March 31, 2024:

[0000866374-24-000053:notes:110]
|  | Fair Value Measurements as of September 27, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,640 |  |  | $ | — |  |  | $ | 1,640 |  |
| Foreign currency contracts (Note 9) | — |  |  | 45 |  |  | — |  |  | 45 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (70) |  |  | $ | — |  |  | $ | (70) |  |
|  | Fair Value Measurements as of March 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 759 |  |  | $ | — |  |  | $ | 759 |  |
| Foreign currency contracts (Note 9) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (52) |  |  | $ | — |  |  | $ | (52) |  |

[0000866374-24-000053:notes:111]
[same as prior period, unchanged from 0000866374-24-000034:notes:103]

[0000866374-24-000053:notes:112]
[same as prior period, unchanged from 0000866374-24-000034:notes:104]

[0000866374-24-000053:notes:113]
|  | As of September 27, 2024 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | 532 |  |  | $ | 531 |  |  | $ | 584 |  |  | $ | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 680 |  |  | 673 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 411 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 656 |  |  | 658 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 678 |  |  | 679 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 503 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 283 |  |  | 226 |  |  | 274 |  |  | 219 |  |  | Level 2 |

[0000866374-24-000053:notes:114]
The Notes due June 2025, February 2026, January 2028, June 2029, May 2030 and January 2032 are valued based on broker trading prices in active markets. HUF Bonds are valued based on the broker trading prices in an inactive market.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-24-000053:notes:115]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-24-000053:notes:116]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated,

[0000866374-24-000053:notes:117]
(iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-24-000053:notes:118]
The Company is currently involved in a commercial dispute related to a construction matter with related production objectives. Management assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment recognized $50 million in Selling, general and administrative expenses in the fourth quarter of the fiscal year ended March 31, 2024 as an accrual. The ultimate resolution of this dispute is uncertain, and the actual outcome may differ from the estimates made by management. Changes in circumstances or additional information may impact the Company’s assessment of its loss and could result in adjustments to the $50 million accrual, however, management currently believes that the resolution of this dispute will not have a material effect on the Company’s financial position, results of operations or cash flows. The Company will continue to monitor developments related to this matter and will adjust its accrual and disclosures accordingly in future reporting periods as additional information becomes available.

[0000866374-24-000053:notes:119]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. Two remain, where the Company was unsuccessful at the administrative level and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 36 million Brazilian reals (approximately USD $7 million). The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 59 million Brazilian reals (approximately USD $11 million). The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-24-000053:notes:120]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $285 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. Subsequent to the quarter ended September 27, 2024, approximately $118 million of the approximate $285 million assessment was abated by the Tax Authority, leaving approximately $167 million remaining. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-24-000053:notes:121]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material effect on the Company’s financial position, results of operations or cash flows.

[0000866374-24-000053:notes:122]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-24-000053:notes:123]
SHARE REPURCHASES 
During the three and six-month periods ended September 27, 2024, the Company repurchased 9.8 million and 25.1 million shares at an aggregate purchase price of $300 million and $757 million, respectively, and retired all of these shares.

[0000866374-24-000053:notes:124]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.7 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 8, 2024. As of September 27, 2024, shares in the aggregate amount of $1.5 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-24-000053:notes:125]
[same as prior period, unchanged from 0000866374-24-000034:notes:117]

[0000866374-24-000053:notes:126]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include

[0000866374-24-000053:notes:127]
intangible amortization, stock-based compensation, restructuring charges, legal and other, and interest, net and other charges, net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-24-000053:notes:128]
[same as prior period, unchanged from 0000866374-24-000034:notes:119]

[0000866374-24-000053:notes:129]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,606 |  |  | $ | 3,618 |  |  | $ | 6,971 |  |  | $ | 7,219 |  |
| Flex Reliability Solutions | 2,939 |  |  | 3,315 |  |  | 5,888 |  |  | 6,606 |  |
|  | $ | 6,545 |  |  | $ | 6,933 |  |  | $ | 12,859 |  |  | $ | 13,825 |  |
| Segment income and reconciliation of income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 218 |  |  | $ | 167 |  |  | $ | 397 |  |  | $ | 313 |  |
| Flex Reliability Solutions | 159 |  |  | 171 |  |  | 306 |  |  | 336 |  |
| Corporate and Other | (19) |  |  | (11) |  |  | (39) |  |  | (29) |  |
| Total segment income | 358 |  |  | 327 |  |  | 664 |  |  | 620 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 16 |  |  | 17 |  |  | 32 |  |  | 37 |  |
| Stock-based compensation | 28 |  |  | 28 |  |  | 60 |  |  | 60 |  |
| Restructuring charges | 17 |  |  | 1 |  |  | 42 |  |  | 24 |  |
| Legal and other (1) | — |  |  | — |  |  | — |  |  | 3 |  |
| Interest expense | 53 |  |  | 49 |  |  | 109 |  |  | 105 |  |
| Interest income | 16 |  |  | 15 |  |  | 32 |  |  | 31 |  |
| Other charges (income), net | (4) |  |  | 14 |  |  | (3) |  |  | 25 |  |
| Income from continuing operations before income taxes | $ | 264 |  |  | $ | 233 |  |  | $ | 456 |  |  | $ | 397 |  |

[0000866374-24-000053:notes:130]
(1)Legal and other consists of costs not directly related to core business results and including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During the first half of fiscal year 2024, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-24-000053:notes:131]
[same as prior period, unchanged from 0000866374-24-000034:notes:122]

[0000866374-24-000053:notes:132]
[same as prior period, unchanged from 0000866374-24-000034:notes:123]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-24-000053:notes:133]
RESTRUCTURING CHARGES
During the three and six-month periods ended September 27, 2024, the Company recognized approximately $18 million and $43 million of restructuring charges, respectively, most of which related to employee severance.

[0000866374-24-000053:notes:134]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of September 27, 2024 for charges incurred during the six-month period ended September 27, 2024:

[0000866374-24-000053:notes:135]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2024 | $ | 77 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 80 |  |
| Provision for charges incurred during the six-month period ended September 27, 2024 | 42 |  |  | 1 |  |  | — |  |  | 43 |  |
| Cash payments during the six-month period ended September 27, 2024 | (34) |  |  | — |  |  | — |  |  | (34) |  |
| Non-cash reductions during the six-month period ended September 27, 2024 | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Other adjustments | (2) |  |  | — |  |  | — |  |  | (2) |  |
| Balance as of September 27, 2024 | 83 |  |  | — |  |  | 3 |  |  | 86 |  |
| Less: Current portion (classified as other current liabilities) | 83 |  |  | — |  |  | 3 |  |  | 86 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:SubsequentEventsTextBlock

[0000866374-24-000053:notes:136]
SUBSEQUENT EVENTS
On October 16, 2024, the Company entered into a definitive agreement to acquire 100% ownership of Crown Technical Systems (“Crown”), a U.S. leader in critical power solutions for $325 million in an all-cash transaction. The acquisition will add to the Company' portfolio of power products and expand its offering in the utility and data center markets and is expected to close in the third quarter of fiscal year 2025, subject to customary closing conditions, including regulatory approval. For reporting purposes, Crown will be included in the Industrial reporting unit within the FRS segment.
