# FLEX note change history — 0000866374-19-000013 → 0000866374-20-000003


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000866374-20-000003:note_history:1]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019,  lead plaintiff filed a further amended complaint. On December 4, 2019, Defendants filed a motion to dismiss the amended complaint. Defendants’ motion to dismiss is set for hearing on April 9, 2020. The Company believes that the claims are without merit and intends to vigorously defend this case.
  (was, 2019-10-30, similarity 0.8073):
[0000866374-19-000013:note_history:1]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. Lead plaintiff’s deadline to file a further amended complaint is November 8, 2019, and Defendants’ deadline to move to dismiss is December 4, 2019. The Company believes that the claims are without merit and intends to vigorously defend this case.

- changed (2020-01-31):
[0000866374-20-000003:note_history:2]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible
  (was, 2019-10-30, similarity 0.6577):
[0000866374-19-000013:note_history:2]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously

- changed (2020-01-31):
[0000866374-20-000003:note_history:3]
contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.
  (was, 2019-10-30, similarity 0.839):
[0000866374-19-000013:note_history:3]
shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- changed (2020-01-31):
[0000866374-20-000003:note_history:4]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There are six tax assessments totaling 340 million Brazilian reals (approximately USD $83.8 million based on the exchange rate as of December 31, 2019). The assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60 million Brazilian reals or USD $14.8 million), but that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.
  (was, 2019-10-30, similarity 0.9931):
[0000866374-19-000013:note_history:4]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There are six tax assessments totaling 360 million Brazilian reals (approximately USD $86.2 million based on the exchange rate as of September 27, 2019). The assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totally approximately 54 million Brazilian reals or USD $12.9 million), but that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000866374-20-000003:note_history:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2019 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020.
  (was, 2019-10-30, similarity 0.9928):
[0000866374-19-000013:note_history:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2019 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and six-month periods ended September 27, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020.

- changed (2020-01-31):
[0000866374-20-000003:note_history:6]
The first quarters for fiscal years 2020 and 2019 ended on June 28, 2019, which is comprised of 89 days in the period, and June 29, 2018, which is comprised of 90 days in the period, respectively. The second quarters for fiscal years 2020 and 2019 ended on September 27, 2019 and September 28, 2018, which are comprised of 91 days in both periods. The Company's third quarters ended on December 31 of each year, which are comprised of 95 days and 94 days for fiscal years 2020 and 2019, respectively.
  (was, 2019-10-30, similarity 0.8121):
[0000866374-19-000013:note_history:6]
The first quarters for fiscal years 2020 and 2019 ended on June 28, 2019, which is comprised of 89 days in the period, and June 29, 2018, which is comprised of 90 days in the period, respectively. The second quarters for fiscal years 2020 and 2019 ended on September 27, 2019 and September 28, 2018, which are comprised of 91 days in both periods.

- changed (2020-01-31):
[0000866374-20-000003:note_history:7]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-
  (was, 2019-10-30, similarity 0.755):
[0000866374-19-000013:note_history:7]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these

- changed (2020-01-31):
[0000866374-20-000003:note_history:8]
owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.
  (was, 2019-10-30, similarity 0.638):
[0000866374-19-000013:note_history:8]
companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

- added (2020-01-31):
[0000866374-20-000003:note_history:9]
As previously disclosed, the Company has made certain immaterial corrections to net sales previously reported for the first, second, and third quarters of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result of correcting these errors, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month and nine-month periods ended December 31, 2018 have been reduced by $22 million and $95 million, respectively, from previously reported amounts. These corrections had no impact on gross profit, segment income or net income for the periods presented. Amounts presented for the three-month and nine-month periods ended December 31, 2018 related to the disaggregation of revenue in the CTG segment in Note 4, and CTG segment net sales and total net sales in Note 16, have also been restated accordingly. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to the previously issued financial statements.

- changed (2020-01-31):
[0000866374-20-000003:note_history:10]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU No. 2016-02, "Leases", and subsequent updates (collectively, referred to as Accounting Standard Codification 842 or “ASC 842”). ASC 842 requires a lessee to recognize a right of use (“ROU”) asset and lease liability. Leases will be classified as finance or operating, with classification affecting the recognition of expense and presentation in the income statement.
  (was, 2019-10-30, similarity 0.9836):
[0000866374-19-000013:note_history:10]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU No. 2016-02, Leases, and subsequent updates (collectively, referred to as Accounting Standard Codification 842 or “ASC 842”). ASC 842 requires a lessee to recognize a right of use (“ROU”) asset and lease liability. Leases will be classified as finance or operating, with classification affecting the recognition of expense and presentation in the income statement.

- changed (2020-01-31):
[0000866374-20-000003:note_history:11]
The Company adopted ASC 842 on April 1, 2019 using the optional transition method, by which companies may elect not to recast the comparative periods presented in financial statements in the period of adoption and recognize a cumulative effect adjustment in the period of adoption. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before the Company's adoption date. The Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. In addition, the Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for its leases, the Company uses its estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company’s estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company’s leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.
  (was, 2019-10-30, similarity 0.9457):
[0000866374-19-000013:note_history:11]
The Company adopted ASC 842 on April 1, 2019 using the modified retrospective method on the effective date. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before the Company's adoption date. The Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. In addition, the Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for its leases, the Company uses its estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company’s estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company’s leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

- changed (2020-01-31):
[0000866374-20-000003:note_history:12]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04,  ASU 2019-05, ASU 2019-10, and ASU 2019-11, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is currently assessing and expects the new guidance to have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.
  (was, 2019-10-30, similarity 0.9851):
[0000866374-19-000013:note_history:12]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04 and ASU 2019-05, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is currently assessing and expects the new guidance to have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

- added (2020-01-31):
[0000866374-20-000003:note_history:13]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes", which removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

- removed (2020-01-31):
[0000866374-19-000013:note_history:14]
In the accompanying condensed consolidated statements of operations $26.8 million and $29.0 million of expenses incurred in the three-month and six-month periods ended September 28, 2018, respectively, that were previously included as cost of sales have been reclassified as restructuring charges to conform with the current period presentation. Also, as previously disclosed, the Company has made certain immaterial corrections to net sales previously reported for the first and second quarters of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result of correcting these errors, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month and six-month periods ended September 28, 2018 have been reduced by $48 million and $73 million, respectively, from previously reported amounts. These corrections had no impact on gross profit, segment income or net income for the periods presented. Amounts presented for the three-month and six-month periods ended September 28, 2018 related to the disaggregation of revenue in the CTG segment in Note 4, and CTG segment net sales and total net sales in Note 16, have also been restated accordingly. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to the previously issued financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000866374-20-000003:note_history:15]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2019 are as follows:
  (was, 2019-10-30, similarity 0.9761):
[0000866374-19-000013:note_history:15]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 27, 2019 are as follows:

- changed (2020-01-31):
[0000866374-20-000003:note_history:16]
|  | As of December 31, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | — |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 439,688 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305,927 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,150 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 662,205 |  |  | — |  |
| India Facilities | 133,145 |  |  | 170,206 |  |
| Other | 165,897 |  |  | 168,039 |  |
| Debt issuance costs | (14,031 | ) |  | (10,639 | ) |
|  | 2,789,981 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (88,869 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,701,112 |  |  | $ | 2,421,904 |  |
  (was, 2019-10-30, similarity 0.9933):
[0000866374-19-000013:note_history:16]
|  | As of September 27, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,224 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,037 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,277 |  |  | — |  |
| India Facilities | 110,258 |  |  | 170,206 |  |
| Other | 162,992 |  |  | 168,039 |  |
| Debt issuance costs | (13,273 | ) |  | (10,639 | ) |
|  | 2,990,328 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (32,450 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,957,878 |  |  | $ | 2,421,904 |  |

- changed (2020-01-31):
[0000866374-20-000003:note_history:17]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.2% as of December 31, 2019 and March 31, 2019.
  (was, 2019-10-30, similarity 0.9782):
[0000866374-19-000013:note_history:17]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.2% as of September 27, 2019 and March 31, 2019.

- changed (2020-01-31):
[0000866374-20-000003:note_history:18]
During fiscal year 2020, and as further discussed below, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, in addition to issuing $650 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay the outstanding balances of the Company's existing 4.625% Notes due February 2020, and the Term Loan due November 2021. As both transactions were determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during the three-month and nine-month periods ended December 31, 2019, which was recorded in interest and other, net on the condensed consolidated statements of operations during the period.
  (was, 2019-10-30, similarity 0.9625):
[0000866374-19-000013:note_history:18]
During the first quarter of fiscal year 2020, and as further discussed below, the Company entered into a JPY33.525 billion term loan agreement due April 2024, in addition to issuing $450 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay the outstanding balance of the Company's existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021. As both transactions were determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during the three-month and six-month periods ended September 27, 2019, which was recorded in interest and other, net on the condensed consolidated statements of operations during the period.

- changed (2020-01-31):
[0000866374-20-000003:note_history:19]
Scheduled repayments of the Company's long-term debt as of December 31, 2019 are as follows:
  (was, 2019-10-30, similarity 0.9714):
[0000866374-19-000013:note_history:19]
Scheduled repayments of the Company's long-term debt as of September 27, 2019 are as follows:

- changed (2020-01-31):
[0000866374-20-000003:note_history:20]
| (1) | Represents estimated repayments for the remaining three-month period ending March 31, 2020. |
  (was, 2019-10-30, similarity 0.9574):
[0000866374-19-000013:note_history:20]
| (1) | Represents estimated repayments for the remaining six-month period ending March 31, 2020. |

- changed (2020-01-31):
[0000866374-20-000003:note_history:21]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 10 for additional details.
  (was, 2019-10-30, similarity 0.8762):
[0000866374-19-000013:note_history:21]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency

- changed (2020-01-31):
[0000866374-20-000003:note_history:22]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are
  (was, 2019-10-30, similarity 0.6498):
[0000866374-19-000013:note_history:22]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of September 27, 2019, the Company was in compliance with the covenants under this term loan agreement.

- added (2020-01-31):
[0000866374-20-000003:note_history:23]
subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2019, the Company was in compliance with the covenants under this term loan agreement.

- added (2020-01-31):
[0000866374-20-000003:note_history:24]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “Existing 2029 Notes”), at 99.607% of face value. In November 2019, as a further issuance of the Existing 2029 Notes, the Company issued under the same terms, an additional $200 million of 4.875% Notes due June 15, 2029 (together with the "Existing 2029 Notes" above, the "2029 Notes"), at 107.289% of face value. Immediately after the issuance of the notes issued in November 2019, the Company has $650 million aggregate principal amount of 4.875% Notes due 2029 outstanding. The Company received in aggregate, proceeds of approximately $662.8 million, net of discount and premium, from the issuances which were used, together with available cash, to refinance certain other outstanding debt. The Company incurred and capitalized as a direct reduction to the carrying amount of the notes presented on the balance sheet approximately $6.6 million of costs in conjunction with the issuance of the 2029 Notes.

- changed (2020-01-31):
[0000866374-20-000003:note_history:25]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of December 31, 2019, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.
  (was, 2019-10-30, similarity 0.9976):
[0000866374-19-000013:note_history:25]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of September 27, 2019, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.

- removed (2020-01-31):
[0000866374-19-000013:note_history:26]
contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 10 for additional details.

- removed (2020-01-31):
[0000866374-19-000013:note_history:27]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “2029 Notes”), at 99.607% of face value. The Company received proceeds of approximately $448.2 million, net of discount, from the issuance which was used, together with available cash, to refinance certain other outstanding debt. The Company incurred and capitalized as a direct reduction to the carrying amount of the notes presented on the balance sheet approximately $4.3 million of costs in conjunction with the issuance of the 2029 Notes.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000866374-20-000003:note_history:28]
|  | As of December 31, 2019 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through June 2022 | 439,688 |  |  | 441,337 |  |  | 458,531 |  |  | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 534,733 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305,927 |  |  | 305,927 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,150 |  |  | 647,854 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 662,205 |  |  | 717,955 |  |  | — |  |  | — |  |  | Level 1 |
| India Facilities | 133,145 |  |  | 133,145 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |
| Euro Term Loan due September 2020 | 51,281 |  |  | 51,281 |  |  | 52,746 |  |  | 52,746 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 111,632 |  |  | 111,632 |  |  | 112,524 |  |  | 112,524 |  |  | Level 2 |
| Total | $ | 2,801,028 |  |  | $ | 2,943,864 |  |  | $ | 1,890,822 |  |  | $ | 1,893,324 |  |  |  |
  (was, 2019-10-30, similarity 0.9203):
[0000866374-19-000013:note_history:28]
|  | As of September 27, 2019 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | — |  |  | — |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due November 2021 | 421,563 |  |  | 423,671 |  |  | 671,563 |  |  | 670,724 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 453,946 |  |  | 458,531 |  |  | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 533,977 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,224 |  |  | 311,224 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,037 |  |  | 637,084 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 448,277 |  |  | 473,116 |  |  | — |  |  | — |  |  | Level 1 |
| India Facilities | 110,258 |  |  | 110,258 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |
| Euro Term Loan due September 2020 | 50,679 |  |  | 50,679 |  |  | 52,746 |  |  | 52,746 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 109,577 |  |  | 109,577 |  |  | 112,524 |  |  | 112,524 |  |  | Level 2 |
| Total | $ | 3,000,865 |  |  | $ | 3,103,532 |  |  | $ | 3,062,385 |  |  | $ | 3,063,998 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000866374-20-000003:note_history:29]
Bank borrowings and long-term debt as of December 31, 2019 are as follows:
  (was, 2019-10-30, similarity 0.964):
[0000866374-19-000013:note_history:29]
Bank borrowings and long-term debt as of September 27, 2019 are as follows:

- changed (2020-01-31):
[0000866374-20-000003:note_history:30]
|  | As of December 31, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | — |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 439,688 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305,927 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,150 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 662,205 |  |  | — |  |
| India Facilities | 133,145 |  |  | 170,206 |  |
| Other | 165,897 |  |  | 168,039 |  |
| Debt issuance costs | (14,031 | ) |  | (10,639 | ) |
|  | 2,789,981 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (88,869 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,701,112 |  |  | $ | 2,421,904 |  |
  (was, 2019-10-30, similarity 0.9933):
[0000866374-19-000013:note_history:30]
|  | As of September 27, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,224 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,037 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,277 |  |  | — |  |
| India Facilities | 110,258 |  |  | 170,206 |  |
| Other | 162,992 |  |  | 168,039 |  |
| Debt issuance costs | (13,273 | ) |  | (10,639 | ) |
|  | 2,990,328 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (32,450 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,957,878 |  |  | $ | 2,421,904 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000866374-20-000003:note_history:31]
Scheduled repayments of the Company's long-term debt as of December 31, 2019 are as follows:
  (was, 2019-10-30, similarity 0.9714):
[0000866374-19-000013:note_history:31]
Scheduled repayments of the Company's long-term debt as of September 27, 2019 are as follows:

- changed (2020-01-31):
[0000866374-20-000003:note_history:32]
Represents estimated repayments for the remaining three-month period ending March 31, 2020.
  (was, 2019-10-30, similarity 0.9524):
[0000866374-19-000013:note_history:32]
Represents estimated repayments for the remaining six-month period ending March 31, 2020.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000866374-20-000003:note_history:33]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2019 and December 31, 2018 (in thousands), respectively.
  (was, 2019-10-30, similarity 0.8923):
[0000866374-19-000013:note_history:33]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended September 27, 2019 and September 28, 2018 (in thousands), respectively.

- changed (2020-01-31):
[0000866374-20-000003:note_history:34]
|  | Three-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 978,026 |  |  | $ | 1,471,116 |  |  | $ | 1,513,721 |  |  | $ | 1,191,491 |  |  | $ | 5,154,354 |  |
| Over time | 266,689 |  |  | 517,749 |  |  | 367,690 |  |  | 154,905 |  |  | 1,307,033 |  |
| Total segment | $ | 1,244,715 |  |  | $ | 1,988,865 |  |  | $ | 1,881,411 |  |  | $ | 1,346,396 |  |  | $ | 6,461,387 |  |
  (was, 2019-10-30, similarity 0.9895):
[0000866374-19-000013:note_history:34]
|  | Three-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 942,113 |  |  | $ | 1,147,976 |  |  | $ | 1,390,059 |  |  | $ | 1,103,855 |  |  | $ | 4,584,003 |  |
| Over time | 246,518 |  |  | 637,592 |  |  | 338,538 |  |  | 281,403 |  |  | 1,504,051 |  |
| Total segment | $ | 1,188,631 |  |  | $ | 1,785,568 |  |  | $ | 1,728,597 |  |  | $ | 1,385,258 |  |  | $ | 6,088,054 |  |

- changed (2020-01-31):
[0000866374-20-000003:note_history:35]
|  | Nine-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,843,866 |  |  | $ | 3,734,151 |  |  | $ | 4,263,144 |  |  | $ | 3,319,972 |  |  | $ | 14,161,133 |  |
| Over time | 767,523 |  |  | 1,677,196 |  |  | 1,205,713 |  |  | 913,815 |  |  | 4,564,247 |  |
| Total segment | $ | 3,611,389 |  |  | $ | 5,411,347 |  |  | $ | 5,468,857 |  |  | $ | 4,233,787 |  |  | $ | 18,725,380 |  |
  (was, 2019-10-30, similarity 0.9789):
[0000866374-19-000013:note_history:35]
|  | Six-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,865,840 |  |  | $ | 2,263,035 |  |  | $ | 2,749,423 |  |  | $ | 2,128,481 |  |  | $ | 9,006,779 |  |
| Over time | 500,834 |  |  | 1,159,447 |  |  | 838,023 |  |  | 758,910 |  |  | 3,257,214 |  |
| Total segment | $ | 2,366,674 |  |  | $ | 3,422,482 |  |  | $ | 3,587,446 |  |  | $ | 2,887,391 |  |  | $ | 12,263,993 |  |

- changed (2020-01-31):
[0000866374-20-000003:note_history:36]
|  | Three-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 929,638 |  |  | $ | 1,198,669 |  |  | $ | 1,663,262 |  |  | $ | 1,232,712 |  |  | $ | 5,024,281 |  |
| Over time | 276,714 |  |  | 460,256 |  |  | 596,966 |  |  | 564,610 |  |  | 1,898,546 |  |
| Total segment | $ | 1,206,352 |  |  | $ | 1,658,925 |  |  | $ | 2,260,228 |  |  | $ | 1,797,322 |  |  | $ | 6,922,827 |  |
  (was, 2019-10-30, similarity 0.9895):
[0000866374-19-000013:note_history:36]
|  | Three-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 893,141 |  |  | $ | 1,089,319 |  |  | $ | 1,519,041 |  |  | $ | 1,201,696 |  |  | $ | 4,703,197 |  |
| Over time | 314,830 |  |  | 476,634 |  |  | 621,756 |  |  | 546,187 |  |  | 1,959,407 |  |
| Total segment | $ | 1,207,971 |  |  | $ | 1,565,953 |  |  | $ | 2,140,797 |  |  | $ | 1,747,883 |  |  | $ | 6,662,604 |  |

- changed (2020-01-31):
[0000866374-20-000003:note_history:37]
|  | Nine-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,827,959 |  |  | $ | 3,351,886 |  |  | $ | 4,675,809 |  |  | $ | 3,732,545 |  |  | $ | 14,588,199 |  |
| Over time | 801,790 |  |  | 1,319,302 |  |  | 1,679,502 |  |  | 1,595,594 |  |  | 5,396,188 |  |
| Total segment | $ | 3,629,749 |  |  | $ | 4,671,188 |  |  | $ | 6,355,311 |  |  | $ | 5,328,139 |  |  | $ | 19,984,387 |  |
  (was, 2019-10-30, similarity 0.9789):
[0000866374-19-000013:note_history:37]
|  | Six-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,898,321 |  |  | $ | 2,153,218 |  |  | $ | 3,012,548 |  |  | $ | 2,499,833 |  |  | $ | 9,563,920 |  |
| Over time | 525,075 |  |  | 859,046 |  |  | 1,082,535 |  |  | 1,030,984 |  |  | 3,497,640 |  |
| Total segment | $ | 2,423,396 |  |  | $ | 3,012,264 |  |  | $ | 4,095,083 |  |  | $ | 3,530,817 |  |  | $ | 13,061,560 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000866374-20-000003:note_history:38]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable
  (was, 2019-10-30, similarity 0.7664):
[0000866374-19-000013:note_history:38]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first

- changed (2020-01-31):
[0000866374-20-000003:note_history:39]
profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.
  (was, 2019-10-30, similarity 0.7601):
[0000866374-19-000013:note_history:39]
required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- changed (2020-01-31):
[0000866374-20-000003:note_history:40]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $523.2 million and $271.8 million as of December 31, 2019 and March 31, 2019, respectively.
  (was, 2019-10-30, similarity 0.9379):
[0000866374-19-000013:note_history:40]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $341.5 million and $271.8 million as of September 27, 2019 and March 31, 2019, respectively.

- changed (2020-01-31):
[0000866374-20-000003:note_history:41]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2019 and December 31, 2018 (in thousands), respectively.
  (was, 2019-10-30, similarity 0.8923):
[0000866374-19-000013:note_history:41]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended September 27, 2019 and September 28, 2018 (in thousands), respectively.

- changed (2020-01-31):
[0000866374-20-000003:note_history:42]
|  | Three-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 978,026 |  |  | $ | 1,471,116 |  |  | $ | 1,513,721 |  |  | $ | 1,191,491 |  |  | $ | 5,154,354 |  |
| Over time | 266,689 |  |  | 517,749 |  |  | 367,690 |  |  | 154,905 |  |  | 1,307,033 |  |
| Total segment | $ | 1,244,715 |  |  | $ | 1,988,865 |  |  | $ | 1,881,411 |  |  | $ | 1,346,396 |  |  | $ | 6,461,387 |  |
  (was, 2019-10-30, similarity 0.9895):
[0000866374-19-000013:note_history:42]
|  | Three-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 942,113 |  |  | $ | 1,147,976 |  |  | $ | 1,390,059 |  |  | $ | 1,103,855 |  |  | $ | 4,584,003 |  |
| Over time | 246,518 |  |  | 637,592 |  |  | 338,538 |  |  | 281,403 |  |  | 1,504,051 |  |
| Total segment | $ | 1,188,631 |  |  | $ | 1,785,568 |  |  | $ | 1,728,597 |  |  | $ | 1,385,258 |  |  | $ | 6,088,054 |  |

- changed (2020-01-31):
[0000866374-20-000003:note_history:43]
|  | Nine-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,843,866 |  |  | $ | 3,734,151 |  |  | $ | 4,263,144 |  |  | $ | 3,319,972 |  |  | $ | 14,161,133 |  |
| Over time | 767,523 |  |  | 1,677,196 |  |  | 1,205,713 |  |  | 913,815 |  |  | 4,564,247 |  |
| Total segment | $ | 3,611,389 |  |  | $ | 5,411,347 |  |  | $ | 5,468,857 |  |  | $ | 4,233,787 |  |  | $ | 18,725,380 |  |
  (was, 2019-10-30, similarity 0.9789):
[0000866374-19-000013:note_history:43]
|  | Six-Month Period Ended September 27, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,865,840 |  |  | $ | 2,263,035 |  |  | $ | 2,749,423 |  |  | $ | 2,128,481 |  |  | $ | 9,006,779 |  |
| Over time | 500,834 |  |  | 1,159,447 |  |  | 838,023 |  |  | 758,910 |  |  | 3,257,214 |  |
| Total segment | $ | 2,366,674 |  |  | $ | 3,422,482 |  |  | $ | 3,587,446 |  |  | $ | 2,887,391 |  |  | $ | 12,263,993 |  |

- changed (2020-01-31):
[0000866374-20-000003:note_history:44]
|  | Three-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 929,638 |  |  | $ | 1,198,669 |  |  | $ | 1,663,262 |  |  | $ | 1,232,712 |  |  | $ | 5,024,281 |  |
| Over time | 276,714 |  |  | 460,256 |  |  | 596,966 |  |  | 564,610 |  |  | 1,898,546 |  |
| Total segment | $ | 1,206,352 |  |  | $ | 1,658,925 |  |  | $ | 2,260,228 |  |  | $ | 1,797,322 |  |  | $ | 6,922,827 |  |
  (was, 2019-10-30, similarity 0.9895):
[0000866374-19-000013:note_history:44]
|  | Three-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 893,141 |  |  | $ | 1,089,319 |  |  | $ | 1,519,041 |  |  | $ | 1,201,696 |  |  | $ | 4,703,197 |  |
| Over time | 314,830 |  |  | 476,634 |  |  | 621,756 |  |  | 546,187 |  |  | 1,959,407 |  |
| Total segment | $ | 1,207,971 |  |  | $ | 1,565,953 |  |  | $ | 2,140,797 |  |  | $ | 1,747,883 |  |  | $ | 6,662,604 |  |

- changed (2020-01-31):
[0000866374-20-000003:note_history:45]
|  | Nine-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,827,959 |  |  | $ | 3,351,886 |  |  | $ | 4,675,809 |  |  | $ | 3,732,545 |  |  | $ | 14,588,199 |  |
| Over time | 801,790 |  |  | 1,319,302 |  |  | 1,679,502 |  |  | 1,595,594 |  |  | 5,396,188 |  |
| Total segment | $ | 3,629,749 |  |  | $ | 4,671,188 |  |  | $ | 6,355,311 |  |  | $ | 5,328,139 |  |  | $ | 19,984,387 |  |
  (was, 2019-10-30, similarity 0.9789):
[0000866374-19-000013:note_history:45]
|  | Six-Month Period Ended September 28, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,898,321 |  |  | $ | 2,153,218 |  |  | $ | 3,012,548 |  |  | $ | 2,499,833 |  |  | $ | 9,563,920 |  |
| Over time | 525,075 |  |  | 859,046 |  |  | 1,082,535 |  |  | 1,030,984 |  |  | 3,497,640 |  |
| Total segment | $ | 2,423,396 |  |  | $ | 3,012,264 |  |  | $ | 4,095,083 |  |  | $ | 3,530,817 |  |  | $ | 13,061,560 |  |
