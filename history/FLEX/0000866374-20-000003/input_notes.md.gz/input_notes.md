# FLEX notes — 0000866374-20-000003


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-20-000003:notes:1]
[same as prior period, unchanged from 0000866374-19-000013:notes:1]

[0000866374-20-000003:notes:2]
[same as prior period, unchanged from 0000866374-19-000013:notes:2]

[0000866374-20-000003:notes:3]
[same as prior period, unchanged from 0000866374-19-000013:notes:3]

[0000866374-20-000003:notes:4]
[same as prior period, unchanged from 0000866374-19-000013:notes:4]

[0000866374-20-000003:notes:5]
[same as prior period, unchanged from 0000866374-19-000013:notes:5]

[0000866374-20-000003:notes:6]
[same as prior period, unchanged from 0000866374-19-000013:notes:6]

[0000866374-20-000003:notes:7]
[same as prior period, unchanged from 0000866374-19-000013:notes:7]

[0000866374-20-000003:notes:8]
[same as prior period, unchanged from 0000866374-19-000013:notes:8]

[0000866374-20-000003:notes:9]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2019 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020.

[0000866374-20-000003:notes:10]
The first quarters for fiscal years 2020 and 2019 ended on June 28, 2019, which is comprised of 89 days in the period, and June 29, 2018, which is comprised of 90 days in the period, respectively. The second quarters for fiscal years 2020 and 2019 ended on September 27, 2019 and September 28, 2018, which are comprised of 91 days in both periods. The Company's third quarters ended on December 31 of each year, which are comprised of 95 days and 94 days for fiscal years 2020 and 2019, respectively.

[0000866374-20-000003:notes:11]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-

[0000866374-20-000003:notes:12]
owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

[0000866374-20-000003:notes:13]
As previously disclosed, the Company has made certain immaterial corrections to net sales previously reported for the first, second, and third quarters of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result of correcting these errors, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month and nine-month periods ended December 31, 2018 have been reduced by $22 million and $95 million, respectively, from previously reported amounts. These corrections had no impact on gross profit, segment income or net income for the periods presented. Amounts presented for the three-month and nine-month periods ended December 31, 2018 related to the disaggregation of revenue in the CTG segment in Note 4, and CTG segment net sales and total net sales in Note 16, have also been restated accordingly. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to the previously issued financial statements.

[0000866374-20-000003:notes:14]
Recently Adopted Accounting Pronouncement

[0000866374-20-000003:notes:15]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU No. 2016-02, "Leases", and subsequent updates (collectively, referred to as Accounting Standard Codification 842 or “ASC 842”). ASC 842 requires a lessee to recognize a right of use (“ROU”) asset and lease liability. Leases will be classified as finance or operating, with classification affecting the recognition of expense and presentation in the income statement.

[0000866374-20-000003:notes:16]
The Company adopted ASC 842 on April 1, 2019 using the optional transition method, by which companies may elect not to recast the comparative periods presented in financial statements in the period of adoption and recognize a cumulative effect adjustment in the period of adoption. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before the Company's adoption date. The Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. In addition, the Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for its leases, the Company uses its estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company’s estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company’s leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-20-000003:notes:17]
[same as prior period, unchanged from 0000866374-19-000013:notes:17]

[0000866374-20-000003:notes:18]
[same as prior period, unchanged from 0000866374-19-000013:notes:18]

[0000866374-20-000003:notes:19]
In October 2018, the FASB issued ASU 2018-16 “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” to expand the lists of eligible benchmark interest rates to include OIS based on SOFR to facilitate the marketplace transition from LIBOR. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.

[0000866374-20-000003:notes:20]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing

[0000866374-20-000003:notes:21]
[same as prior period, unchanged from 0000866374-19-000013:notes:21]

[0000866374-20-000003:notes:22]
In August 2018, the FASB issued ASU 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.

[0000866374-20-000003:notes:23]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

[0000866374-20-000003:notes:24]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

[0000866374-20-000003:notes:25]
Recently Issued Accounting Pronouncements

[0000866374-20-000003:notes:26]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04,  ASU 2019-05, ASU 2019-10, and ASU 2019-11, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is currently assessing and expects the new guidance to have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-20-000003:notes:27]
In October 2018, the FASB issued ASU 2018-17 “Consolidation (Topic 810): Targeted Improvements to Related Party Guidance for Variable Interest Entities” to provide a new private company variable interest entity exemption and change how decision makers apply the variable interest criteria. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-20-000003:notes:28]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes", which removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-20-000003:notes:29]
[same as prior period, unchanged from 0000866374-19-000013:notes:28]

[0000866374-20-000003:notes:30]
[same as prior period, unchanged from 0000866374-19-000013:notes:29]

[0000866374-20-000003:notes:31]
|  | As of December 31, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| Raw materials | $ | 2,723,041 |  |  | $ | 2,922,101 |  |
| Work-in-progress | 382,881 |  |  | 366,135 |  |
| Finished goods | 578,251 |  |  | 434,618 |  |
|  | $ | 3,684,173 |  |  | $ | 3,722,854 |  |

[0000866374-20-000003:notes:32]
[same as prior period, unchanged from 0000866374-19-000013:notes:31]

[0000866374-20-000003:notes:33]
The following table summarizes the activity in the Company’s goodwill account for each of its four reporting units (which align to the Company's reportable segments) during the nine-month period ended December 31, 2019:

[0000866374-20-000003:notes:34]
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
|  | (In thousands) |
| Balance, beginning of the year | $ | 507,209 |  |  | $ | 333,257 |  |  | $ | 129,325 |  |  | $ | 103,264 |  |  | $ | 1,073,055 |  |
| Divestitures | (1,102 | ) |  | (137 | ) |  | — |  |  | — |  |  | (1,239 | ) |
| Foreign currency translation adjustments | (2,004 | ) |  | — |  |  | — |  |  | — |  |  | (2,004 | ) |
| Balance, end of the period | $ | 504,103 |  |  | $ | 333,120 |  |  | $ | 129,325 |  |  | $ | 103,264 |  |  | $ | 1,069,812 |  |

[0000866374-20-000003:notes:35]
[same as prior period, unchanged from 0000866374-19-000013:notes:34]

[0000866374-20-000003:notes:36]
|  | As of December 31, 2019 |  | As of March 31, 2019 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 277,422 |  |  | $ | (120,812 | ) |  | $ | 156,610 |  |  | $ | 297,306 |  |  | $ | (113,627 | ) |  | $ | 183,679 |  |
| Licenses and other intangibles | 247,097 |  |  | (123,779 | ) |  | 123,318 |  |  | 274,604 |  |  | (127,288 | ) |  | 147,316 |  |
| Total | $ | 524,519 |  |  | $ | (244,591 | ) |  | $ | 279,928 |  |  | $ | 571,910 |  |  | $ | (240,915 | ) |  | $ | 330,995 |  |

[0000866374-20-000003:notes:37]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that it is more likely than not that the fair value of a reporting unit is below its carrying value. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying value, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. As previously disclosed, at the date of its most recent annual impairment test the fair value of the CTG reporting unit exceeded its carrying value by 22%. The Company has assessed whether an interim impairment test should be performed on the CTG reporting unit in light of recent CTG’s financial performance. Management has concluded that it is more likely than not that CTG’s fair value exceeds its carrying value as of December 31, 2019, thus a full interim impairment test was not completed. The Company shall perform its next annual impairment test on January 1, 2020. As the Company continues to refine its long-term strategy for the CTG reporting unit, it is reasonably possible that changes in circumstances could require management to perform additional impairment tests for CTG. In the event that CTG is determined to be impaired during the annual impairment test, the resulting charge could be material to the consolidated results of operations.

[0000866374-20-000003:notes:38]
[same as prior period, unchanged from 0000866374-19-000013:notes:37]

[0000866374-20-000003:notes:39]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2020 (1) |  | $ | 15,351 |  |
| 2021 |  | 60,289 |  |
| 2022 |  | 51,846 |  |
| 2023 |  | 44,193 |  |
| 2024 |  | 42,572 |  |
| Thereafter |  | 65,677 |  |
| Total amortization expense |  | $ | 279,928 |  |

[0000866374-20-000003:notes:40]
[same as prior period, unchanged from 0000866374-19-000013:notes:39]

[0000866374-20-000003:notes:41]
| (1) | Represents estimated amortization for the remaining three-month period ending March 31, 2020. |

[0000866374-20-000003:notes:42]
[same as prior period, unchanged from 0000866374-19-000013:notes:41]

[0000866374-20-000003:notes:43]
Other current assets include approximately $292.5 million as of March 31, 2019 for the deferred purchase price receivable from the Company's Asset-Backed Securitization programs. Effective November 2019, the Company amended its Asset-Backed Securitization programs and removed the requirement for the deferred purchase price receivable. Approximately $55 million of the repurchased deferred purchase price receivable under the old Asset-Backed Securitization programs remains uncollected and outstanding as of December 31, 2019, and was included in other current assets and carried at the expected recovery amount. See note 12 for additional information.

[0000866374-20-000003:notes:44]
Other Current Liabilities
Other current liabilities include customer working capital advances of $239.9 million and $266.3 million, customer-related accruals of $212.4 million and $260.1 million, and contract liabilities, identified as deferred revenue of $523.2 million and $271.8 million, as of December 31, 2019 and March 31, 2019, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Following the adoption of ASC 842, current operating lease liabilities were $121.0 million as of December 31, 2019.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-20-000003:notes:45]
LEASES
The Company has several commitments under operating leases for warehouses, buildings, and equipment. The Company also has a minimal number of finance leases with an immaterial impact on its condensed consolidated financial statements. Leases have initial lease terms ranging from 1 year to 23 years.

[0000866374-20-000003:notes:46]
[same as prior period, unchanged from 0000866374-19-000013:notes:48]

[0000866374-20-000003:notes:47]
| Lease cost | Three-Month Period Ended |  | Nine-Month Period Ended |
|  | December 31, 2019 |  | December 31, 2019 |
| Operating lease cost | $ | 40,278 |  |  | $ | 122,767 |  |

[0000866374-20-000003:notes:48]
Amounts reported in the condensed consolidated balance sheet as of the period ended December 31, 2019 were (in thousands, except weighted average lease term and discount rate):

[0000866374-20-000003:notes:49]
|  |  | As of December 31, 2019 |
| Operating Leases: |  |  |
| Operating lease right of use assets |  | $ | 615,073 |  |
| Operating lease liabilities |  | 661,034 |  |
| Weighted-average remaining lease term (In years) |  |  |
| Operating leases |  | 7.5 |  |
| Weighted-average discount rate |  |  |
| Operating leases |  | 4.2 | % |

[0000866374-20-000003:notes:50]
[same as prior period, unchanged from 0000866374-19-000013:notes:52]

[0000866374-20-000003:notes:51]
|  |  | Nine-Month Period Ended |
|  |  | December 31, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |
| Operating cash flows from operating leases |  | $ | 106,748 |  |

[0000866374-20-000003:notes:52]
For the three and nine-month periods ended December 31, 2019, the Company sold and leased back certain properties and received cash proceeds of $34.1 million and $69.6 million, respectively, resulting in total gains of $18.3 million and $32.7 million, respectively, recorded in cost of sales within the condensed statements of operations. For the three and nine-month

[0000866374-20-000003:notes:53]
periods ended December 31, 2018, the Company sold and leased back certain properties and received cash proceeds of $67.7 million and recorded a deferred gain of $22 million. As a result of adopting ASC 842 as of April 1, 2019, the Company recognized the deferred gain to prior year retained earnings.

[0000866374-20-000003:notes:54]
Future lease payments under non-cancellable leases as of December 31, 2019 are as follows (in thousands):

[0000866374-20-000003:notes:55]
| Fiscal Year Ended March 31, |  | Operating Leases |
| 2020 (1) |  | $ | 40,977 |  |
| 2021 |  | 132,642 |  |
| 2022 |  | 111,967 |  |
| 2023 |  | 99,453 |  |
| 2024 |  | 83,555 |  |
| Thereafter |  | 312,807 |  |
| Total undiscounted lease payments |  | 781,401 |  |
| Less: imputed interest |  | 120,367 |  |
| Total lease liabilities |  | $ | 661,034 |  |

[0000866374-20-000003:notes:56]
| (1) | Represents estimated lease payments for the remaining three-month period ending March 31, 2020. |

[0000866374-20-000003:notes:57]
[same as prior period, unchanged from 0000866374-19-000013:notes:57]

[0000866374-20-000003:notes:58]
[same as prior period, unchanged from 0000866374-19-000013:notes:58]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-20-000003:notes:59]
[same as prior period, unchanged from 0000866374-19-000013:notes:59]

[0000866374-20-000003:notes:60]
[same as prior period, unchanged from 0000866374-19-000013:notes:60]

[0000866374-20-000003:notes:61]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable

[0000866374-20-000003:notes:62]
profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-20-000003:notes:63]
[same as prior period, unchanged from 0000866374-19-000013:notes:63]

[0000866374-20-000003:notes:64]
[same as prior period, unchanged from 0000866374-19-000013:notes:64]

[0000866374-20-000003:notes:65]
[same as prior period, unchanged from 0000866374-19-000013:notes:65]

[0000866374-20-000003:notes:66]
[same as prior period, unchanged from 0000866374-19-000013:notes:66]

[0000866374-20-000003:notes:67]
[same as prior period, unchanged from 0000866374-19-000013:notes:67]

[0000866374-20-000003:notes:68]
[same as prior period, unchanged from 0000866374-19-000013:notes:68]

[0000866374-20-000003:notes:69]
[same as prior period, unchanged from 0000866374-19-000013:notes:69]

[0000866374-20-000003:notes:70]
[same as prior period, unchanged from 0000866374-19-000013:notes:70]

[0000866374-20-000003:notes:71]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $523.2 million and $271.8 million as of December 31, 2019 and March 31, 2019, respectively.

[0000866374-20-000003:notes:72]
[same as prior period, unchanged from 0000866374-19-000013:notes:72]

[0000866374-20-000003:notes:73]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2019 and December 31, 2018 (in thousands), respectively.

[0000866374-20-000003:notes:74]
|  | Three-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 978,026 |  |  | $ | 1,471,116 |  |  | $ | 1,513,721 |  |  | $ | 1,191,491 |  |  | $ | 5,154,354 |  |
| Over time | 266,689 |  |  | 517,749 |  |  | 367,690 |  |  | 154,905 |  |  | 1,307,033 |  |
| Total segment | $ | 1,244,715 |  |  | $ | 1,988,865 |  |  | $ | 1,881,411 |  |  | $ | 1,346,396 |  |  | $ | 6,461,387 |  |

[0000866374-20-000003:notes:75]
|  | Nine-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,843,866 |  |  | $ | 3,734,151 |  |  | $ | 4,263,144 |  |  | $ | 3,319,972 |  |  | $ | 14,161,133 |  |
| Over time | 767,523 |  |  | 1,677,196 |  |  | 1,205,713 |  |  | 913,815 |  |  | 4,564,247 |  |
| Total segment | $ | 3,611,389 |  |  | $ | 5,411,347 |  |  | $ | 5,468,857 |  |  | $ | 4,233,787 |  |  | $ | 18,725,380 |  |

[0000866374-20-000003:notes:76]
|  | Three-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 929,638 |  |  | $ | 1,198,669 |  |  | $ | 1,663,262 |  |  | $ | 1,232,712 |  |  | $ | 5,024,281 |  |
| Over time | 276,714 |  |  | 460,256 |  |  | 596,966 |  |  | 564,610 |  |  | 1,898,546 |  |
| Total segment | $ | 1,206,352 |  |  | $ | 1,658,925 |  |  | $ | 2,260,228 |  |  | $ | 1,797,322 |  |  | $ | 6,922,827 |  |

[0000866374-20-000003:notes:77]
|  | Nine-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,827,959 |  |  | $ | 3,351,886 |  |  | $ | 4,675,809 |  |  | $ | 3,732,545 |  |  | $ | 14,588,199 |  |
| Over time | 801,790 |  |  | 1,319,302 |  |  | 1,679,502 |  |  | 1,595,594 |  |  | 5,396,188 |  |
| Total segment | $ | 3,629,749 |  |  | $ | 4,671,188 |  |  | $ | 6,355,311 |  |  | $ | 5,328,139 |  |  | $ | 19,984,387 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-20-000003:notes:78]
[same as prior period, unchanged from 0000866374-19-000013:notes:78]

[0000866374-20-000003:notes:79]
[same as prior period, unchanged from 0000866374-19-000013:notes:79]

[0000866374-20-000003:notes:80]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Cost of sales | $ | 4,275 |  |  | $ | 4,769 |  |  | $ | 11,427 |  |  | $ | 14,940 |  |
| Selling, general and administrative expenses | 14,940 |  |  | 16,258 |  |  | 41,905 |  |  | 46,121 |  |
| Total share-based compensation expense | $ | 19,215 |  |  | $ | 21,027 |  |  | $ | 53,332 |  |  | $ | 61,061 |  |

[0000866374-20-000003:notes:81]
Total unrecognized compensation expense related to share options under all plans as well as the number of options outstanding and exercisable were immaterial as of December 31, 2019.

[0000866374-20-000003:notes:82]
During the nine-month period ended December 31, 2019, the Company granted 8.2 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 6.4 million are plain-vanilla unvested RSU awards that vest over four years, with no performance or market conditions, and with an average grant date price of $9.22 per award. Further, approximately 1.8 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $11.92 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 3.6 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-20-000003:notes:83]
As of December 31, 2019, approximately 17.0 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 3.5 million awards is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 7.0 million based on the achievement levels of the respective conditions. During the nine-month period ended December 31, 2019, no shares vested in connection with the awards with market conditions granted in fiscal year 2017.

[0000866374-20-000003:notes:84]
As of December 31, 2019, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $139.5 million, and will be recognized over a weighted-average remaining vesting period of 2.4 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-20-000003:notes:85]
EARNINGS (LOSS) PER SHARE 
The following table reflects basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share attributable to the shareholders of Flex:

[0000866374-20-000003:notes:86]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
|  | (In thousands, except per share amounts) |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 111,388 |  |  | $ | (45,169 | ) |  | $ | 39,320 |  |  | $ | 157,751 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 506,938 |  |  | 524,876 |  |  | 511,198 |  |  | 528,528 |  |
| Basic earnings (loss) per share | $ | 0.22 |  |  | $ | (0.09 | ) |  | $ | 0.08 |  |  | $ | 0.30 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 111,388 |  |  | $ | (45,169 | ) |  | $ | 39,320 |  |  | $ | 157,751 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 506,938 |  |  | 524,876 |  |  | 511,198 |  |  | 528,528 |  |
| Weighted-average ordinary share equivalents from stock options and restricted share unit awards (1) (2) | 3,401 |  |  | — |  |  | 3,351 |  |  | 3,780 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 510,339 |  |  | 524,876 |  |  | 514,549 |  |  | 532,308 |  |
| Diluted earnings (loss) per share | $ | 0.22 |  |  | $ | (0.09 | ) |  | $ | 0.08 |  |  | $ | 0.30 |  |

[0000866374-20-000003:notes:87]
| (1) | An immaterial number of options to purchase ordinary shares were excluded from the computation of diluted earnings (loss) per share during the three and nine-month periods ended December 31, 2019 and December 31, 2018, respectively, due to their anti-dilutive impact on the weighted-average ordinary share equivalents. |

[0000866374-20-000003:notes:88]
(2)

[0000866374-20-000003:notes:89]
RSU awards of 3.7 million and 4.0 million for the three and nine-month periods ended December 31, 2019 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. An immaterial number and 6.6 million of anti-dilutive RSU awards for the three and nine-month periods ended December 31, 2018, respectively, were excluded from the computation of diluted earnings (loss) per share.


## us-gaap:DebtDisclosureTextBlock

[0000866374-20-000003:notes:90]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2019 are as follows:

[0000866374-20-000003:notes:91]
|  | As of December 31, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | — |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 439,688 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305,927 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,150 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 662,205 |  |  | — |  |
| India Facilities | 133,145 |  |  | 170,206 |  |
| Other | 165,897 |  |  | 168,039 |  |
| Debt issuance costs | (14,031 | ) |  | (10,639 | ) |
|  | 2,789,981 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (88,869 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,701,112 |  |  | $ | 2,421,904 |  |

[0000866374-20-000003:notes:92]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.2% as of December 31, 2019 and March 31, 2019.

[0000866374-20-000003:notes:93]
During fiscal year 2020, and as further discussed below, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, in addition to issuing $650 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay the outstanding balances of the Company's existing 4.625% Notes due February 2020, and the Term Loan due November 2021. As both transactions were determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during the three-month and nine-month periods ended December 31, 2019, which was recorded in interest and other, net on the condensed consolidated statements of operations during the period.

[0000866374-20-000003:notes:94]
Scheduled repayments of the Company's long-term debt as of December 31, 2019 are as follows:

[0000866374-20-000003:notes:95]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2020 (1) |  | $ | 6,630 |  |
| 2021 |  | 99,787 |  |
| 2022 |  | 206,041 |  |
| 2023 |  | 862,849 |  |
| 2024 |  | 60,438 |  |
| Thereafter |  | 1,568,267 |  |
| Total |  | $ | 2,804,012 |  |

[0000866374-20-000003:notes:96]
| (1) | Represents estimated repayments for the remaining three-month period ending March 31, 2020. |

[0000866374-20-000003:notes:97]
Term Loan due April 2024

[0000866374-20-000003:notes:98]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 10 for additional details.

[0000866374-20-000003:notes:99]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are

[0000866374-20-000003:notes:100]
subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2019, the Company was in compliance with the covenants under this term loan agreement.

[0000866374-20-000003:notes:101]
Notes due June 2029

[0000866374-20-000003:notes:102]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “Existing 2029 Notes”), at 99.607% of face value. In November 2019, as a further issuance of the Existing 2029 Notes, the Company issued under the same terms, an additional $200 million of 4.875% Notes due June 15, 2029 (together with the "Existing 2029 Notes" above, the "2029 Notes"), at 107.289% of face value. Immediately after the issuance of the notes issued in November 2019, the Company has $650 million aggregate principal amount of 4.875% Notes due 2029 outstanding. The Company received in aggregate, proceeds of approximately $662.8 million, net of discount and premium, from the issuances which were used, together with available cash, to refinance certain other outstanding debt. The Company incurred and capitalized as a direct reduction to the carrying amount of the notes presented on the balance sheet approximately $6.6 million of costs in conjunction with the issuance of the 2029 Notes.

[0000866374-20-000003:notes:103]
Interest on the 2029 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2019. The 2029 Notes are senior unsecured obligations of the Company and rank equally with all of the Company’s other existing and future senior and unsecured indebtedness.

[0000866374-20-000003:notes:104]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of December 31, 2019, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.


## flex:InterestAndOtherNetTextBlock

[0000866374-20-000003:notes:105]
INTEREST AND OTHER, NET 
Interest and other, net for the three and nine-month periods ended December 31, 2019 and December 31, 2018 are primarily composed of the following:

[0000866374-20-000003:notes:106]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Interest expenses on debt obligations (1) | $ | 35,131 |  |  | $ | 38,830 |  |  | $ | 114,020 |  |  | $ | 107,486 |  |
| ABS and AR sales programs related expenses | 10,512 |  |  | 12,077 |  |  | 35,151 |  |  | 32,666 |  |
| Interest income | (5,452 | ) |  | (4,198 | ) |  | (15,250 | ) |  | (14,070 | ) |
| (Gain) Loss on foreign exchange transactions | (2,974 | ) |  | (3,284 | ) |  | (7,027 | ) |  | 1,902 |  |

[0000866374-20-000003:notes:107]
[same as prior period, unchanged from 0000866374-19-000013:notes:109]

[0000866374-20-000003:notes:108]
Interest expense on debt obligations for the three and nine-month periods ended December 31, 2019 include debt extinguishment costs of $0.8 million and $7.2 million, respectively, related to the full repayments of the Notes due February 2020 and the Term Loan due November 2021. There were no debt extinguishment costs incurred during the fiscal year 2019.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-20-000003:notes:109]
OTHER CHARGES (INCOME), NET 
During fiscal year 2019, the Company deconsolidated Bright Machines and recognized a gain of $87.3 million in other income, net. During the three-month ended December 31, 2019 and in connection with the Company’s ongoing assessment of its investment portfolio strategy, the Company concluded that the carrying amount of the investment was other than temporarily impaired and recognized a $15.8 million impairment charge.

[0000866374-20-000003:notes:110]
During the three-month period ended December 31, 2018, the Company recognized other charges of $71.9 million, primarily driven by a $70.1 million charge related to the impairment of a certain investment in an unrelated third-party venture backed company. This charge was offset by the $87.3 million gain on the deconsolidation of Bright Machines for the nine-month period ended December 31, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-20-000003:notes:111]
[same as prior period, unchanged from 0000866374-19-000013:notes:112]

[0000866374-20-000003:notes:112]
[same as prior period, unchanged from 0000866374-19-000013:notes:113]

[0000866374-20-000003:notes:113]
As of December 31, 2019, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $8.5 billion as summarized below:

[0000866374-20-000003:notes:114]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  |
| CNY |  | 1,150,500 |  |  | — |  |  | $ | 164,376 |  |  | $ | — |  |
| EUR |  | 40,108 |  |  | 45,480 |  |  | 44,695 |  |  | 51,528 |  |
| HUF |  | 24,594,000 |  |  | — |  |  | 82,980 |  |  | — |  |
| ILS |  | 222,000 |  |  | — |  |  | 64,197 |  |  | — |  |
| JPY |  | 33,525,000 |  |  | — |  |  | 300,000 |  |  | — |  |
| MXN |  | 3,840,000 |  |  | — |  |  | 203,768 |  |  | — |  |
| MYR |  | 256,000 |  |  | 30,000 |  |  | 61,801 |  |  | 7,242 |  |
| RON |  | 177,000 |  |  | — |  |  | 41,309 |  |  | — |  |
| Other |  | N/A |  |  | N/A |  |  | 93,062 |  |  | — |  |
|  |  |  |  |  |  |  |  | 1,056,188 |  |  | 58,770 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 1,030,000 |  |  | — |  |  | 253,982 |  |
| CAD |  | 61,635 |  |  | 35,624 |  |  | 47,100 |  |  | 27,223 |  |
| CNY |  | 3,531,534 |  |  | 140,048 |  |  | 500,586 |  |  | 20,000 |  |
| EUR |  | 1,891,736 |  |  | 2,090,728 |  |  | 2,109,548 |  |  | 2,329,869 |  |
| GBP |  | 48,512 |  |  | 63,795 |  |  | 63,479 |  |  | 83,458 |  |
| HUF |  | 60,687,931 |  |  | 58,055,222 |  |  | 204,760 |  |  | 195,877 |  |
| ILS |  | 111,600 |  |  | 47,600 |  |  | 32,272 |  |  | 13,765 |  |
| INR |  | 8,051,000 |  |  | 6,956,674 |  |  | 112,834 |  |  | 97,495 |  |
| JPY |  | 2,832,862 |  |  | 2,215,532 |  |  | 25,865 |  |  | 20,242 |  |
| MXN |  | 5,106,692 |  |  | 3,870,080 |  |  | 270,984 |  |  | 205,364 |  |
| MYR |  | 1,060,570 |  |  | 817,890 |  |  | 256,034 |  |  | 197,448 |  |
| PLN |  | 117,246 |  |  | 82,118 |  |  | 30,733 |  |  | 21,525 |  |
| SEK |  | 529,107 |  |  | 611,979 |  |  | 56,023 |  |  | 65,493 |  |
| SGD |  | 98,938 |  |  | 63,959 |  |  | 73,168 |  |  | 47,300 |  |
| Other |  | N/A |  |  | N/A |  |  | 41,622 |  |  | 26,027 |  |
|  |  |  |  |  |  |  |  | 3,825,008 |  |  | 3,605,068 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  |  | $ | 4,881,196 |  |  | $ | 3,663,838 |  |

[0000866374-20-000003:notes:115]
As of December 31, 2019, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of December 31, 2019 and March 31, 2019, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were immaterial as of December 31, 2019, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-20-000003:notes:116]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of December 31, 2019. The changes in fair value of the USD JPY cross currency swap are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also

[0000866374-20-000003:notes:117]
impacts the same line.

[0000866374-20-000003:notes:118]
[same as prior period, unchanged from 0000866374-19-000013:notes:119]

[0000866374-20-000003:notes:119]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31, 2019 |  | March 31, 2019 |  | Balance SheetLocation |  | December 31, 2019 |  | March 31, 2019 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 9,113 |  |  | $ | 10,503 |  |  | Other current liabilities |  | $ | 10,284 |  |  | $ | 10,282 |  |
| Foreign currency contracts | Other assets |  | $ | 9,782 |  |  | $ | — |  |  | Other liabilities |  | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 27,147 |  |  | $ | 16,774 |  |  | Other current liabilities |  | $ | 21,347 |  |  | $ | 17,144 |  |

[0000866374-20-000003:notes:120]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-20-000003:notes:121]
[same as prior period, unchanged from 0000866374-19-000013:notes:122]

[0000866374-20-000003:notes:122]
|  | Three-Month Periods Ended |
|  | December 31, 2019 |  | December 31, 2018 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (58,654 | ) |  | $ | (131,110 | ) |  | $ | (189,764 | ) |  | $ | (55,574 | ) |  | $ | (100,807 | ) |  | $ | (156,381 | ) |
| Other comprehensive gain (loss) before reclassifications | 1,134 |  |  | 11,443 |  |  | 12,577 |  |  | (14,683 | ) |  | (7,777 | ) |  | (22,460 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 12,108 |  |  | (1,446 | ) |  | 10,662 |  |  | 19,318 |  |  | — |  |  | 19,318 |  |
| Net current-period other comprehensive gain (loss) | 13,242 |  |  | 9,997 |  |  | 23,239 |  |  | 4,635 |  |  | (7,777 | ) |  | (3,142 | ) |
| Ending balance | $ | (45,412 | ) |  | $ | (121,113 | ) |  | $ | (166,525 | ) |  | $ | (50,939 | ) |  | $ | (108,584 | ) |  | $ | (159,523 | ) |

[0000866374-20-000003:notes:123]
|  | Nine-Month Periods Ended |
|  | December 31, 2019 |  | December 31, 2018 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (41,556 | ) |  | $ | (109,607 | ) |  | $ | (151,163 | ) |  | $ | (35,746 | ) |  | $ | (50,099 | ) |  | $ | (85,845 | ) |
| Other comprehensive loss before reclassifications | (7,817 | ) |  | (10,060 | ) |  | (17,877 | ) |  | (55,396 | ) |  | (58,485 | ) |  | (113,881 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 3,961 |  |  | (1,446 | ) |  | 2,515 |  |  | 40,203 |  |  | — |  |  | 40,203 |  |
| Net current-period other comprehensive loss | (3,856 | ) |  | (11,506 | ) |  | (15,362 | ) |  | (15,193 | ) |  | (58,485 | ) |  | (73,678 | ) |
| Ending balance | $ | (45,412 | ) |  | $ | (121,113 | ) |  | $ | (166,525 | ) |  | $ | (50,939 | ) |  | $ | (108,584 | ) |  | $ | (159,523 | ) |

[0000866374-20-000003:notes:124]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and nine-month periods ended December 31, 2019 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-20-000003:notes:125]
[same as prior period, unchanged from 0000866374-19-000013:notes:126]

[0000866374-20-000003:notes:126]
[same as prior period, unchanged from 0000866374-19-000013:notes:127]

[0000866374-20-000003:notes:127]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells the receivables to unaffiliated financial institutions.

[0000866374-20-000003:notes:128]
Prior to November 2019, these programs allowed the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables ("Old ABS Programs"). The portion of the purchase price for the receivables which was not paid by the unaffiliated financial institutions in cash was a deferred purchase price receivable, which was paid to the special purpose entity as payments on the receivables were collected from account debtors. The deferred purchase price receivable represented a beneficial interest in the transferred financial assets and was recognized at fair value as part of the sale transaction. The accounts receivable balances that were sold under the Old ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows. The Company recognized these proceeds net of the deferred purchase price, consisting of a receivable from the purchasers that entitled the Company to certain collections on the receivable. The Company recognized the collection of the deferred purchase price in net cash provided by investing activities in the condensed consolidated statements of cash flows.

[0000866374-20-000003:notes:129]
Effective November 2019, the Company amended the ABS programs to extend the facilities to November 26, 2021, and removed the requirement for the deferred purchase price receivable ("New ABS Programs"). Under the New ABS Programs,  the entire purchase price of sold receivables are paid in cash. The New ABS Programs contain a guarantee of payment by the special purpose entity, in an amount equal to approximately the net cash proceeds under the programs, and is collateralized by certain receivables held by the special purpose entity. The fair value of the guarantee obligation was immaterial as of December 31, 2019. The accounts receivable balances sold under the New ABS Programs were removed from the condensed consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-20-000003:notes:130]
At the effective date of the New ABS Programs, approximately $1.3 billion representing the outstanding balance of sold receivables was repurchased by the Company by exchanging outstanding deferred purchase price receivable of $0.4 billion and

[0000866374-20-000003:notes:131]
re-investing $0.9 billion of trade account receivables into the New ABS Programs. These repurchases are considered non-cash investing activities in the condensed consolidated statements of cash flows. Cash collections on repurchased deferred purchase price receivables are reported as investing activities in the condensed consolidated statements of cash flows and were approximately $0.3 billion for the nine-month period ended December 31, 2019.

[0000866374-20-000003:notes:132]
The deferred purchase price receivables, which are included in other current assets as of March 31, 2019, were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables, and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented. There are no deferred purchase price receivables outstanding as of December 31, 2019. Approximately $55 million of the repurchased deferred purchase price receivables remain uncollected and outstanding as of December 31, 2019, and are included in other current assets within the condensed consolidated balance sheet, at the expected recovery amount.

[0000866374-20-000003:notes:133]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are legally isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which have the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $790 million for the Global Program, of which $615 million is committed and $175 million is uncommitted, and $285 million for the North American Program, of which $210 million is committed and $75 million is uncommitted.

[0000866374-20-000003:notes:134]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three and nine-month periods ended December 31, 2019 and December 31, 2018 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-20-000003:notes:135]
As of December 31, 2019, approximately $0.9 billion of accounts receivable had been sold to the special purpose entities under the New ABS Programs for which the Company had received net cash proceeds for the same amount. As of March 31, 2019, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $0.9 billion and deferred purchase price receivables of $0.3 billion. The deferred purchase price balances as of March 31, 2019, also represent the non-cash beneficial interest obtained in exchange for securitized receivables.

[0000866374-20-000003:notes:136]
For the nine-month periods ended December 31, 2019 and December 31, 2018, cash flows from sales of receivables under the Old ABS Programs consisted of approximately $3.7 billion and $5.2 billion, respectively, for transfers of receivables, and approximately $2.2 billion and $2.7 billion, respectively, for collections on deferred purchase price receivables. The Company's cash flows from transfer of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-20-000003:notes:137]
Trade Accounts Receivable Sale Programs
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.3 billion and $0.5 billion as of December 31, 2019 and March 31, 2019, respectively. For the nine-month periods ended December 31, 2019 and December 31, 2018, total accounts receivable sold to certain third-party banking institutions was approximately $1.2 billion and $2.1 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-20-000003:notes:138]
[same as prior period, unchanged from 0000866374-19-000013:notes:137]

[0000866374-20-000003:notes:139]
[same as prior period, unchanged from 0000866374-19-000013:notes:138]

[0000866374-20-000003:notes:140]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager. The Company’s deferred compensation plan assets are included in other noncurrent assets on the condensed consolidated balance sheets and include investments in equity securities that are valued using active market prices. There were no investments  classified as level 1 in the fair value hierarchy as of December 31, 2019.

[0000866374-20-000003:notes:141]
[same as prior period, unchanged from 0000866374-19-000013:notes:140]

[0000866374-20-000003:notes:142]
[same as prior period, unchanged from 0000866374-19-000013:notes:141]

[0000866374-20-000003:notes:143]
[same as prior period, unchanged from 0000866374-19-000013:notes:142]

[0000866374-20-000003:notes:144]
[same as prior period, unchanged from 0000866374-19-000013:notes:143]

[0000866374-20-000003:notes:145]
[same as prior period, unchanged from 0000866374-19-000013:notes:144]

[0000866374-20-000003:notes:146]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of December 31, 2019 and March 31, 2019.

[0000866374-20-000003:notes:147]
The Company's deferred purchase price receivables relating to its asset-backed securitization program are recorded initially at fair value based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short-term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not material. The interrelationship between these inputs is also insignificant. There is no deferred purchase price receivables outstanding as of December 31, 2019 due to the New ABS Programs as further discussed in Note 12.

[0000866374-20-000003:notes:148]
There were no transfers between levels in the fair value hierarchy during the nine-month periods ended December 31, 2019 and December 31, 2018.

[0000866374-20-000003:notes:149]
[same as prior period, unchanged from 0000866374-19-000013:notes:147]

[0000866374-20-000003:notes:150]
[same as prior period, unchanged from 0000866374-19-000013:notes:148]

[0000866374-20-000003:notes:151]
|  | Fair Value Measurements as of December 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 373,644 |  |  | $ | — |  |  | $ | 373,644 |  |
| Foreign currency contracts (Note 10) | — |  |  | 46,042 |  |  | — |  |  | 46,042 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 58,204 |  |  | — |  |  | 58,204 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0.003 |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (31,631 | ) |  | $ | — |  |  | $ | (31,631 | ) |
|  | Fair Value Measurements as of March 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 473,888 |  |  | $ | — |  |  | $ | 473,888 |  |
| Foreign currency contracts (Note 10) | — |  |  | 27,277 |  |  | — |  |  | 27,277 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 2,845 |  |  | 76,852 |  |  | — |  |  | 79,697 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (27,426 | ) |  | $ | — |  |  | $ | (27,426 | ) |

[0000866374-20-000003:notes:152]
[same as prior period, unchanged from 0000866374-19-000013:notes:150]

[0000866374-20-000003:notes:153]
[same as prior period, unchanged from 0000866374-19-000013:notes:151]

[0000866374-20-000003:notes:154]
|  | As of December 31, 2019 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through June 2022 | 439,688 |  |  | 441,337 |  |  | 458,531 |  |  | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 534,733 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305,927 |  |  | 305,927 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,150 |  |  | 647,854 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 662,205 |  |  | 717,955 |  |  | — |  |  | — |  |  | Level 1 |
| India Facilities | 133,145 |  |  | 133,145 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |
| Euro Term Loan due September 2020 | 51,281 |  |  | 51,281 |  |  | 52,746 |  |  | 52,746 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 111,632 |  |  | 111,632 |  |  | 112,524 |  |  | 112,524 |  |  | Level 2 |
| Total | $ | 2,801,028 |  |  | $ | 2,943,864 |  |  | $ | 1,890,822 |  |  | $ | 1,893,324 |  |  |  |

[0000866374-20-000003:notes:155]
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans due September 2020 and January 2022 based on the current market rate, and as of December 31, 2019, the carrying amounts approximate fair values.
The Term Loan due June 2022, and the Notes due February 2023, June 2025 and June 2029 are valued based on broker trading prices in active markets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-20-000003:notes:156]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-20-000003:notes:157]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-20-000003:notes:158]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-20-000003:notes:159]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

[0000866374-20-000003:notes:160]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019,  lead plaintiff filed a further amended complaint. On December 4, 2019, Defendants filed a motion to dismiss the amended complaint. Defendants’ motion to dismiss is set for hearing on April 9, 2020. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-20-000003:notes:161]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible

[0000866374-20-000003:notes:162]
contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-20-000003:notes:163]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There are six tax assessments totaling 340 million Brazilian reals (approximately USD $83.8 million based on the exchange rate as of December 31, 2019). The assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60 million Brazilian reals or USD $14.8 million), but that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-20-000003:notes:164]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter which is ongoing. The Company cannot predict how long it will take to complete the investigation or to what extent the Company could be subject to penalties.

[0000866374-20-000003:notes:165]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes. As the final resolution of the assessment remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-20-000003:notes:166]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-20-000003:notes:167]
SHARE REPURCHASES 
During the three and nine-month periods ended December 31, 2019, the Company repurchased 5.3 million and 16.2 million shares at an aggregate purchase price of $61.0 million and $173.1 million, respectively, and retired all of these shares.

[0000866374-20-000003:notes:168]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 20, 2019. As of December 31, 2019, shares in the aggregate amount of $402.0 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-20-000003:notes:169]
[same as prior period, unchanged from 0000866374-19-000013:notes:167]

[0000866374-20-000003:notes:170]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment charges, restructuring charges, the new revenue standard adoption impact, legal and other, interest and other, net and other charges (income), net.

[0000866374-20-000003:notes:171]
[same as prior period, unchanged from 0000866374-19-000013:notes:170]

[0000866374-20-000003:notes:172]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| High Reliability Solutions | $ | 1,244,715 |  |  | $ | 1,206,352 |  |  | $ | 3,611,389 |  |  | $ | 3,629,749 |  |
| Industrial & Emerging Industries | 1,988,865 |  |  | 1,658,925 |  |  | 5,411,347 |  |  | 4,671,188 |  |
| Communications & Enterprise Compute | 1,881,411 |  |  | 2,260,228 |  |  | 5,468,857 |  |  | 6,355,311 |  |
| Consumer Technologies Group | 1,346,396 |  |  | 1,797,322 |  |  | 4,233,787 |  |  | 5,328,139 |  |
|  | $ | 6,461,387 |  |  | $ | 6,922,827 |  |  | $ | 18,725,380 |  |  | $ | 19,984,387 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| High Reliability Solutions | $ | 82,111 |  |  | $ | 95,751 |  |  | $ | 252,743 |  |  | $ | 278,874 |  |
| Industrial & Emerging Industries | 124,420 |  |  | 78,782 |  |  | 331,231 |  |  | 196,000 |  |
| Communications & Enterprise Compute | 53,086 |  |  | 62,590 |  |  | 110,867 |  |  | 171,463 |  |
| Consumer Technologies Group | 24,654 |  |  | 39,023 |  |  | 81,762 |  |  | 96,792 |  |
| Corporate and Other | (28,233 | ) |  | (19,768 | ) |  | (85,563 | ) |  | (75,513 | ) |
| Total segment income | 256,038 |  |  | 256,378 |  |  | 691,040 |  |  | 667,616 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 15,598 |  |  | 20,308 |  |  | 48,903 |  |  | 57,059 |  |
| Stock-based compensation | 19,215 |  |  | 21,027 |  |  | 53,332 |  |  | 61,061 |  |
| Customer related asset impairments (1) | 3,754 |  |  | 50,153 |  |  | 95,210 |  |  | 67,517 |  |
| Restructuring charges (Note 17) | 14,616 |  |  | 65,843 |  |  | 199,123 |  |  | 100,433 |  |
| New revenue standard adoption impact (Note 4) | — |  |  | — |  |  | — |  |  | 9,291 |  |
| Legal and other (2) | 6,864 |  |  | 4,994 |  |  | 28,012 |  |  | 25,363 |  |
| Interest and other, net | 36,207 |  |  | 54,087 |  |  | 135,650 |  |  | 136,889 |  |
| Other charges (income), net (Note 9) | 14,395 |  |  | 71,879 |  |  | 17,005 |  |  | (8,515 | ) |
| Income (loss) before income taxes | $ | 145,389 |  |  | $ | (31,913 | ) |  | $ | 113,805 |  |  | $ | 218,518 |  |

[0000866374-20-000003:notes:173]
| (1) | Customer related asset impairments for the three-month and nine-month periods ended December 31, 2019 and December 31, 2018 primarily relate to non-cash impairments of certain property and equipment for customers we have disengaged or are in the process of disengaging, additional provision for doubtful accounts receivable, charges for other asset impairments, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand as the Company reduces its exposure to certain higher volatility businesses. |

[0000866374-20-000003:notes:174]
| (2) | Legal and other during the three-month and nine-month periods ended December 31, 2019 primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India. |

[0000866374-20-000003:notes:175]
Legal and other during the three and nine-month periods ended December 31, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, for the nine-month period ended December 31, 2018, Legal and other also includes certain charges of the China based Multek operations that was divested in the second quarter of fiscal year 2019.

[0000866374-20-000003:notes:176]
[same as prior period, unchanged from 0000866374-19-000013:notes:176]

[0000866374-20-000003:notes:177]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled on the operating campuses and are compatible across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segments nor reported by segment to the Company's CODM.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-20-000003:notes:178]
RESTRUCTURING CHARGES
During fiscal year 2019, the Company took actions to optimize its portfolio with greater focus to be placed on higher margin, less volatile businesses. During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and streamline its cost structure. During the three and nine-month periods ended December 31, 2019, the Company recognized $14.6 million and $199.1 million, respectively, of restructuring charges. The Company incurred cash charges of approximately $14.9 million and $142.7 million, respectively, that were predominantly for employee severance, in addition to non-cash charges of an immaterial amount and $56.4 million, respectively, primarily related to asset impairments during the three and nine-month periods ended December 31, 2019.

[0000866374-20-000003:notes:179]
During the three and nine-month periods ended December 31, 2018, the Company recognized $65.8 million and $100.4 million, respectively, for charges primarily associated with the wind down of its NIKE operations in Mexico, the majority of which were for non-cash asset impairments.

[0000866374-20-000003:notes:180]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of December 31, 2019 for charges incurred during the nine-month period ended December 31, 2019:

[0000866374-20-000003:notes:181]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In thousands) |
| Balance as of March 31, 2019 | $ | 23,234 |  |  | $ | — |  |  | $ | 9,200 |  |  | $ | 32,434 |  |
| Provision for charges incurred during the nine-month period ended December 31, 2019 | 107,598 |  |  | 44,746 |  |  | 46,779 |  |  | 199,123 |  |
| Cash payments for charges incurred in the fiscal year 2019 and prior | (13,267 | ) |  | — |  |  | (2,800 | ) |  | (16,067 | ) |
| Cash payments for charges incurred during the nine-month period ended December 31, 2019 | (96,827 | ) |  | — |  |  | (34,125 | ) |  | (130,952 | ) |
| Non-cash charges incurred during the nine-month period ended December 31, 2019 | — |  |  | (44,746 | ) |  | (12,344 | ) |  | (57,090 | ) |
| Balance as of December 31, 2019 | 20,738 |  |  | — |  |  | 6,710 |  |  | 27,448 |  |
| Less: Current portion (classified as other current liabilities) | 20,738 |  |  | — |  |  | 6,710 |  |  | 27,448 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
