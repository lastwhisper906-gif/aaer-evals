# FLEX MD&A — 0000866374-20-000003


## mdna

[0000866374-20-000003:mdna:1]
[same as prior period, unchanged from 0000866374-19-000013:mdna:1]

[0000866374-20-000003:mdna:2]
[same as prior period, unchanged from 0000866374-19-000013:mdna:2]

[0000866374-20-000003:mdna:3]
[same as prior period, unchanged from 0000866374-19-000013:mdna:16]

[0000866374-20-000003:mdna:4]
[same as prior period, unchanged from 0000866374-19-000013:mdna:5]

[0000866374-20-000003:mdna:5]
We are a globally-recognized, provider of Sketch-to-Scale® services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. We design, build, ship and manage complete packaged consumer and enterprise products, for companies of all sizes in various industries and end-markets, through our activities in the following segments:

[0000866374-20-000003:mdna:6]
[same as prior period, unchanged from 0000866374-19-000013:mdna:7]

[0000866374-20-000003:mdna:7]
[same as prior period, unchanged from 0000866374-19-000013:mdna:8]

[0000866374-20-000003:mdna:8]
[same as prior period, unchanged from 0000866374-19-000013:mdna:9]

[0000866374-20-000003:mdna:9]
[same as prior period, unchanged from 0000866374-19-000013:mdna:10]

[0000866374-20-000003:mdna:10]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and manage a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-20-000003:mdna:11]
[same as prior period, unchanged from 0000866374-19-000013:mdna:12]

[0000866374-20-000003:mdna:12]
[same as prior period, unchanged from 0000866374-19-000013:mdna:13]

[0000866374-20-000003:mdna:13]
[same as prior period, unchanged from 0000866374-19-000013:mdna:14]

[0000866374-20-000003:mdna:14]
During fiscal year 2019, we took actions to optimize our portfolio with greater focus to be placed on higher margin, less volatile businesses. During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. We recognized $199 million of charges during the first three quarters of fiscal year 2020, comprised of approximately $143 million of cash charges predominantly for employee severance, and $56 million of non-cash charges primarily related to asset impairments. While the bulk of the restructuring charges were executed in the first three quarters of fiscal year 2020, we expect to incur additional restructuring charges as we continue to optimize our portfolio with the majority of these activities planned to be completed by the end of the fiscal year.

[0000866374-20-000003:mdna:15]
[same as prior period, unchanged from 0000866374-19-000013:mdna:18]

[0000866374-20-000003:mdna:16]
We are one of the world's largest providers of global supply chain solutions, with revenues of $18.7 billion for the nine-month period ended December 31, 2019 and $26.2 billion in fiscal year 2019. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-20-000003:mdna:17]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Net sales: | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
|  | (In millions) |
| China | $ | 1,638 |  |  | 25 | % |  | $ | 1,779 |  |  | 26 | % |  | $ | 4,535 |  |  | 24 | % |  | $ | 5,179 |  |  | 26 | % |
| Mexico | 1,171 |  |  | 18 | % |  | 1,187 |  |  | 17 | % |  | 3,408 |  |  | 18 | % |  | 3,477 |  |  | 17 | % |
| U.S. | 966 |  |  | 15 | % |  | 886 |  |  | 13 | % |  | 2,677 |  |  | 14 | % |  | 2,173 |  |  | 11 | % |
| Brazil | 480 |  |  | 7 | % |  | 512 |  |  | 7 | % |  | 1,524 |  |  | 8 | % |  | 1,632 |  |  | 8 | % |
| Malaysia | 398 |  |  | 6 | % |  | 541 |  |  | 8 | % |  | 1,233 |  |  | 7 | % |  | 1,559 |  |  | 8 | % |
| India | 298 |  |  | 5 | % |  | 448 |  |  | 6 | % |  | 1,091 |  |  | 6 | % |  | 1,333 |  |  | 7 | % |
| Other | 1,510 |  |  | 24 | % |  | 1,570 |  |  | 23 | % |  | 4,257 |  |  | 23 | % |  | 4,631 |  |  | 23 | % |
|  | $ | 6,461 |  |  |  |  |  | $ | 6,923 |  |  |  |  |  | $ | 18,725 |  |  |  |  |  | $ | 19,984 |  |  |  |  |

[0000866374-20-000003:mdna:18]
[same as prior period, unchanged from 0000866374-19-000013:mdna:21]

[0000866374-20-000003:mdna:19]
As previously disclosed, we have made certain immaterial corrections to net sales previously reported for the first, second, and third quarters of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result of correcting these errors, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month and nine-month periods ended December 31, 2018 have been reduced by $22 million and $95 million, respectively, from previously reported amounts. These corrections had no impact on gross profit, segment income or net income for the periods presented.

[0000866374-20-000003:mdna:20]
|  | As of |  | As of |
| Property and equipment, net: | December 31, 2019 |  | March 31, 2019 |
|  | (In millions) |
| Mexico | $ | 553 |  |  | 25 | % |  | $ | 537 |  |  | 23 | % |
| China | 399 |  |  | 18 | % |  | 523 |  |  | 22 | % |
| U.S. | 375 |  |  | 17 | % |  | 361 |  |  | 15 | % |
| India | 209 |  |  | 9 | % |  | 219 |  |  | 9 | % |
| Malaysia | 120 |  |  | 5 | % |  | 138 |  |  | 6 | % |
| Hungary | 102 |  |  | 5 | % |  | 103 |  |  | 4 | % |
| Other | 448 |  |  | 21 | % |  | 454 |  |  | 21 | % |
|  | $ | 2,206 |  |  |  |  |  | $ | 2,336 |  |  |  |  |

[0000866374-20-000003:mdna:21]
[same as prior period, unchanged from 0000866374-19-000013:mdna:24]

[0000866374-20-000003:mdna:22]
We believe that the combination of our design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Most of the underlying manufacturing and design assets are co-mingled on the operating campuses and are compatible across our sites and business and highly interchangeable throughout the platform. We continue to leverage our existing assets to redeploy installed capacity where it is needed, which is a notable strength of our global system. In addition, we continue to reposition and optimize our global footprints while maximizing efficiency and return of our asset base by entering into asset disposals and/or sales leaseback arrangements as needed.

[0000866374-20-000003:mdna:23]
[same as prior period, unchanged from 0000866374-19-000013:mdna:26]

[0000866374-20-000003:mdna:24]
[same as prior period, unchanged from 0000866374-19-000013:mdna:27]

[0000866374-20-000003:mdna:25]
[same as prior period, unchanged from 0000866374-19-000013:mdna:29]

[0000866374-20-000003:mdna:26]
[same as prior period, unchanged from 0000866374-19-000013:mdna:30]

[0000866374-20-000003:mdna:27]
[same as prior period, unchanged from 0000866374-19-000013:mdna:31]

[0000866374-20-000003:mdna:28]
[same as prior period, unchanged from 0000866374-19-000013:mdna:32]

[0000866374-20-000003:mdna:29]
[same as prior period, unchanged from 0000866374-19-000013:mdna:33]

[0000866374-20-000003:mdna:30]
[same as prior period, unchanged from 0000866374-19-000013:mdna:34]

[0000866374-20-000003:mdna:31]
[same as prior period, unchanged from 0000866374-19-000013:mdna:35]

[0000866374-20-000003:mdna:32]
[same as prior period, unchanged from 0000866374-19-000013:mdna:36]

[0000866374-20-000003:mdna:33]
[same as prior period, unchanged from 0000866374-19-000013:mdna:37]

[0000866374-20-000003:mdna:34]
[same as prior period, unchanged from 0000866374-19-000013:mdna:38]

[0000866374-20-000003:mdna:35]
[same as prior period, unchanged from 0000866374-19-000013:mdna:39]

[0000866374-20-000003:mdna:36]
[same as prior period, unchanged from 0000866374-19-000013:mdna:40]

[0000866374-20-000003:mdna:37]
[same as prior period, unchanged from 0000866374-19-000013:mdna:41]

[0000866374-20-000003:mdna:38]
[same as prior period, unchanged from 0000866374-19-000013:mdna:42]

[0000866374-20-000003:mdna:39]
[same as prior period, unchanged from 0000866374-19-000013:mdna:43]

[0000866374-20-000003:mdna:40]
[same as prior period, unchanged from 0000866374-19-000013:mdna:44]

[0000866374-20-000003:mdna:41]
[same as prior period, unchanged from 0000866374-19-000013:mdna:45]

[0000866374-20-000003:mdna:42]
[same as prior period, unchanged from 0000866374-19-000013:mdna:46]

[0000866374-20-000003:mdna:43]
Beginning with the adoption of ASC 842 on April 1, 2019, we recognize a right-of-use (“ROU”) asset and a lease liability at the lease commencement date for our operating leases. For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at the lease commencement date. We have elected the short-term lease recognition and measurement exemption for all classes of assets, which allows us to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option we are reasonably certain of exercising. We have also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As we cannot determine the interest rate implicit in the lease for our leases, we use our estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments.

[0000866374-20-000003:mdna:44]
36

[0000866374-20-000003:mdna:45]
Our estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of our leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that we are reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-20-000003:mdna:46]
[same as prior period, unchanged from 0000866374-19-000013:mdna:50]

[0000866374-20-000003:mdna:47]
[same as prior period, unchanged from 0000866374-19-000013:mdna:51]

[0000866374-20-000003:mdna:48]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.1 |  |  | 94.0 |  |  | 93.9 |  |  | 93.9 |  |
| Restructuring charges | 0.2 |  |  | 0.9 |  |  | 0.9 |  |  | 0.4 |  |
| Gross profit | 6.7 |  |  | 5.1 |  |  | 5.2 |  |  | 5.7 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.4 |  |  | 3.4 |  |  | 3.6 |  |
| Intangible amortization | 0.2 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.0 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Interest and other, net | 0.6 |  |  | 0.8 |  |  | 0.7 |  |  | 0.7 |  |
| Other charges (income), net | 0.2 |  |  | 1.0 |  |  | 0.1 |  |  | 0.0 |  |
| Income (loss) before income taxes | 2.3 |  |  | (0.5 | ) |  | 0.6 |  |  | 1.0 |  |
| Provision for income taxes | 0.5 |  |  | 0.2 |  |  | 0.4 |  |  | 0.3 |  |
| Net income (loss) | 1.8 | % |  | (0.7 | )% |  | 0.2 | % |  | 0.7 | % |

[0000866374-20-000003:mdna:49]
[same as prior period, unchanged from 0000866374-19-000013:mdna:53]

[0000866374-20-000003:mdna:50]
[same as prior period, unchanged from 0000866374-19-000013:mdna:54]

[0000866374-20-000003:mdna:51]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Segments: | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
|  | (In millions) |
| High Reliability Solutions | $ | 1,245 |  |  | 19 | % |  | $ | 1,207 |  |  | 17 | % |  | $ | 3,611 |  |  | 19 | % |  | $ | 3,630 |  |  | 18 | % |
| Industrial & Emerging Industries | 1,989 |  |  | 31 | % |  | 1,659 |  |  | 24 | % |  | 5,411 |  |  | 29 | % |  | 4,671 |  |  | 23 | % |
| Communications & Enterprise Compute | 1,881 |  |  | 29 | % |  | 2,260 |  |  | 33 | % |  | 5,469 |  |  | 29 | % |  | 6,355 |  |  | 32 | % |
| Consumer Technologies Group | 1,346 |  |  | 21 | % |  | 1,797 |  |  | 26 | % |  | 4,234 |  |  | 23 | % |  | 5,328 |  |  | 27 | % |
|  | $ | 6,461 |  |  |  |  | $ | 6,923 |  |  |  |  | $ | 18,725 |  |  |  |  | $ | 19,984 |  |  |  |

[0000866374-20-000003:mdna:52]
[same as prior period, unchanged from 0000866374-19-000013:mdna:56]

[0000866374-20-000003:mdna:53]
Net sales during the three-month period ended December 31, 2019 totaled $6.5 billion, representing a decrease of approximately $461 million, or 7% from $6.9 billion during the three-month period ended December 31, 2018. The decrease in sales was driven by reduced demand in our CTG and CEC segments offset by increases in our IEI and HRS segments. Our CTG segment decreased $451 million, primarily resulting from our targeted reduction to high volatility, low margin, short-cycle customers and product categories. Our CEC segment decreased $379 million, driven by reduced demand in our networking and telecommunication businesses due to the slower roll-out of 5G technology and our previously announced disengagement with a customer primarily in China and India. Our IEI segment increased $330 million, mainly driven by strong sales within our solar energy business and our home and lifestyle business. Our HRS segment increased $38 million, primarily due to ramps in our automotive business that more than offset the modestly lower demand in our health solution business. Net sales decreased $462 million to $2.6 billion in Asia, $14 million to $1.3 billion in Europe, offset by a modest increase of $15 million to $2.6 billion in the Americas.

[0000866374-20-000003:mdna:54]
Net sales during the nine-month period ended December 31, 2019 totaled $18.7 billion, representing a decrease of approximately $1.3 billion, or 6% from $20.0 billion during the nine-month period ended December 31, 2018. With the exception of our IEI segment that increased $0.7 billion and offsets the overall decline in sales, all of our remaining segments declined from the year ago period. The most notable decreases were in our CTG and CEC segments of $1.1 billion and $0.9 billion, respectively versus the prior year nine-month period. The majority of the changes in segment results for the nine month periods are due to the same factors described above. Net sales decreased $1.4 billion to $7.5 billion in Asia, and $102 million to $3.6 billion in Europe, offset by an increase of $196 million to $7.7 billion in the Americas.

[0000866374-20-000003:mdna:55]
Our ten largest customers, during the three and nine-month periods ended December 31, 2019, accounted for approximately 40% and 39% of net sales, respectively. Our ten largest customers, during the three and nine-month periods ended December 31, 2018, accounted for approximately 43% of net sales. No customer accounted for more than 10% of net sales during the three and nine-month periods ended December 31, 2019 or December 31, 2018.

[0000866374-20-000003:mdna:56]
[same as prior period, unchanged from 0000866374-19-000013:mdna:60]

[0000866374-20-000003:mdna:57]
[same as prior period, unchanged from 0000866374-19-000013:mdna:61]

[0000866374-20-000003:mdna:58]
Gross profit during the three-month period ended December 31, 2019 increased $73 million to $430 million, or 6.7% of net sales, from $357 million, or 5.1% of net sales, during the three-month period ended December 31, 2018, with gross margin improving 160 basis points. The increase in both gross profit and gross margin is primarily the result of favorable product mix driven from revenue increases in some of our higher margin businesses in IEI, improved operational execution, reduced fixed costs resulting from prior restructuring activities, coupled with lower restructuring charges recorded during the three-month period ended December 31, 2019.

[0000866374-20-000003:mdna:59]
Gross profit during the nine-month period ended December 31, 2019 decreased $165 million to $972 million, or 5.2% of net sales, from $1,137 million, or 5.7% of net sales, during the nine-month period ended December 31, 2018, with gross margin declining 50 basis points. The decrease in both gross profit and gross margin is primarily due to the geopolitical challenges and uncertainties which impacted specific customers resulting in restructuring charges recorded in the first half of fiscal year 2020 as well as the write down of inventory in the second quarter of fiscal year 2020 that will not be recovered due to significant reductions in future customer demand as we reduce our exposure to certain higher volatility businesses. These were partially offset by the favorable product mix and the increased revenues and gross profit from our IEI segment, the wind-down of our NIKE Mexico operations in the second half of fiscal year 2019, and benefits realized from our earlier restructuring activities initiated in fiscal year 2019.

[0000866374-20-000003:mdna:60]
[same as prior period, unchanged from 0000866374-19-000013:mdna:63]

[0000866374-20-000003:mdna:61]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment charges, restructuring charges, the new revenue standard adoption impact, legal and other, interest and other, net and other charges (income), net. A portion of depreciation is allocated to the respective segment, together with other general corporate research and development and administrative expenses.

[0000866374-20-000003:mdna:62]
[same as prior period, unchanged from 0000866374-19-000013:mdna:66]

[0000866374-20-000003:mdna:63]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |
|  | (In millions) |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High Reliability Solutions | $ | 82 |  |  | 6.6 | % |  | $ | 96 |  |  | 7.9 | % |  | $ | 253 |  |  | 7.0 | % |  | $ | 279 |  |  | 7.7 | % |
| Industrial & Emerging Industries | 124 |  |  | 6.3 | % |  | 79 |  |  | 4.7 | % |  | 331 |  |  | 6.1 | % |  | 196 |  |  | 4.2 | % |
| Communications & Enterprise Compute | 53 |  |  | 2.8 | % |  | 63 |  |  | 2.8 | % |  | 111 |  |  | 2.0 | % |  | 171 |  |  | 2.7 | % |
| Consumer Technologies Group | 25 |  |  | 1.8 | % |  | 39 |  |  | 2.1 | % |  | 82 |  |  | 1.9 | % |  | 97 |  |  | 1.8 | % |
| Corporate and Other | (28 | ) |  |  |  | (20 | ) |  |  |  | (86 | ) |  |  |  | (76 | ) |  |  |
| Total segment income | 256 |  |  | 4.0 | % |  | 256 |  |  | 3.7 | % |  | 691 |  |  | 3.7 | % |  | 668 |  |  | 3.3 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 16 |  |  |  |  | 20 |  |  |  |  | 49 |  |  |  |  | 57 |  |  |  |
| Stock-based compensation | 19 |  |  |  |  | 21 |  |  |  |  | 53 |  |  |  |  | 61 |  |  |  |
| Customer related asset impairments (1) | 4 |  |  |  |  | 50 |  |  |  |  | 95 |  |  |  |  | 68 |  |  |  |
| Restructuring charges (Note 17) | 15 |  |  |  |  | 66 |  |  |  |  | 199 |  |  |  |  | 100 |  |  |  |
| New revenue standard adoption impact (Note 4) | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 9 |  |  |  |
| Legal and other (2) | 7 |  |  |  |  | 5 |  |  |  |  | 28 |  |  |  |  | 25 |  |  |  |
| Interest and other, net | 36 |  |  |  |  | 54 |  |  |  |  | 136 |  |  |  |  | 137 |  |  |  |
| Other charges (income), net (Note 9) | 14 |  |  |  |  | 72 |  |  |  |  | 17 |  |  |  |  | (9 | ) |  |  |
| Income (loss) before income taxes | $ | 145 |  |  |  |  | $ | (32 | ) |  |  |  | $ | 114 |  |  |  |  | $ | 219 |  |  |  |
| Amounts may not sum due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-20-000003:mdna:64]
| (1) | Customer related asset impairments for the three-month and nine-month periods ended December 31, 2019 and December 31, 2018 primarily relate to non-cash impairments of certain property and equipment for customers we have disengaged or are in the process of disengaging, additional provision for doubtful accounts receivable, charges for other asset impairments, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand as the Company reduces its exposure to certain higher volatility businesses. |

[0000866374-20-000003:mdna:65]
| (2) | Legal and other during the three-month and nine-month periods ended December 31, 2019 primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India. |

[0000866374-20-000003:mdna:66]
Legal and other during the three and nine-month periods ended December 31, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, for the nine-month period ended December 31, 2018, Legal and other also includes certain charges of the China based Multek operations that was divested in the second quarter of fiscal year 2019.

[0000866374-20-000003:mdna:67]
HRS segment margin decreased 130 basis points, to 6.6% for the three-month period ended December 31, 2019, from 7.9% for the three-month period ended December 31, 2018. HRS segment margin decreased 70 basis points, to 7.0% for the nine-month period ended December 31, 2019, from 7.7% for the nine-month period ended December 31, 2018. The decrease in HRS segment margin during the periods is primarily the result of accelerated investments and costs associated with new program ramps and pricing pressure with demand declines in the global market that impacted product mix.

[0000866374-20-000003:mdna:68]
IEI segment margin increased 160 basis points, to 6.3% for the three-month period ended December 31, 2019, from 4.7% for the three-month period ended December 31, 2018.  IEI segment margin increased 190 basis points, to 6.1% for the nine-month period ended December 31, 2019, from 4.2% for the nine-month period ended December 31, 2018. The increase in IEI's margin is primarily due to a favorable business mix resulting from increased demand from new business particularly in Energy and in Home & Lifestyle, greater levels of design and engineering led engagements and improved operational execution.

[0000866374-20-000003:mdna:69]
CEC segment margin remained consistent  at 2.8% for the three-month periods ended December 31, 2019 and December 31, 2018. CEC segment margin decreased 70 basis points, to 2.0% for the nine-month period ended December 31, 2019, from 2.7% for the nine-month period ended December 31, 2018. The decrease in CEC's margin during the nine-month period is

[0000866374-20-000003:mdna:70]
39

[0000866374-20-000003:mdna:71]
primarily due to geopolitical challenges and uncertainties which impacted demand from specific customers as well as a drop in demand in our networking and telecommunication businesses due to the slower roll-out of 5G technology which created elevated levels of unabsorbed manufacturing overhead costs.

[0000866374-20-000003:mdna:72]
CTG segment margin decreased 30 basis points to 1.8% for the three-month period ended December 31, 2019, from 2.1% for the three-month period ended December 31, 2018, as it remained pressured during our portfolio transition and ongoing repositioning of our operating structure.  CTG segment margin increased 10 basis points, to 1.9% for the nine-month period ended December 31, 2019, from 1.8% for the nine-month period ended December 31, 2018, which reflected lower losses from our former strategic partnership with NIKE versus the nine-month period ended December 31, 2018 and mix improvements as we continued to rationalize and prune underperforming accounts to improve our portfolio mix.

[0000866374-20-000003:mdna:73]
[same as prior period, unchanged from 0000866374-19-000013:mdna:77]

[0000866374-20-000003:mdna:74]
During fiscal year 2019, we took actions to optimize our portfolio with greater focus to be placed on higher margin, less volatile businesses. During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During the three and nine-month periods ended December 31, 2019, we recognized $15 million and $199 million, respectively, of restructuring charges. We incurred cash charges of approximately $15 million and $143 million, respectively, that were predominantly for employee severance, in addition to non-cash charges for an immaterial amount and $56 million, respectively, primarily related to asset impairments during the three and nine-month periods ended December 31, 2019. While the bulk of the restructuring charges were executed in the first three quarters of fiscal year 2020, we expect to incur additional restructuring charges throughout the fourth quarter of fiscal year 2020, and expect to complete the majority of these activities by the end of the fiscal year.

[0000866374-20-000003:mdna:75]
During the three and nine-month periods ended December 31, 2018, we recognized $66 million and $100 million, respectively, for charges primarily associated with the wind down of our NIKE operations in Mexico, the majority of which were for non-cash asset impairments.

[0000866374-20-000003:mdna:76]
[same as prior period, unchanged from 0000866374-19-000013:mdna:80]

[0000866374-20-000003:mdna:77]
Selling, general and administrative expenses (“SG&A”) was $218 million, or 3.4% of net sales, during the three-month period ended December 31, 2019, decreasing $20 million from $238 million, or 3.4% of net sales, during the three-month period ended December 31, 2018. SG&A was $633 million, or 3.4% of net sales, during the nine-month period ended December 31, 2019, decreasing $90 million from $723 million, or 3.6% of net sales, during the nine-month period ended December 31, 2018. These decreases were primarily due to strict cost discipline focused on driving further productivity improvements and a refined cost structure benefiting from prior restructuring initiatives.

[0000866374-20-000003:mdna:78]
[same as prior period, unchanged from 0000866374-19-000013:mdna:82]

[0000866374-20-000003:mdna:79]
Amortization of intangible assets was $16 million during the three-month period ended December 31, 2019, compared to $20 million for the three-month period ended December 31, 2018, and $49 million during the nine-month period ended December 31, 2019, compared to $57 million for the nine-month period ended December 31, 2018. The decline in both periods was primarily due to certain intangibles now being fully amortized.

[0000866374-20-000003:mdna:80]
[same as prior period, unchanged from 0000866374-19-000013:mdna:84]

[0000866374-20-000003:mdna:81]
Interest and other, net was $36 million during the three-month period ended December 31, 2019 compared to $54 million during the three-month period ended December 31, 2018, primarily due to a lower average borrowing levels and lower short term rates during the period.

[0000866374-20-000003:mdna:82]
Interest and other, net was $136 million during the nine-month period ended December 31, 2019 compared to $137 million during the nine-month period ended December 31, 2018, which primarily resulted from increases in net foreign exchange gains coupled with lower average borrowing levels, offset by higher expenses from our asset-backed securitization programs in addition to debt extinguishment costs incurred during fiscal year 2020.

[0000866374-20-000003:mdna:83]
[same as prior period, unchanged from 0000866374-19-000013:mdna:86]

[0000866374-20-000003:mdna:84]
Other charges (income), net was $14 million of net expense during the three-month period ended December 31, 2019, compared to $72 million of net expense during the three-month period ended December 31, 2018, primarily as a result of the $70 million charge related to an investment in an unrelated third-party venture backed company, determined to be impaired in fiscal year 2019. Other charges (income), net was $17 million of net expense during the nine-month period ended December 31, 2019, compared to $9 million of net income during the nine-month period ended December 31, 2018, primarily as a result of the non-cash gain from the deconsolidation of Bright Machines recognized in fiscal year 2019.

[0000866374-20-000003:mdna:85]
[same as prior period, unchanged from 0000866374-19-000013:mdna:88]

[0000866374-20-000003:mdna:86]
[same as prior period, unchanged from 0000866374-19-000013:mdna:89]

[0000866374-20-000003:mdna:87]
[same as prior period, unchanged from 0000866374-19-000013:mdna:90]

[0000866374-20-000003:mdna:88]
The consolidated effective tax rate was 23% and 65% for the three-month and nine-month periods ended December 31, 2019 and (42)% and 28% for the three-month and nine-month periods ended December 31, 2018. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, India, the Netherlands and Israel. The effective tax rate for the three-month period ended December 31, 2019 is significantly higher than the effective tax rate for the three-month period ended December 31, 2018, due to a changing jurisdictional mix of income, and our recognition of approximately $194 million in restructuring charges, impairment of non-core investment, and customer related asset impairments with minimal associated tax benefit for the three-month period ended December 31, 2018. The effective tax rate for the nine-month period ended December 31, 2019 is significantly higher than the effective tax rate for the nine-month period ended December 31, 2018, due to a changing jurisdictional mix of income and the company’s recognition of approximately $155 million in additional restructuring charges, impairment of non-core investments, and customer related asset impairments in the nine-month period ended December 31, 2019 compared to the nine-month period ended December 31, 2018. The charges for both respective periods generate minimal associated tax benefits.

[0000866374-20-000003:mdna:89]
[same as prior period, unchanged from 0000866374-19-000013:mdna:92]

[0000866374-20-000003:mdna:90]
As of December 31, 2019, we had cash and cash equivalents of approximately $1.8 billion and bank and other borrowings of approximately $2.8 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. We also entered into a JPY 33.525 billion term loan due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. In addition, we issued $650 million of 4.875% Notes in fiscal year 2020. The proceeds were used to repay the outstanding balance of our existing 4.625% Notes due February 2020, and the Term Loan due November 2021, resulting in a net debt reduction of $200 million. Refer to note 7 to the condensed consolidated financial statement for details. As of December 31, 2019, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-20-000003:mdna:91]
Cash used in operating activities was $1.7 billion during the nine-month period ended December 31, 2019, primarily driven by cash outflows related to accounts receivable. Cash collections from the deferred purchase price on our ABS sales program, prior to amendment and including collection on the repurchased deferred purchase price receivables, of $2.5 billion were included in cash from investing activities (refer to note 12 to the condensed consolidated financial statements for discussion of the amendment). This was coupled with $39 million of net income for the period, partially offset by $579 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation.

[0000866374-20-000003:mdna:92]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. Net working capital decreased $175 million as of December 31, 2019, from $1.7 billion as of March 31, 2019. This decrease is primarily driven by a $284 million increase in accounts payable, offset by a $154 million increase in net receivables. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended December 31, 2019, decreased to 5.8% from 6.7% of annualized net sales for the quarter ended March 31, 2019. We generally operate in a net working capital targeted range between 6% to 8% of annualized revenue for the quarter.

[0000866374-20-000003:mdna:93]
Cash provided by investing activities was $2.3 billion during the nine-month period ended December 31, 2019. This was primarily driven by $2.5 billion of cash collections on deferred purchase price receivables from our ABS programs during the nine-month period ended December 31, 2019, offset by approximately $274 million of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding IEI and HRS businesses.

[0000866374-20-000003:mdna:94]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, plus cash collections of deferred purchase price receivables, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency (refer to note 12 to the condensed consolidated financial statements for discussion of the amendment of the ABS programs). We also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation. Our adjusted free cash flows for the nine-month period ended December 31, 2019 was $538 million compared to a use of $126 million for the nine-month period ended December 31, 2018. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-20-000003:mdna:95]
|  | Nine-Month Periods Ended |
|  | December 31, 2019 |  | December 31, 2018 |
|  | (In millions) |
| Net cash used in operating activities | (1,699 | ) |  | $ | (2,329 | ) |
| Cash collection of deferred purchase price and other | 2,511 |  |  | 2,708 |  |
| Purchases of property and equipment | (376 | ) |  | (592 | ) |
| Proceeds from the disposition of property and equipment | 102 |  |  | 87 |  |
| Adjusted free cash flow | $ | 538 |  |  | $ | (126 | ) |

[0000866374-20-000003:mdna:96]
Cash used by financing activities was $462 million during the nine-month period ended December 31, 2019, which was primarily driven by $663 million of proceeds, net of discount and premium, received following the issuance of the 2029 Notes, $300 million of proceeds following the execution of our term loan agreement due April 2024 during the first quarter of fiscal year 2020, coupled with $54 million of proceeds from drawdowns from our India term loan facility. For further information, see note 7 to the condensed consolidated financial statements. Partially offsetting the proceeds described above were i) $500 million of cash paid for the repurchase of the outstanding balance of our 4.625% Notes due February 2020, ii) $672 million of cash paid for the repayment of the term loan due November 2021, iii) $91 million of cash paid for the outstanding balance of our short-term bank borrowings facility in India, and iv) $173 million of cash paid for the repurchase of our ordinary shares.

[0000866374-20-000003:mdna:97]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of December 31, 2019, and March 31, 2019, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2019). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-20-000003:mdna:98]
[same as prior period, unchanged from 0000866374-19-000013:mdna:103]

[0000866374-20-000003:mdna:99]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the

[0000866374-20-000003:mdna:100]
program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs amounted to approximately $0.2 billion and $0.6 billion for the three and nine-month periods ended December 31, 2019, respectively, and approximately $0.1 billion and $0.3 billion for the three and nine-month periods ended December 31, 2018, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-20-000003:mdna:101]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to credit import advance facility and revolving sale and repurchase of subordinated note established under the securitization facility, under which there were no borrowings outstanding as of December 31, 2019.

[0000866374-20-000003:mdna:102]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth.

[0000866374-20-000003:mdna:103]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-20-000003:mdna:104]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 20, 2019. During the nine-month period ended December 31, 2019, we paid $173 million to repurchase shares under the current and prior repurchase plans at an average price of $10.66 per share. As of December 31, 2019, shares in the aggregate amount of $402 million were available to be repurchased under the current plan.

[0000866374-20-000003:mdna:105]
[same as prior period, unchanged from 0000866374-19-000013:mdna:111]

[0000866374-20-000003:mdna:106]
[same as prior period, unchanged from 0000866374-19-000013:mdna:112]

[0000866374-20-000003:mdna:107]
During the fiscal year 2020, we entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. In addition, we issued $650 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay the outstanding balance of our existing 4.625% Notes due February 2020, and the Term Loan due November 2021.

[0000866374-20-000003:mdna:108]
[same as prior period, unchanged from 0000866374-19-000013:mdna:114]

[0000866374-20-000003:mdna:109]
[same as prior period, unchanged from 0000866374-19-000013:mdna:115]

[0000866374-20-000003:mdna:110]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs. Effective November 2019, we amended the structure and removed the requirement for the deferred purchase price receivable. Under the New ABS Programs, the entire purchase price of sold receivables are paid in cash and are guaranteed. For further information on the amendment see note 12 to the condensed consolidated financial statements. Prior to November 26, 2019, under the old ABS structure, in addition to cash, we received a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables served as additional credit support to the financial institutions and was recorded at its estimated fair value. As of March 31, 2019, the fair value of our deferred purchase price receivable was approximately $293 million. There are no deferred purchase price receivables outstanding as of December 31, 2019.

[0000866374-20-000003:mdna:111]
As of December 31, 2019, and March 31, 2019, the outstanding balance on receivables sold for cash was $1.2 billion and $1.3 billion, respectively, under our asset-backed securitization programs and accounts receivable factoring program, which are not included in our condensed consolidated balance sheets. For further information, see note 12 to the condensed consolidated financial statements.
