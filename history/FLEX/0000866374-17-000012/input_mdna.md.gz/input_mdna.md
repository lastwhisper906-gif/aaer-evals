# FLEX MD&A — 0000866374-17-000012


## mdna

[0000866374-17-000012:mdna:1]
[same as prior period, unchanged from 0000866374-17-000008:mdna:1]

[0000866374-17-000012:mdna:2]
[same as prior period, unchanged from 0000866374-17-000008:mdna:2]

[0000866374-17-000012:mdna:3]
[same as prior period, unchanged from 0000866374-17-000008:mdna:4]

[0000866374-17-000012:mdna:4]
[same as prior period, unchanged from 0000866374-17-000008:mdna:5]

[0000866374-17-000012:mdna:5]
[same as prior period, unchanged from 0000866374-17-000008:mdna:6]

[0000866374-17-000012:mdna:6]
[same as prior period, unchanged from 0000866374-17-000008:mdna:7]

[0000866374-17-000012:mdna:7]
[same as prior period, unchanged from 0000866374-17-000008:mdna:8]

[0000866374-17-000012:mdna:8]
[same as prior period, unchanged from 0000866374-17-000008:mdna:9]

[0000866374-17-000012:mdna:9]
[same as prior period, unchanged from 0000866374-17-000008:mdna:10]

[0000866374-17-000012:mdna:10]
[same as prior period, unchanged from 0000866374-17-000008:mdna:11]

[0000866374-17-000012:mdna:11]
[same as prior period, unchanged from 0000866374-17-000008:mdna:12]

[0000866374-17-000012:mdna:12]
[same as prior period, unchanged from 0000866374-17-000008:mdna:13]

[0000866374-17-000012:mdna:13]
[same as prior period, unchanged from 0000866374-17-000008:mdna:14]

[0000866374-17-000012:mdna:14]
We are one of the world's largest providers of global supply chain solutions, with revenues of $12.3 billion for the six-month period ended September 29, 2017 and $23.9 billion in fiscal year 2017. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-17-000012:mdna:15]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Net sales: | September 29, 2017 |  | September 30, 2016 |  | September 29, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| China | $ | 1,752,076 |  |  | 28 | % |  | $ | 1,959,064 |  |  | 32 | % |  | $ | 3,496,616 |  |  | 29 | % |  | $ | 3,799,916 |  |  | 32 | % |
| Mexico | 1,078,933 |  |  | 17 | % |  | 952,857 |  |  | 16 | % |  | 2,119,378 |  |  | 17 | % |  | 1,868,202 |  |  | 16 | % |
| U.S. | 740,261 |  |  | 12 | % |  | 708,858 |  |  | 12 | % |  | 1,434,597 |  |  | 12 | % |  | 1,417,268 |  |  | 12 | % |
| Brazil | 642,130 |  |  | 10 | % |  | 417,958 |  |  | 7 | % |  | 1,240,181 |  |  | 10 | % |  | 789,631 |  |  | 7 | % |
| Malaysia | 515,396 |  |  | 8 | % |  | 539,985 |  |  | 9 | % |  | 1,019,968 |  |  | 8 | % |  | 1,112,748 |  |  | 9 | % |
| Other | 1,541,624 |  |  | 25 | % |  | 1,429,803 |  |  | 24 | % |  | 2,967,952 |  |  | 24 | % |  | 2,897,573 |  |  | 24 | % |
|  | $ | 6,270,420 |  |  |  |  |  | $ | 6,008,525 |  |  |  |  |  | $ | 12,278,692 |  |  |  |  |  | $ | 11,885,338 |  |  |  |  |

[0000866374-17-000012:mdna:16]
|  | As of |  | As of |
| Property and equipment, net: | September 29, 2017 |  | March 31, 2017 |
|  | (In thousands) |
| China | $ | 700,524 |  |  | 29 | % |  | $ | 719,972 |  |  | 31 | % |
| Mexico | 596,288 |  |  | 25 | % |  | 525,282 |  |  | 23 | % |
| U.S. | 297,595 |  |  | 12 | % |  | 290,463 |  |  | 13 | % |
| Malaysia | 162,988 |  |  | 7 | % |  | 173,410 |  |  | 7 | % |
| Hungary | 145,613 |  |  | 6 | % |  | 132,527 |  |  | 6 | % |
| Other | 512,566 |  |  | 21 | % |  | 475,372 |  |  | 20 | % |
|  | $ | 2,415,574 |  |  |  |  |  | $ | 2,317,026 |  |  |  |  |

[0000866374-17-000012:mdna:17]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and industrial campuses in

[0000866374-17-000012:mdna:18]
27

[0000866374-17-000012:mdna:19]
low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer electronics and industrial products for leading multinational and regional customers. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-17-000012:mdna:20]
[same as prior period, unchanged from 0000866374-17-000008:mdna:20]

[0000866374-17-000012:mdna:21]
[same as prior period, unchanged from 0000866374-17-000008:mdna:21]

[0000866374-17-000012:mdna:22]
[same as prior period, unchanged from 0000866374-17-000008:mdna:22]

[0000866374-17-000012:mdna:23]
[same as prior period, unchanged from 0000866374-17-000008:mdna:23]

[0000866374-17-000012:mdna:24]
[same as prior period, unchanged from 0000866374-17-000008:mdna:24]

[0000866374-17-000012:mdna:25]
[same as prior period, unchanged from 0000866374-17-000008:mdna:25]

[0000866374-17-000012:mdna:26]
[same as prior period, unchanged from 0000866374-17-000008:mdna:26]

[0000866374-17-000012:mdna:27]
[same as prior period, unchanged from 0000866374-17-000008:mdna:27]

[0000866374-17-000012:mdna:28]
[same as prior period, unchanged from 0000866374-17-000008:mdna:29]

[0000866374-17-000012:mdna:29]
[same as prior period, unchanged from 0000866374-17-000008:mdna:30]

[0000866374-17-000012:mdna:30]
[same as prior period, unchanged from 0000866374-17-000008:mdna:31]

[0000866374-17-000012:mdna:31]
[same as prior period, unchanged from 0000866374-17-000008:mdna:32]

[0000866374-17-000012:mdna:32]
[same as prior period, unchanged from 0000866374-17-000008:mdna:33]

[0000866374-17-000012:mdna:33]
[same as prior period, unchanged from 0000866374-17-000008:mdna:34]

[0000866374-17-000012:mdna:34]
[same as prior period, unchanged from 0000866374-17-000008:mdna:35]

[0000866374-17-000012:mdna:35]
[same as prior period, unchanged from 0000866374-17-000008:mdna:36]

[0000866374-17-000012:mdna:36]
[same as prior period, unchanged from 0000866374-17-000008:mdna:37]

[0000866374-17-000012:mdna:37]
[same as prior period, unchanged from 0000866374-17-000008:mdna:38]

[0000866374-17-000012:mdna:38]
28

[0000866374-17-000012:mdna:39]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |  | September 29, 2017 |  | September 30, 2016 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.7 |  |  | 94.8 |  |  | 93.5 |  |  | 93.9 |  |
| Gross profit | 6.3 |  |  | 5.2 |  |  | 6.5 |  |  | 6.1 |  |
| Selling, general and administrative expenses | 4.4 |  |  | 4.1 |  |  | 4.3 |  |  | 4.1 |  |
| Intangible amortization | 0.3 |  |  | 0.4 |  |  | 0.3 |  |  | 0.4 |  |
| Interest and other, net | 0.4 |  |  | 0.4 |  |  | 0.4 |  |  | 0.4 |  |
| Other charges (income), net | (2.3 | ) |  | 0.1 |  |  | (1.5 | ) |  | 0.1 |  |
| Income before income taxes | 3.5 |  |  | 0.2 |  |  | 3.0 |  |  | 1.1 |  |
| Provision for income taxes | 0.2 |  |  | 0.3 |  |  | 0.3 |  |  | 0.2 |  |
| Net income (loss) | 3.3 | % |  | (0.1 | )% |  | 2.7 | % |  | 0.9 | % |

[0000866374-17-000012:mdna:40]
[same as prior period, unchanged from 0000866374-17-000008:mdna:41]

[0000866374-17-000012:mdna:41]
[same as prior period, unchanged from 0000866374-17-000008:mdna:42]

[0000866374-17-000012:mdna:42]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Segments: | September 29, 2017 |  | September 30, 2016 |  | September 29, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| Communications & Enterprise Compute | $ | 1,901,057 |  |  | 30 | % |  | $ | 2,101,922 |  |  | 35 | % |  | $ | 3,874,390 |  |  | 31 | % |  | $ | 4,297,912 |  |  | 36 | % |
| Consumer Technologies Group | 1,755,143 |  |  | 28 | % |  | 1,664,736 |  |  | 28 | % |  | 3,267,112 |  |  | 27 | % |  | 2,978,518 |  |  | 25 | % |
| Industrial & Emerging Industries | 1,454,539 |  |  | 23 | % |  | 1,242,722 |  |  | 21 | % |  | 2,845,138 |  |  | 23 | % |  | 2,531,737 |  |  | 21 | % |
| High Reliability Solutions | 1,159,681 |  |  | 19 | % |  | 999,145 |  |  | 16 | % |  | 2,292,052 |  |  | 19 | % |  | 2,077,171 |  |  | 18 | % |
|  | $ | 6,270,420 |  |  |  |  |  | $ | 6,008,525 |  |  |  |  |  | $ | 12,278,692 |  |  |  |  |  | $ | 11,885,338 |  |  |  |  |

[0000866374-17-000012:mdna:43]
Net sales during the three-month period ended September 29, 2017 totaled $6.3 billion, representing an increase of approximately $0.3 billion, or 4% from $6.0 billion during the three-month period ended September 30, 2016. The overall increase in sales was driven by increases in three of our segments offset with a decline in sales in our CEC segment. Our IEI segment increased $212 million, mainly driven by our industrial, home and lifestyle business in addition to growth in our solar energy business. Our HRS segment increased $161 million from higher sales in our automotive business. Our CTG segment increased $90 million, primarily because of stronger sales in our connected living and mobile devices businesses, offset by a decrease in gaming. Sales in our CEC segment declined $201 million, largely attributable to lower sales within our telecom and networking business, offset by increased sales of our cloud and data center business. Net sales increased $396 million to $2.5 billion in the Americas and $36 million to $1.1 billion in Europe, offset by a decrease of $170 million to $2.7 billion in Asia.

[0000866374-17-000012:mdna:44]
Net sales during the six-month period ended September 29, 2017 totaled $12.3 billion, representing an increase of approximately $0.4 billion, or 3% from $11.9 billion during the six-month period ended September 30, 2016. The overall increase in net sales during the six-month period ended September 29, 2017, was driven by increases of $313 million in our IEI segment, $289 million in our CTG segment, and $215 million in our HRS segment due to the same drivers as described above. These increases were offset by a decrease of $424 million in our CEC segment as a result of lower sales within our telecom and legacy server & storage business, offset by increased sales of our cloud and data center business. Net sales increased $747 million to $4.8 billion in the Americas, offset by decreases of $276 million to $5.4 billion in Asia and $78 million to $2.1 billion in Europe.

[0000866374-17-000012:mdna:45]
[same as prior period, unchanged from 0000866374-17-000008:mdna:83]

[0000866374-17-000012:mdna:46]
Our ten largest customers, during the three and six-month periods ended September 29, 2017 accounted for approximately 42% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and six-month periods ended September 29, 2017.

[0000866374-17-000012:mdna:47]
Our ten largest customers, during the three and six-month periods ended September 30, 2016 accounted for approximately 42% and 43% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and six-month periods ended September 30, 2016.

[0000866374-17-000012:mdna:48]
[same as prior period, unchanged from 0000866374-17-000008:mdna:46]

[0000866374-17-000012:mdna:49]
[same as prior period, unchanged from 0000866374-17-000008:mdna:47]

[0000866374-17-000012:mdna:50]
Gross profit during the three-month period ended September 29, 2017 increased $80 million to $393 million, or 6.3% of net sales, from $314 million, or 5.2% of net sales, during the three-month period ended September 30, 2016. Gross profit during the six-month period ended September 29, 2017 increased $81 million to $800 million, or 6.5% of net sales, from $720 million, or 6.1% of net sales, during the six-month period ended September 30, 2016. The increase in gross profit for both the three and six-month periods ended September 29, 2017 is primarily the result of $93 million of charges recognized during the second quarter of fiscal year 2017 related to the significant decline in prices for solar modules and slowdown in demand, which negatively impacted our prior year gross profits. This was partially offset by an elevated level of costs associated with material management, labor inefficiencies and capacity refinements as we transition through a production curve with a strategic customer in our CTG segment.

[0000866374-17-000012:mdna:51]
Gross margins improved 110 basis points and 40 basis points in the three and six-month periods ended September 29, 2017, respectively, compared to that of the three and six-month periods ended September 30, 2016 primarily as a result of the various factors described above.

[0000866374-17-000012:mdna:52]
[same as prior period, unchanged from 0000866374-17-000008:mdna:49]

[0000866374-17-000012:mdna:53]
An operating segment’s performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, other charges (income), net and interest and other, net. A portion of depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-17-000012:mdna:54]
30

[0000866374-17-000012:mdna:55]
[same as prior period, unchanged from 0000866374-17-000008:mdna:51]

[0000866374-17-000012:mdna:56]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |  | September 29, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 42,733 |  |  | 2.2 | % |  | $ | 52,453 |  |  | 2.5 | % |  | $ | 91,335 |  |  | 2.4 | % |  | $ | 114,352 |  |  | 2.7 | % |
| Consumer Technologies Group | 30,722 |  |  | 1.8 | % |  | 55,314 |  |  | 3.3 | % |  | 48,726 |  |  | 1.5 | % |  | 79,948 |  |  | 2.7 | % |
| Industrial & Emerging Industries | 50,945 |  |  | 3.5 | % |  | 37,363 |  |  | 3.0 | % |  | 106,322 |  |  | 3.7 | % |  | 87,340 |  |  | 3.4 | % |
| High Reliability Solutions | 92,364 |  |  | 8.0 | % |  | 78,707 |  |  | 7.9 | % |  | 182,576 |  |  | 8.0 | % |  | 167,243 |  |  | 8.1 | % |
| Corporate and Other | (28,438 | ) |  |  |  | (26,902 | ) |  |  |  | (62,716 | ) |  |  |  | (61,702 | ) |  |  |
| Total segment income | 188,326 |  |  | 3.0 | % |  | 196,935 |  |  | 3.3 | % |  | 366,243 |  |  | 3.0 | % |  | 387,181 |  |  | 3.3 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 16,376 |  |  |  |  | 21,986 |  |  |  |  | 36,277 |  |  |  |  | 43,584 |  |  |  |
| Stock-based compensation | 20,464 |  |  |  |  | 22,733 |  |  |  |  | 42,260 |  |  |  |  | 46,530 |  |  |  |
| Distressed customers assets impairment (1) | 4,753 |  |  |  |  | 92,915 |  |  |  |  | 4,753 |  |  |  |  | 92,915 |  |  |  |
| Contingencies and other (2) | 43,933 |  |  |  |  | 11,539 |  |  |  |  | 43,933 |  |  |  |  | 11,539 |  |  |  |
| Other charges (income), net | (143,167 | ) |  |  |  | 8,388 |  |  |  |  | (179,332 | ) |  |  |  | 11,917 |  |  |  |
| Interest and other, net | 27,554 |  |  |  |  | 24,632 |  |  |  |  | 54,430 |  |  |  |  | 49,031 |  |  |  |
| Income before income taxes | $ | 218,413 |  |  |  |  | $ | 14,742 |  |  |  |  | $ | 363,922 |  |  |  |  | $ | 131,665 |  |  |  |

[0000866374-17-000012:mdna:57]
(1)  During the fourth quarter of fiscal year 2016, the Company accepted return of previously shipped inventory from a former customer, SunEdison, Inc. ("SunEdison"), of approximately $90 million. On April 21, 2016, SunEdison filed a petition for reorganization under bankruptcy law, and as a result, the Company recognized a bad debt reserve of $61 million as of March 31, 2016, associated with its outstanding SunEdison receivables.

[0000866374-17-000012:mdna:58]
During the three-month period ended September 30, 2016, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand as of September 30, 2016 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market in the three and six-month periods ended September 30, 2016. The Company also recognized a $16.0 million impairment charge for solar module equipment and $16.9 million primarily related to negative margin sales and other associated solar panel direct costs incurred during the same periods. The total charge of $92.9 million is included in cost of sales for the three and six-month periods ended September 30, 2016 but is excluded from segment results above.

[0000866374-17-000012:mdna:59]
(2)  During the second quarter of fiscal year 2018, the Company incurred charges in connection with the matters described in note 13 to the condensed consolidated financial statements for certain loss contingencies where it believes that losses are probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted one of our China facilities.

[0000866374-17-000012:mdna:60]
During fiscal year 2017, the Company initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its Sketch-to-Scaletm initiatives. As part of this plan, approximately $11.5 million was recognized in the quarter ended September 30, 2016. The plan was finalized and completed during fiscal year 2017.

[0000866374-17-000012:mdna:61]
CEC segment margin decreased 30 basis points, to 2.2% for the three-month period ended September 29, 2017, from 2.5% during the three-month period ended September 30, 2016. CEC segment margin decreased 30 basis points, to 2.4% for the six-month period ended September 29, 2017, from 2.7% for the six-month period ended September 30, 2016. The decreases in CEC's margins for both the three and six-month periods ended September 29, 2017 were due to lower capacity utilization

[0000866374-17-000012:mdna:62]
31

[0000866374-17-000012:mdna:63]
causing reduced overhead absorption, coupled with modest increased investments to expand its converged enterprise and cloud capabilities.

[0000866374-17-000012:mdna:64]
CTG segment margin decreased 150 basis point to 1.8% for the three-month period ended September 29, 2017, from 3.3% during the three-month period ended September 30, 2016. CTG segment margin decreased 120 basis points, to 1.5% for the six-month period ended September 29, 2017 from 2.7% for the six-month period ended September 30, 2016. The decrease in CTG's margins for both the three and six-month periods ended September 29, 2017 reflected the negative impacts from the elevated levels of costs associated with material management, labor inefficiencies and capacity refinements as we transition through a production curve with a strategic customer.

[0000866374-17-000012:mdna:65]
IEI segment margin increased 50 basis points, to 3.5% for the three-month period ended September 29, 2017, from 3.0% during the three-month period ended September 30, 2016. IEI segment margin increased 30 basis points, to 3.7% for the six-month period ended September 29, 2017, from 3.4% for the six-month period ended September 30, 2016. The increases in IEI's margins for both the three and six-month periods ended September 29, 2017 are primarily due to revenue increases resulting in improved absorption of costs as a result of ramping multiple new programs in our industrial, home and lifestyle and energy businesses. This was partially offset by high levels of start-up costs on several new customer programs as we prepositioned resources in advance of the significant underlying ramps, as well as an impact from the underlying mix of business.

[0000866374-17-000012:mdna:66]
HRS segment margin increased 10 basis points, to 8.0% for the three-month period ended September 29, 2017, from 7.9% during the three-month period ended September 30, 2016 primarily as a result of new customers and programs ramp up coupled with solid operational management. HRS segment margin decreased 10 basis points, to 8.0% for the six-month period ended September 29, 2017, from 8.1% for the six-month period ended September 30, 2016 as a result of an elevated level of investments during the period as part of our Sketch-to-Scaletm initiatives and relative revenue mix.

[0000866374-17-000012:mdna:67]
[same as prior period, unchanged from 0000866374-17-000008:mdna:57]

[0000866374-17-000012:mdna:68]
Selling, general and administrative expenses (“SG&A”) was $274 million, or 4.4% of net sales, during the three-month period ended September 29, 2017, increasing $30 million from $244 million, or 4.1% of net sales, during the three-month period ended September 30, 2016. SG&A was $525 million, or 4.3% of net sales, during the six-month period ended September 29, 2017, increasing $42 million from $483 million, or 4.1% of net sales, during the six-month period ended September 30, 2016. The increase in SG&A in dollars and as a percentage of net sales was primarily due to incremental costs associated with our continued expansion of our design and engineering resources and innovation system to support our increased Sketch-to-Scaletm initiatives and the recognition of certain contingencies that are probable and estimable of payout combined with incremental costs from our acquisitions.

[0000866374-17-000012:mdna:69]
[same as prior period, unchanged from 0000866374-17-000008:mdna:59]

[0000866374-17-000012:mdna:70]
Amortization of intangible assets marginally declined during the three-month period ended September 29, 2017 to $16 million from $22 million for the three-month period ended September 30, 2016, and decreased by $7 million during the six-month period ended September 29, 2017 to $36 million from $44 million during the six-month period ended September 30, 2016, due to certain intangibles now being fully amortized.

[0000866374-17-000012:mdna:71]
[same as prior period, unchanged from 0000866374-17-000008:mdna:61]

[0000866374-17-000012:mdna:72]
Interest and other, net was $28 million during the three-month period ended September 29, 2017 compared to $25 million during the three-month period ended September 30, 2016, and $54 million during the six-month period ended September 29, 2017 compared to $49 million during the six-month period ended September 30, 2016. The increase in interest and other, net was primarily a result of higher interest expense due to higher interest rates and higher average borrowing level.

[0000866374-17-000012:mdna:73]
[same as prior period, unchanged from 0000866374-17-000008:mdna:63]

[0000866374-17-000012:mdna:74]
Other charges (income), net was $143 million of income during the three-month period ended September 29, 2017 compared to $8 million of charges during the three-month period ended September 30, 2016. Other charges (income), net was $179 million of income during the six-month period ended September 29, 2017 compared to $12 million of expense during the six-month period ended September 30, 2016. The increases are primarily due to a $152 million non-cash gain as a result of the deconsolidation of our investment in Elementum.  This is coupled with a $39 million gain recognized for the disposition of Wink during the first quarter of fiscal year 2018. Refer to note 5 and note 2 of the condensed consolidated financial statements for details of the deconsolidation and the disposition of Wink, respectively.

[0000866374-17-000012:mdna:75]
32

[0000866374-17-000012:mdna:76]
[same as prior period, unchanged from 0000866374-17-000008:mdna:65]

[0000866374-17-000012:mdna:77]
[same as prior period, unchanged from 0000866374-17-000008:mdna:66]

[0000866374-17-000012:mdna:78]
[same as prior period, unchanged from 0000866374-17-000008:mdna:67]

[0000866374-17-000012:mdna:79]
The consolidated effective tax rate was 6.1% and 9.4% for the three and six-month periods ended September 29, 2017, and 117.0% and 21.6% for the three and six-month periods ended September 30, 2016. The effective rate varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. The effective tax rate for the three-month and six-month periods ended September 29, 2017 is significant lower than the effective tax rate for the three-month and six-month periods ended September 30, 2016, respectively, primarily due to the charges related to the solar panel inventory impairment and business exit and the rationalization costs incurred during the three-month period ended September 30, 2016 that were in jurisdictions which resulted in minimal tax benefit.

[0000866374-17-000012:mdna:80]
[same as prior period, unchanged from 0000866374-17-000008:mdna:69]

[0000866374-17-000012:mdna:81]
As of September 29, 2017, we had cash and cash equivalents of approximately $1.4 billion and bank and other borrowings of approximately $3.0 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. As of September 29, 2017, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0000866374-17-000012:mdna:82]
Cash provided by operating activities was $281 million during the six-month period ended September 29, 2017. This resulted from $330 million of net income for the period plus adjustments for $282 million, net, non-cash charges such as depreciation, amortization, and stock-based compensation. These were partially offset by a $152 million gain from the deconsolidation of Elementum, and a $39 million gain on sale of Wink, which are both included in the determination of net income. The foregoing was further offset by a $140 million net increase in our operating assets and liabilities as we ramp into third quarter production.

[0000866374-17-000012:mdna:83]
[same as prior period, unchanged from 0000866374-17-000008:mdna:72]

[0000866374-17-000012:mdna:84]
|  | Three-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |
| Days in trade accounts receivable | 44 days |  | 40 days |
| Days in inventory | 57 days |  | 58 days |
| Days in accounts payable | 78 days |  | 72 days |
| Cash conversion cycle | 23 days |  | 26 days |

[0000866374-17-000012:mdna:85]
Days in trade accounts receivable was calculated as average accounts receivable, net of allowance for doubtful accounts, for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended September 29, 2017, days in trade accounts receivable increased by 4 days compared to the three-month period ended September 30, 2016 due to an increase in accounts receivable not offset by a proportionate increase in sales. Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $487 million and $462 million for the quarters ended September 29, 2017 and September 30, 2016, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 10 to the condensed consolidated financial statements.

[0000866374-17-000012:mdna:86]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in inventory decreased by 1 day during the three-month period ended

[0000866374-17-000012:mdna:87]
September 29, 2017, compared to the three-month period ended September 30, 2016, primarily driven by an increase of cost of sales.

[0000866374-17-000012:mdna:88]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable increased by 6 days during the three-month period ended September 29, 2017, compared to the three-month period ended September 30, 2016, primarily due to timing of purchases driving an increase in accounts payable not offset by a proportionate increase in cost of sales.

[0000866374-17-000012:mdna:89]
Our cash conversion cycle was calculated as the sum of days of inventory and days of account receivables outstanding less days payable outstanding. Our cash conversion cycle decreased by 3 days during the three-month period ended September 29, 2017, compared to the three-month period ended September 30, 2016, due to the factors for each of the components in the calculation discussed above.

[0000866374-17-000012:mdna:90]
Cash used in investing activities amounted to $618 million during the six-month period ended September 29, 2017. During the six-month period ended September 29, 2017, we paid $214 million for the acquisition of AGM, net of cash acquired, invested $228 million for property and equipment to expand capabilities and capacity in support of our automotive and medical businesses, and paid a deposit of $59 million to a customer for an acquisition of certain assets that closed September 30, 2017. In addition, other investing activities includes $73 million of cash outflow resulting from the deconsolidation of Elementum, and $40 million of payments for investments, net of cash received, in non-core businesses.

[0000866374-17-000012:mdna:91]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the six-month period ended September 29, 2017 was $53 million compared to $264 million for the six-month period ended September 30, 2016. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-17-000012:mdna:92]
|  | Six-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 280,805 |  |  | $ | 543,552 |  |
| Purchases of property and equipment | (264,030 | ) |  | (305,936 | ) |
| Proceeds from the disposition of property and equipment | 36,123 |  |  | 26,561 |  |
| Free cash flow | $ | 52,898 |  |  | $ | 264,177 |  |

[0000866374-17-000012:mdna:93]
Cash used in financing activities was $110 million during the six-month period ended September 29, 2017, which was primarily for the repurchase of our ordinary shares in the amount of $145 million, offset by $59 million received from third party investors, during our first quarter, in exchange for an additional noncontrolling equity interest in Elementum.

[0000866374-17-000012:mdna:94]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of September 29, 2017 and March 31, 2017, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.2 billion as of March 31, 2017). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of

[0000866374-17-000012:mdna:95]
funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-17-000012:mdna:96]
[same as prior period, unchanged from 0000866374-17-000008:mdna:85]

[0000866374-17-000012:mdna:97]
[same as prior period, unchanged from 0000866374-17-000008:mdna:86]

[0000866374-17-000012:mdna:98]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-17-000012:mdna:99]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 15, 2017. During the six-month period ended September 29, 2017, we paid $145 million to repurchase shares under the current and prior repurchase plans at an average price of $16.37 per share. As of September 29, 2017, shares in the aggregate amount of $445 million were available to be repurchased under the current plan.

[0000866374-17-000012:mdna:100]
[same as prior period, unchanged from 0000866374-17-000008:mdna:89]

[0000866374-17-000012:mdna:101]
[same as prior period, unchanged from 0000866374-17-000008:mdna:90]

[0000866374-17-000012:mdna:102]
[same as prior period, unchanged from 0000866374-17-000008:mdna:91]

[0000866374-17-000012:mdna:103]
[same as prior period, unchanged from 0000866374-17-000008:mdna:92]

[0000866374-17-000012:mdna:104]
[same as prior period, unchanged from 0000866374-17-000008:mdna:93]

[0000866374-17-000012:mdna:105]
35

[0000866374-17-000012:mdna:106]
[same as prior period, unchanged from 0000866374-17-000008:mdna:94]

[0000866374-17-000012:mdna:107]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of September 29, 2017 and March 31, 2017, the fair values of our deferred purchase price receivable were approximately $487 million and $507 million, respectively. As of September 29, 2017 and March 31, 2017, the outstanding balance on receivables sold for cash was $1.2 billion under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information, see note 10 to the condensed consolidated financial statements.
