# FLEX notes — 0000866374-17-000012


## flex:InterestAndOtherNetTextBlock

[0000866374-17-000012:notes:1]
[same as prior period, unchanged from 0000866374-17-000008:notes:1]

[0000866374-17-000012:notes:2]
During the three-month and six-month periods ended September 29, 2017, the Company recognized interest expense of $29.6 million and $58.6 million, respectively, on its debt obligations outstanding during the periods. During the three-month and six-month periods ended September 30, 2016, the Company recognized interest expense of $26.5 million and $53.4 million, respectively.


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0000866374-17-000012:notes:3]
[same as prior period, unchanged from 0000866374-17-000008:notes:3]

[0000866374-17-000012:notes:4]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |  | September 29, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| Beginning balance | $ | 547,492 |  |  | $ | 460,334 |  |  | $ | 506,522 |  |  | $ | 501,097 |  |
| Transfers of receivables | 770,101 |  |  | 760,540 |  |  | 1,617,105 |  |  | 1,522,724 |  |
| Collections | (830,407 | ) |  | (759,330 | ) |  | (1,636,441 | ) |  | (1,562,277 | ) |
| Ending balance | $ | 487,186 |  |  | $ | 461,544 |  |  | $ | 487,186 |  |  | $ | 461,544 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-17-000012:notes:5]
[same as prior period, unchanged from 0000866374-17-000008:notes:5]

[0000866374-17-000012:notes:6]
[same as prior period, unchanged from 0000866374-17-000008:notes:6]

[0000866374-17-000012:notes:7]
[same as prior period, unchanged from 0000866374-17-000008:notes:7]

[0000866374-17-000012:notes:8]
[same as prior period, unchanged from 0000866374-17-000008:notes:8]

[0000866374-17-000012:notes:9]
|  | Purchase Consideration |  | Net Tangible Assets Acquired |  | Purchased Intangible Assets |  | Goodwill |
| AGM | $ | 213,718 |  |  | $ | 56,438 |  |  | $ | 82,000 |  |  | $ | 75,280 |  |

[0000866374-17-000012:notes:10]
The intangible assets of $82.0 million is comprised solely of customer relationships of AGM, and are amortized over a weighted-average estimated useful life of 10 years.

[0000866374-17-000012:notes:11]
[same as prior period, unchanged from 0000866374-17-000008:notes:10]

[0000866374-17-000012:notes:12]
The results of operations of the AGM acquisition were included in the Company’s condensed consolidated financial results beginning on the date of acquisition, and the total amount of net income and revenue were immaterial to the Company's condensed consolidated financial results for the three-month and six-month periods ended September 29, 2017. Pro-forma results of operations have not been presented because the effects were not material to the Company’s condensed consolidated financial results for all periods presented.

[0000866374-17-000012:notes:13]
During the quarter ended September 29, 2017, the Company paid a deposit of $59.0 million for the acquisition of certain assets and related operations to a customer. The acquisition closed on September 30, 2017. As of September 29, 2017, the deposit is included in other current assets on the consolidated balance sheet and is reflected as a payment for businesses acquired in the consolidated statement of cash flows for the six-month period then ended. The acquisition is included in the CEC segment and will not be significant to the consolidated financial position, result of operations and cash flows of the Company.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-17-000012:notes:14]
COMMITMENTS AND CONTINGENCIES

[0000866374-17-000012:notes:15]
Litigation and other legal matters

[0000866374-17-000012:notes:16]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The Company does not believe that the amounts accrued are material.  Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented.  Any such excess could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-17-000012:notes:17]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible loss. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-17-000012:notes:18]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 291 million Brazilian reals (approximately USD $91 million based on the exchange rate as of September 29, 2017). The assessments are in various stages of the review process at the administrative level. The Company has meritorious defenses and plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-17-000012:notes:19]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-17-000012:notes:20]
[same as prior period, unchanged from 0000866374-17-000008:notes:12]

[0000866374-17-000012:notes:21]
[same as prior period, unchanged from 0000866374-17-000008:notes:13]

[0000866374-17-000012:notes:22]
|  | Three-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (34,595 | ) |  | $ | (84,881 | ) |  | $ | (119,476 | ) |  | $ | (40,174 | ) |  | $ | (84,532 | ) |  | $ | (124,706 | ) |
| Other comprehensive gain (loss) before reclassifications | (3,865 | ) |  | 9,478 |  |  | 5,613 |  |  | (1,169 | ) |  | 4,213 |  |  | 3,044 |  |
| Net gains reclassified from accumulated other comprehensive loss | (10,010 | ) |  | — |  |  | (10,010 | ) |  | (890 | ) |  | — |  |  | (890 | ) |
| Net current-period other comprehensive gain (loss) | (13,875 | ) |  | 9,478 |  |  | (4,397 | ) |  | (2,059 | ) |  | 4,213 |  |  | 2,154 |  |
| Ending balance | $ | (48,470 | ) |  | $ | (75,403 | ) |  | $ | (123,873 | ) |  | $ | (42,233 | ) |  | $ | (80,319 | ) |  | $ | (122,552 | ) |

[0000866374-17-000012:notes:23]
|  | Six-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain (loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |  | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |
| Other comprehensive gain (loss) before reclassifications | (845 | ) |  | 20,314 |  |  | 19,469 |  |  | 324 |  |  | 14,299 |  |  | 14,623 |  |
| Net gains reclassified from accumulated other comprehensive loss | (15,199 | ) |  | — |  |  | (15,199 | ) |  | (1,035 | ) |  | (225 | ) |  | (1,260 | ) |
| Net current-period other comprehensive gain (loss) | (16,044 | ) |  | 20,314 |  |  | 4,270 |  |  | (711 | ) |  | 14,074 |  |  | 13,363 |  |
| Ending balance | $ | (48,470 | ) |  | $ | (75,403 | ) |  | $ | (123,873 | ) |  | $ | (42,233 | ) |  | $ | (80,319 | ) |  | $ | (122,552 | ) |

[0000866374-17-000012:notes:24]
Substantially all unrealized gains relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month and six-month periods ended September 29, 2017 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:ConsolidationPolicyTextBlock

[0000866374-17-000012:notes:25]
[same as prior period, unchanged from 0000866374-17-000008:notes:16]

[0000866374-17-000012:notes:26]
[same as prior period, unchanged from 0000866374-17-000008:notes:17]

[0000866374-17-000012:notes:27]
[same as prior period, unchanged from 0000866374-17-000008:notes:18]

[0000866374-17-000012:notes:28]
[same as prior period, unchanged from 0000866374-17-000008:notes:19]

[0000866374-17-000012:notes:29]
[same as prior period, unchanged from 0000866374-17-000008:notes:20]

[0000866374-17-000012:notes:30]
[same as prior period, unchanged from 0000866374-17-000008:notes:21]

[0000866374-17-000012:notes:31]
[same as prior period, unchanged from 0000866374-17-000008:notes:22]


## us-gaap:DebtDisclosureTextBlock

[0000866374-17-000012:notes:32]
BANK BORROWINGS AND LONG TERM DEBT

[0000866374-17-000012:notes:33]
Bank borrowings and long-term debt are as follows:

[0000866374-17-000012:notes:34]
|  | As of September 29, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 496,219 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,180 |  |  | 595,979 |  |
| Other | 179,101 |  |  | 169,671 |  |
| Debt issuance costs | (15,379 | ) |  | (16,007 | ) |
| Total | $ | 2,956,121 |  |  | $ | 2,952,143 |  |

[0000866374-17-000012:notes:35]
The weighted-average interest rates for the Company’s long-term debt were 3.5% as of September 29, 2017 and March 31, 2017, respectively.

[0000866374-17-000012:notes:36]
On June 30, 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature on March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualified as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the term of the 2022 Credit Facility.

[0000866374-17-000012:notes:37]
Borrowings under the 2022 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate that would be calculated as of each day in respect of a proposed LIBOR loan with a one-month interest period, plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 1.875% per annum, based on the Company’s credit ratings.

[0000866374-17-000012:notes:38]
The 2022 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of September 29, 2017, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.

[0000866374-17-000012:notes:39]
The Company has three tranches of Notes, the 4.625% Notes due 2020, the 5.000% Notes due 2023 and the 4.75% Notes due 2025. These Notes are senior unsecured obligations, and prior to June 30, 2017, were guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). Upon the termination of the $2.1 billion credit facility, all guarantor subsidiaries were released from their guarantees under each indenture for each Note. As a result, the Company will no longer be providing supplemental guarantor and non-guarantor condensed consolidating financial statements.

[0000866374-17-000012:notes:40]
Repayment of the Company’s long term debt outstanding as of September 29, 2017 is as follows:

[0000866374-17-000012:notes:41]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 (1) | $ | 26,720 |  |
| 2019 | 44,080 |  |
| 2020 | 542,846 |  |
| 2021 | 111,784 |  |
| 2022 | 806,973 |  |
| Thereafter | 1,439,097 |  |
| Total | $ | 2,971,500 |  |

[0000866374-17-000012:notes:42]
_________________________________________________________

[0000866374-17-000012:notes:43]
| (1) | Represents scheduled repayment for the remaining six-month period ending March 31, 2018. |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-17-000012:notes:44]
[same as prior period, unchanged from 0000866374-17-000008:notes:35]

[0000866374-17-000012:notes:45]
[same as prior period, unchanged from 0000866374-17-000008:notes:36]

[0000866374-17-000012:notes:46]
The Company enters into forward contracts and foreign currency swap contracts primarily to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions. The Company hedges committed exposures and does not engage in speculative transactions. As of September 29, 2017, the aggregate notional amount of the Company’s outstanding foreign currency contracts was $7.8 billion as summarized below:

[0000866374-17-000012:notes:47]
|  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |
| CNY | 1,966,000 |  |  | — |  |  | $ | 295,973 |  |  | $ | — |  |
| EUR | 27,750 |  |  | 104,595 |  |  | 32,555 |  |  | 121,947 |  |
| HUF | 18,773,250 |  |  | — |  |  | 70,800 |  |  | — |  |
| INR | 1,577,172 |  |  | — |  |  | 24,000 |  |  | — |  |
| MXN | 2,906,280 |  |  | — |  |  | 160,501 |  |  | — |  |
| MYR | 134,500 |  |  | 51,000 |  |  | 32,088 |  |  | 12,167 |  |
| RON | 104,130 |  |  | — |  |  | 26,573 |  |  | — |  |
| SGD | 31,300 |  |  | — |  |  | 23,033 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 45,734 |  |  | 5,206 |  |
|  |  |  |  |  |  |  | 711,257 |  |  | 139,320 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |
| BRL | — |  |  | 706,000 |  |  | — |  |  | 221,407 |  |
| CAD | 233,429 |  |  | 246,916 |  |  | 188,706 |  |  | 199,609 |  |
| CHF | 13,160 |  |  | 31,378 |  |  | 13,502 |  |  | 32,192 |  |
| CNY | 1,554,257 |  |  | — |  |  | 234,000 |  |  | — |  |
| DKK | 187,600 |  |  | 158,800 |  |  | 29,576 |  |  | 25,036 |  |
| EUR | 1,926,154 |  |  | 2,309,322 |  |  | 2,261,811 |  |  | 2,713,000 |  |
| GBP | 34,051 |  |  | 63,058 |  |  | 45,574 |  |  | 84,125 |  |
| HUF | 18,465,506 |  |  | 20,671,489 |  |  | 69,639 |  |  | 77,959 |  |
| ILS | 162,700 |  |  | 97,800 |  |  | 45,932 |  |  | 27,610 |  |
| INR | 4,090,000 |  |  | 277,061 |  |  | 62,243 |  |  | 4,200 |  |
| MXN | 2,968,175 |  |  | 1,906,930 |  |  | 163,920 |  |  | 105,312 |  |
| MYR | 387,400 |  |  | 56,450 |  |  | 92,423 |  |  | 13,467 |  |
| SEK | 173,247 |  |  | 263,957 |  |  | 21,487 |  |  | 32,355 |  |
| Other | N/A |  |  | N/A |  |  | 93,599 |  |  | 59,170 |  |
|  |  |  |  |  |  |  | 3,322,412 |  |  | 3,595,442 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  | $ | 4,033,669 |  |  | $ | 3,734,762 |  |

[0000866374-17-000012:notes:48]
As of September 29, 2017, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of September 29, 2017 and March 31, 2017, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses were $2.2 million as of September 29, 2017, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0000866374-17-000012:notes:49]
[same as prior period, unchanged from 0000866374-17-000008:notes:40]

[0000866374-17-000012:notes:50]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 29, 2017 |  | March 31, 2017 |  | Balance SheetLocation |  | September 29, 2017 |  | March 31, 2017 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 8,422 |  |  | $ | 11,936 |  |  | Other current liabilities |  | $ | 7,691 |  |  | $ | 1,814 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 28,151 |  |  | $ | 10,086 |  |  | Other current liabilities |  | $ | 25,777 |  |  | $ | 9,928 |  |

[0000866374-17-000012:notes:51]
[same as prior period, unchanged from 0000866374-17-000008:notes:42]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-17-000012:notes:52]
[same as prior period, unchanged from 0000866374-17-000008:notes:43]

[0000866374-17-000012:notes:53]
Historically, the Company's primary plan used for granting equity compensation awards was the 2010 Equity Incentive Plan (the "2010 Plan"). Effective August 15, 2017, awards are granted under the Company's 2017 Equity Incentive Plan (the "2017 Plan"), which was approved by the Company's shareholders at the 2017 Annual General Meeting of Shareholders. For further discussion on this 2017 Plan, refer to the Company's Proxy Statement, which was filed with the Securities and Exchange Commission on July 5, 2017.

[0000866374-17-000012:notes:54]
[same as prior period, unchanged from 0000866374-17-000008:notes:45]

[0000866374-17-000012:notes:55]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |  | September 29, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| Cost of sales | $ | 4,985 |  |  | $ | 2,636 |  |  | $ | 8,304 |  |  | $ | 5,069 |  |
| Selling, general and administrative expenses | 15,479 |  |  | 20,097 |  |  | 33,956 |  |  | 41,461 |  |
| Total share-based compensation expense | $ | 20,464 |  |  | $ | 22,733 |  |  | $ | 42,260 |  |  | $ | 46,530 |  |

[0000866374-17-000012:notes:56]
Total unrecognized compensation expense related to share options under all plans was $6.6 million, and will be recognized over a weighted-average remaining vesting period of 1.6 years. As of September 29, 2017, the number of options outstanding and exercisable under all plans was 1.7 million and 0.6 million, respectively, at a weighted-average exercise price of $3.57 per share and $4.33 per share, respectively.

[0000866374-17-000012:notes:57]
During the six-month period ended September 29, 2017, the Company granted 5.0 million unvested share bonus awards. Of this amount, approximately 4.2 million unvested share bonus awards have an average grant date price of $16.38 per share and vest over four years. Further, approximately 0.6 million of these unvested shares represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $20.25 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 1.2 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met. No additional share options under the immaterial plans were granted by the Company during the six-month period ended September 29, 2017.

[0000866374-17-000012:notes:58]
As of September 29, 2017, approximately 16.3 million unvested share bonus awards under all plans were outstanding, of which vesting for a targeted amount of 2.1 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 4.2 million based on the achievement levels of the respective conditions. During the six-month period ended September 29, 2017, 1.4 million shares vested in connection with the share bonus awards with market conditions granted in fiscal year 2015.

[0000866374-17-000012:notes:59]
As of September 29, 2017, total unrecognized compensation expense related to unvested share bonus awards under all plans was approximately $176.3 million, and will be recognized over a weighted-average remaining vesting period of 2.8 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-17-000012:notes:60]
[same as prior period, unchanged from 0000866374-17-000008:notes:51]

[0000866374-17-000012:notes:61]
[same as prior period, unchanged from 0000866374-17-000008:notes:52]

[0000866374-17-000012:notes:62]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |  | September 29, 2017 |  | September 30, 2016 |
|  | (In thousands, except per share amounts) |
| Net income (loss) | $ | 205,086 |  |  | $ | (2,508 | ) |  | $ | 329,796 |  |  | $ | 103,221 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 531,313 |  |  | 544,055 |  |  | 530,790 |  |  | 544,353 |  |
| Basic earnings (losses) per share | $ | 0.39 |  |  | $ | 0.00 |  |  | $ | 0.62 |  |  | $ | 0.19 |  |
| Diluted earnings (losses) per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 205,086 |  |  | $ | (2,508 | ) |  | $ | 329,796 |  |  | $ | 103,221 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 531,313 |  |  | 544,055 |  |  | 530,790 |  |  | 544,353 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) | 4,706 |  |  | — |  |  | 5,521 |  |  | 5,581 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 536,019 |  |  | 544,055 |  |  | 536,311 |  |  | 549,934 |  |
| Diluted earnings (losses) per share | $ | 0.38 |  |  | $ | 0.00 |  |  | $ | 0.61 |  |  | $ | 0.19 |  |

[0000866374-17-000012:notes:63]
[same as prior period, unchanged from 0000866374-17-000008:notes:54]

[0000866374-17-000012:notes:64]
(1)         Options to purchase ordinary shares of 0.1 million and 1.7 million during the three-month periods ended September 29, 2017 and September 30, 2016, respectively, and share bonus awards of 0.8 million and 3.4 million for the three-month periods ended September 29, 2017 and September 30, 2016, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. As a result of the Company's net loss for the three-month period ended September 30, 2016, ordinary share equivalents from approximately 4.3 million options and share bonus awards were excluded from the calculation of diluted earnings (losses) per share.

[0000866374-17-000012:notes:65]
(2)         Options to purchase ordinary shares of 0.1 million and 0.9 million during the six-month periods ended September 29, 2017 and September 30, 2016, respectively, and share bonus awards of 0.5 million for the six-month period ended September 29, 2017 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. An immaterial amount of anti-dilutive share bonus awards was excluded for the six-month period ended September 30, 2016.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-17-000012:notes:66]
[same as prior period, unchanged from 0000866374-17-000008:notes:56]

[0000866374-17-000012:notes:67]
[same as prior period, unchanged from 0000866374-17-000008:notes:57]

[0000866374-17-000012:notes:68]
[same as prior period, unchanged from 0000866374-17-000008:notes:58]

[0000866374-17-000012:notes:69]
[same as prior period, unchanged from 0000866374-17-000008:notes:59]

[0000866374-17-000012:notes:70]
[same as prior period, unchanged from 0000866374-17-000008:notes:60]

[0000866374-17-000012:notes:71]
[same as prior period, unchanged from 0000866374-17-000008:notes:61]

[0000866374-17-000012:notes:72]
[same as prior period, unchanged from 0000866374-17-000008:notes:62]

[0000866374-17-000012:notes:73]
[same as prior period, unchanged from 0000866374-17-000008:notes:63]

[0000866374-17-000012:notes:74]
[same as prior period, unchanged from 0000866374-17-000008:notes:64]

[0000866374-17-000012:notes:75]
[same as prior period, unchanged from 0000866374-17-000008:notes:65]

[0000866374-17-000012:notes:76]
[same as prior period, unchanged from 0000866374-17-000008:notes:66]

[0000866374-17-000012:notes:77]
[same as prior period, unchanged from 0000866374-17-000008:notes:67]

[0000866374-17-000012:notes:78]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |  | September 29, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| Beginning balance | $ | 15,426 |  |  | $ | 75,258 |  |  | $ | 22,426 |  |  | $ | 73,423 |  |
| Additions to accrual | — |  |  | — |  |  | — |  |  | — |  |
| Payments | — |  |  | (2,221 | ) |  | — |  |  | (2,221 | ) |
| Fair value adjustments | 1,916 |  |  | 2,577 |  |  | (5,084 | ) |  | 4,412 |  |
| Ending balance | $ | 17,342 |  |  | $ | 75,614 |  |  | $ | 17,342 |  |  | $ | 75,614 |  |

[0000866374-17-000012:notes:79]
In connection with the acquisition of NEXTracker, Inc. in fiscal year 2016, the Company has an obligation to pay additional cash consideration to the former shareholders contingent upon NEXTracker, Inc.'s achievement of revenue targets during the two years after acquisition (ending on September 30, 2017). During the six-month period ended September 29, 2017, the Company reduced the obligation by $5.1 million based on the NEXTracker revenue achievement over the contingent period.

[0000866374-17-000012:notes:80]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not material. The interrelationship between these inputs is also insignificant. Refer to note 10 for a reconciliation of the change in the deferred purchase price receivable during the six-month periods ended September 29, 2017 and September 30, 2016.

[0000866374-17-000012:notes:81]
There were no transfers between levels in the fair value hierarchy during the six-month periods ended September 29, 2017 and September 30, 2016.

[0000866374-17-000012:notes:82]
[same as prior period, unchanged from 0000866374-17-000008:notes:72]

[0000866374-17-000012:notes:83]
[same as prior period, unchanged from 0000866374-17-000008:notes:73]

[0000866374-17-000012:notes:84]
|  | Fair Value Measurements as of September 29, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 593,539 |  |  | $ | — |  |  | $ | 593,539 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 487,186 |  |  | 487,186 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 36,573 |  |  | — |  |  | 36,573 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 6,829 |  |  | 63,395 |  |  | — |  |  | 70,224 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (33,468 | ) |  | $ | — |  |  | $ | (33,468 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (17,342 | ) |  | (17,342 | ) |
|  | Fair Value Measurements as of March 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,066,841 |  |  | $ | — |  |  | $ | 1,066,841 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 506,522 |  |  | 506,522 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 22,022 |  |  | — |  |  | 22,022 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,062 |  |  | 52,680 |  |  | — |  |  | 59,742 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (11,742 | ) |  | $ | — |  |  | $ | (11,742 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (22,426 | ) |  | (22,426 | ) |

[0000866374-17-000012:notes:85]
[same as prior period, unchanged from 0000866374-17-000008:notes:75]

[0000866374-17-000012:notes:86]
[same as prior period, unchanged from 0000866374-17-000008:notes:76]

[0000866374-17-000012:notes:87]
|  | As of September 29, 2017 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 523,360 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,441 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 496,219 |  |  | 496,532 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 543,685 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,180 |  |  | 650,490 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 57,359 |  |  | 57,359 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 117,660 |  |  | 117,660 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,967,418 |  |  | $ | 3,089,527 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |

[0000866374-17-000012:notes:88]
(1)    On June 30, 2017, the Company entered into a new agreement that effectively extended the maturity date of the loan from March 31, 2019 to June 30, 2022. Refer to note 6 for further details of the arrangement.

[0000866374-17-000012:notes:89]
The Company values its Euro Term Loans due September 2020 and January 2022 based on the current market rate, and as of September 29, 2017, the carrying amounts approximate fair values.

[0000866374-17-000012:notes:90]
[same as prior period, unchanged from 0000866374-17-000008:notes:80]


## us-gaap:MinorityInterestDisclosureTextBlock

[0000866374-17-000012:notes:91]
DECONSOLIDATION OF SUBSIDIARY ENTITY

[0000866374-17-000012:notes:92]
The Company has a majority owned subsidiary, Elementum SCM (Cayman) Ltd ("Elementum"), which qualifies as a variable interest entity for accounting purposes. The Company owns a majority of Elementum’s outstanding equity (consisting primarily of preferred stock) and as of March 31, 2017, controlled its board of directors, which gave the Company the power to direct the activities of Elementum that most significantly impact its economic performance. Accordingly, the Company recognized the carrying value of the noncontrolling interest as a component of total shareholders' equity, and the consolidated financial statements include the financial position and results of operations of Elementum as of and for the period ended March 31, 2017.

[0000866374-17-000012:notes:93]
During the quarter ended September 29, 2017, the Company and other minority shareholders of Elementum amended certain agreements resulting in joint control of the board of directors between the Company and other non-controlling interest holders. As a result, the Company concluded it is no longer the primary beneficiary of Elementum and accordingly, deconsolidated the entity. The Company no longer recognizes the carrying value of the noncontrolling interest as a component of total shareholder’s equity resulting in a reduction of $90.6 million of noncontrolling interest from its condensed consolidated balance sheet upon deconsolidation, which was treated as a non-cash financing activity in the condensed consolidated statement of cash flows for the period ended September 29, 2017. Further, the Company derecognized approximately $72.6 million of cash of Elementum as of the date of deconsolidation which is reflected as an outflow from investing activities within other investing activities, net in the condensed consolidated statement of cash flows for the period ended September 29, 2017. There were no other material impacts to the condensed consolidated balance sheet or condensed consolidated cash flows resulting from deconsolidation of the entity. The noncontrolling interest in the operating losses of Elementum prior to deconsolidation is immaterial for all periods presented and is classified as a component of interest and other, net, in the Company's condensed consolidated statements of operations.

[0000866374-17-000012:notes:94]
The carrying amount of the Company’s variable interest in Elementum was approximately $132.7 million as of September 29, 2017, is accounted for as a cost method investment, and is included in other assets on the condensed consolidated balance sheet. The value of the Company’s variable interest was based on management’s estimate of the fair value of Elementum on the date of deconsolidation. Given that Elementum had recently raised equity funding from third-party investors, the Company concluded that the market approach was the most appropriate method to determine the fair value of the entity on the date of deconsolidation. The Company recognized a gain on deconsolidation of approximately $151.6 million with no related tax impact, which is included in other charges (income), net on the condensed consolidated statement of operations. As the Company is not obligated to fund future losses of Elementum, the carrying amount is the Company’s maximum risk of loss. Pro-forma financials have not been presented because the effects were not material to the Company’s condensed consolidated financial position and results of operation for all periods presented. Elementum remains a related party to the Company after deconsolidation.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000866374-17-000012:notes:95]
Recently Adopted Accounting Pronouncement

[0000866374-17-000012:notes:96]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.

[0000866374-17-000012:notes:97]
In October 2016, the FASB issued new guidance intended to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early adoption permitted in the first interim period of fiscal year 2018. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.

[0000866374-17-000012:notes:98]
Recently Issued Accounting Pronouncements

[0000866374-17-000012:notes:99]
In August 2017, the FASB issued new guidance with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-17-000012:notes:100]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. The guidance is effective for the Company beginning in the first quarter of fiscal year 2019.

[0000866374-17-000012:notes:101]
The Company is in the process of implementation activities in accordance with the planned effective date. These activities are focused on the review of significant customer contracts, identification and development of additional systems capabilities to enable the Company to make reasonable estimates of revenue as products are manufactured, and the design and implementation of relevant internal controls. The Company has determined that the new standard will change the timing of revenue recognition for a significant portion of its business. Under the new standard, revenue for a significant majority of the manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery). This change will also have material impacts to the Company’s balance sheet, primarily related to a reduction in finished goods and work-in-process inventories and a corresponding increase in unbilled receivables.

[0000866374-17-000012:notes:102]
The new guidance allows for two transition methods in application - (i) retrospective to each prior reporting period presented, or (ii) prospective with the cumulative effect of adoption recognized on April 1, 2018, the first day of the Company's fiscal year 2019 (also known as the modified retrospective approach). The Company will adopt the standard using the modified retrospective approach, which will result in an adjustment to accumulated deficit for the cumulative effect of applying this guidance to contracts in process as of the adoption date. Under this approach, prior financial statements presented will not be restated. This guidance requires additional disclosures of the amount by which each financial statement line item affected in the current reporting period during fiscal year 2019 as compared to the guidance that was in effect before the change, and an explanation of the reasons for the significant changes.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-17-000012:notes:103]
[same as prior period, unchanged from 0000866374-17-000008:notes:91]

[0000866374-17-000012:notes:104]
[same as prior period, unchanged from 0000866374-17-000008:notes:92]

[0000866374-17-000012:notes:105]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2017 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and six-month periods ended September 29, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018.

[0000866374-17-000012:notes:106]
The first quarters for fiscal year 2018 and fiscal year 2017 ended on June 30, 2017, which is comprised of 91 days in the period, and July 1, 2016, which is comprised of 92 days in the period, respectively. The second quarters for fiscal year 2018 and fiscal year 2017 ended on September 29, 2017 and September 30, 2016, which are comprised of 91 days in both periods.

[0000866374-17-000012:notes:107]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. Noncontrolling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

[0000866374-17-000012:notes:108]
[same as prior period, unchanged from 0000866374-17-000008:notes:96]


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000866374-17-000012:notes:109]
[same as prior period, unchanged from 0000866374-17-000008:notes:97]

[0000866374-17-000012:notes:110]
|  | As of September 29, 2017 |  | As of March 31, 2017 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 352,651 |  |  | $ | (125,276 | ) |  | $ | 227,375 |  |  | $ | 260,704 |  |  | $ | (105,912 | ) |  | $ | 154,792 |  |
| Licenses and other intangibles | 280,712 |  |  | (87,628 | ) |  | 193,084 |  |  | 283,897 |  |  | (76,508 | ) |  | 207,389 |  |
| Total | $ | 633,363 |  |  | $ | (212,904 | ) |  | $ | 420,459 |  |  | $ | 544,601 |  |  | $ | (182,420 | ) |  | $ | 362,181 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000866374-17-000012:notes:111]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the six-month period ended September 29, 2017:

[0000866374-17-000012:notes:112]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year | $ | 420,935 |  |  | $ | 111,223 |  |  | $ | 337,707 |  |  | $ | 115,002 |  |  | $ | 984,867 |  |
| Additions (1) | 75,280 |  |  | — |  |  | — |  |  | — |  |  | 75,280 |  |
| Divestitures (2) | — |  |  | (3,475 | ) |  | — |  |  | — |  |  | (3,475 | ) |
| Purchase accounting adjustments | — |  |  | — |  |  | — |  |  | (14 | ) |  | (14 | ) |
| Foreign currency translation adjustments (3) | 30,320 |  |  | — |  |  | — |  |  | — |  |  | 30,320 |  |
| Balance, end of the period | $ | 526,535 |  |  | $ | 107,748 |  |  | $ | 337,707 |  |  | $ | 114,988 |  |  | $ | 1,086,978 |  |

[0000866374-17-000012:notes:113]
| (1) | The goodwill generated from the Company’s acquisition of AGM Automotive ("AGM") completed during the six-month period ended September 29, 2017 is primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired business. The goodwill is not deductible for income tax purposes. See note 12 for additional information. |

[0000866374-17-000012:notes:114]
| (2) | During the six-month period ended September 29, 2017, the Company disposed of Wink Labs Inc. ("Wink"), a business within the CTG segment, and recorded an aggregate reduction of goodwill of $3.5 million accordingly, which is included as an offset to the gain on sale recorded in other charges (income), net on the condensed consolidated statement of operations. |

[0000866374-17-000012:notes:115]
| (3) | During the six-month period ended September 29, 2017, the Company recorded $30.3 million of foreign currency translation adjustments primarily related to the goodwill associated with the acquisition of Mirror Controls International ("MCi"), as the U.S. Dollar fluctuated against the Euro. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000866374-17-000012:notes:116]
[same as prior period, unchanged from 0000866374-17-000008:notes:104]

[0000866374-17-000012:notes:117]
|  | As of September 29, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| Raw materials | $ | 2,672,700 |  |  | $ | 2,537,623 |  |
| Work-in-progress | 474,477 |  |  | 279,493 |  |
| Finished goods | 626,477 |  |  | 579,346 |  |
|  | $ | 3,773,654 |  |  | $ | 3,396,462 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-17-000012:notes:118]
[same as prior period, unchanged from 0000866374-17-000008:notes:106]

[0000866374-17-000012:notes:119]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2017 |  | September 30, 2016 |  | September 29, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 1,901,057 |  |  | $ | 2,101,922 |  |  | $ | 3,874,390 |  |  | $ | 4,297,912 |  |
| Consumer Technologies Group | 1,755,143 |  |  | 1,664,736 |  |  | 3,267,112 |  |  | 2,978,518 |  |
| Industrial & Emerging Industries | 1,454,539 |  |  | 1,242,722 |  |  | 2,845,138 |  |  | 2,531,737 |  |
| High Reliability Solutions | 1,159,681 |  |  | 999,145 |  |  | 2,292,052 |  |  | 2,077,171 |  |
|  | $ | 6,270,420 |  |  | $ | 6,008,525 |  |  | $ | 12,278,692 |  |  | $ | 11,885,338 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 42,733 |  |  | $ | 52,453 |  |  | $ | 91,335 |  |  | $ | 114,352 |  |
| Consumer Technologies Group | 30,722 |  |  | 55,314 |  |  | 48,726 |  |  | 79,948 |  |
| Industrial & Emerging Industries | 50,945 |  |  | 37,363 |  |  | 106,322 |  |  | 87,340 |  |
| High Reliability Solutions | 92,364 |  |  | 78,707 |  |  | 182,576 |  |  | 167,243 |  |
| Corporate and Other | (28,438 | ) |  | (26,902 | ) |  | (62,716 | ) |  | (61,702 | ) |
| Total segment income | 188,326 |  |  | 196,935 |  |  | 366,243 |  |  | 387,181 |  |
| Reconciling items: |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 16,376 |  |  | 21,986 |  |  | 36,277 |  |  | 43,584 |  |
| Stock-based compensation | 20,464 |  |  | 22,733 |  |  | 42,260 |  |  | 46,530 |  |
| Distressed customers assets impairment (1) | 4,753 |  |  | 92,915 |  |  | 4,753 |  |  | 92,915 |  |
| Contingencies and other (2) | 43,933 |  |  | 11,539 |  |  | 43,933 |  |  | 11,539 |  |
| Other charges (income), net | (143,167 | ) |  | 8,388 |  |  | (179,332 | ) |  | 11,917 |  |
| Interest and other, net | 27,554 |  |  | 24,632 |  |  | 54,430 |  |  | 49,031 |  |
| Income before income taxes | $ | 218,413 |  |  | $ | 14,742 |  |  | $ | 363,922 |  |  | $ | 131,665 |  |

[0000866374-17-000012:notes:120]
(1)     During the fourth quarter of fiscal year 2016, the Company accepted return of previously shipped inventory from a former customer, SunEdison, of approximately $90 million. On April 21, 2016, SunEdison filed a petition for reorganization under bankruptcy law, and as a result, the Company recognized a bad debt reserve of $61 million as of March 31, 2016, associated with its outstanding SunEdison receivables.

[0000866374-17-000012:notes:121]
During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand as of September 30, 2016 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market in the three and six-month periods ended September 30, 2016. The Company also recognized a $16.0 million impairment charge for solar module equipment and $16.9 million primarily related to negative margin sales and other associated solar panel direct costs incurred during the same periods. The total charge of $92.9 million is included in cost of sales for the three and six-month periods ended September 30, 2016 but is excluded from segment results above.

[0000866374-17-000012:notes:122]
(2)     During the second quarter of fiscal year 2018, the Company incurred charges in connection with the matters described in note 13, for certain loss contingencies where it believes that losses are probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted one of its China facilities.

[0000866374-17-000012:notes:123]
During fiscal year 2017, the Company initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its Sketch-to-Scaletm initiatives. As part of this plan, approximately $11.5 million was recognized in the quarter ended September 30, 2016. The plan was finalized and completed during fiscal year 2017.


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0000866374-17-000012:notes:124]
[same as prior period, unchanged from 0000866374-17-000008:notes:108]

[0000866374-17-000012:notes:125]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 (1) | $ | 37,620 |  |
| 2019 | 70,049 |  |
| 2020 | 63,846 |  |
| 2021 | 59,436 |  |
| 2022 | 50,401 |  |
| Thereafter | 139,107 |  |
| Total amortization expense | $ | 420,459 |  |

[0000866374-17-000012:notes:126]
| (1) | Represents estimated amortization for the remaining six-month period ending March 31, 2018. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-17-000012:notes:127]
[same as prior period, unchanged from 0000866374-17-000008:notes:111]

[0000866374-17-000012:notes:128]
[same as prior period, unchanged from 0000866374-17-000008:notes:112]

[0000866374-17-000012:notes:129]
[same as prior period, unchanged from 0000866374-17-000008:notes:113]

[0000866374-17-000012:notes:130]
[same as prior period, unchanged from 0000866374-17-000008:notes:114]

[0000866374-17-000012:notes:131]
[same as prior period, unchanged from 0000866374-17-000008:notes:115]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-17-000012:notes:132]
[same as prior period, unchanged from 0000866374-17-000008:notes:116]

[0000866374-17-000012:notes:133]
[same as prior period, unchanged from 0000866374-17-000008:notes:117]

[0000866374-17-000012:notes:134]
[same as prior period, unchanged from 0000866374-17-000008:notes:118]

[0000866374-17-000012:notes:135]
The gross carrying amounts of intangible assets are removed when fully amortized. During the six-month period ended September 29, 2017, the total value of intangible assets increased primarily as a result of the Company's estimated value of $82.0 million for customer related intangibles acquired with the AGM acquisition in the HRS segment, which will amortize over a weighted-average estimated useful life of 10 years. The increase was partially offset by $7.5 million for the divestiture of Wink in the CTG segment. The assigned value is subject to change as the Company completes the valuation. The estimated future annual amortization expense for intangible assets is as follows:

[0000866374-17-000012:notes:136]
[same as prior period, unchanged from 0000866374-17-000008:notes:120]

[0000866374-17-000012:notes:137]
Other current assets include approximately $487.2 million and $506.5 million as of September 29, 2017 and March 31, 2017, respectively, for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0000866374-17-000012:notes:138]
[same as prior period, unchanged from 0000866374-17-000008:notes:122]

[0000866374-17-000012:notes:139]
During the first quarter of fiscal year 2018, the Company sold Wink to an unrelated third-party venture backed company in exchange for contingent consideration fair valued at $59.0 million. This estimated consideration was based on the value of the acquirer as of the most recent third-party funding of which the Company participated. The Company recognized a non-cash gain on sale of $38.7 million, which is recorded in other charges (income), net on the condensed consolidated statement of income in the six-month period ended September 29, 2017. The contingent consideration is expected to be settled in the fourth quarter of fiscal year 2018, based on a remeasured fair value on the settlement date. As of September 29, 2017, the total investment, including working capital advances, of $72.8 million is accounted for as a cost method investment, and is included in other assets on the condensed consolidated balance sheet.

[0000866374-17-000012:notes:140]
During the second quarter of fiscal year 2018, the Company deconsolidated one of its majority owned subsidiaries, following the amendments of certain agreements that resulted in joint control of the board of directors between the Company and other non-controlling interest holders. As of September 29, 2017, this subsidiary is accounted for as a cost method investment of approximately $132.7 million and is included in other assets on the condensed consolidated balance sheet. See note 5 for additional information on the deconsolidation.

[0000866374-17-000012:notes:141]
[same as prior period, unchanged from 0000866374-17-000008:notes:124]

[0000866374-17-000012:notes:142]
Other current liabilities include customer working capital advances of $187.8 million and $231.3 million, customer-related accruals of $453.2 million and $501.9 million, and deferred revenue of $284.8 million and $280.7 million as of September 29, 2017 and March 31, 2017, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-17-000012:notes:143]
[same as prior period, unchanged from 0000866374-17-000008:notes:126]

[0000866374-17-000012:notes:144]
[same as prior period, unchanged from 0000866374-17-000008:notes:127]

[0000866374-17-000012:notes:145]
[same as prior period, unchanged from 0000866374-17-000008:notes:128]

[0000866374-17-000012:notes:146]
[same as prior period, unchanged from 0000866374-17-000008:notes:129]

[0000866374-17-000012:notes:147]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month and six-month periods ended September 29, 2017 and September 30, 2016 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0000866374-17-000012:notes:148]
As of September 29, 2017, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $1.0 billion and deferred purchase price receivables of approximately $487.2 million. As of March 31, 2017, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $1.0 billion and deferred purchase price receivables of approximately $506.5 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of September 29, 2017 and March 31, 2017, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-17-000012:notes:149]
As of September 29, 2017 and March 31, 2017, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-17-000012:notes:150]
For the six-month periods ended September 29, 2017 and September 30, 2016, cash flows from sales of receivables under the ABS Programs consisted of approximately $3.1 billion and $2.8 billion, for transfers of receivables, respectively (of which approximately $135.7 million and $92.7 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0000866374-17-000012:notes:151]
[same as prior period, unchanged from 0000866374-17-000008:notes:134]

[0000866374-17-000012:notes:152]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $231.1 million and $225.2 million as of September 29, 2017 and March 31, 2017, respectively. For the six-month periods ended September 29, 2017 and September 30, 2016, total accounts receivable sold to certain third party banking institutions was approximately $0.6 billion and $0.8 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-17-000012:notes:153]
[same as prior period, unchanged from 0000866374-17-000008:notes:136]

[0000866374-17-000012:notes:154]
During the three-month and six-month periods ended September 29, 2017, the Company repurchased 4.4 million shares at an aggregate purchase price of $71.1 million, and 8.9 million shares at an aggregate purchase price of $145.0 million, and retired all of these shares.

[0000866374-17-000012:notes:155]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 15, 2017. As of September 29, 2017, shares in the aggregate amount of $445.1 million were available to be repurchased under the current plan.
