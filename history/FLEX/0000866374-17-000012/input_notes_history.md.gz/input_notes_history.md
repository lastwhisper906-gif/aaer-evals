# FLEX note change history — 0000866374-17-000008 → 0000866374-17-000012


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2017-10-30):
[0000866374-17-000012:note_history:1]
COMMITMENTS AND CONTINGENCIES

- added (2017-10-30):
[0000866374-17-000012:note_history:2]
Litigation and other legal matters

- added (2017-10-30):
[0000866374-17-000012:note_history:3]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The Company does not believe that the amounts accrued are material.  Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented.  Any such excess could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- added (2017-10-30):
[0000866374-17-000012:note_history:4]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible loss. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- added (2017-10-30):
[0000866374-17-000012:note_history:5]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 291 million Brazilian reals (approximately USD $91 million based on the exchange rate as of September 29, 2017). The assessments are in various stages of the review process at the administrative level. The Company has meritorious defenses and plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

- added (2017-10-30):
[0000866374-17-000012:note_history:6]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-10-30):
[0000866374-17-000012:note_history:7]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2017 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and six-month periods ended September 29, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018.
  (was, 2017-08-01, similarity 0.8656):
[0000866374-17-000008:note_history:7]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2017 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018.

- changed (2017-10-30):
[0000866374-17-000012:note_history:8]
The first quarters for fiscal year 2018 and fiscal year 2017 ended on June 30, 2017, which is comprised of 91 days in the period, and July 1, 2016, which is comprised of 92 days in the period, respectively. The second quarters for fiscal year 2018 and fiscal year 2017 ended on September 29, 2017 and September 30, 2016, which are comprised of 91 days in both periods.
  (was, 2017-08-01, similarity 0.722):
[0000866374-17-000008:note_history:8]
The first quarters for fiscal year 2018 and fiscal year 2017 ended on June 30, 2017, which is comprised of 91 days in the period, and July 1, 2016, which is comprised of 92 days in the period, respectively.

- changed (2017-10-30):
[0000866374-17-000012:note_history:9]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. Noncontrolling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.
  (was, 2017-08-01, similarity 0.8951):
[0000866374-17-000008:note_history:9]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The associated noncontrolling owners' interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- added (2017-10-30):
[0000866374-17-000012:note_history:10]
In August 2017, the FASB issued new guidance with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- changed (2017-10-30):
[0000866374-17-000012:note_history:11]
The Company is in the process of implementation activities in accordance with the planned effective date. These activities are focused on the review of significant customer contracts, identification and development of additional systems capabilities to enable the Company to make reasonable estimates of revenue as products are manufactured, and the design and implementation of relevant internal controls. The Company has determined that the new standard will change the timing of revenue recognition for a significant portion of its business. Under the new standard, revenue for a significant majority of the manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery). This change will also have material impacts to the Company’s balance sheet, primarily related to a reduction in finished goods and work-in-process inventories and a corresponding increase in unbilled receivables.
  (was, 2017-08-01, similarity 0.9812):
[0000866374-17-000008:note_history:11]
The Company is in process of implementation activities in accordance with the planned effective date. These activities are focused on the review of significant customer contracts, identification and development of additional systems capabilities to enable the Company to make reasonable estimates of revenue as products are manufactured, and the design and implementation of relevant internal controls. The Company has determined that the new standard will change the timing of revenue recognition for a significant portion of its business. Under the new standard, revenue for a significant majority of electronics manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery). This change will also have material impacts to the Company’s balance sheet, primarily related to a reduction in finished goods and work-in-process inventories and a corresponding increase in contract assets for unbilled receivables.

- added (2017-10-30):
[0000866374-17-000012:note_history:12]
The new guidance allows for two transition methods in application - (i) retrospective to each prior reporting period presented, or (ii) prospective with the cumulative effect of adoption recognized on April 1, 2018, the first day of the Company's fiscal year 2019 (also known as the modified retrospective approach). The Company will adopt the standard using the modified retrospective approach, which will result in an adjustment to accumulated deficit for the cumulative effect of applying this guidance to contracts in process as of the adoption date. Under this approach, prior financial statements presented will not be restated. This guidance requires additional disclosures of the amount by which each financial statement line item affected in the current reporting period during fiscal year 2019 as compared to the guidance that was in effect before the change, and an explanation of the reasons for the significant changes.

- removed (2017-10-30):
[0000866374-17-000008:note_history:13]
The new guidance allows for two transition methods in application - (i) retrospective to each prior reporting period presented, or (ii) prospective with the cumulative effect of adoption recognized on April 1, 2018, the first day of the Company's fiscal year 2019. The Company has not yet concluded upon its selection of the transition method.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-10-30):
[0000866374-17-000012:note_history:14]
|  | As of September 29, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 496,219 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,180 |  |  | 595,979 |  |
| Other | 179,101 |  |  | 169,671 |  |
| Debt issuance costs | (15,379 | ) |  | (16,007 | ) |
| Total | $ | 2,956,121 |  |  | $ | 2,952,143 |  |

- changed (2017-10-30):
[0000866374-17-000012:note_history:15]
The weighted-average interest rates for the Company’s long-term debt were 3.5% as of September 29, 2017 and March 31, 2017, respectively.
  (was, 2017-08-01, similarity 0.8644):
[0000866374-17-000008:note_history:15]
The weighted-average interest rates for the Company’s long-term debt were 3.3% and 3.5% as of June 30, 2017 and March 31, 2017.

- changed (2017-10-30):
[0000866374-17-000012:note_history:16]
On June 30, 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature on March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualified as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the term of the 2022 Credit Facility.
  (was, 2017-08-01, similarity 0.9957):
[0000866374-17-000008:note_history:16]
On June 30, 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature on March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and of approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualify as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the terms of the 2022 Credit Facility.

- changed (2017-10-30):
[0000866374-17-000012:note_history:17]
The 2022 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of September 29, 2017, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.
  (was, 2017-08-01, similarity 0.8999):
[0000866374-17-000008:note_history:17]
The 2022 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of June 30, 2017, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.

- changed (2017-10-30):
[0000866374-17-000012:note_history:18]
Repayment of the Company’s long term debt outstanding as of September 29, 2017 is as follows:
  (was, 2017-08-01, similarity 0.9357):
[0000866374-17-000008:note_history:18]
Repayment of the Company’s long term debt outstanding as of June 30, 2017 is as follows:

- changed (2017-10-30):
[0000866374-17-000012:note_history:19]
| (1) | Represents scheduled repayment for the remaining six-month period ending March 31, 2018. |
  (was, 2017-08-01, similarity 0.973):
[0000866374-17-000008:note_history:19]
| (1) | Represents scheduled repayment for the remaining nine-month period ending March 31, 2018. |

- removed (2017-10-30):
[0000866374-17-000008:note_history:20]
|  | As of June 30, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 502,500 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,078 |  |  | 595,979 |  |
| Other | 182,046 |  |  | 169,671 |  |
| Debt issuance costs | (16,092 | ) |  | (16,007 | ) |
| Total | $ | 2,964,532 |  |  | $ | 2,952,143 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-10-30):
[0000866374-17-000012:note_history:21]
|  | As of September 29, 2017 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 523,360 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,441 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 496,219 |  |  | 496,532 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 543,685 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,180 |  |  | 650,490 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 57,359 |  |  | 57,359 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 117,660 |  |  | 117,660 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,967,418 |  |  | $ | 3,089,527 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |
  (was, 2017-08-01, similarity 0.9923):
[0000866374-17-000008:note_history:21]
|  | As of June 30, 2017 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 526,370 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 699,125 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 502,500 |  |  | 503,405 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 546,820 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,078 |  |  | 639,876 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 55,977 |  |  | 55,977 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 114,093 |  |  | 114,093 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,968,648 |  |  | $ | 3,085,666 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |

- changed (2017-10-30):
[0000866374-17-000012:note_history:22]
(1)    On June 30, 2017, the Company entered into a new agreement that effectively extended the maturity date of the loan from March 31, 2019 to June 30, 2022. Refer to note 6 for further details of the arrangement.
  (was, 2017-08-01, similarity 0.9167):
[0000866374-17-000008:note_history:22]
(1)    On June 30, 2017, the Company entered into a new arrangement and extended the maturity date of the agreement from March 31, 2019 to June 30, 2022. Refer to note 6 for further details of the arrangement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-10-30):
[0000866374-17-000012:note_history:23]
|  | As of September 29, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 496,219 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,180 |  |  | 595,979 |  |
| Other | 179,101 |  |  | 169,671 |  |
| Debt issuance costs | (15,379 | ) |  | (16,007 | ) |
| Total | $ | 2,956,121 |  |  | $ | 2,952,143 |  |

- removed (2017-10-30):
[0000866374-17-000008:note_history:24]
|  | As of June 30, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 502,500 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,078 |  |  | 595,979 |  |
| Other | 182,046 |  |  | 169,671 |  |
| Debt issuance costs | (16,092 | ) |  | (16,007 | ) |
| Total | $ | 2,964,532 |  |  | $ | 2,952,143 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-10-30):
[0000866374-17-000012:note_history:25]
Repayment of the Company’s long term debt outstanding as of September 29, 2017 is as follows:
  (was, 2017-08-01, similarity 0.9357):
[0000866374-17-000008:note_history:25]
Repayment of the Company’s long term debt outstanding as of June 30, 2017 is as follows:

- changed (2017-10-30):
[0000866374-17-000012:note_history:26]
| (1) | Represents scheduled repayment for the remaining six-month period ending March 31, 2018. |
  (was, 2017-08-01, similarity 0.973):
[0000866374-17-000008:note_history:26]
| (1) | Represents scheduled repayment for the remaining nine-month period ending March 31, 2018. |
