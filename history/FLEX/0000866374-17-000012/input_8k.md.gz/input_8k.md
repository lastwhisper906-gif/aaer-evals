# FLEX 8-K — 0001104659-17-064047 filed 2017-10-26

## item codes, every 8-K on or before 2017-10-30

- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2017-10-30

- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-17-064047:8k_2_02:1]
EX-99.1
2
a17-24445_1ex99d1.htm
EX-99.1

[0001104659-17-064047:8k_2_02:2]
Exhibit 99.1

[0001104659-17-064047:8k_2_02:3]
P R E S S   R E L E A S E

[0001104659-17-064047:8k_2_02:4]
FLEX REPORTS SECOND QUARTER FISCAL 2018 RESULTS

[0001104659-17-064047:8k_2_02:5]
·                  Quarterly revenue of $6.3 billion, increased 4% year-over-year

[0001104659-17-064047:8k_2_02:6]
·                  GAAP diluted EPS of $0.38, Non-GAAP diluted EPS of $0.27

[0001104659-17-064047:8k_2_02:7]
·                  Quarterly cash flow from operations of $142 million

[0001104659-17-064047:8k_2_02:8]
·                  Repurchased 4.4 million shares for $71 million

[0001104659-17-064047:8k_2_02:9]
San Jose, CA, October 26, 2017 — Flex (NASDAQ: FLEX), the Sketch-to-Scale™ solutions provider that designs and builds Intelligent Products for a Connected World™, today announced results for its second quarter ended September 29, 2017.

[0001104659-17-064047:8k_2_02:10]
“Our results this quarter strongly indicate Flex’s top-line growth, structural portfolio evolution, and capital return all remain on track,” said Mike McNamara, CEO at Flex. “We had impressive revenue performance across the board, growing for the third consecutive quarter on a year-over-year basis, with revenue for all four business groups above the midpoint of their respective guidance ranges.”

[0001104659-17-064047:8k_2_02:11]
|  |  | Three-Month Periods Ended |  |
| (US$ in millions, except EPS) |  | September 29, 2017 |  | September 30, 2016 |  |
| Net sales |  | $ | 6,270 |  | $ | 6,009 |  |
| GAAP income before income taxes |  | 218 |  | 15 |  |
| Adjusted operating income |  | 188 |  | 197 |  |
| GAAP net income (loss) |  | 205 |  | (3 | ) |
| Adjusted net income |  | 142 |  | 152 |  |
| GAAP EPS |  | 0.38 |  | 0.00 |  |
| Adjusted EPS |  | 0.27 |  | 0.28 |  |

[0001104659-17-064047:8k_2_02:12]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release.

[0001104659-17-064047:8k_2_02:13]
Second Quarter Fiscal 2018 Results of Operations

[0001104659-17-064047:8k_2_02:14]
Net sales for the second quarter ended September 29, 2017 were $6.3 billion, growing 4% year-over-year and at the high end of the guidance range of $5.9 to $6.3 billion. GAAP income before income taxes was $218 million for the quarter and adjusted operating income was $188 million, above the mid-point of the guidance range of $170 million to $200 million. GAAP net income was approximately $205 million and adjusted net income for the quarter was $142 million. GAAP EPS was $0.38 for the quarter and non-GAAP EPS was $0.27 for the quarter.

[0001104659-17-064047:8k_2_02:15]
Cash Flow and Balance Sheet

[0001104659-17-064047:8k_2_02:16]
For the three-month period ended September 29, 2017, Flex generated cash from operations of approximately $142 million and free cash flow of $34 million. For the six-month period ended September 29, 2017, Flex generated cash from operations of $281 million and free cash flow of $53 million.  The Company remains committed to return over 50% of annual free cash flow to its shareholders as it repurchased ordinary shares for approximately $71 million and $145 million during

[0001104659-17-064047:8k_2_02:17]
the three and six-month periods ended September 29, 2017, respectively. Flex ended the quarter with over $1.3 billion of cash on hand and total debt of $3.0 billion. The balance sheet remains strong and is well-positioned to support the business over the long-term.

[0001104659-17-064047:8k_2_02:18]
Third Quarter Fiscal Year 2018 Guidance

[0001104659-17-064047:8k_2_02:19]
For the third quarter ending December 31, 2017, revenue is expected to be in the range of $6.3 to $6.7 billion, GAAP EPS is expected to be in the range of $0.20 to $0.24 and includes stock-based compensation expense and intangible amortization. Adjusted EPS is expected to be in the range of $0.28 to $0.32 per diluted share.

[0001104659-17-064047:8k_2_02:20]
Webcast and Conference Call

[0001104659-17-064047:8k_2_02:21]
Flex management team will host a conference call today at 2:00 PM (PT) / 5:00 PM (ET), to review second quarter fiscal 2018 results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com. An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0001104659-17-064047:8k_2_02:22]
About Flex

[0001104659-17-064047:8k_2_02:23]
Flex Ltd. (Reg. No. 199002645H) is the Sketch-to-Scale™ solutions provider that designs and builds Intelligent Products for a Connected World™. With approximately 200,000 professionals across 30 countries, Flex provides innovative design, engineering, manufacturing, real-time supply chain insight and logistics services to companies of all sizes in various industries and end-markets. For more information, visit flex.com or follow us on Twitter @Flexintl. Flex — Live Smarter™

[0001104659-17-064047:8k_2_02:24]
Contact

[0001104659-17-064047:8k_2_02:25]
Kevin Kessel, CFA

[0001104659-17-064047:8k_2_02:26]
Vice President, Investor Relations & Corporate Communications

[0001104659-17-064047:8k_2_02:27]
(408) 576-7985

[0001104659-17-064047:8k_2_02:28]
kevin.kessel@flex.com

[0001104659-17-064047:8k_2_02:29]
Forward-Looking Statements

[0001104659-17-064047:8k_2_02:30]
SCHEDULE I

[0001104659-17-064047:8k_2_02:31]
FLEX

[0001104659-17-064047:8k_2_02:32]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-17-064047:8k_2_02:33]
(In thousands, except per share amounts)

[0001104659-17-064047:8k_2_02:34]
|  |  | Three-Month Periods Ended |  |
|  |  | September 29, 2017 |  | September 30, 2016 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 6,270,420 |  | $ | 6,008,525 |  |
| Cost of sales |  | 5,877,095 |  | 5,694,834 |  |
| Gross profit |  | 393,325 |  | 313,691 |  |
| Selling, general and administrative expenses |  | 274,149 |  | 243,943 |  |
| Intangible amortization |  | 16,376 |  | 21,986 |  |
| Interest and other, net |  | 27,554 |  | 24,632 |  |
| Other charges (income), net |  | (143,167 | ) | 8,388 |  |
| Income before income taxes |  | 218,413 |  | 14,742 |  |
| Provision for income taxes |  | 13,327 |  | 17,250 |  |
| Net income (loss) |  | $ | 205,086 |  | $ | (2,508 | ) |
| Earnings (losses) per share: |  |  |  |  |  |
| GAAP |  | $ | 0.38 |  | $ | 0.00 |  |
| Non-GAAP |  | $ | 0.27 |  | $ | 0.28 |  |
| Basic shares used in computing per share amounts (2) |  | 531,313 |  | 544,055 |  |
| Diluted shares used in computing per share amounts (2) |  | 536,019 |  | 544,055 |  |

[0001104659-17-064047:8k_2_02:35]
| See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |

[0001104659-17-064047:8k_2_02:36]
FLEX

[0001104659-17-064047:8k_2_02:37]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-17-064047:8k_2_02:38]
(In thousands, except per share amounts)

[0001104659-17-064047:8k_2_02:39]
|  |  | Six-Month Periods Ended |  |
|  |  | September 29, 2017 |  | September 30, 2016 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 12,278,692 |  | $ | 11,885,338 |  |
| Cost of sales |  | 11,478,435 |  | 11,165,652 |  |
| Gross profit |  | 800,257 |  | 719,686 |  |
| Selling, general and administrative expenses |  | 524,960 |  | 483,489 |  |
| Intangible amortization |  | 36,277 |  | 43,584 |  |
| Interest and other, net |  | 54,430 |  | 49,031 |  |
| Other charges (income), net |  | (179,332 | ) | 11,917 |  |
| Income before income taxes |  | 363,922 |  | 131,665 |  |
| Provision for income taxes |  | 34,126 |  | 28,444 |  |
| Net income |  | $ | 329,796 |  | $ | 103,221 |  |
| Earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.61 |  | $ | 0.19 |  |
| Non-GAAP |  | $ | 0.51 |  | $ | 0.55 |  |
| Basic shares used in computing per share amounts |  | 530,790 |  | 544,353 |  |
| Diluted shares used in computing per share amounts |  | 536,311 |  | 549,934 |  |

[0001104659-17-064047:8k_2_02:40]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release.

[0001104659-17-064047:8k_2_02:41]
SCHEDULE II

[0001104659-17-064047:8k_2_02:42]
FLEX

[0001104659-17-064047:8k_2_02:43]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-17-064047:8k_2_02:44]
(In thousands, except per share amounts)

[0001104659-17-064047:8k_2_02:45]
|  |  | Three-Month Periods Ended |  |
|  |  | September 29, 2017 |  | September 30, 2016 |  |
| GAAP gross profit |  | $ | 393,325 |  | $ | 313,691 |  |
| Stock-based compensation expense |  | 4,985 |  | 2,636 |  |
| Distressed customer asset impairment (3) |  | — |  | 92,915 |  |
| Contingencies and other (4) |  | 18,933 |  | 6,824 |  |
| Non-GAAP gross profit |  | $ | 417,243 |  | $ | 416,066 |  |
| GAAP income before income taxes |  | $ | 218,413 |  | $ | 14,742 |  |
| Intangible amortization |  | 16,376 |  | 21,986 |  |
| Stock-based compensation expense |  | 20,464 |  | 22,733 |  |
| Distressed customer asset impairment (3) |  | 4,753 |  | 92,915 |  |
| Contingencies and other (4) |  | 43,933 |  | 11,539 |  |
| Other charges (income), net (5) |  | (143,167 | ) | 8,388 |  |
| Interest and other, net |  | 27,554 |  | 24,632 |  |
| Non-GAAP operating income |  | $ | 188,326 |  | $ | 196,935 |  |
| GAAP provision for income taxes |  | $ | 13,327 |  | $ | 17,250 |  |
| Intangible amortization benefit |  | 2,250 |  | 1,825 |  |
| Tax benefit on contingencies and other |  | 2,738 |  | 196 |  |
| Non-GAAP provision for income taxes |  | $ | 18,315 |  | $ | 19,271 |  |
| GAAP net income (loss) |  | $ | 205,086 |  | $ | (2,508 | ) |
| Intangible amortization |  | 16,376 |  | 21,986 |  |
| Stock-based compensation expense |  | 20,464 |  | 22,733 |  |
| Distressed customer asset impairment (3) |  | 4,753 |  | 92,915 |  |
| Contingencies and other (4) |  | 43,933 |  | 11,539 |  |
| Other charges (income), net (5) |  | (143,167 | ) | 7,388 |  |
| Adjustments for taxes |  | (4,988 | ) | (2,021 | ) |
| Non-GAAP net income |  | $ | 142,457 |  | $ | 152,032 |  |
| Diluted earnings (losses) per share: |  |  |  |  |  |
| GAAP (2) |  | $ | 0.38 |  | $ | 0.00 |  |
| Non-GAAP (2) |  | $ | 0.27 |  | $ | 0.28 |  |

[0001104659-17-064047:8k_2_02:46]
FLEX

[0001104659-17-064047:8k_2_02:47]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-17-064047:8k_2_02:48]
(In thousands, except per share amounts)

[0001104659-17-064047:8k_2_02:49]
|  |  | Six-Month Periods Ended |  |
|  |  | September 29, 2017 |  | September 30, 2016 |  |
| GAAP gross profit |  | $ | 800,257 |  | $ | 719,686 |  |
| Stock-based compensation expense |  | 8,304 |  | 5,069 |  |
| Distressed customer asset impairment (3) |  | — |  | 92,915 |  |
| Contingencies and other (4) |  | 18,933 |  | 6,824 |  |
| Non-GAAP gross profit |  | $ | 827,494 |  | $ | 824,494 |  |
| GAAP income before income taxes |  | $ | 363,922 |  | $ | 131,665 |  |
| Intangible amortization |  | 36,277 |  | 43,584 |  |
| Stock-based compensation expense |  | 42,260 |  | 46,530 |  |
| Distressed customer asset impairment (3) |  | 4,753 |  | 92,915 |  |
| Contingencies and other (4) |  | 43,933 |  | 11,539 |  |
| Other charges (income), net (5) |  | (179,332 | ) | 11,917 |  |
| Interest and other, net |  | 54,430 |  | 49,031 |  |
| Non-GAAP operating income |  | $ | 366,243 |  | $ | 387,181 |  |
| GAAP provision for income taxes |  | $ | 34,126 |  | $ | 28,444 |  |
| Intangible amortization benefit |  | 4,016 |  | 3,675 |  |
| Tax benefit on contingencies and other |  | 2,738 |  | 196 |  |
| Tax benefit on intangible assets |  | — |  | 638 |  |
| Non-GAAP provision for income taxes |  | $ | 40,880 |  | $ | 32,953 |  |
| GAAP net income |  | $ | 329,796 |  | $ | 103,221 |  |
| Intangible amortization |  | 36,277 |  | 43,584 |  |
| Stock-based compensation expense |  | 42,260 |  | 46,530 |  |
| Distressed customer asset impairment (3) |  | 4,753 |  | 92,915 |  |
| Contingencies and other (4) |  | 43,933 |  | 11,539 |  |
| Other charges (income), net (5) |  | (179,332 | ) | 7,388 |  |
| Adjustments for taxes |  | (6,754 | ) | (4,509 | ) |
| Non-GAAP net income |  | $ | 270,933 |  | $ | 300,668 |  |
| Diluted earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.61 |  | $ | 0.19 |  |
| Non-GAAP |  | $ | 0.51 |  | $ | 0.55 |  |

[0001104659-17-064047:8k_2_02:50]
SCHEDULE III

[0001104659-17-064047:8k_2_02:51]
FLEX

[0001104659-17-064047:8k_2_02:52]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-17-064047:8k_2_02:53]
(In thousands)

[0001104659-17-064047:8k_2_02:54]
|  |  | As of September 29, 2017 |  | As of March 31, 2017 |  |
| ASSETS |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,369,502 |  | $ | 1,830,675 |  |
| Accounts receivable, net of allowance for doubtful accounts |  | 2,632,934 |  | 2,192,704 |  |
| Inventories |  | 3,773,654 |  | 3,396,462 |  |
| Other current assets |  | 1,091,957 |  | 967,935 |  |
| Total current assets |  | 8,868,047 |  | 8,387,776 |  |
| Property and equipment, net |  | 2,415,574 |  | 2,317,026 |  |
| Goodwill |  | 1,086,978 |  | 984,867 |  |
| Other intangible assets, net |  | 420,459 |  | 362,181 |  |
| Other assets |  | 770,848 |  | 541,513 |  |
| Total assets |  | $ | 13,561,906 |  | $ | 12,593,363 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 46,977 |  | $ | 61,534 |  |
| Accounts payable |  | 5,231,130 |  | 4,484,908 |  |
| Accrued payroll |  | 400,074 |  | 344,245 |  |
| Other current liabilities |  | 1,552,254 |  | 1,613,940 |  |
| Total current liabilities |  | 7,230,435 |  | 6,504,627 |  |
| Long-term debt, net of current portion |  | 2,909,144 |  | 2,890,609 |  |
| Other liabilities |  | 550,042 |  | 519,851 |  |
| Total shareholders’ equity |  | 2,872,285 |  | 2,678,276 |  |
| Total liabilities and shareholders’ equity |  | $ | 13,561,906 |  | $ | 12,593,363 |  |

[0001104659-17-064047:8k_2_02:55]
SCHEDULE IV

[0001104659-17-064047:8k_2_02:56]
FLEX

[0001104659-17-064047:8k_2_02:57]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-17-064047:8k_2_02:58]
(In thousands)

[0001104659-17-064047:8k_2_02:59]
|  |  | Six-Month Periods Ended |  |
|  |  | September 29, 2017 |  | September 30, 2016 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income |  | $ | 329,796 |  | $ | 103,221 |  |
| Depreciation, amortization and other impairment charges |  | 264,718 |  | 337,387 |  |
| Gain from deconsolidation of a subsidiary entity |  | (151,574 | ) | — |  |
| Changes in working capital and other |  | (162,135 | ) | 102,944 |  |
| Net cash provided by operating activities |  | 280,805 |  | 543,552 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property and equipment |  | (264,030 | ) | (305,936 | ) |
| Proceeds from the disposition of property and equipment |  | 36,123 |  | 26,561 |  |
| Acquisition of businesses, net of cash acquired |  | (273,167 | ) | (189,895 | ) |
| Proceeds from divestiture of business, net of cash held in divested business |  | (2,949 | ) | 36,073 |  |
| Other investing activities, net |  | (114,063 | ) | 20,357 |  |
| Net cash used in investing activities |  | (618,086 | ) | (412,840 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | — |  | 75,035 |  |
| Repayments of bank borrowings and long-term debt |  | (26,483 | ) | (110,592 | ) |
| Payments for repurchases of ordinary shares |  | (145,005 | ) | (184,698 | ) |
| Net proceeds from issuance of ordinary shares |  | 1,211 |  | 11,344 |  |
| Other financing activities, net |  | 60,591 |  | (6,836 | ) |
| Net cash used in financing activities |  | (109,686 | ) | (215,747 | ) |
| Effect of exchange rates on cash and cash equivalents |  | (14,206 | ) | 14,521 |  |
| Net decrease in cash and cash equivalents |  | (461,173 | ) | (70,514 | ) |
| Cash and cash equivalents, beginning of period |  | 1,830,675 |  | 1,607,570 |  |
| Cash and cash equivalents, end of period |  | $ | 1,369,502 |  | $ | 1,537,056 |  |

[0001104659-17-064047:8k_2_02:60]
SCHEDULE V

[0001104659-17-064047:8k_2_02:61]
FLEX AND SUBSIDIARIES

[0001104659-17-064047:8k_2_02:62]
NOTES TO SCHEDULES I, II, III, & IV

[0001104659-17-064047:8k_2_02:63]
(1)   To supplement Flex’s unaudited selected financial data presented consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies.  We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-17-064047:8k_2_02:64]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-17-064047:8k_2_02:65]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-17-064047:8k_2_02:66]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-17-064047:8k_2_02:67]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-17-064047:8k_2_02:68]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-17-064047:8k_2_02:69]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-17-064047:8k_2_02:70]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types.  In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-17-064047:8k_2_02:71]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions.  The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-17-064047:8k_2_02:72]
Distressed customer assets impairment consists primarily of non-cash inventory impairments of certain inventory on hand to net realizable value as well as additional provisions for doubtful accounts receivable for customers that are experiencing significant financial difficulties. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures. See additional description related to the specific period charge as applicable below.

[0001104659-17-064047:8k_2_02:73]
Contingencies and other consists primarily of charges in connection with certain legal matters of which loss contingencies are believed to be probable and estimable. It also includes certain targeted site restructuring costs and damages incurred from natural disasters which are not directly related to ongoing or core business results, and do not reflect expected future operating expense. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-17-064047:8k_2_02:74]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies when applicable.

[0001104659-17-064047:8k_2_02:75]
Other charges (income), net consists of various other types of items that are not directly related to ongoing or core business results, such as the gain or loss from certain divestitures and impairment charges associated with non-core investments.  We exclude these items because they are not related to the Company’s ongoing operating performance or do not affect core operations.  Excluding these amounts provide investors with a basis to compare Company performance against the performance of other companies without this variability.

[0001104659-17-064047:8k_2_02:76]
For the three-month period ended September 29, 2017, Free Cash Flow was $34 million consisting of GAAP net cash flows from operating activities of approximately $142 million less purchases of property and equipment net of proceeds from dispositions of $108 million. We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash flows provided by operating activities.”

[0001104659-17-064047:8k_2_02:77]
(2) Basic shares were used in calculating diluted GAAP EPS for the quarter ended September 30, 2016 due to the net loss recognized during the period. Diluted shares for Q2 fiscal 2017 were 548,358 thousand which were used in calculating diluted Non-GAAP EPS for the quarter.

[0001104659-17-064047:8k_2_02:78]
(3)   Distressed customer assets impairment for the three and six-month periods ended September 29, 2017    relates to additional provision for doubtful accounts receivable for a customer experiencing significant financial difficulties.

[0001104659-17-064047:8k_2_02:79]
During the fourth quarter of fiscal year 2016, the Company accepted return of previously shipped inventory from a former customer, SunEdison, Inc. (“SunEdison”), of approximately $90 million. On April 21, 2016, SunEdison filed a petition for reorganization under bankruptcy law, and as a result, the Company recognized a bad debt reserve of $61 million as of March 31, 2016, associated with its outstanding SunEdison receivables.

[0001104659-17-064047:8k_2_02:80]
During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand as of September 30, 2016 was not fully recoverable and recorded a charge of $60 million to reduce the carrying costs to market in the three and six-month periods ended September 30, 2016. The Company also recognized a $16 million impairment charge for solar module equipment and $16.9 million primarily related to negative margin sales and other

[0001104659-17-064047:8k_2_02:81]
associated solar panel direct costs incurred during the same periods. The total charge of $92.9 million is included in cost of sales for the three and six-month periods ended September 30, 2016.

[0001104659-17-064047:8k_2_02:82]
(4)   Contingencies and other during the three and six-month periods ended September 29, 2017 consist of charges in connection with certain legal matters of which loss contingencies are believed to be probable and estimable. Additionally, during the second quarter ended September 29, 2017 the Company incurred various other charges predominantly related to damages incurred from a typhoon that impacted one of its China facilities.

[0001104659-17-064047:8k_2_02:83]
During fiscal year 2017, the Company initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its Sketch-to-Scale™ initiatives. As part of this plan, approximately $11.5 million was recognized in the quarter ended September 30, 2016. The plan was finalized and completed during fiscal year 2017.

[0001104659-17-064047:8k_2_02:84]
(5) During the quarter ended September 29, 2017, the Company and other minority shareholders of Elementum amended certain agreements and as a result, the Company concluded it no longer had majority control and accordingly, deconsolidated the entity. As part of the deconsolidation, we recognized a gain of $151.6 million, which is included in other charges (income), net for the three and six-month periods ended September 29, 2017.

[0001104659-17-064047:8k_2_02:85]
In addition, the company sold its Wink business during first quarter of fiscal year 2018 to an unrelated third-party venture backed company in exchange for contingent consideration fair valued at $59 million and recognized a gain on sale of $38.7 million, which is recorded in other charges (income), net for the six-months ended September 29, 2017. The contingent consideration is expected to be settled in the fourth quarter of fiscal year 2018.

[0001104659-17-064047:8k_2_02:86]
The three and six-month periods ended September 30, 2016 includes a $7.4 million loss attributable to a non-strategic facility sold during the second quarter of fiscal year 2017.
