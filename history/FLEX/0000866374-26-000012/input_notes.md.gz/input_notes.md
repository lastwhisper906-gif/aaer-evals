# FLEX notes — 0000866374-26-000012


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000866374-26-000012:notes:1]
| Document |  | Parts into Which Incorporated |
| Proxy Statement to be delivered to shareholders in connection with the Registrant's 2026 Annual General Meeting of Shareholders |  | Part III |


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000866374-26-000012:notes:2]
Our cybersecurity risk management program is intended to protect the confidentiality, integrity, and availability of our critical information technology ("IT") systems and data. We have integrated this program into our broader enterprise risk management framework, which is designed to identify, assess, prioritize and mitigate risks across the organization to enhance our resilience and support the achievement of our strategic objectives. We have designed and assess our cybersecurity risk management program based on multiple cybersecurity frameworks, including the National Institute of Standards and Technology Cybersecurity Framework ("NIST 2.0 CSF") and information security standards issued by the International Organization for Standardization, including ISO 27001. These frameworks guide us in identifying, assessing, and managing cybersecurity risks relevant to our business. Our global information security management program is ISO 27001:2022 certified.

[0000866374-26-000012:notes:3]
Our cybersecurity risk management program is led by our Chief Information Officer (“CIO”) on an interim basis, supported by our security team principally responsible for managing our cybersecurity risk assessment processes, security controls, and detection and response to cybersecurity incidents. Our program includes protocols for preventing, detecting, and responding to cybersecurity incidents, as well as cross-functional coordination of business continuity and disaster recovery plans. Key components of our program include:

[0000866374-26-000012:notes:4]
•risk assessments designed to help identify cybersecurity threats to our critical IT systems, information, and our broader enterprise IT environment;

[0000866374-26-000012:notes:5]
•the periodic engagement of independent security firms and other third-party experts, where appropriate, to assess, test, and certify components of our cybersecurity program, and to otherwise assist with aspects of our cybersecurity processes and controls;

[0000866374-26-000012:notes:6]
•      annual cybersecurity awareness training for our employees;

[0000866374-26-000012:notes:7]
•regular assessments of the design and operational effectiveness of the program’s key processes and controls by our internal audit team as well as external consultants; and

[0000866374-26-000012:notes:8]
•      a risk management process for third-party service providers and vendors that includes security due diligence during the selection process, contractual security requirements, and periodic monitoring of adherence to applicable cybersecurity standards.

[0000866374-26-000012:notes:9]
We maintain a cybersecurity incident response plan that establishes procedures to assess and manage cybersecurity incidents. The plan includes escalation protocols based on the nature and severity of the incident, including escalation to the Audit Committee and the Board when appropriate. We conduct tabletop exercises at least annually to test our incident response procedures, identify gaps, and evaluate team preparedness.

[0000866374-26-000012:notes:10]
As part of our overall risk mitigation strategy, we maintain insurance coverage intended to address certain aspects of cybersecurity risks. However, this insurance may not be sufficient in type or amount to cover all claims related to cybersecurity breaches, cyberattacks, or other related incidents.

[0000866374-26-000012:notes:11]
As of the date of this report, we do not believe that any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, have materially affected or are reasonably likely to materially affect our Company, including our business strategy, results of operations or financial condition. Despite our security measures, however, there can be no assurance that we, or third parties with which we interact, will not experience a cybersecurity incident in the future that could materially affect us. For more information on our cybersecurity-related risks, see Item 1A, "Risk Factors - A breach of our IT or physical security systems, or a cybersecurity incident affecting our operations, products, or third parties upon which we rely, could materially disrupt our business, damage our reputation, and expose us to significant costs and liability."


## cyd:CybersecurityRiskBoardCommitteeOrSubcommitteeResponsibleForOversightTextBlock

[0000866374-26-000012:notes:12]
The Audit Committee of our Board of Directors has primary oversight responsibility for cybersecurity risks and other information technology risks. This oversight includes reviewing our plans to mitigate cybersecurity risks and our preparedness to respond to data breaches or other cybersecurity incidents.

[0000866374-26-000012:notes:13]
The Audit Committee receives reports on cybersecurity matters at least quarterly from our Chief Information Security Officer ("CISO") (and currently on an interim basis, our CIO). These reports cover a range of topics, including our cybersecurity risk profile, the current and emerging threat landscape, the status of ongoing cybersecurity initiatives, incident reports, and the results of internal and external assessments. The Audit Committee also annually reviews the adequacy and effectiveness of our information security policies and related internal controls, and receives periodic updates from our internal

[0000866374-26-000012:notes:14]
audit function on the results of cybersecurity audits and related mitigation activities. The Chair of the Audit Committee reports to the full Board on these matters as appropriate.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0000866374-26-000012:notes:15]
The full Board also receives briefings on cybersecurity matters annually from our CISO (and currently on an interim basis, our CIO). In addition, Board members periodically receive presentations on cybersecurity topics from external experts as part of the Board’s continuing education and overall risk oversight responsibilities.

[0000866374-26-000012:notes:16]
At the management level, our CIO has assumed interim oversight of our enterprise-wide cybersecurity program following the departure of our former CISO in April 2026. In this role, he monitors the prevention, detection, mitigation, and remediation of cybersecurity risks and incidents through participation in the cybersecurity risk management and strategy processes described above, including the operation of our incident response plan. Our CIO reports to our Chief Operating Officer, a member of our executive leadership team.

[0000866374-26-000012:notes:17]
Our CIO has over 20 years of experience in information technology and has led teams in the design, implementation, and continuous improvement of enterprise-wide digital and cybersecurity programs. Our CIO has managed material risks from cybersecurity threats, including the development and operation of incident response plans. Our CIO holds a Bachelor's degree in Computer Engineering and a Master's degree in Information Technology.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-26-000012:notes:18]
ORGANIZATION OF THE COMPANY
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, and integrated services, plus a portfolio of power and cooling products. Over time, we have built differentiated scale and expertise across both technology-driven and regulated markets, enabling us to support customers with increasingly complex product, infrastructure, and compliance requirements. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, and power.

[0000866374-26-000012:notes:19]
Beginning in the fourth quarter of fiscal year 2026, the Company changed how it reports its results to its Chief Operating Decision Maker ("CODM"), principally reflecting growth of Flex's data center businesses. A new segment, Cloud and Power Infrastructure ("CPI") was created to report these data center-related businesses, including the Cloud and Cooling business from the former CEC reporting unit in the former Flex Agility Solutions ("FAS") segment and the Power business from the former Industrial reporting unit in the former Flex Reliability Solutions ("FRS") segment. The FAS segment was renamed Integrated Technology Solutions ("ITS") and the FRS segment was renamed Regulated Manufacturing Solutions ("RMS"). In addition, the former Consumer Devices reporting unit in FAS was merged into the Lifestyle reporting unit in ITS and certain customers were moved between FRS and FAS to better reflect how the businesses are managed. As of March 31, 2026, Flex's three operating and reportable segments are as follows:

[0000866374-26-000012:notes:20]
•Integrated Technology Solutions ("ITS"), which is comprised of the following end markets:

[0000866374-26-000012:notes:21]
◦Communications, high speed networking, enterprise, and satellite communications systems

[0000866374-26-000012:notes:22]
◦Lifestyle, premium products across commercial, home and personal product categories

[0000866374-26-000012:notes:23]
•Regulated Manufacturing Solutions ("RMS"), which is comprised of the following end markets:

[0000866374-26-000012:notes:24]
◦Industrial, mission-critical automation, energy, and industrial infrastructure

[0000866374-26-000012:notes:25]
◦Automotive, compute and power electronics platforms, and integrated systems

[0000866374-26-000012:notes:26]
◦Healthcare, regulated manufacturing for medical devices, drug delivery and equipment

[0000866374-26-000012:notes:27]
•Cloud and Power Infrastructure ("CPI"), which is comprised of the following end markets:

[0000866374-26-000012:notes:28]
◦Cloud and Cooling, integrated compute systems supporting power‑dense digital infrastructure deployments, and advanced liquid cooling solutions supporting higher-density, power-intensive rack architectures

[0000866374-26-000012:notes:29]
◦Power, utility and facility‑level electrical infrastructure enabling reliable, scalable power delivery and high-density rack- and board-level power systems supporting power-intensive compute workloads

[0000866374-26-000012:notes:30]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).

[0000866374-26-000012:notes:31]
On May 5, 2026, Flex announced its intention to separate its CPI segment from Flex and into an independent, publicly traded company (“SpinCo”). The separation of CPI into SpinCo will create a separate publicly traded company focused on data center power, digital infrastructure and power, thermal and compute integration. The spin-off of CPI from Flex is expected to be completed in the first quarter of calendar 2027 and is subject to the approval of Flex’s Board of Directors, shareholders, and the High Court of the Republic of Singapore and the SEC declaring SpinCo’s Form 10 registration statement effective. Subsequent to the spin-off of CPI from Flex, Flex will continue as an advanced manufacturing and supply chain solutions business consisting of the ITS and RMS segments. There can be no assurance that any spin-off transaction will ultimately occur or, if one does occur, of its terms or timing. Refer to note 22 "Subsequent Events" for further details.

[0000866374-26-000012:notes:32]
Nextracker Follow-on Offering and Spin-off

[0000866374-26-000012:notes:33]
On February 13, 2023, Nextracker Inc. ("Nextracker") completed an initial public offering (the "IPO") of its Class A common stock that, together with a subsequent follow‑on offering, reduced Flex’s ownership interest prior to the completion of the full separation of Nextracker in January 2024. In connection with the IPO, Nextracker entered into a Tax Receivable Agreement ("TRA") with Flex and TPG wherein 85% of the tax benefits realized in relation to the IPO would be paid to those parties. Flex has not recorded an asset in relation to amounts potentially due to Flex under the TRA as the amounts are contingent upon Nextracker realizing the IPO related tax benefits. As such, amounts will be recognized in income, if and when they are received. Amounts that could be received by Flex, over a 20-year period, range from zero to approximately $300 million. During fiscal year 2026, $20 million was received under the Nextracker TRA.

[0000866374-26-000012:notes:34]
On January 2, 2024, the Company completed its previously announced spin-off of its remaining interest in Nextracker to Flex shareholders on a pro-rata basis. The Nextracker spin-off is intended to qualify as a tax-free transaction for U.S. federal income tax purposes.

[0000866374-26-000012:notes:35]
As a result of the completion of the spin-off, Nextracker became a fully independent public company, Flex no longer directly or indirectly holds any shares of Nextracker common stock or any securities convertible into or exchangeable for shares of Nextracker common stock, and Flex no longer consolidates Nextracker into its financial results. Prior to or in connection with the spin-off, Flex entered into various agreements to effect the Nextracker spin-off and provide a framework for the relationship between Flex and Nextracker following the spin-off, including a Separation Agreement, a Tax Matters Agreement, a Transition Services Agreement, as well as agreements governing future trading relationships.

[0000866374-26-000012:notes:36]
Subsequent to the spin-off, Flex presents Nextracker’s historical operations as discontinued operations and, as such, Nextracker’s historical results have been excluded from continuing operations and, unless otherwise indicated, Flex’s disclosures are presented on a continuing operations basis.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-26-000012:notes:37]
SUMMARY OF ACCOUNTING POLICIES
Basis of Presentation and Principles of Consolidation

[0000866374-26-000012:notes:38]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners.

[0000866374-26-000012:notes:39]
Use of Estimates

[0000866374-26-000012:notes:40]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; valuation of warrants, and the fair values of restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas conflict, and recent U.S. military operations in Iran) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-26-000012:notes:41]
Impact of Missile Strike in Ukraine

[0000866374-26-000012:notes:42]
During the fiscal year ended March 31, 2026, the Company recognized $51 million in asset impairments, inventory write-downs and other charges as a result of a missile strike on its Mukachevo, Ukraine facility in Western Ukraine on August 21, 2025. The total $51 million expense includes $23 million of long-lived asset impairments, $13 million of inventory write-downs and $15 million of other charges. The missile strike represents an unusual and infrequent event as hostilities related to the Russian invasion of Ukraine have been primarily focused in Eastern Ukraine. The missile strike caused substantial physical damage and disrupted normal operations at the facility. In response, the Company activated contingency manufacturing plans and transitioned production to alternative facilities. As restoration activities progress in Mukachevo, the Company expects to incur additional immaterial near-term inefficiencies. The total $51 million expense is included in restructuring and impairment charges in the consolidated statements of operations.

[0000866374-26-000012:notes:43]
Translation of Foreign Currencies

[0000866374-26-000012:notes:44]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive income (loss), a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in the Company's consolidated results of operations. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for all periods presented, and have been classified as a component of other charges (income), net in the consolidated statements of operations.

[0000866374-26-000012:notes:45]
Revenue Recognition

[0000866374-26-000012:notes:46]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Service contract revenue is recognized on an overtime basis using the output method. Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company recognizes estimates of this variable consideration that are not expected to result in a significant revenue reversal in the future, primarily based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Certain of the Company's customer contracts involve purchasing raw materials from customers or acting as an agent for the sale of certain customer products. Finished goods billings related to these products are reported net of the associated material cost in net sales in the consolidated statements of operations. Refer to note 4 "Revenue" for further details.

[0000866374-26-000012:notes:47]
Government Incentives and Grants

[0000866374-26-000012:notes:48]
The Company receives incentives from federal, state and local governments in different regions of the world that primarily encourage the Company to establish, maintain, or increase investment, employment, or production in the regions. The Company accounts for government incentives as a reduction in the cost of the capital investment or a reduction of expense, based on the substance of the incentives received. Benefits are generally recorded when all conditions attached to the incentive

[0000866374-26-000012:notes:49]
have been met and there is reasonable assurance of receipt. The Company records capital-related incentives as a reduction to Property and equipment, net on the consolidated balance sheets and recognizes a reduction to depreciation and amortization expense over the useful life of the corresponding acquired asset. The Company records operating grants as a reduction to expense in the same line item on the consolidated statements of operations as the expenditure for which the grant is intended to compensate. Government incentives and grant transactions are not material to the Company's financial position, results of operations or cash flows.

[0000866374-26-000012:notes:50]
Concentration of Credit Risk

[0000866374-26-000012:notes:51]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, derivative instruments, and cash and cash equivalents.

[0000866374-26-000012:notes:52]
Customer Credit Risk

[0000866374-26-000012:notes:53]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer-related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-26-000012:notes:54]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2026, 2025 and 2024:

[0000866374-26-000012:notes:55]
|  | Balance atBeginningof Year |  | Charges (Recoveries) to Costs and Expenses (1) |  | Deductions/Write-Offs |  | Balance atEnd ofYear |
|  | (In millions) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2024 | $ | 6 |  |  | $ | 9 |  |  | $ | (3) |  |  | $ | 12 |  |
| Year ended March 31, 2025 | 12 |  |  | (1) |  |  | (4) |  |  | 7 |  |
| Year ended March 31, 2026 | 7 |  |  | 3 |  |  | (2) |  |  | 8 |  |

[0000866374-26-000012:notes:56]
(1)Charges and recoveries incurred during fiscal years 2026, 2025 and 2024 are primarily for costs and expenses or bad debt recoveries related to various distressed customers.

[0000866374-26-000012:notes:57]
No customer accounted for greater than 10% of the Company's net sales in fiscal years 2026, 2025 or 2024. A single customer accounted for 16% of the Company's total balance of accounts receivable, net as of fiscal year ended March 31, 2026, which is almost entirely within the CPI segment. No other customers accounted for greater than 10% during the same period. No customer accounted for greater than 10% of the Company's total balance of accounts receivable, net as of the fiscal years ended March 31, 2025 or March 31, 2024.

[0000866374-26-000012:notes:58]
The Company's ten largest customers accounted for 45%, 44% and 37%, of its net sales in fiscal years 2026, 2025 and 2024, respectively.

[0000866374-26-000012:notes:59]
Derivative Instruments

[0000866374-26-000012:notes:60]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 10.

[0000866374-26-000012:notes:61]
Cash and Cash Equivalents

[0000866374-26-000012:notes:62]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-26-000012:notes:63]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-26-000012:notes:64]
Cash and cash equivalents consisted of the following:

[0000866374-26-000012:notes:65]
|  | As of March 31, |
|  | 2026 |  | 2025 |
|  | (In millions) |
| Cash and bank balances | $ | 745 |  |  | $ | 754 |  |
| Money market funds and time deposits | 1,644 |  |  | 1,535 |  |
|  | $ | 2,389 |  |  | $ | 2,289 |  |

[0000866374-26-000012:notes:66]
Inventories

[0000866374-26-000012:notes:67]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or net realizable value write-downs, were as follows:

[0000866374-26-000012:notes:68]
|  | As of March 31, |
|  | 2026 |  | 2025 |
|  | (In millions) |
| Raw materials | $ | 4,834 |  |  | $ | 4,092 |  |
| Work-in-progress | 474 |  |  | 485 |  |
| Finished goods | 537 |  |  | 494 |  |
|  | $ | 5,845 |  |  | $ | 5,071 |  |

[0000866374-26-000012:notes:69]
In addition to the Flex controlled inventory shown above, the Company held inventory controlled by customers of $1.3 billion, $416 million and $77 million as of fiscal year ended March 31, 2026, 2025 and 2024, respectively. These amounts are reported in other current assets in the consolidated balance sheets.

[0000866374-26-000012:notes:70]
Property and Equipment, Net

[0000866374-26-000012:notes:71]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are depreciated over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment is comprised of the following:

[0000866374-26-000012:notes:72]
|  | Depreciable Life(In Years) |  | As of March 31, |
|  |  | 2026 |  | 2025 |
|  |  |  | (In millions) |
| Machinery and equipment | 2 - 10 |  | $ | 4,058 |  |  | $ | 3,978 |  |
| Buildings | 30 |  | 1,414 |  |  | 1,342 |  |
| Leasehold improvements | Shorter of lease term or useful life of the improvement |  | 676 |  |  | 669 |  |
| Furniture, fixtures, computer equipment and software, and other | 3 - 7 |  | 570 |  |  | 564 |  |
| Land | — |  | 126 |  |  | 126 |  |
| Construction-in-progress | — |  | 459 |  |  | 271 |  |
|  |  |  | 7,303 |  |  | 6,950 |  |
| Accumulated depreciation and amortization |  |  | (4,798) |  |  | (4,620) |  |
| Property and equipment, net |  |  | $ | 2,505 |  |  | $ | 2,330 |  |

[0000866374-26-000012:notes:73]
Total depreciation expense associated with property and equipment was $457 million, $439 million and $428 million in fiscal years 2026, 2025 and 2024, respectively.

[0000866374-26-000012:notes:74]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-26-000012:notes:75]
Deferred Income Taxes

[0000866374-26-000012:notes:76]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-26-000012:notes:77]
Accounting for Business and Asset Acquisitions

[0000866374-26-000012:notes:78]
The Company has strategically pursued business and asset acquisitions. For business combinations, the fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill and if the fair value of assets acquired and liabilities assumed exceeds the purchase consideration a gain on bargain purchase is recognized.

[0000866374-26-000012:notes:79]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-26-000012:notes:80]
Goodwill

[0000866374-26-000012:notes:81]
During the fourth quarter of fiscal year 2026, the Company's reporting unit structure was updated to reflect growth of Flex's data center-related businesses, resulting in a change to its reportable segments. Segment information for prior periods has been retrospectively recast to conform to current period presentation. The Company’s operating and reporting segments now consist of three segments, ITS, RMS and CPI. Refer to note 1 "Organization of the Company" for further details.

[0000866374-26-000012:notes:82]
The Company evaluates goodwill for impairment at the reporting unit level annually, and in certain circumstances such as a change in reporting units or whenever there are indications that goodwill might be impaired. The Company performed its annual goodwill impairment assessment before and after the reorganization during the fourth quarter of fiscal year 2026 and as a result of the quantitative assessments of its goodwill, the Company determined that no impairment existed immediately before or after the reorganization because the fair value of each of the reporting units exceeded its respective carrying value.

[0000866374-26-000012:notes:83]
Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market valuations, market multiples for comparable companies as well as a discounted cash flow analysis. Certain of these approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require management to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider the Company's budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of the Company's goodwill.

[0000866374-26-000012:notes:84]
If the recorded value of the assets, including goodwill, and liabilities ("net book value") of any reporting unit exceeds its fair value, an impairment loss may be required to be recognized.

[0000866374-26-000012:notes:85]
The following table summarizes the activity in the Company's goodwill during fiscal years 2026 and 2025:

[0000866374-26-000012:notes:86]
|  |  | ITS |  | RMS |  |  |  | CPI |  | Total |
|  |  | (In millions) |
| Balance at March 31, 2024 |  | $ | 229 |  |  | $ | 490 |  |  |  |  | $ | 416 |  |  | $ | 1,135 |  |
| Acquisitions (1) |  | 8 |  |  | — |  |  |  |  | 201 |  |  | 209 |  |
| Foreign currency translation adjustments |  | — |  |  | — |  |  |  |  | (3) |  |  | (3) |  |
| Balance at March 31, 2025 |  | 237 |  |  | 490 |  |  |  |  | 614 |  |  | 1,341 |  |
| Acquisitions (2) |  | — |  |  | — |  |  |  |  | 8 |  |  | 8 |  |
| Foreign currency translation adjustments |  | 2 |  |  | 29 |  |  |  |  | (11) |  |  | 20 |  |
| Balance at March 31, 2026 |  | $ | 239 |  |  | $ | 519 |  |  |  |  | $ | 611 |  |  | $ | 1,369 |  |

[0000866374-26-000012:notes:87]
(1)Represents goodwill of $170 million from the Crown acquisition, $31 million from the JetCool acquisition and $8 million from an acquisition completed in the first quarter of fiscal year 2025.

[0000866374-26-000012:notes:88]
(2)Represents goodwill of $8 million from an acquisition of a manufacturing business in Bielsko Biala, Poland in the first quarter of fiscal year 2026. Refer to note 19 for further details.

[0000866374-26-000012:notes:89]
Other Intangible Assets

[0000866374-26-000012:notes:90]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2026 and concluded that such amounts continued to be recoverable.

[0000866374-26-000012:notes:91]
Intangible assets are comprised of customer-related intangible assets that include contractual agreements and customer relationships, and licenses and other intangible assets that are primarily comprised of licenses, patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight-line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability. During fiscal year 2026, acquisitions added $2 million to the value of intangible assets. Refer to note 19 for additional information.

[0000866374-26-000012:notes:92]
The components of acquired intangible assets are as follows:

[0000866374-26-000012:notes:93]
|  | As of March 31, 2026 |  | As of March 31, 2025 |
|  | Weighted-Average Remaining Useful life (in Years) |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  |  |  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | 8.1 |  | $ | 317 |  |  | $ | (156) |  |  | $ | 161 |  |  | $ | 383 |  |  | $ | (186) |  |  | $ | 197 |  |
| Licenses and other intangibles | 6.0 |  | 198 |  |  | (76) |  |  | 122 |  |  | 365 |  |  | (219) |  |  | 146 |  |
| Total |  |  | $ | 515 |  |  | $ | (232) |  |  | $ | 283 |  |  | $ | 748 |  |  | $ | (405) |  |  | $ | 343 |  |

[0000866374-26-000012:notes:94]
Total intangible asset amortization expense recognized in operations during fiscal years 2026, 2025 and 2024 was $68 million, $70 million and $70 million, respectively. The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2026, the gross carrying amounts of fully amortized intangible assets totaled $254 million. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-26-000012:notes:95]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2027 | $ | 58 |  |
| 2028 | 44 |  |
| 2029 | 41 |  |
| 2030 | 36 |  |
| 2031 | 32 |  |
| Thereafter | 72 |  |
| Total amortization expense | $ | 283 |  |

[0000866374-26-000012:notes:96]
The Company owns or licenses various United States and foreign patents relating to a variety of technologies. For certain of the Company's proprietary processes, inventions, and works of authorship, the Company relies on trade secret or copyright protection. The Company also maintains trademark rights (including registrations) for the Company's corporate name and several other trademarks and service marks that the Company uses in the Company's business in the United States and other countries throughout the world. The Company has policies and procedures (including both technological means and training programs for the Company's employees) to identify and protect the Company's intellectual property, as well as that of the Company's customers and suppliers.

[0000866374-26-000012:notes:97]
Derivative Instruments and Hedging Activities

[0000866374-26-000012:notes:98]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Cash receipts and cash payments related to derivative instruments are recorded in the same category as the cash flows from the items being hedged on the consolidated statements of cash flows. Additional information is included in note 10.

[0000866374-26-000012:notes:99]
Investments

[0000866374-26-000012:notes:100]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other non-current assets. These privately held companies range from startups to

[0000866374-26-000012:notes:101]
more mature companies with established revenue streams and business models. As of March 31, 2026 and 2025, the Company's investments in non-consolidated companies totaled $67 million and $119 million, respectively.

[0000866374-26-000012:notes:102]
The Company recognized $31 million and $3 million of equity in losses, associated with its equity method investments, in Equity in earnings (losses) of unconsolidated affiliates on the consolidated statements of operations during fiscal years 2026 and 2025, respectively. The increase during fiscal year 2026 was primarily driven by a $25 million loss related to the continuing investment in a specific venture capital fund. Additionally, during fiscal year 2026, a $21 million impairment loss related to a different specific venture capital fund was recognized, which is included in Other charges (income), net on the consolidated statements of operations.

[0000866374-26-000012:notes:103]
Non-consolidated investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage generally equal to or greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. Cost method is used for investments where the Company does not have the ability to significantly influence the operating decisions of the investee, or if the Company’s investment is in securities other than common stock or in-substance common stock.

[0000866374-26-000012:notes:104]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy, and require management to make various judgmental assumptions primarily about comparable company multiples and discounted cash flow projections. Some of the inherent estimates and assumptions used in determining the fair value of the investments are outside the control of management. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the investments, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of investments.

[0000866374-26-000012:notes:105]
For investments accounted for under the cost method that do not have readily determinable fair values, the Company measures them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-26-000012:notes:106]
Customer Working Capital Advances

[0000866374-26-000012:notes:107]
Customer working capital advances were $1.8 billion and $1.6 billion, as of March 31, 2026 and 2025, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-26-000012:notes:108]
Other non-current assets

[0000866374-26-000012:notes:109]
Other non-current assets include deferred tax assets of $538 million and $577 million as of March 31, 2026 and 2025, respectively.

[0000866374-26-000012:notes:110]
Other Current Liabilities

[0000866374-26-000012:notes:111]
Other current liabilities include customer-related accruals of $355 million and $246 million as of March 31, 2026 and 2025, respectively.

[0000866374-26-000012:notes:112]
Supplier Finance Programs

[0000866374-26-000012:notes:113]
The Company has six supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to its suppliers while also providing its suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due dates. The Company's suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and the Company's rights and obligations to its suppliers are not impacted by our suppliers’ decisions to sell amounts under these

[0000866374-26-000012:notes:114]
programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. The Company has no economic interest in a supplier’s decision to participate in the supplier finance programs.

[0000866374-26-000012:notes:115]
Obligations under these programs are classified within accounts payable on the consolidated balance sheets, with the associated payments reflected in the operating activities section of the consolidated statements of cash flows. The roll-forward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the fiscal years ended March 31, 2026 and March 31, 2025 are as follows:

[0000866374-26-000012:notes:116]
|  |  | Fiscal Year Ended |
|  |  | March 31, 2026 |  | March 31, 2025 |
|  |  | (In millions) |
| Confirmed obligations outstanding at the beginning of the year |  | $ | 119 |  |  | $ | 123 |  |
| Invoices confirmed during the year |  | 571 |  |  | 574 |  |
| Confirmed invoices paid during the year |  | (543) |  |  | (569) |  |
| Foreign currency exchange impact |  | 7 |  |  | (9) |  |
| Confirmed obligations outstanding at the end of the year |  | $ | 154 |  |  | $ | 119 |  |

[0000866374-26-000012:notes:117]
Leases

[0000866374-26-000012:notes:118]
The Company is a lessee with several non-cancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. The Company determines if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the Company has the right to control the use of the identified asset. The Company recognizes a right-of-use ("ROU") asset and a lease liability at the lease commencement date for the Company's operating leases. For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at the lease commencement date. The Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and non-lease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for the Company's leases, the Company uses the Company's estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company's estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company's leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-26-000012:notes:119]
As of March 31, 2026 and 2025, current operating lease liabilities were $149 million and $135 million, respectively, which are included in other current liabilities on the consolidated balance sheets.

[0000866374-26-000012:notes:120]
Restructuring Charges

[0000866374-26-000012:notes:121]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and reduce excess workforce capacity. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-26-000012:notes:122]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no over or under accruals are retained, and the utilization of the

[0000866374-26-000012:notes:123]
provisions are for their intended purpose in accordance with developed restructuring plans. See note 16 for additional information regarding restructuring charges.

[0000866374-26-000012:notes:124]
Recently Issued Accounting Pronouncements

[0000866374-26-000012:notes:125]
In November 2024, the FASB issued ASU 2024-03 "Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses", which requires public entities to disclose specified information about certain costs and expenses. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2028 and will be applied retrospectively to all prior periods presented on its consolidated financial statements. The Company is currently evaluating the guidance to determine the impact on the Company's disclosures. In January 2025, the FASB issued ASU 2025-01 on the same topic to clarify the amendments for ASU 2024-03 are effective for the Company in the fourth quarter of fiscal year 2028.

[0000866374-26-000012:notes:126]
In December 2025, the FASB issued ASU 2025-12 "Codification Improvements", which includes numerous refinements and enhancements, including clarifications on the accounting for the retirement of treasury stock among others. The guidance is effective for the Company beginning in the first quarter of fiscal year 2028. The Company is currently evaluating the guidance to determine the method of adoption and impact on the Company's disclosures.

[0000866374-26-000012:notes:127]
Recently Adopted Accounting Pronouncements

[0000866374-26-000012:notes:128]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and income taxes paid both in the U.S. and foreign jurisdictions. This standard improves the transparency of income tax disclosures by requiring consistent categories and greater disaggregation of information in the effective tax rate reconciliation and income taxes paid disaggregated by jurisdiction. It also includes certain other amendments to improve the effectiveness of income tax disclosures. The adoption of this new standard did not have a material impact on the Company's consolidated financial statements and was adopted on a prospective basis as it is effective for the Company, beginning in the fourth quarter of fiscal year 2026. For additional information, see note 15 - "Income Taxes."

[0000866374-26-000012:notes:129]
In July 2025, the FASB issued ASU 2025-05 "Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets", which provides for the use of a new practical expedient when estimating expected credit losses for accounts receivable and contract assets arising from transactions accounted for under Topic 606 that assumes that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for the Company, and has been adopted, beginning in the second quarter of fiscal year 2026.


## us-gaap:DerivativesPolicyTextBlock

[0000866374-26-000012:notes:130]
Derivative Instruments
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions.
Derivative Instruments and Hedging Activities
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Cash receipts and cash payments related to derivative instruments are recorded in the same category as the cash flows from the items being hedged on the consolidated statements of cash flows.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-26-000012:notes:131]
LEASES
The Company has several commitments under operating leases for warehouses, buildings, and equipment. The Company also has a number of finance leases with an immaterial impact on its consolidated financial statements. Leases have remaining lease terms ranging from approximately 1 year to 18 years.

[0000866374-26-000012:notes:132]
The components of lease cost recognized were as follows (in millions):

[0000866374-26-000012:notes:133]
| Lease cost | Fiscal Year Ended |
|  | March 31, 2026 |  | March 31, 2025 |
| Operating lease cost | $ | 179 |  |  | $ | 173 |  |

[0000866374-26-000012:notes:134]
Amounts reported in the consolidated balance sheet as of the fiscal years ended March 31, 2026 and 2025 were (in millions, except weighted average lease term and discount rate):

[0000866374-26-000012:notes:135]
|  | As of March 31, 2026 |  | As of March 31, 2025 |
| Operating Leases: |  |  |  |
| Operating lease right-of-use assets | $ | 659 |  | $ | 562 |
| Operating lease liabilities * | 714 |  | 591 |
| Weighted-average remaining lease term (in years) |  |  |  |
| Operating leases | 6.2 |  | 6.0 |
| Weighted-average discount rate |  |  |  |
| Operating leases | 4.4 | % |  | 4.4 | % |

[0000866374-26-000012:notes:136]
*Operating lease liabilities includes $149 million reported in Other current liabilities and $565 million reported in Operating lease liabilities, non-current, within the consolidated balance sheets.

[0000866374-26-000012:notes:137]
Other information related to leases was as follows (in millions):

[0000866374-26-000012:notes:138]
|  | Fiscal Year Ended |
|  | March 31, 2026 |  | March 31, 2025 |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 175 |  |  | $ | 168 |  |
| Right‑of‑use assets obtained in exchange for lease liabilities: |  |  |  |
| Operating leases | $ | 227 |  |  | $ | 106 |  |

[0000866374-26-000012:notes:139]
Future lease payments under non-cancellable leases as of March 31, 2026 were as follows (in millions):

[0000866374-26-000012:notes:140]
| Fiscal Year Ended March 31, | Operating Leases |
| 2027 | $ | 176 |  |
| 2028 | 156 |  |
| 2029 | 127 |  |
| 2030 | 100 |  |
| 2031 | 79 |  |
| Thereafter | 176 |  |
| Total undiscounted lease payments | 814 |  |
| Less: imputed interest | 100 |  |
| Total lease liabilities | $ | 714 |  |

[0000866374-26-000012:notes:141]
Total rent expense amounted to $213 million, $194 million and $188 million in fiscal years 2026, 2025 and 2024, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-26-000012:notes:142]
REVENUE
Revenue Recognition

[0000866374-26-000012:notes:143]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements ("MSAs") with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents

[0000866374-26-000012:notes:144]
such as a statement of work, product addendum, forecast commitments, emails or other communications that embody the commitment by the customer.

[0000866374-26-000012:notes:145]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract are transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Service contract revenue is recognized on an overtime basis using the output method.

[0000866374-26-000012:notes:146]
Customer Contracts and Related Obligations

[0000866374-26-000012:notes:147]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-26-000012:notes:148]
Performance Obligations

[0000866374-26-000012:notes:149]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

[0000866374-26-000012:notes:150]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-26-000012:notes:151]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is

[0000866374-26-000012:notes:152]
required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately. As most of our contracts have an expected duration of one year or less, we have applied the practical expedient such that specified disclosures pertaining to remaining performance obligations are not required.

[0000866374-26-000012:notes:153]
Contract Balances

[0000866374-26-000012:notes:154]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to receivables when rights to payment become unconditional and invoiced.

[0000866374-26-000012:notes:155]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $431 million and $377 million as of March 31, 2026 and 2025, respectively, of which $362 million and $347 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-26-000012:notes:156]
Warrant

[0000866374-26-000012:notes:157]
During the second quarter of fiscal year 2026, the Company issued a warrant (“the Warrant”) to a customer for the purchase of up to an aggregate of 3.9 million ordinary shares of the Company ("Warrant Shares"). The Warrant Shares vest based on qualifying payments (as defined in the Warrant) for the purchase of all products and services over the term of the Warrant and are recognized as a deduction to revenue as qualifying revenues are recognized. Refer to note 5 "Share-Based Compensation and Warrants" for additional information.

[0000866374-26-000012:notes:158]
Disaggregation of Revenue

[0000866374-26-000012:notes:159]
The following table presents the Company’s revenue disaggregated based on timing of transfer - PIT and OT for the fiscal years ended March 31, 2026, 2025 and 2024:

[0000866374-26-000012:notes:160]
|  | Fiscal Year Ended March 31, |
|  | 2026 (1) |  | 2025 (1) |  | 2024 |
| Timing of Transfer | (In millions) |
| ITS |  |  |  |  |  |
| Point in time | $ | 6,984 |  |  | $ | 8,479 |  |  | $ | 11,535 |  |
| Over time | 4,125 |  |  | 2,857 |  |  | 1,101 |  |
| Total | 11,109 |  |  | 11,336 |  |  | 12,636 |  |
| RMS |  |  |  |  |  |
| Point in time | 5,867 |  |  | 6,914 |  |  | 9,749 |  |
| Over time | 4,324 |  |  | 2,764 |  |  | 786 |  |
| Total | 10,191 |  |  | 9,678 |  |  | 10,535 |  |
| CPI |  |  |  |  |  |
| Point in time | 6,160 |  |  | 4,688 |  |  | 3,233 |  |
| Over time | 454 |  |  | 111 |  |  | 11 |  |
| Total | 6,614 |  |  | 4,799 |  |  | 3,244 |  |
| Flex |  |  |  |  |  |
| Point in time | 19,011 |  |  | 20,081 |  |  | 24,517 |  |
| Over time | 8,903 |  |  | 5,732 |  |  | 1,898 |  |
| Total | $ | 27,914 |  |  | $ | 25,813 |  |  | $ | 26,415 |  |

[0000866374-26-000012:notes:161]
(1)Certain existing customer contractual relationships changed to provide an enforceable right to payment for work completed to date that had the effect of transitioning revenue with those customers from being recognized on a point in time to an over time basis, with prospective effect. This change had the effect of increasing contract assets by $206 million and $232 million as of March 31, 2026 and 2025, respectively. Contract assets are generally transferred to receivables in the succeeding quarter due to the short-term nature of the Company’s manufacturing cycle.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-26-000012:notes:162]
SHARE-BASED COMPENSATION AND WARRANTS
Equity Compensation Plan

[0000866374-26-000012:notes:163]
Flex maintains stock-based compensation plans at the corporate level. The Company grants equity compensation awards under its 2017 Equity Incentive Plan (as amended, the "2017 Plan").

[0000866374-26-000012:notes:164]
Stock-Based Compensation Expense

[0000866374-26-000012:notes:165]
The following table summarizes the Company's stock-based compensation expense for the 2017 Plan:

[0000866374-26-000012:notes:166]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions) |
| Cost of sales | $ | 34 |  |  | $ | 32 |  |  | $ | 28 |  |
| Selling, general and administrative expenses | 108 |  |  | 93 |  |  | 85 |  |
| Total share-based compensation expense | $ | 142 |  |  | $ | 125 |  |  | $ | 113 |  |

[0000866374-26-000012:notes:167]
Cash flows related to tax benefits from stock-based compensation are classified as operating cash flows. During fiscal year 2026 and fiscal year 2025, the Company recognized $15 million and $14 million of tax benefits associated with stock-based compensation expense as an operating cash inflow. No such tax benefits were recognized in fiscal year 2024.

[0000866374-26-000012:notes:168]
The 2017 Plan

[0000866374-26-000012:notes:169]
As of March 31, 2026, the Company had 14.8 million shares available for grant under the 2017 Plan. The Company grants restricted share unit ("RSU") awards under its 2017 Plan. RSU awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. RSU awards generally vest in installments over three years, and unvested RSU awards are generally forfeited upon termination of employment.

[0000866374-26-000012:notes:170]
Vesting for certain RSU awards is contingent upon both service and market conditions or both service and performance conditions.

[0000866374-26-000012:notes:171]
As of March 31, 2026, the total unrecognized compensation cost related to unvested RSU awards under the 2017 Plan was $188 million. These costs will be amortized generally on a straight-line basis over a weighted-average period of two years. $14 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain market conditions. $39 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain performance conditions.

[0000866374-26-000012:notes:172]
Determining Fair Value - RSU awards

[0000866374-26-000012:notes:173]
Valuation and Amortization Method—The fair market value of RSU awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-26-000012:notes:174]
Determining Fair Value - RSU awards with service and market conditions

[0000866374-26-000012:notes:175]
Valuation and Amortization Method—The Company estimates the fair value of RSU awards granted under the 2017 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-26-000012:notes:176]
Expected Volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the RSU awards granted. The service period is three years for those RSU awards granted in fiscal years 2026, 2025, and 2024.

[0000866374-26-000012:notes:177]
Average Peer Volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of Flex's peer companies for the RSU awards granted in fiscal years 2026, 2025, and 2024.

[0000866374-26-000012:notes:178]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to Flex's peer companies for the RSU awards granted in fiscal years 2026, 2025, and 2024.

[0000866374-26-000012:notes:179]
Expected Dividend —The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-26-000012:notes:180]
Risk-Free Interest Rate Assumptions—The Company bases the risk-free interest rate used in the Monte Carlo simulation on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the RSU awards.

[0000866374-26-000012:notes:181]
The fair value of the Company's RSU awards under the 2017 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2026, 2025, and 2024 was estimated using the following weighted-average assumptions:

[0000866374-26-000012:notes:182]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Expected volatility | 38.1 | % |  | 34.6 | % |  | 36.9 | % |
| Average peer volatility | 37.6 | % |  | 34.0 | % |  | 35.2 | % |
| Average peer correlation | 0.3 |  | 0.3 |  | 0.4 |
| Risk-free interest rate | 3.9 | % |  | 4.4 | % |  | 4.3 | % |

[0000866374-26-000012:notes:183]
Share-Based Awards Activity

[0000866374-26-000012:notes:184]
The following table summarizes the Company's RSU award activity under the 2017 Plan ("Price" reflects the weighted-average grant-date fair value):

[0000866374-26-000012:notes:185]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested RSU awards outstanding, beginning of fiscal year | 11,731,235 |  |  | $ | 24.96 |  |  | 15,367,056 |  |  | $ | 17.73 |  |  | 15,348,615 |  |  | $ | 16.79 |  |
| Granted (1) | 4,227,640 |  |  | 45.52 |  |  | 5,747,499 |  |  | 33.38 |  |  | 6,162,067 |  |  | 27.86 |  |
| Vested (1) | (7,109,890) |  |  | 19.95 |  |  | (8,213,127) |  |  | 16.46 |  |  | (8,529,857) |  |  | 14.34 |  |
| Forfeited (2) | (611,930) |  |  | 30.04 |  |  | (1,170,193) |  |  | 20.88 |  |  | (994,150) |  |  | 19.76 |  |
| Nextracker spin-off adjustment (3) (4) | — |  |  |  |  | — |  |  |  |  | 3,380,381 |  |  |  |
| Unvested RSU awards outstanding, end of fiscal year | 8,237,055 |  |  | $ | 35.67 |  |  | 11,731,235 |  |  | $ | 24.96 |  |  | 15,367,056 |  |  | $ | 17.73 |  |

[0000866374-26-000012:notes:186]
(1)Included in fiscal years 2026, 2025 and 2024, amounts are 1.0 million, 0.7 million and 1.2 million of share bonus awards representing the number of awards achieved above target levels based on the achievement of certain market and performance conditions for awards granted in fiscal years 2023, 2022 and 2021, respectively. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-26-000012:notes:187]
(2)Fiscal year 2024, includes immaterial RSU awards previously granted to Nextracker employees under the 2017 Plan and subsequently canceled in connection with the Nextracker spin-off.

[0000866374-26-000012:notes:188]
(3)Represents an adjustment to the outstanding RSU awards under the terms of the 2017 Plan using a conversion ratio of approximately 1.29 as a result of the Nextracker spin-off.

[0000866374-26-000012:notes:189]
(4)The weighted-average grant date fair value of the RSUs is equal to the weighted-average grant date fair value of the awards at their respective grant date divided by a factor of approximately 1.29. The weighted-average grant date fair value of the unvested RSUs as of March 31, 2024 reflects the adjustment.

[0000866374-26-000012:notes:190]
Of the 4.2 million unvested RSU awards granted in fiscal year 2026, 2.0 million are plain-vanilla unvested RSU awards with no performance or market conditions with an average grant date price of $44.30 per share. Further, 0.2 million of these unvested RSU awards granted in fiscal year 2026 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions, with an average grant date fair value estimated to be $58.55 per award calculated using a Monte Carlo simulation. Vesting information for these shares is further detailed in the table below.

[0000866374-26-000012:notes:191]
Of the 8.2 million unvested RSU awards outstanding under the 2017 Plan as of the fiscal year ended March 31, 2026, 0.8 million unvested RSU awards represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-26-000012:notes:192]
|  |  | Targetnumber ofawards as ofMarch 31, 2026(in shares) (1) |  |  |  |  |  | Range of sharesthat may be issued (2) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment dates |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2026 |  | 220,101 |  |  | $ | 58.55 |  |  |  |  | — |  |  | 440,202 |  |  | June 2028 |
| Fiscal 2025 |  | 253,047 |  |  | $ | 42.36 |  |  |  |  | — |  |  | 506,094 |  |  | June 2027 |
| Fiscal 2024 |  | 342,759 |  |  | $ | 35.55 |  |  |  |  | — |  |  | 685,518 |  |  | June 2026 |
| Totals |  | 815,907 |  |  |  |  |  |  |  |  | 1,631,814 |  |  |  |

[0000866374-26-000012:notes:193]
(1)    Fiscal 2024 target number of awards includes an adjustment to the outstanding RSU awards under the terms of the 2017 Plan using a conversion ratio of approximately 1.29 as a result of the Nextracker spin-off.

[0000866374-26-000012:notes:194]
(2)    Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against Flex's peer companies for RSU awards granted in fiscal years 2026, 2025 and 2024.

[0000866374-26-000012:notes:195]
The Company will continue to recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2026, 2.3 million shares vested in connection with the awards with market and performance conditions granted in fiscal year 2023.

[0000866374-26-000012:notes:196]
1.0 million of these unvested RSU awards granted in fiscal year 2026 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, with an average grant date price of $44.30 per share. Vesting information for these shares is further detailed in the table below.

[0000866374-26-000012:notes:197]
Of the 8.2 million unvested RSU awards outstanding under the 2017 Plan as of the fiscal year ended March 31, 2026, 1.7 million unvested RSU awards represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain performance conditions summarized as follows:

[0000866374-26-000012:notes:198]
|  |  | Targetnumber ofawards as ofMarch 31, 2026(in shares) (1) |  |  |  |  |  | Range of sharesthat may be issued (2) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment date |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2026 |  | 977,347 |  |  | $ | 45.09 |  |  |  |  | — |  |  | 2,393,131 |  |  | Mar 2029 |
| Fiscal 2025 |  | 405,663 |  |  | $ | 31.14 |  |  |  |  | — |  |  | 811,326 |  |  | Mar 2028 |
| Fiscal 2024 |  | 343,056 |  |  | $ | 26.67 |  |  |  |  | — |  |  | 686,112 |  |  | Mar 2027 |
| Totals |  | 1,726,066 |  |  |  |  |  |  |  |  | 3,890,569 |  |  |  |

[0000866374-26-000012:notes:199]
(2)    Vesting ranges from zero to 250% based on performance of Company's average adjusted earnings per share growth.

[0000866374-26-000012:notes:200]
The total intrinsic value of RSU awards vested under the Company's 2017 Plan was $330 million, $260 million and $227 million during fiscal years 2026, 2025 and 2024, respectively, based on the closing price of the Company's ordinary shares on the date vested.

[0000866374-26-000012:notes:201]
On August 15, 2025, the Company issued the Warrant to Amazon.com NV Investment Holdings LLC (“Warrantholder”), a wholly-owned subsidiary of Amazon.com, Inc. ("Parent") to purchase up to an aggregate of 3,859,851 Warrant Shares at an exercise price of $51.29 per share, which is the preceding 30 trading days Volume-Weighted Average Price. The Warrant allows for cashless exercise and expires on August 15, 2030; however, if there are unexercised Warrant Shares as of the expiration date, and the Company and Warrantholder maintain a continued commercial relationship, the Company shall negotiate in good faith with Warrantholder to agree to issue to Warrantholder a new two-year warrant as of the expiration date that provides the same exercise price and other terms for vested and unexercised Warrant Shares, that also takes into account the commercial relationship in effect at such time. The Warrant Shares are subject to vesting based on qualifying payments (as defined in the Warrant) for the purchase of all products and services by or on behalf of Parent and its affiliates over the term of the Warrant. Upon the consummation of an acquisition transaction (as defined in the related transaction agreement), subject to a specified condition, the unvested portion of the Warrant will vest in full. So long as the Warrant is unexercised, the Warrant

[0000866374-26-000012:notes:202]
does not entitle Warrantholder to any voting rights or any other shareholder rights. The exercise price and the number of Warrant Shares are subject to customary anti-dilution adjustments. The expense associated with the Warrant Shares will be recorded as a deduction to revenue as the customer purchases products and services over the vesting period.

[0000866374-26-000012:notes:203]
The estimated fair value of the Warrant was determined as of the issuance date, using the Black-Scholes option pricing model. The following assumptions were used in the model:

[0000866374-26-000012:notes:204]
|  | As of August 15, 2025 |
| Expected volatility | 45.8 | % |
| Expected dividend yield | — | % |
| Expected life | 7 years |
| Risk-free interest rate | 4.0 | % |

[0000866374-26-000012:notes:205]
The calculated fair value of each Warrant Share at the issuance date was $25.47. The Company recorded charges of $7 million during the fiscal year ended March 31, 2026. As of March 31, 2026, no Warrant Shares have vested or been exercised.


## us-gaap:EarningsPerShareTextBlock

[0000866374-26-000012:notes:206]
EARNINGS PER SHARE
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-26-000012:notes:207]
Diluted earnings per share reflects the potential dilution from share-based compensation awards and warrants. The potential dilution was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-26-000012:notes:208]
The computation of earnings per share and weighted average shares outstanding of the Company’s ordinary shares for the following periods is presented below:

[0000866374-26-000012:notes:209]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions, except per share amounts) |
| Numerator: |  |  |  |  |  |
| Net income from continuing operations | $ | 880 |  |  | $ | 838 |  |  | $ | 872 |  |
| Net income from discontinued operations, net of tax (Note 7) | — |  |  | — |  |  | 373 |  |
| Less: Net income attributable to noncontrolling interest (Note 7) | — |  |  | — |  |  | 239 |  |
| Net income from discontinued operations attributable to Flex Ltd. (Note 7) | — |  |  | — |  |  | 134 |  |
| Total net income attributable to Flex Ltd. | $ | 880 |  |  | $ | 838 |  |  | $ | 1,006 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding - basic | 371 |  |  | 391 |  |  | 435 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 7 |  |  | 7 |  |  | 6 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding - diluted | 378 |  |  | 398 |  |  | 441 |  |
| Earnings per share - basic |  |  |  |  |  |
| Continuing operations | $ | 2.37 |  |  | $ | 2.14 |  |  | $ | 2.00 |  |
| Discontinued operations, net of tax (Note 7) | — |  |  | — |  |  | 0.31 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 2.37 |  |  | $ | 2.14 |  |  | $ | 2.31 |  |
| Earnings per share - diluted |  |  |  |  |  |
| Continuing operations | $ | 2.33 |  |  | $ | 2.11 |  |  | $ | 1.98 |  |
| Discontinued operations, net of tax (Note 7) | — |  |  | — |  |  | 0.30 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 2.33 |  |  | $ | 2.11 |  |  | $ | 2.28 |  |

[0000866374-26-000012:notes:210]
(1)An immaterial amount of RSU awards during fiscal years 2026, 2025, and 2024, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000866374-26-000012:notes:211]
DISCONTINUED OPERATIONS & NONCONTROLLING INTEREST
On January 2, 2024, Flex completed the spin-off of its remaining interests in Nextracker to Flex shareholders on a pro-rata basis based on the number of ordinary shares of Flex held by each shareholder of Flex as of December 29, 2023, which was the record date of the Distribution.

[0000866374-26-000012:notes:212]
Nextracker's financial results for periods prior to the spin-off have been reflected in the Company's consolidated statement of operations, retrospectively, as discontinued operations. Details of net income from discontinued operations included in the consolidated statements of operations are as follows:

[0000866374-26-000012:notes:213]
|  |  |  |  |  | Fiscal Year Ended March 31, |
|  |  |  |  |  | 2024 (1) |
|  |  |  |  |  | (In millions) |
| Net sales (2) |  |  |  |  | $ | 1,664 |  |
| Cost of sales (2) |  |  |  |  | 1,198 |  |
| Gross profit |  |  |  |  | 466 |  |
| Selling, general and administrative expenses |  |  |  |  | 145 |  |
| Intangible amortization |  |  |  |  | — |  |
| Operating income |  |  |  |  | 321 |  |
| Interest, net |  |  |  |  | 1 |  |
| Other charges (income), net |  |  |  |  | (2) |  |
| Income before income taxes |  |  |  |  | 322 |  |
| (Benefit from) provision for income taxes |  |  |  |  | (51) |  |
| Net income from discontinued operations |  |  |  |  | 373 |  |
| Net income from discontinued operations attributable to noncontrolling interest (3) |  |  |  |  | 239 |  |
| Net income from discontinued operations attributable to Flex Ltd. |  |  |  |  | $ | 134 |  |

[0000866374-26-000012:notes:214]
(1)Represents the financial results for the nine-month period prior to the Nextracker spin-off. The financial results for the period from January 1, 2024 to the spin-off date were immaterial.

[0000866374-26-000012:notes:215]
(2)Both net sales and cost of sales from discontinued operations includes the effect of intercompany transactions that were eliminated from Flex's consolidated operations of approximately $99 million for the fiscal year ended March 31, 2024.

[0000866374-26-000012:notes:216]
(3)Net income from discontinued operations attributable to noncontrolling interest represented a share of pre-tax income of $145 million and of an income tax benefit of $94 million. As such, pre-tax income attributable to Flex Ltd. from discontinued operations was $177 million in fiscal year 2024.

[0000866374-26-000012:notes:217]
Details of cash flows from discontinued operations are as follows:

[0000866374-26-000012:notes:218]
|  |  |  |  |  | Fiscal Year Ended March 31, |
|  |  |  |  |  | 2024 (1) |
|  |  |  |  |  | (In millions) |
| Net cash provided by (used in) discontinued operations operating activities (2) |  |  |  |  | $ | 317 |  |
| Net cash used in discontinued operations investing activities |  |  |  |  | (4) |  |

[0000866374-26-000012:notes:219]
(1)Represents the financial results for the nine-month period prior to the Nextracker spin-off.

[0000866374-26-000012:notes:220]
(2)Cash flows from discontinued operations operating activities includes the effect of intercompany transactions that were eliminated from Flex's consolidated operations of $54 million for the fiscal year ended March 31, 2024.
Flex's noncontrolling interest related solely to Nextracker. As of March 31, 2026 and 2025, noncontrolling interest was zero. Net income attributable to noncontrolling interest was zero, zero and $239 million in fiscal years 2026, 2025, and 2024, respectively.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-26-000012:notes:221]
SUPPLEMENTAL CASH FLOW DISCLOSURES
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-26-000012:notes:222]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 212 |  |  | $ | 214 |  |  | $ | 226 |  |
| Income taxes | 323 |  |  | 184 |  |  | 243 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 174 |  |  | $ | 136 |  |  | $ | 97 |  |


## us-gaap:ScheduleOfCashFlowSupplementalDisclosuresTableTextBlock

[0000866374-26-000012:notes:223]
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-26-000012:notes:224]
Upon adoption of ASU 2023-09, Improvements to Income Tax Disclosures, as described in Note 2, Summary of Significant Accounting Policies, cash paid for income taxes, net of refunds, during the fiscal year ended March 31, 2026 was as follows:

[0000866374-26-000012:notes:225]
|  |  | Fiscal Year Ended March 31, 2026 |
|  |  | (In millions) |
| Domestic |  | $ | — |  |
| Foreign: |  |  |
| Mexico |  | 84 |  |
| China |  | 82 |  |
| Malaysia |  | 41 |  |
| Mauritius |  | 20 |  |
| United States |  | 18 |  |
| Other countries |  | 78 |  |
| Total cash paid for income taxes, net of refunds |  | $ | 323 |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-26-000012:notes:226]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt are as follows:

[0000866374-26-000012:notes:227]
|  | Maturity Date |  | As of March 31, |
|  |  |  | 2026 |  | 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | — |  |  | $ | 531 |  |
| 3.750% Notes (1) | February 2026 |  | — |  |  | 678 |  |
| 6.000% Notes ("2028 Notes") (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes ("2029 Notes") (1) | June 2029 |  | 654 |  |  | 655 |  |
| 4.875% Notes ("2030 Notes") (1) | May 2030 |  | 671 |  |  | 676 |  |
| 5.250% Notes ("2032 Notes") (1) (2) | January 2032 |  | 651 |  |  | 499 |  |
| 5.375% Notes ("2035 Notes") (1) (2) | November 2035 |  | 598 |  |  | — |  |
| Delayed Draw Term Loan (3) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (4) | December 2031 |  | 296 |  |  | 269 |  |
| Debt issuance costs |  |  | (17) |  |  | (14) |  |
|  |  |  | 3,751 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | — |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,751 |  |  | $ | 2,483 |  |

[0000866374-26-000012:notes:228]
(1)Each note is carried at the principal amount, less any unamortized discount and unamortized debt issuance costs and inclusive of any premium. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

[0000866374-26-000012:notes:229]
(2)In November 2025, the Company issued $600 million of 5.375% Notes due November 2035 and $150 million of 5.250% Notes due January 2032.

[0000866374-26-000012:notes:230]
(3)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at the Secured Overnight Financing Rate ("SOFR") plus 100 basis points.

[0000866374-26-000012:notes:231]
(4)In December 2021, the Company issued HUF 100 billion (approximately $296 million as of March 31, 2026) in aggregate principal amount of bonds under the National Bank of Hungary’s Bond Funding for Growth Scheme. The bonds are unsecured and unsubordinated obligations of the Company and rank equally with all of the Company’s other existing and future unsecured and unsubordinated obligations. The outstanding principal amount of the bonds bear interest at 3.60% per annum. The proceeds of the bonds were used for general corporate purposes. The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

[0000866374-26-000012:notes:232]
The 2030 Credit Facility

[0000866374-26-000012:notes:233]
In July 2025, the Company entered into a new $2.75 billion credit facility (“2030 Credit Facility”) which matures in July 2030 and consists of a $2.75 billion revolving credit facility with a sub-limit of $400 million available for swing line loans and a sub-limit of $200 million available for the issuance of letters of credit. The 2030 Credit Facility replaced the previous $2.5 billion credit facility, which was due to mature in July 2027. Borrowings under the 2030 Credit Facility bear interest at the

[0000866374-26-000012:notes:234]
Company’s option at various market based rates, adjusted for the Company’s credit rating, or at the SOFR or similar non-reporting currency benchmarks based on the underlying borrowing currency, adjusted for the Company’s credit rating. The Company is required to pay a quarterly commitment fee on the unutilized portion of the 2030 Credit Facility ranging from 0.100% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.00% to 1.750% per annum, based on the Company’s credit ratings, on the daily average amount of outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit. As of March 31, 2026, no borrowings were outstanding.

[0000866374-26-000012:notes:235]
As of March 31, 2026 and 2025, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities of $797 million and $584 million in the aggregate, respectively. There were no borrowings outstanding under these facilities as of March 31, 2026 and 2025. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin.

[0000866374-26-000012:notes:236]
On April 30, 2026, the Company entered into a Credit Agreement which provides a senior delayed draw term loan credit facility in an aggregate commitment amount of $1.45 billion. Refer to note 22 "Subsequent Events" for additional information.

[0000866374-26-000012:notes:237]
Debt Covenants

[0000866374-26-000012:notes:238]
Borrowings under the Company’s debt agreements are subject to various covenants that limit the Company’s ability to incur additional indebtedness, sell assets, effect mergers and certain transactions, and effect certain transactions with subsidiaries and affiliates. In addition, the 2030 Credit Facility and delayed draw term loan also require that the Company maintain a maximum ratio of total indebtedness to EBITDA and a minimum interest coverage ratio. The Company is also subject to certain covenants requiring the Company to offer to repurchase the 2028 Notes, 2029 Notes, 2030 Notes, 2032 Notes and 2035 Notes upon a change of control. As of March 31, 2026 and 2025, the Company was in compliance with its debt covenants.

[0000866374-26-000012:notes:239]
The weighted-average interest rates for the Company's long-term debt were 4.9% and 4.6% as of March 31, 2026 and 2025, respectively.

[0000866374-26-000012:notes:240]
Scheduled repayments of the Company's bank borrowings and long-term debt are as follows:

[0000866374-26-000012:notes:241]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2027 | $ | — |  |
| 2028 | 898 |  |
| 2029 | 30 |  |
| 2030 | 683 |  |
| 2031 | 701 |  |
| Thereafter | 1,456 |  |
| Total | $ | 3,768 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-26-000012:notes:242]
FINANCIAL INSTRUMENTS
Foreign Currency Contracts

[0000866374-26-000012:notes:243]
The Company transacts business in various foreign countries and is therefore exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, forecasted sales and cost of sales, and monetary assets and liabilities in currencies other than the functional currency of the operating entity. The Company enters into short-term and long-term foreign currency derivative contracts, including forward, swap, and option contracts, to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable, accounts payable, debt, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized

[0000866374-26-000012:notes:244]
since the contracts are with large financial institutions and, accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-26-000012:notes:245]
As of March 31, 2026, the aggregate notional amount of the Company's outstanding foreign currency derivative contracts was $7.5 billion as summarized below:

[0000866374-26-000012:notes:246]
|  |  |  | Notional ContractValue in USD |
| Currency |  |  |  |  | Buy |  | Sell |
|  |  |  |  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| MXN |  |  |  |  | $ | 632 |  |  | $ | — |  |
| HUF |  |  |  |  | 437 |  |  | — |  |
| CNY |  |  |  |  | 336 |  |  | — |  |
| Other |  |  |  |  | 550 |  |  | 8 |  |
|  |  |  |  |  | 1,955 |  |  | 8 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |
| CNY |  |  |  |  | 886 |  |  | 517 |  |
| EUR |  |  |  |  | 550 |  |  | 558 |  |
| MXN |  |  |  |  | 467 |  |  | 348 |  |
| Other |  |  |  |  | 1,204 |  |  | 1,040 |  |
|  |  |  |  |  | 3,107 |  |  | 2,463 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 5,062 |  |  | $ | 2,471 |  |

[0000866374-26-000012:notes:247]
As of March 31, 2026 and 2025, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the consolidated statements of operations. The Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were $0.7 million as of March 31, 2026, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations primarily over the next twelve-month period, except for gains attributable to changes in fair value of  the USD HUF cross currency swaps, which are discussed below.

[0000866374-26-000012:notes:248]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other current assets and other non-current liabilities as of March 31, 2026 and March 31, 2025, respectively. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-26-000012:notes:249]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2026 and 2025:

[0000866374-26-000012:notes:250]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31,2026 |  | March 31,2025 |  | Balance SheetLocation |  | March 31,2026 |  | March 31,2025 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 39 |  |  | $ | 13 |  |  | Other current liabilities |  | $ | (18) |  |  | $ | (18) |  |
| Foreign currency contracts | Other non-current assets |  | — |  |  | — |  |  | Other non-current liabilities |  | (29) |  |  | (46) |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 15 |  |  | $ | 21 |  |  | Other current liabilities |  | $ | (27) |  |  | $ | (15) |  |

[0000866374-26-000012:notes:251]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with certain counterparties. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-26-000012:notes:252]
ACCUMULATED OTHER COMPREHENSIVE LOSS
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2026, 2025 and 2024 are as follows:

[0000866374-26-000012:notes:253]
|  | Unrealized gain (loss) onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Ending balance on March 31, 2023 | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |
| Other comprehensive gain (loss) before reclassifications | 95 |  |  | (19) |  |  | 76 |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | (77) |  |  | — |  |  | (77) |  |
| Net current-period other comprehensive gain (loss) | 18 |  |  | (19) |  |  | (1) |  |
| Ending balance on March 31, 2024 | $ | 4 |  |  | $ | (199) |  |  | $ | (195) |  |
| Other comprehensive gain (loss) before reclassifications | (77) |  |  | (6) |  |  | (83) |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | 54 |  |  | — |  |  | 54 |  |
| Net current-period other comprehensive gain (loss) | (23) |  |  | (6) |  |  | (29) |  |
| Ending balance on March 31, 2025 | $ | (19) |  |  | $ | (205) |  |  | $ | (224) |  |
| Other comprehensive gain (loss) before reclassifications | 97 |  |  | 53 |  |  | 150 |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | (93) |  |  | — |  |  | (93) |  |
| Net current-period other comprehensive gain (loss) | 4 |  |  | 53 |  |  | 57 |  |
| Ending balance on March 31, 2026 | $ | (15) |  |  | $ | (152) |  |  | $ | (167) |  |

[0000866374-26-000012:notes:254]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the fiscal year 2026 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the consolidated statement of operations, which primarily relate to the Company's foreign currency contracts accounted for as cash flow hedges.
The tax impact to other comprehensive loss was immaterial for all periods presented.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-26-000012:notes:255]
TRADE RECEIVABLES SALES PROGRAMS
The Company sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was $0.5 billion and $0.7 billion as of March 31, 2026 and 2025, respectively. For the fiscal years ended March 31, 2026, 2025 and 2024, total accounts receivable sold to certain third party banking institutions was $3.1 billion, $4.0 billion and $3.6 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and the cash received was included as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-26-000012:notes:256]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-26-000012:notes:257]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000866374-26-000012:notes:258]
Level 2 - Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-26-000012:notes:259]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-26-000012:notes:260]
The Company's cash equivalents include bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-26-000012:notes:261]
Level 3 - Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-26-000012:notes:262]
The Company has accrued for contingent consideration related to an acquisition in fiscal year 2025, classified as a level 3 measurement in the fair value hierarchy due to significant unobservable inputs. Fair value is determined using internal cash flow models that incorporate unobservable inputs, including the probability of achieving performance milestones. As of March 31, 2026 and March 31, 2025, the balance of contingent consideration was $2 million and $5 million, respectively.

[0000866374-26-000012:notes:263]
The significant inputs include the Company's probability assessments of expected future revenue during the earn-out periods, associated volatility, and a discount rate reflecting uncertainties in the obligation consistent with the terms of the purchase agreement. Significant decreases in expected revenue, or increases in the discount rate or volatility, would reduce fair value estimates. The interrelationship between these inputs is not considered significant.

[0000866374-26-000012:notes:264]
During fiscal years 2026 and 2025, there were no other additions to the accrual, payments, fair value adjustments, or unrealized gains or losses included in earnings.

[0000866374-26-000012:notes:265]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other non-current assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as either level 1 or level 2, dependent on the valuation inputs, within the fair value hierarchy.

[0000866374-26-000012:notes:266]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-26-000012:notes:267]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2026 and 2025:

[0000866374-26-000012:notes:268]
|  | Fair Value Measurements as of March 31, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 1,644 |  |  | $ | — |  |  | $ | 1,644 |  |
| Foreign currency contracts (Note 10) | — |  |  | 55 |  |  | — |  |  | 55 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 35 |  |  | 13 |  |  | — |  |  | 48 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (73) |  |  | $ | — |  |  | $ | (73) |  |
| Contingent consideration in connection with acquisitions | — |  |  | — |  |  | (2) |  |  | (2) |  |

[0000866374-26-000012:notes:269]
|  | Fair Value Measurements as of March 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 1,535 |  |  | $ | — |  |  | $ | 1,535 |  |
| Foreign currency contracts (Note 10) | — |  |  | 34 |  |  | — |  |  | 34 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (79) |  |  | $ | — |  |  | $ | (79) |  |
| Contingent consideration in connection with acquisitions | — |  |  | — |  |  | (5) |  |  | (5) |  |

[0000866374-26-000012:notes:270]
Other financial instruments

[0000866374-26-000012:notes:271]
The following table presents the Company's major debts not carried at fair value as of March 31, 2026 and 2025:

[0000866374-26-000012:notes:272]
|  | As of March 31, 2026 |  | As of March 31, 2025 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In millions) |  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | — |  |  | $ | — |  |  | $ | 531 |  |  | $ | 531 |  |  | Level 1 |
| 3.750% Notes due February 2026 | — |  |  | — |  |  | 678 |  |  | 672 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 406 |  |  | 398 |  |  | 409 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 654 |  |  | 655 |  |  | 655 |  |  | 651 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 671 |  |  | 669 |  |  | 676 |  |  | 669 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 651 |  |  | 651 |  |  | 499 |  |  | 497 |  |  | Level 1 |
| 5.375% Notes due November 2035 | 598 |  |  | 585 |  |  | — |  |  | — |  |  | Level 1 |
| Delayed Draw Term Loan due December 2027 | 500 |  |  | 500 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 296 |  |  | 237 |  |  | 269 |  |  | 215 |  |  | Level 2 |

[0000866374-26-000012:notes:273]
The Notes due June 2025, February 2026, January 2028, June 2029, May 2030, January 2032, and November 2035 are valued based on broker trading prices in active markets. The Delayed Draw Term Loan due December 2027 bears interest at variable interest rates; therefore, as of March 31, 2026, the carrying amount approximates fair value. HUF Bonds are valued based on the broker trading prices in an inactive market.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-26-000012:notes:274]
COMMITMENTS AND CONTINGENCIES
Commitments

[0000866374-26-000012:notes:275]
As of March 31, 2026 and 2025, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under finance leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2044. Refer to note 3 for additional details on the minimum lease payments.

[0000866374-26-000012:notes:276]
Litigation and other legal matters

[0000866374-26-000012:notes:277]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-26-000012:notes:278]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. The Company was unsuccessful at the administrative level in two of the remaining assessments and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 37 million Brazilian reals (approximately USD $7 million). The Brazilian court ruled in favor of the Company on the first annulment action on March 7, 2025 and the assessment obligation has been canceled, although it remains subject to appeal. The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 60 million Brazilian reals (approximately USD $12 million). The Company is still awaiting a resolution of the second annulment action. The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on the remaining assessments and annulment actions in the near future.

[0000866374-26-000012:notes:279]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagreed with the Tax Authority’s assessments and was actively contesting the assessments through the administrative and judicial processes. During the third quarter of the fiscal year ended March 31, 2026, the Company and the Tax Authority agreed to a $50 million settlement covering all open fiscal years and all assessed amounts. The Company had previously expensed $31 million and paid $30 million to the Tax Authority in prior fiscal years and agreed to make an additional $20 million cash payment to the Tax Authority subsequent to the execution of a definitive settlement agreement, which resulted in a charge to income tax expense of $19 million in the third quarter of the fiscal year ended March 31, 2026. The definitive settlement agreement was executed on February 3, 2026 and the $20 million cash payment was made in the fourth quarter of the fiscal year ending March 31, 2026.

[0000866374-26-000012:notes:280]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-26-000012:notes:281]
INCOME TAXES
The domestic (Singapore) and foreign components of income from continuing operations before income taxes were comprised of the following:

[0000866374-26-000012:notes:282]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions) |
| Domestic | $ | (459) |  |  | $ | 94 |  |  | $ | (165) |  |
| Foreign | 1,602 |  |  | 929 |  |  | 831 |  |
| Total | $ | 1,143 |  |  | $ | 1,023 |  |  | $ | 666 |  |

[0000866374-26-000012:notes:283]
The (benefit from) provision for income taxes from continuing operations consisted of the following:

[0000866374-26-000012:notes:284]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions) |
| Current: |  |  |  |  |  |
| Domestic | $ | 2 |  |  | $ | 2 |  |  | $ | 3 |  |
| Foreign | 223 |  |  | 128 |  |  | 161 |  |
|  | 225 |  |  | 130 |  |  | 164 |  |
| Deferred: |  |  |  |  |  |
| Domestic | — |  |  | 3 |  |  | (1) |  |
| Foreign | 38 |  |  | 52 |  |  | (369) |  |
|  | 38 |  |  | 55 |  |  | (370) |  |
| (Benefit from) provision for income taxes | $ | 263 |  |  | $ | 185 |  |  | $ | (206) |  |

[0000866374-26-000012:notes:285]
Upon adoption of ASU 2023-09, Improvements to Income Tax Disclosures, as described in note 2 "Summary of Significant Accounting Policies," the reconciliation of taxes at the Singapore statutory rate of 17.0% to the Company's provision for (benefit from) income taxes for the year ended March 31, 2026 was as follows (in millions, except percentages):

[0000866374-26-000012:notes:286]
|  | Fiscal Year Ended March 31, 2026 |
|  | Amounts |  | Percent |
| Income taxes based on domestic statutory rates | $ | 194 |  |  | 17 | % |
| Effect of jurisdictional tax rate differential: |  |  |  |
| China: |  |  |  |
| Liability for Undistributed Earnings | 10 |  |  | 1 | % |
| Other | 12 |  |  | 1 | % |
| Brazil: |  |  |  |
| Statutory tax rate difference between Brazil and Singapore | 15 |  |  | 1 | % |
| Nontaxable or nondeductible items | (78) |  |  | (7) | % |
| Foreign exchange gain or loss on deferred tax asset | (42) |  |  | (4) | % |
| Change in valuation allowance | 93 |  |  | 8 | % |
| Other | (12) |  |  | (1) | % |
| Hungary: |  |  |  |
| Local business Tax | 11 |  |  | 1 | % |
| Other | (7) |  |  | (1) | % |

[0000866374-26-000012:notes:287]
| Luxembourg: |  |  |  |
| Statutory tax rate difference between Luxembourg and Singapore | 22 |  |  | 2 | % |
| Change in valuation allowance | (70) |  |  | (6) | % |
| Other | (6) |  |  | — | % |
| Netherlands: |  |  |  |
| Nontaxable or nondeductible items | (17) |  |  | (1) | % |
| Other | 7 |  |  | 1 | % |
| Malaysia: |  |  |  |
| Statutory tax rate difference between Malaysia and Singapore | 12 |  |  | 1 | % |
| Other | (5) |  |  | — | % |
| Mexico: |  |  |  |
| Statutory tax rate difference between Mexico and Singapore | 47 |  |  | 4 | % |
| Nontaxable or nondeductible items | (45) |  |  | (4) | % |
| Other | (8) |  |  | (1) | % |
| United States: |  |  |  |
| Statutory tax rate difference between United States and Singapore | 23 |  |  | 2 | % |
| State and local income tax | 10 |  |  | 1 | % |
| Global intangible low-taxed income | 17 |  |  | 2 | % |
| Excess compensation (Section 162(m)) | 21 |  |  | 2 | % |
| Stock-based compensation | (30) |  |  | (3) | % |
| Other | 1 |  |  | — | % |
| Other Foreign Jurisdictions: |  |  |  |
| Nontaxable or nondeductible items | (9) |  |  | (1) | % |
| Other | 2 |  |  | — | % |
| Nontaxable or nondeductible items | 61 |  |  | 5 | % |
| Change in unrecognized tax benefits | 33 |  |  | 3 | % |
| Other | 1 |  |  | — | % |
| Provision for income taxes | $ | 263 |  |  | 23 | % |

[0000866374-26-000012:notes:288]
The reconciliation of taxes at the federal statutory rate to the Company's provision for (benefit from) income taxes for the years ended March 31, 2025 and 2024 in accordance with the guidance prior to the adoption of ASU 2023-09 was as follows:

[0000866374-26-000012:notes:289]
|  |  |  | Fiscal Year Ended March 31, |
|  |  |  | 2025 |  | 2024 |
|  |  |  | (In millions) |
| Income taxes based on domestic statutory rates |  |  | $ | 174 |  |  | $ | 113 |  |
| Effect of jurisdictional tax rate differential |  |  | 13 |  |  | 68 |  |
| Change in unrecognized tax benefit |  |  | (19) |  |  | (10) |  |
| Change in valuation allowance |  |  | (37) |  |  | (685) |  |
| Foreign exchange movement on prior year taxes recoverable |  |  | 4 |  |  | (1) |  |
| Liability for undistributed earnings |  |  | 6 |  |  | 135 |  |
| Global intangible low-taxed income (GILTI) / Subpart F income |  |  | 9 |  |  | 13 |  |
| Nextracker related transactions gains |  |  | — |  |  | 115 |  |
| Earnings from partnership |  |  | — |  |  | 47 |  |
| U.S. state taxes |  |  | 10 |  |  | 10 |  |
| Excess compensation (Section 162(m)) |  |  | 16 |  |  | 15 |  |
| Other |  |  | 9 |  |  | (26) |  |
| (Benefit from) provision for income taxes |  |  | $ | 185 |  |  | $ | (206) |  |

[0000866374-26-000012:notes:290]
Cash paid for income taxes, net of refunds, during the fiscal years ended March 31, 2025 and 2024 was $184 million and $243 million, respectively.

[0000866374-26-000012:notes:291]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2026, 2025 and 2024 were $19 million, $17 million and $20 million, respectively. For the fiscal year ended March 31, 2026, the effect on basic and diluted earnings per share was $0.05, and the effects on basic and diluted earnings per share during fiscal years 2025 and 2024 were $0.04, and $0.05, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in various years through the end of fiscal year 2031.

[0000866374-26-000012:notes:292]
The Company provides a valuation allowance against deferred tax assets that in the Company's estimation are not more likely than not to be realized. During fiscal years 2026, 2025 and 2024, the Company released net valuation allowances totaling

[0000866374-26-000012:notes:293]
$1 million, $4 million and $447 million, respectively. The $1 million net release during fiscal year 2026 was related to operations in various jurisdictions.

[0000866374-26-000012:notes:294]
In addition, various other valuation allowance positions in other jurisdictions were increased or decreased to offset movement in deferred tax positions due to varying factors such as one-time income recognition in loss entities with existing valuation allowances, liquidation of entities with existing valuation allowances, recognition of uncertain tax positions impacting deferred tax assets with existing valuation allowances, foreign exchange impacts on deferred tax balances with existing valuation allowances, and current period losses in legal entities with existing valuation allowance positions. These offsetting changes in the valuation allowance included an increase of $17 million in the fiscal year ended March 31, 2026, a decrease of $53 million in the fiscal year ended March 31, 2025, and an increase of $43 million in the fiscal year ended March 31, 2024.

[0000866374-26-000012:notes:295]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effects of foreign income not repatriated to Singapore for the fiscal years ended March 31, 2026, 2025 and 2024 were $49 million, $96 million and zero, respectively.

[0000866374-26-000012:notes:296]
The components of deferred income taxes are as follows:

[0000866374-26-000012:notes:297]
|  | As of March 31, |
|  | 2026 |  | 2025 |
|  | (In millions) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (39) |  |  | $ | (44) |  |
| Intangible assets | (45) |  |  | (52) |  |
| Others | (92) |  |  | (128) |  |
| Total deferred tax liabilities | (176) |  |  | (224) |  |
| Deferred tax assets: |  |  |  |
| Fixed assets | 76 |  |  | 76 |  |
| Intangible assets | 1 |  |  | 3 |  |
| Deferred compensation | 44 |  |  | 37 |  |
| Inventory valuation | 29 |  |  | 32 |  |
| Provision for doubtful accounts | 2 |  |  | 3 |  |
| Net operating loss and other carryforwards | 943 |  |  | 1,022 |  |
| Tax receivable agreement | 70 |  |  | 74 |  |
| Others | 235 |  |  | 186 |  |
| Total deferred tax assets | 1,400 |  |  | 1,433 |  |
| Valuation allowances | (797) |  |  | (781) |  |
| Total deferred tax assets, net of valuation allowances | 603 |  |  | 652 |  |
| Net deferred tax asset | $ | 427 |  |  | $ | 428 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Long-term asset | $ | 538 |  |  | $ | 577 |  |
| Long-term liability | (111) |  |  | (149) |  |
| Total | $ | 427 |  |  | $ | 428 |  |

[0000866374-26-000012:notes:298]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-26-000012:notes:299]
The Company has recorded deferred tax assets of approximately $1.0 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $224 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-26-000012:notes:300]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |  |
| Fiscal year |  | (In millions) |
| 2027 - 2032 |  | $ | 89 |  |
| 2033 - 2038 |  | 171 |  |
| 2039 and thereafter |  | 9 |  |
| Indefinite |  | 704 |  |
|  |  | $ | 973 |  |

[0000866374-26-000012:notes:301]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-26-000012:notes:302]
The Company does not provide for income taxes on approximately $930 million of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. The estimated amount of the unrecognized deferred tax liability on these undistributed earnings is approximately $82 million. In the current year, the Company, as part of its regular process, assessed its cash position in overseas territories relative to the levels needed to manage operations and fund future investment in those territories. Management noted that the current and forecasted cash position in China was in excess of levels required to fund the Company’s business in the country. As a result, a deferred tax liability of $82 million was recorded on the remaining distributable earnings from China of approximately $822 million.

[0000866374-26-000012:notes:303]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-26-000012:notes:304]
|  | Fiscal Year EndedMarch 31, |
|  | 2026 |  | 2025 |
|  | (In millions) |
| Balance, beginning of fiscal year | $ | 180 |  |  | $ | 197 |  |
| Additions based on tax position related to the current year | 13 |  |  | 10 |  |
| Additions for tax positions of prior years | 29 |  |  | 1 |  |
| Reductions for tax positions of prior years | (5) |  |  | (5) |  |
| Reductions related to lapse of applicable statute of limitations | (13) |  |  | (23) |  |
| Settlements | (52) |  |  | — |  |
| Impact from foreign exchange rates fluctuation | 7 |  |  | — |  |
| Balance, end of fiscal year | $ | 159 |  |  | $ | 180 |  |

[0000866374-26-000012:notes:305]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an additional approximate $10 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-26-000012:notes:306]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2008.

[0000866374-26-000012:notes:307]
Of the $159 million of unrecognized tax benefits at March 31, 2026, $131 million will affect the annual effective tax rate ("ETR") if the benefits are eventually recognized. The amount that does not impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-26-000012:notes:308]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company’s tax expense. The Company recognized interest and penalties of approximately zero, ($3) million and ($2) million, during the fiscal years ended March 31, 2026, 2025, and 2024, respectively. The Company had approximately $10 million, $10 million and $13

[0000866374-26-000012:notes:309]
million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2026, 2025, and 2024, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-26-000012:notes:310]
RESTRUCTURING CHARGES
Fiscal Year 2026

[0000866374-26-000012:notes:311]
The Company continued to improve operational efficiencies through targeted restructuring activities in fiscal year 2026. The Company recognized $87 million of restructuring charges in fiscal year 2026, most of which related to employee severance. This figure excludes $51 million of impairment and other charges relating to a missile strike on the Company's Mukachevo, Ukraine facility during fiscal year 2026. A total of $135 million of restructuring and impairment charges are excluded from segment income, as disclosed further in note 21.

[0000866374-26-000012:notes:312]
Fiscal Year 2025

[0000866374-26-000012:notes:313]
During fiscal year 2025, the Company committed to targeted restructuring activities to improve operational efficiency by reducing excess workforce capacity. As a result, the Company recognized $86 million of restructuring charges, most of which related to employee severance. Certain restructuring charges of $84 million are not included in segment income.

[0000866374-26-000012:notes:314]
Fiscal Year 2024

[0000866374-26-000012:notes:315]
The Company identified certain structural changes to restructure its business throughout fiscal year 2024. During fiscal year 2024, the Company recognized $175 million of restructuring charges, most of which related to employee severance and are not included in segment income.

[0000866374-26-000012:notes:316]
The following table summarizes the provisions for charges incurred, respective payments for the fiscal years ended March 31, 2026, 2025, and 2024, respectively, and remaining accrued balances as of the same periods:

[0000866374-26-000012:notes:317]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2023 | $ | 44 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 50 |  |
| Provision for charges incurred in fiscal year 2024 | 161 |  |  | 14 |  |  | — |  |  | 175 |  |
| Cash payments for charges incurred in fiscal year 2023 and prior | (13) |  |  | — |  |  | — |  |  | (13) |  |
| Cash payments for charges incurred in fiscal year 2024 | (115) |  |  | — |  |  | — |  |  | (115) |  |
| Non-cash reductions (including FX) incurred in fiscal year 2024 | — |  |  | (14) |  |  | (3) |  |  | (17) |  |
| Balance as of March 31, 2024 | 77 |  |  | — |  |  | 3 |  |  | 80 |  |
| Provision for charges incurred in fiscal year 2025 | 76 |  |  | 10 |  |  | — |  |  | 86 |  |
| Cash payments for charges incurred in fiscal year 2024 and prior | (20) |  |  | — |  |  | — |  |  | (20) |  |
| Cash payments for charges incurred in fiscal year 2025 | (54) |  |  | — |  |  | — |  |  | (54) |  |
| Non-cash reductions (including FX) incurred in fiscal year 2025 (1) | (28) |  |  | (10) |  |  | (3) |  |  | (41) |  |
| Balance as of March 31, 2025 | 51 |  |  | — |  |  | — |  |  | 51 |  |
| Provision for charges incurred in fiscal year 2026 | 72 |  |  | 9 |  |  | 6 |  |  | 87 |  |
| Cash payments for charges incurred in fiscal year 2025 and prior | (27) |  |  | — |  |  | (4) |  |  | (31) |  |
| Cash payments for charges incurred in fiscal year 2026 | (33) |  |  | — |  |  | (3) |  |  | (36) |  |
| Non-cash reductions (including FX) incurred in fiscal year 2026 | — |  |  | (9) |  |  | 1 |  |  | (8) |  |
| Balance as of March 31, 2026 | 63 |  |  | — |  |  | — |  |  | 63 |  |
| Less: Current portion (classified as other current liabilities) | 63 |  |  | — |  |  | — |  |  | 63 |  |
| Accrued restructuring costs, net of current portion (classified as other non-current liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000866374-26-000012:notes:318]
(1) The non-cash adjustments predominantly relate to the liabilities derecognized as part of a business disposition. Refer to note 19 for further details.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-26-000012:notes:319]
OTHER CHARGES (INCOME), NET
Other charges (income), net for the fiscal years ended March 31, 2026, 2025 and 2024 are comprised of the following:

[0000866374-26-000012:notes:320]
|  | Fiscal Year Ended March 31 |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions) |
| (Gain)/Loss on foreign exchange transactions | $ | 17 |  |  | $ | 10 |  |  | $ | 24 |  |
| (Gain) on bargain purchase (1) | — |  |  | (19) |  |  | — |  |
| Other | 13 |  |  | (5) |  |  | 20 |  |

[0000866374-26-000012:notes:321]
(1)Represents the gain on bargain purchase as a result of an acquisition occurring during the fourth quarter of fiscal year 2025. See note 19 "Business Acquisitions & Divestitures" for additional information.


## flex:InterestAndOtherNetTextBlock

[0000866374-26-000012:notes:322]
INTEREST EXPENSE AND INTEREST INCOME
Interest expense and interest income for the fiscal years ended March 31, 2026, 2025 and 2024 are primarily comprised of the following:

[0000866374-26-000012:notes:323]
|  | Fiscal Year Ended March 31 |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions) |
| Interest expense on debt obligations | $ | 197 |  |  | $ | 185 |  |  | $ | 161 |  |
| AR sales programs related expenses | 18 |  |  | 33 |  |  | 46 |  |
| Interest income | (51) |  |  | (61) |  |  | (56) |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000866374-26-000012:notes:324]
BUSINESS ACQUISITIONS & DIVESTITURES
Fiscal 2026 Acquisition

[0000866374-26-000012:notes:325]
On April 30, 2025, the Company completed the acquisition of a manufacturing business in Bielsko Biała, Poland, for total purchase consideration of $35 million. The business is included in the Power reporting unit in the CPI segment. The results of the acquired business are included in the Company’s consolidated financial statements from the acquisition date. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed is based on their fair values as of the date of acquisition.

[0000866374-26-000012:notes:326]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities of the acquired business (in millions):

[0000866374-26-000012:notes:327]
| Current Assets: |  |
| Inventories | $ | 15 |  |
| Contract assets | 9 |  |
| Accounts Receivable | 1 |  |
| Total current assets | 25 |  |
| Operating lease right-of-use assets, net | 28 |  |
| Property and equipment, net | 4 |  |
| Intangible assets (1) | 2 |  |
| Goodwill | 8 |  |
| Total assets | $ | 67 |  |
| Current Liabilities: |  |
| Accrued payroll | $ | 4 |  |
| Operating lease liabilities | 2 |  |
| Total current liabilities | 6 |  |
| Operating lease liabilities, non-current | 26 |  |
| Total liabilities | 32 |  |
| Total aggregate purchase price | $ | 35 |  |

[0000866374-26-000012:notes:328]
(1) Intangible assets of $2 million relate to customer relationships and will be amortized over a weighted-average estimated useful life of 5 years.

[0000866374-26-000012:notes:329]
Fiscal 2025 Acquisitions and Divestiture

[0000866374-26-000012:notes:330]
On November 19, 2024, the Company completed the business acquisition of 100% ownership of Crown, a U.S. leader in critical power solutions for a total purchase consideration of $319 million, including cash of $313 million and a $6 million estimate of customary closing adjustments. The acquisition added complementary capabilities to the Company's existing portfolio in the United States, primarily strengthening its industrial power solutions. Upon acquisition, Crown was included in the Industrial reporting unit within the former FRS segment. Currently, Crown is included in the Power reporting unit within the CPI segment. The intangible assets of $128 million are comprised of customer-related intangible assets of $83 million and licenses and other intangible assets such as trade names and patented technology of $45 million. Customer-related assets are amortized over a weighted-average estimated useful life of 12.6 years while licenses and other intangibles are amortized over a weighted-average estimated useful life of 10.0 years.

[0000866374-26-000012:notes:331]
On November 14, 2024, the Company acquired 100% ownership of JetCool, a provider of liquid cooling solutions tailored for the data center market, for approximately $43 million in cash, a deemed settled pre-existing loan from Flex of approximately $5 million, and contingent consideration with an acquisition date fair value of $5 million for a total purchase price of $53 million. As of March 31, 2026, the remaining carrying value of the contingent consideration is $2 million. Upon acquisition, JetCool was included in the CEC reporting unit within the former FAS segment. Currently, JetCool is included in the Cloud and Cooling reporting unit within the CPI segment. Acquired intangible assets of $21 million relate to developed technology and are amortized over a weighted-average estimated useful life of 6.5 years.

[0000866374-26-000012:notes:332]
On February 4, 2025, the Company acquired the U.S. manufacturing operations of the Forest & Garden division of Husqvarna, a leading global producer of outdoor power products. Under the agreement, the Company assumed operation of Husqvarna’s Orangeburg, South Carolina, facility to support Husqvarna’s U.S. manufacturing requirements. The total purchase consideration was $78 million, including $57 million in cash and $21 million in deferred consideration as of the acquisition date, $8 million of which has been paid in fiscal year 2026, $5 million to be paid in fiscal year 2027, $4 million in fiscal year 2028 and $4 million in fiscal year 2029. Additionally, the Company recognized a gain on bargain purchase of $19 million in other charges (income) on the consolidated statements of operations during fiscal year 2025. The gain on bargain purchase reflects the seller’s strategic decision to prioritize its partnership with Flex as a manufacturing partner. The acquired business is

[0000866374-26-000012:notes:333]
included in the Industrial reporting unit within the RMS segment. Acquired intangible assets of $15 million relate to customer relationships and are amortized over a weighted-average estimated useful life of 5 years.

[0000866374-26-000012:notes:334]
In May 2024, the Company completed the acquisition of a business that was not material to the Company's consolidated financial position, results of operations, or cash flows. The acquisition expanded the Company’s service offerings across multiple markets and supports sustainability initiatives through second-life products. $8 million of goodwill was recognized in connection with this transaction.

[0000866374-26-000012:notes:335]
During the fiscal year ended March 31, 2025, the Company disposed of ones of its European sites. The property and equipment and various other assets sold and liabilities transferred were not material to the Company's consolidated financial results. The net loss on disposition of $6 million was recorded in other charges (income), net in the consolidated statements of operations for fiscal year 2025.

[0000866374-26-000012:notes:336]
Fiscal 2024 Divestitures

[0000866374-26-000012:notes:337]
During the fiscal year ended March 31, 2024, the Company completed the spin-off of Nextracker. See note 7 - "Discontinued Operations & Noncontrolling Interest" for additional information.

[0000866374-26-000012:notes:338]
In addition, the Company disposed of a non-strategic business within the RMS segment and received proceeds of $14 million. The property and equipment and various other assets sold and liabilities transferred were not material to the Company's consolidated financial results. The net loss on disposition was not material to the Company’s consolidated financial results, and was included in other charges (income), net in the consolidated statements of operations for fiscal year 2024.


## us-gaap:TreasuryStockTextBlock

[0000866374-26-000012:notes:339]
SHARE REPURCHASE PLAN
During fiscal year 2026, the Company repurchased 19.2 million shares for an aggregate purchase price of $944 million and retired all these shares.

[0000866374-26-000012:notes:340]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.7 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 6, 2025. As of March 31, 2026, shares in the aggregate amount of $1.1 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-26-000012:notes:341]
SEGMENT REPORTING
The Company's Chief Executive Officer is the Company's Chief Operating Decision Maker ("CODM") who evaluates how we allocate resources, assess performance and make strategic and operational decisions. Based on such evaluation and the information provided to the CODM, the Company determined as of and for the period ended March 31, 2026, that Flex has three operating and reportable segments. See note 1 "Organization of the Company" for further details on the segment change that took place in the fourth quarter of fiscal year 2026.

[0000866374-26-000012:notes:342]
The ITS segment is optimized for speed to market based on a highly flexible supply and manufacturing system. ITS is comprised of the following end markets that represent reporting units:

[0000866374-26-000012:notes:343]
•Communications, high speed networking, enterprise, and satellite communications systems

[0000866374-26-000012:notes:344]
•Lifestyle, premium products across commercial, home and personal product categories

[0000866374-26-000012:notes:345]
The RMS segment is optimized for longer product lifecycles requiring complex ramps with specialized production models. RMS is comprised of the following end markets that represent reporting units:

[0000866374-26-000012:notes:346]
•Industrial, mission-critical automation, energy, and industrial infrastructure

[0000866374-26-000012:notes:347]
•Automotive, compute and power electronics platforms, and integrated systems

[0000866374-26-000012:notes:348]
•Healthcare, regulated manufacturing for medical devices, drug delivery and equipment

[0000866374-26-000012:notes:349]
The CPI segment is a global provider of power and cooling products and integrated rack-scale compute systems serving digital infrastructure and industrial applications. CPI is comprised of the following end markets that represent reporting units:

[0000866374-26-000012:notes:350]
•Cloud and Cooling, integrated compute systems supporting power‑dense digital infrastructure deployments, and advanced liquid cooling solutions supporting higher-density, power-intensive rack architectures

[0000866374-26-000012:notes:351]
•Power, utility and facility‑level electrical infrastructure enabling reliable, scalable power delivery and high-density rack- and board-level power systems supporting power-intensive compute workloads

[0000866374-26-000012:notes:352]
The determination of the separate operating and reporting segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-26-000012:notes:353]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. The CODM compares actual segment income to budgeted financial performance in allocating resources and assessing segment performance.  Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, certain restructuring charges, customer-related asset impairment charges or recoveries, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-26-000012:notes:354]
Selected financial information by segment is in the tables below.

[0000866374-26-000012:notes:355]
| Fiscal Year Ended March 31, 2026 | ITS |  | RMS |  | CPI |  | Total |
| Net Sales | $ | 11,109 |  |  | $ | 10,191 |  |  | $ | 6,614 |  |  | $ | 27,914 |  |
| Segment cost of sales | (10,231) |  |  | (9,225) |  |  | (5,810) |  |  |  |
| Segment selling, general and administrative expenses | (282) |  |  | (355) |  |  | (194) |  |  |  |
| Segment income | $ | 596 |  |  | $ | 611 |  |  | $ | 610 |  |  | $ | 1,817 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Corporate and other |  |  |  |  |  |  | $ | 53 |  |
| Intangible amortization |  |  |  |  |  |  | 68 |  |
| Stock-based compensation |  |  |  |  |  |  | 142 |  |
| Restructuring and impairment charges (1) |  |  |  |  |  |  | 135 |  |
| Customer-related asset recoveries (2) |  |  |  |  |  |  | (2) |  |
| Legal and other (3) |  |  |  |  |  |  | 53 |  |
| Interest expense |  |  |  |  |  |  | 215 |  |
| Interest income |  |  |  |  |  |  | 51 |  |
| Other charges (income), net |  |  |  |  |  |  | 30 |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (31) |  |
| Income from continuing operations before income taxes |  |  |  |  |  |  | $ | 1,143 |  |

[0000866374-26-000012:notes:356]
(1)Certain restructuring charges of $3 million are excluded from the reconciling amount of $135 million as they are included within segment income.

[0000866374-26-000012:notes:357]
(2)Customer-related asset impairments may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. During fiscal year 2026, the Company recovered approximately $2 million of prior year customer-related asset impairments.

[0000866374-26-000012:notes:358]
(3)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and asset impairment. During fiscal year 2026, $53 million in Legal and other costs primarily related to temporary and incremental costs associated with the Company's intent to separate its CPI segment from Flex.

[0000866374-26-000012:notes:359]
| Fiscal Year Ended March 31, 2025 | ITS |  | RMS |  | CPI |  | Total |
| Net Sales | $ | 11,336 |  |  | $ | 9,678 |  |  | $ | 4,799 |  |  | $ | 25,813 |  |
| Segment cost of sales | (10,512) |  |  | (8,851) |  |  | (4,163) |  |  |  |
| Segment selling, general and administrative expenses | (283) |  |  | (322) |  |  | (144) |  |  |  |
| Segment income | $ | 541 |  |  | $ | 505 |  |  | $ | 492 |  |  | $ | 1,538 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Corporate and other |  |  |  |  |  |  | $ | 79 |  |
| Intangible amortization |  |  |  |  |  |  | 70 |  |
| Stock-based compensation |  |  |  |  |  |  | 125 |  |
| Restructuring charges |  |  |  |  |  |  | 84 |  |
| Customer-related asset impairment (1) |  |  |  |  |  |  | 2 |  |
| Legal and other (2) |  |  |  |  |  |  | 9 |  |
| Interest expense |  |  |  |  |  |  | 218 |  |
| Interest income |  |  |  |  |  |  | 61 |  |
| Other charges (income), net |  |  |  |  |  |  | (14) |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (3) |  |
| Income from continuing operations before income taxes |  |  |  |  |  |  | $ | 1,023 |  |

[0000866374-26-000012:notes:360]
(1)Customer-related asset impairments may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. During fiscal year 2025, the Company recognized approximately $2 million of customer-related asset impairments.

[0000866374-26-000012:notes:361]
(2)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer-related asset impairment. During fiscal year 2025, the Company accrued for $5 million related to asset impairments and $4 million is related to acquisition costs.

[0000866374-26-000012:notes:362]
| Fiscal Year Ended March 31, 2024 | ITS |  | RMS |  | CPI |  | Total |
| Net Sales | $ | 12,636 |  |  | $ | 10,535 |  |  | $ | 3,244 |  |  | $ | 26,415 |  |
| Segment cost of sales | (11,846) |  |  | (9,656) |  |  | (2,835) |  |  |  |
| Segment selling, general and administrative expenses | (301) |  |  | (339) |  |  | (103) |  |  |  |
| Segment income | $ | 489 |  |  | $ | 540 |  |  | $ | 306 |  |  | $ | 1,335 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Corporate and other |  |  |  |  |  |  | $ | 68 |  |
| Intangible amortization |  |  |  |  |  |  | 70 |  |
| Stock-based compensation |  |  |  |  |  |  | 113 |  |
| Restructuring charges |  |  |  |  |  |  | 172 |  |
| Customer-related asset impairment (1) |  |  |  |  |  |  | 14 |  |
| Legal and other (2) |  |  |  |  |  |  | 45 |  |
| Interest expense |  |  |  |  |  |  | 207 |  |
| Interest income |  |  |  |  |  |  | 56 |  |
| Other charges (income), net |  |  |  |  |  |  | 44 |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | 8 |  |
| Income from continuing operations before income taxes |  |  |  |  |  |  | $ | 666 |  |

[0000866374-26-000012:notes:363]
(1)Customer-related asset impairments may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. During fiscal year 2024, the Company recognized approximately $14 million of customer-related asset impairments.

[0000866374-26-000012:notes:364]
(2)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer-related asset recoveries. During fiscal year 2024, the Company recognized a $50 million loss contingency for a commercial dispute related to a construction matter with related production objectives.

[0000866374-26-000012:notes:365]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled in the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segment nor reported by segment to the Company's CODM.

[0000866374-26-000012:notes:366]
Property and equipment on a segment basis is not separately identified and is not internally reported by segment to the Company's CODM as described above. During fiscal years 2026, 2025 and 2024, total depreciation expense, including amounts allocated to the reportable segments and Corporate and Other, was as follows:

[0000866374-26-000012:notes:367]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions) |
| Depreciation expense: |  |  |  |  |  |
| Integrated Technology Solutions | $ | 162 |  |  | $ | 180 |  |  | $ | 184 |  |
| Regulated Manufacturing Solutions | 221 |  |  | 209 |  |  | 204 |  |
| Cloud and Power Infrastructure | 62 |  |  | 39 |  |  | 24 |  |
| Corporate and Other | 12 |  |  | 11 |  |  | 16 |  |
| Total depreciation expense | $ | 457 |  |  | $ | 439 |  |  | $ | 428 |  |

[0000866374-26-000012:notes:368]
Geographic information of net sales is as follows:

[0000866374-26-000012:notes:369]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 13,820 |  |  | 50 | % |  | $ | 12,656 |  |  | 49 | % |  | $ | 12,232 |  |  | 46 | % |
| Asia | 8,401 |  |  | 30 | % |  | 7,701 |  |  | 30 | % |  | 8,540 |  |  | 32 | % |
| Europe | 5,693 |  |  | 20 | % |  | 5,456 |  |  | 21 | % |  | 5,643 |  |  | 22 | % |
|  | $ | 27,914 |  |  |  |  | $ | 25,813 |  |  |  |  | $ | 26,415 |  |  |  |

[0000866374-26-000012:notes:370]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0000866374-26-000012:notes:371]
During fiscal years 2026, 2025 and 2024, net sales generated from Singapore, the country of domicile, were $194 million, $266 million and $660 million, respectively.

[0000866374-26-000012:notes:372]
The following table summarizes the countries that accounted for more than 10% of net sales in fiscal years 2026, 2025, and 2024:

[0000866374-26-000012:notes:373]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (In millions) |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 6,994 |  |  | 25 | % |  | $ | 6,854 |  |  | 27 | % |  | $ | 6,935 |  |  | 26 | % |
| U.S. | 5,186 |  |  | 19 | % |  | 4,162 |  |  | 16 | % |  | 3,598 |  |  | 14 | % |
| China | 4,494 |  |  | 16 | % |  | 4,319 |  |  | 17 | % |  | 5,117 |  |  | 19 | % |
| Malaysia | 2,967 |  |  | 11 | % |  | 2,379 |  |  | 9 | % |  | 2,122 |  |  | 8 | % |

[0000866374-26-000012:notes:374]
No other country accounted for more than 10% of net sales for the fiscal periods presented in the table above.

[0000866374-26-000012:notes:375]
Geographic information of property and equipment, net is as follows:

[0000866374-26-000012:notes:376]
|  | As of March 31, |
|  | 2026 |  | 2025 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Americas | $ | 1,419 |  |  | 57 | % |  | $ | 1,292 |  |  | 55 | % |
| Asia | 585 |  |  | 23 | % |  | 555 |  |  | 24 | % |
| Europe | 501 |  |  | 20 | % |  | 483 |  |  | 21 | % |
|  | $ | 2,505 |  |  |  |  | $ | 2,330 |  |  |  |

[0000866374-26-000012:notes:377]
As of March 31, 2026 and 2025, property and equipment, net held in Singapore was $4 million in both periods.

[0000866374-26-000012:notes:378]
The following table summarizes the countries that accounted for more than 10% of property and equipment, net for the fiscal years ended March 31, 2026 and 2025:

[0000866374-26-000012:notes:379]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 891 |  |  | 36 | % |  | $ | 815 |  |  | 35 | % |
| U.S. | 443 |  |  | 18 | % |  | 376 |  |  | 16 | % |
| China | 306 |  |  | 12 | % |  | 293 |  |  | 13 | % |

[0000866374-26-000012:notes:380]
No other country accounted for more than 10% of property and equipment, net for the periods presented in the table above.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-26-000012:notes:381]
(2)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer-related asset recoveries. During fiscal year 2024, the Company recognized a $50 million loss contingency for a commercial dispute related to a construction matter with related production objectives. 
During fiscal years 2026, 2025 and 2024, total depreciation expense, including amounts allocated to the reportable segments and Corporate and Other, was as follows:


## us-gaap:SubsequentEventsTextBlock

[0000866374-26-000012:notes:382]
SUBSEQUENT EVENTS
On May 5, 2026, Flex announced its intention to separate its CPI segment from Flex and into an independent, publicly traded company (“SpinCo”).  The separation of CPI into SpinCo will create a separate publicly traded company focused on data center power, digital infrastructure and power, thermal and compute integration.  The spin-off of CPI from Flex is expected to be completed in the first quarter of calendar 2027 and is subject to the approval of Flex’s Board of Directors, shareholders, and the High Court of the Republic of Singapore and the SEC declaring SpinCo’s Form 10 registration statement effective.  Subsequent to the spin-off of CPI from Flex, Flex will continue as an advanced manufacturing and supply chain solutions business consisting of its ITS and RMS segments.  There can be no assurance that any separation transaction will ultimately occur or, if one does occur, of its terms or timing and there is no guarantee that the spin-off, if completed, will achieve the intended financial, strategic, and operational benefits.

[0000866374-26-000012:notes:383]
On May 1, 2026, the Company completed the business acquisition of 100% ownership of Electrical Power Products, Inc ("EPP"), a U.S. leader in critical power solutions for a total estimated purchase consideration of $1.1 billion of cash, subject to customary closing adjustments. The acquisition enhances the scale of the Company's U.S. critical power portfolio. EPP will be reported within the Power reporting unit in the CPI segment. Due to the timing of the EPP acquisition, it is not practical to disclose the preliminary allocations of the purchase consideration to the assets acquired and liabilities assumed.

[0000866374-26-000012:notes:384]
On April 30, 2026, the Company entered into, and fully drew down, a new $1.45 billion credit facility (the "New Credit Facility") which matures on the date that is 364 days after the date on which the term loans are first funded pursuant to the New Credit Facility. Proceeds from the New Credit Facility are to be used for general corporate purposes including the financing of the acquisition of EPP described above. Loans under the New Credit Facility bear interest at either the forward-looking term rate based on the secured overnight financing rate for a specified interest period or a rate based on the prime rate, in each case plus an applicable margin determined by reference to the Company's long-term issuer credit ratings from S&P, Moody's, and Fitch.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000866374-26-000012:notes:385]
On February 12, 2026, Scott Offer, Executive Vice President and General Counsel, adopted a trading plan that provides for the sale of up to 51,750 ordinary shares of the Company. The plan will terminate on June 30, 2026, subject to early termination for certain specified events set forth in the plan.

[0000866374-26-000012:notes:386]
On February 20, 2026, Revathi Advaithi, Chief Executive Officer and a director, adopted a trading plan that provides for the sale of up to 167,000 ordinary shares of the Company. The plan will terminate on January 29, 2027, subject to early termination for certain specified events set forth in the plan.
