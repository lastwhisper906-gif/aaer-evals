# FLEX MD&A — 0000866374-26-000012


## mdna

[0000866374-26-000012:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-26-000012:mdna:2]
OVERVIEW

[0000866374-26-000012:mdna:3]
We are the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we deliver technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets.

[0000866374-26-000012:mdna:4]
The Company’s full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, and integrated services, plus a portfolio of power and cooling products. Over time, we have built differentiated scale and expertise across both technology-driven and regulated markets, enabling us to support customers with increasingly complex product, infrastructure, and compliance requirements. We partner with customers across a diverse set of industries including data center, healthcare, industrial, automotive, communications, and lifestyle.

[0000866374-26-000012:mdna:5]
In the fourth quarter of fiscal year 2026, the Company changed how it reports its operating results to its Chief Operating Decision Maker (“CODM”), principally reflecting the growth of Flex’s data center‑related businesses. As a result, the Company reorganized its operating structure and established a new operating and reportable segment, Cloud and Power Infrastructure (“CPI”) and updated its former segments from Flex Agility Solutions and Flex Reliability Solutions to Integrated Technology Solutions (“ITS”) and Regulated Manufacturing Solutions (“RMS”). Certain prior‑period segment information has been recast to conform to the current presentation. The determination of the separate operating and reportable segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 "Organization of the Company" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details on the segment change that took place in the fourth quarter of fiscal year 2026.

[0000866374-26-000012:mdna:6]
As of March 31, 2026, we report our financial performance based on three operating and reportable segments as follows

[0000866374-26-000012:mdna:7]
•Integrated Technology Solutions ("ITS"), which is comprised of the following end markets:

[0000866374-26-000012:mdna:8]
◦Communications, high speed networking, enterprise, and satellite communications systems

[0000866374-26-000012:mdna:9]
◦Lifestyle, premium products across commercial, home and personal product categories

[0000866374-26-000012:mdna:10]
•Regulated Manufacturing Solutions ("RMS"), which is comprised of the following end markets:

[0000866374-26-000012:mdna:11]
◦Industrial, mission-critical automation, energy, and industrial infrastructure

[0000866374-26-000012:mdna:12]
◦Automotive, compute and power electronics platforms, and integrated systems

[0000866374-26-000012:mdna:13]
◦Healthcare, regulated manufacturing for medical devices, drug delivery and equipment

[0000866374-26-000012:mdna:14]
•Cloud and Power Infrastructure ("CPI"), which is comprised of the following end markets:

[0000866374-26-000012:mdna:15]
◦Cloud and Cooling, integrated compute systems supporting power‑dense digital infrastructure deployments, and advanced liquid cooling solutions supporting higher-density, power-intensive rack architectures

[0000866374-26-000012:mdna:16]
◦Power, utility and facility‑level electrical infrastructure enabling reliable, scalable power delivery and high-density rack- and board-level power systems supporting power-intensive compute workloads

[0000866374-26-000012:mdna:17]
In fiscal year 2025, we formally introduced the next phase in our strategic evolution, our EMS + Products + Services approach. This hybrid model is focused on strengthening our core manufacturing and supply chain capabilities while expanding

[0000866374-26-000012:mdna:18]
36

[0000866374-26-000012:mdna:19]
our portfolio of proprietary products and value-added services to maximize value creation for customers. To advance this approach, we completed several strategic acquisitions in fiscal year 2025 that enhanced our differentiated portfolio to address critical data center customer challenges around power, heat and scale. These included the acquisitions of JetCool to expand direct-to-chip liquid cooling capabilities and Crown to increase critical power capabilities while adding opportunities in grid modernization. We continued with the acquisition of a power facility in Poland in fiscal year 2026 and the acquisition of Electrical Power Products in May 2026.

[0000866374-26-000012:mdna:20]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product lifecycle.

[0000866374-26-000012:mdna:21]
In today’s business landscape, we are witnessing greater product diversification by many companies, primarily in the technology sector, along with increased product complexity. These companies now require unique and customized manufacturing and supply chain solutions that meet their evolving requirements.

[0000866374-26-000012:mdna:22]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-26-000012:mdna:23]
We believe that our strategy is positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-26-000012:mdna:24]
We are continuously evaluating our capital structure in response to the current environment and expect that our current financial condition, including our liquidity sources are adequate to fund future commitments. See additional discussion in the Liquidity and Capital Resources section below.

[0000866374-26-000012:mdna:25]
Cloud and Power Infrastructure (CPI) Segment Spin-off

[0000866374-26-000012:mdna:26]
On May 5, 2026, we announced our intention to separate our CPI segment from Flex and into an independent, publicly traded company (“SpinCo”).  The separation of CPI into SpinCo will create a separate publicly traded company focused on data center power, digital infrastructure and power, thermal and compute integration.  The spin-off of CPI from Flex is expected to be completed in the first quarter of calendar 2027 and is subject to certain customary conditions, including, among others, the approval of Flex’s Board of Directors, shareholders, and the High Court of the Republic of Singapore and the SEC declaring SpinCo’s Form 10 registration statement effective.  Subsequent to the spin-off of CPI from Flex, Flex will continue as an advanced manufacturing and supply chain solutions business consisting of our ITS and RMS segments.  There can be no assurance that any spin-off transaction will ultimately occur or, if one does occur, of its terms or timing. See Item 1A, "Risk Factors - Planned Spin-off Risks—The planned spin-off of our Cloud and Power Infrastructure businesses may not be completed on the terms or timeline currently contemplated, if at all, and there is no guarantee that the spin-off, if completed, will achieve the intended financial, strategic, and operational benefits.".

[0000866374-26-000012:mdna:27]
Nextracker Spin-off

[0000866374-26-000012:mdna:28]
In February 2023, our former subsidiary, Nextracker, completed an initial public offering (the "IPO") of its Class A common stock followed by a follow-on offering in July 2023, after which we continued to consolidate Nextracker as an operating segment. In January 2024, we completed the Nextracker spin-off and Nextracker became a fully independent public company and we no longer consolidate Nextracker in our financial results.

[0000866374-26-000012:mdna:29]
Nextracker’s historical results are presented as discontinued operations. See note 7 "Discontinued Operations & Noncontrolling Interest" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further information. Unless otherwise indicated, any reference to income statement items in this "Management’s Discussion and Analysis of Financial Condition and Results of Operations" refers to results from continuing operations.

[0000866374-26-000012:mdna:30]
Update on Component Shortages and Logistical Constraints on our Business

[0000866374-26-000012:mdna:31]
Component shortages experienced in the recent past have largely subsided, however logistical constraints persist which have increased freight costs. We continue to monitor potential supply chain disruptions, as a result of emerging and evolving geopolitical tensions and tariff implementations. For further information, refer to "Risk Factors - Supply chain disruptions and demand forecasting failures have in the past adversely affected, and could in the future adversely affect, our ability to meet customer demand, and lead to higher costs, or result in excess or obsolete inventory." and "—Global economic conditions and geopolitical uncertainty have in the past adversely affected, and could in the future adversely affect, our business, results of operations, financial condition, and access to capital markets."

[0000866374-26-000012:mdna:32]
37

[0000866374-26-000012:mdna:33]
Russian Invasion of Ukraine and Middle East Conflicts

[0000866374-26-000012:mdna:34]
We continue to monitor and respond to the conflict in Ukraine and the associated sanctions and other restrictions. We also are monitoring and responding to the Israel-Hamas conflict and recent U.S. military operations in Iran. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine and Israel. The full impact of the conflicts on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflicts and their impact on regional and global economic conditions. We will continue to monitor the conflicts and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-26-000012:mdna:35]
During the fiscal year ended March 31, 2026, we recognized $51 million in asset impairments, inventory write-downs and other charges as a result of a missile strike on our Mukachevo, Ukraine facility in Western Ukraine on August 21, 2025. The missile strike represents an unusual and infrequent event as hostilities related to the Russian invasion of Ukraine have been primarily focused in Eastern Ukraine. The missile strike caused substantial physical damage and disrupted normal operations at the facility. In response, we activated contingency manufacturing plans and transitioned production to alternative facilities. As restoration activities progress in Mukachevo, we expect to incur additional immaterial near-term inefficiencies. The total $51 million expense is included in restructuring and impairment charges in the consolidated statements of operations. For further information, refer to Item 1A, "Risk Factors - Global economic conditions and geopolitical uncertainty have in the past adversely affected, and could in the future adversely affect, our business, results of operations, financial condition, and access to capital markets."

[0000866374-26-000012:mdna:36]
Tariffs

[0000866374-26-000012:mdna:37]
The U.S. tariffs initially announced in April 2025, which continue to evolve, and other countries' potential retaliatory tariffs and import/export restrictions may materially increase our product input costs and negatively affect global economic conditions, contracting customer demand. As a contract manufacturer, we expect to recover the cost of tariffs by passing tariff costs to our customers which would increase net sales, decrease operating income margins, and negatively affect operating cash flow timing as we recover paid tariffs from our customers. During the fiscal year ended March 31, 2026, tariff costs paid and recoveries from our customers impacted our revenues and costs of goods by approximately one percent and had a negligible impact on our profitability. If, in the future, we are no longer able to fully pass through these tariffs, our results from operations and cash flows would be negatively impacted. On February 20, 2026, the U.S. Supreme Court struck down tariffs imposed under the International Emergency Economic Powers Act ("IEEPA") and on April 20, 2026 the U.S. government opened a system to facilitate refunds for IEEPA tariffs paid. We are considering our options with respect to claims for refunds on tariffs paid and do not expect that any refunds received would have a material effect on Flex's financial position or performance. We will continue to monitor changes in global trade policy and employ measures to mitigate the impact of tariffs and leverage competitive opportunities. However, despite these efforts, the Company may not be able to fully mitigate the impact of changes in trade policies. For further information, refer to Item 1A, "Risk Factors - Tariffs, trade restrictions, export controls, and changes in trade policy, including heightened trade volatility and uncertainty regarding trade agreements, have in the past adversely affected, and could in the future adversely affect, our business, results of operations, and financial condition."

[0000866374-26-000012:mdna:38]
Business Overview

[0000866374-26-000012:mdna:39]
We are one of the world's largest providers of global supply chain solutions, with revenues from continuing operations of $27.9 billion in the fiscal year ended March 31, 2026. We have established an extensive network of manufacturing facilities in the world's major markets (Asia, the Americas, and Europe) to serve the outsourcing needs of both multinational and regional customers. We design, build, ship, and service products for our customers through a network of more than 100 facilities across approximately 30 countries on four continents. As of March 31, 2026, our total active manufacturing capacity was approximately 27 million square feet. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-26-000012:mdna:40]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  |  |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 13,820 |  | 50 | % |  | $ | 12,656 |  | 49 | % |  |  |  |  |
| Asia | 8,401 |  | 30 | % |  | 7,701 |  | 30 | % |  |  |  |  |
| Europe | 5,693 |  | 20 | % |  | 5,456 |  | 21 | % |  |  |  |  |
|  | $ | 27,914 |  |  |  | $ | 25,813 |  |  |  |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 6,994 |  | 25 | % |  | $ | 6,854 |  | 27 | % |  |  |  |  |
| U.S. | 5,186 |  | 19 | % |  | 4,162 |  | 16 | % |  |  |  |  |
| China | 4,494 |  | 16 | % |  | 4,319 |  | 17 | % |  |  |  |  |
| Malaysia | 2,967 |  | 11 | % |  | 2,379 |  | 9 | % |  |  |  |  |
| Brazil | 1,558 |  | 6 | % |  | 1,552 |  | 6 | % |  |  |  |  |
| Hungary | 1,327 |  | 5 | % |  | 1,316 |  | 5 | % |  |  |  |  |
| Other | 5,388 |  | 18 | % |  | 5,231 |  | 20 | % |  |  |  |  |
|  | $ | 27,914 |  |  |  | $ | 25,813 |  |  |  |  |  |  |

[0000866374-26-000012:mdna:41]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |
| Mexico | $ | 891 |  | 36 | % |  | $ | 815 |  | 35 | % |
| U.S. | 443 |  | 18 | % |  | 376 |  | 16 | % |
| China | 306 |  | 12 | % |  | 293 |  | 13 | % |
| Malaysia | 191 |  | 8 | % |  | 163 |  | 7 | % |
| Hungary | 165 |  | 7 | % |  | 140 |  | 6 | % |
| Brazil | 79 |  | 3 | % |  | 83 |  | 4 | % |
| Other | 430 |  | 16 | % |  | 460 |  | 19 | % |
|  | $ | 2,505 |  |  |  | $ | 2,330 |  |  |

[0000866374-26-000012:mdna:42]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses, including many in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing products for leading multinational and regional customers. Specifically, we offer our customers the ability to simplify their global product development, manufacturing process, and after-sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-26-000012:mdna:43]
Our operating results are affected by a number of factors, including the following:

[0000866374-26-000012:mdna:44]
•global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets;

[0000866374-26-000012:mdna:45]
•the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, and other factors;

[0000866374-26-000012:mdna:46]
•the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance;

[0000866374-26-000012:mdna:47]
39

[0000866374-26-000012:mdna:48]
•our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers;

[0000866374-26-000012:mdna:49]
•the effects on our business due to certain customers' products having short product lifecycles, our customers' ability to cancel or delay orders or change production quantities or locations, the short-term nature of our customers' commitments and rapid changes in demand;

[0000866374-26-000012:mdna:50]
•the effects that current credit and market conditions could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-26-000012:mdna:51]
•the impacts on our business due to supply chain issues, including component shortages, disruptions in transportation or other supply chain related constraints including disruptions in international commerce as a result of disruptions in the Strait of Hormuz and the Red Sea, including as a result of attacks on shipping vessels;

[0000866374-26-000012:mdna:52]
•integration of acquired businesses and facilities;

[0000866374-26-000012:mdna:53]
•increased labor costs due to adverse labor conditions in the markets we operate;

[0000866374-26-000012:mdna:54]
•changes in tax legislation;

[0000866374-26-000012:mdna:55]
•changes in trade regulations and treaties; and

[0000866374-26-000012:mdna:56]
•exposure to infectious disease, epidemics and pandemics on our business operations in geographic locations impacted by an outbreak and on the business operations of our customers and suppliers.

[0000866374-26-000012:mdna:57]
We also are subject to other risks as outlined in Item 1A, "Risk Factors."

[0000866374-26-000012:mdna:58]
Net sales for fiscal year 2026 increased 8%, or $2.1 billion, to $27.9 billion from the prior year. Net sales for our ITS segment decreased $0.2 billion, or 2%, from the prior year, primarily driven by a 9% decrease in our Lifestyle business, partially offset by a 6% increase in our Communications business. Net sales for our RMS segment increased $0.5 billion, or 5%, from the prior year, primarily driven by an increase in net sales of 13% in our Industrial business and a 5% increase in our Healthcare business, partially offset by a 2% decrease in our Automotive business. Net sales for our CPI segment increased $1.8 billion or 38% from the prior year driven by increased demand across our Cloud and Cooling and Power businesses. Our fiscal year 2026 gross profit totaled $2.6 billion, representing an increase of $0.4 billion, or 19%, from the prior year. The increase was primarily driven by an increase in gross profit margin due to improved product mix with most of the revenue growth in higher margin businesses combined with operational efficiencies. Our net income from continuing operations totaled $0.9 billion, representing an increase of $42 million, or 5%, compared to fiscal year 2025, due to the factors explained above.

[0000866374-26-000012:mdna:59]
Cash provided by operating activities increased by $0.2 billion in fiscal 2026 as compared with fiscal 2025, as a result of higher profitability and favorable working capital movements. Refer to "Liquidity and Capital Resources" below for further details of changes in net working capital.

[0000866374-26-000012:mdna:60]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and to fund certain other activities. Our free cash flow is defined as cash provided by operating activities, less purchases of property and equipment and proceeds from the disposition of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. Our free cash flow was $1.1 billion and $1.1 billion for fiscal years 2026 and 2025, respectively. Refer to "Liquidity and Capital Resources" below for the free cash flows reconciliation to the most directly comparable GAAP financial measure of net cash provided by operating activities.

[0000866374-26-000012:mdna:61]
Cash used in investing activities decreased by $0.1 billion to a cash outflow of $0.7 billion for fiscal year 2026, compared with a cash outflow of $0.8 billion for fiscal year 2025, primarily due to a reduction of $0.4 billion on acquisitions, partially offset by an increase in capital expenditures of $0.2 billion. Cash used in financing activities increased by $0.1 billion to a cash outflow of $0.9 billion for fiscal year 2026, primarily driven by a reduction of $0.4 billion of borrowings and $0.3 billion lower share repurchases.

[0000866374-26-000012:mdna:62]
CRITICAL ACCOUNTING ESTIMATES

[0000866374-26-000012:mdna:63]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-

[0000866374-26-000012:mdna:64]
40

[0000866374-26-000012:mdna:65]
Hamas conflict, and recent U.S. military operations in Iran), there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-26-000012:mdna:66]
We believe the following critical accounting estimates affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2  to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-26-000012:mdna:67]
Revenue Recognition

[0000866374-26-000012:mdna:68]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assess whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when we have transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Service contract revenue is recognized on an overtime basis using the output method. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-26-000012:mdna:69]
Customer Contracts and Related Obligations

[0000866374-26-000012:mdna:70]
Certain of our customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. We estimate the variable consideration related to these price adjustments as part of the total transaction price and recognize revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. We constrain the amount of revenues recognized for these contractual provisions based on our best estimate of the amount which will not result in a significant reversal of revenue in a future period. We determine the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-26-000012:mdna:71]
Inventory Valuation

[0000866374-26-000012:mdna:72]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand and anticipated component shortages, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regards to inventory procured to fulfill customer demand.

[0000866374-26-000012:mdna:73]
Carrying Value of Long-Lived Assets

[0000866374-26-000012:mdna:74]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. An impairment loss is recognized when the carrying amount of the asset group exceeds its fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such asset groups are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair

[0000866374-26-000012:mdna:75]
value of assets may be impacted by changes in market conditions, the general business environment and other factors including geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas conflict and recent U.S. military operations in Iran), which remain highly uncertain and unpredictable. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize material impairment charges in the future.

[0000866374-26-000012:mdna:76]
Business Combinations

[0000866374-26-000012:mdna:77]
In business combinations, the fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax balances, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill and if the fair value of assets acquired and liabilities assumed exceeds the purchase consideration a gain on bargain purchase is recognized.

[0000866374-26-000012:mdna:78]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. The valuation of acquired assets and liabilities is subject to further management review and may change between the preliminary allocation and end of the one-year purchase price allocation period. Refer to note 19 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail on our acquisitions.

[0000866374-26-000012:mdna:79]
Goodwill

[0000866374-26-000012:mdna:80]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require us to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider our budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While we believe we have made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If our actual results are not consistent with our estimates and assumptions used to calculate fair value, it could result in material impairments of our goodwill. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail on our goodwill.

[0000866374-26-000012:mdna:81]
Income Taxes

[0000866374-26-000012:mdna:82]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-26-000012:mdna:83]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-26-000012:mdna:84]
RESULTS OF OPERATIONS

[0000866374-26-000012:mdna:85]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data."

[0000866374-26-000012:mdna:86]
The data below, and discussion that follows, represents our results from operations, and relative percentages.

[0000866374-26-000012:mdna:87]
|  | Fiscal Year EndedMarch 31, |
|  | 2026 |  | 2025 |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of sales | 90.6 |  |  | 91.4 |  |  |  |  |  |
| Restructuring charges | 0.2 |  |  | 0.2 |  |  |  |  |  |
| Gross profit | 9.2 |  |  | 8.4 |  |  |  |  |  |
| Selling, general and administrative expenses | 3.8 |  |  | 3.5 |  |  |  |  |  |
| Restructuring and impairment charges | 0.3 |  |  | 0.1 |  |  |  |  |  |
| Intangible amortization | 0.2 |  |  | 0.3 |  |  |  |  |  |
| Operating income | 4.9 |  |  | 4.5 |  |  |  |  |  |
| Interest expense | 0.8 |  |  | 0.8 |  |  |  |  |  |
| Interest income | 0.2 |  |  | 0.2 |  |  |  |  |  |
| Other charges (income), net | 0.1 |  |  | (0.1) |  |  |  |  |  |
| Equity in earnings (losses) of unconsolidated affiliates | (0.1) |  |  | — |  |  |  |  |  |
| Income from continuing operations before income taxes | 4.1 |  |  | 4.0 |  |  |  |  |  |
| Provision for (benefit from) income taxes | 0.9 |  |  | 0.8 |  |  |  |  |  |
| Net income attributable to Flex Ltd. | 3.2 | % |  | 3.2 | % |  |  |  |  |

[0000866374-26-000012:mdna:88]
Net sales

[0000866374-26-000012:mdna:89]
The following table sets forth our net sales by segment, and their relative percentages:

[0000866374-26-000012:mdna:90]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |  |  |  |  |
| Net sales: | (In millions) |
| Integrated Technology Solutions | $ | 11,109 |  |  | 40 | % |  | $ | 11,336 |  |  | 44 | % |  | $ | 12,636 |  |  | 48 | % |  |  |  |  |  |  |  |  |
| Regulated Manufacturing Solutions | 10,191 |  |  | 36 | % |  | 9,678 |  |  | 37 | % |  | 10,535 |  |  | 40 | % |  |  |  |  |  |  |  |  |
| Cloud and Power Infrastructure | 6,614 |  |  | 24 | % |  | 4,799 |  |  | 19 | % |  | 3,244 |  |  | 12 | % |  |  |  |  |  |  |  |  |
|  | $ | 27,914 |  |  |  |  | $ | 25,813 |  |  |  |  | $ | 26,415 |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-26-000012:mdna:91]
Net sales for the fiscal year ended March 31, 2026 totaled $27.9 billion, representing an increase of $2.1 billion, or 8%, from $25.8 billion for the fiscal year ended March 31, 2025. Net sales for our ITS segment decreased $0.2 billion, or 2%, from fiscal year 2025, mainly due to a 9% decrease in our Lifestyle business as demand weakened in consumer end markets. This was offset by a 6% increase in our Communications business due to stronger demand. Net sales in our RMS segment increased $0.5 billion, or 5%, from fiscal year 2025, driven primarily by an increase in net sales of 13% in our Industrial business which was driven by stronger demand and the contribution from our acquisition of the manufacturing facility in Orangeburg, South Carolina in February 2025. Additionally, revenue from our Healthcare business increased by 5% driven by higher demand for medical equipment. This was partially offset by a 2% decrease in our Automotive business due to weaker demand. Net sales in our CPI segment increased by $1.8 billion, or 38% from fiscal year 2025, driven by a 29% increase in our Cloud and Cooling business and 61% growth in our Power business. The overall growth in CPI is primarily related to increased demand in the data center market and $0.2 billion related contributions from acquisitions in the United States and Poland.

[0000866374-26-000012:mdna:92]
Net sales for the fiscal year ended March 31, 2025 decreased by $0.6 billion, or 2% from $26.4 billion for the fiscal year ended March 31, 2024. Net sales for the ITS segment decreased by $1.3 billion or 10% as weak demand in the Communications business decreased revenue by 19% while net sales for the Lifestyle business were flat. Net sales in our RMS segment decreased $0.9 billion, or 8%, from fiscal year 2024, driven primarily by a decrease in net sales of 17% in our Industrial business which was driven by weaker demand in renewables, clean energy and industrial devices, a 3% decrease in our Automotive business, and a 3% decrease in our Health Solution business, primarily driven by softening demand in medical

[0000866374-26-000012:mdna:93]
equipment, partially offset by increased demand for medical devices. Net sales for the CPI segment increased by $1.6 billion or 48% from $3.2 billion in fiscal year 2024. This was driven by a 58% increase in demand in the Cloud and Cooling business and 26% growth in our Power business, with a partial year contribution from the Crown acquisition.

[0000866374-26-000012:mdna:94]
Net sales for the fiscal year ended March 31, 2026 increased $1.2 billion to $13.8 billion in the Americas, increased $0.7 billion to $8.4 billion in Asia, and increased $0.2 billion to $5.7 billion in Europe.

[0000866374-26-000012:mdna:95]
Our ten largest customers during fiscal years 2026 and 2025 accounted for 45% and 44% of net sales, respectively. We maintain a diverse portfolio which allows us to operate at scale in many different industries, and, as a result, no customer accounted for greater than 10% of net sales in fiscal year 2026 or 2025.

[0000866374-26-000012:mdna:96]
Cost of sales

[0000866374-26-000012:mdna:97]
Cost of sales is affected by a number of factors, including the number and size of new manufacturing programs, product mix, labor cost fluctuations by region, component costs and availability and capacity utilization.

[0000866374-26-000012:mdna:98]
Cost of sales during fiscal year 2026 totaled $25.3 billion, representing an increase of $1.7 billion, or 7% from $23.6 billion during fiscal year 2025. The increase in cost of sales is less than the associated increase in net sales of 8%, as a result of favorable product mix with increases in revenue in higher margin Cloud and Power as well as cost actions taken during the period. Cost of sales in our ITS segment decreased $0.3 billion, or 3%, from fiscal year 2025 as a result of decreased sales and favorable product mix. Cost of sales in our RMS segment for fiscal year 2026 increased $0.4 billion, or 4%, from fiscal year 2025, due to 5% sales growth partially offset by cost reductions and favorable product mix. Cost of sales in our CPI segment for fiscal year 2026 increased $1.6 billion or 40%, from fiscal year 2025, in excess of the 38% sales growth as costs to ramp new contracts impacted margins.

[0000866374-26-000012:mdna:99]
Cost of sales for the fiscal year ended March 31, 2025 decreased by $0.8 billion, or 3% from $24.4 billion in fiscal year 2024. The decrease in cost of sales is greater than the associated decrease in consolidated sales of 2%, as a result of favorable product mix with increases in revenue in higher margin Cloud and Power as well as cost actions taken during the period. Cost of sales in ITS decreased $1.3 billion, or 11%, from fiscal year 2024. This decrease was in excess of the 10% decrease in net sales during the year as sales remained steady in the higher margin Lifestyle business. Cost of sales in RMS for fiscal year 2025 decreased $0.8 billion, or 8%, from fiscal year 2024, in line with the decrease in net sales for the segment. Cost of sales in CPI for fiscal year 2025 increased $1.3 billion or 47%, consistent with sales growth for the segment.

[0000866374-26-000012:mdna:100]
Gross profit

[0000866374-26-000012:mdna:101]
Gross profit is affected by fluctuations in cost of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all markets. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-26-000012:mdna:102]
Gross profit during fiscal year 2026 increased $0.4 billion to $2.6 billion, or 9.2% of net sales, from $2.2 billion, or 8.4% of net sales, during fiscal year 2025. The increase in gross profit during fiscal year 2026 was due to the factors discussed above as well as lower restructuring costs in fiscal year 2026.

[0000866374-26-000012:mdna:103]
Segment income

[0000866374-26-000012:mdna:104]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, certain restructuring charges, customer-related asset impairment charges or recoveries, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-26-000012:mdna:105]
The following table sets forth segment income and margins. Segment margins in the table below may not recalculate exactly due to rounding.

[0000866374-26-000012:mdna:106]
44

[0000866374-26-000012:mdna:107]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |  |  |  |  |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integrated Technology Solutions | $ | 596 |  |  | 5.4 | % |  | $ | 541 |  |  | 4.8 | % |  | $ | 489 |  |  | 3.9 | % |  |  |  |  |  |  |  |  |
| Regulated Manufacturing Solutions | 611 |  |  | 6.0 | % |  | 505 |  |  | 5.2 | % |  | 540 |  |  | 5.1 | % |  |  |  |  |  |  |  |  |
| Cloud and Power Infrastructure | 610 |  |  | 9.2 | % |  | 492 |  |  | 10.2 | % |  | 306 |  |  | 9.4 | % |  |  |  |  |  |  |  |  |

[0000866374-26-000012:mdna:108]
ITS segment margin increased 60 basis points, to 5.4% for fiscal year 2026, from 4.8% for fiscal year 2025. The margin increase during the period was driven by improvement in the Communications business with strong execution, product mix and cost actions taken. ITS segment margin increased 90 basis points for fiscal year 2025, from 3.9% in fiscal year 2024. The margin increased in both Communications and Lifestyle businesses from strong execution, product mix and cost actions taken.

[0000866374-26-000012:mdna:109]
RMS segment margin increased 80 basis points, to 6.0% for fiscal year 2026, from 5.2% for fiscal year 2025. The margin increase in the RMS segment was primarily driven by strength in the Industrial business with increased productivity, favorable mix and cost actions taken. RMS segment margin increased by 10 basis points for fiscal year 2025, from 5.1% for fiscal year 2024, with an increase in Healthcare margins offsetting weakness in Industrial and Automotive.

[0000866374-26-000012:mdna:110]
CPI segment margin decreased 100 basis points, to 9.2% for fiscal year 2026. The margin decrease in the CPI segment was primarily driven by the costs to ramp the business and unfavorable mix in the Cloud and Cooling business, partially offset by faster growth in the higher margin Power business. CPI segment margin increased by 80 basis points for fiscal year 2025. The margin increased in both Power and Cloud and Cooling reflecting favorable product mix and strong execution.

[0000866374-26-000012:mdna:111]
Restructuring and impairment charges

[0000866374-26-000012:mdna:112]
During fiscal year 2026, we committed to targeted restructuring activities to improve operational efficiency by reducing excess workforce capacity. As a result, we recognized $87 million of restructuring charges, primarily related to employee severance. During fiscal year 2025, we recognized $86 million of restructuring charges, also primarily related to employee severance. Additionally, in fiscal year 2026 we also recognized $51 million in impairment and other charges related to a missile strike on our Mukachevo, Ukraine facility as discussed in the Overview section above.

[0000866374-26-000012:mdna:113]
Refer to note 16 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-26-000012:mdna:114]
Selling, general and administrative expenses

[0000866374-26-000012:mdna:115]
Selling, general and administrative expenses ("SG&A") totaled $1.1 billion, during fiscal year 2026, compared to $904 million during fiscal year 2025, increasing by $148 million. The increase was primarily driven by an increase in labor and infrastructure costs in line with growth of the business as well as a $44 million increase in legal and other costs associated with portfolio optimization projects, including the anticipated spin-off of the CPI segment.

[0000866374-26-000012:mdna:116]
Intangible amortization

[0000866374-26-000012:mdna:117]
Amortization of intangible assets was $68 million and $70 million in fiscal years 2026 and 2025, respectively. The change of $2 million was due to certain intangible assets becoming fully amortized, partially offset by amortization related to acquisitions from fiscal years 2025 and 2026.

[0000866374-26-000012:mdna:118]
Interest expense

[0000866374-26-000012:mdna:119]
Interest expense was $215 million during fiscal year 2026, compared to $218 million during fiscal year 2025, decreasing $3 million primarily due to lower costs from reduced factoring of accounts receivable during the year, partially offset by higher average debt balances during the year and higher interest rates on refinanced notes.

[0000866374-26-000012:mdna:120]
Interest income

[0000866374-26-000012:mdna:121]
Interest income was $51 million during fiscal year 2026, compared to $61 million during fiscal year 2025, decreasing $10 million primarily due to lower interest rates and lower average cash balances.

[0000866374-26-000012:mdna:122]
Other charges (income), net

[0000866374-26-000012:mdna:123]
During fiscal year 2026, we recorded $30 million of other charges, net, compared to $14 million of other income, net, in fiscal year 2025. The charge in fiscal year 2026 largely related to unfavorable foreign exchange movements and an impairment of a non-core unconsolidated investment. The income in fiscal year 2025 predominantly resulted from a gain on bargain purchase of $19 million on an acquisition occurring during the fourth quarter of fiscal year 2025.

[0000866374-26-000012:mdna:124]
Refer to notes 17 and 19 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our other charges (income), net and business acquisitions and divestitures.

[0000866374-26-000012:mdna:125]
Equity in earnings (losses) of unconsolidated affiliates

[0000866374-26-000012:mdna:126]
During fiscal year 2026, we recorded $31 million of equity in losses of unconsolidated affiliates, compared to $3 million of losses during fiscal year 2025. The increase during fiscal year 2026 was primarily due to losses related to a specific venture capital fund.

[0000866374-26-000012:mdna:127]
Income taxes

[0000866374-26-000012:mdna:128]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |
|  | Amount |  | Effective Tax Rate |  | Amount |  | Effective Tax Rate |
|  | (In millions, except percentages) |
| Provision for (benefit from) income taxes | $ | 263 |  |  | 23.0 | % |  | $ | 185 |  |  | 18.1 | % |

[0000866374-26-000012:mdna:129]
We work to ensure that we accrue and pay the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which we operate. The consolidated effective tax rates were 23.0% and 18.1% for the fiscal years 2026 and 2025, respectively. The effective income tax rate differed for the fiscal year ended March 31, 2026, compared to the fiscal year ended March 31, 2025, primarily due to: (i) recognition of a $19 million tax provision in the fiscal year ended March 31, 2026 related to a definitive settlement agreement with a foreign tax authority for the fiscal years 2010 through 2020, (ii) a $26 million tax benefit related to prior years interest recoverable by one of our Brazilian subsidiaries during the fiscal year ended March 31, 2025 and (iii) a change in the jurisdictional mix of earnings. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effects of certain tax holidays and incentives granted in certain countries in which the Company is located.  Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion.

[0000866374-26-000012:mdna:130]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our effective tax rate, tax position, operating results, financial position and cash flows.

[0000866374-26-000012:mdna:131]
The OECD Pillar Two Global Anti-Base Erosion (“GloBE”) model rules, issued under the OECD Inclusive Framework on Base Erosion and Profit Shifting, introduced a global minimum tax of 15% applicable to multinational enterprise groups with consolidated financial statement revenue in excess of €750 million. Numerous foreign jurisdictions have already enacted tax legislation based on the GloBE rules, with some effective as early as January 1, 2024. As of March 31, 2026, these changes did not have a material impact to our effective income tax rate for the fiscal year ended March 31, 2026.

[0000866374-26-000012:mdna:132]
On July 4, 2025, The One Big Beautiful Bill Act (“OBBBA”) was enacted in the U.S. The OBBBA makes permanent various provisions of the Tax Cuts and Jobs Act which otherwise would have expired as well as makes significant modifications to the U.S. international tax framework. The Company does not expect a material impact to the consolidated financial statements from the OBBBA, however, the Company will continue to monitor developments and evaluate any potential future impacts.

[0000866374-26-000012:mdna:133]
Net income from continuing operations

[0000866374-26-000012:mdna:134]
Net income from continuing operations was $880 million during fiscal year 2026, compared to $838 million during fiscal year 2025, driven by the factors outlined above.

[0000866374-26-000012:mdna:135]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-26-000012:mdna:136]
We continuously evaluate our ability to meet our obligations over the next 12 months and have proactively adjusted our capital structure to improve maturities and liquidity. We expect that our current financial condition, including our liquidity sources, are adequate to fund current and future commitments. As of March 31, 2026, we had cash and cash equivalents of $2.4 billion and bank and other borrowings of $3.8 billion. We have a $2.75 billion revolving credit facility under which we had no borrowings outstanding as of March 31, 2026. As of March 31, 2026, we were in compliance with the covenants under all of our credit facilities and indentures and expect to remain in compliance with the covenants in the upcoming 12 months.

[0000866374-26-000012:mdna:137]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2026, 62% of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore ($0.9 billion as of March 31, 2026). Repatriation could result in an additional income tax payment; however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-26-000012:mdna:138]
Fiscal Year 2026

[0000866374-26-000012:mdna:139]
Cash provided by operating activities was $1.7 billion during fiscal year 2026. The total cash provided by operating activities resulted primarily from $0.9 billion of net income for the period plus $0.9 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, deferred income taxes and stock-based compensation. These cash inflows were partially offset by a net change in our operating assets and liabilities of $0.1 billion as the growth in inventory, contract assets, other current assets, and accounts receivable were offset by an increase in accounts payable and other current liabilities.

[0000866374-26-000012:mdna:140]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital increased by $1.3 billion to $4.3 billion as of March 31, 2026 from $3.0 billion as of March 31, 2025. This increase was primarily driven by a $1.2 billion decrease in the current portion of our long-term debt as amounts falling due were repaid. Other movements largely offset each other with a $1.0 billion increase in the net accounts receivable, a $1.2 billion increase in other current assets, principally customer controlled inventory, and a $0.8 billion increase in inventory, offset by a $2.9 billion increase in accounts payable.

[0000866374-26-000012:mdna:141]
Cash used in investing activities totaled $0.7 billion during fiscal year 2026. This was primarily driven by $0.6 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our business growth. Refer to note 19 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our business acquisitions and divestitures.

[0000866374-26-000012:mdna:142]
Cash used in financing activities was $0.9 billion during fiscal year 2026. This was primarily driven by $0.9 billion of cash paid for the repurchase of our ordinary shares as debt repayments and borrowings largely offset each other. Refer to note 9 and note 20 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for additional details.

[0000866374-26-000012:mdna:143]
Fiscal Year 2025

[0000866374-26-000012:mdna:144]
Cash provided by operating activities was $1.5 billion during fiscal year 2025. The total cash provided by operating activities resulted primarily from $0.8 billion of net income for the period plus $0.8 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, deferred income taxes and stock-based compensation.  Non-cash charges were in line with the prior year with the exception of deferred income taxes that were significantly impacted in fiscal year 2024 by discrete events in the year. These cash inflows of $1.6 billion were partially offset by a net change in our operating assets and liabilities of $0.1 billion as the reduction in inventory and increase in payables compared to fiscal year 2024 were offset by increases in accounts receivable, contract assets and a decrease in working capital advances.

[0000866374-26-000012:mdna:145]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital decreased by $1.5 billion to $3.0 billion as of March 31, 2025 from $4.5 billion as of March 31, 2024. This decrease was primarily driven by a $1.2 billion increase in the current portion of long-term debt as two notes matured within twelve months of March 31, 2025. Additional factors include a $1.1 billion decrease in inventory and a $0.7 billion increase in accounts payable being partially offset by a $0.6 billion increase in accounts receivable,

[0000866374-26-000012:mdna:146]
net, a $0.4 billion increase in contract assets and working capital advances decreasing by $0.6 billion as inventory levels reduced.

[0000866374-26-000012:mdna:147]
Cash used in investing activities totaled $0.8 billion during fiscal year 2025. This was primarily driven by $0.4 billion of cash paid for the acquisitions of the Orangeburg manufacturing facility, Crown and JetCool, net of cash acquired, and $0.4 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our businesses. Refer to note 19 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our business acquisitions and divestitures.

[0000866374-26-000012:mdna:148]
Cash used in financing activities was $0.8 billion during fiscal year 2025. This was primarily driven by $1.3 billion of cash paid for the repurchase of our ordinary shares, partially offset by $0.5 billion of proceeds from borrowings. Refer to note 9 and note 20 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for additional details.

[0000866374-26-000012:mdna:149]
Free Cash Flow

[0000866374-26-000012:mdna:150]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is defined as net cash provided by operating activities, less purchases of property and equipment and proceeds from the disposition of property and equipment. Our free cash flow was $1.1 billion for both fiscal years 2026 and 2025. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of net cash provided by operating activities as follows:

[0000866374-26-000012:mdna:151]
|  | Fiscal Year Ended March 31, |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,685 |  |  | $ | 1,505 |  |  |  |  |  |
| Purchases of property and equipment | (633) |  |  | (438) |  |  |  |  |  |
| Proceeds from the disposition of property and equipment | 8 |  |  | 15 |  |  |  |  |  |
| Free cash flow | $ | 1,060 |  |  | $ | 1,082 |  |  |  |  |  |

[0000866374-26-000012:mdna:152]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months and beyond.

[0000866374-26-000012:mdna:153]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volume of customer orders.

[0000866374-26-000012:mdna:154]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of March 31, 2026.

[0000866374-26-000012:mdna:155]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed

[0000866374-26-000012:mdna:156]
Historically, we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In July 2025, the Company entered into a new $2.75 billion credit facility (“2030 Credit Facility”) which matures in July 2030 and consists of a $2.75 billion revolving credit facility with a sub-limit of $400 million available for swing line loans and a sub-limit of $200 million available for the issuance of letters of credit. The 2030 Credit Facility replaced the previous $2.5 billion credit facility, which was due to mature in July 2027. Refer to note 9 "Bank Borrowings and Long-Term Debt" to the consolidated financial statements included in Item 8, "Financial Statements and Supplementary Data" for additional information.

[0000866374-26-000012:mdna:157]
48

[0000866374-26-000012:mdna:158]
On April 30, 2026, the Company entered into, and fully drew down,  a credit agreement which provides a senior delayed draw term loan credit facility in an aggregate commitment amount of $1.45 billion. Refer to note 22 "Subsequent Events" to the consolidated financial statements included under in Item 8, "Financial Statements and Supplementary Data" for additional information.

[0000866374-26-000012:mdna:159]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-26-000012:mdna:160]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1.7 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 6, 2025. During fiscal year 2026, we paid $0.9 billion to repurchase shares under the current and prior repurchase plans at an average price of $49.08 per share. As of March 31, 2026, shares in the aggregate amount of $1.1 billion were available to be repurchased under the current plan.

[0000866374-26-000012:mdna:161]
Warrant

[0000866374-26-000012:mdna:162]
On August 15, 2025, we issued a warrant (the “Warrant”) to Amazon.com NV Investment Holdings LLC, a wholly-owned subsidiary of Amazon.com, Inc. (“Parent”) to purchase up to an aggregate of 3,859,851 ordinary shares of the Company (“Warrant Shares”) at an exercise price of $51.29 per share. The Warrant allows for cashless exercise and expires on August 15, 2030. The Warrant Shares are subject to vesting based on qualifying payments (as defined in the Warrant) for the purchase of all products and services by or on behalf of Parent and its affiliates over the term of the Warrant. The expense associated with the Warrant Shares will be recorded as a deduction to revenue as the customer purchases products and services over the vesting period. The Company recorded charges of $7 million related to the Warrant during the fiscal year ended March 31, 2026.

[0000866374-26-000012:mdna:163]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-26-000012:mdna:164]
Refer to note 9 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details of our debt obligations.

[0000866374-26-000012:mdna:165]
In addition, we have leased certain of our property and equipment under finance lease commitments, and certain of our facilities and equipment under operating lease commitments. The following table summarizes current and non-current material cash requirements as of March 31, 2026 including future payments due under our debt including finance leases and related interest obligations and operating leases (amounts may not sum due to rounding):

[0000866374-26-000012:mdna:166]
|  | Total |  | 1 Year or Less |  | 2 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In millions) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings, long-term debt and finance lease obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and long-term debt | $ | 3,768 |  |  | $ | — |  |  | $ | 928 |  |  | $ | 1,384 |  |  | $ | 1,456 |  |
| Interest on long-term debt obligations | 827 |  |  | 177 |  |  | 292 |  |  | 178 |  |  | 180 |  |
| Operating leases, net of subleases | 811 |  |  | 175 |  |  | 281 |  |  | 179 |  |  | 176 |  |
| Capital expenditures | 286 |  |  | 257 |  |  | 29 |  |  | — |  |  | — |  |
| Restructuring costs | 63 |  |  | 63 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 5,755 |  |  | $ | 672 |  |  | $ | 1,530 |  |  | $ | 1,741 |  |  | $ | 1,812 |  |

[0000866374-26-000012:mdna:167]
We also have outstanding firm purchase orders with certain suppliers for the purchase of inventory, which are not included in the table above. The majority of the purchase obligations are generally short-term in nature. We generally do not enter into non-cancelable purchase orders for materials until we receive a corresponding production forecast from our customers. Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-26-000012:mdna:168]
49

[0000866374-26-000012:mdna:169]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-26-000012:mdna:170]
Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for recent accounting pronouncements.

[0000866374-26-000012:mdna:171]
50
