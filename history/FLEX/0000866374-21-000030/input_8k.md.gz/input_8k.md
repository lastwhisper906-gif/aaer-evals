# FLEX 8-K — 0000866374-21-000027 filed 2021-05-05

## item codes, every 8-K on or before 2021-05-19

- 2021-05-05 0000866374-21-000027 — 2.02, 9.01
- 2021-02-26 0000866374-21-000021 — 5.02
- 2021-01-28 0000866374-21-000016 — 2.02, 9.01
- 2021-01-22 0000866374-21-000012 — 5.02 — amendment of 0000866374-20-000037
- 2021-01-13 0000866374-21-000006 — 1.01, 1.02, 2.03, 9.01
- 2020-11-24 0000866374-20-000037 — 5.02, 9.01
- 2020-11-23 0000866374-20-000034 — 5.02, 7.01, 9.01
- 2020-10-29 0000866374-20-000028 — 2.02, 9.01
- 2020-09-21 0000866374-20-000021 — 5.02, 9.01
- 2020-09-18 0000866374-20-000017 — 5.02
- 2020-08-17 0001104659-20-096092 — 1.01, 8.01, 9.01
- 2020-08-11 0001104659-20-093288 — 5.02, 5.07, 9.01
- 2020-08-07 0001104659-20-092018 — 5.02, 7.01, 9.01
- 2020-07-30 0001104659-20-088503 — 2.02, 9.01
- 2020-06-09 0001104659-20-071371 — 5.02, 9.01
- 2020-06-03 0001104659-20-069435 — 5.02, 9.01
- 2020-05-12 0001104659-20-060179 — 1.01, 8.01, 9.01
- 2020-05-07 0001104659-20-058102 — 2.02, 8.01, 9.01
- 2020-04-20 0000866374-20-000005 — 5.02, 9.01 — amendment of 0001104659-20-044212
- 2020-04-07 0001104659-20-044212 — 5.02, 7.01, 9.01
- 2020-04-02 0001104659-20-042445 — 5.02, 8.01, 9.01
- 2020-03-09 0001104659-20-030489 — 7.01, 9.01
- 2020-01-30 0001104659-20-008704 — 2.02, 9.01
- 2019-11-07 0001104659-19-061133 — 8.01, 9.01
- 2019-10-24 0001104659-19-056135 — 2.02, 9.01
- 2019-08-23 0001410578-19-000891 — 3.03, 5.07, 8.01, 9.01
- 2019-08-08 0001410578-19-000722 — 8.01
- 2019-07-25 0001104659-19-041852 — 2.02, 2.05, 9.01
- 2019-06-10 0001410578-19-000371 — 5.02
- 2019-06-06 0001104659-19-034315 — 1.01, 8.01, 9.01
- 2019-05-31 0001104659-19-032835 — 8.01, 9.01
- 2019-05-30 0001104659-19-032818 — 8.01, 9.01
- 2019-05-30 0001104659-19-032593 — 8.01, 9.01
- 2019-04-30 0001104659-19-025293 — 2.02, 9.01
- 2019-03-07 0001104659-19-013420 — 5.02
- 2019-02-11 0001104659-19-006978 — 5.02, 7.01, 9.01
- 2019-02-06 0001104659-19-005884 — 5.02
- 2019-01-30 0001104659-19-004485 — 2.02, 9.01
- 2019-01-18 0001104659-19-002495 — 5.02
- 2018-12-28 0001104659-18-075143 — 5.02
- 2018-12-11 0001104659-18-072382 — 5.02
- 2018-11-15 0001104659-18-068678 — 5.02, 9.01
- 2018-10-25 0001104659-18-063948 — 2.02, 9.01
- 2018-10-25 0001104659-18-063944 — 5.02, 9.01
- 2018-08-21 0001104659-18-053031 — 5.07, 8.01, 9.01
- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2021-05-19

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0000866374-21-000027:8k_2_02:1]
EX-99.1
2
flexex9915521.htm
EX-99.1

[0000866374-21-000027:8k_2_02:2]
Document

[0000866374-21-000027:8k_2_02:3]
EXHIBIT 99.1

[0000866374-21-000027:8k_2_02:4]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:5]
FLEX REPORTS FOURTH QUARTER AND FISCAL 2021 RESULTS

[0000866374-21-000027:8k_2_02:6]
San Jose, Calif., May 5, 2021 – Flex (NASDAQ: FLEX) today announced results for its fourth quarter and fiscal year ended March 31, 2021.

[0000866374-21-000027:8k_2_02:7]
Fourth Quarter Fiscal Year 2021 Highlights:

[0000866374-21-000027:8k_2_02:8]
•Net Sales: $6.3 billion

[0000866374-21-000027:8k_2_02:9]
•GAAP Income Before Income Taxes: $260 million

[0000866374-21-000027:8k_2_02:10]
•Adjusted Operating Income: $310 million

[0000866374-21-000027:8k_2_02:11]
•GAAP Net Income: $240 million

[0000866374-21-000027:8k_2_02:12]
•Adjusted Net Income: $248 million

[0000866374-21-000027:8k_2_02:13]
•GAAP Earnings Per Share: $0.47

[0000866374-21-000027:8k_2_02:14]
•Adjusted Earnings Per Share: $0.49

[0000866374-21-000027:8k_2_02:15]
Fiscal Year 2021 Results of Operations:

[0000866374-21-000027:8k_2_02:16]
•Net Sales: $24.1 billion

[0000866374-21-000027:8k_2_02:17]
•GAAP Income Before Income Taxes: $714 million

[0000866374-21-000027:8k_2_02:18]
•Adjusted Operating Income: $1.0 billion

[0000866374-21-000027:8k_2_02:19]
•GAAP Net Income: $613 million

[0000866374-21-000027:8k_2_02:20]
•Adjusted Net Income: $795 million

[0000866374-21-000027:8k_2_02:21]
•GAAP Earnings Per Share: $1.21

[0000866374-21-000027:8k_2_02:22]
•Adjusted Earnings Per Share: $1.57

[0000866374-21-000027:8k_2_02:23]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedules II and V attached to this press release.

[0000866374-21-000027:8k_2_02:24]
“We are very pleased with our strong fourth quarter results,” said Revathi Advaithi, Chief Executive Officer for Flex. “Our progress on our multi-year transformation during fiscal 2021 is reflected in our overall solid performance during a very challenging global environment this past year, and I am confident that we will continue our positive momentum in FY22.”

[0000866374-21-000027:8k_2_02:25]
First Quarter Fiscal Year 2022 Guidance

[0000866374-21-000027:8k_2_02:26]
•Revenue: $5.9 billion to $6.3 billion

[0000866374-21-000027:8k_2_02:27]
•GAAP Income Before Income Taxes: $160 million to $200 million

[0000866374-21-000027:8k_2_02:28]
•Adjusted Operating Income: $240 million to $280 million

[0000866374-21-000027:8k_2_02:29]
•GAAP EPS: $0.26 to $0.32 which includes $0.05 for stock-based compensation expense and $0.03 for net intangible amortization

[0000866374-21-000027:8k_2_02:30]
•Adjusted EPS: $0.34 to $0.40

[0000866374-21-000027:8k_2_02:31]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:32]
Fiscal Year 2022 Guidance

[0000866374-21-000027:8k_2_02:33]
•Revenue: $25 billion to $26 billion

[0000866374-21-000027:8k_2_02:34]
•GAAP EPS: $1.30 to $1.45 which includes $0.21 for stock-based compensation expense and $0.09 for net intangible amortization

[0000866374-21-000027:8k_2_02:35]
•Adjusted EPS: $1.60 to $1.75

[0000866374-21-000027:8k_2_02:36]
Webcast and Conference Call

[0000866374-21-000027:8k_2_02:37]
The Flex management team will host a conference call today at 8:00 AM (PT) / 11:00 AM (ET), to review fourth quarter and fiscal 2021 results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com. An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0000866374-21-000027:8k_2_02:38]
About Flex

[0000866374-21-000027:8k_2_02:39]
Flex (Reg. No. 199002645H) is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across 30 countries and responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets.

[0000866374-21-000027:8k_2_02:40]
Contacts

[0000866374-21-000027:8k_2_02:41]
Investors & Analysts

[0000866374-21-000027:8k_2_02:42]
David Rubin

[0000866374-21-000027:8k_2_02:43]
Vice President, Investor Relations

[0000866374-21-000027:8k_2_02:44]
(408) 577-4632

[0000866374-21-000027:8k_2_02:45]
David.Rubin@flex.com

[0000866374-21-000027:8k_2_02:46]
Media & Press

[0000866374-21-000027:8k_2_02:47]
Silvia Gianelli

[0000866374-21-000027:8k_2_02:48]
Senior Director, Corporate Communications

[0000866374-21-000027:8k_2_02:49]
(408) 797-7130

[0000866374-21-000027:8k_2_02:50]
Silvia.Gianelli@flex.com

[0000866374-21-000027:8k_2_02:51]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:52]
Forward-Looking Statements

[0000866374-21-000027:8k_2_02:53]
This press release does not constitute an offer to sell or the solicitation of an offer to buy any securities.  Any securities to be offered in any offering may not be sold nor may offers to buy be accepted prior to the time a registration statement becomes effective.

[0000866374-21-000027:8k_2_02:54]
Additional information concerning these, and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our annual report on Form 10-K for the fiscal year ended March 31, 2020 and our quarterly

[0000866374-21-000027:8k_2_02:55]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:56]
report on Form 10-Q for the fiscal quarter ended December 31, 2020. The forward-looking statements in this press release are based on current expectations and Flex assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0000866374-21-000027:8k_2_02:57]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:58]
SCHEDULE I

[0000866374-21-000027:8k_2_02:59]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In millions, except per share amounts) |
|  |  | Three-Month Periods Ended |
|  |  | March 31, 2021 |  | March 31, 2020 |
| GAAP: |  |  |  |
|  | Net sales | $ | 6,266 |  |  | $ | 5,484 |  |
|  | Cost of sales | 5,732 |  |  | 5,103 |  |
|  | Restructuring charges | 25 |  |  | 15 |  |
|  | Gross profit | 509 |  |  | 366 |  |
|  | Selling, general and administrative expenses | 211 |  |  | 201 |  |
|  | Intangible amortization | 15 |  |  | 15 |  |
|  | Restructuring charges | 1 |  |  | 2 |  |
|  | Interest, net (2) | 36 |  |  | 36 |  |
|  | Other charges (income), net (2) | (14) |  |  | 67 |  |
|  | Income before income taxes | 260 |  |  | 45 |  |
|  | Provision for income taxes | 20 |  |  | (3) |  |
|  | Net Income | $ | 240 |  |  | $ | 48 |  |
| Earnings per share: |  |  |  |
|  | GAAP | $ | 0.47 |  |  | $ | 0.10 |  |
|  | Non-GAAP | $ | 0.49 |  |  | $ | 0.28 |  |
|  | Diluted shares used in computing per share amounts | 507 |  |  | 506 |  |
|  | See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |

[0000866374-21-000027:8k_2_02:60]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:61]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In millions, except per share amounts) |
|  |  | Twelve-Month Periods Ended |
|  |  | March 31, 2021 |  | March 31, 2020 |
| GAAP: |  |  |  |
|  | Net sales | $ | 24,124 |  |  | $ | 24,210 |  |
|  | Cost of sales | 22,349 |  |  | 22,681 |  |
|  | Restructuring charges | 88 |  |  | 190 |  |
|  | Gross profit | 1,687 |  |  | 1,339 |  |
|  | Selling, general and administrative expenses | 817 |  |  | 834 |  |
|  | Intangible amortization | 62 |  |  | 64 |  |
|  | Restructuring charges | 13 |  |  | 26 |  |
|  | Interest, net (2) | 148 |  |  | 174 |  |
|  | Other charges (income), net (2) | (67) |  |  | 82 |  |
|  | Income before income taxes | 714 |  |  | 159 |  |
|  | Provision for income taxes | 101 |  |  | 71 |  |
|  | Net Income | $ | 613 |  |  | $ | 88 |  |
| Earnings per share: |  |  |  |
|  | GAAP | $ | 1.21 |  |  | $ | 0.17 |  |
|  | Non-GAAP | $ | 1.57 |  |  | $ | 1.23 |  |
|  | Diluted shares used in computing per share amounts | 506 |  |  | 512 |  |
|  | See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |

[0000866374-21-000027:8k_2_02:62]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:63]
SCHEDULE II

[0000866374-21-000027:8k_2_02:64]
| FLEX |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1) |
| (In millions, except per share amounts) * |
|  |  | Three-Month Periods Ended |
|  |  | March 31, 2021 |  | March 31, 2020 |
| GAAP income before income taxes | $ | 260 |  |  | $ | 45 |  |
|  | Intangible amortization | 15 |  |  | 15 |  |
|  | Stock-based compensation expense | 18 |  |  | 18 |  |
|  | Customer related asset impairments (recoveries) | (3) |  |  | 11 |  |
|  | Restructuring charges | 26 |  |  | 17 |  |
|  | Legal and other | (27) |  |  | (2) |  |
|  | Interest, net (2) | 36 |  |  | 36 |  |
|  | Other charges (income), net (2) | (14) |  |  | 67 |  |
| Non-GAAP operating income | $ | 310 |  |  | $ | 207 |  |
| GAAP provision for (benefit from) income taxes | $ | 20 |  |  | $ | (3) |  |
|  | Intangible amortization benefit | 2 |  |  | 2 |  |
|  | Other tax related adjustments | 14 |  |  | (12) |  |
|  | Tax benefit on restructuring and other | 5 |  |  | 41 |  |
| Non-GAAP provision for income taxes | $ | 40 |  |  | $ | 27 |  |
| GAAP net income | $ | 240 |  |  | $ | 48 |  |
|  | Intangible amortization | 15 |  |  | 15 |  |
|  | Stock-based compensation expense | 18 |  |  | 18 |  |
|  | Restructuring charges | 26 |  |  | 17 |  |
|  | Customer related asset impairments (recoveries) | (3) |  |  | 11 |  |
|  | Legal and other | (27) |  |  | (2) |  |
|  | Interest and other charges, net | 1 |  |  | 66 |  |
|  | Adjustments for taxes | (21) |  |  | (31) |  |
| Non-GAAP net income | $ | 248 |  |  | $ | 143 |  |
| Diluted earnings per share: |
|  | GAAP | $ | 0.47 |  |  | $ | 0.10 |  |
|  | Non-GAAP | $ | 0.49 |  |  | $ | 0.28 |  |
|  | See the accompanying notes on Schedule V attached to this press release. |
|  | *Amounts may not sum due to rounding |  |  |  |

[0000866374-21-000027:8k_2_02:65]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:66]
| FLEX |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1) |
| (In millions, except per share amounts) * |
|  |  | Twelve-Month Periods Ended |
|  |  | March 31, 2021 |  | March 31, 2020 |
| GAAP income before income taxes | $ | 714 |  |  | $ | 159 |  |
|  | Intangible amortization | 62 |  |  | 64 |  |
|  | Stock-based compensation expense | 79 |  |  | 71 |  |
|  | Customer related asset impairments (recoveries) | (7) |  |  | 106 |  |
|  | Restructuring charges | 101 |  |  | 216 |  |
|  | Legal and other | 1 |  |  | 26 |  |
|  | Interest, net (2) | 148 |  |  | 174 |  |
|  | Other charges (income), net (2) | (67) |  |  | 82 |  |
| Non-GAAP operating income | $ | 1,031 |  |  | $ | 898 |  |
| GAAP provision for income taxes | $ | 101 |  |  | $ | 71 |  |
|  | Intangible amortization benefit | 8 |  |  | 8 |  |
|  | Other tax related adjustments | 11 |  |  | (31) |  |
|  | Tax benefit on restructuring and other | 9 |  |  | 56 |  |
| Non-GAAP provision for income taxes | $ | 129 |  |  | $ | 105 |  |
| GAAP net income | $ | 613 |  |  | $ | 88 |  |
|  | Intangible amortization | 62 |  |  | 64 |  |
|  | Stock-based compensation expense | 79 |  |  | 71 |  |
|  | Restructuring charges | 101 |  |  | 216 |  |
|  | Customer related asset impairments (recoveries) | (7) |  |  | 106 |  |
|  | Legal and other | 1 |  |  | 26 |  |
|  | Interest and other charges (income), net | (27) |  |  | 93 |  |
|  | Adjustments for taxes | (28) |  |  | (34) |  |
| Non-GAAP net income | $ | 795 |  |  | $ | 632 |  |
| Diluted earnings per share: |  |  |  |
|  | GAAP | $ | 1.21 |  |  | $ | 0.17 |  |
|  | Non-GAAP | $ | 1.57 |  |  | $ | 1.23 |  |
|  | See the accompanying notes on Schedule V attached to this press release. |  |  |
|  | *Amounts may not sum due to rounding |  |  |  |

[0000866374-21-000027:8k_2_02:67]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:68]
SCHEDULE III

[0000866374-21-000027:8k_2_02:69]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
|  |  | As of March 31, 2021 |  | As of March 31, 2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
|  | Cash and cash equivalents | $ | 2,637 |  |  | $ | 1,923 |  |
|  | Accounts receivable, net of allowance for doubtful accounts | 4,106 |  |  | 2,436 |  |
|  | Contract assets | 135 |  |  | 282 |  |
|  | Inventories | 3,895 |  |  | 3,785 |  |
|  | Other current assets | 590 |  |  | 660 |  |
| Total current assets | 11,363 |  |  | 9,086 |  |
| Property and equipment, net | 2,097 |  |  | 2,216 |  |
| Operating lease right-of-use assets, net | 642 |  |  | 605 |  |
| Goodwill | 1,090 |  |  | 1,065 |  |
| Other intangible assets, net | 213 |  |  | 262 |  |
| Other assets | 431 |  |  | 456 |  |
| Total assets | $ | 15,836 |  |  | $ | 13,690 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |
| Current liabilities: |  |  |  |
|  | Bank borrowings and current portion of long-term debt | $ | 268 |  |  | $ | 149 |  |
|  | Accounts payable | 5,247 |  |  | 5,108 |  |
|  | Accrued payroll | 473 |  |  | 364 |  |
|  | Other current liabilities | 1,846 |  |  | 1,590 |  |
| Total current liabilities | 7,834 |  |  | 7,211 |  |
| Long-term debt, net of current portion | 3,515 |  |  | 2,689 |  |
| Operating lease liabilities, non-current | 562 |  |  | 529 |  |
| Other liabilities | 489 |  |  | 430 |  |
| Total shareholders' equity | 3,436 |  |  | 2,831 |  |
| Total liabilities and shareholders' equity | $ | 15,836 |  |  | $ | 13,690 |  |

[0000866374-21-000027:8k_2_02:70]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:71]
SCHEDULE IV

[0000866374-21-000027:8k_2_02:72]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
|  |  | Twelve-Month Periods Ended |
|  |  | March 31, 2021 |  | March 31, 2020 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
|  | Net income | $ | 613 |  |  | $ | 88 |  |
|  | Depreciation, amortization and other impairment charges (2) | 569 |  |  | 626 |  |
|  | Changes in working capital and other, net (2) | (1,039) |  |  | (2,247) |  |
|  | Net cash provided by (used in) operating activities | 144 |  |  | (1,533) |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
|  | Purchases of property and equipment | (351) |  |  | (462) |  |
|  | Proceeds from the disposition of property and equipment | 85 |  |  | 106 |  |
|  | Cash collections of deferred purchase price | — |  |  | 2,566 |  |
|  | Other investing activities, net | 64 |  |  | 69 |  |
|  | Net cash provided by (used in) investing activities | (202) |  |  | 2,279 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
|  | Proceeds from bank borrowings and long-term debt | 2,065 |  |  | 1,070 |  |
|  | Repayments of bank borrowings and long-term debt | (1,142) |  |  | (1,316) |  |
|  | Payments for repurchases of ordinary shares | (183) |  |  | (260) |  |
|  | Other financing activities, net | 3 |  |  | (2) |  |
|  | Net cash provided by (used in) financing activities | 743 |  |  | (508) |  |
| Effect of exchange rates on cash | 29 |  |  | (12) |  |
|  | Net increase in cash and cash equivalents | 714 |  |  | 226 |  |
|  | Cash and cash equivalents, beginning of year | 1,923 |  |  | 1,697 |  |
|  | Cash and cash equivalents, end of year | $ | 2,637 |  |  | $ | 1,923 |  |

[0000866374-21-000027:8k_2_02:73]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:74]
SCHEDULE V

[0000866374-21-000027:8k_2_02:75]
FLEX AND SUBSIDIARIES

[0000866374-21-000027:8k_2_02:76]
NOTES TO SCHEDULES I, II and IV

[0000866374-21-000027:8k_2_02:77]
(1) To supplement Flex’s unaudited selected financial data presented consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges and gains, including non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude restructuring charges, customer-related asset impairments (recoveries), stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP and may be different from non-GAAP measures used by other companies. We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0000866374-21-000027:8k_2_02:78]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0000866374-21-000027:8k_2_02:79]
•the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0000866374-21-000027:8k_2_02:80]
•the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0000866374-21-000027:8k_2_02:81]
•a better understanding of how management plans and measures the Company’s underlying business; and

[0000866374-21-000027:8k_2_02:82]
•an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0000866374-21-000027:8k_2_02:83]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0000866374-21-000027:8k_2_02:84]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions. The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types. In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0000866374-21-000027:8k_2_02:85]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions. The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore

[0000866374-21-000027:8k_2_02:86]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:87]
excludes such charges when presenting non-GAAP financial measures. The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0000866374-21-000027:8k_2_02:88]
Customer related asset impairments (recoveries) may consist of non-cash impairments of property and equipment to estimated fair value for customers we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In addition, it includes write-downs of inventory that will not be recovered due to significant reductions in future customer demand as the Company reduced its exposure to certain high volatility business in the second quarter of fiscal year 2020. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. These costs and recoveries are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0000866374-21-000027:8k_2_02:89]
Restructuring charges include severance for rationalization at existing sites and corporate SG&A functions as well as asset impairment, and other charges related to the closures and consolidations of certain operating sites and targeted activities to restructure the business. These costs may vary in size based on the Company’s initiatives and are not directly related to ongoing or core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0000866374-21-000027:8k_2_02:90]
In order to support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, the Company has identified certain structural changes to restructuring the business. These restructuring actions will eliminate non-core activities primarily within the Company’s corporate function, align the Company’s cost structure with its reorganizing and optimizing of its operations model along its two reporting segments, and further sharpen its focus to winning business in end markets where it has competitive advantages and deep domain expertise. During the three and twelve-month periods ended March 31, 2021, the Company recognized approximately $26 million and $101 million of restructuring charges respectively, most of which related to employee severance.

[0000866374-21-000027:8k_2_02:91]
During the first half of fiscal year 2020 in connection with geopolitical developments and uncertainties at the time, primarily impacting one customer in China, the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and streamline its cost structure. During fiscal year 2020, the Company recognized $216 million of restructuring charges. The Company incurred cash charges of approximately $159 million, that were predominantly for employee severance, in addition to non-cash charges of $57 million, primarily related to asset impairments.

[0000866374-21-000027:8k_2_02:92]
Legal and other consist primarily of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis. Legal and other costs include 1) certain loss contingencies where losses are considered probable and estimable accrued in the first quarter of fiscal year 2021, 2) the gain on the sale of real estate in the fourth quarter of fiscal 2021 exited as a result of the disengagement of a certain customer in fiscal year 2020, 3) certain direct and incremental costs associated with the disengagement of a certain customer in the second, third, and fourth quarters of fiscal year 2020, and 4) certain gains resulting from the recognition of prior year expenses paid to the government now considered probable of recovery and reasonably estimable due to a favorable tax ruling received in fiscal year 2020. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0000866374-21-000027:8k_2_02:93]
P R E S S   R E L E A S E

[0000866374-21-000027:8k_2_02:94]
Interest and other charges (income), net consists of various other types of items that are not directly related to ongoing or core business results, such as the gain or losses related to certain divestitures, debt extinguishment costs and impairment charges or gains associated with certain non-core investments. The Company excludes these items because they are not related to the Company’s ongoing operating performance or do not affect core operations. Excluding these amounts provides investors with a basis to compare Company performance against the performance of other companies without this variability.

[0000866374-21-000027:8k_2_02:95]
In fiscal year 2020, the Company incurred debt extinguishment costs of $7.2 million, related to full repayments of the Notes due February 2020 and Term Loan due November 2021.

[0000866374-21-000027:8k_2_02:96]
During fiscal year 2020, and in connection with the Company’s ongoing assessment of its investment portfolio strategy, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $97.7 million total impairment, of which $74.8 million was recorded in the fourth quarter. The impairments in the fourth quarter of fiscal year 2020 were primarily related to Elementum and certain other non-core investments, reflecting recent market valuation changes, in addition to capturing additional risks due to the economic challenges in light of COVID-19. This was offset by a $10.9 million realized gain from a distribution by one of our non-core investments in the fourth quarter of fiscal year 2020.

[0000866374-21-000027:8k_2_02:97]
In fiscal year 2021, the Company recognized realized gains of approximately $45 million from distribution by one of our non-core investment funds.  This was offset by a $35 million impairment charge, related to a certain investment as a result of the Company’s ongoing assessment of recoverability of its investment portfolio and conclusion that the carrying amount of its investment was other than temporarily impaired.

[0000866374-21-000027:8k_2_02:98]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies, valuation allowance releases or other non-recurring tax charges, when applicable.

[0000866374-21-000027:8k_2_02:99]
(2)  Certain prior period presentations were reclassified to ensure comparability with the current period presentation. The prior year amounts related to interest expense (income), net are now presented separately under Interest, net and the remaining balances under interest and other, net have been reclassified to other charges (income), net within the unaudited condensed consolidated statements of operations. In addition, amortization of Right-of-Use ("ROU") assets for operating leases is included in changes in working capital and other, net for all periods presented.
