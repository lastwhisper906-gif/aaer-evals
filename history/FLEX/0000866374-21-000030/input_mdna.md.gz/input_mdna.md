# FLEX MD&A — 0000866374-21-000030


## mdna

[0000866374-21-000030:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-21-000030:mdna:2]
OVERVIEW

[0000866374-21-000030:mdna:3]
We are the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, we deliver technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In the first quarter of fiscal year 2021, the Company made certain changes in its organization structure as part of its strategy to further drive efficiency and productivity with two focused and complimentary delivery models. As a result, the Company now reports its financial performance based on two reportable segments:

[0000866374-21-000030:mdna:4]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-21-000030:mdna:5]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-21-000030:mdna:6]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

[0000866374-21-000030:mdna:7]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-21-000030:mdna:8]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-21-000030:mdna:9]
◦Automotive, including autonomous, connectivity, electrification, and smart technologies;

[0000866374-21-000030:mdna:10]
◦Health Solutions, including medical devices, medical equipment and drug delivery; and

[0000866374-21-000030:mdna:11]
◦Industrial, including capital equipment, industrial devices, renewable including our Nextracker business, grid edge, and power systems.

[0000866374-21-000030:mdna:12]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-21-000030:mdna:13]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain

[0000866374-21-000030:mdna:14]
solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0000866374-21-000030:mdna:15]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customer's supply chain solutions needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-21-000030:mdna:16]
During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During fiscal year 2021, in order to further support our strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, we identified and engaged in certain structural changes. See additional discussion regarding these restructuring actions below under "Results of Operations - Restructuring charges".

[0000866374-21-000030:mdna:17]
We believe that our continued business transformation is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-21-000030:mdna:18]
Update on the Impact of COVID-19 on our Business

[0000866374-21-000030:mdna:19]
As anticipated, our results were negatively impacted by COVID-19 disruptions to our factories, workforce, and suppliers most notably in our first quarter as the impact from the pandemic extended throughout the entire quarter. Total COVID-19 related costs incurred over fiscal year 2021 were over $150 million and were primarily comprised of enhanced health and safety protocols, incremental labor incentives, incremental supply chain costs and forced under-absorption of idle and underutilized labor and overhead costs. As we expected, these incremental costs persisted during fiscal year 2021, but declined significantly over the period as demand improved. Although not materially impacting our results for the fourth quarter of fiscal year 2021, most recently, with the second wave of the pandemic, we have also been experiencing temporary plant closures and/or restrictions at certain manufacturing facilities in Brazil and Malaysia. In addition, India is experiencing a severe COVID-19 resurgence, which has resulted in renewed disease control measures being taken to limit its spread including movement bans and shelter-in-place orders. We have workforce and operations in India and are closely monitoring the situation in India. Our priority is the welfare of our employees.

[0000866374-21-000030:mdna:20]
Throughout the fiscal year 2021, COVID-19 related demand and production pressures remained in certain end markets that we serve. Net sales decreased $0.1 billion during fiscal year 2021 versus the prior year primarily due to declines in our Consumer Devices business included in the FAS segment.  Included in the FRS segment, our Health Solutions business performed well during fiscal year 2021 driven by the increased demand for critical care products and diagnostics and patient monitoring programs. Our factories were productive throughout most of fiscal year 2021 resulting in sales recovering specifically for the automotive businesses that were shut down during the majority of the first quarter. During the third quarter of fiscal year 2021, we started to see certain component constraints in the supply chain and we continued to carefully monitor potential supply chain disruptions due to ongoing tightness in the overall component environment. We expect consumer devices to be one of the end markets more sensitive to industry component constraints. In addition, while we anticipate revenue will continue to improve across our end markets, we believe that our businesses tied to consumer spending, such as Lifestyle and Consumer Devices, will continue to be impacted if there is a prolonged demand slowdown. Refer to “Risk Factors - The COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material.”

[0000866374-21-000030:mdna:21]
As part of our continuous response to the outbreak, we initiated salary cuts, furloughs and other programs to cut costs during the first half of fiscal year 2021. This also included aggressively reducing discretionary corporate spend. Employees that have been operating on a work-from-home basis are continuing to do so. While there still remains an elevated degree of uncertainty, we have removed specific austerity measures involving employee compensation.

[0000866374-21-000030:mdna:22]
We are continuously evaluating our capital structure in response to the current environment and expect that our current financial condition, including our liquidity sources are adequate to fund future commitments. See additional discussion in the Liquidity and Capital Resources section below.

[0000866374-21-000030:mdna:23]
Other Developments

[0000866374-21-000030:mdna:24]
We are actively pursuing alternatives for our Nextracker business. We are considering options that may include, among others, a full or partial separation of the business through an initial public offering, sale, spin-off, or other transaction. On April

[0000866374-21-000030:mdna:25]
28, 2021, we announced that we confidentially submitted a draft registration statement on Form S-1 with the U.S. Securities and Exchange Commission relating to the proposed initial public offering of Nextracker's Class A common stock. The initial public offering and its timing are subject to market and other conditions and the SEC’s review process, and there can be no assurance that we will proceed with such offering or any alternative transaction. Refer to "Risk Factors - We are pursuing alternatives for our Nextracker business, including a full or partial separation of the business, through an initial public offering of Nextracker or otherwise, which may not be consummated as or when planned or at all, and may not achieve the intended benefits."

[0000866374-21-000030:mdna:26]
This Annual Report on Form 10-K does not constitute an offer to sell or a solicitation of an offer to buy securities, and shall not constitute an offer, solicitation or sale in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of that jurisdiction.

[0000866374-21-000030:mdna:27]
Business Overview

[0000866374-21-000030:mdna:28]
We are one of the world's largest providers of global supply chain solutions, with revenues of $24.1 billion in fiscal year 2021. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. As of March 31, 2021, our total manufacturing capacity was approximately 27 million square feet. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment, by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-21-000030:mdna:29]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 9,326 |  |  | 39 | % |  | $ | 9,362 |  |  | 39 | % |  | $ | 11,470 |  |  | 44 | % |
| Americas | 9,672 |  |  | 40 | % |  | 10,066 |  |  | 42 | % |  | 9,893 |  |  | 38 | % |
| Europe | 5,126 |  |  | 21 | % |  | 4,782 |  |  | 19 | % |  | 4,848 |  |  | 18 | % |
|  | $ | 24,124 |  |  |  |  | $ | 24,210 |  |  |  |  | $ | 26,211 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 6,147 |  |  | 25 | % |  | $ | 5,665 |  |  | 23 | % |  | $ | 6,649 |  |  | 25 | % |
| Mexico | 4,413 |  |  | 18 | % |  | 4,449 |  |  | 18 | % |  | 4,539 |  |  | 17 | % |
| U.S. | 3,648 |  |  | 15 | % |  | 3,719 |  |  | 15 | % |  | 3,106 |  |  | 12 | % |
| Malaysia | 1,563 |  |  | 6 | % |  | 1,539 |  |  | 6 | % |  | 1,996 |  |  | 8 | % |
| Brazil | 1,554 |  |  | 6 | % |  | 1,831 |  |  | 8 | % |  | 2,181 |  |  | 8 | % |
| Hungary | 1,313 |  |  | 5 | % |  | 1,355 |  |  | 6 | % |  | 1,290 |  |  | 5 | % |
| Other | 5,486 |  |  | 25 | % |  | 5,652 |  |  | 24 | % |  | 6,450 |  |  | 25 | % |
|  | $ | 24,124 |  |  |  |  | $ | 24,210 |  |  |  |  | $ | 26,211 |  |  |  |

[0000866374-21-000030:mdna:30]
34

[0000866374-21-000030:mdna:31]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 553 |  |  | 26 | % |  | $ | 555 |  |  | 25 | % |
| U.S. | 361 |  |  | 17 | % |  | 378 |  |  | 17 | % |
| China | 331 |  |  | 16 | % |  | 396 |  |  | 18 | % |
| India | 166 |  |  | 8 | % |  | 207 |  |  | 9 | % |
| Malaysia | 106 |  |  | 5 | % |  | 111 |  |  | 5 | % |
| Hungary | 105 |  |  | 5 | % |  | 100 |  |  | 4 | % |
| Other | 475 |  |  | 23 | % |  | 469 |  |  | 22 | % |
|  | $ | 2,097 |  |  |  |  | $ | 2,216 |  |  |  |

[0000866374-21-000030:mdna:32]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we offer our customers the ability to simplify their global product development, manufacturing process, and after-sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-21-000030:mdna:33]
Our operating results are affected by a number of factors, including the following:

[0000866374-21-000030:mdna:34]
•the impacts on our business due to component shortages, disruptions in transportation or other supply chain related constraints including as a result of the COVID-19 pandemic;

[0000866374-21-000030:mdna:35]
•the effects of the COVID-19 pandemic on our business and results of operations;

[0000866374-21-000030:mdna:36]
•changes in the macro-economic environment and related changes in consumer demand;

[0000866374-21-000030:mdna:37]
•the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, and other factors;

[0000866374-21-000030:mdna:38]
•the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance;

[0000866374-21-000030:mdna:39]
•our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers;

[0000866374-21-000030:mdna:40]
•the effects that current credit and market conditions (including as a result of the COVID-19 pandemic) could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-21-000030:mdna:41]
•the effects on our business due to certain customers' products having short product life cycles;

[0000866374-21-000030:mdna:42]
•our customers' ability to cancel or delay orders or change production quantities;

[0000866374-21-000030:mdna:43]
•our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements;

[0000866374-21-000030:mdna:44]
•integration of acquired businesses and facilities;

[0000866374-21-000030:mdna:45]
•increased labor costs due to adverse labor conditions in the markets we operate;

[0000866374-21-000030:mdna:46]
•changes in tax legislation; and

[0000866374-21-000030:mdna:47]
•changes in trade regulations and treaties.

[0000866374-21-000030:mdna:48]
We also are subject to other risks as outlined in Item 1A, "Risk Factors".

[0000866374-21-000030:mdna:49]
Net sales for fiscal year 2021 decreased less than 1%, or $0.1 billion, to $24.1 billion from the prior year. The decrease in sale was most notable in our FAS segment, down $0.6 billion, or 4.0%, from the prior year, driven by lower demand in our Consumer Devices business due to the impact of COVID-19 and more significantly our continued strategic shift away from high volatility, short cycle businesses that we initiated in the prior years. Largely offsetting the overall decline in revenue from our FAS segment for fiscal year 2021, was an increase in net sales from our FRS segment of $0.5 billion, or 4.7%, from the prior year, primarily driven by an increase in sales from our Health Solutions business and to a lesser extent from our Industrial business. Our fiscal year 2021 gross profit totaled $1.7 billion, representing an increase of $0.3 billion, or 26%, from the prior year. The increase was primarily driven by lower restructuring costs in fiscal year 2021 versus those incurred in fiscal year 2020 as a result of the geopolitical challenges and uncertainties which impacted certain of our customers. Gross profit also increased by $0.1 billion due to customer asset impairment charges recorded in the prior year coupled with the write-down of inventory not recoverable due to the significant reductions in future customer demand as we reduced our exposure to certain higher volatility businesses. Our net income totaled $0.6 billion, representing an increase of $0.5 billion, or 597%, compared to fiscal year 2020, due to the factors explained above, further impacted by higher impairment charges incurred in fiscal year 2020. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details of the investment impairments.

[0000866374-21-000030:mdna:50]
Cash provided by operations increased by approximately $1.6 billion to a cash inflow of $0.1 billion for fiscal year 2021 compared with a cash outflow of $1.5 billion for fiscal year 2020 primarily driven by the $0.5 billion increase in net income and the reduced cash outflow related to accounts receivables during fiscal year 2021. Our net working capital ("NWC") is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. Our net working capital as a percentage of annualized sales for fiscal year 2021 increased to 11.5% from 6.3% in the prior year as a direct result of reducing the outstanding balance of accounts receivable sold through our ABS and accounts receivable factoring programs.

[0000866374-21-000030:mdna:51]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, plus cash collections of deferred purchase price receivables (for fiscal year 2020), less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. We also excluded the impact to cash flows related to certain vendor programs that is required for U.S. GAAP presentation as well as cash outflows related to repayment of the outstanding balance of our ABS programs in fiscal year 2021 as we utilized proceeds from debt issuance to replace funding from the ABS programs for working capital purposes. Our adjusted free cash flow remained relatively flat at $0.7 billion for fiscal year 2021 compared to $0.7 billion for fiscal year 2020. Refer to Liquidity and Capital Resources section for the adjusted free cash flows reconciliation to the most directly comparable GAAP financial measure of cash flows from operations. Cash used in investing activities decreased by approximately $2.5 billion to a cash outflow of $0.2 billion for fiscal year 2021, compared with a cash inflow of $2.3 billion for fiscal year 2020, primarily due to lower cash collections on deferred purchase price receivables offset by lower net capital expenditures in the current fiscal year. Cash provided by financing activities increased by approximately $1.2 billion to a cash inflow of $0.7 billion during fiscal year 2021, compared with a cash outflow of $0.5 billion in the prior year, primarily driven by $1.4 billion of proceeds received in aggregate, net of discounts and after premiums, following the issuance of the 2026 Notes and the 2030 Notes, partially offset by $0.4 billion cash paid for the repayment of the term loan due June 2022.

[0000866374-21-000030:mdna:52]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000866374-21-000030:mdna:53]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from those estimates and assumptions.

[0000866374-21-000030:mdna:54]
We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-21-000030:mdna:55]
36

[0000866374-21-000030:mdna:56]
Revenue Recognition

[0000866374-21-000030:mdna:57]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assess whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when we have transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-21-000030:mdna:58]
Customer Contracts and Related Obligations

[0000866374-21-000030:mdna:59]
Certain of our customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. We estimate the variable consideration related to these price adjustments as part of the total transaction price and recognize revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. We constrain the amount of revenues recognized for these contractual provisions based on our best estimate of the amount which will not result in a significant reversal of revenue in a future period. We determine the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-21-000030:mdna:60]
Customer Credit Risk

[0000866374-21-000030:mdna:61]
We have an established customer credit policy through which we manage customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. We perform ongoing credit evaluations of our customers' financial condition and make provisions for doubtful accounts based on the outcome of those credit evaluations. We evaluate the collectability of accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent we identify exposures as a result of customer credit issues, we also review other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-21-000030:mdna:62]
Restructuring Charges

[0000866374-21-000030:mdna:63]
We recognize restructuring charges related to our plans to close or consolidate excess manufacturing facilities and rationalize administrative functions and to realign our corporate cost structure. In connection with these activities, we recognize restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-21-000030:mdna:64]
The recognition of these restructuring charges requires that we make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned restructuring activity. To the extent our actual results differ from our estimates and assumptions, we may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, we evaluate the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed exit plans.

[0000866374-21-000030:mdna:65]
Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-21-000030:mdna:66]
Inventory Valuation

[0000866374-21-000030:mdna:67]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand, and we estimate write downs for excess and obsolete inventory based on our regular

[0000866374-21-000030:mdna:68]
reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regards to inventory procured to fulfill customer demand.

[0000866374-21-000030:mdna:69]
Valuation of Private Company Investments

[0000866374-21-000030:mdna:70]
We assess our investments for impairment whenever events or changes in circumstances indicate that the assets may be impaired. The factors we consider in our evaluation of potential impairment of our investments, include, but are not limited to a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. The carrying value of certain of our investments are individually material, and thus there is the potential for material charges in future periods if we determine that those investments are impaired.  Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our investments.

[0000866374-21-000030:mdna:71]
Carrying Value of Long-Lived Assets

[0000866374-21-000030:mdna:72]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. An impairment loss is recognized when the carrying amount of the asset group exceeds its fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such asset groups are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, general business environment and other factors including future developments of the COVID-19 pandemic which remain highly uncertain and unpredictable. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize additional impairment charges in the future.

[0000866374-21-000030:mdna:73]
Goodwill

[0000866374-21-000030:mdna:74]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require us to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider our budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While we believe we have made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If our actual results are not consistent with our estimates and assumptions used to calculate fair value, it could result in material impairments of our goodwill. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail on our goodwill.

[0000866374-21-000030:mdna:75]
Contingent Liabilities

[0000866374-21-000030:mdna:76]
We may be exposed to certain liabilities relating to our business operations, acquisitions of businesses and assets and other activities. We make provisions for such liabilities when it is probable that the settlement of the liability will result in an outflow of economic resources or the impairment of an asset. We make these assessments based on facts and circumstances that may change in the future resulting in additional expenses.

[0000866374-21-000030:mdna:77]
Refer to note 13 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our contingent liabilities.

[0000866374-21-000030:mdna:78]
Income Taxes

[0000866374-21-000030:mdna:79]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments

[0000866374-21-000030:mdna:80]
38

[0000866374-21-000030:mdna:81]
regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-21-000030:mdna:82]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-21-000030:mdna:83]
RESULTS OF OPERATIONS

[0000866374-21-000030:mdna:84]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data." As previously disclosed, we made certain changes in our organization structure. As a result of these changes, we revised our reportable segments as further discussed in note 20 to the consolidated financial statement in Item 8. There was no change to our consolidated financial statements. Additionally, as further discussed in note 2 to the consolidated financial statement in Item 8, the prior year amounts related to interest expense (income), net are now presented separately under interest, net, and the remaining balances under interest and other, net have been reclassified to other charges (income), net within the consolidated statement of operations. For comparability purposes, the prior periods have been recast to conform to the current presentation. The reclassifications had no effect on the previously reported results of operations.

[0000866374-21-000030:mdna:85]
The data below, and discussion that follows, represents our results from operations.

[0000866374-21-000030:mdna:86]
|  | Fiscal Year EndedMarch 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 92.6 |  |  | 93.7 |  |  | 93.8 |  |
| Restructuring charges | 0.4 |  |  | 0.8 |  |  | 0.4 |  |
| Gross profit | 7.0 |  |  | 5.5 |  |  | 5.8 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.4 |  |  | 3.6 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Interest, net | 0.6 |  |  | 0.7 |  |  | 0.7 |  |
| Other charges (income), net | (0.3) |  |  | 0.3 |  |  | 0.4 |  |
| Income before income taxes | 2.9 |  |  | 0.7 |  |  | 0.7 |  |
| Provision for income taxes | 0.4 |  |  | 0.3 |  |  | 0.3 |  |
| Net Income | 2.5 | % |  | 0.4 | % |  | 0.4 | % |

[0000866374-21-000030:mdna:87]
Net sales

[0000866374-21-000030:mdna:88]
The following table sets forth our net sales by segment, and their relative percentages:

[0000866374-21-000030:mdna:89]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Net sales: | (In millions) |
| Flex Agility Solutions | $ | 13,493 |  |  | 56 | % |  | $ | 14,053 |  |  | 58 | % |  | $ | 16,855 |  |  | 64 | % |
| Flex Reliability Solutions | 10,631 |  |  | 44 | % |  | 10,157 |  |  | 42 | % |  | 9,356 |  |  | 36 | % |
|  | $ | 24,124 |  |  |  |  | $ | 24,210 |  |  |  |  | $ | 26,211 |  |  |  |

[0000866374-21-000030:mdna:90]
Fiscal year 2021 vs 2020

[0000866374-21-000030:mdna:91]
39

[0000866374-21-000030:mdna:92]
Net sales during fiscal year 2021 totaled $24.1 billion, representing a decrease of $0.1 billion, or less than 1%, from $24.2 billion during fiscal year 2020. The decrease in net sales was most notable in our FAS segment, down $0.6 billion, or 4%, from the prior year, mainly due to a drop of 25% in our Consumer Devices business resulting from lower demand due to the impact of COVID-19 in the earlier part of fiscal year 2021, and our continued strategic shift away from high volatility, short cycle businesses that we initiated in fiscal year 2019. CEC grew 2% in fiscal year 2021 from the prior year driven by cloud and critical infrastructure spending. Lifestyle grew 5% in fiscal year 2021 from the prior year due to new customer ramps and continued market strength driven by work, learn and live-from-home trends. Largely offsetting the overall decline in revenue in our FAS segment was an increase in revenues from our FRS segment of $0.5 billion, or 5%, driven primarily by an increase of roughly 25% in sales from prior year of our Health Solutions business as a result of continued demand for critical care products, ventilator project ramps initiated earlier in fiscal year 2021, and continued growth in our chronic care business. Industrial revenue grew approximately 3% from the prior year with steady demand in core industrial. These increases in our FRS segment were offset by a drop of approximately 7% in our Automotive business due to the factory shutdowns in the first quarter of fiscal year 2021 despite the recovery noted in the subsequent quarters of fiscal year 2021.

[0000866374-21-000030:mdna:93]
Net sales were also lower in our Americas and Asia regions during fiscal year 2021, with decreases of $0.4 billion and less than $0.1 billion, respectively, partially offset by higher sales in Europe of $0.3 billion during the same period.

[0000866374-21-000030:mdna:94]
Fiscal year 2020 vs 2019

[0000866374-21-000030:mdna:95]
Net sales during fiscal year 2020 totaled $24.2 billion, representing a decrease of $2.0 billion, or 8%, from $26.2 billion during fiscal year 2019. The decrease in net sales was most notable in our FAS segment, down $2.8 billion, or 17%, from fiscal year 2019, driven by our targeted reductions of high volatility, low margin, short-cycle customers and product categories and further impacted by significant COVID-19 related supply chain constraints in our fourth quarter of fiscal year 2020. Additionally, our FAS segment was impacted by a 15% reduced demand from our CEC business due to the slower roll-out of 5G technology and our previously announced disengagement with Huawei Technologies Co., coupled with production disruptions due to COVID-19 in our fourth quarter of fiscal year 2020. Partially offsetting the overall decrease in revenue was a $0.8 billion, or 9% increase in our FRS segment. The increase in our FRS segment was primarily driven by a 19% increase in demand from our Industrial business throughout the year, which more than offset the underlying supply chain disruptions due to COVID-19 that impacted product ramps for various businesses within the FRS segment in our fourth quarter of fiscal year 2020. Offsetting the increase from our Industrial businesses were modest decreases of 2% in our Automotive businesses due to COVID-19 disruptions as multiple factories shut down late in the fourth quarter of fiscal year 2020.

[0000866374-21-000030:mdna:96]
Net sales were also lower in our Asia and Europe regions during fiscal year 2020, with decreases of $2.1 billion and less than $0.1 billion, respectively, partially offset by slightly higher sales in the Americas with an increase of $0.2 billion during the same period.

[0000866374-21-000030:mdna:97]
Our ten largest customers during fiscal years 2021, 2020 and 2019 accounted for approximately 36%, 39% and 43% of net sales, respectively. We have made substantial efforts to diversify our portfolio which allows us to operate at scale in many different industries, and, as a result, no customer accounted for greater than 10% of net sales in fiscal year 2021, 2020 or 2019.

[0000866374-21-000030:mdna:98]
Cost of sales

[0000866374-21-000030:mdna:99]
Cost of sales is affected by a number of factors, including the number and size of new manufacturing programs, product mix, labor cost fluctuations by region, component costs and availability and capacity utilization.

[0000866374-21-000030:mdna:100]
Fiscal year 2021 vs 2020

[0000866374-21-000030:mdna:101]
Cost of sales during fiscal year 2021 totaled $22.3 billion, representing a decrease of approximately $0.4 billion, or 1% from $22.7 billion during fiscal year 2020. The decrease in cost of sales is more notable in our FAS segment. Cost of sales in FAS for fiscal year 2021 decreased $0.6 billion or almost 5% from fiscal year 2020, which is in line with the 4.0% decrease in revenue, primarily as a result of COVID-19 impacting our Consumer Devices business in the earlier part of fiscal year 2021, coupled with our targeted disengagement of high volatility, short cycle businesses initiated in fiscal year 2019. Offsetting the decrease in cost of sales in FAS is an increase of $0.5 billion, or 5%, related to the FRS segment during fiscal year 2021. These fluctuations are consistent with the associated change in net sales noted above. Cost of sales was also higher in the prior year due to $0.1 billion of customer assets impairment charges for customers that were experiencing financial difficulties as well as the write-down of inventory not recoverable due to significant reductions in future customer demand as we reduced our exposure to certain higher volatility businesses.

[0000866374-21-000030:mdna:102]
Fiscal year 2020 vs 2019

[0000866374-21-000030:mdna:103]
Cost of sales during fiscal year 2020 totaled $22.7 billion, representing a decrease of approximately $1.9 billion, or 8% from $24.6 billion during fiscal year 2019. The decrease in cost of sales for fiscal year 2020 is more notable in our FAS

[0000866374-21-000030:mdna:104]
40

[0000866374-21-000030:mdna:105]
segment with a decrease of $2.7 billion or almost 17% from fiscal year 2019, which is in line with the 17% decrease in revenue, primarily as a result of our targeted reductions of high volatility, low margin, short-cycle customers and product categories and further impacted by significant COVID-19 related supply chain constraints in our fourth quarter of fiscal year 2020. Our FRS segment partially offset the decrease described above with an increase of $0.7 billion, or 8%, from fiscal year 2019, which is in line with the 9% increase in revenue noted above. In addition, we wrote down inventory in the second quarter of fiscal year 2020 that will not be recovered due to significant reductions in future customer demand as we reduced our exposure to certain high volatility business.

[0000866374-21-000030:mdna:106]
Gross profit

[0000866374-21-000030:mdna:107]
Gross profit is affected by a fluctuation in costs of sales elements as outlined above and further by a number of factors, including product life cycles, unit volumes, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-21-000030:mdna:108]
Gross profit during fiscal year 2021 increased $0.3 billion to $1.7 billion, or 7.0% of net sales, from $1.3 billion, or 5.5% of net sales, during fiscal year 2020, an improvement of 150 basis points. The increase in gross profit and gross margin during fiscal year 2021 primarily resulted from lower restructuring costs, $0.1 billion in fiscal year 2021, versus $0.2 billion in fiscal year 2020. The decline of $0.1 billion was primarily due to higher charges taken in fiscal year 2020 due to geopolitical challenges and uncertainties which impacted certain of our customers. Gross profit also increased due to the $0.1 billion of customer assets impairment charges recorded in the prior year for customers that were experiencing financial difficulties coupled with the write-down of inventory not recoverable due to the significant reductions in future customer demand as we reduced our exposure to certain higher volatility businesses. These increases were partially offset by the decline in revenue and gross profit in our Consumer Devices and Automotive end markets reflecting COVID-19 demand and production pressures during the first half of fiscal year 2021.

[0000866374-21-000030:mdna:109]
Gross profit decreased $0.2 billion to $1.3 billion in fiscal year 2020, from $1.5 billion in fiscal year 2019. Gross margin decreased 30 basis points, to 5.5% of net sales in fiscal year 2020, from 5.8% of net sales in fiscal year 2019. The decrease in both gross profit and gross margin is primarily due to lower sales coupled with an additional $91 million, or 40 basis points, of restructuring charges incurred during fiscal year 2020 versus fiscal year 2019. In addition, we wrote down inventory in the second quarter of fiscal year 2020 that will not be recovered due to significant reductions in future customer demand as we reduced our exposure to certain high volatility businesses. We also incurred approximately $52 million, or 21 basis points, of direct incremental costs due to COVID-19 in the fourth quarter of fiscal year 2020. These were partially offset by the favorable product mix and the increased revenue and gross profit from our Industrial business and benefits realized from our earlier restructuring activities initiated in fiscal year 2019.

[0000866374-21-000030:mdna:110]
Segment income

[0000866374-21-000030:mdna:111]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related assets impairments (recoveries), restructuring charges, the new revenue standard adoption impact, legal and other, interest, net and other charges (income), net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-21-000030:mdna:112]
The following table sets forth segment income and margins (amounts may not sum due to rounding):

[0000866374-21-000030:mdna:113]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 449 |  |  | 3.3 | % |  | $ | 369 |  |  | 2.6 | % |  | $ | 442 |  |  | 2.6 | % |
| Flex Reliability Solutions | 662 |  |  | 6.2 | % |  | 642 |  |  | 6.3 | % |  | 534 |  |  | 5.7 | % |

[0000866374-21-000030:mdna:114]
Fiscal year 2021 vs 2020

[0000866374-21-000030:mdna:115]
FAS segment margin increased 70 basis points, to 3.3% for fiscal year 2021, from 2.6% for fiscal year 2020. The margin increase during the period was driven by an increase in demand from high-end audio, floor care and appliance customers included in our Lifestyle end markets coupled with better fixed costs absorption. This is partially offset by the decline in our Consumer Devices business due to elevated overhead costs and supply chain constraints noted in the earlier part of fiscal year 2021.

[0000866374-21-000030:mdna:116]
FRS segment margin decreased 10 basis points, to 6.2% for fiscal year 2021, from 6.3% for fiscal year 2020. The slight decrease in margin during the period is primarily the results of plant shutdowns during most of our first quarter of fiscal year 2021, which affected the entire automotive ecosystem across all regions, coupled with under-absorption and efficiency impacts, in addition to new product ramps in our Health Solution market.

[0000866374-21-000030:mdna:117]
Fiscal year 2020 vs 2019

[0000866374-21-000030:mdna:118]
FAS segment margin remained constant at 2.6% for fiscal year 2020 and fiscal year 2019, respectively. FAS segment margin in fiscal year 2020 was impacted by manufacturing inefficiencies from supply chain disruptions and constraints in the fourth quarter due to COVID-19, slower roll-out of 5G technology, and ongoing repositioning of our operating structure and portfolio transition in the Consumer Devices end market. FAS segment margin in fiscal year 2019 was impacted by losses from our NIKE operations in Mexico, which we exited in the third quarter coupled with under-performance of certain accounts in the Consumer Devices end markets, partially offset by operational efficiencies and improved absorption of overhead in our CEC business.

[0000866374-21-000030:mdna:119]
FRS segment margin increased 60 basis points, to 6.3% for fiscal year 2020, from 5.7% for fiscal year 2019. The FRS segment margin benefited from favorable business mix resulting from increased demand from new business particularly in the Industrial end market, greater levels of design and engineering led engagements and improved operational execution. Offsetting these favorable impacts to the FAS segment were margin deterioration due to accelerated investments and costs associated with new program ramps and pricing pressure with demand declines in the global market that impacted product mix, coupled with under absorption of costs associated with the temporary closure of several automotive sites in the fourth quarter of fiscal year 2020 due to COVID-19.

[0000866374-21-000030:mdna:120]
Restructuring charges

[0000866374-21-000030:mdna:121]
In order to support our strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, we identified certain structural changes to restructure the business. These restructuring actions will eliminate non-core activities primarily within our corporate function, align our cost structure with our reorganizing and optimizing of our operations model along our two reporting segments, and further sharpen our focus to winning business in end markets where we have competitive advantages and deep domain expertise. During fiscal year 2021, we recognized approximately $0.1 billion of restructuring charges, most of which related to employee severance.

[0000866374-21-000030:mdna:122]
During the first half of fiscal year 2020 in connection with the geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During fiscal year 2020, we recognized $0.2 billion of restructuring charges. We incurred cash charges of approximately $159 million, that were predominantly for employee severance, in addition to non-cash charges of $57 million, primarily related to asset impairments.

[0000866374-21-000030:mdna:123]
During fiscal year 2019, we took targeted actions to optimize our portfolio, most notably within our former Consumer Technologies Group segment. We recognized restructuring charges of approximately $0.1 billion during the fiscal year ended March 31, 2019, of which $73 million were non-cash charges primarily for asset impairments. A significant component of our charges were associated with the wind down of our NIKE operations in Mexico in the third quarter of fiscal year 2019. In addition, we executed targeted head-count reductions at existing operating and design sites and corporate functions and exited certain immaterial businesses. Of these total charges, approximately $99 million was recognized as a component of cost of sales during the fiscal year ended March 31, 2019.

[0000866374-21-000030:mdna:124]
Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-21-000030:mdna:125]
Selling, general and administrative expenses

[0000866374-21-000030:mdna:126]
Selling, general and administrative expenses ("SG&A") totaled $0.8 billion, or 3.4% of net sales, during fiscal year 2021, compared to $0.8 billion, or 3.4% of net sales, during fiscal year 2020, decreasing by $17 million or 2%, which reflects strong cost discipline practiced across the enterprise as well as the benefits from our distinct actions taken to temporarily reduce

[0000866374-21-000030:mdna:127]
42

[0000866374-21-000030:mdna:128]
compensation costs across our employee base and aggressively reducing our discretionary spend levels during the first half of fiscal year 2021.

[0000866374-21-000030:mdna:129]
SG&A totaled $0.8 billion, or 3.4% of net sales, during fiscal year 2020, compared to $1.0 billion, or 3.6% of net sales, during fiscal year 2019, decreasing by $0.2 billion or 12%, due to strict cost discipline focused on driving further productivity improvements which enabled us to respond quickly to current market conditions by taking targeted actions on our discretionary spends coupled with a refined cost structure benefiting from prior restructuring initiatives.

[0000866374-21-000030:mdna:130]
Intangible amortization

[0000866374-21-000030:mdna:131]
Amortization of intangible assets in fiscal years 2021 and 2020 were $62 million and $64 million, respectively, representing a decrease of $2 million and $10 million, from their respective prior years as a result of certain intangible assets being fully amortized during the respective periods.

[0000866374-21-000030:mdna:132]
Interest, net

[0000866374-21-000030:mdna:133]
Interest, net was $148 million during fiscal year 2021, compared to $174 million during fiscal year 2020, decreasing $26 million primarily due to lower expenses from our asset-backed securitization programs, partially offset by a higher average borrowing level during fiscal year 2021.

[0000866374-21-000030:mdna:134]
Interest, net was $174 million during fiscal year 2020, remaining relatively constant from $175 million during fiscal year 2019. The slight decrease was driven by a lower interest rate environment during fiscal year 2020 compared to the prior year.

[0000866374-21-000030:mdna:135]
Other charges (income), net

[0000866374-21-000030:mdna:136]
During fiscal year 2021, we recorded $67 million of other income, net, primarily as a result of recognizing $83 million of equity in earnings, driven by the value increase in certain investment funds resulting from discrete market events including IPOs of certain companies included in the funds. Out of the $83 million equity in earnings recorded in fiscal year 2021, we collected $48 million of cash proceeds as we sold certain shares received as a distribution from one of our funds' investments. Partially offsetting the income was an impairment charge of $37 million related to certain non-core investments that were determined to be other than temporarily impaired.

[0000866374-21-000030:mdna:137]
During fiscal year 2020, and in connection with our ongoing assessment of our investment portfolio strategy, we concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $98 million total impairment charge.

[0000866374-21-000030:mdna:138]
During the last half of fiscal year 2019, we reassessed our strategy with respect to our entire investment portfolio. As a result, we recognized an aggregate net charge related to investment impairments and dispositions of approximately $193 million for the year ended March 31, 2019. The aggregate charge was primarily driven by write-downs of our investment positions in a non-core cost method investment and Elementum that were recognized in the third and fourth quarters of fiscal 2019, respectively. We also incurred other investment impairments that were individually immaterial as a result of our strategy shift and due to market valuation changes. Offsetting these charges was an $87 million non-cash gain from the deconsolidation of Bright Machines.

[0000866374-21-000030:mdna:139]
Refer to note 16 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our other charges (income), net.

[0000866374-21-000030:mdna:140]
Income taxes

[0000866374-21-000030:mdna:141]
We work to ensure that we accrue and pay the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which we operate. Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were 14.1%, 44.7% and 48.7% for the fiscal years 2021, 2020 and 2019, respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0000866374-21-000030:mdna:142]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  | 17.0 | % |
| Effect of tax rate differential | (11.6) |  |  | (51.2) |  |  | (74.1) |  |
| Change in unrecognized tax benefit | 1.5 |  |  | (0.6) |  |  | (8.4) |  |
| Change in valuation allowance | 4.9 |  |  | 58.4 |  |  | 105.4 |  |
| Foreign exchange movement on prior year taxes recoverable | 0.7 |  |  | 8.4 |  |  | 3.0 |  |
| Expiration of tax attributes | — |  |  | — |  |  | 2.3 |  |
| APB 23 tax liability | 0.1 |  |  | 5.5 |  |  | 1.1 |  |
| Other | 1.5 |  |  | 7.2 |  |  | 2.4 |  |
| Provision for income taxes | 14.1 | % |  | 44.7 | % |  | 48.7 | % |

[0000866374-21-000030:mdna:143]
The variation in our effective tax rate each year is primarily a result of recognition of earnings in foreign jurisdictions which are taxed at rates lower than the Singapore statutory rate including the effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia, Costa Rica,  Netherlands and Israel of $21 million, $16 million and $24 million in fiscal years 2021, 2020 and 2019, respectively. Additionally, our effective tax rate is impacted by changes in our liabilities for uncertain tax positions of $11 million, ($1) million, and ($15) million and changes in our valuation allowances on deferred tax assets of $35 million, $93 million and $192 million in fiscal years 2021, 2020 and 2019, respectively. We generate most of our revenues and profits from operations outside of Singapore.

[0000866374-21-000030:mdna:144]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows.

[0000866374-21-000030:mdna:145]
We provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized. During fiscal year 2021, we released a valuation allowance of $25 million mainly related to certain operations in Canada as this amount was deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those subsidiaries. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances. Lastly, these valuation allowance reductions and eliminations were offset by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions.

[0000866374-21-000030:mdna:146]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-21-000030:mdna:147]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of March 31, 2021, we had cash and cash equivalents of approximately $2.6 billion and bank and other borrowings of approximately $3.8 billion. We have a new $2.0 billion revolving credit facility, that is due to mature in January 2026 (the "2026 Credit Facility"), under which we had no borrowings outstanding as of March 31, 2021. The new credit facility replaced the previous $1.75 billion credit facility that was to mature in June 2022. We also issued $675 million of 3.750% Notes due February 2026 and $650 million of 4.875% Notes due May 2030 and repaid $433 million for the term loan due June 2022 in fiscal year 2021. Refer to note 8 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details on the new credit facility and the new notes. As of March 31, 2021, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-21-000030:mdna:148]
44

[0000866374-21-000030:mdna:149]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2021, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.5 billion as of March 31, 2021). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-21-000030:mdna:150]
Fiscal Year 2021

[0000866374-21-000030:mdna:151]
Cash provided by operating activities was $0.1 billion during fiscal year 2021. The total cash provided by operating activities resulted primarily from $0.6 billion of net income for the period plus $0.6 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, provision for doubtful accounts, deferred income taxes and stock-based compensation. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were offset by a net change in our operating assets and liabilities of $1.1 billion, primarily driven by cash outflows related to accounts receivables resulting from the reduction of our outstanding balances of accounts receivable sold through our ABS and accounts receivable factoring programs.

[0000866374-21-000030:mdna:152]
We believe NWC, and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. NWC is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. NWC increased by $1.5 billion to $2.9 billion as of March 31, 2021, from $1.4 billion as of March 31, 2020. This increase is primarily driven by a $1.7 billion increase in net receivables as we reduced our outstanding balances on our ABS and accounts receivable factoring programs as discussed above, coupled with a $0.1 billion increase in inventories, and partially offset with a $0.1 billion decrease in contract assets and a $0.1 billion increase in accounts payable. Our net working capital as a percentage of annualized net sales as of March 31, 2021 increased to 11.5% as compared to 6.3% of annualized net sales as of March 31, 2020 as a direct result of reducing the outstanding balance of accounts receivable sold through our ABS and accounts receivable factoring programs. We expect to operate in this range going forward. Though we have mitigated most of the initial supplier constraints and component shortages that we had encountered in the first quarter of fiscal year 2021, we continue to operate in an unusual and dynamic environment with respect to COVID-19 related production limitations and fluctuating demand. We expect it will take additional time to adequately drive down our inventory levels to align with the current demand environment. We are actively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative resetting our load planning. Component shortages are also expected to persist at least in the near future as we are seeing increasing supply constraints. We are working diligently with our partners to secure needed parts and fulfill demand.

[0000866374-21-000030:mdna:153]
Cash used in investing activities totaled $0.2 billion during fiscal year 2021. This was primarily driven by  approximately $0.4 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Health Solutions and Industrial businesses net of approximately $0.1 billion of proceeds from the sale of fixed assets including proceeds from the sale of an exited facility in the fourth quarter of fiscal year 2021 as a result of  the disengagement of a certain customer in fiscal year 2020. Further offsetting the capital expenditures was $48 million of proceeds from the sale of certain shares received as distribution from one of our funds' investments.

[0000866374-21-000030:mdna:154]
Cash provided by financing activities was $0.7 billion during fiscal year 2021. This was primarily driven by $1.4 billion of proceeds received in aggregate, net of discounts and after premiums, following the issuance of the 2026 Notes and the 2030 Notes, partially offset by $0.4 billion of cash paid for the repayment of the term loan due June 2022. Refer to note 8 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details. Also offsetting cash provided by financing activities was $0.2 billion of cash paid for the repurchase of our ordinary shares.

[0000866374-21-000030:mdna:155]
Fiscal Year 2020

[0000866374-21-000030:mdna:156]
Cash used in operating activities was $1.5 billion during fiscal year 2020. The total cash used in operating activities resulted primarily from $88 million of net income for the period plus $0.8 billion of non-cash charges such as depreciation, amortization, restructuring and impairment charges, provision for doubtful accounts, and stock-based compensation. Depreciation expense was $0.4 billion and slightly lower than prior years. These additions were more than offset by a net change in our operating assets and liabilities of $2.4 billion, primarily driven by cash outflows related to accounts receivable. Cash collections from the deferred purchase price on our ABS sales programs of $2.6 billion were included in cash from investing activities.

[0000866374-21-000030:mdna:157]
Cash provided by investing activities totaled $2.3 billion during fiscal year 2020. This was primarily driven by $2.6 billion of cash collections on deferred purchase price receivables from our ABS Programs offset by approximately $0.4 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Health Solutions and Industrial businesses. In addition, other investing activities include $44 million of proceeds from the sale of our partial investment in Bright Machines.

[0000866374-21-000030:mdna:158]
Cash used in financing activities was $0.5 billion during fiscal year 2020. This was primarily the result of (i) $0.7 billion of cash paid for the repayment of the term loan due November 2021, (ii) $0.5 billion of cash paid for the tender and redemption of the outstanding balance of our 4.625% Notes due February 2020, (iii) $0.1 billion of cash paid to pay off the outstanding balance of our short-term bank borrowings facility in India, and (iv) $0.3 billion of cash paid for the repurchase of our ordinary shares. Partially offsetting the payments described above were $0.7 billion of proceeds, net of discount and premium, received following the issuance of the 2029 Notes, $0.3 billion of proceeds following the execution of our term loan agreement due in April 2024, $59 million of proceeds from drawdowns from our India term loan facility coupled with $47 million of proceeds from the execution of our term loan due in March 2021.

[0000866374-21-000030:mdna:159]
Fiscal Year 2019

[0000866374-21-000030:mdna:160]
Cash used in operating activities was $3.0 billion during fiscal year 2019. As further discussed below, cash collections on the deferred purchase price from our ABS Programs of $3.6 billion were included in cash from investing activities instead of cash from operating activities in accordance with new accounting guidance adopted in fiscal year 2019. The total cash used in operating activities resulted primarily from $93 million of net income for the period plus $0.8 billion of non-cash charges such as depreciation, amortization, restructuring and impairment charges, provision for doubtful accounts, and stock-based compensation, net of a gain of $87 million from the deconsolidation of Bright Machines which were included in the determination of net income. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were more than offset by a net change in our operating assets and liabilities of $3.9 billion. In accordance with the new accounting guidance adopted in fiscal year 2019, cash collections on deferred purchase price from our ABS Programs were classified as cash flows from investing activities and no longer included in cash receipts related to accounts receivable. As a result, while accounts receivable only increased by approximately $95 million from fiscal year 2018 to fiscal year 2019, the impact to operating cash flows is an outflow of $3.6 billion. Year over year increases in inventory and contract assets also added to the net change in our operating assets and liabilities reflected on our cash flow from operations.

[0000866374-21-000030:mdna:161]
Cash provided by investing activities totaled $3.3 billion during fiscal year 2019. This was primarily driven by the impact of our adoption of ASU 2016-15 during fiscal year 2019 referred to above, which required us to classify cash collections on the deferred purchase price from our ABS Programs that were previously classified as operating cash inflows as cash flows from investing activities. In addition, we received $0.3 billion of proceeds, net of cash held, in connection with the divestiture of our China-based Multek operations as further described in note 18 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data". We also invested $0.6 billion of net capital expenditures for property and equipment to expand capabilities and capacity in support of our Industrial, Automotive and Health Solutions businesses.

[0000866374-21-000030:mdna:162]
Cash used in financing activities was $30 million during fiscal year 2019. This was primarily the result of repurchases of ordinary shares in the amount of $0.2 billion, offset by $0.2 billion received from the drawdown of India Facilities.

[0000866374-21-000030:mdna:163]
Adjusted Free Cash Flow

[0000866374-21-000030:mdna:164]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, plus cash collections of deferred purchase price receivables (for fiscal year 2020 and prior), less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. We also excluded the impact to cash flows related to certain vendor programs that is required for U.S. GAAP presentation. During fiscal year 2021, we proactively and strategically reduced the outstanding balance of our ABS programs. Proceeds from our debt issuance replaced the funding from the ABS programs for working capital purposes. We reduced the balance on this short-term financing product by $0.8 billion as of March 31, 2021 from March 31, 2020, which has the accounting effect of reducing our cash flow from operations, resulting in no balance outstanding as of March 31, 2021. As this decrease in cash flow reflects the change of our capital strategy, we have added this back for our adjusted free cash flow calculation. Our adjusted free cash flow was $0.7 billion, $0.7 billion and $3 million for fiscal years 2021, 2020 and 2019, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-21-000030:mdna:165]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Net cash provided by (used in) operating activities | $ | 144 |  |  | $ | (1,533) |  |  | $ | (2,971) |  |
| Reduction in ABS levels | 797 |  |  | — |  |  | — |  |
| Cash collection of deferred purchase price and other | 2 |  |  | 2,561 |  |  | 3,605 |  |
| Purchases of property and equipment | (351) |  |  | (462) |  |  | (725) |  |
| Proceeds from the disposition of property and equipment | 85 |  |  | 106 |  |  | 94 |  |
| Adjusted free cash flow | $ | 677 |  |  | $ | 672 |  |  | $ | 3 |  |

[0000866374-21-000030:mdna:166]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months.

[0000866374-21-000030:mdna:167]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volumes of customer orders.

[0000866374-21-000030:mdna:168]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. During fiscal years ended March 31, 2021 and 2020, the cumulative payments due to suppliers participating in the programs amounted to approximately $1.0 billion and $0.9 billion, respectively. Pursuant to their agreements with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-21-000030:mdna:169]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to commercial paper program and revolving sale and repurchase of subordinated note established under the securitization facility, under which there were no borrowings outstanding as of March 31, 2021.

[0000866374-21-000030:mdna:170]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under ABS Programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed.

[0000866374-21-000030:mdna:171]
During fiscal years 2021, 2020 and 2019, we received approximately $0.6 billion, $7.6 billion and  $6.8 billion, respectively from transfers of receivables under our ABS Programs, and $0.8 billion, $1.6 billion and $2.7 billion, respectively from other sales of receivables. As of March 31, 2021, and 2020, the outstanding balance on receivables sold for cash was $0.2 billion and $1.2 billion, respectively, under all our ABS programs and accounts receivable factoring program, which were removed from accounts receivable balances in our consolidated balance sheets.

[0000866374-21-000030:mdna:172]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In January 2021, we entered into a $2.0 billion credit agreement which matures in January 2026 and consists of a $2.0 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2026 Credit Facility replaced the previous $1.75 billion credit facility, which was due to mature in June 2022.

[0000866374-21-000030:mdna:173]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt

[0000866374-21-000030:mdna:174]
could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares. Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 7, 2020. During fiscal year 2021, we paid $183 million to repurchase shares under the current and prior repurchase plans at an average price of $17.49 per share. As of March 31, 2021, shares in the aggregate amount of $317 million were available to be repurchased under the current plan.

[0000866374-21-000030:mdna:175]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-21-000030:mdna:176]
Bank borrowings and long-term debt are as follows:

[0000866374-21-000030:mdna:177]
|  | As of March 31, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Term Loan, including current portion, due in installments through June 2022 | — |  |  | 433 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305 |  |  | 310 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 597 |  |
| 3.750% Notes due February 2026 | 694 |  |  | — |  |
| 4.875% Notes due June 2029 | 661 |  |  | 662 |  |
| 4.875% Notes due May 2030 | 694 |  |  | — |  |
| India Facilities | 133 |  |  | 138 |  |
| Other | 219 |  |  | 211 |  |
| Debt issuance costs | (21) |  |  | (13) |  |
|  | 3,783 |  |  | 2,838 |  |
| Current portion, net of debt issuance costs | (268) |  |  | (149) |  |
| Non-current portion | $ | 3,515 |  |  | $ | 2,689 |  |

[0000866374-21-000030:mdna:178]
Refer to the discussion in note 8 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details of our debt obligations.

[0000866374-21-000030:mdna:179]
We have purchase obligations that arise in the normal course of business, primarily consisting of binding purchase orders for inventory related items and capital expenditures. Additionally, we have leased certain of our property and equipment under finance lease commitments, and certain of our facilities and equipment under operating lease commitments.

[0000866374-21-000030:mdna:180]
48

[0000866374-21-000030:mdna:181]
Future payments due under our purchase obligations, debt including finance leases and related interest obligations and operating leases are as follows (amounts may not sum due to rounding):

[0000866374-21-000030:mdna:182]
|  | Total |  | Less Than1 Year |  | 1 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In millions) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Purchase obligations | $ | 4,668 |  |  | $ | 4,668 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Bank borrowings, long-term debt and finance lease obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and long-term debt | 3,804 |  |  | 268 |  |  | 584 |  |  | 1,597 |  |  | 1,355 |  |
| Finance leases | 14 |  |  | 10 |  |  | 3 |  |  | 1 |  |  | — |  |
| Interest on long-term debt obligations | 821 |  |  | 144 |  |  | 258 |  |  | 201 |  |  | 218 |  |
| Operating leases, net of subleases | 800 |  |  | 147 |  |  | 240 |  |  | 157 |  |  | 256 |  |
| Restructuring costs | 53 |  |  | 50 |  |  | 3 |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 10,160 |  |  | $ | 5,287 |  |  | $ | 1,088 |  |  | $ | 1,956 |  |  | $ | 1,829 |  |

[0000866374-21-000030:mdna:183]
We have excluded $266 million of liabilities for unrecognized tax benefits from the contractual obligations table as we cannot make a reasonably reliable estimate of the periodic settlements with the respective taxing authorities. See note 14, "Income Taxes" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-21-000030:mdna:184]
Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-21-000030:mdna:185]
OFF-BALANCE SHEET ARRANGEMENTS

[0000866374-21-000030:mdna:186]
As of March 31, 2021 and 2020, the outstanding balance on receivables sold for cash was $0.2 billion and $1.2 billion, respectively, under our asset-backed securitization programs and accounts receivable factoring program, which were removed from accounts receivable balances in our consolidated balance sheets. For further information, see note 11 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data".

[0000866374-21-000030:mdna:187]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-21-000030:mdna:188]
Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for recent accounting pronouncements.
