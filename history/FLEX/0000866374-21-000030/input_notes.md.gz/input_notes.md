# FLEX notes — 0000866374-21-000030


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000866374-21-000030:notes:1]
Proxy Statement to be delivered to shareholders in connection with the Registrant's 2021 Annual General Meeting of Shareholders


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-21-000030:notes:2]
ORGANIZATION OF THE COMPANY
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In the first quarter of fiscal year 2021, the Company made certain changes in its organizational structure as part of its strategy to further drive efficiency and productivity with two focused and complimentary delivery models. As a result, beginning in the first quarter of fiscal year 2021, the Company reports its financial performance based on two operating and reportable segments:

[0000866374-21-000030:notes:3]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-21-000030:notes:4]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-21-000030:notes:5]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

[0000866374-21-000030:notes:6]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-21-000030:notes:7]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-21-000030:notes:8]
◦Automotive, including autonomous, connectivity, electrification, and smart technologies;

[0000866374-21-000030:notes:9]
◦Health Solutions, including medical devices, medical equipment and drug delivery; and

[0000866374-21-000030:notes:10]
◦Industrial, including capital equipment, industrial devices, renewable including our Nextracker business, grid edge, and power systems.

[0000866374-21-000030:notes:11]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-21-000030:notes:12]
SUMMARY OF ACCOUNTING POLICIES
Basis of Presentation and Principles of Consolidation

[0000866374-21-000030:notes:13]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the consolidated statements of operations.

[0000866374-21-000030:notes:14]
Certain prior period presentations and disclosures were reclassified to ensure comparability with the current period presentation. The prior year amounts related to interest expense (income), net are now presented separately under interest, net, and the remaining balances under interest and other, net have been reclassified to the other charges (income), net within the consolidated statements of operations. Additionally, the amortization of right-of-use assets for operating leases have been reclassified from the amortization and other impairment charges line on the consolidated statement of cash flows, and are now presented separately under non-cash lease expense. The reclassifications had no effect on the previously reported results of operations or cash flows from operating activities.

[0000866374-21-000030:notes:15]
Use of Estimates

[0000866374-21-000030:notes:16]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-21-000030:notes:17]
Translation of Foreign Currencies

[0000866374-21-000030:notes:18]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive income (loss), a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for all periods presented, and have been classified as a component of interest and other, net in the consolidated statements of operations.

[0000866374-21-000030:notes:19]
Revenue Recognition

[0000866374-21-000030:notes:20]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the

[0000866374-21-000030:notes:21]
Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to note 4 "Revenue Recognition" for further details.

[0000866374-21-000030:notes:22]
On April 1, 2018, the Company adopted the Accounting Standard Codification 606 ("ASC 606") using the modified retrospective approach by applying the guidance to all open contracts at the adoption date and has implemented revised accounting policies, new operational and financial reporting processes, enhanced systems capabilities and relevant internal controls. Note 4 "Revenue" provides further disclosures required by the new standard.

[0000866374-21-000030:notes:23]
Concentration of Credit Risk

[0000866374-21-000030:notes:24]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, derivative instruments, and cash and cash equivalents.

[0000866374-21-000030:notes:25]
Customer Credit Risk

[0000866374-21-000030:notes:26]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-21-000030:notes:27]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2021, 2020 and 2019:

[0000866374-21-000030:notes:28]
|  | Balance atBeginningof Year |  | Charged toCosts andExpenses (1) |  | Deductions/Write-Offs |  | Balance atEnd ofYear |
|  | (In millions) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2019 | $ | 60 |  |  | $ | 42 |  |  | $ | (11) |  |  | $ | 91 |  |
| Year ended March 31, 2020 | 91 |  |  | 24 |  |  | (19) |  |  | 96 |  |
| Year ended March 31, 2021 | 96 |  |  | 5 |  |  | (40) |  |  | 61 |  |

[0000866374-21-000030:notes:29]
(1)Charges incurred during fiscal years 2021,  2020 and 2019 are primarily for costs and expenses related to various distressed customers.

[0000866374-21-000030:notes:30]
No customer accounted for greater than 10% of the Company's net sales in fiscal years 2021, 2020 and 2019. One customer within the Company's FAS segment accounted for approximately 11% of the Company's total balance of accounts receivable, net in fiscal years 2021 and 2019, respectively. A different customer within the Company's FAS segment accounted for approximately 10% of the Company's total balances of accounts receivable, net in fiscal years 2020.

[0000866374-21-000030:notes:31]
The Company's ten largest customers accounted for approximately 36%, 39% and 43%, of its net sales in fiscal years 2021, 2020 and 2019, respectively.

[0000866374-21-000030:notes:32]
Derivative Instruments

[0000866374-21-000030:notes:33]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 9.

[0000866374-21-000030:notes:34]
Cash and Cash Equivalents

[0000866374-21-000030:notes:35]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-21-000030:notes:36]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-21-000030:notes:37]
Cash and cash equivalents consisted of the following:

[0000866374-21-000030:notes:38]
|  | As of March 31, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Cash and bank balances | $ | 1,130 |  |  | $ | 1,519 |  |
| Money market funds and time deposits | 1,507 |  |  | 404 |  |
|  | $ | 2,637 |  |  | $ | 1,923 |  |

[0000866374-21-000030:notes:39]
Inventories

[0000866374-21-000030:notes:40]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or net realizable value write-downs, were as follows:

[0000866374-21-000030:notes:41]
|  | As of March 31, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Raw materials | $ | 2,831 |  |  | $ | 2,836 |  |
| Work-in-progress | 459 |  |  | 373 |  |
| Finished goods | 605 |  |  | 576 |  |
|  | $ | 3,895 |  |  | $ | 3,785 |  |

[0000866374-21-000030:notes:42]
Property and Equipment, Net

[0000866374-21-000030:notes:43]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are depreciated over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment is comprised of the following:

[0000866374-21-000030:notes:44]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2021 |  | 2020 |
|  |  |  | (In millions) |
| Machinery and equipment | 2 - 10 |  | $ | 3,381 |  |  | $ | 3,265 |  |
| Buildings | 30 |  | 1,103 |  |  | 1,086 |  |
| Leasehold improvements | up to 30 |  | 500 |  |  | 510 |  |
| Furniture, fixtures, computer equipment and software | 3 - 7 |  | 491 |  |  | 492 |  |
| Land | — |  | 113 |  |  | 112 |  |
| Construction-in-progress | — |  | 255 |  |  | 271 |  |
|  |  |  | 5,843 |  |  | 5,736 |  |
| Accumulated depreciation and amortization |  |  | (3,746) |  |  | (3,520) |  |
| Property and equipment, net |  |  | $ | 2,097 |  |  | $ | 2,216 |  |

[0000866374-21-000030:notes:45]
Total depreciation expense associated with property and equipment was approximately $422.3 million, $422.4 million and $433.4 million in fiscal years 2021, 2020 and 2019, respectively.

[0000866374-21-000030:notes:46]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-21-000030:notes:47]
Deferred Income Taxes

[0000866374-21-000030:notes:48]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-21-000030:notes:49]
Accounting for Business and Asset Acquisitions

[0000866374-21-000030:notes:50]
The Company has strategically pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0000866374-21-000030:notes:51]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-21-000030:notes:52]
Goodwill

[0000866374-21-000030:notes:53]
In accordance with accounting guidance on goodwill, the Company evaluates goodwill for impairment at the reporting unit level annually, and in certain circumstances such as a change in reporting units or whenever there are indications that goodwill might be impaired. As described in note 1, the Company made certain changes in its organizational structure during the first quarter of fiscal year 2021 as part of its strategy to further drive growth and productivity through two separate delivery models that represent reportable segments, FAS and FRS. With these changes, the Company also revised its reporting units. Accordingly, the Company completed an interim test as of April 1, 2020 and additionally, its goodwill was reallocated among each of the Company's six reporting units based on each reporting unit’s relative fair value as of that date. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require management to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider the Company's budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of the Company's goodwill.

[0000866374-21-000030:notes:54]
If the recorded value of the assets, including goodwill, and liabilities ("net book value") of any reporting unit exceeds its fair value, an impairment loss may be required to be recognized. Further, to the extent the net book value of the Company as a whole is greater than its fair value in the aggregate, all, or a significant portion of its goodwill may be considered impaired.

[0000866374-21-000030:notes:55]
The Company performed its annual goodwill impairment assessment on January 1, 2021 and as a result of the quantitative assessment of its goodwill, the Company determined that no impairment existed as of the date of the impairment test because the fair value of each one of its reporting units exceeded its respective carrying value.

[0000866374-21-000030:notes:56]
The following table summarizes the activity in the Company's goodwill during fiscal years 2021 and 2020 (in millions):

[0000866374-21-000030:notes:57]
|  |  | FAS |  | FRS |  |  |
|  |  | Communications, Enterprise and Cloud |  | Lifestyle |  | Consumer Devices |  | Automotive |  | Health Solutions |  | Industrial |  | Total |
|  | (In millions) |
| Balance at March 31, 2019 |  | $ | 188 |  |  | $ | 131 |  |  | $ | 51 |  |  | $ | 182 |  |  | $ | 192 |  |  | $ | 329 |  |  | $ | 1,073 |  |
| Divestitures |  | — |  |  | — |  |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Foreign currency translation adjustments |  | — |  |  | — |  |  | — |  |  | (8) |  |  | 1 |  |  | — |  |  | (7) |  |
| Balance at March 31,2020 |  | $ | 188 |  |  | $ | 131 |  |  | $ | 51 |  |  | $ | 174 |  |  | $ | 192 |  |  | $ | 329 |  |  | $ | 1,065 |  |
| Divestitures |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (1) |  |  | (1) |  |
| Foreign currency translation adjustments |  | 1 |  |  | — |  |  | — |  |  | 22 |  |  | 2 |  |  | 1 |  |  | 26 |  |
| Balance at March 31, 2021 |  | $ | 189 |  |  | $ | 131 |  |  | $ | 51 |  |  | $ | 196 |  |  | $ | 194 |  |  | $ | 329 |  |  | $ | 1,090 |  |

[0000866374-21-000030:notes:58]
Other Intangible Assets

[0000866374-21-000030:notes:59]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be

[0000866374-21-000030:notes:60]
recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2021 and concluded that such amounts continued to be recoverable.

[0000866374-21-000030:notes:61]
Intangible assets are comprised of customer-related intangible assets that include contractual agreements and customer relationships, and licenses and other intangible assets that are primarily comprised of licenses and also include patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight-line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability. The components of acquired intangible assets are as follows:

[0000866374-21-000030:notes:62]
|  | As of March 31, 2021 |  | As of March 31, 2020 |
|  | Weighted-Average Remaining Useful life (in Years) |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  |  |  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | 4.8 |  | $ | 276 |  |  | $ | (154) |  |  | $ | 122 |  |  | $ | 275 |  |  | $ | (128) |  |  | $ | 147 |  |
| Licenses and other intangibles | 4.0 |  | 250 |  |  | (159) |  |  | 91 |  |  | 245 |  |  | (130) |  |  | 115 |  |
| Total |  |  | $ | 526 |  |  | $ | (313) |  |  | $ | 213 |  |  | $ | 520 |  |  | $ | (258) |  |  | $ | 262 |  |

[0000866374-21-000030:notes:63]
Total intangible asset amortization expense recognized in operations during fiscal years 2021, 2020 and 2019 was $61.8 million, $64.1 million and $74.4 million, respectively. The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2021, the gross carrying amounts of fully amortized intangible assets totaled $16.9 million. The Company also recorded $11.4 million of foreign currency translation adjustments during fiscal year 2021, as the U.S. Dollar fluctuated against foreign currencies for certain intangibles. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-21-000030:notes:64]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2022 | $ | 54 |  |
| 2023 | 46 |  |
| 2024 | 44 |  |
| 2025 | 39 |  |
| 2026 | 18 |  |
| Thereafter | 12 |  |
| Total amortization expense | $ | 213 |  |

[0000866374-21-000030:notes:65]
The Company owns or licenses various United States and foreign patents relating to a variety of technologies. For certain of the Company's proprietary processes, inventions, and works of authorship, the Company relies on trade secret or copyright protection. The Company also maintains trademark rights (including registrations) for the Company's corporate name and several other trademarks and service marks that the Company uses in the Company's business in the United States and other countries throughout the world. The Company has implemented appropriate policies and procedures (including both technological means and training programs for the Company's employees) to identify and protect the Company's intellectual property, as well as that of the Company's customers and suppliers. As of March 31, 2021 and 2020, the carrying value of the Company's intellectual property was not material.

[0000866374-21-000030:notes:66]
Derivative Instruments and Hedging Activities

[0000866374-21-000030:notes:67]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Additional information is included in note 9.

[0000866374-21-000030:notes:68]
Investments

[0000866374-21-000030:notes:69]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other assets. These privately held companies range from startups to more mature companies with established revenue streams and business models. As of March 31, 2021, and March 31, 2020, the Company's investments in non-consolidated companies totaled $102.8 million and $128.1 million, respectively.

[0000866374-21-000030:notes:70]
During fiscal year 2021, the Company recognized $83.5 million of equity in earnings, associated with its equity method investments in other charges (income), net on the consolidated statement of operations. Additional information is included in note 16. Also during fiscal year 2021, in connection with the Company’s ongoing assessment of recoverability of its investment portfolio, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $36.5 million total impairment in other charges (income), net on the consolidated statement of operations primarily related to the Company's investment in Bright Machines.

[0000866374-21-000030:notes:71]
During fiscal year 2020, the Company recognized $97.7 million of total impairments primarily related to Elementum and certain other non-core investments, reflecting recent market valuation changes, in addition to capturing additional risks due to the economic challenges in light of COVID-19.

[0000866374-21-000030:notes:72]
During the last half of fiscal year 2019, the Company reassessed its strategy with respect to its entire investment portfolio. As a result the Company recognized aggregate net charges related to investment impairments and dispositions of approximately $193 million for the fiscal year ended March 31, 2019, primarily related to a non-core cost method investment and Elementum.

[0000866374-21-000030:notes:73]
Non-consolidated investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage generally equal to or greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. Cost method is used for investments where the Company does not have the ability to significantly influence the operating decisions of the investee, or if the Company’s investment is in securities other than common stock or in-substance common stock.

[0000866374-21-000030:notes:74]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy, and require management to make various judgmental assumptions primarily about comparable company multiples and discounted cash flow projections. Some of the inherent estimates and assumptions used in determining the fair value of the investments are outside the control of management. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the investments, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of investments.

[0000866374-21-000030:notes:75]
For investments accounted for under the cost method that do not have readily determinable fair values, the Company measures them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-21-000030:notes:76]
Bright Machines

[0000866374-21-000030:notes:77]
During the first quarter of fiscal year 2019, the Company transferred existing employees and equipment with a net book value of approximately $35 million along with certain related software and intellectual property, into the newly created Bright Machines, in exchange for shares of preferred stock and a controlling financial interest in Bright Machines. Bright Machines is a privately held software-as-a service (SaaS) and hardware company focused on developing and deploying an automation solution worldwide. The Company has concluded that Bright Machines does not qualify as a variable interest entity for purposes of evaluating whether it has a controlling financial interest.

[0000866374-21-000030:notes:78]
Subsequent to the initial formation and prior to June 29, 2018, Bright Machines received equity funding from third party investors and expanded the board of directors, resulting in dilution of the Company's voting interest to below 50%. As a result, the Company concluded it no longer held a controlling financial interest in Bright Machines and accordingly deconsolidated the entity.

[0000866374-21-000030:notes:79]
The fair value of the Company’s non-controlling interest in Bright Machines upon deconsolidation was approximately $128 million as of the date of deconsolidation. The Company initially accounted for its investment in Bright Machines under the equity method, with the carrying amount included in other assets on the consolidated balance sheet. The value of the Company’s interest on the date of deconsolidation was based on management’s estimate of the fair value of Bright Machines at that time. Management relied on a multi-stage process which involved calculating the enterprise and equity value of Bright Machines, then allocating the equity value of the entity to the Company’s securities. The enterprise value of Bright Machines was estimated based on the value implied by the equity funding Bright Machines received from third parties in the same period (i.e., Level 2 inputs). The Company recognized a gain on deconsolidation of approximately $87 million with no material tax impact, which is included in other charges (income), net on the consolidated statement of operations for the fiscal year ended March 31, 2019.

[0000866374-21-000030:notes:80]
Concurrently with the deconsolidation, the Company engaged Bright Machines as a strategic partner to develop and deploy automation solutions for Flex and entered into a 5-year subscription agreement for the use of fixed assets along with other automation services. The subscription agreement provides the Company with the use of the assets previously contributed to Bright Machines and accordingly is accounted for as a finance lease. As a result, the Company recognized a finance lease asset and obligation in the consolidated balance sheets. The related finance lease asset and obligation balances as of March 31, 2021and 2020 were not material.

[0000866374-21-000030:notes:81]
Pro-forma financials have not been presented because the effects were not material to the Company’s consolidated financial position and results of operation for all periods presented. Subscription fees under the Bright Machines agreement were immaterial for all periods presented.

[0000866374-21-000030:notes:82]
During fiscal year 2020, the Company and Bright Machines executed agreements that provided for, among other things, the repurchase of certain preferred stock of Bright Machines held by the Company and the removal of certain rights associated with such shares, including the Company’s right to elect certain members of Bright Machines' board of directors. In conjunction with this transaction, the Company received consideration of approximately $44 million and recognized a total charge of $23 million, which is included in other charges, net on the consolidated statement of operations.

[0000866374-21-000030:notes:83]
As a result of the transaction, the Company no longer has the ability to exercise significant influence, and therefore accounts for its remaining investment in Bright Machines as a cost method investment, which is included in other assets on the consolidated balance sheet as of March 31, 2020. Bright Machines is no longer a related party of the Company subsequent to the transaction described above.

[0000866374-21-000030:notes:84]
During fiscal year 2021, the Company recorded approximately $35 million charge primarily related to the anticipated cancellation and retirement of certain shares of preferred stock, held by the Company, as a condition to amend the subscription agreement with Bright Machines as well as a change in the market valuation which resulted in part of the carrying value of the investment to be other than temporarily impaired. The charge is included in other charges, net on the consolidated statements of operations.

[0000866374-21-000030:notes:85]
Other Current Liabilities

[0000866374-21-000030:notes:86]
Other current liabilities include customer working capital advances of $471.5 million and $264.2 million, and customer-related accruals of $242.0 million and $195.1 million as of March 31, 2021 and 2020, respectively. The customer working

[0000866374-21-000030:notes:87]
capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.

[0000866374-21-000030:notes:88]
Leases

[0000866374-21-000030:notes:89]
The Company is a lessee with several non-cancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. The Company determines if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the customer has the right to control the use of the identified asset. Beginning with the adoption of ASC 842 on April 1, 2019, the Company elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. The Company recognizes a right-of-use (“ROU”) asset and a lease liability at the lease commencement date for the Company's operating leases. For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at the lease commencement date. The Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and non-lease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for the Company's leases, the Company uses the Company's estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company's estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company's leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-21-000030:notes:90]
The adoption of ASC 842 had a material impact to the Company’s consolidated balance sheet, but did not materially impact the consolidated statement of operations or consolidated statement of cash flows. The most significant changes to the consolidated balance sheet relate to the recognition of ROU assets and lease liabilities for operating leases. The Company’s accounting for finance leases remains substantially unchanged and the balances are not material for any periods presented.

[0000866374-21-000030:notes:91]
As a result of adopting ASC 842 as of April 1, 2019, the Company recognized additional operating liabilities of $658 million with a corresponding ROU asset of $624 million and a deferred gain of $22 million for sale leaseback transactions to opening retained earnings. Note 3 "Leases" provides further disclosures required by the new standard.

[0000866374-21-000030:notes:92]
As of March 31, 2021 and 2020, current operating lease liabilities were $127.6 million and $114.1 million, respectively, which are included in other current liabilities on the consolidated balance sheets.

[0000866374-21-000030:notes:93]
Restructuring Charges

[0000866374-21-000030:notes:94]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and rationalize administrative functions. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-21-000030:notes:95]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed restructuring plans. See note 15 for additional information regarding restructuring charges.

[0000866374-21-000030:notes:96]
Recently Adopted Accounting Pronouncements

[0000866374-21-000030:notes:97]
In October 2020, the FASB issued ASU 2020-09 "Debt (Topic 470): Amendments to SEC Paragraphs Pursuant to SEC Release No. 33-10762." which amends and supersedes SEC paragraphs in the Accounting Standards Codification to reflect the issuance of SEC Release No. 33-10762 related to financial disclosure requirements for subsidiary issuers and guarantors of registered debt securities and affiliates whose securities are pledged as collateral for registered securities. The Company adopted the new guidance during the fourth quarter of fiscal year 2021 with no impact on its consolidated financial statements.

[0000866374-21-000030:notes:98]
In March 2020, the FASB issued ASU 2020-04 "Facilitation of the Effects of Reference Rate Reform on Financial Reporting", which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

[0000866374-21-000030:notes:99]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04, ASU 2019-05, ASU 2019-10, and ASU 2019-11, which replace the existing incurred loss impairment model with an expected credit loss model and require a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

[0000866374-21-000030:notes:100]
Recently Issued Accounting Pronouncements

[0000866374-21-000030:notes:101]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Accounting Standards Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies the application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

[0000866374-21-000030:notes:102]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

[0000866374-21-000030:notes:103]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes", which removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.


## us-gaap:DerivativesPolicyTextBlock

[0000866374-21-000030:notes:104]
Derivative InstrumentsThe amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions.Derivative Instruments and Hedging ActivitiesAll derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-21-000030:notes:105]
LEASES
The Company has several commitments under operating leases for warehouses, buildings, and equipment. The Company also has a minimal number of finance leases with an immaterial impact on its consolidated financial statements. Leases have initial lease terms ranging from 1 year to 23 years.

[0000866374-21-000030:notes:106]
The components of lease cost recognized under ASC 842 were as follow (in millions):

[0000866374-21-000030:notes:107]
| Lease cost | Year Ended |
|  | March 31, 2021 |  | March 31, 2020 |
| Operating lease cost | $ | 152 |  |  | $ | 163 |  |

[0000866374-21-000030:notes:108]
Amounts reported in the consolidated balance sheet as of the periods ended March 31, 2021 and 2020 were (in millions, except weighted average lease term and discount rate):

[0000866374-21-000030:notes:109]
|  | As of March 31, 2021 |  | As of March 31, 2020 |
| Operating Leases: |  |  |  |
| Operating lease right of use assets | $ | 642 |  |  | $ | 605 |  |
| Operating lease liabilities | $ | 690 |  |  | $ | 643 |  |
| Weighted-average remaining lease term (In years) |  |  |  |
| Operating leases | 7.5 |  | 7.9 |
| Weighted-average discount rate |  |  |  |
| Operating leases | 3.9 | % |  | 4.1 | % |

[0000866374-21-000030:notes:110]
Other information related to leases was as follow (in millions):

[0000866374-21-000030:notes:111]
|  | Year Ended |
|  | March 31, 2021 |  | March 31, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 152 |  |  | $ | 150 |  |
| Right‑of‑use assets obtained in exchange for lease liabilities |  |  |  |
| Operating Lease | $ | 159 |  |  | $ | 99 |  |

[0000866374-21-000030:notes:112]
During the fiscal year ended March 31, 2020 the Company sold and leased back certain properties and received cash proceeds of $69.6 million and recorded a deferred gain of $32.7 million. As a result of adopting ASC 842 as of April 1, 2019, the Company recognized the deferred gain to prior year retained earnings. No properties were sold and leased back by the Company during the fiscal year ended March 31, 2021.

[0000866374-21-000030:notes:113]
Future lease payments under non-cancellable leases as of March 31, 2021 are as follows (in millions):

[0000866374-21-000030:notes:114]
| Fiscal Year Ended March 31, | Operating Leases |
| 2022 | $ | 147 |  |
| 2023 | 130 |  |
| 2024 | 110 |  |
| 2025 | 87 |  |
| 2026 | 70 |  |
| Thereafter | 256 |  |
| Total undiscounted lease payments | 800 |  |
| Less: imputed interest | 110 |  |
| Total lease liabilities | $ | 690 |  |

[0000866374-21-000030:notes:115]
Total rent expense amounted to $179.8 million, $186.9 million, and $176.8 million  in fiscal years 2021, 2020 and 2019, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-21-000030:notes:116]
REVENUE
Revenue Recognition

[0000866374-21-000030:notes:117]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-21-000030:notes:118]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-21-000030:notes:119]
Customer Contracts and Related Obligations

[0000866374-21-000030:notes:120]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be

[0000866374-21-000030:notes:121]
recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-21-000030:notes:122]
Performance Obligations

[0000866374-21-000030:notes:123]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

[0000866374-21-000030:notes:124]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-21-000030:notes:125]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-21-000030:notes:126]
Contract Balances

[0000866374-21-000030:notes:127]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to receivables when rights to payment become unconditional.

[0000866374-21-000030:notes:128]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $435.4 million and $366.8 million as of March 31, 2021 and 2020, respectively, of which $376.5 million and $361.5 million, respectively, is included in other current liabilities.

[0000866374-21-000030:notes:129]
Disaggregation of Revenue

[0000866374-21-000030:notes:130]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time for the fiscal years ended March 31, 2021, 2020 and 2019:

[0000866374-21-000030:notes:131]
|  | Fiscal Year Ended March 31, |
|  | March 31, 2021 |  | March 31, 2020 |  | March 31, 2019 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |
| Point in time | $ | 12,058 |  |  | $ | 11,581 |  |  | $ | 12,311 |  |
| Over time | 1,435 |  |  | 2,472 |  |  | 4,544 |  |
| Total | 13,493 |  |  | 14,053 |  |  | 16,855 |  |
| FRS |  |  |  |  |  |
| Point in time | 7,674 |  |  | 6,870 |  |  | 6,527 |  |
| Over time | 2,957 |  |  | 3,287 |  |  | 2,829 |  |
| Total | 10,631 |  |  | 10,157 |  |  | 9,356 |  |
| Flex |  |  |  |  |  |
| Point in time | 19,732 |  |  | 18,451 |  |  | 18,838 |  |
| Over time | 4,392 |  |  | 5,759 |  |  | 7,373 |  |
| Total | $ | 24,124 |  |  | $ | 24,210 |  |  | $ | 26,211 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-21-000030:notes:132]
SHARE-BASED COMPENSATION
Equity Compensation Plans

[0000866374-21-000030:notes:133]
The Company's primary plan used for granting equity compensation awards is the Company's 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-21-000030:notes:134]
Share-Based Compensation Expense

[0000866374-21-000030:notes:135]
The following table summarizes the Company's share-based compensation expense for all equity incentive plans:

[0000866374-21-000030:notes:136]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Cost of sales | $ | 20 |  |  | $ | 15 |  |  | $ | 20 |  |
| Selling, general and administrative expenses | 59 |  |  | 56 |  |  | 56 |  |
| Total share-based compensation expense | $ | 79 |  |  | $ | 71 |  |  | $ | 76 |  |

[0000866374-21-000030:notes:137]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as operating cash flows. During fiscal years 2021, 2020 and 2019, the Company did not recognize any excess tax benefits as an operating cash inflow.

[0000866374-21-000030:notes:138]
As of March 31, 2021, the Company had approximately 24.8 million shares available for grant under the 2017 Plan. Options issued to employees under this plan generally vest over four years and expire ten years from the date of grant. Options granted to non-employee directors generally expire five years from the date of grant.

[0000866374-21-000030:notes:139]
The exercise price of options granted to employees is determined by the Company's Board of Directors or the Compensation Committee and may not be less than the closing price of the Company's ordinary shares on the date of grant.

[0000866374-21-000030:notes:140]
As of March 31, 2021, the total unrecognized compensation cost related to unvested share options granted to employees under all plans was not material.

[0000866374-21-000030:notes:141]
The Company also grants restricted share unit ("RSU") awards under its 2017 Plan. RSU awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. RSU awards generally vest in installments over a three to four-year period and unvested RSU awards are forfeited upon termination of employment.

[0000866374-21-000030:notes:142]
Vesting for certain RSU awards is contingent upon both service and market conditions.

[0000866374-21-000030:notes:143]
As of March 31, 2021, the total unrecognized compensation cost related to unvested RSU awards under all plans was approximately $124.1 million. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 1.9 years. Approximately $23.2 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain market conditions.

[0000866374-21-000030:notes:144]
Determining Fair Value - Options and RSU awards

[0000866374-21-000030:notes:145]
Valuation and Amortization Method—The Company estimates the fair value of share options granted under the 2017 Plan using the Black-Scholes valuation method and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period. The fair market value of RSU awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-21-000030:notes:146]
Expected Term—The Company's expected term used in the Black-Scholes valuation method represents the period that the Company's share options are expected to be outstanding and is determined based on historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share options.

[0000866374-21-000030:notes:147]
Expected Volatility—The Company's expected volatility used in the Black-Scholes valuation method is derived from a combination of implied volatility related to publicly traded options to purchase Flex ordinary shares and historical variability in the Company's periodic share price.

[0000866374-21-000030:notes:148]
Expected Dividend—The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-21-000030:notes:149]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0000866374-21-000030:notes:150]
There were no options granted under the 2017 Plan during fiscal years 2021, 2020, and 2019.

[0000866374-21-000030:notes:151]
Determining Fair Value - RSU awards with service and market conditions

[0000866374-21-000030:notes:152]
Valuation and Amortization Method—The Company estimates the fair value of RSU awards granted under the 2017 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-21-000030:notes:153]
Expected volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the RSU awards granted. The service period is three years for those RSU awards granted in fiscal years 2021, 2020, and 2019.

[0000866374-21-000030:notes:154]
Average peer volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of the Standard and Poor's ("S&P") 500 index for the RSU awards granted in fiscal years 2021, 2020, and 2019.

[0000866374-21-000030:notes:155]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to the S&P 500 index for the RSU awards granted in fiscal years 2021, 2020, and 2019.

[0000866374-21-000030:notes:156]
Expected Dividend and Risk-Free Interest Rate assumptions—Same methodology as discussed above.

[0000866374-21-000030:notes:157]
The fair value of the Company's RSU awards under the 2017 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2021, 2020, and 2019 was estimated using the following weighted-average assumptions:

[0000866374-21-000030:notes:158]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Expected volatility | 52.8 | % |  | 38.8 | % |  | 27.4 | % |
| Average peer volatility | 35.9 | % |  | 24.9 | % |  | 25.6 | % |
| Average peer correlation | 0.7 |  |  | 0.5 |  |  | 0.5 |  |
| Expected dividends | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 0.3 | % |  | 1.8 | % |  | 2.7 | % |

[0000866374-21-000030:notes:159]
Share-Based Awards Activity

[0000866374-21-000030:notes:160]
Option activity for all plans is immaterial for all periods presented.

[0000866374-21-000030:notes:161]
Cash received from option exercises under all plans, which was reflected within other financing activities in the consolidated statement of cash flows, was immaterial for fiscal years 2021, 2020, and 2019.

[0000866374-21-000030:notes:162]
The following table summarizes the Company's RSU award activity under all plans ("Price" reflects the weighted-average grant-date fair value):

[0000866374-21-000030:notes:163]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested RSU awards outstanding, beginning of fiscal year | 16,050,640 |  |  | $ | 11.87 |  |  | 14,903,886 |  |  | $ | 13.76 |  |  | 14,619,692 |  |  | $ | 14.39 |  |
| Granted | 10,982,109 |  |  | 11.04 |  |  | 8,259,272 |  |  | 9.81 |  |  | 8,257,502 |  |  | 12.59 |  |
| Vested | (5,520,005) |  |  | 11.64 |  |  | (4,222,524) |  |  | 13.33 |  |  | (5,952,039) |  |  | 13.12 |  |
| Forfeited | (4,204,119) |  |  | 11.92 |  |  | (2,889,994) |  |  | 12.89 |  |  | (2,021,269) |  |  | 14.51 |  |
| Unvested RSU awards outstanding, end of fiscal year | 17,308,625 |  |  | $ | 11.14 |  |  | 16,050,640 |  |  | $ | 11.87 |  |  | 14,903,886 |  |  | $ | 13.76 |  |

[0000866374-21-000030:notes:164]
Of the 11.0 million unvested RSU awards granted in fiscal year 2021, approximately 9.4 million are plain-vanilla unvested RSU awards with no performance or market conditions with an average grant date price of $10.37 per share. Further, approximately 1.6 million of these unvested RSU awards granted in fiscal year 2021 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions, with an average grant date fair value estimated to be $15.03 per award calculated using a Monte Carlo simulation. Vesting information for these shares is further detailed in the table below.

[0000866374-21-000030:notes:165]
Of the 17.3 million unvested RSU awards outstanding under all plans as of the fiscal year ended March 31, 2021, approximately 3.4 million unvested RSU awards represent the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-21-000030:notes:166]
|  |  | Targetednumber ofawards as ofMarch 31, 2021(in shares) |  |  |  |  |  | Range of sharesthat may be issued (1) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment dates |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2021 |  | 1,455,969 |  |  | $ | 15.03 |  |  |  |  | — |  |  | 2,911,938 |  |  | June 2023 |
| Fiscal 2020 |  | 1,388,691 |  |  | $ | 11.92 |  |  |  |  | — |  |  | 2,777,382 |  |  | June 2022 |
| Fiscal 2019 |  | 553,652 |  |  | $ | 14.00 |  |  |  |  | — |  |  | 1,107,304 |  |  | June 2021 |
| Totals |  | 3,398,312 |  |  |  |  |  |  | — |  |  | 6,796,624 |  |  |  |

[0000866374-21-000030:notes:167]
(1)    Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against the Standard and Poor's ("S&P") 500 Composite Index.

[0000866374-21-000030:notes:168]
The Company will continue to recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2021, no shares vested in connection with the RSU awards with market conditions granted in fiscal year 2018.

[0000866374-21-000030:notes:169]
The total intrinsic value of RSU awards vested under all the Company's plans was $68.6 million, $41.7 million and $80.2 million during fiscal years 2021, 2020 and 2019, respectively, based on the closing price of the Company's ordinary shares on the date vested.


## us-gaap:EarningsPerShareTextBlock

[0000866374-21-000030:notes:170]
EARNINGS PER SHARE
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-21-000030:notes:171]
Diluted earnings per share reflects the potential dilution from stock options and RSU awards. The potential dilution from stock options exercisable into ordinary share equivalents and restricted share unit awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-21-000030:notes:172]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income per share:

[0000866374-21-000030:notes:173]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions, exceptper share amounts) |
| Basic earnings per share: |  |  |  |  |  |
| Net income | $ | 613 |  |  | $ | 88 |  |  | $ | 93 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 499 |  |  | $ | 509 |  |  | $ | 527 |  |
| Basic earnings per share | $ | 1.23 |  |  | $ | 0.17 |  |  | $ | 0.18 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 613 |  |  | $ | 88 |  |  | $ | 93 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 499 |  |  | $ | 509 |  |  | $ | 527 |  |
| Weighted-average ordinary share equivalents from stock options and RSU awards (1) (2) | 7 |  |  | 3 |  |  | 3 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 506 |  |  | 512 |  |  | 530 |  |
| Diluted earnings per share | $ | 1.21 |  |  | $ | 0.17 |  |  | $ | 0.18 |  |

[0000866374-21-000030:notes:174]
_________________________________________________________________________
(1)An immaterial amount of options to purchase ordinary shares during fiscal years 2021, 2020, and 2019 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. (2)An immaterial number of RSU awards during fiscal years 2021  2020, and 2019, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-21-000030:notes:175]
SUPPLEMENTAL CASH FLOW DISCLOSURES
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-21-000030:notes:176]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 147 |  |  | $ | 172 |  |  | $ | 190 |  |
| Income taxes | $ | 105 |  |  | $ | 99 |  |  | $ | 134 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 102 |  |  | $ | 104 |  |  | $ | 112 |  |
| Non-cash investment in Bright Machines (Note 2) | $ | — |  |  | $ | — |  |  | $ | 128 |  |
| Finance lease for Bright Machines assets (Note 2) | $ | 4 |  |  | $ | 23 |  |  | $ | 35 |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-21-000030:notes:177]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt are as follows:

[0000866374-21-000030:notes:178]
|  | As of March 31, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Term Loan, including current portion, due in installments through June 2022 | — |  |  | 433 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305 |  |  | 310 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 597 |  |
| 3.750% Notes due February 2026 | 694 |  |  | — |  |
| 4.875% Notes due June 2029 | 661 |  |  | 662 |  |
| 4.875% Notes due May 2030 | 694 |  |  | — |  |
| India Facilities | 133 |  |  | 138 |  |
| Other | 219 |  |  | 211 |  |
| Debt issuance costs | (21) |  |  | (13) |  |
|  | 3,783 |  |  | 2,838 |  |
| Current portion, net of debt issuance costs | (268) |  |  | (149) |  |
| Non-current portion | $ | 3,515 |  |  | $ | 2,689 |  |

[0000866374-21-000030:notes:179]
The weighted-average interest rates for the Company's long-term debt were 4.3% and 4.0% as of March 31, 2021 and 2020, respectively.

[0000866374-21-000030:notes:180]
Scheduled repayments of the Company's bank borrowings and long-term debt are as follows:

[0000866374-21-000030:notes:181]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2022 | $ | 268 |  |
| 2023 | $ | 531 |  |
| 2024 | $ | 53 |  |
| 2025 | $ | 305 |  |
| 2026 | $ | 1,292 |  |
| Thereafter | $ | 1,355 |  |
| Total | $ | 3,804 |  |

[0000866374-21-000030:notes:182]
Notes due February 2026 and May 2030

[0000866374-21-000030:notes:183]
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026 (the "Existing 2026 Notes"), at 99.617% of face value and $325 million aggregate principal amount of 4.875% Notes due May 2030 (the "Existing 2030 Notes" and, together with the Existing 2026 Notes, the "Existing Notes"), at 99.562% of face value. In August 2020, as a further issuance of the Existing Notes, the Company issued under the same terms (other than the initial interest accrual date and first interest payment date for the additional 2026 Notes, and the initial offering price and the issue date for the additional 2026 and 2030 Notes), an additional $250 million of 3.750% Notes due February 2026 (together with the Existing 2026 Notes, the "2026 Notes"), at 109.294% of face value, and $325 million of 4.875% Notes due May 2030 (together with the Existing 2030 Notes, the "2030 Notes"), at 114.863% of face value. Immediately after the issuance of the additional notes issued in August 2020, the Company has $675 million aggregate principal amount of 3.750% Notes due 2026 outstanding and $650 million aggregate principal amount of 4.875% Notes due 2030 outstanding. The Company received in aggregate, proceeds of approximately $1.4 billion, net of discounts and after premiums, from the issuances, which have been used for

[0000866374-21-000030:notes:184]
working capital and other general corporate purposes, in addition to repaying the term loan due June 2022. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet approximately $12.8 million of costs in conjunction with the issuance of the Notes.

[0000866374-21-000030:notes:185]
Interest on the 2026 Notes and the 2030 Notes is payable semi-annually, commencing on August 1, 2020 and November 12, 2020, respectively, except that interest on the additional 2026 Notes is payable commencing February 1, 2021. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.

[0000866374-21-000030:notes:186]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2026 Notes or 2030 Notes may declare all of such series of Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of such series of Notes. As of March 31, 2021, the Company was in compliance with the covenants in the indenture governing the Notes.

[0000866374-21-000030:notes:187]
The 2026 Credit Facility

[0000866374-21-000030:notes:188]
In January 2021, the Company entered into a new $2.0 billion credit agreement which matures in January 2026 (the "2026 Credit Facility") and consists of a $2.0 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2026 Credit Facility replaced the previous $1.75 billion revolving credit facility, which was due to mature in June 2022 (the "2022 Credit Facility"). The Company determined that effectively increasing the borrowing capacity of the former revolving arrangement qualified as a debt modification and consequently all unamortized debt issuance costs related to the $1.75 billion credit facility remain capitalized and are being amortized over the term of the 2026 Credit Facility.

[0000866374-21-000030:notes:189]
Borrowings under the 2026 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.250% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.250% and 1.875% per annum, based on the Company’s credit ratings. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the last business day of March, June, September and December of each calendar year and (ii) in the case of borrowings at the LIBOR rate, on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2026 Credit Facility ranging from 0.15% to 0.30% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.250% to 1.875% per annum (based on the Company’s credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

[0000866374-21-000030:notes:190]
Under the 2026 Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

[0000866374-21-000030:notes:191]
The 2026 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain acquisitions of other entities, (iii) incur liens, (iv) dispose of assets and (v) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2026 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings

[0000866374-21-000030:notes:192]
before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the New Credit Facility. As of March 31, 2021, the Company was in compliance with the covenants under the 2026 Credit Facility agreement.

[0000866374-21-000030:notes:193]
Notes due February 2020 and February 2023

[0000866374-21-000030:notes:194]
In February 2013, the Company issued $500 million of 4.625% Notes due February 15, 2020 and $500 million of 5.000% Notes due February 15, 2023 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act. In July 2013, the Company exchanged these notes for new notes (collectively the "Notes") with substantially similar terms and completed the registration of the Notes with the Securities and Exchange Commission.

[0000866374-21-000030:notes:195]
Interest on the Notes is payable semi-annually, which commenced on August 15, 2013. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and up until June 30, 2017 were guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). The Company replaced its $2.1 billion credit facility, which was due to expire in March 2019 and was guaranteed by the guarantor subsidiaries, with the 2022 Credit Facility, which is not guaranteed by the guarantor subsidiaries. Effective upon the replacement, all guarantor subsidiaries were released from their guarantees under the indenture governing the Notes. The 2022 Credit Facility was further replaced by the 2026 Credit Facility in January 2021.

[0000866374-21-000030:notes:196]
At any time prior to maturity, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date. During fiscal year 2020, the Company tendered and redeemed the total outstanding balance under the Notes due February 15, 2020 with parts of the proceeds obtained from the JPY 33.525 billion term loan due April 2024 and the $650 million of 4.875% Notes due June 15, 2029 (as described further below). As the transaction was determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during its fiscal year ended March 31, 2020, which was recorded in interest and other, net on the consolidated statements of operations.

[0000866374-21-000030:notes:197]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately. As of March 31, 2021, the Company was in compliance with the covenants in the indenture governing the Notes.

[0000866374-21-000030:notes:198]
Term Loan due April 2024

[0000866374-21-000030:notes:199]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 9 for additional details.

[0000866374-21-000030:notes:200]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA, and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2021, the Company was in compliance with the covenants under this term loan agreement.

[0000866374-21-000030:notes:201]
Notes due June 2025

[0000866374-21-000030:notes:202]
In June 2015, the Company issued $600 million of 4.750% Notes ("2025 Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at 99.213% of face value, and an effective yield of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which was used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.

[0000866374-21-000030:notes:203]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the 2025 Notes. The issuance costs were capitalized and presented on the balance sheet as a direct deduction from the carrying amount of the 2025 Notes.

[0000866374-21-000030:notes:204]
Interest on the 2025 Notes is payable semi-annually, commencing on December 15, 2015. The 2025 Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and up until June 30, 2017 were guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). The Company replaced its $2.1 billion credit facility, which was due to expire in March 2019 and was guaranteed by the guarantor subsidiaries, with the 2022 Credit Facility, which was not guaranteed by the guarantor subsidiaries. Effective upon the replacement, all guarantor subsidiaries were released from their guarantees under the indenture for the 2025 Notes. The 2022 Credit Facility was further replaced by the 2026 Credit Facility in January 2021.

[0000866374-21-000030:notes:205]
At any time prior to March 15, 2025, the Company may redeem some or all of the 2025 Notes at a redemption price equal to 100% of the principal amount of the 2025 Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the 2025 Notes indenture), the Company must offer to repurchase the 2025 Notes at a repurchase price equal to 101% of the principal amount of the 2025 Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0000866374-21-000030:notes:206]
The indenture governing the 2025 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2025 Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2025 Notes may declare all of the 2025 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2025 Notes. As of March 31, 2021, the Company was in compliance with the covenants in the indenture governing the 2025 Notes.

[0000866374-21-000030:notes:207]
Notes due June 2029

[0000866374-21-000030:notes:208]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “Existing 2029 Notes”), at 99.607% of face value. In November 2019, as a further issuance of the Existing 2029 Notes, the Company issued under the same terms, an additional $200 million of 4.875% Notes due June 15, 2029 (together with the "Existing 2029 Notes", the "2029 Notes"), at 107.289% of face value. Immediately after the issuance of the notes issued in November 2019, the Company has $650 million aggregate principal amount of 4.875% Notes due 2029 outstanding. The Company received in aggregate, proceeds of approximately $662.8 million, net of discount and premium, from the issuances which were used, together with available cash, to refinance certain other outstanding debt. The Company incurred and capitalized as a direct reduction to the carrying amount of the notes presented on the balance sheet approximately $6.6 million of costs in conjunction with the issuance of the 2029 Notes.

[0000866374-21-000030:notes:209]
Interest on the 2029 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2019. The 2029 Notes are senior unsecured obligations of the Company and rank equally with all of the Company’s other existing and future senior and unsecured indebtedness.

[0000866374-21-000030:notes:210]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with,

[0000866374-21-000030:notes:211]
or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of March 31, 2021, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.

[0000866374-21-000030:notes:212]
Other Borrowings

[0000866374-21-000030:notes:213]
In July 2018, a subsidiary of the Company entered into a $200 million term loan facility (the "Facility"), under which there was $133.4 million in borrowings outstanding as of March 31, 2021. The Facility was used to fund capital expenditures to support the Company's expansion plans for India. The availability period during which drawdowns can be made was from the date of the agreement to and including January 2020. The maximum maturity of each drawdown will be 5 years from the funded Capex shipment date. As a result, the longest maturity date of any drawdown under the Facility will be June 2023. Borrowings under this term loan bear interest at LIBOR plus a margin of 0.90% to 1.15% depending on loan duration.

[0000866374-21-000030:notes:214]
In January 2017, the Company borrowed €100 million (approximately $117.6 million as of March 31, 2021), under a 5-year, term-loan agreement due January 2, 2022. Borrowings under this term loan bear interest at EURIBOR minus 0.1% plus the applicable margin ranging between 0.40% and 1.35%, based on the Company's credit ratings. During the fourth quarter of fiscal year 2021, the Company repaid the loan and immediately borrowed the same amount from a different financial institution for a fixed interest rate of (0.16)%, while maintaining the January 2, 2022 maturity date. As of March 31, 2021, the borrowings have been included as current liabilities under the consolidated balance sheet.

[0000866374-21-000030:notes:215]
In October 2015, the Company borrowed €50 million, under a 5-year, term-loan agreement due September 30, 2020. As of March 31, 2021, the borrowings under this term-loan have been paid in full.

[0000866374-21-000030:notes:216]
These term loans are unsecured and are guaranteed by the Company. These term loan agreements contain customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. These term loan agreements also require that the Company maintain a maximum ratio of total indebtedness to EBITDA, and a minimum interest coverage ratio, as defined therein, during their terms. As of March 31, 2021, the Company was in compliance with the covenants under these term loan agreements.

[0000866374-21-000030:notes:217]
As of March 31, 2021, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities in the amount of $319.1 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2021 and 2020. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-21-000030:notes:218]
FINANCIAL INSTRUMENTS
Foreign Currency Contracts

[0000866374-21-000030:notes:219]
The Company transacts business in various foreign countries and is therefore exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency of the operating entity. The Company enters into short-term and long-term foreign currency derivatives contracts, including forward, swap, and options contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and

[0000866374-21-000030:notes:220]
transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-21-000030:notes:221]
As of March 31, 2021, the aggregate notional amount of the Company's outstanding foreign currency derivative contracts was $8.9 billion as summarized below:

[0000866374-21-000030:notes:222]
|  | Foreign CurrencyAmount |  | Notional ContractValue in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| CNY | 2,895 |  |  | — |  |  | $ | 441 |  |  | $ | — |  |
| HUF | 33,969 |  |  | — |  |  | 110 |  |  | — |  |
| JPY | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN | 6,197 |  |  | — |  |  | 299 |  |  |  |
| Other | N/A |  | N/A |  | 282 |  |  | 62 |  |
|  |  |  |  |  | 1,432 |  |  | 62 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |
| CAD | 103 |  |  | 67 |  |  | 82 |  |  | 53 |  |
| CNY | 4,376 |  |  | 1,442 |  |  | 668 |  |  | 220 |  |
| EUR | 1,724 |  |  | 1,892 |  |  | 2,031 |  |  | 2,237 |  |
| GBP | 47 |  |  | 69 |  |  | 65 |  |  | 95 |  |
| HUF | 66,705 |  |  | 64,004 |  |  | 216 |  |  | 207 |  |
| ILS | 422 |  |  | 10 |  |  | 127 |  |  | 3 |  |
| MXN | 6,524 |  |  | 5,362 |  |  | 315 |  |  | 259 |  |
| MYR | 642 |  |  | 297 |  |  | 155 |  |  | 72 |  |
| PLN | 221 |  |  | 190 |  |  | 56 |  |  | 48 |  |
| SEK | 467 |  |  | 541 |  |  | 55 |  |  | 62 |  |
| Other | N/A |  | N/A |  | 210 |  |  | 175 |  |
|  |  |  |  |  | 3,980 |  |  | 3,431 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 5,412 |  |  | $ | 3,493 |  |

[0000866374-21-000030:notes:223]
As of March 31, 2021 and 2020, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the consolidated statements of operations. The Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were immaterial  as of March 31, 2021, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-21-000030:notes:224]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of March 31, 2021, and March 30, 2020. The changes in fair value of the USD JPY cross currency swap are reported in accumulated other comprehensive loss,

[0000866374-21-000030:notes:225]
with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also impacts the same line.

[0000866374-21-000030:notes:226]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2021 and 2020:

[0000866374-21-000030:notes:227]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31,2021 |  | March 31,2020 |  | Balance SheetLocation |  | March 31,2021 |  | March 31,2020 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 23 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 16 |  |  | $ | 47 |  |
| Foreign currency contracts | Other assets |  | $ | 5 |  |  | $ | 14 |  |  | Other liabilities |  | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 31 |  |  | $ | 83 |  |  | Other current liabilities |  | $ | 32 |  |  | $ | 103 |  |

[0000866374-21-000030:notes:228]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-21-000030:notes:229]
ACCUMULATED OTHER COMPREHENSIVE LOSSThe changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2021, 2020 and 2019 are as follows:

[0000866374-21-000030:notes:230]
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance on April 1, 2018 | $ | (36) |  |  | $ | (50) |  |  | $ | (86) |  |
| Other comprehensive loss before reclassifications | (48) |  |  | (59) |  |  | (107) |  |
| Net loss reclassified from accumulated other comprehensive loss | 42 |  |  | — |  |  | 42 |  |
| Net current-period other comprehensive loss | (6) |  |  | (59) |  |  | (65) |  |
| Ending balance on March 31, 2019 | $ | (42) |  |  | $ | (109) |  |  | $ | (151) |  |
| Other comprehensive loss before reclassifications | (43) |  |  | (22) |  |  | (65) |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 3 |  |  | (2) |  |  | 1 |  |
| Net current-period other comprehensive loss | (40) |  |  | (24) |  |  | (64) |  |
| Ending balance on March 31, 2020 | $ | (82) |  |  | $ | (133) |  |  | $ | (215) |  |
| Other comprehensive gain before reclassifications | 48 |  |  | 56 |  |  | 104 |  |
| Net gains reclassified from accumulated other comprehensive loss | (8) |  |  | — |  |  | (8) |  |
| Net current-period other comprehensive gain | 40 |  |  | 56 |  |  | 96 |  |
| Ending balance on March 31, 2021 | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |

[0000866374-21-000030:notes:231]
Net (gains) losses reclassified from accumulated other comprehensive loss were immaterial during fiscal years 2021 and 2020.

[0000866374-21-000030:notes:232]
Net gains reclassified from accumulated other comprehensive loss during fiscal year 2019 relating to derivative instruments and other includes $40.6 million attributable to the Company's cash flow hedge instruments which were recognized as a component of cost of sales in the consolidated statement of operations.
The tax impact to other comprehensive loss was immaterial for all periods presented.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-21-000030:notes:233]
TRADE RECEIVABLES SECURITIZATION
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-21-000030:notes:234]
Asset-Backed Securitization Programs

[0000866374-21-000030:notes:235]
The Company sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the "Global Program") and its North American Asset-Backed Securitization Agreement (the "North American Program," and together with the Global Program, the "ABS Programs") to affiliated special purpose entities, each of which in turn sells a fraction of the receivables to unaffiliated financial institutions, based on the Company's requirements. Under these programs, the entire purchase price of sold receivables are paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The fair value of the guarantee obligation was immaterial as of March 31, 2021 and March 31, 2020, respectively. The accounts receivable balances sold under the ABS Programs were removed from the consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the consolidated statements of cash flows.

[0000866374-21-000030:notes:236]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are legally isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which have the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by

[0000866374-21-000030:notes:237]
the financial institutions are $375 million for the Global Program, of which $200 million is committed and $175 million is uncommitted, and $175 million for the North American Program, of which $100 million is committed and $75 million is uncommitted.

[0000866374-21-000030:notes:238]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the fiscal years ended March 31, 2021, 2020 and 2019 were not material and are included in interest, net within the consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-21-000030:notes:239]
As of March 31, 2021, no accounts receivable had been sold under the ABS programs. As of March 31, 2020, approximately $0.8 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds for the same amount.

[0000866374-21-000030:notes:240]
For the fiscal year ended March 31, 2021, cash flows from sales of receivables to the special purpose entities under the ABS Programs consisted of approximately $8.7 billion, for transfers of receivables. Further, cash flows from sales of receivables from the special purpose entities to unaffiliated financial institutions, during fiscal year 2021, consisted of approximately $0.6 billion for transfers of receivables. For the fiscal years ended March 31, 2020 and 2019 cash flows from sales of receivables under the ABS Programs consisted of approximately $7.6 billion and $6.8 billion, respectively, for transfers of receivables and approximately $2.6 billion and $3.6 billion, respectively, for collections on deferred purchase price receivables (effective November 2019, upon amending the previous ABS programs, the Company no longer holds a deferred purchase price receivables balance). The Company's cash flows from transfers of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-21-000030:notes:241]
Trade Accounts Receivable Sale Programs

[0000866374-21-000030:notes:242]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.2 billion and $0.4 billion as of March 31, 2021 and 2020, respectively. For the fiscal years ended March 31, 2021, 2020 and 2019, total accounts receivable sold to certain third party banking institutions was approximately $0.8 billion, $1.6 billion and $2.7 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and the cash received were included as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-21-000030:notes:243]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-21-000030:notes:244]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of March 31, 2021.

[0000866374-21-000030:notes:245]
Level 2 - Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-21-000030:notes:246]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-21-000030:notes:247]
The Company's cash equivalents are comprised of bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-21-000030:notes:248]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other noncurrent assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy. There were no investments classified as level 1 in the fair value hierarchy as of March 31, 2021.

[0000866374-21-000030:notes:249]
Level 3 - Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-21-000030:notes:250]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of March 31, 2021 and 2020.

[0000866374-21-000030:notes:251]
There were no transfers between levels in the fair value hierarchy during fiscal years 2021 and 2020.

[0000866374-21-000030:notes:252]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-21-000030:notes:253]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2021 and 2020:

[0000866374-21-000030:notes:254]
|  | Fair Value Measurements as of March 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 1,507 |  |  | $ | — |  |  | $ | 1,507 |  |
| Foreign currency contracts (Note 9) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |

[0000866374-21-000030:notes:255]
|  | Fair Value Measurements as of March 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 404 |  |  | $ | — |  |  | $ | 404 |  |
| Foreign currency contracts (Note 9) | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (150) |  |  | $ | — |  |  | $ | (150) |  |

[0000866374-21-000030:notes:256]
Other financial instruments

[0000866374-21-000030:notes:257]
The following table presents the Company's major debts not carried at fair value as of March 31, 2021 and 2020:

[0000866374-21-000030:notes:258]
|  | As of March 31, 2021 |  | As of March 31, 2020 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In millions) |  | (In millions) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | $ | — |  |  | $ | — |  |  | $ | 433 |  |  | $ | 414 |  |  | Level 1 |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 537 |  |  | $ | 500 |  |  | $ | 500 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | $ | 305 |  |  | $ | 305 |  |  | $ | 310 |  |  | $ | 310 |  |  | Level 2 |
| 4.750% Notes due June 2025 | $ | 598 |  |  | $ | 670 |  |  | $ | 597 |  |  | $ | 613 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 694 |  |  | 756 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | $ | 661 |  |  | $ | 756 |  |  | $ | 662 |  |  | $ | 628 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 694 |  |  | 800 |  |  | — |  |  | — |  |  | Level 1 |
| Euro Term Loans | $ | 168 |  |  | $ | 168 |  |  | $ | 208 |  |  | $ | 208 |  |  | Level 2 |
| India Facilities | $ | 133 |  |  | $ | 133 |  |  | $ | 138 |  |  | $ | 138 |  |  | Level 2 |

[0000866374-21-000030:notes:259]
The Term Loan due June 2022, and the Notes due February 2023, June 2025, February 2026, June 2029 and May 2030 are valued based on broker trading prices in active markets.
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans due May 2021 and January 2022, based on the current market rate, and as of March 31, 2021, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-21-000030:notes:260]
COMMITMENTS AND CONTINGENCIES
Commitments

[0000866374-21-000030:notes:261]
As of March 31, 2021 and 2020, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under finance leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2038. Refer to note 3 for additional details on the minimum lease payments.

[0000866374-21-000030:notes:262]
Litigation and other legal matters

[0000866374-21-000030:notes:263]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-21-000030:notes:264]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could

[0000866374-21-000030:notes:265]
be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-21-000030:notes:266]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor agreed to an immaterial settlement in fiscal year 2021.

[0000866374-21-000030:notes:267]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. Lead plaintiff’s opening appeal brief is due May 19, 2021, and defendants’ answering brief is due June 18, 2021. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-21-000030:notes:268]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-21-000030:notes:269]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 387.5 million Brazilian reals (approximately USD $66.8 million based on the exchange rate as of March 31, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 61.7 million Brazilian reals or USD $10.6 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and has filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is

[0000866374-21-000030:notes:270]
37.6 million Brazilian reals (approximately USD $6.5 million). The Company believes there is no legal basis for any of these assessments and has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

[0000866374-21-000030:notes:271]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-21-000030:notes:272]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $162.5 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-21-000030:notes:273]
A different foreign Tax Authority has issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagrees with the Tax Authority’s assertion but has agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount has been accrued for during the fourth quarter of fiscal year 2021 and is expected to be paid during the first half of fiscal year 2022.

[0000866374-21-000030:notes:274]
As the final resolutions of the above tax items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-21-000030:notes:275]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-21-000030:notes:276]
INCOME TAXES
The domestic (Singapore) and foreign components of income before income taxes were comprised of the following:

[0000866374-21-000030:notes:277]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Domestic | $ | 242 |  |  | $ | (2) |  |  | $ | (10) |  |
| Foreign | 472 |  |  | 161 |  |  | 192 |  |
| Total | $ | 714 |  |  | $ | 159 |  |  | $ | 182 |  |

[0000866374-21-000030:notes:278]
The provision for income taxes consisted of the following:

[0000866374-21-000030:notes:279]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Current: |  |  |  |  |  |
| Domestic | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Foreign | 105 |  |  | 62 |  |  | 99 |  |
|  | 106 |  |  | 64 |  |  | 101 |  |
| Deferred: |  |  |  |  |  |
| Domestic | 1 |  |  | — |  |  | — |  |
| Foreign | (6) |  |  | 7 |  |  | (12) |  |
|  | (5) |  |  | 7 |  |  | (12) |  |
| Provision for income taxes | $ | 101 |  |  | $ | 71 |  |  | $ | 89 |  |

[0000866374-21-000030:notes:280]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2021, 2020 and 2019. The reconciliation of the income tax expense expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0000866374-21-000030:notes:281]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Income taxes based on domestic statutory rates | $ | 121 |  |  | $ | 27 |  |  | $ | 31 |  |
| Effect of tax rate differential | (82) |  |  | (81) |  |  | (135) |  |
| Change in unrecognized tax benefit | 11 |  |  | (1) |  |  | (15) |  |
| Change in valuation allowance | 35 |  |  | 93 |  |  | 192 |  |
| Foreign exchange movement on prior year taxes recoverable | 5 |  |  | 13 |  |  | 5 |  |
| Expiration of tax attributes | — |  |  | — |  |  | 4 |  |
| APB23 tax liability | 1 |  |  | 9 |  |  | 2 |  |
| Other | 10 |  |  | 11 |  |  | 5 |  |
| Provision for income taxes | $ | 101 |  |  | $ | 71 |  |  | $ | 89 |  |

[0000866374-21-000030:notes:282]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2021, 2020 and 2019 was $21.2 million, $15.6 million and $24.4 million, respectively. For the fiscal year ended March 31, 2021, the effect on basic and diluted earnings per share was $0.04 and $0.04, respectively, and the effects on basic and diluted earnings per share during fiscal years 2020 and 2019 were $0.03 and $0.03, and $0.05 and $0.05, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in various years through the end of fiscal year 2028.

[0000866374-21-000030:notes:283]
The Company provides a valuation allowance against deferred tax assets that in the Company's estimation are not more likely than not to be realized. During fiscal year 2021, 2020 and 2019, the Company released valuation allowances totaling $24.5 million, $1.1 million and $2.8 million, respectively. For fiscal year 2021, this valuation allowance release was mainly related to certain operations in Canada as this amount was deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those subsidiaries. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances. Lastly, these valuation allowance reductions and eliminations were offset by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions.

[0000866374-21-000030:notes:284]
For fiscal years ended March 31, 2021, 2020 and 2019, the offsetting amounts totaled $60.0 million, $90.2 million and $194.8 million, respectively.

[0000866374-21-000030:notes:285]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years ended March 31, 2021, 2020 and 2019 were $57.3 million, $27.9 million and $7.5 million, respectively.

[0000866374-21-000030:notes:286]
The components of deferred income taxes are as follows:

[0000866374-21-000030:notes:287]
|  | As of March 31, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (69) |  |  | $ | (37) |  |
| Intangible assets | (45) |  |  | (50) |  |
| Others | (13) |  |  | (25) |  |
| Total deferred tax liabilities | (127) |  |  | (112) |  |
| Deferred tax assets: |  |  |  |
| Fixed assets | 66 |  |  | 59 |  |
| Intangible assets | 8 |  |  | 7 |  |
| Deferred compensation | 20 |  |  | 17 |  |
| Inventory valuation | 28 |  |  | 27 |  |
| Provision for doubtful accounts | 5 |  |  | 5 |  |
| Net operating loss and other carryforwards | 1,641 |  |  | 1,821 |  |
| Others | 190 |  |  | 207 |  |
| Total deferred tax assets | 1,958 |  |  | 2,143 |  |
| Valuation allowances | (1,726) |  |  | (1,939) |  |
| Total deferred tax assets, net of valuation allowances | 232 |  |  | 204 |  |
| Net deferred tax asset | $ | 105 |  |  | $ | 92 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Long-term asset | $ | 165 |  |  | $ | 163 |  |
| Long-term liability | (60) |  |  | (71) |  |
| Total | $ | 105 |  |  | $ | 92 |  |

[0000866374-21-000030:notes:288]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-21-000030:notes:289]
The Company has recorded deferred tax assets of approximately $1.8 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $82.9 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-21-000030:notes:290]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
|  | (In millions) |
| 2022 - 2027 | $ | 577 |  |
| 2028 - 2033 | 437 |  |
| 2034 and post | 126 |  |
| Indefinite | 613 |  |
|  | $ | 1,753 |  |

[0000866374-21-000030:notes:291]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-21-000030:notes:292]
The Company does not provide for income taxes on approximately $1.5 billion of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. The estimated amount of the unrecognized deferred tax liability on these undistributed earnings is approximately $134.8 million. As a result, as of March 31, 2021, the Company has provided for earnings in foreign subsidiaries that are not considered to be indefinitely reinvested and therefore subject to withholding taxes on $12.6 million of undistributed foreign earnings, recording a deferred tax liability of approximately $0.6 million thereon.

[0000866374-21-000030:notes:293]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-21-000030:notes:294]
|  | Fiscal Year EndedMarch 31, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Balance, beginning of fiscal year | $ | 246 |  |  | $ | 252 |  |
| Additions based on tax position related to the current year | 16 |  |  | 24 |  |
| Additions for tax positions of prior years | 14 |  |  | 4 |  |
| Reductions for tax positions of prior years | (8) |  |  | (3) |  |
| Reductions related to lapse of applicable statute of limitations | (16) |  |  | (18) |  |
| Impact from foreign exchange rates fluctuation | 14 |  |  | (13) |  |
| Balance, end of fiscal year | $ | 266 |  |  | $ | 246 |  |

[0000866374-21-000030:notes:295]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an additional approximate $22.0 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-21-000030:notes:296]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2008.

[0000866374-21-000030:notes:297]
Of the $266.0 million of unrecognized tax benefits at March 31, 2021, $173.0 million will affect the annual effective tax rate (ETR) if the benefits are eventually recognized. The amount that doesn’t impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-21-000030:notes:298]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company’s tax expense. During the fiscal years ended March 31, 2021, 2020 and 2019, the Company recognized interest and penalties of 
approximately $2.1 million, ($0.9) million and ($2.9) million, respectively. The Company had approximately $14.4 million, $12.3 million and $13.3 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2021, 2020 and 2019, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-21-000030:notes:299]
RESTRUCTURING CHARGES
Fiscal Year 2021

[0000866374-21-000030:notes:300]
In order to support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, the Company identified certain structural changes to restructure the business. These restructuring actions will eliminate non-core activities primarily within the Company’s corporate function, align the Company’s cost structure with its reorganizing and optimizing of its operations model along its two reporting segments, and further sharpen its focus to winning business in end markets where it has competitive advantages and deep domain expertise. During fiscal year 2021, the Company recognized approximately $101.3 million of restructuring charges, most of which related to employee severance.

[0000866374-21-000030:notes:301]
Restructuring charges are not included in segment income, as disclosed further in note 20.

[0000866374-21-000030:notes:302]
Fiscal Year 2020

[0000866374-21-000030:notes:303]
During the first half of fiscal year 2020 in connection with the geopolitical developments and uncertainties at the time, primarily impacting one customer in China, the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and streamline its cost structure. During fiscal year 2020, the Company recognized $216.4 million of restructuring charges. The Company incurred cash charges of approximately $159.3 million, that were predominantly for employee severance, in addition to non-cash charges of $57.1 million, respectively, primarily related to asset impairments.

[0000866374-21-000030:notes:304]
Fiscal Year 2019

[0000866374-21-000030:notes:305]
During fiscal year 2019, the Company took targeted actions to optimize its portfolio, most notably within its former Consumer Technologies Group segment. The Company recognized restructuring charges of approximately $113.3 million during the fiscal year ended March 31, 2019, of which $73.2 million were non-cash charges primarily for asset impairments. A significant component of its charges were associated with the wind down of its NIKE operations in Mexico in the third quarter of fiscal year 2019 where it recognized charges of $66 million primarily for non-cash asset impairments.

[0000866374-21-000030:notes:306]
In addition, the Company executed targeted head-count reductions at existing operating and design sites and corporate functions and exited certain immaterial businesses. Of these total restructuring charges, approximately $99.0 million was recognized as a component of cost of sales during the fiscal year ended March 31, 2019.

[0000866374-21-000030:notes:307]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2018 | $ | 48 |  |  | $ | — |  |  | $ | 13 |  |  | $ | 61 |  |
| Provision for charges incurred in fiscal year 2019 | 39 |  |  | 46 |  |  | 28 |  |  | 113 |  |
| Cash payments for charges incurred in fiscal year 2018 and prior | (41) |  |  | — |  |  | (4) |  |  | (45) |  |
| Cash payments for charges incurred in fiscal year 2019 | (23) |  |  | — |  |  | (1) |  |  | (24) |  |
| Non-cash charges incurred in fiscal year 2019 | — |  |  | (46) |  |  | (27) |  |  | (73) |  |
| Balance as of March 31, 2019 | 23 |  |  | — |  |  | 9 |  |  | 32 |  |
| Provision for charges incurred in fiscal year 2020 | 123 |  |  | 46 |  |  | 47 |  |  | 216 |  |
| Cash payments for charges incurred in fiscal year 2019 and prior | (15) |  |  | — |  |  | (3) |  |  | (18) |  |
| Cash payments for charges incurred in fiscal year 2020 | (112) |  |  | — |  |  | (35) |  |  | (147) |  |
| Non-cash charges incurred in fiscal year 2020 | — |  |  | (46) |  |  | (14) |  |  | (60) |  |
| Balance as of March 31, 2020 | 19 |  |  | — |  |  | 4 |  |  | 23 |  |
| Provision for charges incurred in fiscal year 2021 | 89 |  |  | 8 |  |  | 4 |  |  | 101 |  |
| Cash payments for charges incurred in fiscal year 2020 and prior | (14) |  |  | — |  |  | — |  |  | (14) |  |
| Cash payments for charges incurred in fiscal year 2021 | (49) |  |  | — |  |  | (1) |  |  | (50) |  |
| Non-cash charges incurred in fiscal year 2021 | — |  |  | (8) |  |  | 1 |  |  | (7) |  |
| Balance as of March 31, 2021 | 45 |  |  | — |  |  | 8 |  |  | 53 |  |
| Less: Current portion (classified as other current liabilities) | 42 |  |  | — |  |  | 8 |  |  | 50 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-21-000030:notes:308]
OTHER CHARGES (INCOME), NET
Other charges (income), net for the fiscal years ended March 31, 2021, 2020 and 2019 are primarily composed of the following:

[0000866374-21-000030:notes:309]
|  | Fiscal Year Ended March 31 |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Gain on deconsolidation of subsidiary (1) | $ | — |  |  | $ | — |  |  | $ | (87) |  |
| Gain on foreign exchange transactions | (21) |  |  | (10) |  |  | (1) |  |
| Equity in (earnings) losses (2) | (83) |  |  | (5) |  |  | 6 |  |
| Investment impairments (3) | 37 |  |  | 98 |  |  | 193 |  |

[0000866374-21-000030:notes:310]
(1)During fiscal year 2019, the Company recognized other income of approximately $87 million from the deconsolidation of Bright Machines.

[0000866374-21-000030:notes:311]
(2)Represents (gains) losses on strategic investments in privately held companies accounted under equity method. During fiscal year 2021, the Company recognized $83 million of equity in earnings, driven by the value increase in certain investment funds primarily resulting from discrete market events including initial public offerings of certain companies included in the fund. Out of the total gain on investment, the Company realized approximately $48 million of cash proceeds as it sold certain shares received as a distribution from one of its funds' investments. 
(3)During fiscal years 2021 and 2020, and in connection with the Company’s ongoing assessment of recoverability of its investment portfolio, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized $36.5 million and $97.7 million of total impairment charges, respectively (See note 2 for additional information). During fiscal year 2019, the Company recognized investment impairments of $193.1 million, under other charges (income), net, which is primarily driven by an $84 million impairment in its investment in Elementum, coupled with a $76 million loss for the portion of its investment in an unrelated third-party venture backed company, also determined to be impaired.


## flex:InterestAndOtherNetTextBlock

[0000866374-21-000030:notes:312]
INTEREST, NET
Interest, net for the fiscal years ended March 31, 2021, 2020 and 2019 are primarily composed of the following:

[0000866374-21-000030:notes:313]
|  | Fiscal Year Ended March 31 |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Interest expenses on debt obligations (1) | $ | 150 |  |  | $ | 146 |  |  | $ | 146 |  |
| ABS and AR sales programs related expenses | $ | 11 |  |  | $ | 43 |  |  | $ | 46 |  |
| Interest income | $ | (14) |  |  | $ | (19) |  |  | $ | (19) |  |

[0000866374-21-000030:notes:314]
(1)    Interest expense on debt obligations for fiscal year 2020 includes debt extinguishment costs of $7.2 million, related to the full repayments of the Notes due February 2020 and the Term Loan due November 2021. Debt extinguishment costs incurred during fiscal years 2021 and 2019 were immaterial.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-21-000030:notes:315]
BUSINESS AND ASSET ACQUISITIONS & DIVESTITURES
Fiscal 2020 Business acquisition and divestitures

[0000866374-21-000030:notes:316]
During fiscal year 2020, the Company completed an acquisition that was not significant to the consolidated financial position, result of operations and cash flows of the Company.

[0000866374-21-000030:notes:317]
Further, during fiscal year 2020, the Company disposed of two immaterial non-strategic businesses that operated under its former High Reliability Solutions and Industrial and Emerging Industries ("IEI") segments. The net gain on dispositions was not material to the Company’s consolidated financial results, and was included in other charges, net in the consolidated statements of operations for fiscal year 2020.

[0000866374-21-000030:notes:318]
Pro-forma results of operations for the acquisition and divestitures have not been presented because the effects were not individually, nor in the aggregate, material to the Company's consolidated financial results for all periods presented.

[0000866374-21-000030:notes:319]
Fiscal 2019 Business acquisition

[0000866374-21-000030:notes:320]
In October 2018, the Company completed the acquisition of a business that was not significant to the consolidated financial position, result of operations and cash flows of the Company. The acquired business expanded the Company's design capabilities in the telecom market within its former Communications & Enterprise Compute segment. The assets acquired and liabilities assumed were not material to the Company's consolidated financial results. Results of operations were included in the Company’s consolidated financial results beginning on the date of acquisition, and were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-21-000030:notes:321]
Fiscal 2019 Divestitures

[0000866374-21-000030:notes:322]
During the third quarter of fiscal year 2019, the Company disposed of an immaterial non-strategic business in Brazil that operated across all of its former segments. The net loss on disposition was not material to the Company's consolidated financial results, and was included in other charges, net in the consolidated statement of operation for fiscal year 2019.

[0000866374-21-000030:notes:323]
During the second quarter of fiscal year 2019, the Company divested its China-based Multek operations, for proceeds of approximately $267.1 million, net of cash. The Company transferred approximately $231.4 million of net assets, primarily property and equipment, accounts receivable, and accounts payable. Further, the Company incurred various selling costs as part of this divestiture and allocated approximately $19.0 million of goodwill to the divested business. This transaction resulted in the recognition of an immaterial loss which was included in other charges, net in the consolidated statements of operations for fiscal year 2019.

[0000866374-21-000030:notes:324]
Pro-forma results of operations for these divestitures have not been presented because the effects were not individually, nor in the aggregate, material to the Company's consolidated financial results for all periods presented.


## us-gaap:TreasuryStockTextBlock

[0000866374-21-000030:notes:325]
SHARE REPURCHASE PLAN
During fiscal year 2021, the Company repurchased approximately 10.5 million shares for an aggregate purchase price of approximately $183.5 million and retired all of these shares.

[0000866374-21-000030:notes:326]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 7, 2020. As of March 31, 2021, shares in the aggregate amount of $316.5 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-21-000030:notes:327]
SEGMENT REPORTINGIn March 2020, the Company announced a change in organizational structure as part of its strategy to further drive efficiency and productivity with two focused delivery models. The Company’s chief operating decision maker ("CODM") changed from the CEO and certain direct staff who oversee operations of the business, to the CEO herself. As a result, beginning in fiscal year 2021, the Company now reports its financial performance based on two operating and reportable segments, Flex Agility Solutions (“FAS”) and Flex Reliability Solutions (“FRS”) and analyzes operating income as the measure of segment profitability.
The FAS segment is optimized for speed to market based on a highly flexible supply and manufacturing system. The Company realigned the majority of the customers under the former Communications & Enterprise Compute, and Consumer Technologies Group segments under the new FAS segment. Certain customers that were in the former IEI segment that meet the above delivery model were also consolidated into the FAS segment. FAS is now comprised of the following end markets that represent reporting units:

[0000866374-21-000030:notes:328]
•Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-21-000030:notes:329]
•Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

[0000866374-21-000030:notes:330]
•Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-21-000030:notes:331]
The FRS segment is optimized for longer product lifecycles requiring complex ramps with specialized production models and critical environments. The Company consolidated the majority of its customers under the former High Reliability Solutions and Industrial and Emerging Industries segments into the new FRS segment. FRS is now comprised of the following end markets that represent reporting units:

[0000866374-21-000030:notes:332]
•Automotive, including autonomous, connectivity, electrification, and smart technologies;

[0000866374-21-000030:notes:333]
•Health Solutions, including medical devices, medical equipment and drug delivery; and

[0000866374-21-000030:notes:334]
•Industrial, including capital equipment, industrial devices, renewable including our Nextracker business, grid edge, and power systems.

[0000866374-21-000030:notes:335]
The determination of the FAS and FRS segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-21-000030:notes:336]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related assets impairments (recoveries), restructuring charges, the new revenue standard adoption impact, legal and other, interest, net and other charges (income), net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-21-000030:notes:337]
Selected financial information by segment is in the table below. Fiscal year 2020 and 2019 historical information has been recast to reflect the new operating and reportable segments, in the table below and in Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations."

[0000866374-21-000030:notes:338]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |
| Flex Agility Solutions | $ | 13,493 |  |  | $ | 14,053 |  |  | $ | 16,855 |  |
| Flex Reliability Solutions | 10,631 |  |  | 10,157 |  |  | 9,356 |  |
|  | $ | 24,124 |  |  | $ | 24,210 |  |  | $ | 26,211 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |
| Flex Agility Solutions | $ | 449 |  |  | $ | 369 |  |  | $ | 442 |  |
| Flex Reliability Solutions | 662 |  |  | 642 |  |  | 534 |  |
| Corporate and Other | (80) |  |  | (113) |  |  | (104) |  |
| Total income | 1,031 |  |  | 898 |  |  | 872 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 62 |  |  | 64 |  |  | 74 |  |
| Stock-based compensation | 79 |  |  | 71 |  |  | 76 |  |
| Customer related asset impairments (recoveries) (1) | (7) |  |  | 106 |  |  | 87 |  |
| Restructuring charges (Note 15) | 101 |  |  | 216 |  |  | 113 |  |
| New revenue standard adoption impact (Note 4) | — |  |  | — |  |  | 9 |  |
| Legal and other (2) | 1 |  |  | 26 |  |  | 36 |  |
| Interest, net | 148 |  |  | 174 |  |  | 175 |  |
| Other charges (income), net (Note 16) | (67) |  |  | 82 |  |  | 120 |  |
| Income before income taxes | $ | 714 |  |  | $ | 159 |  |  | $ | 182 |  |

[0000866374-21-000030:notes:339]
(1)Customer related asset impairments (recoveries) for fiscal year 2021 were not material .

[0000866374-21-000030:notes:340]
Customer related asset impairments for fiscal year 2020, primarily relate to non-cash impairments of certain property and equipment for customers we have disengaged or were in the process of disengaging, additional provision for doubtful accounts receivable, charges for other asset impairments, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand.

[0000866374-21-000030:notes:341]
Customer related asset impairments for fiscal year 2019, primarily relate to provision for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties and/or the Company is disengaging.

[0000866374-21-000030:notes:342]
(2)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis. During the first quarter of fiscal year 2021, the Company accrued for certain loss contingencies where losses are considered probable and estimable. In addition, the Company recorded a gain on the sale of real estate in the fourth quarter of fiscal year 2021 exited as a result of  the disengagement of a certain customer in fiscal year 2020.

[0000866374-21-000030:notes:343]
Legal and other during fiscal year 2020, primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India, offset by certain gains resulting from the recognition of prior year expenses paid to a government now considered probable of recovery and reasonably estimable due to a favorable tax ruling.

[0000866374-21-000030:notes:344]
Legal and other during fiscal year 2019, primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, Legal and other also includes certain charges related to the China based Multek operations that was divested in the second quarter of fiscal year 2019.

[0000866374-21-000030:notes:345]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-21-000030:notes:346]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled in the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segment nor reported by segment to the Company's CODM.

[0000866374-21-000030:notes:347]
Property and equipment on a segment basis is not disclosed as it is not separately identified and is not internally reported by segment to the Company's CODM as described above. During fiscal years 2021, 2020 and 2019, depreciation expense included in the segments' measure of operating performance above is as follows. Historical information has been recast to reflect realignment of customers and/or products between segments as well as the new operating segment and reportable segment structure:

[0000866374-21-000030:notes:348]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Depreciation expense: |  |  |  |  |  |
| Flex Agility Solutions | $ | 185 |  |  | $ | 218 |  |  | $ | 249 |  |
| Flex Reliability Solutions | 212 |  |  | 173 |  |  | 148 |  |
| Corporate and Other | 25 |  |  | 31 |  |  | 36 |  |
| Total depreciation expense | $ | 422 |  |  | $ | 422 |  |  | $ | 433 |  |

[0000866374-21-000030:notes:349]
Geographic information of net sales is as follows:

[0000866374-21-000030:notes:350]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 9,326 |  |  | 39 | % |  | $ | 9,362 |  |  | 39 | % |  | $ | 11,470 |  |  | 44 | % |
| Americas | 9,672 |  |  | 40 | % |  | 10,066 |  |  | 42 | % |  | 9,893 |  |  | 38 | % |
| Europe | 5,126 |  |  | 21 | % |  | 4,782 |  |  | 19 | % |  | 4,848 |  |  | 18 | % |
|  | $ | 24,124 |  |  |  |  | $ | 24,210 |  |  |  |  | $ | 26,211 |  |  |  |

[0000866374-21-000030:notes:351]
Revenues are attributable to the country in which the product is manufactured, or service is provided.

[0000866374-21-000030:notes:352]
During fiscal years 2021, 2020 and 2019, net sales generated from Singapore, the country of domicile, were approximately $507.0 million, $574.6 million and $642.7 million, respectively.

[0000866374-21-000030:notes:353]
The following table summarizes the countries that accounted for more than 10% of net sales in fiscal years 2021, 2020, and 2019:

[0000866374-21-000030:notes:354]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (In millions) |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 6,147 |  |  | 25 | % |  | $ | 5,665 |  |  | 23 | % |  | $ | 6,649 |  |  | 25 | % |
| Mexico | 4,413 |  |  | 18 | % |  | 4,449 |  |  | 18 | % |  | 4,539 |  |  | 17 | % |
| U.S. | 3,648 |  |  | 15 | % |  | 3,719 |  |  | 15 | % |  | 3,106 |  |  | 12 | % |

[0000866374-21-000030:notes:355]
No other country accounted for more than 10% of net sales for the fiscal periods presented in the table above.

[0000866374-21-000030:notes:356]
Geographic information of property and equipment, net is as follows:

[0000866374-21-000030:notes:357]
|  | As of March 31, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Americas | $ | 1,015 |  |  | 48 | % |  | $ | 1,037 |  |  | 47 | % |
| Asia | 627 |  |  | 30 | % |  | 738 |  |  | 33 | % |
| Europe | 455 |  |  | 22 | % |  | 441 |  |  | 20 | % |
|  | $ | 2,097 |  |  |  |  | $ | 2,216 |  |  |  |

[0000866374-21-000030:notes:358]
As of March 31, 2021 and 2020, property and equipment, net held in Singapore were approximately $5.9 million and $8.6 million, respectively.

[0000866374-21-000030:notes:359]
The following table summarizes the countries that accounted for more than 10% of property and equipment, net in fiscal year 2021 and 2020:

[0000866374-21-000030:notes:360]
|  | Fiscal Year Ended March 31, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 553 |  |  | 26 | % |  | $ | 555 |  |  | 25 | % |
| U.S. | 361 |  |  | 17 | % |  | 378 |  |  | 17 | % |
| China | 331 |  |  | 16 | % |  | 396 |  |  | 18 | % |

[0000866374-21-000030:notes:361]
No other country accounted for more than 10% of property and equipment, net for the fiscal periods presented in the table above.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-21-000030:notes:362]
Legal and other during fiscal year 2019, primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, Legal and other also includes certain charges related to the China based Multek operations that was divested in the second quarter of fiscal year 2019. 
During fiscal years 2021, 2020 and 2019, depreciation expense included in the segments' measure of operating performance above is as follows. Historical information has been recast to reflect realignment of customers and/or products between segments as well as the new operating segment and reportable segment structure:


## us-gaap:SubsequentEventsTextBlock

[0000866374-21-000030:notes:363]
SUBSEQUENT EVENTS
On April 28, 2021, the Company announced that it had confidentially submitted a draft registration statement on Form S-1 with the U.S. Securities and Exchange Commission relating to the proposed initial public offering of Nextracker's Class A common stock. The initial public offering and its timing are subject to market and other conditions and the SEC’s review process, and there can be no assurance that the Company will proceed with such offering or any alternative transaction. Refer to "Risk Factors - We are pursuing alternatives for our Nextracker business, including a full or partial separation of the business, through an initial public offering of Nextracker or otherwise, which may not be consummated as or when planned or at all, and may not achieve the intended benefits."

[0000866374-21-000030:notes:364]
This Annual Report on Form 10-K does not constitute an offer to sell or a solicitation of an offer to buy securities, and shall not constitute an offer, solicitation or sale in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of that jurisdiction.
