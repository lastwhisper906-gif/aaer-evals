# FLEX note change history — 0000866374-21-000043 → 0000866374-21-000062


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-10-29):
[0000866374-21-000062:note_history:1]
In connection with the matters described below, other than the Brazilian "Credit Habilitation" gain contingency, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.
  (was, 2021-07-30, similarity 0.9711):
[0000866374-21-000043:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- changed (2021-10-29):
[0000866374-21-000062:note_history:2]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.
  (was, 2021-07-30, similarity 0.9996):
[0000866374-21-000043:note_history:2]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

- added (2021-10-29):
[0000866374-21-000062:note_history:3]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff, National Elevator Industry Pension Fund, and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. On May 19, 2021, lead plaintiff filed its opening appeal brief, on July 19, 2021, defendants filed their answering brief, and on September 8, 2021, lead plaintiff filed its reply brief. The Court of Appeals has scheduled oral argument for December 8, 2021. The Company believes that the claims are without merit and intends to vigorously defend this case.

- added (2021-10-29):
[0000866374-21-000062:note_history:4]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously

- changed (2021-10-29):
[0000866374-21-000062:note_history:5]
shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.
  (was, 2021-07-30, similarity 0.745):
[0000866374-21-000043:note_history:5]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- changed (2021-10-29):
[0000866374-21-000062:note_history:6]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 373.7 million Brazilian reals (approximately USD $68.9 million based on the exchange rate as of October 1, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 60.6 million Brazilian reals or USD $11.2 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 33.9 million Brazilian reals (approximately USD $6.3 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.
  (was, 2021-07-30, similarity 0.9947):
[0000866374-21-000043:note_history:6]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 387.5 million Brazilian reals (approximately USD $77.2 million based on the exchange rate as of July 2, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 61.7 million Brazilian reals or USD $12.3 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 37.6 million Brazilian reals (approximately USD $7.5 million). The Company believes there is no legal basis for any of these assessments and that is has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

- changed (2021-10-29):
[0000866374-21-000062:note_history:7]
A different foreign Tax Authority had issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagreed with the Tax Authority’s assertion but agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount was accrued for during the fourth quarter of fiscal year 2021 and is expected to be paid during fiscal year 2022.
  (was, 2021-07-30, similarity 0.9842):
[0000866374-21-000043:note_history:7]
A different foreign Tax Authority had issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagreed with the Tax Authority’s assertion but agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount was accrued for during the fourth quarter of fiscal year 2021 and is expected to be paid during the first half of fiscal year 2022.

- changed (2021-10-29):
[0000866374-21-000062:note_history:8]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for "Credit Habilitation" with the tax authorities in June 2021 to request additional PIS/COFINS credit in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of the Company's
  (was, 2021-07-30, similarity 0.7243):
[0000866374-21-000043:note_history:8]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for Credit Habilitation with the tax authorities in June 2021 to request additional PIS/COFINS credit recovery in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of our credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remains uncertainty regarding the Company’s ability to recover these credits. The Company considers the recovery of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and has not recorded a gain for the recovery in the three-month period ended July 2, 2021 as it has not resolved all contingencies to conclude a realized or realizable amount. The amount and timing of recognition of the gain recovery is dependent upon the decision from the relevant tax authorities in regards to our application for Credit Habilitation and may have a material impact to our consolidated financial statements. We expect that this contingency could be resolved as early as the second quarter of fiscal year 2022. Additional taxes may also result from the credit recovery we receive subsequently.

- added (2021-10-29):
[0000866374-21-000062:note_history:9]
credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remained uncertainty regarding the Company’s ability to recognize these credits. The Company considered the recognition of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and did not record a gain for such credits in the three-month period ended July 2, 2021 as it had not resolved all contingencies to conclude a realized or realizable amount. In September 2021, the Credit Habilitation request was approved by the tax authorities and the Company recognized a gain of 809.6 million Brazilian reals (approximately USD $149.3 million based on the exchange rate as of October 1, 2021) included in interest and other, net in the condensed consolidated statements of operations for the three and six-month periods ended October 1, 2021. The total gain recorded included credits from February 2003 to September 2021, net of additional taxes, as the Credit Habilitation received covering the period from February 2003 to December 2019 resolved any uncertainty regarding the Company's ability to claim such credits. This gain is non-cash and can only be used to offset certain current and future tax obligations. Out of the $149.3 million, $50.6 million was included in other current assets and $98.7 million was included in other assets in the condensed consolidated balance sheet as of October 1, 2021 as we expect to utilize these credits in the next two to three years.

- removed (2021-10-29):
[0000866374-21-000043:note_history:10]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. On May 19, 2021, lead plaintiff filed its opening appeal brief, and on July 19, 2021, defendants filed their answering brief. Lead plaintiff’s reply brief is due September 8, 2021. The Company believes that the claims are without merit and intends to vigorously defend this case.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-10-29):
[0000866374-21-000062:note_history:11]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In order to drive efficiency and productivity, the Company is organized around two focused and complementary delivery models, which also represent its operating and reportable segments:
  (was, 2021-07-30, similarity 0.8989):
[0000866374-21-000043:note_history:11]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In order to drive efficiency and productivity the Company is organized around two focused and complementary delivery models, which also represent its operating and reportable segments:

- added (2021-10-29):
[0000866374-21-000062:note_history:12]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2021 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended October 1, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation. Beginning in the second quarter of fiscal year 2022, the Company elected to include operating income as a subtotal in the condensed consolidated statements of operations. In addition, deferred revenue and customer working capital advances, previously included within other current liabilities, have been separately presented as deferred revenue and customer working capital advances in the current liabilities section of the condensed consolidated balance sheets. Further, certain unbilled receivables previously presented as part of accounts receivable, net of allowance for doubtful accounts are now being presented as contract assets on the condensed consolidated balance sheets as billing is to occur subsequent to revenue recognition and is conditional upon other than the passage of time. The Company reclassified $146.8 million of unbilled receivables from account receivable, net of allowance for doubtful accounts to contract assets for the period ended March 31, 2021 in order to align with the current year presentation. These presentation changes were applied to all periods presented in the condensed consolidated statements of operations and balance sheets. The foregoing changes in presentation had no impact on the Company's results of operations or cash flows.

- changed (2021-10-29):
[0000866374-21-000062:note_history:13]
The first quarters for fiscal years 2022 and 2021 ended on July 2, 2021, which is comprised of 93 days in the period, and June 26, 2020, which is comprised of 87 days in the period, respectively. The second quarters for fiscal years 2022 and 2021 ended on October 1, 2021 and September 25, 2020, which are comprised of 91 days in both periods.
  (was, 2021-07-30, similarity 0.7288):
[0000866374-21-000043:note_history:13]
The first quarters for fiscal years 2022 and 2021 ended on July 2, 2021, which is comprised of 93 days in the period, and June 26, 2020, which is comprised of 87 days in the period, respectively.

- changed (2021-10-29):
[0000866374-21-000062:note_history:14]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.
  (was, 2021-07-30, similarity 0.9905):
[0000866374-21-000043:note_history:14]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.

- added (2021-10-29):
[0000866374-21-000062:note_history:15]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

- changed (2021-10-29):
[0000866374-21-000062:note_history:16]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.
  (was, 2021-07-30, similarity 0.9916):
[0000866374-21-000043:note_history:16]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.

- added (2021-10-29):
[0000866374-21-000062:note_history:17]
Recently Issued Accounting Pronouncements

- added (2021-10-29):
[0000866374-21-000062:note_history:18]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2023.

- removed (2021-10-29):
[0000866374-21-000043:note_history:19]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2021 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended July 2, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022. Beginning in the second quarter of fiscal year 2021, the Company began reporting all dollar amounts in millions. In certain circumstances, this change in rounding resulted in line items being removed within prior year disclosures. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

- removed (2021-10-29):
[0000866374-21-000043:note_history:20]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force," which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-10-29):
[0000866374-21-000062:note_history:21]
|  | As of October 1, 2021 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 529 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 300 |  |  | 300 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 665 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 692 |  |  | 753 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 660 |  |  | 762 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 692 |  |  | 801 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 166 |  |  | 166 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| India Facilities | 126 |  |  | 126 |  |  | 133 |  |  | 133 |  |  | Level 2 |
  (was, 2021-07-30, similarity 0.9926):
[0000866374-21-000043:note_history:21]
|  | As of July 2, 2021 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 534 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 302 |  |  | 302 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 669 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 693 |  |  | 758 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 660 |  |  | 764 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 693 |  |  | 806 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 170 |  |  | 170 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| India Facilities | 133 |  |  | 133 |  |  | 133 |  |  | 133 |  |  | Level 2 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-10-29):
[0000866374-21-000062:note_history:22]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended October 1, 2021 and September 25, 2020, respectively.
  (was, 2021-07-30, similarity 0.9257):
[0000866374-21-000043:note_history:22]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended July 2, 2021 and June 26, 2020, respectively.

- added (2021-10-29):
[0000866374-21-000062:note_history:23]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,250 |  |  | $ | 2,823 |  |  | $ | 6,498 |  |  | $ | 5,269 |  |
| Over time | 187 |  |  | 495 |  |  | 371 |  |  | 961 |  |
| Total | 3,437 |  |  | 3,318 |  |  | 6,869 |  |  | 6,230 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,308 |  |  | 1,779 |  |  | 4,711 |  |  | 3,103 |  |
| Over time | 484 |  |  | 888 |  |  | 991 |  |  | 1,805 |  |
| Total | 2,792 |  |  | 2,667 |  |  | 5,702 |  |  | 4,908 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,558 |  |  | 4,602 |  |  | 11,209 |  |  | 8,372 |  |
| Over time | 671 |  |  | 1,383 |  |  | 1,362 |  |  | 2,766 |  |
| Total | $ | 6,229 |  |  | $ | 5,985 |  |  | $ | 12,571 |  |  | $ | 11,138 |  |

- removed (2021-10-29):
[0000866374-21-000043:note_history:24]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
| Timing of Transfer | (In millions) |  |  |  |  |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,248 |  |  | $ | 2,446 |  |  |  |  |  |
| Over time | 184 |  |  | 466 |  |  |  |  |  |
| Total | 3,432 |  |  | 2,912 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,403 |  |  | 1,323 |  |  |  |  |  |
| Over time | 507 |  |  | 918 |  |  |  |  |  |
| Total | 2,910 |  |  | 2,241 |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,651 |  |  | 3,769 |  |  |  |  |  |
| Over time | 691 |  |  | 1,384 |  |  |  |  |  |
| Total | $ | 6,342 |  |  | $ | 5,153 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-10-29):
[0000866374-21-000062:note_history:25]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and

- changed (2021-10-29):
[0000866374-21-000062:note_history:26]
can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.
  (was, 2021-07-30, similarity 0.8231):
[0000866374-21-000043:note_history:26]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

- changed (2021-10-29):
[0000866374-21-000062:note_history:27]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.
  (was, 2021-07-30, similarity 0.8311):
[0000866374-21-000043:note_history:27]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result,

- changed (2021-10-29):
[0000866374-21-000062:note_history:28]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet.
  (was, 2021-07-30, similarity 0.9789):
[0000866374-21-000043:note_history:28]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

- changed (2021-10-29):
[0000866374-21-000062:note_history:29]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed
  (was, 2021-07-30, similarity 0.6914):
[0000866374-21-000043:note_history:29]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

- added (2021-10-29):
[0000866374-21-000062:note_history:30]
as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

- added (2021-10-29):
[0000866374-21-000062:note_history:31]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $545.4 million and $435.4 million as of October 1, 2021 and March 31, 2021, respectively, of which $480.1 million and $376.5 million, respectively, is included in deferred revenue and customer working capital advances.

- changed (2021-10-29):
[0000866374-21-000062:note_history:32]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended October 1, 2021 and September 25, 2020, respectively.
  (was, 2021-07-30, similarity 0.9257):
[0000866374-21-000043:note_history:32]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended July 2, 2021 and June 26, 2020, respectively.

- added (2021-10-29):
[0000866374-21-000062:note_history:33]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,250 |  |  | $ | 2,823 |  |  | $ | 6,498 |  |  | $ | 5,269 |  |
| Over time | 187 |  |  | 495 |  |  | 371 |  |  | 961 |  |
| Total | 3,437 |  |  | 3,318 |  |  | 6,869 |  |  | 6,230 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,308 |  |  | 1,779 |  |  | 4,711 |  |  | 3,103 |  |
| Over time | 484 |  |  | 888 |  |  | 991 |  |  | 1,805 |  |
| Total | 2,792 |  |  | 2,667 |  |  | 5,702 |  |  | 4,908 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,558 |  |  | 4,602 |  |  | 11,209 |  |  | 8,372 |  |
| Over time | 671 |  |  | 1,383 |  |  | 1,362 |  |  | 2,766 |  |
| Total | $ | 6,229 |  |  | $ | 5,985 |  |  | $ | 12,571 |  |  | $ | 11,138 |  |

- removed (2021-10-29):
[0000866374-21-000043:note_history:34]
revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- removed (2021-10-29):
[0000866374-21-000043:note_history:35]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $489.9 million and $435.4 million as of July 2, 2021 and March 31, 2021, respectively, of which $425.2 million and $376.5 million, respectively, is included in other current liabilities.

- removed (2021-10-29):
[0000866374-21-000043:note_history:36]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
| Timing of Transfer | (In millions) |  |  |  |  |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,248 |  |  | $ | 2,446 |  |  |  |  |  |
| Over time | 184 |  |  | 466 |  |  |  |  |  |
| Total | 3,432 |  |  | 2,912 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,403 |  |  | 1,323 |  |  |  |  |  |
| Over time | 507 |  |  | 918 |  |  |  |  |  |
| Total | 2,910 |  |  | 2,241 |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,651 |  |  | 3,769 |  |  |  |  |  |
| Over time | 691 |  |  | 1,384 |  |  |  |  |  |
| Total | $ | 6,342 |  |  | $ | 5,153 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-10-29):
[0000866374-21-000062:note_history:37]
SUBSEQUENT EVENTSIn October 2021, the Company announced that it has entered into a definitive agreement to acquire 100% of the voting shares of Anord Mardix, a global leader in critical power solutions for $540 million in an all-cash transaction. The acquisition will add to the Company' portfolio of Power products and expand its offering in the data center market and is expected to close in the third quarter of fiscal year 2022, subject to customary closing conditions, including regulatory approval. For reporting purposes, Anord Mardix will be included in the Industrial business unit within the FRS segment.
