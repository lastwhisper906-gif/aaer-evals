# FLEX MD&A — 0000866374-21-000062


## mdna

[0000866374-21-000062:mdna:1]
[same as prior period, unchanged from 0000866374-21-000043:mdna:1]

[0000866374-21-000062:mdna:2]
[same as prior period, unchanged from 0000866374-21-000043:mdna:2]

[0000866374-21-000062:mdna:3]
25

[0000866374-21-000062:mdna:4]
forward-looking statements are subject to risks and uncertainties, including, without limitation, those risks and uncertainties discussed in this section, as well as any risks and uncertainties discussed in Part II, Item 1A, “Risk Factors” of this report on Form 10-Q, and in Part I, Item 1A, “Risk Factors” and in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021. In addition, new risks emerge from time to time and it is not possible for management to predict all such risk factors or to assess the impact of such risk factors on our business. Accordingly, our future results may differ materially from historical results or from those discussed or implied by these forward-looking statements. Given these risks and uncertainties, the reader should not place undue reliance on these forward-looking statements.

[0000866374-21-000062:mdna:5]
[same as prior period, unchanged from 0000866374-21-000043:mdna:4]

[0000866374-21-000062:mdna:6]
[same as prior period, unchanged from 0000866374-21-000043:mdna:5]

[0000866374-21-000062:mdna:7]
[same as prior period, unchanged from 0000866374-21-000043:mdna:6]

[0000866374-21-000062:mdna:8]
[same as prior period, unchanged from 0000866374-21-000043:mdna:7]

[0000866374-21-000062:mdna:9]
[same as prior period, unchanged from 0000866374-21-000043:mdna:8]

[0000866374-21-000062:mdna:10]
[same as prior period, unchanged from 0000866374-21-000043:mdna:9]

[0000866374-21-000062:mdna:11]
[same as prior period, unchanged from 0000866374-21-000043:mdna:10]

[0000866374-21-000062:mdna:12]
[same as prior period, unchanged from 0000866374-21-000043:mdna:11]

[0000866374-21-000062:mdna:13]
[same as prior period, unchanged from 0000866374-21-000043:mdna:12]

[0000866374-21-000062:mdna:14]
[same as prior period, unchanged from 0000866374-21-000043:mdna:13]

[0000866374-21-000062:mdna:15]
[same as prior period, unchanged from 0000866374-21-000043:mdna:14]

[0000866374-21-000062:mdna:16]
[same as prior period, unchanged from 0000866374-21-000043:mdna:15]

[0000866374-21-000062:mdna:17]
[same as prior period, unchanged from 0000866374-21-000043:mdna:16]

[0000866374-21-000062:mdna:18]
[same as prior period, unchanged from 0000866374-21-000043:mdna:17]

[0000866374-21-000062:mdna:19]
[same as prior period, unchanged from 0000866374-21-000043:mdna:18]

[0000866374-21-000062:mdna:20]
With the second wave of the pandemic including follow-on variants of COVID-19, we continue to experience plant closures and/or restrictions at certain manufacturing facilities in Malaysia. There have been renewed disease control measures being taken to limit the spread including movement bans and shelter-in-place orders. We continue to closely monitor the situation in all the locations where we operate. Our priority remains the welfare of our employees. In addition, our end markets continue to be impacted by the global supply chain disruptions. Component shortages and logistical constraints are pervasive across the entire value chain. COVID-19 related restrictions also contributed to a declining workforce, including at ports and warehouses, as well as creating driver shortages around the world. We expect persistent waves of COVID-19 to remain a headwind into the

[0000866374-21-000062:mdna:21]
[same as prior period, unchanged from 0000866374-21-000043:mdna:52]

[0000866374-21-000062:mdna:22]
near future. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future as we are continuing to see increasing supply constraints and costs. Refer to “Risk Factors - The ongoing COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material.” as disclosed in Part II, “Item 1A. Risk Factors.”

[0000866374-21-000062:mdna:23]
[same as prior period, unchanged from 0000866374-21-000043:mdna:20]

[0000866374-21-000062:mdna:24]
[same as prior period, unchanged from 0000866374-21-000043:mdna:22]

[0000866374-21-000062:mdna:25]
[same as prior period, unchanged from 0000866374-21-000043:mdna:23]

[0000866374-21-000062:mdna:26]
This Quarterly Report on Form 10-Q for the second quarter ended October 1, 2021 does not constitute an offer to sell or a solicitation of an offer to buy securities, and shall not constitute an offer, solicitation or sale in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of that jurisdiction.

[0000866374-21-000062:mdna:27]
Subsequent Events

[0000866374-21-000062:mdna:28]
In October 2021, we announced that we have entered into a definitive agreement to acquire 100% of the voting shares of Anord Mardix, a global leader in critical power solutions for $540 million in an all-cash transaction. The acquisition will add to our portfolio of Power products and expand our offering in the data center market and is expected to close in the third quarter of fiscal year 2022, subject to customary closing conditions, including regulatory approval. For reporting purposes, Anord Mardix will be included in the Industrial business unit within our FRS segment.

[0000866374-21-000062:mdna:29]
[same as prior period, unchanged from 0000866374-21-000043:mdna:62]

[0000866374-21-000062:mdna:30]
[same as prior period, unchanged from 0000866374-21-000043:mdna:26]

[0000866374-21-000062:mdna:31]
We are one of the world's largest providers of global supply chain solutions, with revenues of $12.6 billion for the six-month period ended October 1, 2021 and $24.1 billion in fiscal year 2021. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-21-000062:mdna:32]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 2,605 |  |  | 42 | % |  | $ | 2,453 |  |  | 41 | % |  | $ | 5,184 |  |  | 41 | % |  | $ | 4,557 |  |  | 41 | % |
| Asia | 2,347 |  |  | 38 | % |  | 2,277 |  |  | 38 | % |  | 4,712 |  |  | 37 | % |  | 4,290 |  |  | 39 | % |
| Europe | 1,277 |  |  | 20 | % |  | 1,255 |  |  | 21 | % |  | 2,675 |  |  | 22 | % |  | 2,291 |  |  | 20 | % |
|  | $ | 6,229 |  |  |  |  | $ | 5,985 |  |  |  |  | $ | 12,571 |  |  |  |  | $ | 11,138 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 1,547 |  |  | 25 | % |  | $ | 1,493 |  |  | 25 | % |  | $ | 3,078 |  |  | 24 | % |  | $ | 2,910 |  |  | 26 | % |
| Mexico | 1,240 |  |  | 20 | % |  | 1,153 |  |  | 19 | % |  | 2,460 |  |  | 20 | % |  | 2,060 |  |  | 18 | % |
| U.S. | 846 |  |  | 14 | % |  | 895 |  |  | 15 | % |  | 1,722 |  |  | 14 | % |  | 1,764 |  |  | 16 | % |
| Brazil | 502 |  |  | 8 | % |  | 389 |  |  | 6 | % |  | 966 |  |  | 8 | % |  | 711 |  |  | 6 | % |
| Malaysia | 412 |  |  | 7 | % |  | 433 |  |  | 7 | % |  | 823 |  |  | 7 | % |  | 732 |  |  | 7 | % |
| Hungary | 295 |  |  | 5 | % |  | 307 |  |  | 5 | % |  | 647 |  |  | 5 | % |  | 557 |  |  | 5 | % |
| Other | 1,387 |  |  | 21 | % |  | 1,315 |  |  | 23 | % |  | 2,875 |  |  | 22 | % |  | 2,404 |  |  | 22 | % |
|  | $ | 6,229 |  |  |  |  | $ | 5,985 |  |  |  |  | $ | 12,571 |  |  |  |  | $ | 11,138 |  |  |  |

[0000866374-21-000062:mdna:33]
|  | As of |  | As of |
| Property and equipment, net: | October 1, 2021 |  | March 31, 2021 |
|  | (In millions) |
| Mexico | $ | 574 |  |  | 27 | % |  | $ | 553 |  |  | 26 | % |
| U.S. | 362 |  |  | 17 | % |  | 361 |  |  | 17 | % |
| China | 316 |  |  | 15 | % |  | 331 |  |  | 16 | % |
| India | 144 |  |  | 7 | % |  | 166 |  |  | 8 | % |
| Hungary | 112 |  |  | 5 | % |  | 105 |  |  | 5 | % |
| Malaysia | 108 |  |  | 5 | % |  | 106 |  |  | 5 | % |
| Other | 484 |  |  | 24 | % |  | 475 |  |  | 23 | % |
|  | $ | 2,100 |  |  |  |  | $ | 2,097 |  |  |  |

[0000866374-21-000062:mdna:34]
[same as prior period, unchanged from 0000866374-21-000043:mdna:30]

[0000866374-21-000062:mdna:35]
[same as prior period, unchanged from 0000866374-21-000043:mdna:31]

[0000866374-21-000062:mdna:36]
[same as prior period, unchanged from 0000866374-21-000043:mdna:32]

[0000866374-21-000062:mdna:37]
[same as prior period, unchanged from 0000866374-21-000043:mdna:33]

[0000866374-21-000062:mdna:38]
[same as prior period, unchanged from 0000866374-21-000043:mdna:34]

[0000866374-21-000062:mdna:39]
[same as prior period, unchanged from 0000866374-21-000043:mdna:35]

[0000866374-21-000062:mdna:40]
[same as prior period, unchanged from 0000866374-21-000043:mdna:36]

[0000866374-21-000062:mdna:41]
[same as prior period, unchanged from 0000866374-21-000043:mdna:37]

[0000866374-21-000062:mdna:42]
[same as prior period, unchanged from 0000866374-21-000043:mdna:38]

[0000866374-21-000062:mdna:43]
[same as prior period, unchanged from 0000866374-21-000043:mdna:39]

[0000866374-21-000062:mdna:44]
[same as prior period, unchanged from 0000866374-21-000043:mdna:40]

[0000866374-21-000062:mdna:45]
[same as prior period, unchanged from 0000866374-21-000043:mdna:41]

[0000866374-21-000062:mdna:46]
[same as prior period, unchanged from 0000866374-21-000043:mdna:42]

[0000866374-21-000062:mdna:47]
[same as prior period, unchanged from 0000866374-21-000043:mdna:43]

[0000866374-21-000062:mdna:48]
[same as prior period, unchanged from 0000866374-21-000043:mdna:44]

[0000866374-21-000062:mdna:49]
[same as prior period, unchanged from 0000866374-21-000043:mdna:45]

[0000866374-21-000062:mdna:50]
[same as prior period, unchanged from 0000866374-21-000043:mdna:46]

[0000866374-21-000062:mdna:51]
[same as prior period, unchanged from 0000866374-21-000043:mdna:47]

[0000866374-21-000062:mdna:52]
[same as prior period, unchanged from 0000866374-21-000043:mdna:48]

[0000866374-21-000062:mdna:53]
[same as prior period, unchanged from 0000866374-21-000043:mdna:49]

[0000866374-21-000062:mdna:54]
[same as prior period, unchanged from 0000866374-21-000043:mdna:50]

[0000866374-21-000062:mdna:55]
[same as prior period, unchanged from 0000866374-21-000043:mdna:51]

[0000866374-21-000062:mdna:56]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 92.4 |  |  | 93.0 |  |  | 92.5 |  |  | 93.4 |  |
| Restructuring charges | 0.1 |  |  | 0.4 |  |  | 0.1 |  |  | 0.3 |  |
| Gross profit | 7.5 |  |  | 6.6 |  |  | 7.4 |  |  | 6.3 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.2 |  |  | 3.3 |  |  | 3.4 |  |
| Restructuring charges | 0.0 |  |  | 0.2 |  |  | 0.0 |  |  | 0.1 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.2 |  |  | 0.3 |  |
| Operating income | 3.8 |  |  | 2.9 |  |  | 3.9 |  |  | 2.5 |  |
| Interest and other, net | (2.2) |  |  | 0.4 |  |  | (0.9) |  |  | 0.5 |  |
| Income before income taxes | 6.0 |  |  | 2.5 |  |  | 4.8 |  |  | 2.0 |  |
| Provision for income taxes | 0.6 |  |  | 0.7 |  |  | 0.5 |  |  | 0.5 |  |
| Net income | 5.4 | % |  | 1.8 | % |  | 4.3 | % |  | 1.5 | % |

[0000866374-21-000062:mdna:57]
[same as prior period, unchanged from 0000866374-21-000043:mdna:54]

[0000866374-21-000062:mdna:58]
[same as prior period, unchanged from 0000866374-21-000043:mdna:55]

[0000866374-21-000062:mdna:59]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,437 |  |  | 55 | % |  | $ | 3,318 |  |  | 55 | % |  | $ | 6,869 |  |  | 55 | % |  | $ | 6,230 |  |  | 56 | % |
| Flex Reliability Solutions | 2,792 |  |  | 45 | % |  | 2,667 |  |  | 45 | % |  | 5,702 |  |  | 45 | % |  | 4,908 |  |  | 44 | % |
|  | $ | 6,229 |  |  |  |  | $ | 5,985 |  |  |  |  | $ | 12,571 |  |  |  |  | $ | 11,138 |  |  |  |

[0000866374-21-000062:mdna:60]
Net sales during the three-month period ended October 1, 2021 totaled $6.2 billion, representing an increase of approximately $0.2 billion, or 4% from $6.0 billion during the three-month period ended September 25, 2020. Net sales for our FAS segment increased $0.1 billion, or 4% from the three-month period ended September 25, 2020, primarily driven by an increase in our Lifestyle business due to strong demand, particularly with new product ramps and new customers. Offsetting the increase to some extent were impacts from COVID-19 outlined above and specifically related to scarcity of component and raw materials and logistics constraints. Net sales for our FRS segment increased approximately $0.1 billion, or 5% from the three-month period ended September 25, 2020, primarily driven by our Industrial business led by customer ramps and strong demand in key areas including electric vehicles (EV) charging and renewables, semicap, and robotics. The increases noted in FRS during the three-month period ended October 1, 2021 were partially offset by a decrease in our Health Solutions business primarily due to lower COVID-19 related demand compared to prior year period coupled with component shortages as well as clear-to-build constraints. Net sales increased across all regions with a $0.2 billion increase to $2.6 billion in the Americas, a $0.1 billion increase to $2.3 billion in Asia and a modest $22 million increase to $1.3 billion in Europe.

[0000866374-21-000062:mdna:61]
Net sales during the six-month period ended October 1, 2021 totaled $12.6 billion, representing an increase of approximately $1.4 billion, or 13% from $11.1 billion during the six-month period ended September 25, 2020. Net sales for our FAS segment increased $0.6 billion, or 10% from the six-month period ended September 25, 2020, primarily driven by an increase in our Lifestyle business and to a lesser extent increase in our Consumer Devices business. These increases were driven by a lesser impact from COVID-19 production pressure during the current year, coupled with new ramps, customer expansions and continued recoveries in consumer spending, offset to some extent by the scarcity of components and raw material and logistics constraints noted above. Net sales for our FRS segment increased approximately $0.8 billion, or 16% from the six-month period ended September 25, 2020, primarily due to an increase in our Industrial business, as a result of customer ramps and strong demand in EV charging and renewables, semicap, and robotics. In addition, net sale for our Automotive business increased due to depressed automotive sales from factory shutdowns in the first quarter of fiscal year 2021. The increase in our Automotive business was partially constrained by component shortages and OEM plant shutdowns during the six-month period ended October 1, 2021. Net sales increased across all regions with a $0.6 billion increase to $5.2 billion in the Americas, a $0.4 billion increase to $4.7 billion in Asia, and a $0.4 billion increase to $2.7 billion in Europe.

[0000866374-21-000062:mdna:62]
[same as prior period, unchanged from 0000866374-21-000043:mdna:93]

[0000866374-21-000062:mdna:63]
Our ten largest customers during the three and six-month periods ended October 1, 2021 accounted for approximately 36% and 35% of net sales, respectively. Our ten largest customers, during the three and six-month periods ended September 25, 2020, accounted for approximately 39% and 38% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and six-month periods ended October 1, 2021 or September 25, 2020.

[0000866374-21-000062:mdna:64]
[same as prior period, unchanged from 0000866374-21-000043:mdna:59]

[0000866374-21-000062:mdna:65]
[same as prior period, unchanged from 0000866374-21-000043:mdna:60]

[0000866374-21-000062:mdna:66]
Cost of sales during the three-month period ended October 1, 2021 totaled $5.8 billion, representing an increase of approximately $0.2 billion, or 3% from $5.6 billion during the three-month period ended September 25, 2020. The increase in cost of sales for the three-month period ended October 1, 2021 was primarily driven by the increased consolidated sales of over $0.2 billion. Cost of sales in FAS for the three-month period ended October 1, 2021 increased approximately 2%, or $50 million from the three-month period ended September 25, 2020, which is slightly lower than the overall 4% increase in FAS revenue during the same period primarily as a result of higher revenue in our Lifestyle and Consumer Devices businesses coupled with better fixed cost absorption, disciplined cost management as well as our continued push for new business wins and renewals at accretive margins. Cost of sales in FRS for the three-month period ended October 1, 2021 increased 6%, or $0.1 billion from the three-month period ended September 25, 2020, which is slightly higher than the overall 5% increase in FRS revenue during the same period primarily due to material constraints causing numerous production disruptions impacting our automotive business and continued increases in freight and logistics costs impacting our industrial businesses despite stronger demand and lesser COVID-19 pressures during the first half of fiscal year 2022, as discussed above.

[0000866374-21-000062:mdna:67]
Cost of sales during the six-month period ended October 1, 2021 totaled $11.6 billion, representing an increase of approximately $1.2 billion, or 12% from $10.4 billion during the six-month period ended September 25, 2020. The increase in cost of sales for the six-month period ended October 1, 2021 was primarily driven by the increased consolidated sales of over $1.4 billion during the same period. Cost of sales in FAS for the six-month period ended October 1, 2021 increased approximately 8%, or $0.5 billion from the six-month period ended September 25, 2020, which is lower than the overall 10% increase in FAS revenue during the same period primarily due to the same reasons as discussed above in the three-month period ended comparison. Cost of sales in FRS for the six-month period ended October 1, 2021 increased 17%, or $0.7 billion from the six-month period ended September 25, 2020, which is slightly higher than the overall 16% increase in FRS revenue during the same period due to the same reasons as discussed above in the three-month period ended comparison.

[0000866374-21-000062:mdna:68]
[same as prior period, unchanged from 0000866374-21-000043:mdna:64]

[0000866374-21-000062:mdna:69]
[same as prior period, unchanged from 0000866374-21-000043:mdna:65]

[0000866374-21-000062:mdna:70]
Gross profit during the three-month period ended October 1, 2021 increased $0.1 billion to $0.5 billion, or 7.5% of net sales, from $0.4 billion, or 6.6% of net sales, during the three-month period ended September 25, 2020. Gross margin improved 90 basis points during the same period despite certain COVID-19 disruptions, industry-wide component shortages and cost pressures on logistics in the three-month period ended October 1, 2021. The increase in gross profit and gross margin during the current period resulted primarily from the overall stronger demand in our FAS segment which allowed for improved fixed cost absorption, coupled with continued improvement in the mix of our business, benefits from prior restructuring activities and a lower direct and incremental unfavorable impact from COVID-19 compared to the prior year period.

[0000866374-21-000062:mdna:71]
Gross profit during the six-month period ended October 1, 2021 increased $0.2 billion to $0.9 billion, or 7.4% of net sales, from $0.7 billion, or 6.3% of net sales, during the six-month period ended September 25, 2020. Gross margin improved 110 basis points during the same period due to the same factors noted above in the three-month periods discussion.

[0000866374-21-000062:mdna:72]
[same as prior period, unchanged from 0000866374-21-000043:mdna:67]

[0000866374-21-000062:mdna:73]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, and legal and other. A portion of depreciation is

[0000866374-21-000062:mdna:74]
allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-21-000062:mdna:75]
[same as prior period, unchanged from 0000866374-21-000043:mdna:69]

[0000866374-21-000062:mdna:76]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 153 |  |  | 4.4 | % |  | $ | 88 |  |  | 2.7 | % |  | $ | 290 |  |  | 4.2 | % |  | $ | 160 |  |  | 2.6 | % |
| Flex Reliability Solutions | 151 |  |  | 5.4 | % |  | 179 |  |  | 6.7 | % |  | 321 |  |  | 5.6 | % |  | 294 |  |  | 6.0 | % |

[0000866374-21-000062:mdna:77]
FAS segment margin increased 170 basis points, to 4.4% for the three-month period ended October 1, 2021, from 2.7% for the three-month period ended September 25, 2020. The margin increase was driven by an increase in demand notably in our Lifestyle and Consumer Devices end markets due to new business wins and renewals at accretive margins, strong demand recovery from COVID-19, disciplined cost management and improved efficiencies as noted above, partially offset by the elevated costs due to component shortages and logistics constraints we faced during the three-month period ended October 1, 2021. The FAS segment margin increased 160 basis points, to 4.2% for the six-month period ended October 1, 2021, from 2.6% for the six-month period ended September 25, 2020. The increase in FAS segment margin during the six-month period is due to the same factors noted in the discussion above for the three-month period.

[0000866374-21-000062:mdna:78]
FRS segment margin decreased 130 basis points, to 5.4% for the three-month period ended October 1, 2021, from 6.7% for the three-month period ended September 25, 2020. The margin decrease in FRS was primarily driven by production disruptions in our Automotive business, as well as continued freight and logistics cost headwinds impacting our Industrial business during the three-month period ended October 1, 2021. FRS segment margin decreased 40 basis points, to 5.6% for the six-month period ended October 1, 2021, from 6.0% for the six-month period ended September 25, 2020. The decrease in FRS segment margin during the six-month period is due to the same factors noted in the discussion above for the three-month period.

[0000866374-21-000062:mdna:79]
Restructuring charges

[0000866374-21-000062:mdna:80]
During the three and six-month periods ended October 1, 2021, we recognized approximately $9 million of restructuring charges, primarily cash charges related to employee severance. During the three and six-month periods ended September 25, 2020, we recognized approximately $35 million and $45 million, respectively, of restructuring charges, primarily cash charges related to employee severance.

[0000866374-21-000062:mdna:81]
[same as prior period, unchanged from 0000866374-21-000043:mdna:73]

[0000866374-21-000062:mdna:82]
Selling, general and administrative expenses (“SG&A”) was $0.2 billion, or 3.4% of net sales, during the three-month period ended October 1, 2021, increasing $20 million from $0.2 billion, or 3.2% of net sales, during the three-month period ended September 25, 2020. SG&A was $0.4 billion, or 3.3% of net sales, during the six-month period ended October 1, 2021, increasing $30 million from $0.4 billion, or 3.4% of net sales, during the six-month period ended September 25, 2020, which reflects our enhanced cost control efforts to support higher revenue growth while keeping our SG&A expenses relatively flat.

[0000866374-21-000062:mdna:83]
[same as prior period, unchanged from 0000866374-21-000043:mdna:75]

[0000866374-21-000062:mdna:84]
Amortization of intangible assets marginally declined to $15 million during the three-month period ended October 1, 2021, from $16 million for the three-month period ended September 25, 2020, and declined to $30 million during the six-month period ended October 1, 2021, from $31 million for the six-month period ended September 25, 2020, primarily due to certain intangibles now being fully amortized.

[0000866374-21-000062:mdna:85]
[same as prior period, unchanged from 0000866374-21-000043:mdna:77]

[0000866374-21-000062:mdna:86]
Interest and other, net was income of $134 million during the three-month period ended October 1, 2021 compared to an expense of $22 million during the three-month period ended September 25, 2020, primarily driven by a $149 million gain related to a certain tax credit recorded upon approval of a "Credit Habilitation" request by the relevant Brazil tax authorities. This is a non-cash gain which will be used to offset certain current and future tax obligations. Refer to note 11 to the condensed consolidated financial statements for further detail.

[0000866374-21-000062:mdna:87]
Interest and other, net was income of $111 million during the six-month period ended October 1, 2021 compared to an expense of $51 million during the six-month period ended September 25, 2020, due to the same driver noted above.

[0000866374-21-000062:mdna:88]
[same as prior period, unchanged from 0000866374-21-000043:mdna:79]

[0000866374-21-000062:mdna:89]
[same as prior period, unchanged from 0000866374-21-000043:mdna:80]

[0000866374-21-000062:mdna:90]
The consolidated effective tax rate was 9% and 10% for the three and six-month periods ended October 1, 2021, and 26% and 25% for the three and six-month periods ended September 25, 2020, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, the Netherlands and Israel. The effective tax rate for the three and six-month periods ended October 1, 2021 is lower than the effective tax rate for the three-month and six-month periods ended September 25, 2020, primarily due to a changing jurisdictional mix of incomes, restructuring charges for the three-month and six-month periods ended September 25, 2020 which resulted in minimal tax benefit, and the significant Brazilian indirect tax credits recorded this period (as discussed above in note 11 to the condensed consolidated financial statements) which resulted in immaterial additional income tax cost.

[0000866374-21-000062:mdna:91]
[same as prior period, unchanged from 0000866374-21-000043:mdna:82]

[0000866374-21-000062:mdna:92]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of October 1, 2021, we had cash and cash equivalents of approximately $2.5 billion and bank and other borrowings of approximately $3.8 billion. We have a $2.0 billion revolving credit facility that is due to mature in January 2026 (the "2026 Credit Facility"), under which we had no borrowings outstanding as of October 1, 2021. As of October 1, 2021, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-21-000062:mdna:93]
Cash provided by operating activities was $0.5 billion during the six-month period ended October 1, 2021, primarily driven by $0.5 billion of net income for the period plus $0.3 billion of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation offset by changes in net working capital as discussed below.

[0000866374-21-000062:mdna:94]
We believe net working capital ("NWC") and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, plus inventories and contract assets, less accounts payable. Net working capital increased $0.3 billion to $3.2 billion as of October 1, 2021, from $2.9 billion as of March 31, 2021. This increase is primarily driven by a $1.3 billion increase in inventories due to component shortages and logistics constraints driving up buffer stock and inventory pricing, partially offset by a $0.5 billion decrease in net receivables and a $0.6 billion increase in accounts payable. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended October 1, 2021, increased to 13.0% from 11.5% of annualized net sales for the quarter ended March 31, 2021 due to component shortages and logistics constraints. We continue to see component shortages in the supply chain and logistical constraints, and although we are actively managing these impacts, we expect continued working capital pressure in the near future. We expect it will take additional time to adequately drive down our inventory levels to align with the current demand environment. We are proactively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative resetting our load planning. In addition, we are pursuing alternative resources using inclusive hybrid solutions to minimize transit times and implementing operational efficiencies. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future as we are continuing to see increasing supply constraints and costs. We are working diligently with our partners to secure needed parts and fulfill demand.

[0000866374-21-000062:mdna:95]
Cash used in investing activities was $0.2 billion during the six-month period ended October 1, 2021. This was primarily driven by $0.2 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Health Solutions, Automotive, and Industrial businesses.

[0000866374-21-000062:mdna:96]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. During fiscal year 2021, we proactively and strategically reduced the outstanding balance of our ABS programs. As this decrease in cash flow reflected the change of our capital strategy, we added this back for our adjusted free cash flow calculation and also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation for fiscal year 2021. Refer to Item 7,

[0000866374-21-000062:mdna:97]
“Management’s Discussion and Analysis of Financial Condition and Results of Operations” (Adjusted Free Cash Flow subsection) of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2021 for further discussion. Our adjusted free cash flows for the six-month period ended October 1, 2021 and September 25, 2020 is relatively consistent and remains an inflow of $0.3 billion. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-21-000062:mdna:98]
|  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |
|  | (In millions) |
| Net cash used in operating activities | $ | 514 |  |  | $ | (365) |  |
| Reduction in ABS levels and other | — |  |  | 788 |  |
| Purchases of property and equipment | (210) |  |  | (185) |  |
| Proceeds from the disposition of property and equipment | 5 |  |  | 14 |  |
| Adjusted free cash flow | $ | 309 |  |  | $ | 252 |  |

[0000866374-21-000062:mdna:99]
Cash used in financing activities was $0.5 billion during the six-month period ended October 1, 2021, which was primarily driven by $0.5 billion of cash paid for the repurchase of our ordinary shares.

[0000866374-21-000062:mdna:100]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of October 1, 2021, and March 31, 2021, approximately half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.5 billion as of March 31, 2021). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-21-000062:mdna:101]
[same as prior period, unchanged from 0000866374-21-000043:mdna:91]

[0000866374-21-000062:mdna:102]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs amounted to approximately $0.3 billion and $0.6 billion for the three and six-month periods ended October 1, 2021, respectively, and $0.2 billion and $0.5 billion for the three and six-month periods ended September 25, 2020, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-21-000062:mdna:103]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to commercial paper program, and revolving sale and repurchase of subordinated note established under the securitization facility, under which there were no borrowings outstanding as of October 1, 2021.

[0000866374-21-000062:mdna:104]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also have the ability to sell a designated pool of trade

[0000866374-21-000062:mdna:105]
receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed.

[0000866374-21-000062:mdna:106]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-21-000062:mdna:107]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 4, 2021. During the six-month period ended October 1, 2021, we paid $0.5 billion to repurchase shares under the current and prior repurchase plans at an average price of $18.14 per share. As of October 1, 2021, shares in the aggregate amount of $0.7 billion were available to be repurchased under the current plan.

[0000866374-21-000062:mdna:108]
[same as prior period, unchanged from 0000866374-21-000043:mdna:98]

[0000866374-21-000062:mdna:109]
[same as prior period, unchanged from 0000866374-21-000043:mdna:99]

[0000866374-21-000062:mdna:110]
There were no material changes in our contractual obligations and commitments as of October 1, 2021.

[0000866374-21-000062:mdna:111]
[same as prior period, unchanged from 0000866374-21-000043:mdna:101]

[0000866374-21-000062:mdna:112]
As of October 1, 2021, and March 31, 2021, the outstanding balance on receivables sold for cash was $0.3 billion and $0.2 billion, respectively, under our accounts receivable factoring program, which were removed from accounts receivable balances in our condensed consolidated balance sheets. There were no outstanding balance of receivables sold under our ABS programs as of each of the periods presented. For further information, see note 9 to the condensed consolidated financial statements.
