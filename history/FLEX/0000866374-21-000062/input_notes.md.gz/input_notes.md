# FLEX notes — 0000866374-21-000062


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-21-000062:notes:1]
[same as prior period, unchanged from 0000866374-21-000043:notes:1]

[0000866374-21-000062:notes:2]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In order to drive efficiency and productivity, the Company is organized around two focused and complementary delivery models, which also represent its operating and reportable segments:

[0000866374-21-000062:notes:3]
[same as prior period, unchanged from 0000866374-21-000043:notes:3]

[0000866374-21-000062:notes:4]
[same as prior period, unchanged from 0000866374-21-000043:notes:4]

[0000866374-21-000062:notes:5]
[same as prior period, unchanged from 0000866374-21-000043:notes:5]

[0000866374-21-000062:notes:6]
[same as prior period, unchanged from 0000866374-21-000043:notes:6]

[0000866374-21-000062:notes:7]
[same as prior period, unchanged from 0000866374-21-000043:notes:7]

[0000866374-21-000062:notes:8]
[same as prior period, unchanged from 0000866374-21-000043:notes:8]

[0000866374-21-000062:notes:9]
[same as prior period, unchanged from 0000866374-21-000043:notes:9]

[0000866374-21-000062:notes:10]
[same as prior period, unchanged from 0000866374-21-000043:notes:10]

[0000866374-21-000062:notes:11]
[same as prior period, unchanged from 0000866374-21-000043:notes:11]

[0000866374-21-000062:notes:12]
[same as prior period, unchanged from 0000866374-21-000043:notes:12]

[0000866374-21-000062:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2021 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended October 1, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation. Beginning in the second quarter of fiscal year 2022, the Company elected to include operating income as a subtotal in the condensed consolidated statements of operations. In addition, deferred revenue and customer working capital advances, previously included within other current liabilities, have been separately presented as deferred revenue and customer working capital advances in the current liabilities section of the condensed consolidated balance sheets. Further, certain unbilled receivables previously presented as part of accounts receivable, net of allowance for doubtful accounts are now being presented as contract assets on the condensed consolidated balance sheets as billing is to occur subsequent to revenue recognition and is conditional upon other than the passage of time. The Company reclassified $146.8 million of unbilled receivables from account receivable, net of allowance for doubtful accounts to contract assets for the period ended March 31, 2021 in order to align with the current year presentation. These presentation changes were applied to all periods presented in the condensed consolidated statements of operations and balance sheets. The foregoing changes in presentation had no impact on the Company's results of operations or cash flows.

[0000866374-21-000062:notes:14]
The first quarters for fiscal years 2022 and 2021 ended on July 2, 2021, which is comprised of 93 days in the period, and June 26, 2020, which is comprised of 87 days in the period, respectively. The second quarters for fiscal years 2022 and 2021 ended on October 1, 2021 and September 25, 2020, which are comprised of 91 days in both periods.

[0000866374-21-000062:notes:15]
[same as prior period, unchanged from 0000866374-21-000043:notes:15]

[0000866374-21-000062:notes:16]
[same as prior period, unchanged from 0000866374-21-000043:notes:16]

[0000866374-21-000062:notes:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-21-000062:notes:18]
Recently Adopted Accounting Pronouncement

[0000866374-21-000062:notes:19]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

[0000866374-21-000062:notes:20]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

[0000866374-21-000062:notes:21]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

[0000866374-21-000062:notes:22]
Recently Issued Accounting Pronouncements

[0000866374-21-000062:notes:23]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-21-000062:notes:24]
[same as prior period, unchanged from 0000866374-21-000043:notes:22]

[0000866374-21-000062:notes:25]
[same as prior period, unchanged from 0000866374-21-000043:notes:23]

[0000866374-21-000062:notes:26]
|  | As of October 1, 2021 |  | As of March 31, 2021 |
|  | (In millions) |
| Raw materials | $ | 4,106 |  |  | $ | 2,831 |  |
| Work-in-progress | 466 |  |  | 459 |  |
| Finished goods | 596 |  |  | 605 |  |
|  | $ | 5,168 |  |  | $ | 3,895 |  |

[0000866374-21-000062:notes:27]
[same as prior period, unchanged from 0000866374-21-000043:notes:25]

[0000866374-21-000062:notes:28]
During the six-month period ended October 1, 2021, there was no activity in the Company's goodwill account for each of its reporting units, other than foreign currency translation adjustments of $5.5 million, which primarily impacted its Automotive reporting unit.

[0000866374-21-000062:notes:29]
[same as prior period, unchanged from 0000866374-21-000043:notes:27]

[0000866374-21-000062:notes:30]
|  | As of October 1, 2021 |  | As of March 31, 2021 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 245 |  |  | $ | (139) |  |  | $ | 106 |  |  | $ | 276 |  |  | $ | (154) |  |  | $ | 122 |  |
| Licenses and other intangibles | 202 |  |  | (126) |  |  | 76 |  |  | 250 |  |  | (159) |  |  | 91 |  |
| Total | $ | 447 |  |  | $ | (265) |  |  | $ | 182 |  |  | $ | 526 |  |  | $ | (313) |  |  | $ | 213 |  |

[0000866374-21-000062:notes:31]
[same as prior period, unchanged from 0000866374-21-000043:notes:29]

[0000866374-21-000062:notes:32]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2022 (1) |  | $ | 24 |  |
| 2023 |  | 46 |  |
| 2024 |  | 44 |  |
| 2025 |  | 39 |  |
| 2026 |  | 18 |  |
| Thereafter |  | 11 |  |
| Total amortization expense |  | $ | 182 |  |

[0000866374-21-000062:notes:33]
[same as prior period, unchanged from 0000866374-21-000043:notes:31]

[0000866374-21-000062:notes:34]
(1)Represents estimated amortization for the remaining fiscal six-month period ending March 31, 2022.

[0000866374-21-000062:notes:35]
Customer Working Capital Advances

[0000866374-21-000062:notes:36]
Customer working capital advances was $666.4 million and $471.5 million, as of October 1, 2021 and March 31, 2021, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-21-000062:notes:37]
[same as prior period, unchanged from 0000866374-21-000043:notes:34]

[0000866374-21-000062:notes:38]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and

[0000866374-21-000062:notes:39]
can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-21-000062:notes:40]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-21-000062:notes:41]
[same as prior period, unchanged from 0000866374-21-000043:notes:38]

[0000866374-21-000062:notes:42]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet.

[0000866374-21-000062:notes:43]
[same as prior period, unchanged from 0000866374-21-000043:notes:40]

[0000866374-21-000062:notes:44]
[same as prior period, unchanged from 0000866374-21-000043:notes:41]

[0000866374-21-000062:notes:45]
[same as prior period, unchanged from 0000866374-21-000043:notes:42]

[0000866374-21-000062:notes:46]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed

[0000866374-21-000062:notes:47]
as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-21-000062:notes:48]
[same as prior period, unchanged from 0000866374-21-000043:notes:44]

[0000866374-21-000062:notes:49]
[same as prior period, unchanged from 0000866374-21-000043:notes:45]

[0000866374-21-000062:notes:50]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $545.4 million and $435.4 million as of October 1, 2021 and March 31, 2021, respectively, of which $480.1 million and $376.5 million, respectively, is included in deferred revenue and customer working capital advances.

[0000866374-21-000062:notes:51]
[same as prior period, unchanged from 0000866374-21-000043:notes:47]

[0000866374-21-000062:notes:52]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended October 1, 2021 and September 25, 2020, respectively.

[0000866374-21-000062:notes:53]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,250 |  |  | $ | 2,823 |  |  | $ | 6,498 |  |  | $ | 5,269 |  |
| Over time | 187 |  |  | 495 |  |  | 371 |  |  | 961 |  |
| Total | 3,437 |  |  | 3,318 |  |  | 6,869 |  |  | 6,230 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,308 |  |  | 1,779 |  |  | 4,711 |  |  | 3,103 |  |
| Over time | 484 |  |  | 888 |  |  | 991 |  |  | 1,805 |  |
| Total | 2,792 |  |  | 2,667 |  |  | 5,702 |  |  | 4,908 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,558 |  |  | 4,602 |  |  | 11,209 |  |  | 8,372 |  |
| Over time | 671 |  |  | 1,383 |  |  | 1,362 |  |  | 2,766 |  |
| Total | $ | 6,229 |  |  | $ | 5,985 |  |  | $ | 12,571 |  |  | $ | 11,138 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-21-000062:notes:54]
[same as prior period, unchanged from 0000866374-21-000043:notes:50]

[0000866374-21-000062:notes:55]
[same as prior period, unchanged from 0000866374-21-000043:notes:51]

[0000866374-21-000062:notes:56]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
|  | (In millions) |
| Cost of sales | $ | 6 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 10 |  |
| Selling, general and administrative expenses | 18 |  |  | 18 |  |  | 33 |  |  | 27 |  |
| Total share-based compensation expense | $ | 24 |  |  | $ | 24 |  |  | $ | 44 |  |  | $ | 37 |  |

[0000866374-21-000062:notes:57]
Total number of options outstanding and exercisable were immaterial as of October 1, 2021. All options have been fully expensed as of October 1, 2021.

[0000866374-21-000062:notes:58]
During the six-month period ended October 1, 2021, the Company granted 5.8 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 5.0 million are plain-vanilla unvested RSU awards that vest over a period of two to three years, with no performance or market conditions, and with an average grant date price of $18.25 per award. In

[0000866374-21-000062:notes:59]
addition, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $18.22 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of 0.8 million based on a measurement of the Company's earnings per share growth over a certain specified period, and will cliff vest after a period of three years, to the extent such performance conditions have been met. Further, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $25.86 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 0.8 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-21-000062:notes:60]
As of October 1, 2021, approximately 15.9 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 2.9 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of 0.4 million shares is contingent on meeting certain performance conditions. The number of shares tied to market condition that will ultimately be issued can range from zero to 5.8 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to 0.8 million based on the achievement levels. During the six-month period ended October 1, 2021, no shares vested in connection with the awards with market conditions granted in fiscal year 2019.

[0000866374-21-000062:notes:61]
As of October 1, 2021, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $175.6 million, and will be recognized over a weighted-average remaining vesting period of 2.2 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-21-000062:notes:62]
[same as prior period, unchanged from 0000866374-21-000043:notes:58]

[0000866374-21-000062:notes:63]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
|  | (In millions, except per share amounts) |
| Basic earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 336 |  |  | $ | 113 |  |  | $ | 542 |  |  | $ | 165 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 482 |  |  | 501 |  |  | 487 |  |  | 499 |  |
| Basic earnings per share | $ | 0.70 |  |  | $ | 0.23 |  |  | $ | 1.11 |  |  | $ | 0.33 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 336 |  |  | $ | 113 |  |  | $ | 542 |  |  | $ | 165 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 482 |  |  | 501 |  |  | 487 |  |  | 499 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 5 |  |  | 3 |  |  | 6 |  |  | 4 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 487 |  |  | 504 |  |  | 493 |  |  | 503 |  |
| Diluted earnings per share | $ | 0.69 |  |  | $ | 0.22 |  |  | $ | 1.10 |  |  | $ | 0.33 |  |

[0000866374-21-000062:notes:64]
(1)Immaterial RSU awards for the three and six-month periods ended October 1, 2021, and 3.5 million and 3.6 million RSU awards for the three and six-month periods ended September 25, 2020, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## flex:InterestAndOtherNetTextBlock

[0000866374-21-000062:notes:65]
INTEREST AND OTHER, NET 
Interest and other, net for the three and six-month periods ended October 1, 2021 and September 25, 2020 are primarily composed of the following:

[0000866374-21-000062:notes:66]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 37 |  |  | $ | 38 |  |  | $ | 75 |  |  | $ | 71 |  |
| Interest income | (4) |  |  | (3) |  |  | (8) |  |  | (6) |  |
| Brazil tax credit (1) | $ | (149) |  |  | — |  |  | (149) |  |  | $ | — |  |

[0000866374-21-000062:notes:67]
(1)In the second quarter of fiscal year 2022, the Company recognized a $149 million gain related to a certain tax credit upon approval of a "Credit Habilitation" request by the relevant Brazil tax authorities. Refer to note 11 to the condensed consolidated financial statements for further information.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-21-000062:notes:68]
[same as prior period, unchanged from 0000866374-21-000043:notes:63]

[0000866374-21-000062:notes:69]
[same as prior period, unchanged from 0000866374-21-000043:notes:64]

[0000866374-21-000062:notes:70]
As of October 1, 2021, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $9.4 billion as summarized below:

[0000866374-21-000062:notes:71]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| CNY |  | 4,008 |  |  | — |  |  | $ | 620 |  |  | $ | — |  |
| HUF |  | 38,453 |  |  | — |  |  | 124 |  |  | — |  |
| JPY |  | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN |  | 6,533 |  |  | — |  |  | 320 |  |  | — |  |
| MYR |  | 482 |  |  | 210 |  |  | 115 |  |  | 50 |  |
| Other |  | N/A |  | N/A |  | 227 |  |  | 68 |  |
|  |  |  |  |  |  | 1,706 |  |  | 118 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |
| BRL |  | 11 |  |  | 717 |  |  | 2 |  |  | 132 |  |
| CAD |  | 106 |  |  | 65 |  |  | 83 |  |  | 51 |  |
| CNY |  | 3,468 |  |  | — |  |  | 535 |  |  | — |  |
| EUR |  | 1,851 |  |  | 1,989 |  |  | 2,153 |  |  | 2,319 |  |
| GBP |  | 60 |  |  | 83 |  |  | 81 |  |  | 112 |  |
| HUF |  | 73,443 |  |  | 60,446 |  |  | 237 |  |  | 195 |  |
| ILS |  | 582 |  |  | 95 |  |  | 181 |  |  | 30 |  |
| INR |  | 11,398 |  |  | 305 |  |  | 153 |  |  | 4 |  |
| MXN |  | 7,202 |  |  | 5,645 |  |  | 352 |  |  | 276 |  |
| MYR |  | 694 |  |  | 192 |  |  | 166 |  |  | 46 |  |
| SEK |  | 571 |  |  | 657 |  |  | 66 |  |  | 75 |  |
| SGD |  | 104 |  |  | 56 |  |  | 77 |  |  | 41 |  |
| Other |  | N/A |  | N/A |  | 125 |  |  | 93 |  |
|  |  |  |  |  |  | 4,211 |  |  | 3,374 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 5,917 |  |  | $ | 3,492 |  |

[0000866374-21-000062:notes:72]
As of October 1, 2021, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of October 1, 2021 and March 31, 2021, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred loss was $9.1 million as of October 1, 2021, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-21-000062:notes:73]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of October 1, 2021. The changes in fair value of the USD JPY cross currency swap are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also impacts the same line.

[0000866374-21-000062:notes:74]
[same as prior period, unchanged from 0000866374-21-000043:notes:69]

[0000866374-21-000062:notes:75]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | October 1,2021 |  | March 31,2021 |  | Balance SheetLocation |  | October 1,2021 |  | March 31,2021 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 11 |  |  | $ | 23 |  |  | Other current liabilities |  | $ | 17 |  |  | $ | 16 |  |
| Foreign currency contracts | Other assets |  | $ | — |  |  | $ | 5 |  |  | Other liabilities |  | $ | 2 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 26 |  |  | $ | 31 |  |  | Other current liabilities |  | $ | 27 |  |  | $ | 32 |  |

[0000866374-21-000062:notes:76]
[same as prior period, unchanged from 0000866374-21-000043:notes:71]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-21-000062:notes:77]
[same as prior period, unchanged from 0000866374-21-000043:notes:72]

[0000866374-21-000062:notes:78]
|  | Three-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (39) |  |  | $ | (72) |  |  | $ | (111) |  |  | $ | (52) |  |  | $ | (119) |  |  | $ | (171) |  |
| Other comprehensive gain (loss) before reclassifications | (5) |  |  | (16) |  |  | (21) |  |  | 11 |  |  | 31 |  |  | 42 |  |
| Net gains reclassified from accumulated other comprehensive loss | (5) |  |  | — |  |  | (5) |  |  | (4) |  |  | — |  |  | (4) |  |
| Net current-period other comprehensive gain (loss) | (10) |  |  | (16) |  |  | (26) |  |  | 7 |  |  | 31 |  |  | 38 |  |
| Ending balance | $ | (49) |  |  | $ | (88) |  |  | $ | (137) |  |  | $ | (45) |  |  | $ | (88) |  |  | $ | (133) |  |

[0000866374-21-000062:notes:79]
|  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |  | $ | (82) |  |  | $ | (133) |  |  | $ | (215) |  |
| Other comprehensive gain (loss) before reclassifications | 7 |  |  | (10) |  |  | (3) |  |  | 30 |  |  | 45 |  |  | 75 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (14) |  |  | (1) |  |  | (15) |  |  | 7 |  |  | — |  |  | 7 |  |
| Net current-period other comprehensive gain (loss) | (7) |  |  | (11) |  |  | (18) |  |  | 37 |  |  | 45 |  |  | 82 |  |
| Ending balance | $ | (49) |  |  | $ | (88) |  |  | $ | (137) |  |  | $ | (45) |  |  | $ | (88) |  |  | $ | (133) |  |

[0000866374-21-000062:notes:80]
Substantially all unrealized losses and gains relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and six-month periods ended October 1, 2021 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-21-000062:notes:81]
[same as prior period, unchanged from 0000866374-21-000043:notes:75]

[0000866374-21-000062:notes:82]
[same as prior period, unchanged from 0000866374-21-000043:notes:76]

[0000866374-21-000062:notes:83]
The Company sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” and together with the Global Program, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells a fraction of the receivables to unaffiliated financial institutions, based on the Company's requirements. Under these programs, the entire purchase price of sold receivables is paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The fair value of the guarantee obligation was zero as of October 1, 2021 and March 31, 2021, respectively. The accounts receivable balances sold under the ABS Programs were removed from the condensed consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-21-000062:notes:84]
[same as prior period, unchanged from 0000866374-21-000043:notes:78]

[0000866374-21-000062:notes:85]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the six-month periods ended October 1, 2021 and September 25, 2020 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-21-000062:notes:86]
As of October 1, 2021 and March 31, 2021, no accounts receivable had been sold under the ABS programs.

[0000866374-21-000062:notes:87]
For the six-month periods ended September 25, 2020, cash flows from sales of receivables from the special purpose entities to unaffiliated financial institutions, consisted of approximately $0.6 billion, for transfers of receivables. The Company's cash flows from transfers of receivables in fiscal year 2021 consisted primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented. 
Trade Accounts Receivable Sale ProgramsThe Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.3 billion and $0.2 billion as of October 1, 2021 and March 31, 2021, respectively. For the six-month periods ended October 1, 2021 and September 25, 2020, total accounts receivable sold to certain third-party banking institutions was approximately $0.6 billion and $0.5 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-21-000062:notes:88]
[same as prior period, unchanged from 0000866374-21-000043:notes:83]

[0000866374-21-000062:notes:89]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of October 1, 2021 and March 31, 2021.

[0000866374-21-000062:notes:90]
[same as prior period, unchanged from 0000866374-21-000043:notes:85]

[0000866374-21-000062:notes:91]
[same as prior period, unchanged from 0000866374-21-000043:notes:86]

[0000866374-21-000062:notes:92]
[same as prior period, unchanged from 0000866374-21-000043:notes:87]

[0000866374-21-000062:notes:93]
[same as prior period, unchanged from 0000866374-21-000043:notes:88]

[0000866374-21-000062:notes:94]
[same as prior period, unchanged from 0000866374-21-000043:notes:89]

[0000866374-21-000062:notes:95]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of October 1, 2021 and March 31, 2021.

[0000866374-21-000062:notes:96]
There were no transfers between levels in the fair value hierarchy during the six-month periods ended October 1, 2021 and September 25, 2020.

[0000866374-21-000062:notes:97]
[same as prior period, unchanged from 0000866374-21-000043:notes:92]

[0000866374-21-000062:notes:98]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of October 1, 2021 and March 31, 2021:

[0000866374-21-000062:notes:99]
|  | Fair Value Measurements as of October 1, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,855 |  |  | $ | — |  |  | $ | 1,855 |  |
| Foreign currency contracts (Note 7) | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 42 |  |  | — |  |  | 42 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 7) | $ | — |  |  | $ | (46) |  |  | $ | — |  |  | $ | (46) |  |
|  | Fair Value Measurements as of March 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,507 |  |  | $ | — |  |  | $ | 1,507 |  |
| Foreign currency contracts (Note 7) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 7) | $ | — |  |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |

[0000866374-21-000062:notes:100]
[same as prior period, unchanged from 0000866374-21-000043:notes:95]

[0000866374-21-000062:notes:101]
[same as prior period, unchanged from 0000866374-21-000043:notes:96]

[0000866374-21-000062:notes:102]
|  | As of October 1, 2021 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 529 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 300 |  |  | 300 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 665 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 692 |  |  | 753 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 660 |  |  | 762 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 692 |  |  | 801 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 166 |  |  | 166 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| India Facilities | 126 |  |  | 126 |  |  | 133 |  |  | 133 |  |  | Level 2 |

[0000866374-21-000062:notes:103]
[same as prior period, unchanged from 0000866374-21-000043:notes:98]

[0000866374-21-000062:notes:104]
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans based on the current market rate, and as of October 1, 2021, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-21-000062:notes:105]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-21-000062:notes:106]
In connection with the matters described below, other than the Brazilian "Credit Habilitation" gain contingency, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-21-000062:notes:107]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-21-000062:notes:108]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

[0000866374-21-000062:notes:109]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff, National Elevator Industry Pension Fund, and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. On May 19, 2021, lead plaintiff filed its opening appeal brief, on July 19, 2021, defendants filed their answering brief, and on September 8, 2021, lead plaintiff filed its reply brief. The Court of Appeals has scheduled oral argument for December 8, 2021. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-21-000062:notes:110]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously

[0000866374-21-000062:notes:111]
shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-21-000062:notes:112]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 373.7 million Brazilian reals (approximately USD $68.9 million based on the exchange rate as of October 1, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 60.6 million Brazilian reals or USD $11.2 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 33.9 million Brazilian reals (approximately USD $6.3 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

[0000866374-21-000062:notes:113]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company is currently reviewing those transactions and expects to submit an update to its submission to OFAC once that review is complete. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-21-000062:notes:114]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $163.9 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-21-000062:notes:115]
A different foreign Tax Authority had issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagreed with the Tax Authority’s assertion but agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount was accrued for during the fourth quarter of fiscal year 2021 and is expected to be paid during fiscal year 2022.

[0000866374-21-000062:notes:116]
As the final resolutions of the above tax items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-21-000062:notes:117]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for "Credit Habilitation" with the tax authorities in June 2021 to request additional PIS/COFINS credit in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of the Company's

[0000866374-21-000062:notes:118]
credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remained uncertainty regarding the Company’s ability to recognize these credits. The Company considered the recognition of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and did not record a gain for such credits in the three-month period ended July 2, 2021 as it had not resolved all contingencies to conclude a realized or realizable amount. In September 2021, the Credit Habilitation request was approved by the tax authorities and the Company recognized a gain of 809.6 million Brazilian reals (approximately USD $149.3 million based on the exchange rate as of October 1, 2021) included in interest and other, net in the condensed consolidated statements of operations for the three and six-month periods ended October 1, 2021. The total gain recorded included credits from February 2003 to September 2021, net of additional taxes, as the Credit Habilitation received covering the period from February 2003 to December 2019 resolved any uncertainty regarding the Company's ability to claim such credits. This gain is non-cash and can only be used to offset certain current and future tax obligations. Out of the $149.3 million, $50.6 million was included in other current assets and $98.7 million was included in other assets in the condensed consolidated balance sheet as of October 1, 2021 as we expect to utilize these credits in the next two to three years.

[0000866374-21-000062:notes:119]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-21-000062:notes:120]
SHARE REPURCHASES 
During the three and six-month periods ended October 1, 2021, the Company repurchased 18.0 million and 27.0 million shares at an aggregate purchase price of $328.1 million and $490.3 million, respectively, and retired all of these shares.

[0000866374-21-000062:notes:121]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of Annual General Meeting held on August 4, 2021. As of October 1, 2021, shares in the aggregate amount of $690.9 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-21-000062:notes:122]
[same as prior period, unchanged from 0000866374-21-000043:notes:115]

[0000866374-21-000062:notes:123]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, and legal and other. A portion of depreciation is allocated to the respective segment, together with other general corporate research and development and administrative expenses.

[0000866374-21-000062:notes:124]
[same as prior period, unchanged from 0000866374-21-000043:notes:117]

[0000866374-21-000062:notes:125]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,437 |  |  | $ | 3,318 |  |  | $ | 6,869 |  |  | $ | 6,230 |  |
| Flex Reliability Solutions | 2,792 |  |  | 2,667 |  |  | 5,702 |  |  | 4,908 |  |
|  | $ | 6,229 |  |  | $ | 5,985 |  |  | $ | 12,571 |  |  | $ | 11,138 |  |
| Segment income and reconciliation of operating income: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 153 |  |  | $ | 88 |  |  | $ | 290 |  |  | $ | 160 |  |
| Flex Reliability Solutions | 151 |  |  | 179 |  |  | 321 |  |  | 294 |  |
| Corporate and Other | (18) |  |  | (20) |  |  | (35) |  |  | (44) |  |
| Total segment income | 286 |  |  | 247 |  |  | 576 |  |  | 410 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 15 |  |  | 16 |  |  | 30 |  |  | 31 |  |
| Stock-based compensation | 24 |  |  | 24 |  |  | 44 |  |  | 37 |  |
| Restructuring charges | 9 |  |  | 35 |  |  | 9 |  |  | 45 |  |
| Legal and other (1) | 1 |  |  | (3) |  |  | — |  |  | 25 |  |
| Operating income | $ | 237 |  |  | $ | 175 |  |  | $ | 493 |  |  | $ | 272 |  |

[0000866374-21-000062:notes:126]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as customer related asset recoveries. During the first quarter of fiscal year 2021, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-21-000062:notes:127]
Corporate and other primarily includes corporate services costs that are not included in the chief operating decision maker's ("CODM") assessment of the performance of each of the identified reporting segments.

[0000866374-21-000062:notes:128]
[same as prior period, unchanged from 0000866374-21-000043:notes:121]


## us-gaap:SubsequentEventsTextBlock

[0000866374-21-000062:notes:129]
SUBSEQUENT EVENTSIn October 2021, the Company announced that it has entered into a definitive agreement to acquire 100% of the voting shares of Anord Mardix, a global leader in critical power solutions for $540 million in an all-cash transaction. The acquisition will add to the Company' portfolio of Power products and expand its offering in the data center market and is expected to close in the third quarter of fiscal year 2022, subject to customary closing conditions, including regulatory approval. For reporting purposes, Anord Mardix will be included in the Industrial business unit within the FRS segment.
