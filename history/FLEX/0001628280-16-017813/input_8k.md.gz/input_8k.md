# FLEX 8-K — 0001104659-16-133707 filed 2016-07-21

## item codes, every 8-K on or before 2016-07-27

- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2016-07-27

- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-16-133707:8k_2_02:1]
EX-99.1
2
a16-15202_1ex99d1.htm
EX-99.1

[0001104659-16-133707:8k_2_02:2]
Exhibit 99.1

[0001104659-16-133707:8k_2_02:3]
P R E S S   R E L E A S E

[0001104659-16-133707:8k_2_02:4]
| Renee Brotherton | Kevin Kessel |
| Corporate Communications | Investor Relations |
| (408) 576-7189 | (408) 576-7985 |
| renee.brotherton@flextronics.com | kevin.kessel@flextronics.com |

[0001104659-16-133707:8k_2_02:5]
FLEX REPORTS FIRST QUARTER FISCAL 2017 RESULTS

[0001104659-16-133707:8k_2_02:6]
·                  GAAP diluted EPS of $0.19, non-GAAP diluted EPS of $0.27

[0001104659-16-133707:8k_2_02:7]
·                  Strong cash flow from operations of $264 million and free cash flow of $121 million

[0001104659-16-133707:8k_2_02:8]
·                  Maintains commitment to return value to shareholders

[0001104659-16-133707:8k_2_02:9]
San Jose, CA, July 21, 2016 — Flex (NASDAQ: FLEX), a leading Sketch-to-Scale™ solutions company that designs and builds intelligent products for a connected world, today announced results for its first quarter ended July 01, 2016:

[0001104659-16-133707:8k_2_02:10]
|  |  | Three Month Periods Ended |  |
| (US$ in millions, except EPS) |  | July 01, 2016 |  | June 26, 2015 |  |
| Net sales |  | $ | 5,877 |  | $ | 5,566 |  |
| GAAP income before income taxes |  | $ | 117 |  | $ | 119 |  |
| Adjusted operating income |  | $ | 190 |  | $ | 159 |  |
| GAAP net income |  | $ | 106 |  | $ | 111 |  |
| Adjusted net income |  | $ | 149 |  | $ | 134 |  |
| GAAP EPS |  | $ | 0.19 |  | $ | 0.19 |  |
| Adjusted EPS |  | $ | 0.27 |  | $ | 0.23 |  |

[0001104659-16-133707:8k_2_02:11]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release.

[0001104659-16-133707:8k_2_02:12]
First Quarter Fiscal 2017 Results of Operations

[0001104659-16-133707:8k_2_02:13]
Net sales for the first quarter ended July 01, 2016 were approximately $5.9 billion, which was at the high end of the guidance range of $5.5 to $5.9 billion.

[0001104659-16-133707:8k_2_02:14]
GAAP income before income taxes was $117 million for the quarter and adjusted operating income was $190 million, at the mid-point of the guidance range of $175 million to $205 million.

[0001104659-16-133707:8k_2_02:15]
GAAP gross margin increased approximately 60 basis points and adjusted gross margin increased over 50 basis points on a year-over-year basis.

[0001104659-16-133707:8k_2_02:16]
Net income on a GAAP basis was $106 million and adjusted net income for the quarter was $149 million. GAAP EPS was $0.19 for the quarter which is flat compared to the prior year. Non-GAAP EPS was $0.27 for the quarter, increasing $0.04 from same quarter last year.

[0001104659-16-133707:8k_2_02:17]
“We continue to successfully execute our Sketch-to-Scale strategy” said Mike McNamara, chief executive officer of Flex. “Our first quarter results reflect our continued portfolio evolution with a 20% growth in adjusted operating profit, an increase of 17% in adjusted earnings, strong cash flow from operations and over seven million shares repurchased.”

[0001104659-16-133707:8k_2_02:18]
Guidance

[0001104659-16-133707:8k_2_02:19]
For the second quarter ending September 30, 2016, revenue is expected to be in the range of $5.8 to $6.2 billion, GAAP EPS is expected to be in the range of $0.18 to $0.22 and includes estimated intangible amortization and stock-based compensation expense.  Adjusted EPS is expected to be in the range of $0.26 to $0.30 per diluted share.

[0001104659-16-133707:8k_2_02:20]
Conference Calls and Web Casts

[0001104659-16-133707:8k_2_02:21]
A conference call hosted by the Flex management team will be held today at 2:00 PM (PT) / 5:00 PM (ET) to discuss the Company’s financial results for the first quarter ended July 01, 2016. The conference call will be broadcast via the Internet and may be accessed by logging on to the Company’s website at www.flextronics.com. Additional information in the form of a slide presentation may also be found on the Company’s site.  A replay of the broadcast will remain available on the Company’s website afterwards.

[0001104659-16-133707:8k_2_02:22]
About Flex

[0001104659-16-133707:8k_2_02:23]
Flextronics International Ltd. (Reg. No. 199002645H) is a leading Sketch-to-Scale™ solutions company that designs and builds intelligent products for a connected world. With approximately 200,000 professionals across 30 countries and a promise to help the world Live Smarter™, the Company provides innovative design, engineering, manufacturing, real-time supply chain insight and logistics services to companies of all sizes in various industries and end-markets. For more information, visit www.flextronics.com or follow us on Twitter @Flextronics.

[0001104659-16-133707:8k_2_02:24]
# # #

[0001104659-16-133707:8k_2_02:25]
repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0001104659-16-133707:8k_2_02:26]
SCHEDULE I

[0001104659-16-133707:8k_2_02:27]
FLEX

[0001104659-16-133707:8k_2_02:28]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-16-133707:8k_2_02:29]
(In thousands, except per share amounts)

[0001104659-16-133707:8k_2_02:30]
|  |  | Three Month Periods Ended |  |
|  |  | July 01, 2016 |  | June 26, 2015 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 5,876,813 |  | $ | 5,566,248 |  |
| Cost of sales |  | 5,470,818 |  | 5,213,907 |  |
| Gross profit |  | 405,995 |  | 352,341 |  |
| Selling, general and administrative expenses |  | 239,546 |  | 209,385 |  |
| Intangible amortization |  | 21,598 |  | 7,671 |  |
| Interest and other, net |  | 24,399 |  | 16,505 |  |
| Other charges, net |  | 3,529 |  | 164 |  |
| Income before income taxes |  | 116,923 |  | 118,616 |  |
| Provision for income taxes |  | 11,194 |  | 7,766 |  |
| Net income |  | $ | 105,729 |  | $ | 110,850 |  |
| EPS: |  |  |  |  |  |
| GAAP |  | $ | 0.19 |  | $ | 0.19 |  |
| Non-GAAP |  | $ | 0.27 |  | $ | 0.23 |  |
| Diluted shares used in computing per share amounts |  | 551,029 |  | 577,997 |  |

[0001104659-16-133707:8k_2_02:31]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release.

[0001104659-16-133707:8k_2_02:32]
SCHEDULE II

[0001104659-16-133707:8k_2_02:33]
FLEX

[0001104659-16-133707:8k_2_02:34]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-16-133707:8k_2_02:35]
(In thousands, except per share amounts)

[0001104659-16-133707:8k_2_02:36]
|  |  | Three Month Periods Ended |  |
|  |  | July 01, 2016 |  | June 26, 2015 |  |
| GAAP gross profit |  | $ | 405,995 |  | $ | 352,341 |  |
| Stock-based compensation expense |  | 2,433 |  | 2,018 |  |
| Non-GAAP gross profit |  | $ | 408,428 |  | $ | 354,359 |  |
| GAAP SG&A Expenses |  | $ | 239,546 |  | $ | 209,385 |  |
| Stock-based compensation expense |  | (21,364 | ) | (14,108 | ) |
| Non-GAAP SG&A Expenses |  | $ | 218,182 |  | $ | 195,277 |  |
| GAAP income before income taxes |  | $ | 116,923 |  | $ | 118,616 |  |
| Stock-based compensation expense |  | 23,797 |  | 16,126 |  |
| Intangible amortization |  | 21,598 |  | 7,671 |  |
| Interest and other, net |  | 24,399 |  | 16,505 |  |
| Other charges, net |  | 3,529 |  | 164 |  |
| Non-GAAP operating income |  | $ | 190,246 |  | $ | 159,082 |  |
| GAAP provision for income taxes |  | $ | 11,194 |  | $ | 7,766 |  |
| Intangible amortization benefit |  | 1,850 |  | 258 |  |
| Tax benefit on intangible assets |  | 638 |  | — |  |
| Non-GAAP provision for income taxes |  | $ | 13,682 |  | $ | 8,024 |  |
| GAAP net income |  | $ | 105,729 |  | $ | 110,850 |  |
| Stock-based compensation expense |  | 23,797 |  | 16,126 |  |
| Intangible amortization |  | 21,598 |  | 7,671 |  |
| Adjustments for taxes |  | (2,488 | ) | (258 | ) |
| Non-GAAP net income |  | $ | 148,636 |  | $ | 134,389 |  |
| EPS: |  |  |  |  |  |
| GAAP |  | $ | 0.19 |  | $ | 0.19 |  |
| Non-GAAP |  | $ | 0.27 |  | $ | 0.23 |  |

[0001104659-16-133707:8k_2_02:37]
SCHEDULE III

[0001104659-16-133707:8k_2_02:38]
FLEX

[0001104659-16-133707:8k_2_02:39]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-16-133707:8k_2_02:40]
(In thousands)

[0001104659-16-133707:8k_2_02:41]
|  |  | As of July 01, 2016 |  | As of March 31, 2016 |  |
| ASSETS |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,679,335 |  | $ | 1,607,570 |  |
| Accounts receivable, net of allowance for doubtful accounts |  | 2,057,943 |  | 2,044,757 |  |
| Inventories |  | 3,594,837 |  | 3,491,656 |  |
| Other current assets |  | 1,088,844 |  | 1,171,143 |  |
| Total current assets |  | 8,420,959 |  | 8,315,126 |  |
| Property and equipment, net |  | 2,296,445 |  | 2,257,633 |  |
| Goodwill and other intangible assets, net |  | 1,324,614 |  | 1,345,820 |  |
| Other assets |  | 466,506 |  | 466,402 |  |
| Total assets |  | $ | 12,508,524 |  | $ | 12,384,981 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 66,020 |  | $ | 65,166 |  |
| Accounts payable |  | 4,317,571 |  | 4,248,292 |  |
| Accrued payroll |  | 377,527 |  | 353,547 |  |
| Other current liabilities |  | 1,866,585 |  | 1,905,200 |  |
| Total current liabilities |  | 6,627,703 |  | 6,572,205 |  |
| Long-term debt, net of current portion: |  | 2,692,596 |  | 2,709,389 |  |
| Other liabilities |  | 521,631 |  | 497,857 |  |
| Total shareholders’ equity |  | 2,666,594 |  | 2,605,530 |  |
| Total liabilities and shareholders’ equity |  | $ | 12,508,524 |  | $ | 12,384,981 |  |

[0001104659-16-133707:8k_2_02:42]
SCHEDULE IV

[0001104659-16-133707:8k_2_02:43]
FLEX

[0001104659-16-133707:8k_2_02:44]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-16-133707:8k_2_02:45]
(In thousands)

[0001104659-16-133707:8k_2_02:46]
|  |  | Three-Month Periods Ended |  |
|  |  | July 01, 2016 |  | June 26, 2015 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income |  | $ | 105,729 |  | $ | 110,850 |  |
| Depreciation, amortization and other impairment charges |  | 129,500 |  | 110,119 |  |
| Changes in working capital and other |  | 28,703 |  | 141,307 |  |
| Net cash provided by operating activities |  | 263,932 |  | 362,276 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property and equipment |  | (159,103 | ) | (138,348 | ) |
| Proceeds from the disposition of property and equipment |  | 15,722 |  | 1,512 |  |
| Acquisition of businesses, net of cash acquired |  | (9,492 | ) | (18,580 | ) |
| Proceeds from divestiture of business, net of cash held in divested business |  | 14,828 |  | 1,000 |  |
| Other investing activities, net |  | 26,261 |  | (7,580 | ) |
| Net cash used in investing activities |  | (111,784 | ) | (161,996 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 75,018 |  | 595,548 |  |
| Repayments of bank borrowings and long-term debt |  | (92,222 | ) | (8,457 | ) |
| Payments for repurchases of ordinary shares |  | (94,715 | ) | (99,995 | ) |
| Net proceeds from issuance of ordinary shares |  | 3,966 |  | 44,602 |  |
| Other financing activities, net |  | 12,901 |  | (25,252 | ) |
| Net cash (used in) provided by financing activities |  | (95,052 | ) | 506,446 |  |
| Effect of exchange rates on cash and cash equivalents |  | 14,669 |  | (3,723 | ) |
| Net increase in cash and cash equivalents |  | 71,765 |  | 703,003 |  |
| Cash and cash equivalents, beginning of period |  | 1,607,570 |  | 1,628,408 |  |
| Cash and cash equivalents, end of period |  | $ | 1,679,335 |  | $ | 2,331,411 |  |

[0001104659-16-133707:8k_2_02:47]
SCHEDULE V

[0001104659-16-133707:8k_2_02:48]
FLEX AND SUBSIDIARIES

[0001104659-16-133707:8k_2_02:49]
NOTES TO SCHEDULES I, II, III, & IV

[0001104659-16-133707:8k_2_02:50]
(1)   To supplement Flex’s unaudited selected financial data presented on a basis consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP selling, general and administrative expenses, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude stock-based compensation expense, restructuring charges, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies.  We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-16-133707:8k_2_02:51]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance.  We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors.  In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-16-133707:8k_2_02:52]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-16-133707:8k_2_02:53]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-16-133707:8k_2_02:54]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-16-133707:8k_2_02:55]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-16-133707:8k_2_02:56]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-16-133707:8k_2_02:57]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types.  In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-16-133707:8k_2_02:58]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions.  The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and

[0001104659-16-133707:8k_2_02:59]
therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-16-133707:8k_2_02:60]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies when applicable.

[0001104659-16-133707:8k_2_02:61]
For the three-month period ended July 1, 2016, Free Cash Flow was $121 million consisting of GAAP net cash flows from operating activities of $264 million less purchases of property and equipment net of proceeds from dispositions of $143 million. We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash flows provided by operating activities.”
