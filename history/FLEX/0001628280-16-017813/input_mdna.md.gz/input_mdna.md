# FLEX MD&A — 0001628280-16-017813


## mdna

[0001628280-16-017813:mdna:1]
[same as prior period, unchanged from 0001628280-16-010628:mdna:1]

[0001628280-16-017813:mdna:2]
[same as prior period, unchanged from 0001628280-16-010628:mdna:2]

[0001628280-16-017813:mdna:3]
[same as prior period, unchanged from 0001628280-16-010628:mdna:3]

[0001628280-16-017813:mdna:4]
We are a globally-recognized, leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scaletm; from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through our activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of our medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; our automotive business, including vehicle electronics, connectivity, and clean technologies; and our defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes our mobile devices business, including smart phones; our consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, our CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions.

[0001628280-16-017813:mdna:5]
[same as prior period, unchanged from 0001628280-16-010628:mdna:6]

[0001628280-16-017813:mdna:6]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0001628280-16-017813:mdna:7]
[same as prior period, unchanged from 0001628280-16-010628:mdna:9]

[0001628280-16-017813:mdna:8]
[same as prior period, unchanged from 0001628280-16-010628:mdna:10]

[0001628280-16-017813:mdna:9]
[same as prior period, unchanged from 0001628280-16-010628:mdna:11]

[0001628280-16-017813:mdna:10]
We are one of the world's largest providers of global supply chain solutions, with revenues of $5.9 billion for the three-month period ended July 1, 2016 and $24.4 billion in fiscal year 2016. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0001628280-16-017813:mdna:11]
|  |  | Three-Month Periods Ended |
| Net sales: |  | July 1, 2016 |  | June 26, 2015 |
|  |  | (In thousands) |
| China |  | $ | 1,840,853 |  |  | 31 | % |  | $ | 1,836,188 |  |  | 33 | % |
| Mexico |  | 915,345 |  |  | 16 | % |  | 906,879 |  |  | 16 | % |
| U.S. |  | 708,410 |  |  | 12 | % |  | 642,589 |  |  | 11 | % |
| Malaysia |  | 572,763 |  |  | 10 | % |  | 545,370 |  |  | 10 | % |
| Brazil |  | 371,672 |  |  | 6 | % |  | 484,130 |  |  | 9 | % |
| Other |  | 1,467,770 |  |  | 25 | % |  | 1,151,092 |  |  | 21 | % |
|  |  | $ | 5,876,813 |  |  |  |  |  | $ | 5,566,248 |  |  |  |  |

[0001628280-16-017813:mdna:12]
|  |  | As of |  | As of |
| Property and equipment, net: |  | July 1, 2016 |  | March 31, 2016 |
|  |  | (In thousands) |
| China |  | $ | 793,893 |  |  | 35 | % |  | $ | 789,571 |  |  | 35 | % |
| Mexico |  | 447,250 |  |  | 19 | % |  | 429,989 |  |  | 19 | % |
| U.S. |  | 319,202 |  |  | 14 | % |  | 330,778 |  |  | 15 | % |
| Malaysia |  | 161,414 |  |  | 7 | % |  | 159,787 |  |  | 7 | % |
| Brazil |  | 123,720 |  |  | 5 | % |  | 121,949 |  |  | 5 | % |
| Other |  | 450,966 |  |  | 20 | % |  | 425,559 |  |  | 19 | % |
|  |  | $ | 2,296,445 |  |  |  |  |  | $ | 2,257,633 |  |  |  |  |

[0001628280-16-017813:mdna:13]
[same as prior period, unchanged from 0001628280-16-010628:mdna:15]

[0001628280-16-017813:mdna:14]
[same as prior period, unchanged from 0001628280-16-010628:mdna:17]

[0001628280-16-017813:mdna:15]
[same as prior period, unchanged from 0001628280-16-010628:mdna:18]

[0001628280-16-017813:mdna:16]
[same as prior period, unchanged from 0001628280-16-010628:mdna:19]

[0001628280-16-017813:mdna:17]
30

[0001628280-16-017813:mdna:18]
[same as prior period, unchanged from 0001628280-16-010628:mdna:20]

[0001628280-16-017813:mdna:19]
[same as prior period, unchanged from 0001628280-16-010628:mdna:21]

[0001628280-16-017813:mdna:20]
[same as prior period, unchanged from 0001628280-16-010628:mdna:22]

[0001628280-16-017813:mdna:21]
[same as prior period, unchanged from 0001628280-16-010628:mdna:23]

[0001628280-16-017813:mdna:22]
[same as prior period, unchanged from 0001628280-16-010628:mdna:24]

[0001628280-16-017813:mdna:23]
[same as prior period, unchanged from 0001628280-16-010628:mdna:25]

[0001628280-16-017813:mdna:24]
[same as prior period, unchanged from 0001628280-16-010628:mdna:26]

[0001628280-16-017813:mdna:25]
[same as prior period, unchanged from 0001628280-16-010628:mdna:27]

[0001628280-16-017813:mdna:26]
[same as prior period, unchanged from 0001628280-16-010628:mdna:28]

[0001628280-16-017813:mdna:27]
[same as prior period, unchanged from 0001628280-16-010628:mdna:29]

[0001628280-16-017813:mdna:28]
[same as prior period, unchanged from 0001628280-16-010628:mdna:30]

[0001628280-16-017813:mdna:29]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2016, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0001628280-16-017813:mdna:30]
[same as prior period, unchanged from 0001628280-16-010628:mdna:32]

[0001628280-16-017813:mdna:31]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read in conjunction with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our 2016 Annual Report on Form 10-K.

[0001628280-16-017813:mdna:32]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
| Net sales | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.1 |  |  | 93.7 |  |
| Gross profit | 6.9 |  |  | 6.3 |  |
| Selling, general and administrative expenses | 4.1 |  |  | 3.8 |  |
| Intangible amortization | 0.4 |  |  | 0.1 |  |
| Interest and other, net | 0.4 |  |  | 0.3 |  |
| Other charges, net | 0.1 |  |  | 0.0 |  |
| Income before income taxes | 1.9 |  |  | 2.1 |  |
| Provision for income taxes | 0.2 |  |  | 0.1 |  |
| Net income | 1.7 | % |  | 2.0 | % |

[0001628280-16-017813:mdna:33]
31

[0001628280-16-017813:mdna:34]
[same as prior period, unchanged from 0001628280-16-010628:mdna:36]

[0001628280-16-017813:mdna:35]
[same as prior period, unchanged from 0001628280-16-010628:mdna:37]

[0001628280-16-017813:mdna:36]
|  |  | Three-Month Periods Ended |
| Segments: |  | July 1, 2016 |  | June 26, 2015 |
|  |  | (In thousands) |
| Communications & Enterprise Compute |  | $ | 2,195,990 |  |  | 38 | % |  | $ | 1,966,562 |  |  | 35 | % |
| Consumer Technologies Group |  | 1,313,782 |  |  | 22 | % |  | 1,564,964 |  |  | 28 | % |
| Industrial & Emerging Industries |  | 1,289,015 |  |  | 22 | % |  | 1,130,138 |  |  | 21 | % |
| High Reliability Solutions |  | 1,078,026 |  |  | 18 | % |  | 904,584 |  |  | 16 | % |
|  |  | $ | 5,876,813 |  |  |  |  |  | $ | 5,566,248 |  |  |  |  |

[0001628280-16-017813:mdna:37]
Net sales during the three-month period ended July 1, 2016 totaled $5.9 billion, representing an increase of approximately $310.6 million, or 5.6% from $5.6 billion during the three-month period ended June 26, 2015. The overall increase in sales was driven by modest increases in three of our segments, with a $229.4 million increase in our CEC segment, primarily due to higher sales within our telecom and networking businesses, a $173.4 million increase in our HRS segment primarily attributable to successful new program ramps in our automotive and medical businesses, along with an increase in sales within our automotive business as a result of our Mirror Controls International ("MCi") acquisition, and a $158.9 million increase in our IEI segment, driven by contribution from our NEXTracker acquisition and expansion within our capital equipment business, and our household industrial and lifestyle business. These increases were offset by a decrease of revenue in our CTG segment of $251.2 million, largely due to a decline in demand from our largest customer in our smart phone business offset by expansion across our wearables and connected home markets. Net sales increased $245.1 million to $1.1 billion in Europe and $99.9 million to $2.7 billion in Asia, respectively. These increases were offset by a modest decrease of $34.4 million to $2.0 billion in the Americas.

[0001628280-16-017813:mdna:38]
Our ten largest customers, during the three-month period ended July 1, 2016, accounted for approximately 43% of net sales. No customer accounted for more than 10% of net sales during the three-month period ended July 1, 2016.

[0001628280-16-017813:mdna:39]
Our ten largest customers accounted for approximately 45% of net sales for the three-month period ended June 26, 2015. Lenovo/Motorola accounted for more than 10% of net sales during the three-month period ended June 26, 2015.

[0001628280-16-017813:mdna:40]
[same as prior period, unchanged from 0001628280-16-010628:mdna:44]

[0001628280-16-017813:mdna:41]
[same as prior period, unchanged from 0001628280-16-010628:mdna:45]

[0001628280-16-017813:mdna:42]
Gross profit during the three-month period ended July 1, 2016 increased $53.7 million to $406.0 million, or 6.9% of net sales, from $352.3 million, or 6.3% of net sales, during the three-month period ended June 26, 2015. Gross margins improved 60 basis points in the three-month period ended July 1, 2016, compared to that of the three-month period ended June 26, 2015, led by a richer business mix due to a greater concentration of our higher margin HRS and IEI businesses coupled with improved operational efficiencies.

[0001628280-16-017813:mdna:43]
[same as prior period, unchanged from 0001628280-16-010628:mdna:48]

[0001628280-16-017813:mdna:44]
An operating segment’s performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock‑based compensation, other charges (income), net and interest and other, net. A portion of

[0001628280-16-017813:mdna:45]
amortization and depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0001628280-16-017813:mdna:46]
[same as prior period, unchanged from 0001628280-16-010628:mdna:50]

[0001628280-16-017813:mdna:47]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
|  | (In thousands) |
| Segment income & margin: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 61,899 |  |  | 2.8 | % |  | $ | 57,065 |  |  | 2.9 | % |
| Consumer Technologies Group | 24,634 |  |  | 1.9 | % |  | 38,843 |  |  | 2.5 | % |
| Industrial & Emerging Industries | 49,977 |  |  | 3.9 | % |  | 28,999 |  |  | 2.6 | % |
| High Reliability Solutions | 88,536 |  |  | 8.2 | % |  | 59,886 |  |  | 6.6 | % |
| Corporate and Other | (34,800 | ) |  |  |  | (25,711 | ) |  |  |
| Total segment income | 190,246 |  |  | 3.2 | % |  | 159,082 |  |  | 2.9 | % |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 21,598 |  |  |  |  | 7,671 |  |  |  |
| Stock-based compensation | 23,797 |  |  |  |  | 16,126 |  |  |  |
| Other charges, net | 3,529 |  |  |  |  | 164 |  |  |  |
| Interest and other, net | 24,399 |  |  |  |  | 16,505 |  |  |  |
| Income before income taxes | $ | 116,923 |  |  |  |  | $ | 118,616 |  |  |  |

[0001628280-16-017813:mdna:48]
CEC segment margin decreased 10 basis points to 2.8% for the three-month periods ended July 1, 2016, from 2.9% during the three-month period ended June 26, 2015, mostly reflective of incremental costs associated with our proactive repositioning of certain programs and actions to better align CEC's cost structure.

[0001628280-16-017813:mdna:49]
CTG segment margin decreased 60 basis points to 1.9% for the three-month period ended July 1, 2016, from 2.5% during the three-month period ended June 26, 2015, which reflects an under absorption of costs for the wind-down of production for our Lenovo/Motorola smartphone operations in China, and the overall decrease of revenue in our CTG segment.

[0001628280-16-017813:mdna:50]
IEI segment margin increased 130 basis points to 3.9% for the three-month period ended July 1, 2016, from 2.6% during the three-month period ended June 26, 2015, primarily due to contribution from our NEXTracker acquisition and additional flow through from revenue increases in our core IEI business, coupled with operational improvements for some of our previously under-performing programs.

[0001628280-16-017813:mdna:51]
HRS segment margin increased 160 basis points to 8.2% for the three-month period ended July 1, 2016, from 6.6% during the three-month period ended June 26, 2015, primarily due to new program launches and richer mix with greater value-added business engagements as a result of greater design and engineering solutions as part of our sketch to scaletm offering in our core HRS business, and contribution from our MCi acquisition.

[0001628280-16-017813:mdna:52]
[same as prior period, unchanged from 0001628280-16-010628:mdna:56]

[0001628280-16-017813:mdna:53]
Selling, general and administrative expenses (“SG&A”) was $239.5 million, or 4.1% of net sales, during the three-month period ended July 1, 2016, increasing $30.1 million from $209.4 million, or 3.8% of net sales, during the three-month period ended June 26, 2015. The increase in SG&A in dollars and as a percentage of net sales was primarily due to increases in stock-based compensation expense, incremental costs associated with our acquisitions of MCi and NEXTracker both of which drive a higher proportional SG&A level and further investments in design and engineering resources by the Company.

[0001628280-16-017813:mdna:54]
[same as prior period, unchanged from 0001628280-16-010628:mdna:58]

[0001628280-16-017813:mdna:55]
Amortization of intangible assets increased by $13.9 million during the three-month period ended July 1, 2016 to $21.6 million from $7.7 million for the three-month period ended June 26, 2015. The increase is primarily due to incremental

[0001628280-16-017813:mdna:56]
33

[0001628280-16-017813:mdna:57]
amortization expense on intangible assets relating to our acquisitions completed during fiscal year 2016, primarily MCi and NEXTracker.

[0001628280-16-017813:mdna:58]
[same as prior period, unchanged from 0001628280-16-010628:mdna:60]

[0001628280-16-017813:mdna:59]
Interest and other, net was $24.4 million during the three-month period ended July 1, 2016 compared to $16.5 million during the three-month period ended June 26, 2015. The increase in interest and other, net of $7.9 million was primarily due to $7.2 million of interest expense from the 4.750% Notes due June 15, 2025 issued during the first quarter of fiscal year 2016.

[0001628280-16-017813:mdna:60]
[same as prior period, unchanged from 0001628280-16-010628:mdna:66]

[0001628280-16-017813:mdna:61]
Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 13, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2016 for further discussion.

[0001628280-16-017813:mdna:62]
[same as prior period, unchanged from 0001628280-16-010628:mdna:68]

[0001628280-16-017813:mdna:63]
The consolidated effective tax rate was 9.6% for the three-month period ended July 1, 2016, and 6.5% for the three-month period ended June 26, 2015, and varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions, operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. We generate most of our revenues and profits from operations outside of Singapore. The effective tax rate for the three-month period ended July 1, 2016 is higher than the effective tax rate for the three-month period ended June 26, 2015 primarily due to a favorable audit settlement which resulted in the release of an accrual for uncertain tax positions in the first quarter of fiscal year 2016.

[0001628280-16-017813:mdna:64]
[same as prior period, unchanged from 0001628280-16-010628:mdna:70]

[0001628280-16-017813:mdna:65]
As of July 1, 2016, we had cash and cash equivalents of approximately $1.7 billion and bank and other borrowings of approximately $2.8 billion. We have a $1.5 billion revolving credit facility that expires in March 2019, under which there were no borrowings outstanding as of the end of the quarter. As of July 1, 2016, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0001628280-16-017813:mdna:66]
Cash provided by operating activities was $263.9 million during the three-month period ended July 1, 2016. This resulted from $105.7 million of net income for the period plus adjustments for $129.5 million of non-cash charges such as depreciation, amortization, and other impairment charges, and $28.7 million from changes in our operating assets and liabilities. These changes were mainly related to an increase in accounts payable due to timing of payments to suppliers, offset by an increase in inventory due to the ramping up of many new programs in our automotive, medical, and energy businesses.

[0001628280-16-017813:mdna:67]
[same as prior period, unchanged from 0001628280-16-010628:mdna:73]

[0001628280-16-017813:mdna:68]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
| Days in trade accounts receivable | 39 days |  | 46 days |
| Days in inventory | 59 days |  | 60 days |
| Days in accounts payable | 71 days |  | 78 days |
| Cash conversion cycle | 27 days |  | 28 days |

[0001628280-16-017813:mdna:69]
Days in trade accounts receivable was calculated as average accounts receivable, net of allowance for doubtful accounts, for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended July 1, 2016, days in trade accounts receivable decreased by 7 days compared to the three-month period ended June 26, 2015 largely due to an improvement in our collection efforts and timing of invoicing customers during the current period. Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $460.3 million and

[0001628280-16-017813:mdna:70]
$516.3 million for the quarters ended July 1, 2016 and June 26, 2015, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 8 to the condensed consolidated financial statements.

[0001628280-16-017813:mdna:71]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in inventory decreased by 1 day during the three-month period ended July 1, 2016, compared to the three-month period ended June 26, 2015, primarily as a result of higher sales activity in the current quarter.

[0001628280-16-017813:mdna:72]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable decreased by 7 days during the three-month period ended July 1, 2016, compared to the three-month period ended June 26, 2015, primarily due to timing of payments, combined with higher cost of sales.

[0001628280-16-017813:mdna:73]
Our cash conversion cycle was calculated as the sum of days of inventory and days of account receivables outstanding less days payable outstanding. Our cash conversion cycle declined 1 day during the three-month period ended July 1, 2016, compared to the three-month period ended June 26, 2015, due to the factors for each of the components in the calculation discussed above.

[0001628280-16-017813:mdna:74]
Cash used in investing activities was $111.8 million during the three-month period ended July 1, 2016. This resulted primarily from $143.4 million of net capital expenditures for property and equipment, reflecting focused investments to expand capability and capacity in support of our automotive and medical businesses and further investments in both automation and expanding technologies to support our innovation services. Offsets in other investing activities include $12.5 million received for the sale of a non-strategic business, and $26.8 million of proceeds from the sale of certain assets that were purchased on behalf of a customer and financed by a third party banking institution.

[0001628280-16-017813:mdna:75]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flow for the three-month period ended July 1, 2016 was $120.6 million compared to $225.4 million for the three-month period ended June 26, 2015. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0001628280-16-017813:mdna:76]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 263,932 |  |  | $ | 362,276 |  |
| Purchases of property and equipment | (159,103 | ) |  | (138,348 | ) |
| Proceeds from the disposition of property and equipment | 15,722 |  |  | 1,512 |  |
| Free cash flow | $ | 120,551 |  |  | $ | 225,440 |  |

[0001628280-16-017813:mdna:77]
Cash used in financing activities was $95.1 million during the three-month period ended July 1, 2016, which was primarily for the repurchase of our ordinary shares in the amount of $94.7 million, and $92.2 million for repayment of bank borrowings and long-term debt. These cash outflows were partially offset by $75.0 million of net proceeds from bank borrowings and long-term debt.

[0001628280-16-017813:mdna:78]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of July 1, 2016 and March 31, 2016, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to

[0001628280-16-017813:mdna:79]
35

[0001628280-16-017813:mdna:80]
income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $916.0 million as of March 31, 2016). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0001628280-16-017813:mdna:81]
[same as prior period, unchanged from 0001628280-16-010628:mdna:85]

[0001628280-16-017813:mdna:82]
[same as prior period, unchanged from 0001628280-16-010628:mdna:86]

[0001628280-16-017813:mdna:83]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0001628280-16-017813:mdna:84]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 20, 2015. During the three-month period ended July 1, 2016, we paid $94.7 million to repurchase shares at an average price of $12.44 per share. As of July 1, 2016, shares in the aggregate amount of $151.1 million were available to be repurchased under the current plan.

[0001628280-16-017813:mdna:85]
[same as prior period, unchanged from 0001628280-16-010628:mdna:89]

[0001628280-16-017813:mdna:86]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2016. There have been no material changes in our contractual obligations and commitments since March 31, 2016.

[0001628280-16-017813:mdna:87]
[same as prior period, unchanged from 0001628280-16-010628:mdna:91]

[0001628280-16-017813:mdna:88]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of July 1, 2016 and March 31, 2016, the fair values of our deferred purchase price receivable were approximately $460.3 million and $501.1 million, respectively. As of July 1, 2016 and March 31, 2016, the outstanding balances on receivables sold for cash were $1.2 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information see note 8 to the condensed consolidated financial statements.
