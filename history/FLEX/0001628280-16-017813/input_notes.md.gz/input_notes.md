# FLEX notes — 0001628280-16-017813


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0001628280-16-017813:notes:1]
[same as prior period, unchanged from 0001628280-16-010628:notes:6]

[0001628280-16-017813:notes:2]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
|  | (In thousands) |
| Beginning balance | $ | 501,097 |  |  | $ | 600,672 |  |
| Transfers of receivables | 762,184 |  |  | 767,048 |  |
| Collections | (802,947 | ) |  | (851,433 | ) |
| Ending balance | $ | 460,334 |  |  | $ | 516,287 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001628280-16-017813:notes:3]
[same as prior period, unchanged from 0001628280-16-010628:notes:8]

[0001628280-16-017813:notes:4]
Flextronics International Ltd. (“Parent”) has three tranches of Notes of $500 million, $500 million, and $600 million, respectively, each outstanding, which mature on February 15, 2020, February 15, 2023 and June 15, 2025, respectively. These Notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company’s 100% owned subsidiaries (the “guarantor subsidiaries”). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade, provided that each rating agency confirms that the Notes will continue to be rated investment grade after the Note Guaranties are terminated.

[0001628280-16-017813:notes:5]
In lieu of providing separate financial statements for the guarantor subsidiaries, the Company has included the accompanying condensed consolidating financial statements, which are presented using the equity method of accounting. The principal elimination entries relate to investment in subsidiaries and intercompany balances and transactions, including transactions with the Company’s non-guarantor subsidiaries.

[0001628280-16-017813:notes:6]
Condensed Consolidating Balance Sheets as of July 1, 2016

[0001628280-16-017813:notes:7]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 431,588 |  |  | $ | 118,892 |  |  | $ | 1,128,855 |  |  | $ | — |  |  | $ | 1,679,335 |  |
| Accounts receivable | — |  |  | 819,169 |  |  | 1,238,774 |  |  | — |  |  | 2,057,943 |  |
| Inventories | — |  |  | 1,536,360 |  |  | 2,058,477 |  |  | — |  |  | 3,594,837 |  |
| Inter company receivable | 9,624,074 |  |  | 5,918,488 |  |  | 12,736,490 |  |  | (28,279,052 | ) |  | — |  |
| Other current assets | 1,740 |  |  | 182,510 |  |  | 904,594 |  |  | — |  |  | 1,088,844 |  |
| Total current assets | 10,057,402 |  |  | 8,575,419 |  |  | 18,067,190 |  |  | (28,279,052 | ) |  | 8,420,959 |  |
| Property and equipment, net | — |  |  | 561,046 |  |  | 1,735,399 |  |  | — |  |  | 2,296,445 |  |
| Goodwill and other intangible assets, net | 100 |  |  | 60,173 |  |  | 1,264,341 |  |  | — |  |  | 1,324,614 |  |
| Other assets | 2,232,494 |  |  | 269,927 |  |  | 2,001,920 |  |  | (4,037,835 | ) |  | 466,506 |  |
| Investment in subsidiaries | 2,675,293 |  |  | 3,174,268 |  |  | 18,214,271 |  |  | (24,063,832 | ) |  | — |  |
| Total assets | $ | 14,965,289 |  |  | $ | 12,640,833 |  |  | $ | 41,283,121 |  |  | $ | (56,380,719 | ) |  | $ | 12,508,524 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 58,836 |  |  | $ | 946 |  |  | $ | 6,238 |  |  | $ | — |  |  | $ | 66,020 |  |
| Accounts payable | — |  |  | 1,477,964 |  |  | 2,839,607 |  |  | — |  |  | 4,317,571 |  |
| Accrued payroll | — |  |  | 136,897 |  |  | 240,630 |  |  | — |  |  | 377,527 |  |
| Inter company payable | 9,557,901 |  |  | 8,546,945 |  |  | 10,174,206 |  |  | (28,279,052 | ) |  | — |  |
| Other current liabilities | 26,524 |  |  | 809,796 |  |  | 1,030,265 |  |  | — |  |  | 1,866,585 |  |
| Total current liabilities | 9,643,261 |  |  | 10,972,548 |  |  | 14,290,946 |  |  | (28,279,052 | ) |  | 6,627,703 |  |
| Long term liabilities | 2,698,621 |  |  | 2,059,725 |  |  | 2,493,716 |  |  | (4,037,835 | ) |  | 3,214,227 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) | 2,623,407 |  |  | (391,440 | ) |  | 24,455,272 |  |  | (24,063,832 | ) |  | 2,623,407 |  |
| Noncontrolling interests | — |  |  | — |  |  | 43,187 |  |  | — |  |  | 43,187 |  |
| Total shareholders’ equity (deficit) | 2,623,407 |  |  | (391,440 | ) |  | 24,498,459 |  |  | (24,063,832 | ) |  | 2,666,594 |  |
| Total liabilities and shareholders’ equity | $ | 14,965,289 |  |  | $ | 12,640,833 |  |  | $ | 41,283,121 |  |  | $ | (56,380,719 | ) |  | $ | 12,508,524 |  |

[0001628280-16-017813:notes:8]
Condensed Consolidating Balance Sheets as of March 31, 2016

[0001628280-16-017813:notes:9]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 734,869 |  |  | $ | 148,201 |  |  | $ | 724,500 |  |  | $ | — |  |  | $ | 1,607,570 |  |
| Accounts receivable | — |  |  | 729,331 |  |  | 1,315,426 |  |  | — |  |  | 2,044,757 |  |
| Inventories | — |  |  | 1,482,410 |  |  | 2,009,246 |  |  | — |  |  | 3,491,656 |  |
| Inter company receivable | 9,105,728 |  |  | 5,568,392 |  |  | 12,404,722 |  |  | (27,078,842 | ) |  | — |  |
| Other current assets | 2,951 |  |  | 180,842 |  |  | 987,350 |  |  | — |  |  | 1,171,143 |  |
| Total current assets | 9,843,548 |  |  | 8,109,176 |  |  | 17,441,244 |  |  | (27,078,842 | ) |  | 8,315,126 |  |
| Property and equipment, net | — |  |  | 553,072 |  |  | 1,704,561 |  |  | — |  |  | 2,257,633 |  |
| Goodwill and other intangible assets, net | 175 |  |  | 60,895 |  |  | 1,284,750 |  |  | — |  |  | 1,345,820 |  |
| Other assets | 2,249,145 |  |  | 267,034 |  |  | 2,004,437 |  |  | (4,054,214 | ) |  | 466,402 |  |
| Investment in subsidiaries | 2,815,426 |  |  | 3,010,111 |  |  | 18,175,348 |  |  | (24,000,885 | ) |  | — |  |
| Total assets | $ | 14,908,294 |  |  | $ | 12,000,288 |  |  | $ | 40,610,340 |  |  | $ | (55,133,941 | ) |  | $ | 12,384,981 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 58,836 |  |  | $ | 946 |  |  | $ | 5,384 |  |  | $ | — |  |  | $ | 65,166 |  |
| Accounts payable | — |  |  | 1,401,835 |  |  | 2,846,457 |  |  | — |  |  | 4,248,292 |  |
| Accrued payroll | — |  |  | 114,509 |  |  | 239,038 |  |  | — |  |  | 353,547 |  |
| Inter company payable | 9,562,405 |  |  | 7,999,335 |  |  | 9,517,102 |  |  | (27,078,842 | ) |  | — |  |
| Other current liabilities | 33,008 |  |  | 869,470 |  |  | 1,002,722 |  |  | — |  |  | 1,905,200 |  |
| Total current liabilities | 9,654,249 |  |  | 10,386,095 |  |  | 13,610,703 |  |  | (27,078,842 | ) |  | 6,572,205 |  |
| Long term liabilities | 2,683,173 |  |  | 2,063,988 |  |  | 2,514,299 |  |  | (4,054,214 | ) |  | 3,207,246 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) | 2,570,872 |  |  | (449,795 | ) |  | 24,450,680 |  |  | (24,000,885 | ) |  | 2,570,872 |  |
| Noncontrolling interests | — |  |  | — |  |  | 34,658 |  |  | — |  |  | 34,658 |  |
| Total shareholders’ equity (deficit) | 2,570,872 |  |  | (449,795 | ) |  | 24,485,338 |  |  | (24,000,885 | ) |  | 2,605,530 |  |
| Total liabilities and shareholders’ equity | $ | 14,908,294 |  |  | $ | 12,000,288 |  |  | $ | 40,610,340 |  |  | $ | (55,133,941 | ) |  | $ | 12,384,981 |  |

[0001628280-16-017813:notes:10]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended July 1, 2016

[0001628280-16-017813:notes:11]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 3,830,352 |  |  | $ | 4,336,646 |  |  | $ | (2,290,185 | ) |  | $ | 5,876,813 |  |
| Cost of sales | — |  |  | 3,413,282 |  |  | 4,347,721 |  |  | (2,290,185 | ) |  | 5,470,818 |  |
| Gross profit (loss) | — |  |  | 417,070 |  |  | (11,075 | ) |  | — |  |  | 405,995 |  |
| Selling, general and administrative expenses | — |  |  | 69,969 |  |  | 169,577 |  |  | — |  |  | 239,546 |  |
| Intangible amortization | 75 |  |  | 717 |  |  | 20,806 |  |  | — |  |  | 21,598 |  |
| Interest and other, net | (316,390 | ) |  | 416,317 |  |  | (71,999 | ) |  | — |  |  | 27,928 |  |
| Income (loss) from continuing operations before income taxes | 316,315 |  |  | (69,933 | ) |  | (129,459 | ) |  | — |  |  | 116,923 |  |
| Provision for income taxes | — |  |  | 595 |  |  | 10,599 |  |  | — |  |  | 11,194 |  |
| Equity in earnings in subsidiaries | (210,586 | ) |  | (727 | ) |  | (22,105 | ) |  | 233,418 |  |  | — |  |
| Net income (loss) | $ | 105,729 |  |  | $ | (71,255 | ) |  | $ | (162,163 | ) |  | $ | 233,418 |  |  | $ | 105,729 |  |

[0001628280-16-017813:notes:12]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended June 26, 2015

[0001628280-16-017813:notes:13]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 4,046,385 |  |  | $ | 3,935,515 |  |  | $ | (2,415,652 | ) |  | $ | 5,566,248 |  |
| Cost of sales | — |  |  | 3,644,059 |  |  | 3,985,500 |  |  | (2,415,652 | ) |  | 5,213,907 |  |
| Gross profit (loss) | — |  |  | 402,326 |  |  | (49,985 | ) |  | — |  |  | 352,341 |  |
| Selling, general and administrative expenses | — |  |  | 63,559 |  |  | 145,826 |  |  | — |  |  | 209,385 |  |
| Intangible amortization | 75 |  |  | 960 |  |  | 6,636 |  |  | — |  |  | 7,671 |  |
| Interest and other, net | (267,052 | ) |  | 336,992 |  |  | (53,271 | ) |  | — |  |  | 16,669 |  |
| Income (loss) from continuing operations before income taxes | 266,977 |  |  | 815 |  |  | (149,176 | ) |  | — |  |  | 118,616 |  |
| Provision for (benefit from) income taxes | — |  |  | 9,099 |  |  | (1,333 | ) |  | — |  |  | 7,766 |  |
| Equity in earnings in subsidiaries | (156,127 | ) |  | (17,826 | ) |  | 37,047 |  |  | 136,906 |  |  | — |  |
| Net income (loss) | $ | 110,850 |  |  | $ | (26,110 | ) |  | $ | (110,796 | ) |  | $ | 136,906 |  |  | $ | 110,850 |  |

[0001628280-16-017813:notes:14]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended July 1, 2016

[0001628280-16-017813:notes:15]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 105,729 |  |  | $ | (71,255 | ) |  | $ | (162,163 | ) |  | $ | 233,418 |  |  | $ | 105,729 |  |
| Other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 9,861 |  |  | 17,709 |  |  | 24,763 |  |  | (42,472 | ) |  | 9,861 |  |
| Unrealized gain on derivative instruments and other, net of zero tax | 1,348 |  |  | 2,449 |  |  | 1,348 |  |  | (3,797 | ) |  | 1,348 |  |
| Comprehensive income (loss) | $ | 116,938 |  |  | $ | (51,097 | ) |  | $ | (136,052 | ) |  | $ | 187,149 |  |  | $ | 116,938 |  |

[0001628280-16-017813:notes:16]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended June 26, 2015

[0001628280-16-017813:notes:17]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income | $ | 110,850 |  |  | $ | (26,110 | ) |  | $ | (110,796 | ) |  | $ | 136,906 |  |  | $ | 110,850 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 2,783 |  |  | (23,490 | ) |  | (20,897 | ) |  | 44,387 |  |  | 2,783 |  |
| Unrealized gain on derivative instruments and other, net of zero tax | 12,829 |  |  | 4,624 |  |  | 12,829 |  |  | (17,453 | ) |  | 12,829 |  |
| Comprehensive income (loss) | $ | 126,462 |  |  | $ | (44,976 | ) |  | $ | (118,864 | ) |  | $ | 163,840 |  |  | $ | 126,462 |  |

[0001628280-16-017813:notes:18]
Condensed Consolidating Statements of Cash Flows for the Three-Month Period Ended July 1, 2016

[0001628280-16-017813:notes:19]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 300,435 |  |  | $ | (217,862 | ) |  | $ | 181,392 |  |  | $ | (33 | ) |  | $ | 263,932 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (39,399 | ) |  | (103,976 | ) |  | (6 | ) |  | (143,381 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | (8,888 | ) |  | (604 | ) |  | — |  |  | (9,492 | ) |
| Proceeds from divesture of business, net of cash held in divested business | — |  |  | — |  |  | 14,828 |  |  | — |  |  | 14,828 |  |
| Investing cash flows to affiliates | (481,875 | ) |  | (816,210 | ) |  | (653,366 | ) |  | 1,951,451 |  |  | — |  |
| Other investing activities, net | 1 |  |  | (1,260 | ) |  | 27,520 |  |  | — |  |  | 26,261 |  |
| Net cash used in investing activities | (481,874 | ) |  | (865,757 | ) |  | (715,598 | ) |  | 1,951,445 |  |  | (111,784 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 74,972 |  |  | — |  |  | 46 |  |  | — |  |  | 75,018 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (90,000 | ) |  | (1,152 | ) |  | (1,070 | ) |  |  |  |  | (92,222 | ) |
| Payments for repurchases of ordinary shares | (94,715 | ) |  | — |  |  | — |  |  | — |  |  | (94,715 | ) |
| Net proceeds from issuance of ordinary shares | 3,966 |  |  | — |  |  | — |  |  | — |  |  | 3,966 |  |
| Financing cash flows (to) from affiliates | (30,704 | ) |  | 1,056,584 |  |  | 925,532 |  |  | (1,951,412 | ) |  | — |  |
| Other financing activities, net | 30,000 |  |  | — |  |  | (17,099 | ) |  | — |  |  | 12,901 |  |
| Net cash (used in) provided by financing activities | (106,481 | ) |  | 1,055,432 |  |  | 907,409 |  |  | (1,951,412 | ) |  | (95,052 | ) |
| Effect of exchange rates on cash and cash equivalents | (15,361 | ) |  | (1,122 | ) |  | 31,152 |  |  | — |  |  | 14,669 |  |
| Net increase (decrease) in cash and cash equivalents | (303,281 | ) |  | (29,309 | ) |  | 404,355 |  |  | — |  |  | 71,765 |  |
| Cash and cash equivalents, beginning of period | 734,869 |  |  | 148,201 |  |  | 724,500 |  |  | — |  |  | 1,607,570 |  |
| Cash and cash equivalents, end of period | $ | 431,588 |  |  | $ | 118,892 |  |  | $ | 1,128,855 |  |  | $ | — |  |  | $ | 1,679,335 |  |

[0001628280-16-017813:notes:20]
Condensed Consolidating Statements of Cash Flows for the Three-Month Period Ended June 26, 2015

[0001628280-16-017813:notes:21]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 280,844 |  |  | $ | (4,684 | ) |  | $ | 86,116 |  |  | $ | — |  |  | $ | 362,276 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (47,108 | ) |  | (89,728 | ) |  | — |  |  | (136,836 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | (2,785 | ) |  | (15,795 | ) |  | — |  |  | (18,580 | ) |
| Proceeds from divestiture of business, net of cash held in divested business | — |  |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Investing cash flows to affiliates | (720,048 | ) |  | (162,774 | ) |  | (1,176,220 | ) |  | 2,059,042 |  |  | — |  |
| Other investing activities, net | — |  |  | (14,787 | ) |  | 7,207 |  |  | — |  |  | (7,580 | ) |
| Net cash used in investing activities | (720,048 | ) |  | (227,454 | ) |  | (1,273,536 | ) |  | 2,059,042 |  |  | (161,996 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 595,309 |  |  | 221 |  |  | 18 |  |  | — |  |  | 595,548 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (6,604 | ) |  | (493 | ) |  | (1,360 | ) |  | — |  |  | (8,457 | ) |
| Payments for repurchases of ordinary shares | (99,995 | ) |  | — |  |  | — |  |  | — |  |  | (99,995 | ) |
| Net proceeds from issuance of ordinary shares | 44,602 |  |  | — |  |  | — |  |  | — |  |  | 44,602 |  |
| Financing cash flows from affiliates | 619,970 |  |  | 274,540 |  |  | 1,164,532 |  |  | (2,059,042 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | (25,252 | ) |  | — |  |  | (25,252 | ) |
| Net cash provided by financing activities | 1,153,282 |  |  | 274,268 |  |  | 1,137,938 |  |  | (2,059,042 | ) |  | 506,446 |  |
| Effect of exchange rates on cash and cash equivalents | 24,362 |  |  | (961 | ) |  | (27,124 | ) |  | — |  |  | (3,723 | ) |
| Net increase (decrease) in cash and cash equivalents | 738,440 |  |  | 41,169 |  |  | (76,606 | ) |  | — |  |  | 703,003 |  |
| Cash and cash equivalents, beginning of period | 608,971 |  |  | 168,272 |  |  | 851,165 |  |  | — |  |  | 1,628,408 |  |
| Cash and cash equivalents, end of period | $ | 1,347,411 |  |  | $ | 209,441 |  |  | $ | 774,559 |  |  | $ | — |  |  | $ | 2,331,411 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-16-017813:notes:22]
Basis of Presentation

[0001628280-16-017813:notes:23]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2016 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended July 1, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017.

[0001628280-16-017813:notes:24]
The first quarters for fiscal year 2017 and fiscal year 2016 ended on July 1, 2016, which is comprised of 92 days in the period, and June 26, 2015, which is comprised of 87 days in the period, respectively.

[0001628280-16-017813:notes:25]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The associated noncontrolling owners' interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

[0001628280-16-017813:notes:26]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting.  The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has an ownership percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%.  The equity in earnings (losses) of equity method investees are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-16-017813:notes:27]
BUSINESS AND ASSETS ACQUISITIONS & DIVESTITURES

[0001628280-16-017813:notes:28]
On May 16, 2016, the Company acquired 100% of the outstanding share capital of a software architecture and data science solutions company, which strengthens the Company's capabilities in the energy market within the IEI segment. The Company paid $8.9 million, net of $0.2 million of cash acquired. The property and equipment acquired and liabilities assumed were not material to the Company's consolidated financial results. The Company also recorded $9.5 million of goodwill and intangibles of $1.7 million, and assumed the equity incentive plan of the acquiree. Results of operations were included in the Company’s condensed consolidated financial results beginning on the date of acquisition, and was not material to the Company’s consolidated financial results for the three-month period ended July 1, 2016.

[0001628280-16-017813:notes:29]
During the three-month period ended July 1, 2016, the Company disposed of a non-strategic business within the HRS segment. The Company received $12.5 million of proceeds, net of an immaterial amount of cash held in the divested business. The property and equipment sold and liabilities transferred were not material to the Company's consolidated financial results. The loss on disposition was not material to the Company’s consolidated financial results, and is included in other charges, net in the condensed consolidated statements of operations for the three-month period ended July 1, 2016.

[0001628280-16-017813:notes:30]
Pro-forma results of operations for the acquisition have not been presented, because the effects were immaterial to the Company’s financial results for all periods presented.

[0001628280-16-017813:notes:31]
[same as prior period, unchanged from 0001628280-16-010628:notes:53]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-16-017813:notes:32]
COMMITMENTS AND CONTINGENCIES

[0001628280-16-017813:notes:33]
During the third quarter of fiscal 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice was for nine months of calendar year 2010 for an alleged amount of 52 million Brazilian reals (approximately USD $16 million based on the exchange rate as of July 1, 2016) plus interest. This assessment is in the second stage of the review process at the administrative level. During the fourth quarter of fiscal year 2016, the same Brazilian subsidiary received a further assessment related to the same import taxes of an additional 57 million Brazilian reals (approximately USD $18 million based on the exchange rate as of July 1, 2016) plus interest. This assessment is in the first stage of the review process at the administrative level. The Company plans to continue to vigorously oppose both of these assessments, as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on either of these claims for several years.

[0001628280-16-017813:notes:34]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of an approximately USD $100 million related to income and social contribution taxes, interest and penalties. During the first quarter of fiscal year 2017, the Company received a final favorable judgment in the judicial process reversing the assessment and the case is now closed. As the Company had previously determined there was no legal basis for the assessment, no adjustment was required to be recorded during the first quarter of fiscal year 2017.

[0001628280-16-017813:notes:35]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-16-017813:notes:36]
[same as prior period, unchanged from 0001628280-16-010628:notes:59]

[0001628280-16-017813:notes:37]
[same as prior period, unchanged from 0001628280-16-010628:notes:60]

[0001628280-16-017813:notes:38]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |  | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |
| Other comprehensive gain (loss) before reclassifications | 1,493 |  |  | 10,086 |  |  | 11,579 |  |  | (601 | ) |  | 2,631 |  |  | 2,030 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (145 | ) |  | (225 | ) |  | (370 | ) |  | 13,430 |  |  | 152 |  |  | 13,582 |  |
| Net current-period other comprehensive gain | 1,348 |  |  | 9,861 |  |  | 11,209 |  |  | 12,829 |  |  | 2,783 |  |  | 15,612 |  |
| Ending balance | $ | (40,174 | ) |  | $ | (84,532 | ) |  | $ | (124,706 | ) |  | $ | (55,437 | ) |  | $ | (109,456 | ) |  | $ | (164,893 | ) |

[0001628280-16-017813:notes:39]
Net gains reclassified from accumulated other comprehensive loss during the three-month period ended July 1, 2016 relating to derivative instruments and other includes $0.6 million attributable to the Company’s cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations.

[0001628280-16-017813:notes:40]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month periods ended June 26, 2015, was recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-16-017813:notes:41]
[same as prior period, unchanged from 0001628280-16-010628:notes:83]

[0001628280-16-017813:notes:42]
[same as prior period, unchanged from 0001628280-16-010628:notes:84]

[0001628280-16-017813:notes:43]
The Company primarily enters into forward contracts and foreign currency swap contracts to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions. The Company hedges committed exposures and does not engage in speculative transactions. As of July 1, 2016, the aggregate notional amount of the Company’s outstanding foreign currency contracts was $4.1 billion as summarized below:

[0001628280-16-017813:notes:44]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  |  |
| CNY |  | 912,000 |  |  | — |  |  | $ | 137,283 |  |  | $ | — |  |
| EUR |  | 38,380 |  |  | 131,471 |  |  | 42,616 |  |  | 149,493 |  |
| HUF |  | 15,656,000 |  |  | — |  |  | 54,854 |  |  | — |  |
| ILS |  | 101,600 |  |  | — |  |  | 26,359 |  |  | — |  |
| INR |  | 1,200,326 |  |  | — |  |  | 17,300 |  |  | — |  |
| MXN |  | 1,596,000 |  |  | — |  |  | 86,154 |  |  | — |  |
| MYR |  | 184,000 |  |  | 10,000 |  |  | 45,590 |  |  | 2,478 |  |
| RON |  | 71,600 |  |  | — |  |  | 17,567 |  |  | — |  |
| Other |  | N/A |  |  | N/A |  |  | 35,075 |  |  | — |  |
|  |  |  |  |  |  |  |  | 462,798 |  |  | 151,971 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 387,000 |  |  | — |  |  | 119,618 |  |
| CHF |  | 7,341 |  |  | 24,799 |  |  | 7,493 |  |  | 25,317 |  |
| CNY |  | 889,314 |  |  | — |  |  | 133,700 |  |  | — |  |
| DKK |  | 198,100 |  |  | 157,200 |  |  | 29,573 |  |  | 23,468 |  |
| EUR |  | 827,266 |  |  | 1,019,015 |  |  | 919,695 |  |  | 1,133,079 |  |
| GBP |  | 33,926 |  |  | 59,056 |  |  | 46,021 |  |  | 80,247 |  |
| HUF |  | 44,240,000 |  |  | 40,598,000 |  |  | 155,005 |  |  | 142,244 |  |
| ILS |  | 128,800 |  |  | 124,420 |  |  | 33,416 |  |  | 32,280 |  |
| INR |  | 5,510,229 |  |  | 13,599 |  |  | 81,695 |  |  | 200 |  |
| MXN |  | 1,578,370 |  |  | 353,640 |  |  | 85,202 |  |  | 19,090 |  |
| MYR |  | 348,847 |  |  | 33,900 |  |  | 86,434 |  |  | 8,399 |  |
| PLN |  | 107,804 |  |  | 59,773 |  |  | 27,076 |  |  | 15,013 |  |
| RON |  | 102,172 |  |  | 85,811 |  |  | 25,068 |  |  | 21,054 |  |
| SEK |  | 450,235 |  |  | 817,956 |  |  | 53,085 |  |  | 96,704 |  |
| Other |  | N/A |  |  | N/A |  |  | 57,985 |  |  | 26,215 |  |
|  |  |  |  |  |  |  |  | 1,741,448 |  |  | 1,742,928 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  |  | $ | 2,204,246 |  |  | $ | 1,894,899 |  |

[0001628280-16-017813:notes:45]
As of July 1, 2016, the fair value of the Company’s short-term foreign currency contracts was not material and is included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of July 1, 2016 and March 31, 2016, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred gains were $1.6 million as of July 1, 2016, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0001628280-16-017813:notes:46]
[same as prior period, unchanged from 0001628280-16-010628:notes:88]

[0001628280-16-017813:notes:47]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | July 1, 2016 |  | March 31, 2016 |  | Balance SheetLocation |  | July 1, 2016 |  | March 31, 2016 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 6,645 |  |  | $ | 5,510 |  |  | Other current liabilities |  | $ | 4,424 |  |  | $ | 2,446 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 10,744 |  |  | $ | 17,138 |  |  | Other current liabilities |  | $ | 7,434 |  |  | $ | 18,645 |  |

[0001628280-16-017813:notes:48]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any of the periods presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-017813:notes:49]
[same as prior period, unchanged from 0001628280-16-010628:notes:91]

[0001628280-16-017813:notes:50]
The Company's primary plan used for granting equity compensation awards is the 2010 Equity Incentive Plan (the "2010 Plan").

[0001628280-16-017813:notes:51]
During fiscal year 2016, in conjunction with the acquisition of NEXTracker Inc. ("NEXTracker"), the Company assumed all of the outstanding, unvested share bonus awards and outstanding, unvested options to purchase shares of common stock of NEXTracker, and converted all of these shares into Flex awards. As a result, the Company now offers the 2014 NEXTracker Equity Incentive Plan (the "NEXTracker Plan").

[0001628280-16-017813:notes:52]
Further, during the first quarter of fiscal year 2017, in conjunction with an immaterial acquisition, the Company assumed all of the outstanding, unvested options to purchase shares of common stock of the acquiree, and converted all of these shares into Flex awards. As a result, the Company now offers an additional equity compensation plan, the BrightBox Technologies 2013 Plan (the "BrightBox Plan").

[0001628280-16-017813:notes:53]
The Company early adopted new guidance intended to reduce cost and complexity of the accounting for share-based payments, as discussed further in note 1.

[0001628280-16-017813:notes:54]
[same as prior period, unchanged from 0001628280-16-010628:notes:93]

[0001628280-16-017813:notes:55]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
|  | (In thousands) |
| Cost of sales | $ | 2,433 |  |  | $ | 2,018 |  |
| Selling, general and administrative expenses | 21,364 |  |  | 14,108 |  |
| Total share-based compensation expense | $ | 23,797 |  |  | $ | 16,126 |  |

[0001628280-16-017813:notes:56]
[same as prior period, unchanged from 0001628280-16-010628:notes:95]

[0001628280-16-017813:notes:57]
Total unrecognized compensation expense related to share options under the 2010 Plan is not significant. As of July 1, 2016, the number of options outstanding and exercisable under the 2010 Plan was 1.2 million at a weighted-average exercise price of $8.49 per share, for both.

[0001628280-16-017813:notes:58]
During the three-month period ended July 1, 2016, the Company granted 5.6 million unvested share bonus awards under the 2010 Plan. Of this amount, approximately 4.7 million unvested share bonus awards have an average grant date price of $12.80 per share. Further, approximately 0.7 million of these unvested shares represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $17.57 per award and was calculated using a Monte Carlo simulation. The remaining 0.2 million of unvested shares bonus awards under the 2010 Plan have an average grant date price of $12.82 per share and represents the target amount of grants made to certain executive officers whereby vesting is contingent on meeting certain free cash flow targets. The number of shares under the 2010 Plan, contingent on market conditions that ultimately will vest range from zero up to a maximum of 1.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met. The number of shares under the 2010 Plan, contingent on free cash flow targets that ultimately will vest range from zero up to a maximum of 0.4 million of the target payment based on a measurement of cumulative three-year increase of free cash flow from operations of the Company, and will cliff vest after a period of three years.

[0001628280-16-017813:notes:59]
As of July 1, 2016, approximately 16.4 million unvested share bonus awards under the 2010 Plan were outstanding, of which vesting for a targeted amount of 2.3 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 4.6 million based on the achievement levels of the respective conditions. During the three-month period ended July 1, 2016, 3.5 million shares under the 2010 Plan vested in connection with the share bonus awards with market conditions granted in fiscal year 2014.

[0001628280-16-017813:notes:60]
As of July 1, 2016, total unrecognized compensation expense related to unvested share bonus awards under the 2010 Plan is $177.4 million, and will be recognized over a weighted-average remaining vesting period of 3.0 years. Approximately $30.1 million of the total unrecognized compensation cost, is related to awards under the 2010 Plan whereby vesting is contingent on meeting certain market conditions.

[0001628280-16-017813:notes:61]
[same as prior period, unchanged from 0001628280-16-010628:notes:100]

[0001628280-16-017813:notes:62]
All shares previously granted under the NEXTracker plan are the result of the Company's conversion of all outstanding, unvested shares of NEXTracker into unvested shares of the Company, as part of the acquisition. Therefore, no additional share options or share bonus awards were granted by the Company during the three-month period ended July 1, 2016.

[0001628280-16-017813:notes:63]
As of July 1, 2016, total unrecognized compensation expense related to share options under the NEXTracker Plan is $14.0 million, and will be recognized over a weighted-average remaining vesting period of 2.6 years. As of July 1, 2016, the number of options outstanding and exercisable was 2.4 million and 0.3 million, respectively, at a weighted-average exercise price of $3.79 per share and $5.35 per share, respectively.

[0001628280-16-017813:notes:64]
As of July 1, 2016, approximately 2.3 million unvested share bonus awards were outstanding.  The total unrecognized compensation expense related to these unvested share bonus awards under the NEXTracker Plan is $16.5 million, and will be recognized over a weighted-average remaining vesting period of 2.1 years.

[0001628280-16-017813:notes:65]
The BrightBox Technologies 2013 Plan

[0001628280-16-017813:notes:66]
During the three-month period ended July 1, 2016, the Company granted 0.2 million share options under the BrightBox Plan, at an average grant date fair value price of $11.99 per share, and with a vesting period of three years from the vesting commencement date. All shares granted under the BrightBox plan are the result of the Company's conversion of all outstanding, unvested shares of BrightBox into unvested shares of the Company, as part of the acquisition. No additional grants will be made out of this plan in the future.

[0001628280-16-017813:notes:67]
As of July 1, 2016, total unrecognized compensation expense related to share options under the BrightBox Plan is $1.8 million, and will be recognized over a weighted-average remaining vesting period of 2.9 years. As of July 1, 2016, the number of options outstanding was 0.2 million, at a weighted-average exercise price of $0.51 per share. No options under this plan were exercisable as of July 1, 2016.


## us-gaap:EarningsPerShareTextBlock

[0001628280-16-017813:notes:68]
[same as prior period, unchanged from 0001628280-16-010628:notes:106]

[0001628280-16-017813:notes:69]
[same as prior period, unchanged from 0001628280-16-010628:notes:107]

[0001628280-16-017813:notes:70]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
|  | (In thousands, except per share amounts) |
| Net income | $ | 105,729 |  |  | $ | 110,850 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 544,631 |  |  | 565,545 |  |
| Basic earnings per share | 0.19 |  |  | 0.20 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 105,729 |  |  | $ | 110,850 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 544,631 |  |  | 565,545 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) | 6,398 |  |  | 12,452 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 551,029 |  |  | 577,997 |  |
| Diluted earnings per share | 0.19 |  |  | 0.19 |  |

[0001628280-16-017813:notes:71]
____________________________________________________________

[0001628280-16-017813:notes:72]
(1)         Options to purchase ordinary shares of 1.0 million and 2.0 million during the three-month periods ended July 1, 2016 and June 26, 2015, respectively, and share bonus awards of 0.8 million for the three-month period ended July 1, 2016, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. No anti-dilutive share bonus awards were excluded for the three-month period ended June 26, 2015.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-16-017813:notes:73]
[same as prior period, unchanged from 0001628280-16-010628:notes:111]

[0001628280-16-017813:notes:74]
[same as prior period, unchanged from 0001628280-16-010628:notes:112]

[0001628280-16-017813:notes:75]
[same as prior period, unchanged from 0001628280-16-010628:notes:113]

[0001628280-16-017813:notes:76]
[same as prior period, unchanged from 0001628280-16-010628:notes:114]

[0001628280-16-017813:notes:77]
[same as prior period, unchanged from 0001628280-16-010628:notes:115]

[0001628280-16-017813:notes:78]
[same as prior period, unchanged from 0001628280-16-010628:notes:116]

[0001628280-16-017813:notes:79]
[same as prior period, unchanged from 0001628280-16-010628:notes:117]

[0001628280-16-017813:notes:80]
[same as prior period, unchanged from 0001628280-16-010628:notes:118]

[0001628280-16-017813:notes:81]
[same as prior period, unchanged from 0001628280-16-010628:notes:119]

[0001628280-16-017813:notes:82]
[same as prior period, unchanged from 0001628280-16-010628:notes:120]

[0001628280-16-017813:notes:83]
The fair value of the liability was estimated using a simulation-based measurement technique with significant inputs that are not observable in the market and thus represents a level 3 fair value measurement. The significant inputs in the fair value measurement not supported by market activity included the Company's probability assessments of expected future revenue during the earn-out period and associated volatility, appropriately discounted considering the uncertainties associated with the obligation, and calculated in accordance with the terms of the merger agreement. Significant decreases in expected revenue during the earn-out period, or significant increases in the discount rate or volatility in isolation would result in lower fair value estimates. The interrelationship between these inputs is not considered significant.

[0001628280-16-017813:notes:84]
[same as prior period, unchanged from 0001628280-16-010628:notes:123]

[0001628280-16-017813:notes:85]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
|  | (In thousands) |
| Beginning balance | $ | 73,423 |  |  | $ | 4,500 |  |
| Additions to accrual | — |  |  | — |  |
| Payments | — |  |  | — |  |
| Fair value adjustments | 1,835 |  |  | — |  |
| Ending balance | $ | 75,258 |  |  | $ | 4,500 |  |

[0001628280-16-017813:notes:86]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not meaningful. The interrelationship between these inputs is also insignificant. Refer to note 8 for a reconciliation of the change in the deferred purchase price receivable during the three-month periods ended July 1, 2016 and June 26, 2015.

[0001628280-16-017813:notes:87]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended July 1, 2016 and June 26, 2015.

[0001628280-16-017813:notes:88]
[same as prior period, unchanged from 0001628280-16-010628:notes:127]

[0001628280-16-017813:notes:89]
[same as prior period, unchanged from 0001628280-16-010628:notes:128]

[0001628280-16-017813:notes:90]
|  | Fair Value Measurements as of July 1, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 896,031 |  |  | $ | — |  |  | $ | 896,031 |  |
| Deferred purchase price receivable (Note 8) | — |  |  | — |  |  | 460,334 |  |  | 460,334 |  |
| Foreign exchange contracts (Note 6) | — |  |  | 17,389 |  |  | — |  |  | 17,389 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 8,504 |  |  | 41,455 |  |  | — |  |  | 49,959 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 6) | $ | — |  |  | $ | (11,858 | ) |  | $ | — |  |  | $ | (11,858 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (75,258 | ) |  | (75,258 | ) |
|  | Fair Value Measurements as of March 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,074,132 |  |  | $ | — |  |  | $ | 1,074,132 |  |
| Deferred purchase price receivable (Note 8) | — |  |  | — |  |  | 501,097 |  |  | 501,097 |  |
| Foreign exchange contracts (Note 6) | — |  |  | 22,648 |  |  | — |  |  | 22,648 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 9,228 |  |  | 40,556 |  |  | — |  |  | 49,784 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 6) | $ | — |  |  | $ | (21,091 | ) |  | $ | — |  |  | $ | (21,091 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (73,423 | ) |  | (73,423 | ) |

[0001628280-16-017813:notes:91]
[same as prior period, unchanged from 0001628280-16-010628:notes:130]

[0001628280-16-017813:notes:92]
[same as prior period, unchanged from 0001628280-16-010628:notes:131]

[0001628280-16-017813:notes:93]
|  | As of July 1, 2016 |  | As of March 31, 2016 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 573,750 |  |  | $ | 567,295 |  |  | $ | 577,500 |  |  | $ | 573,533 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 536,250 |  |  | 527,536 |  |  | 547,500 |  |  | 542,709 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 523,650 |  |  | 500,000 |  |  | 524,735 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 524,296 |  |  | 500,000 |  |  | 507,500 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,684 |  |  | 613,950 |  |  | 595,589 |  |  | 604,926 |  |  | Level 1 |
| Total | $ | 2,705,684 |  |  | $ | 2,756,727 |  |  | $ | 2,720,589 |  |  | $ | 2,753,403 |  |  |  |

[0001628280-16-017813:notes:94]
[same as prior period, unchanged from 0001628280-16-010628:notes:133]

[0001628280-16-017813:notes:95]
The Company values its €50 million (approximately $55.5 million as of July 1, 2016), 5-year, unsecured, term-loan due September 30, 2020 based on the current market rate, and as of July 1, 2016, the carrying amount approximates fair value.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-16-017813:notes:96]
Recently Adopted Accounting Pronouncement

[0001628280-16-017813:notes:97]
In March 2016, the Financial Accounting Standards Board ("FASB") issued new guidance intended to reduce the cost and complexity of the accounting for share-based payments. The new guidance simplifies various aspects of the accounting for share-based payments including income tax effects, withholding requirements and forfeitures. The Company elected to early adopt this new guidance during the three-month period ended July 1, 2016. The guidance eliminates additional paid in capital ("APIC") pools and requires companies to recognize all excess tax benefits and tax deficiencies in the income statement when the awards vest or are settled. It also addresses the presentation of excess tax benefits and employee taxes paid on the statement of cash flows. Prior to adoption, the Company elected to not deduct tax benefits for stock-based compensation awards on its tax returns, and accordingly, did not have any excess tax benefits or tax deficiencies upon adoption. The Company therefore determined that adoption of the new guidance had no impact on the condensed consolidated statement of operations and the condensed consolidated statement of cash flows. Further, the new guidance eliminates the requirement to estimate forfeitures and reduce stock compensation expense during the vesting period. Instead, companies can elect to account for actual forfeitures as they occur and record any previously unrecognized compensation expense for estimated forfeitures up to the period of adoption as a retrospective adjustment to beginning retained earnings. The Company has made the election to account for actual forfeitures as they occur starting in fiscal year 2017. After assessment, it was determined that the cumulative effect adjustment required under the new guidance was immaterial and therefore the Company did not record a retrospective adjustment. The Company finally determined that the adoption of this guidance did not have a significant impact on the consolidated financial position, results of operations and cash flows of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-16-017813:notes:98]
[same as prior period, unchanged from 0001628280-16-010628:notes:138]

[0001628280-16-017813:notes:99]
[same as prior period, unchanged from 0001628280-16-010628:notes:139]

[0001628280-16-017813:notes:100]
Flextronics International Ltd. ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scaletm; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electronics, connectivity, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables the Company's OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001628280-16-017813:notes:101]
[same as prior period, unchanged from 0001628280-16-010628:notes:141]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001628280-16-017813:notes:102]
INTEREST AND OTHER, NET

[0001628280-16-017813:notes:103]
During the three-month periods ended July 1, 2016 and June 26, 2015, the Company recognized interest expense of $26.9 million and $20.1 million, respectively, on its debt obligations outstanding.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-16-017813:notes:104]
[same as prior period, unchanged from 0001628280-16-010628:notes:156]

[0001628280-16-017813:notes:105]
|  | As of July 1, 2016 |  | As of March 31, 2016 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 221,466 |  |  | $ | (77,693 | ) |  | $ | 143,773 |  |  | $ | 223,046 |  |  | $ | (66,473 | ) |  | $ | 156,573 |  |
| Licenses and other intangibles | 283,743 |  |  | (47,667 | ) |  | 236,076 |  |  | 285,053 |  |  | (37,872 | ) |  | 247,181 |  |
| Total | $ | 505,209 |  |  | $ | (125,360 | ) |  | $ | 379,849 |  |  | $ | 508,099 |  |  | $ | (104,345 | ) |  | $ | 403,754 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001628280-16-017813:notes:106]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the three-month period ended July 1, 2016:

[0001628280-16-017813:notes:107]
|  |  | HRS |  | CTG |  | IEI |  | CEC |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year |  | $ | 439,336 |  |  | $ | 68,234 |  |  | $ | 322,803 |  |  | $ | 111,693 |  |  | $ | 942,066 |  |
| Additions (1) (2) |  | (1,787 | ) |  | — |  |  | 9,544 |  |  | — |  |  | 7,757 |  |
| Purchase accounting adjustments (3) |  | 794 |  |  | — |  |  | — |  |  | — |  |  | 794 |  |
| Foreign currency translation adjustments |  | (5,852 | ) |  | — |  |  | — |  |  | — |  |  | (5,852 | ) |
| Balance, end of the period |  | $ | 432,491 |  |  | $ | 68,234 |  |  | $ | 332,347 |  |  | $ | 111,693 |  |  | $ | 944,765 |  |

[0001628280-16-017813:notes:108]
| (1) | The goodwill generated from the Company’s business combination completed during the three-month period ended July 1, 2016 is primarily related to value placed on the acquired employee workforce, service offerings and capabilities of an acquired business. The goodwill is not deductible for income tax purposes. See note 10 for additional information. |

[0001628280-16-017813:notes:109]
| (2) | During the three-month period ended July 1, 2016, the Company disposed of a non-strategic business within the HRS segment, and recorded a reduction of goodwill of $1.8 million accordingly, which is included in the loss on sale in other expense on the condensed consolidated statement of operations. |

[0001628280-16-017813:notes:110]
| (3) | Includes adjustments to estimates resulting from the finalization of management's review of the valuation of assets acquired and liabilities assumed through certain business combinations completed in a period subsequent to the respective acquisition. These adjustments were not individually, nor in the aggregate, significant to the Company. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-16-017813:notes:111]
[same as prior period, unchanged from 0001628280-16-010628:notes:162]

[0001628280-16-017813:notes:112]
|  | As of July 1, 2016 |  | As of March 31, 2016 |
|  | (In thousands) |
| Raw materials | $ | 2,347,860 |  |  | $ | 2,234,512 |  |
| Work-in-progress | 493,056 |  |  | 561,282 |  |
| Finished goods | 753,921 |  |  | 695,862 |  |
|  | $ | 3,594,837 |  |  | $ | 3,491,656 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-16-017813:notes:113]
[same as prior period, unchanged from 0001628280-16-010628:notes:165]

[0001628280-16-017813:notes:114]
|  | Three-Month Periods Ended |
|  | July 1, 2016 |  | June 26, 2015 |
|  | (In thousands) |
| Net sales: |  |  |  |
| Communications & Enterprise Compute | $ | 2,195,990 |  |  | $ | 1,966,562 |  |
| Consumer Technology Group | 1,313,782 |  |  | 1,564,964 |  |
| Industrial & Emerging Industries | 1,289,015 |  |  | 1,130,138 |  |
| High Reliability Solutions | 1,078,026 |  |  | 904,584 |  |
|  | $ | 5,876,813 |  |  | $ | 5,566,248 |  |
| Segment income and reconciliation of income before tax: |  |  |  |
| Communications & Enterprise Compute | $ | 61,899 |  |  | $ | 57,065 |  |
| Consumer Technology Group | 24,634 |  |  | 38,843 |  |
| Industrial & Emerging Industries | 49,977 |  |  | 28,999 |  |
| High Reliability Solutions | 88,536 |  |  | 59,886 |  |
| Corporate and Other | (34,800 | ) |  | (25,711 | ) |
| Total segment income | 190,246 |  |  | 159,082 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 21,598 |  |  | 7,671 |  |
| Stock-based compensation | 23,797 |  |  | 16,126 |  |
| Other charges, net | 3,529 |  |  | 164 |  |
| Interest and other, net | 24,399 |  |  | 16,505 |  |
| Income before income taxes | $ | 116,923 |  |  | $ | 118,616 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001628280-16-017813:notes:115]
[same as prior period, unchanged from 0001628280-16-010628:notes:167]

[0001628280-16-017813:notes:116]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2017 (1) | $ | 55,390 |  |
| 2018 | 62,414 |  |
| 2019 | 55,825 |  |
| 2020 | 47,288 |  |
| 2021 | 43,025 |  |
| Thereafter | 115,907 |  |
| Total amortization expense | $ | 379,849 |  |

[0001628280-16-017813:notes:117]
| (1) | Represents estimated amortization for the remaining nine-month period ending March 31, 2017. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-017813:notes:118]
[same as prior period, unchanged from 0001628280-16-010628:notes:170]

[0001628280-16-017813:notes:119]
The Company has four reportable segments: HRS, CTG, IEI, and CEC. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 for a description of the various product categories manufactured under each of these segments.

[0001628280-16-017813:notes:120]
[same as prior period, unchanged from 0001628280-16-010628:notes:172]

[0001628280-16-017813:notes:121]
Corporate and other primarily includes corporate services costs that are not included in the Chief Operating Decision Maker's ("CODM") assessment of the performance of each of the identified reporting segments.

[0001628280-16-017813:notes:122]
Property and equipment on a segment basis is not disclosed as it is not separately identified and is not internally reported by segment to the Company's CODM.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-16-017813:notes:123]
[same as prior period, unchanged from 0001628280-16-010628:notes:175]

[0001628280-16-017813:notes:124]
[same as prior period, unchanged from 0001628280-16-010628:notes:176]

[0001628280-16-017813:notes:125]
[same as prior period, unchanged from 0001628280-16-010628:notes:177]

[0001628280-16-017813:notes:126]
The gross carrying amounts of intangible assets are removed when fully amortized. During the three-month period ended July 1, 2016, the total value of intangible assets decreased primarily as a result of additional amortization and foreign currency translation adjustments. The estimated future annual amortization expense for intangible assets is as follows:

[0001628280-16-017813:notes:127]
[same as prior period, unchanged from 0001628280-16-010628:notes:179]

[0001628280-16-017813:notes:128]
Other current assets include approximately $460.3 million and $501.1 million as of July 1, 2016 and March 31, 2016, respectively, for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 8 for additional information.

[0001628280-16-017813:notes:129]
Also included in other current assets is the value of certain assets purchased on behalf of a customer and financed by a third party banking institution in the amounts of $83.8 million and $83.6 million as of July 1, 2016 and March 31, 2016, respectively.

[0001628280-16-017813:notes:130]
[same as prior period, unchanged from 0001628280-16-010628:notes:185]

[0001628280-16-017813:notes:131]
Other current liabilities include customer working capital advances of $219.3 million and $253.7 million, customer-related accruals of $498.5 million and $479.5 million, and deferred revenue of $330.0 million and $332.3 million as of July 1, 2016 and March 31, 2016, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Other current liabilities also include the outstanding balance due to the third party banking institution related to the financed equipment discussed above of $96.9 million and $122.0 million as of July 1, 2016 and March 31, 2016, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001628280-16-017813:notes:132]
[same as prior period, unchanged from 0001628280-16-010628:notes:187]

[0001628280-16-017813:notes:133]
[same as prior period, unchanged from 0001628280-16-010628:notes:188]

[0001628280-16-017813:notes:134]
[same as prior period, unchanged from 0001628280-16-010628:notes:189]

[0001628280-16-017813:notes:135]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $700.0 million for the Global Program, of which $600.0 million is committed and $100.0 million is uncommitted, and $265.0 million for the North American Program, of which $225.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001628280-16-017813:notes:136]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month periods ended July 1, 2016 and June 26, 2015 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0001628280-16-017813:notes:137]
As of July 1, 2016, approximately $1.3 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $885.0 million and deferred purchase price receivables of approximately $460.3 million. As of March 31, 2016, approximately $1.4 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $880.8 million and deferred purchase price receivables of approximately $501.1 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of July 1, 2016 and March 31, 2016, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0001628280-16-017813:notes:138]
As of July 1, 2016 and March 31, 2016, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0001628280-16-017813:notes:139]
For the three-month periods ended July 1, 2016 and June 26, 2015, cash flows from sales of receivables under the ABS Programs consisted of approximately $1.4 billion and $1.1 billion, for transfers of receivables, respectively (of which approximately $59.5 million and $162.7 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0001628280-16-017813:notes:140]
[same as prior period, unchanged from 0001628280-16-010628:notes:195]

[0001628280-16-017813:notes:141]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $348.4 million and $339.4 million as of July 1, 2016 and March 31, 2016, respectively. For the three-month periods ended July 1, 2016 and June 26, 2015, total accounts receivable sold to certain third party banking institutions was approximately $453.0 million and $637.9 million, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0001628280-16-017813:notes:142]
[same as prior period, unchanged from 0001628280-16-010628:notes:197]

[0001628280-16-017813:notes:143]
During the three-month period ended July 1, 2016, the Company repurchased 7.3 million shares at an aggregate purchase price of $91.0 million, and retired all of these shares.

[0001628280-16-017813:notes:144]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Extraordinary General Meeting held on August 20, 2015. As of July 1, 2016, shares in the aggregate amount of $151.1 million were available to be repurchased under the current plan.
