# FLEX note change history — 0001628280-16-010628 → 0001628280-16-017813


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-07-27):
[0001628280-16-017813:note_history:1]
During the third quarter of fiscal 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice was for nine months of calendar year 2010 for an alleged amount of 52 million Brazilian reals (approximately USD $16 million based on the exchange rate as of July 1, 2016) plus interest. This assessment is in the second stage of the review process at the administrative level. During the fourth quarter of fiscal year 2016, the same Brazilian subsidiary received a further assessment related to the same import taxes of an additional 57 million Brazilian reals (approximately USD $18 million based on the exchange rate as of July 1, 2016) plus interest. This assessment is in the first stage of the review process at the administrative level. The Company plans to continue to vigorously oppose both of these assessments, as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on either of these claims for several years.

- added (2016-07-27):
[0001628280-16-017813:note_history:2]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of an approximately USD $100 million related to income and social contribution taxes, interest and penalties. During the first quarter of fiscal year 2017, the Company received a final favorable judgment in the judicial process reversing the assessment and the case is now closed. As the Company had previously determined there was no legal basis for the assessment, no adjustment was required to be recorded during the first quarter of fiscal year 2017.

- removed (2016-07-27):
[0001628280-16-010628:note_history:3]
Litigation and other legal matters

- removed (2016-07-27):
[0001628280-16-010628:note_history:4]
During the fourth quarter of fiscal year 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010 for an alleged amount of 50 million Brazilian reals (approximately $12.8 million based on the exchange rate as of December 31, 2015) plus interest. This assessment is in the second stage of the review process at the administrative level, and the Company plans to continue to vigorously oppose it as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on these matters for several years.

- removed (2016-07-27):
[0001628280-16-010628:note_history:5]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties. The Company believes there is no legal basis for the assessment and expects that any losses are remote. The Company plans to vigorously defend itself through the administrative and judicial processes.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-07-27):
[0001628280-16-017813:note_history:6]
Flextronics International Ltd. ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scaletm; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electronics, connectivity, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables the Company's OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

- changed (2016-07-27):
[0001628280-16-017813:note_history:7]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2016 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended July 1, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017.
  (was, 2016-02-01, similarity 0.9721):
[0001628280-16-010628:note_history:7]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2015 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and nine-month periods ended December 31, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016.

- added (2016-07-27):
[0001628280-16-017813:note_history:8]
The first quarters for fiscal year 2017 and fiscal year 2016 ended on July 1, 2016, which is comprised of 92 days in the period, and June 26, 2015, which is comprised of 87 days in the period, respectively.

- added (2016-07-27):
[0001628280-16-017813:note_history:9]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The associated noncontrolling owners' interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- changed (2016-07-27):
[0001628280-16-017813:note_history:10]
Recently Adopted Accounting Pronouncement
  (was, 2016-02-01, similarity 0.8611):
[0001628280-16-010628:note_history:10]
Recent Accounting Pronouncement

- added (2016-07-27):
[0001628280-16-017813:note_history:11]
In March 2016, the Financial Accounting Standards Board ("FASB") issued new guidance intended to reduce the cost and complexity of the accounting for share-based payments. The new guidance simplifies various aspects of the accounting for share-based payments including income tax effects, withholding requirements and forfeitures. The Company elected to early adopt this new guidance during the three-month period ended July 1, 2016. The guidance eliminates additional paid in capital ("APIC") pools and requires companies to recognize all excess tax benefits and tax deficiencies in the income statement when the awards vest or are settled. It also addresses the presentation of excess tax benefits and employee taxes paid on the statement of cash flows. Prior to adoption, the Company elected to not deduct tax benefits for stock-based compensation awards on its tax returns, and accordingly, did not have any excess tax benefits or tax deficiencies upon adoption. The Company therefore determined that adoption of the new guidance had no impact on the condensed consolidated statement of operations and the condensed consolidated statement of cash flows. Further, the new guidance eliminates the requirement to estimate forfeitures and reduce stock compensation expense during the vesting period. Instead, companies can elect to account for actual forfeitures as they occur and record any previously unrecognized compensation expense for estimated forfeitures up to the period of adoption as a retrospective adjustment to beginning retained earnings. The Company has made the election to account for actual forfeitures as they occur starting in fiscal year 2017. After assessment, it was determined that the cumulative effect adjustment required under the new guidance was immaterial and therefore the Company did not record a retrospective adjustment. The Company finally determined that the adoption of this guidance did not have a significant impact on the consolidated financial position, results of operations and cash flows of the Company.

- removed (2016-07-27):
[0001628280-16-010628:note_history:12]
Flextronics International Ltd. ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following reportable segments: High Reliability Solutions ("HRS"), which is comprised of medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group ("CTG"), which includes mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics, digital health, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computing, tablets, and printers; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions ("INS"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

- removed (2016-07-27):
[0001628280-16-010628:note_history:13]
The first quarters for fiscal year 2016 and fiscal year 2015 ended on June 26, 2015 and June 27, 2014, respectively. The second quarters for fiscal year 2016 and fiscal year 2015 ended on September 25, 2015 and September 26, 2014, respectively. The Company's third quarters end on December 31 of each year.

- removed (2016-07-27):
[0001628280-16-010628:note_history:14]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority-owned subsidiary of the Company. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The operating results of the subsidiary attributable to the noncontrolling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- removed (2016-07-27):
[0001628280-16-010628:note_history:15]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued new guidance to eliminate the requirement for companies to separate deferred income tax liabilities and assets into current and noncurrent amounts on the balance sheet. Instead, companies will be required to classify all deferred tax liabilities and assets as noncurrent. The Company has elected to early adopt this new guidance during the third quarter of fiscal year 2016 on a prospective basis as permitted under the standard, resulting in the reclassification of $66.3 million of deferred income tax assets and $9.1 million of deferred income tax liabilities from current into noncurrent as of December 31, 2015. Prior periods were not retrospectively adjusted.

- removed (2016-07-27):
[0001628280-16-010628:note_history:16]
In September 2015, the FASB issued new guidance to simplify the accounting for adjustments made to provisional amounts recognized in a business combination.  Under previous guidance, the acquirer retrospectively adjusted the provisional amounts recognized at the acquisition date with a corresponding adjustment to goodwill, and would have to revise comparative information for prior periods presented in financial statements as needed. The update requires an entity to present separately on the face of the income statement or disclose in the notes the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. The Company has elected to early adopt this new guidance which is effective for the Company beginning the third quarter of fiscal year 2016.

- removed (2016-07-27):
[0001628280-16-010628:note_history:17]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018, with early application permitted as of the beginning of an interim or annual reporting period. The Company is currently assessing the impact of this update and the timing of adoption.

- removed (2016-07-27):
[0001628280-16-010628:note_history:18]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. In July 2015, the FASB deferred the effective date of the standard by a year. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019. The Company is in the process of assessing the impact on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-07-27):
[0001628280-16-010628:note_history:19]
BANK BORROWINGS AND LONG TERM DEBT

- removed (2016-07-27):
[0001628280-16-010628:note_history:20]
Bank borrowings and long-term debt are as follows:

- removed (2016-07-27):
[0001628280-16-010628:note_history:21]
|  | As of December 31, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 585,000 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 555,000 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,494 |  |  | — |  |
| Other | 71,516 |  |  | 16,233 |  |
| Total | $ | 2,807,010 |  |  | $ | 2,083,733 |  |

- removed (2016-07-27):
[0001628280-16-010628:note_history:22]
The weighted-average interest rates for the Company’s long-term debt were 3.4% and 3.2% as of December 31, 2015 and March 31, 2015, respectively.

- removed (2016-07-27):
[0001628280-16-010628:note_history:23]
On June 8, 2015, the Company issued $600 million of 4.750% Notes ("Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at a discount of 99.213%, and an effective rate of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which will be used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.

- removed (2016-07-27):
[0001628280-16-010628:note_history:24]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the Notes. The issuance costs were capitalized and will be amortized over the life of the Notes.

- removed (2016-07-27):
[0001628280-16-010628:note_history:25]
Interest on the Notes is payable semi-annually, commencing on December 15, 2015. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Term Loan Agreement and Revolving Line of Credit.

- removed (2016-07-27):
[0001628280-16-010628:note_history:26]
At any time prior to March 15, 2025, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

- removed (2016-07-27):
[0001628280-16-010628:note_history:27]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of December 31, 2015, the Company was in compliance with the covenants in the indenture governing the Notes.

- removed (2016-07-27):
[0001628280-16-010628:note_history:28]
On September 30, 2015, the Company amended its $2.0 billion credit facility to increase the $500 million term loan maturing in March 2019 by $100.0 million. Quarterly repayments of principal under this term loan were amended to $7.5 million up to March 31, 2016, and will be increased to $11.3 million thereafter with the remainder due upon maturity. All other terms remained unchanged.

- removed (2016-07-27):
[0001628280-16-010628:note_history:29]
On October 1, 2015, the Company borrowed €50 million (approximately $54.6 million as of December 31, 2015), under a 5-year, unsecured, term-loan agreement due September 30, 2020. Borrowings under the term loan due September 30, 2020 bear interest at EURIBOR plus the applicable margin ranging between 0.80% and 2.00%, based on the Company’s credit ratings. The loan is repayable beginning December 30, 2016 in quarterly payments of €312,500 through June 30, 2020 with the remainder due upon maturity.  This loan is included in the "Other" category in the table above.

- removed (2016-07-27):
[0001628280-16-010628:note_history:30]
This term loan agreement is unsecured, and is guaranteed by the Company.  This term contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2015, the Company was in compliance with the covenants under this term loan agreement.

- removed (2016-07-27):
[0001628280-16-010628:note_history:31]
Repayment of the Company’s long term debt outstanding as of December 31, 2015 is as follows:

- removed (2016-07-27):
[0001628280-16-010628:note_history:32]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 15,000 |  |
| 2017 | 60,669 |  |
| 2018 | 61,338 |  |
| 2019 | 1,006,338 |  |
| 2020 | 501,338 |  |
| Thereafter | 1,162,327 |  |
| Total | $ | 2,807,010 |  |

- removed (2016-07-27):
[0001628280-16-010628:note_history:33]
____________________________________________________________

- removed (2016-07-27):
[0001628280-16-010628:note_history:34]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2016. |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-07-27):
[0001628280-16-017813:note_history:35]
|  | As of July 1, 2016 |  | As of March 31, 2016 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 573,750 |  |  | $ | 567,295 |  |  | $ | 577,500 |  |  | $ | 573,533 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 536,250 |  |  | 527,536 |  |  | 547,500 |  |  | 542,709 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 523,650 |  |  | 500,000 |  |  | 524,735 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 524,296 |  |  | 500,000 |  |  | 507,500 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,684 |  |  | 613,950 |  |  | 595,589 |  |  | 604,926 |  |  | Level 1 |
| Total | $ | 2,705,684 |  |  | $ | 2,756,727 |  |  | $ | 2,720,589 |  |  | $ | 2,753,403 |  |  |  |

- removed (2016-07-27):
[0001628280-16-010628:note_history:36]
|  | As of December 31, 2015 |  | As of March 31, 2015 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 585,000 |  |  | $ | 580,250 |  |  | $ | 592,500 |  |  | $ | 582,131 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 555,000 |  |  | 549,800 |  |  | 475,000 |  |  | 465,500 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 531,053 |  |  | 500,000 |  |  | 523,750 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 514,430 |  |  | 500,000 |  |  | 543,150 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,494 |  |  | 599,940 |  |  | — |  |  | — |  |  | Level 1 |
| Total | $ | 2,735,494 |  |  | $ | 2,775,473 |  |  | $ | 2,067,500 |  |  | $ | 2,114,531 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-07-27):
[0001628280-16-010628:note_history:37]
Bank borrowings and long-term debt are as follows:

- removed (2016-07-27):
[0001628280-16-010628:note_history:38]
|  | As of December 31, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 585,000 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 555,000 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,494 |  |  | — |  |
| Other | 71,516 |  |  | 16,233 |  |
| Total | $ | 2,807,010 |  |  | $ | 2,083,733 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-07-27):
[0001628280-16-010628:note_history:39]
Repayment of the Company’s long term debt outstanding as of December 31, 2015 is as follows:

- removed (2016-07-27):
[0001628280-16-010628:note_history:40]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 15,000 |  |
| 2017 | 60,669 |  |
| 2018 | 61,338 |  |
| 2019 | 1,006,338 |  |
| 2020 | 501,338 |  |
| Thereafter | 1,162,327 |  |
| Total | $ | 2,807,010 |  |

- removed (2016-07-27):
[0001628280-16-010628:note_history:41]
____________________________________________________________

- removed (2016-07-27):
[0001628280-16-010628:note_history:42]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2016. |
