# FLEX note change history — 0000866374-25-000008 → 0000866374-25-000043


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-07-25):
[0000866374-25-000043:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.
  (was, 2025-01-31, similarity 0.9297):
[0000866374-25-000008:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a

- added (2025-07-25):
[0000866374-25-000043:note_history:2]
The Company was involved in a commercial dispute related to a construction matter with related production objectives. Management had assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment recognized $50 million in Selling, general and administrative expenses in the fourth

- added (2025-07-25):
[0000866374-25-000043:note_history:3]
quarter of the fiscal year ended March 31, 2024 as an accrual. The parties reached a settlement in line with the accrued amount during the first quarter of fiscal year 2026 and the Company made an initial payment of $21 million in line with this agreement.

- added (2025-07-25):
[0000866374-25-000043:note_history:4]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. The Company was unsuccessful at the administrative level in two of the remaining assessments and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 37 million Brazilian reals (approximately USD $7 million). The Brazilian court ruled in favor of the Company on the first annulment action on March 7, 2025 and the assessment obligation has been canceled, although it remains subject to appeal. The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 60 million Brazilian reals (approximately USD $11 million). The Company is still awaiting a resolution of the second annulment action. The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on the remaining assessments and annulment actions in the near future.

- changed (2025-07-25):
[0000866374-25-000043:note_history:5]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.
  (was, 2025-01-31, similarity 0.8298):
[0000866374-25-000008:note_history:5]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $285 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. In the quarter ended December 31, 2024, approximately $118 million of the approximate $285 million assessment was abated by the Tax Authority, leaving approximately $167 million remaining. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.

- removed (2025-07-25):
[0000866374-25-000008:note_history:6]
material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- removed (2025-07-25):
[0000866374-25-000008:note_history:7]
The Company is currently involved in a commercial dispute related to a construction matter with related production objectives. Management assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment recognized $50 million in Selling, general and administrative expenses in the fourth quarter of the fiscal year ended March 31, 2024 as an accrual. The ultimate resolution of this dispute is uncertain, and the actual outcome may differ from the estimates made by management. Changes in circumstances or additional information may impact the Company’s assessment of its loss and could result in adjustments to the $50 million accrual, however, management currently believes that the resolution of this dispute will not have a material effect on the Company’s financial position, results of operations or cash flows. The Company will continue to monitor developments related to this matter and will adjust its accrual and disclosures accordingly in future reporting periods as additional information becomes available.

- removed (2025-07-25):
[0000866374-25-000008:note_history:8]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. Two remain, where the Company was unsuccessful at the administrative level and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 37 million Brazilian reals (approximately USD $6 million). The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 60 million Brazilian reals (approximately USD $10 million). The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-07-25):
[0000866374-25-000043:note_history:9]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, automotive, industrial, healthcare, industrial and power. As of June 27, 2025, Flex's two operating and reportable segments were as follows:
  (was, 2025-01-31, similarity 0.6303):
[0000866374-25-000008:note_history:9]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle and healthcare. As of December 31, 2024, Flex's two operating and reportable segments were as follows:

- changed (2025-07-25):
[0000866374-25-000043:note_history:10]
◦Communications, Enterprise and Cloud ("CEC"), including data center, edge, and communications infrastructure
  (was, 2025-01-31, similarity 0.8667):
[0000866374-25-000008:note_history:10]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure

- added (2025-07-25):
[0000866374-25-000043:note_history:11]
◦Lifestyle, including appliances, floorcare, smart living, Heating, Ventilation and Air-Conditioning ("HVAC"), and power tools

- changed (2025-07-25):
[0000866374-25-000043:note_history:12]
◦Consumer Devices, including mobile and high velocity consumer devices
  (was, 2025-01-31, similarity 0.9929):
[0000866374-25-000008:note_history:12]
◦Consumer Devices, including mobile and high velocity consumer devices.

- added (2025-07-25):
[0000866374-25-000043:note_history:13]
◦Industrial, including industrial devices, capital equipment, renewables, critical power and embedded power

- added (2025-07-25):
[0000866374-25-000043:note_history:14]
◦Automotive, including compute platforms, power electronics, motion, and interface

- changed (2025-07-25):
[0000866374-25-000043:note_history:15]
◦Health Solutions, including medical devices, medical equipment, and drug delivery
  (was, 2025-01-31, similarity 0.9939):
[0000866374-25-000008:note_history:15]
◦Health Solutions, including medical devices, medical equipment and drug delivery

- changed (2025-07-25):
[0000866374-25-000043:note_history:16]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2025 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 27, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026.
  (was, 2025-01-31, similarity 0.9813):
[0000866374-25-000008:note_history:16]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2024 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025.

- added (2025-07-25):
[0000866374-25-000043:note_history:17]
The first quarters for fiscal years 2026 and 2025 ended on June 27, 2025 and June 28, 2024, respectively, and are comprised of 88 and 89 days.

- changed (2025-07-25):
[0000866374-25-000043:note_history:18]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest.
  (was, 2025-01-31, similarity 0.7765):
[0000866374-25-000008:note_history:18]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners.

- added (2025-07-25):
[0000866374-25-000043:note_history:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and

- added (2025-07-25):
[0000866374-25-000043:note_history:20]
intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- changed (2025-07-25):
[0000866374-25-000043:note_history:21]
In November 2024, the FASB issued ASU 2024-03 "Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses", which requires public entities to disclose specified information about certain costs and expenses. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2028 and will be applied retrospectively to all prior periods presented on its consolidated financial statements. The Company is currently evaluating the guidance to determine the impact on the Company's disclosures. In January 2025, the FASB issued ASU 2025-01 on the same topic to clarify the amendments for ASU 2024-03 are effective for the Company in the fourth quarter of fiscal year 2028.
  (was, 2025-01-31, similarity 0.8625):
[0000866374-25-000008:note_history:21]
In November 2024, the FASB issued ASU 2024-03 "Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses", which requires public entities to disclose specified information about certain costs and expenses. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2028 and will be applied retrospectively to all prior periods presented on its consolidated financial statements. We are currently evaluating the guidance to determine the impact on the Company's disclosures.

- removed (2025-07-25):
[0000866374-25-000008:note_history:22]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio

- removed (2025-07-25):
[0000866374-25-000008:note_history:23]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies

- removed (2025-07-25):
[0000866374-25-000008:note_history:24]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings and renewables and grid edge.

- removed (2025-07-25):
[0000866374-25-000008:note_history:25]
The third quarters for fiscal years 2025 and 2024 ended on December 31 of each year and are comprised of 95 and 93 days, respectively. The Company's first three quarters for fiscal years 2025 and 2024 are both comprised of 275 days.

- removed (2025-07-25):
[0000866374-25-000008:note_history:26]
On January 2, 2024, Flex completed its spin-off (the "Spin-off") of its remaining interest in Nextracker Inc. ("Nextracker"). After the Spin-off, Flex no longer consolidates the financial results of Nextracker within its financial results of continuing operations. For all the periods prior to the Spin-off, the financial results of Nextracker are presented as net earnings from discontinued operations in the condensed consolidated statements of operations and unless otherwise indicated Flex's disclosures are presented on a continuing operations basis. The historical statements of comprehensive income and cash flows

- removed (2025-07-25):
[0000866374-25-000008:note_history:27]
and the balances related to shareholders' equity have not been revised to reflect the Spin-off. See note 6 "Discontinued Operations" for additional information.

- removed (2025-07-25):
[0000866374-25-000008:note_history:28]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- removed (2025-07-25):
[0000866374-25-000008:note_history:29]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company has assessed the impact of ASU 2023-07 on its consolidated financial statements and intends to adopt the guidance retrospectively with the updated segment disclosures in the fourth quarter of fiscal year 2025.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-25):
[0000866374-25-000043:note_history:30]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 27, 2025 and March 31, 2025 are as follows:
  (was, 2025-01-31, similarity 0.9569):
[0000866374-25-000008:note_history:30]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2024 and March 31, 2024 are as follows:

- added (2025-07-25):
[0000866374-25-000043:note_history:31]
|  | Maturity Date |  | As of June 27, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | — |  |  | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 677 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 675 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 290 |  |  | 269 |  |
| Debt issuance costs |  |  | (13) |  |  | (14) |  |
|  |  |  | 3,681 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (677) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,004 |  |  | $ | 2,483 |  |

- added (2025-07-25):
[0000866374-25-000043:note_history:32]
(2)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at SOFR plus 100 basis points.

- changed (2025-07-25):
[0000866374-25-000043:note_history:33]
The weighted-average interest rate for the Company's long-term debt was 4.6% as of June 27, 2025 and March 31, 2025, respectively.
  (was, 2025-01-31, similarity 0.9306):
[0000866374-25-000008:note_history:33]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.5% as of December 31, 2024 and March 31, 2024, respectively.

- changed (2025-07-25):
[0000866374-25-000043:note_history:34]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 27, 2025 are as follows:
  (was, 2025-01-31, similarity 0.9524):
[0000866374-25-000008:note_history:34]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2024 are as follows:

- changed (2025-07-25):
[0000866374-25-000043:note_history:35]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2026 (1) |  | $ | 677 |  |
| 2027 |  | — |  |
| 2028 |  | 898 |  |
| 2029 |  | 29 |  |
| 2030 |  | 684 |  |
| Thereafter |  | 1,406 |  |
| Total |  | $ | 3,694 |  |
  (was, 2025-01-31, similarity 0.9247):
[0000866374-25-000008:note_history:35]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | — |  |
| 2026 |  | 1,211 |  |
| 2027 |  | — |  |
| 2028 |  | 398 |  |
| 2029 |  | 25 |  |
| Thereafter |  | 2,061 |  |
| Total |  | $ | 3,695 |  |

- changed (2025-07-25):
[0000866374-25-000043:note_history:36]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2026.
  (was, 2025-01-31, similarity 0.963):
[0000866374-25-000008:note_history:36]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2025.

- added (2025-07-25):
[0000866374-25-000043:note_history:37]
Term Loan due December 2027

- added (2025-07-25):
[0000866374-25-000043:note_history:38]
In March 2025, the Company entered into a delayed draw term loan agreement for an amount of $500 million. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general purposes. All borrowings on the delayed draw term loan will be come due on December 31, 2027. Interest is based on a Term SOFR-based formula plus a margin of 100 basis points. The Company has fully drawn the $500 million loan as of June 27, 2025.

- removed (2025-07-25):
[0000866374-25-000008:note_history:39]
|  | Maturity Date |  | As of December 31, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 679 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 677 |  |  | 681 |  |
| 5.250% Notes (1) (2) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 254 |  |  | 274 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (16) |  |  | (15) |  |
|  |  |  | 3,679 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (532) |  |  | — |  |
| Non-current portion |  |  | $ | 3,147 |  |  | $ | 3,261 |  |

- removed (2025-07-25):
[0000866374-25-000008:note_history:40]
(2)In August 2024, the Company issued $500 million of 5.250% Notes due 2032. The Company received proceeds of approximately $496 million, net of discount and certain issuance costs.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-07-25):
[0000866374-25-000043:note_history:41]
|  | As of June 27, 2025 |  | As of March 31, 2025 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | — |  |  | — |  |  | 531 |  |  | 531 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 677 |  |  | 673 |  |  | 678 |  |  | 672 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 411 |  |  | 398 |  |  | 409 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 655 |  |  | 659 |  |  | 655 |  |  | 651 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 675 |  |  | 678 |  |  | 676 |  |  | 669 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 504 |  |  | 499 |  |  | 497 |  |  | Level 1 |
| Delayed Draw Term Loan due December 2027 | 500 |  |  | 500 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 290 |  |  | 232 |  |  | 269 |  |  | 215 |  |  | Level 2 |

- removed (2025-07-25):
[0000866374-25-000008:note_history:42]
|  | As of December 31, 2024 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | 532 |  |  | $ | 532 |  |  | $ | 584 |  |  | $ | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 679 |  |  | 670 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 406 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 656 |  |  | 644 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 677 |  |  | 662 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 494 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 254 |  |  | 203 |  |  | 274 |  |  | 219 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-25):
[0000866374-25-000043:note_history:43]
Bank borrowings and long-term debt as of June 27, 2025 and March 31, 2025 are as follows:
  (was, 2025-01-31, similarity 0.9383):
[0000866374-25-000008:note_history:43]
Bank borrowings and long-term debt as of December 31, 2024 and March 31, 2024 are as follows:

- added (2025-07-25):
[0000866374-25-000043:note_history:44]
|  | Maturity Date |  | As of June 27, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | — |  |  | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 677 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 675 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 290 |  |  | 269 |  |
| Debt issuance costs |  |  | (13) |  |  | (14) |  |
|  |  |  | 3,681 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (677) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,004 |  |  | $ | 2,483 |  |

- added (2025-07-25):
[0000866374-25-000043:note_history:45]
(2)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at SOFR plus 100 basis points.

- changed (2025-07-25):
[0000866374-25-000043:note_history:46]
(3)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.
  (was, 2025-01-31, similarity 0.7243):
[0000866374-25-000008:note_history:46]
(2)In August 2024, the Company issued $500 million of 5.250% Notes due 2032. The Company received proceeds of approximately $496 million, net of discount and certain issuance costs.
(3)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

- removed (2025-07-25):
[0000866374-25-000008:note_history:47]
|  | Maturity Date |  | As of December 31, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 679 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 677 |  |  | 681 |  |
| 5.250% Notes (1) (2) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 254 |  |  | 274 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (16) |  |  | (15) |  |
|  |  |  | 3,679 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (532) |  |  | — |  |
| Non-current portion |  |  | $ | 3,147 |  |  | $ | 3,261 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-25):
[0000866374-25-000043:note_history:48]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 27, 2025 are as follows:
  (was, 2025-01-31, similarity 0.9524):
[0000866374-25-000008:note_history:48]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2024 are as follows:

- changed (2025-07-25):
[0000866374-25-000043:note_history:49]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2026 (1) |  | $ | 677 |  |
| 2027 |  | — |  |
| 2028 |  | 898 |  |
| 2029 |  | 29 |  |
| 2030 |  | 684 |  |
| Thereafter |  | 1,406 |  |
| Total |  | $ | 3,694 |  |
  (was, 2025-01-31, similarity 0.9247):
[0000866374-25-000008:note_history:49]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | — |  |
| 2026 |  | 1,211 |  |
| 2027 |  | — |  |
| 2028 |  | 398 |  |
| 2029 |  | 25 |  |
| Thereafter |  | 2,061 |  |
| Total |  | $ | 3,695 |  |

- changed (2025-07-25):
[0000866374-25-000043:note_history:50]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2026.
  (was, 2025-01-31, similarity 0.963):
[0000866374-25-000008:note_history:50]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2025.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-07-25):
[0000866374-25-000043:note_history:51]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time:
  (was, 2025-01-31, similarity 0.7295):
[0000866374-25-000008:note_history:51]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2024 and December 31, 2023, respectively.

- changed (2025-07-25):
[0000866374-25-000043:note_history:52]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
| Timing of Transfer |  |  |  |  | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | $ | 2,895 |  |  | $ | 2,873 |  |
| Over time |  |  |  |  | 796 |  |  | 492 |  |
| Total |  |  |  |  | 3,691 |  |  | 3,365 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 1,859 |  |  | 2,633 |  |
| Over time |  |  |  |  | 1,025 |  |  | 316 |  |
| Total |  |  |  |  | 2,884 |  |  | 2,949 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 4,754 |  |  | 5,506 |  |
| Over time |  |  |  |  | 1,821 |  |  | 808 |  |
| Total |  |  |  |  | $ | 6,575 |  |  | $ | 6,314 |  |
  (was, 2025-01-31, similarity 0.7553):
[0000866374-25-000008:note_history:52]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,849 |  |  | $ | 3,151 |  |  | $ | 8,646 |  |  | $ | 9,867 |  |
| Over time | 750 |  |  | 314 |  |  | 1,924 |  |  | 817 |  |
| Total | 3,599 |  |  | 3,465 |  |  | 10,570 |  |  | 10,684 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,960 |  |  | 2,793 |  |  | 6,830 |  |  | 9,070 |  |
| Over time | 997 |  |  | 163 |  |  | 2,015 |  |  | 492 |  |
| Total | 2,957 |  |  | 2,956 |  |  | 8,845 |  |  | 9,562 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,809 |  |  | 5,944 |  |  | 15,476 |  |  | 18,937 |  |
| Over time | 1,747 |  |  | 477 |  |  | 3,939 |  |  | 1,309 |  |
| Total | $ | 6,556 |  |  | $ | 6,421 |  |  | $ | 19,415 |  |  | $ | 20,246 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-07-25):
[0000866374-25-000043:note_history:53]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $450 million and $377 million as of June 27, 2025 and March 31, 2025,
  (was, 2025-01-31, similarity 0.6656):
[0000866374-25-000008:note_history:53]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $355 million and $490 million as of December 31, 2024 and March 31, 2024, respectively, of which $314 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- added (2025-07-25):
[0000866374-25-000043:note_history:54]
respectively, of which $406 million and $347 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2025-07-25):
[0000866374-25-000043:note_history:55]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time:
  (was, 2025-01-31, similarity 0.7295):
[0000866374-25-000008:note_history:55]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2024 and December 31, 2023, respectively.

- changed (2025-07-25):
[0000866374-25-000043:note_history:56]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
| Timing of Transfer |  |  |  |  | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | $ | 2,895 |  |  | $ | 2,873 |  |
| Over time |  |  |  |  | 796 |  |  | 492 |  |
| Total |  |  |  |  | 3,691 |  |  | 3,365 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 1,859 |  |  | 2,633 |  |
| Over time |  |  |  |  | 1,025 |  |  | 316 |  |
| Total |  |  |  |  | 2,884 |  |  | 2,949 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 4,754 |  |  | 5,506 |  |
| Over time |  |  |  |  | 1,821 |  |  | 808 |  |
| Total |  |  |  |  | $ | 6,575 |  |  | $ | 6,314 |  |
  (was, 2025-01-31, similarity 0.7553):
[0000866374-25-000008:note_history:56]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,849 |  |  | $ | 3,151 |  |  | $ | 8,646 |  |  | $ | 9,867 |  |
| Over time | 750 |  |  | 314 |  |  | 1,924 |  |  | 817 |  |
| Total | 3,599 |  |  | 3,465 |  |  | 10,570 |  |  | 10,684 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,960 |  |  | 2,793 |  |  | 6,830 |  |  | 9,070 |  |
| Over time | 997 |  |  | 163 |  |  | 2,015 |  |  | 492 |  |
| Total | 2,957 |  |  | 2,956 |  |  | 8,845 |  |  | 9,562 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,809 |  |  | 5,944 |  |  | 15,476 |  |  | 18,937 |  |
| Over time | 1,747 |  |  | 477 |  |  | 3,939 |  |  | 1,309 |  |
| Total | $ | 6,556 |  |  | $ | 6,421 |  |  | $ | 19,415 |  |  | $ | 20,246 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-07-25):
[0000866374-25-000043:note_history:57]
SUBSEQUENT EVENTS
On July 15, 2025, the Company entered into a new $2.75 billion credit facility (the "New Credit Facility") which matures in July 2030 and consists of a $2.75 billion revolving credit facility with a sub-limit of $400 million available for swing line loans and a sub-limit of $200 million available for the issuance of letters of credit. The New Credit Facility replaced the previous $2.5 billion credit facility. Under the New Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are determined based on standard benchmark interest rates subject to potential adjustment based on the Company’s credit rating.
