# FLEX MD&A — 0000866374-25-000043


## mdna

[0000866374-25-000043:mdna:1]
[same as prior period, unchanged from 0000866374-25-000008:mdna:1]

[0000866374-25-000043:mdna:2]
[same as prior period, unchanged from 0000866374-25-000008:mdna:2]

[0000866374-25-000043:mdna:3]
[same as prior period, unchanged from 0000866374-25-000008:mdna:3]

[0000866374-25-000043:mdna:4]
We are the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we deliver technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. Our full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. We partner with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, healthcare, industrial and power. As of June 27, 2025, our two operating and reportable segments were as follows:

[0000866374-25-000043:mdna:5]
[same as prior period, unchanged from 0000866374-25-000008:mdna:5]

[0000866374-25-000043:mdna:6]
◦Communications, Enterprise and Cloud ("CEC"), including data center, edge, and communications infrastructure

[0000866374-25-000043:mdna:7]
◦Lifestyle, including appliances, floorcare, smart living, Heating, Ventilation and Air-Conditioning ("HVAC"), and power tools

[0000866374-25-000043:mdna:8]
◦Consumer Devices, including mobile and high velocity consumer devices

[0000866374-25-000043:mdna:9]
[same as prior period, unchanged from 0000866374-25-000008:mdna:9]

[0000866374-25-000043:mdna:10]
◦Industrial, including industrial devices, capital equipment, renewables, critical power and embedded power

[0000866374-25-000043:mdna:11]
◦Automotive, including compute platforms, power electronics, motion, and interface

[0000866374-25-000043:mdna:12]
◦Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-25-000043:mdna:13]
[same as prior period, unchanged from 0000866374-25-000008:mdna:13]

[0000866374-25-000043:mdna:14]
In today’s business landscape, we are witnessing greater product diversification by many companies, primarily in the technology sector, along with increased product complexity. These companies now require unique and customized manufacturing and supply chain solutions that meet their evolving requirements.

[0000866374-25-000043:mdna:15]
[same as prior period, unchanged from 0000866374-25-000008:mdna:15]

[0000866374-25-000043:mdna:16]
[same as prior period, unchanged from 0000866374-25-000008:mdna:17]

[0000866374-25-000043:mdna:17]
[same as prior period, unchanged from 0000866374-25-000008:mdna:18]

[0000866374-25-000043:mdna:18]
[same as prior period, unchanged from 0000866374-25-000008:mdna:21]

[0000866374-25-000043:mdna:19]
We continue to monitor and respond to the conflict in Ukraine and the associated sanctions and other restrictions. We also are monitoring and responding to the Israel-Hamas war. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine and Israel. The full impact of the conflicts on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflicts and their impact on regional and global economic conditions. We will continue to monitor the conflicts and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-25-000043:mdna:20]
Tariffs

[0000866374-25-000043:mdna:21]
In the fourth quarter of our fiscal year ended March 31, 2025, the U.S. implemented a series of global tariffs, including on a number of countries in which Flex operates. Although we have been and expect to continue to be able to pass tariff costs through to our customers, the global tariff landscape, which continues to evolve, has the potential to meaningfully impact end customer demand. During the quarter ended June 27. 2025, tariff costs paid and recoveries from our customers impacted our revenues and costs of goods sold by less than one percent and had a negligible impact on our profitability. If, in the future, we are no longer able to fully pass through these tariffs, our results from operations and cash flows would be negatively impacted. For further information, refer to Part I, Item 1A, Risk Factors  - "Global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets have in the past adversely affected, and may in the future adversely affect, our business, results of operations, financial condition, and access to capital markets." in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0000866374-25-000043:mdna:22]
24

[0000866374-25-000043:mdna:23]
[same as prior period, unchanged from 0000866374-25-000008:mdna:23]

[0000866374-25-000043:mdna:24]
We are one of the world's largest providers of global supply chain solutions, with revenues of $6.6 billion for the three-month period ended June 27, 2025 and $25.8 billion in the fiscal year ended March 31, 2025. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of approximately 100 facilities in approximately 30 countries across four continents. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites.

[0000866374-25-000043:mdna:25]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
|  |  |  |  |  |  |  |  |  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |  | $ | 3,364 |  |  | 51 | % |  | $ | 3,018 |  |  | 48 | % |
| Asia |  |  |  |  |  |  |  |  | 1,870 |  |  | 28 | % |  | 1,907 |  |  | 30 | % |
| Europe |  |  |  |  |  |  |  |  | 1,341 |  |  | 21 | % |  | 1,389 |  |  | 22 | % |
|  |  |  |  |  |  |  |  |  | $ | 6,575 |  |  |  |  | $ | 6,314 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mexico |  |  |  |  |  |  |  |  | $ | 1,709 |  |  | 26 | % |  | $ | 1,587 |  |  | 25 | % |
| U.S. |  |  |  |  |  |  |  |  | 1,283 |  |  | 20 | % |  | 1,004 |  |  | 16 | % |
| China |  |  |  |  |  |  |  |  | 1,072 |  |  | 16 | % |  | 1,068 |  |  | 17 | % |
| Malaysia |  |  |  |  |  |  |  |  | 597 |  |  | 9 | % |  | 591 |  |  | 9 | % |
| Brazil |  |  |  |  |  |  |  |  | 354 |  |  | 5 | % |  | 400 |  |  | 6 | % |
| Hungary |  |  |  |  |  |  |  |  | 346 |  |  | 5 | % |  | 343 |  |  | 5 | % |
| Other |  |  |  |  |  |  |  |  | 1,214 |  |  | 19 | % |  | 1,321 |  |  | 22 | % |
|  |  |  |  |  |  |  |  |  | $ | 6,575 |  |  |  |  | $ | 6,314 |  |  |  |

[0000866374-25-000043:mdna:26]
|  | As of |  | As of |
|  | June 27, 2025 |  | March 31, 2025 |
| Property and equipment, net: | (In millions) |
| Mexico | $ | 810 |  |  | 35 | % |  | $ | 815 |  |  | 35 | % |
| U.S. | 376 |  |  | 16 | % |  | 376 |  |  | 16 | % |
| China | 290 |  |  | 13 | % |  | 293 |  |  | 13 | % |
| Malaysia | 174 |  |  | 7 | % |  | 163 |  |  | 7 | % |
| Hungary | 145 |  |  | 6 | % |  | 140 |  |  | 6 | % |
| Brazil | 81 |  |  | 4 | % |  | 83 |  |  | 4 | % |
| Other | 453 |  |  | 19 | % |  | 460 |  |  | 19 | % |
|  | $ | 2,329 |  |  |  |  | $ | 2,330 |  |  |  |

[0000866374-25-000043:mdna:27]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses, including many in low-cost geographic areas, provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing products for leading multinational and regional customers. Specifically, we offer our customers the ability to simplify their global product development, manufacturing process, and after-sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-25-000043:mdna:28]
[same as prior period, unchanged from 0000866374-25-000008:mdna:28]

[0000866374-25-000043:mdna:29]
•global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets;

[0000866374-25-000043:mdna:30]
25

[0000866374-25-000043:mdna:31]
[same as prior period, unchanged from 0000866374-25-000008:mdna:31]

[0000866374-25-000043:mdna:32]
[same as prior period, unchanged from 0000866374-25-000008:mdna:34]

[0000866374-25-000043:mdna:33]
[same as prior period, unchanged from 0000866374-25-000008:mdna:35]

[0000866374-25-000043:mdna:34]
[same as prior period, unchanged from 0000866374-25-000008:mdna:36]

[0000866374-25-000043:mdna:35]
•the effects that current credit and market conditions could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-25-000043:mdna:36]
•the impacts on our business due to supply chain issues, including component shortages, disruptions in transportation or other supply chain related constraints including disruptions in international commerce as a result of attacks on shipping vessels in the Red Sea;

[0000866374-25-000043:mdna:37]
[same as prior period, unchanged from 0000866374-25-000008:mdna:38]

[0000866374-25-000043:mdna:38]
[same as prior period, unchanged from 0000866374-25-000008:mdna:39]

[0000866374-25-000043:mdna:39]
•changes in tax legislation;

[0000866374-25-000043:mdna:40]
•changes in trade regulations and treaties; and

[0000866374-25-000043:mdna:41]
[same as prior period, unchanged from 0000866374-25-000008:mdna:41]

[0000866374-25-000043:mdna:42]
We are also subject to other risks as outlined in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0000866374-25-000043:mdna:43]
[same as prior period, unchanged from 0000866374-25-000008:mdna:43]

[0000866374-25-000043:mdna:44]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas war), there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-25-000043:mdna:45]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0000866374-25-000043:mdna:46]
26

[0000866374-25-000043:mdna:47]
[same as prior period, unchanged from 0000866374-25-000008:mdna:47]

[0000866374-25-000043:mdna:48]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0000866374-25-000043:mdna:49]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
| Net sales |  |  |  |  | 100.0 | % |  | 100.0 | % |
| Cost of sales |  |  |  |  | 91.1 |  |  | 92.3 |  |
| Restructuring charges |  |  |  |  | 0.2 |  |  | 0.2 |  |
| Gross profit |  |  |  |  | 8.7 |  |  | 7.5 |  |
| Selling, general and administrative expenses |  |  |  |  | 3.5 |  |  | 3.4 |  |
| Restructuring charges |  |  |  |  | 0.1 |  |  | 0.1 |  |
| Intangible amortization |  |  |  |  | 0.4 |  |  | 0.3 |  |
| Operating income |  |  |  |  | 4.7 |  |  | 3.7 |  |
| Interest expense |  |  |  |  | 0.8 |  |  | 0.9 |  |
| Interest income |  |  |  |  | 0.2 |  |  | 0.3 |  |
| Other charges (income), net |  |  |  |  | 0.1 |  |  | 0.1 |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  | (0.3) |  |  | — |  |
| Income before income taxes |  |  |  |  | 3.7 |  |  | 3.0 |  |
| Provision for (benefit from) income taxes |  |  |  |  | 0.8 |  |  | 0.8 |  |
| Net income |  |  |  |  | 2.9 | % |  | 2.2 | % |

[0000866374-25-000043:mdna:50]
[same as prior period, unchanged from 0000866374-25-000008:mdna:50]

[0000866374-25-000043:mdna:51]
[same as prior period, unchanged from 0000866374-25-000008:mdna:51]

[0000866374-25-000043:mdna:52]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
|  |  |  |  |  |  |  |  |  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions |  |  |  |  |  |  |  |  | $ | 3,691 |  |  | 56 | % |  | $ | 3,365 |  |  | 53 | % |
| Flex Reliability Solutions |  |  |  |  |  |  |  |  | 2,884 |  |  | 44 | % |  | 2,949 |  |  | 47 | % |
|  |  |  |  |  |  |  |  |  | $ | 6,575 |  |  |  |  | $ | 6,314 |  |  |  |

[0000866374-25-000043:mdna:53]
Net sales during the three-month period ended June 27, 2025 totaled $6.6 billion, representing an increase of approximately $0.3 billion, or 4% from $6.3 billion during the three-month period ended June 28, 2024. Net sales for our FAS segment increased approximately $0.3 billion, or 10% from the three-month period ended June 28, 2024, primarily driven by a strong increase in our CEC business from increased demand in data center cloud, partially offset by a significant decrease in our Consumer Devices business due to lower demand. Net sales for our FRS segment decreased approximately $0.1 billion, or 2% from the three-month period ended June 28, 2024, as growth in data center power combined with sales from our recent Crown acquisition was more than offset by weaker demand in our core Industrial, Automotive, and Health Solutions businesses. Net sales remained consistent in Asia at $1.9 billion, decreased $0.1 billion to $1.3 billion in Europe and increased $0.4 billion to $3.4 billion in the Americas.

[0000866374-25-000043:mdna:54]
Our ten largest customers during the three-month periods ended June 27, 2025 and June 28, 2024 accounted for approximately 48% and 43% of net sales, respectively. No customer accounted for more than 10% of net sales during the three-month periods ended June 27, 2025 or June 28, 2024.

[0000866374-25-000043:mdna:55]
[same as prior period, unchanged from 0000866374-25-000008:mdna:16]

[0000866374-25-000043:mdna:56]
[same as prior period, unchanged from 0000866374-25-000008:mdna:57]

[0000866374-25-000043:mdna:57]
[same as prior period, unchanged from 0000866374-25-000008:mdna:58]

[0000866374-25-000043:mdna:58]
Cost of sales during the three-month period ended June 27, 2025, totaled $6.0 billion, representing an increase of $0.2 billion, or 3% from $5.8 billion during the three-month period ended June 28, 2024. The higher cost of sales for the three-month period ended June 27, 2025, was primarily driven by a $0.3 billion or 4% increase in consolidated sales, partially offset by cost efficiencies and favorable mix. Cost of sales in our FAS segment for the three-month period ended June 27, 2025, increased approximately $0.3 billion, or 8% from the three-month period ended June 28, 2024, due to revenue growth of 10% offset by favorable mix and cost efficiencies. Cost of sales in our FRS segment for the three-month period ended June 27, 2025, decreased approximately $0.1 billion, or 4% from the three-month period ended June 28, 2024, outpacing a 2% revenue decline due to favorable mix and cost efficiencies.

[0000866374-25-000043:mdna:59]
[same as prior period, unchanged from 0000866374-25-000008:mdna:61]

[0000866374-25-000043:mdna:60]
Gross profit is affected by fluctuations in net sales and cost of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all markets. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-25-000043:mdna:61]
Gross profit during the three-month period ended June 27, 2025 increased $0.1 billion to $0.6 billion, or 8.7% of net sales, from $0.5 billion, or 7.5% of net sales, during the three-month period ended June 28, 2024. Gross margin improved 120 basis points year over year primarily due to favorable mix and continued operational execution.

[0000866374-25-000043:mdna:62]
[same as prior period, unchanged from 0000866374-25-000008:mdna:65]

[0000866374-25-000043:mdna:63]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income.  Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, certain restructuring charges, customer related asset impairment, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-25-000043:mdna:64]
The Company's Chief Executive Officer is our Chief Operating Decision Maker ("CODM") who uses segment income in evaluating how we allocate resources, assess performance and make strategic and operational decisions.

[0000866374-25-000043:mdna:65]
[same as prior period, unchanged from 0000866374-25-000008:mdna:67]

[0000866374-25-000043:mdna:66]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
|  |  |  |  |  |  |  |  |  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions |  |  |  |  |  |  |  |  | $ | 240 |  |  | 6.5 | % |  | $ | 179 |  |  | 5.3 | % |
| Flex Reliability Solutions |  |  |  |  |  |  |  |  | 172 |  |  | 6.0 | % |  | 147 |  |  | 5.0 | % |

[0000866374-25-000043:mdna:67]
FAS segment margin increased approximately 120 basis points to 6.5% for the three-month period ended June 27, 2025, from 5.3%, for the three-month period ended June 28, 2024, primarily driven by continued mix improvement and strong operational execution.

[0000866374-25-000043:mdna:68]
FRS segment margin increased approximately 100 basis points to 6.0% for the three-month period ended June 27, 2025, compared to 5.0%, for the three-month period ended June 28, 2024, primarily driven by favorable mix and strong operational execution.

[0000866374-25-000043:mdna:69]
[same as prior period, unchanged from 0000866374-25-000008:mdna:71]

[0000866374-25-000043:mdna:70]
28

[0000866374-25-000043:mdna:71]
We undertook targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. During the three-month period ended June 27, 2025, we recognized approximately $23 million of restructuring charges primarily related to employee severance, compared to $25 million in the same period in fiscal year 2025.

[0000866374-25-000043:mdna:72]
[same as prior period, unchanged from 0000866374-25-000008:mdna:73]

[0000866374-25-000043:mdna:73]
Selling, general and administrative expenses (“SG&A”) was $0.2 billion, or 3.5% of net sales, during the three-month period ended June 27, 2025, remaining consistent with $0.2 billion or 3.4% of net sales, during the three-month period ended June 28, 2024. The percentage consistency in SG&A reflects ongoing cost control efforts.

[0000866374-25-000043:mdna:74]
[same as prior period, unchanged from 0000866374-25-000008:mdna:75]

[0000866374-25-000043:mdna:75]
Amortization of intangible assets increased to $21 million for the three-month period ended June 27, 2025, compared to $16 million in the same period in fiscal year 2025, primarily due to acquisitions during fiscal year 2025.

[0000866374-25-000043:mdna:76]
[same as prior period, unchanged from 0000866374-25-000008:mdna:77]

[0000866374-25-000043:mdna:77]
Interest expense decreased to $51 million for the three-month period ended June 27, 2025, from $56 million in the prior year, driven by a decrease in interest expense from lower commercial paper borrowings and reduced receivable factoring costs, partially offset by increased interest expense on our long-term debt.

[0000866374-25-000043:mdna:78]
[same as prior period, unchanged from 0000866374-25-000008:mdna:79]

[0000866374-25-000043:mdna:79]
Interest income for the three-month period ended June 27, 2025, decreased to $13 million compared to $16 million for the same period in fiscal year 2025. These results are the result of lower interest rates and lower average cash balances comparatively between the two periods.

[0000866374-25-000043:mdna:80]
[same as prior period, unchanged from 0000866374-25-000008:mdna:82]

[0000866374-25-000043:mdna:81]
Other charges (income), net was $7 million during the three-month period ended June 27, 2025 compared to $2 million during the three-month period ended June 28, 2024, primarily due to fluctuations in foreign exchange rates during the quarter.

[0000866374-25-000043:mdna:82]
Equity in earnings (losses) of unconsolidated affiliates

[0000866374-25-000043:mdna:83]
Equity in losses was $20 million during the three-month period ended June 27, 2025, compared to earnings of $1 million during the three-month period ended June 28, 2024, primarily due to a $17 million loss related to a specific venture capital fund during the first quarter of fiscal year 2026.

[0000866374-25-000043:mdna:84]
[same as prior period, unchanged from 0000866374-25-000008:mdna:85]

[0000866374-25-000043:mdna:85]
Certain of our subsidiaries, at various times, have been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 15, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025 for further discussion.

[0000866374-25-000043:mdna:86]
The consolidated effective tax rate was 22% and 28% for the three-month periods ended June 27, 2025 and June 28, 2024, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effects of certain tax holidays and incentives granted to our subsidiaries primarily in China, Costa Rica, Malaysia, the Netherlands and Israel. The effective tax rate for the three-month period ended June 27, 2025 was lower than the effective tax rate for the three-month period ended June 28, 2024, for a variety of reasons, primarily favorable foreign exchange impacts, tax benefits on restructuring charges, and additional interest recoverable on prior periods taxes paid by one of our Brazilian subsidiaries.

[0000866374-25-000043:mdna:87]
The OECD Pillar Two Global Anti-Base Erosion (“GloBE”) model rules, issued under the OECD Inclusive Framework on Base Erosion and Profit Shifting, introduce a global minimum tax of 15% applicable to multinational enterprise groups with consolidated financial statement revenue in excess of €750 million. Numerous foreign jurisdictions have already enacted tax legislation based on the GloBE rules, with some effective as early as January 1, 2024. As of June 27, 2025, the Company has reflected all estimated impacts of the Pillar Two GloBE minimum tax accordingly within its estimated annual effective tax rate for the year.

[0000866374-25-000043:mdna:88]
On July 4, 2025, The One Big Beautiful Bill Act (“OBBBA”) was enacted in the U.S. The OBBBA makes permanent various provisions of the Tax Cuts and Jobs Act which otherwise would have expired as well as makes significant

[0000866374-25-000043:mdna:89]
modifications to the U.S. international tax framework. The Company is in the process of evaluating the impact of the OBBBA to our consolidated financial statements.

[0000866374-25-000043:mdna:90]
Net income

[0000866374-25-000043:mdna:91]
Net income was $192 million during the three-month period ended June 27, 2025, compared to $139 million during the three-month period ended June 28, 2024, driven by the factors discussed above.

[0000866374-25-000043:mdna:92]
[same as prior period, unchanged from 0000866374-25-000008:mdna:97]

[0000866374-25-000043:mdna:93]
We continuously evaluate our ability to meet our obligations over the next 12 months and beyond and proactively reset our capital structure to improve maturities and liquidity. We expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of June 27, 2025, we had cash and cash equivalents of approximately $2.2 billion and bank and other borrowings of approximately $3.7 billion and had a $2.5 billion revolving credit facility under which we had no borrowings outstanding as of June 27, 2025. In July 2025, the $2.5 billion revolving credit facility was replaced by a new $2.75 billion revolving credit facility, which matures in July 2030. We also drew down $500 million from our Delayed Draw Term Loan which is due December 31, 2027 ("the "2027 Delayed Draw Term Loan") in the first quarter of fiscal year 2026. During the first quarter of fiscal year 2026, we repaid the 4.750% Senior Notes due June 2025. As of June 27, 2025, we were in compliance with the covenants under all of our credit facilities and indentures; we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures. We do not anticipate that the new credit facility will impact our compliance with covenants.

[0000866374-25-000043:mdna:94]
Cash provided by operating activities was $0.4 billion during the three-month period ended June 27, 2025, primarily driven by $0.2 billion of net income for the period plus $0.2 billion of non-cash charges such as depreciation, amortization, and stock-based compensation.

[0000866374-25-000043:mdna:95]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital increased approximately $0.5 billion to $3.5 billion as of June 27, 2025, from $3.0 billion as of March 31, 2025. The increase was primarily the result of a $0.5 billion decrease in the current portion of long-term debt driven by the repayment of the 4.750% Senior Notes during the first quarter. Other movements in working capital largely offset themselves with increases of $0.2 billion in accounts receivable, $0.2 billion in contract assets and $0.1 billion in inventory, against increases of $0.7 billion in accounts payable and $0.1 billion in other current liabilities.

[0000866374-25-000043:mdna:96]
Net cash used in investing activities was $0.2 billion during the three-month period ended June 27, 2025. This was primarily driven by $0.1 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our Automotive, CEC, and Industrial businesses as well as payment for a business acquisition during the period.

[0000866374-25-000043:mdna:97]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investors. Our adjusted free cash flow for the three-month periods ended June 27, 2025 and June 28, 2024 was an inflow of $0.3 billion and $0.2 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-25-000043:mdna:98]
|  | Three-Month Periods Ended |
|  | June 27, 2025 |  | June 28, 2024 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 399 |  |  | $ | 340 |  |
| Purchases of property and equipment | (133) |  |  | (111) |  |
| Proceeds from the disposition of property and equipment | 2 |  |  | 3 |  |
| Adjusted free cash flow | $ | 268 |  |  | $ | 232 |  |

[0000866374-25-000043:mdna:99]
Cash used by financing activities was $0.3 billion during the three-month period ended June 27, 2025, which was primarily driven by $0.2 billion of cash paid for the repurchase of our ordinary shares as our debt repayments and borrowings largely offset.

[0000866374-25-000043:mdna:100]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs

[0000866374-25-000043:mdna:101]
[same as prior period, unchanged from 0000866374-25-000008:mdna:46]

[0000866374-25-000043:mdna:102]
under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months and beyond. As of June 27, 2025 and March 31, 2025, approximately 81% of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $0.8 billion as of March 31, 2025). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-25-000043:mdna:103]
[same as prior period, unchanged from 0000866374-25-000008:mdna:109]

[0000866374-25-000043:mdna:104]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of June 27, 2025.

[0000866374-25-000043:mdna:105]
[same as prior period, unchanged from 0000866374-25-000008:mdna:111]

[0000866374-25-000043:mdna:106]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-25-000043:mdna:107]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1.7 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 8, 2024. During the three-month period ended June 27, 2025, we paid $0.2 billion to repurchase shares under the current repurchase plan at an average price of $34.29 per share. As of June 27, 2025, shares in the aggregate amount of $0.8 billion were available to be repurchased under the current plan.

[0000866374-25-000043:mdna:108]
[same as prior period, unchanged from 0000866374-25-000008:mdna:114]

[0000866374-25-000043:mdna:109]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2025.

[0000866374-25-000043:mdna:110]
In June 2025, the Company drew down the 2027 Delayed Draw Term Loan and repaid the 4.750% Senior Notes due June 2025. There were no other material changes in our contractual obligations and commitments as of June 27, 2025.
