# FLEX notes — 0000866374-25-000043


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-25-000043:notes:1]
[same as prior period, unchanged from 0000866374-25-000008:notes:1]

[0000866374-25-000043:notes:2]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, automotive, industrial, healthcare, industrial and power. As of June 27, 2025, Flex's two operating and reportable segments were as follows:

[0000866374-25-000043:notes:3]
[same as prior period, unchanged from 0000866374-25-000008:notes:3]

[0000866374-25-000043:notes:4]
◦Communications, Enterprise and Cloud ("CEC"), including data center, edge, and communications infrastructure

[0000866374-25-000043:notes:5]
◦Lifestyle, including appliances, floorcare, smart living, Heating, Ventilation and Air-Conditioning ("HVAC"), and power tools

[0000866374-25-000043:notes:6]
◦Consumer Devices, including mobile and high velocity consumer devices

[0000866374-25-000043:notes:7]
[same as prior period, unchanged from 0000866374-25-000008:notes:7]

[0000866374-25-000043:notes:8]
◦Industrial, including industrial devices, capital equipment, renewables, critical power and embedded power

[0000866374-25-000043:notes:9]
◦Automotive, including compute platforms, power electronics, motion, and interface

[0000866374-25-000043:notes:10]
◦Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-25-000043:notes:11]
[same as prior period, unchanged from 0000866374-25-000008:notes:11]

[0000866374-25-000043:notes:12]
[same as prior period, unchanged from 0000866374-25-000008:notes:12]

[0000866374-25-000043:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2025 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 27, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026.

[0000866374-25-000043:notes:14]
The first quarters for fiscal years 2026 and 2025 ended on June 27, 2025 and June 28, 2024, respectively, and are comprised of 88 and 89 days.

[0000866374-25-000043:notes:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest.

[0000866374-25-000043:notes:16]
[same as prior period, unchanged from 0000866374-25-000008:notes:18]

[0000866374-25-000043:notes:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and

[0000866374-25-000043:notes:18]
intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-25-000043:notes:19]
Recently Issued Accounting Pronouncements

[0000866374-25-000043:notes:20]
In November 2024, the FASB issued ASU 2024-03 "Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses", which requires public entities to disclose specified information about certain costs and expenses. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2028 and will be applied retrospectively to all prior periods presented on its consolidated financial statements. The Company is currently evaluating the guidance to determine the impact on the Company's disclosures. In January 2025, the FASB issued ASU 2025-01 on the same topic to clarify the amendments for ASU 2024-03 are effective for the Company in the fourth quarter of fiscal year 2028.

[0000866374-25-000043:notes:21]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-25-000043:notes:22]
[same as prior period, unchanged from 0000866374-25-000008:notes:24]

[0000866374-25-000043:notes:23]
[same as prior period, unchanged from 0000866374-25-000008:notes:25]

[0000866374-25-000043:notes:24]
|  | As of June 27, 2025 |  | As of March 31, 2025 |
|  | (In millions) |
| Raw materials | $ | 4,176 |  |  | $ | 4,092 |  |
| Work-in-progress | 516 |  |  | 485 |  |
| Finished goods | 516 |  |  | 494 |  |
|  | $ | 5,208 |  |  | $ | 5,071 |  |

[0000866374-25-000043:notes:25]
[same as prior period, unchanged from 0000866374-25-000008:notes:27]

[0000866374-25-000043:notes:26]
During the three-month period ended June 27, 2025, goodwill increased by $8 million from an acquisition completed in the first quarter of fiscal year 2026. See note 12 for further details.

[0000866374-25-000043:notes:27]
[same as prior period, unchanged from 0000866374-25-000008:notes:32]

[0000866374-25-000043:notes:28]
|  | As of June 27, 2025 |  | As of March 31, 2025 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 317 |  |  | $ | (128) |  |  | $ | 189 |  |  | $ | 383 |  |  | $ | (186) |  |  | $ | 197 |  |
| Licenses and other intangibles | 216 |  |  | (75) |  |  | 141 |  |  | 365 |  |  | (219) |  |  | 146 |  |
| Total | $ | 533 |  |  | $ | (203) |  |  | $ | 330 |  |  | $ | 748 |  |  | $ | (405) |  |  | $ | 343 |  |

[0000866374-25-000043:notes:29]
The gross carrying amounts of intangible assets are removed when fully amortized.

[0000866374-25-000043:notes:30]
[same as prior period, unchanged from 0000866374-25-000008:notes:35]

[0000866374-25-000043:notes:31]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2026 (1) |  | $ | 47 |  |
| 2027 |  | 58 |  |
| 2028 |  | 44 |  |
| 2029 |  | 41 |  |
| 2030 |  | 36 |  |
| Thereafter |  | 104 |  |
| Total amortization expense |  | $ | 330 |  |

[0000866374-25-000043:notes:32]
(1)Represents estimated amortization for the remaining nine-month period of the fiscal year ending March 31, 2026.

[0000866374-25-000043:notes:33]
[same as prior period, unchanged from 0000866374-25-000008:notes:39]

[0000866374-25-000043:notes:34]
Customer working capital advances were $1.5 billion and $1.6 billion as of June 27, 2025 and March 31, 2025, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-25-000043:notes:35]
[same as prior period, unchanged from 0000866374-25-000008:notes:41]

[0000866374-25-000043:notes:36]
Other non-current assets include deferred tax assets of $576 million and $577 million as of June 27, 2025 and March 31, 2025, respectively.

[0000866374-25-000043:notes:37]
[same as prior period, unchanged from 0000866374-25-000008:notes:43]

[0000866374-25-000043:notes:38]
Other current liabilities include customer-related accruals of $281 million and $246 million as of June 27, 2025 and March 31, 2025, respectively.

[0000866374-25-000043:notes:39]
[same as prior period, unchanged from 0000866374-25-000008:notes:45]

[0000866374-25-000043:notes:40]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due dates. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. The Company has no economic interest in a supplier’s decision to participate in the supplier finance programs.

[0000866374-25-000043:notes:41]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of June 27, 2025 and March 31, 2025 were $131 million and $119 million, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-25-000043:notes:42]
[same as prior period, unchanged from 0000866374-25-000008:notes:48]

[0000866374-25-000043:notes:43]
[same as prior period, unchanged from 0000866374-25-000008:notes:49]

[0000866374-25-000043:notes:44]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $450 million and $377 million as of June 27, 2025 and March 31, 2025,

[0000866374-25-000043:notes:45]
respectively, of which $406 million and $347 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-25-000043:notes:46]
[same as prior period, unchanged from 0000866374-25-000008:notes:51]

[0000866374-25-000043:notes:47]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time:

[0000866374-25-000043:notes:48]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
| Timing of Transfer |  |  |  |  | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | $ | 2,895 |  |  | $ | 2,873 |  |
| Over time |  |  |  |  | 796 |  |  | 492 |  |
| Total |  |  |  |  | 3,691 |  |  | 3,365 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 1,859 |  |  | 2,633 |  |
| Over time |  |  |  |  | 1,025 |  |  | 316 |  |
| Total |  |  |  |  | 2,884 |  |  | 2,949 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 4,754 |  |  | 5,506 |  |
| Over time |  |  |  |  | 1,821 |  |  | 808 |  |
| Total |  |  |  |  | $ | 6,575 |  |  | $ | 6,314 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-25-000043:notes:49]
SHARE-BASED COMPENSATION
Flex historically maintains share-based compensation plans at the corporate level. The Company grants equity compensation awards under its 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-25-000043:notes:50]
Share-Based Compensation Expense

[0000866374-25-000043:notes:51]
[same as prior period, unchanged from 0000866374-25-000008:notes:56]

[0000866374-25-000043:notes:52]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
|  |  |  |  |  | (In millions) |
| Cost of sales |  |  |  |  | $ | 8 |  |  | $ | 8 |  |
| Selling, general and administrative expenses |  |  |  |  | 26 |  |  | 24 |  |
| Total share-based compensation expense |  |  |  |  | $ | 34 |  |  | $ | 32 |  |

[0000866374-25-000043:notes:53]
[same as prior period, unchanged from 0000866374-25-000008:notes:58]

[0000866374-25-000043:notes:54]
During the three-month period ended June 27, 2025, the Company granted approximately 4.2 million restricted share unit ("RSU") awards. Of this amount, approximately 1.9 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, with an average grant date price of $43.55 per award. In addition, approximately 1.0 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, with an average grant date price of $45.03 per award. These performance-based RSUs include awards tied to the Company's adjusted earnings per share growth and awards tied to operating profit goals. The number of shares that will ultimately vest will range from zero up to a maximum of approximately 2.2 million based on the level of achievement of these performance conditions. The awards will cliff vest after a period of three years, depending on the specific performance metrics, to the extent such performance conditions have been met. Further, approximately 0.2 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards that are contingent on certain market conditions was estimated to be $58.55 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 0.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met. The remaining balance of approximately 1.1 million represents the number of shares issued

[0000866374-25-000043:notes:55]
upon the vesting of RSU awards above target levels based on the achievement of certain market and performance conditions for awards granted in fiscal year 2023. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-25-000043:notes:56]
As of June 27, 2025, approximately 10.2 million unvested RSU awards under the 2017 Plan were outstanding, of which vesting for a targeted amount of approximately 0.9 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of approximately 2.0 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to approximately 1.8 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to approximately 4.1 million based on the achievement levels. During the three-month period ended June 27, 2025, approximately 2.2 million shares vested in connection with the awards with market and performance conditions granted in fiscal year 2023.

[0000866374-25-000043:notes:57]
As of June 27, 2025, total unrecognized compensation expense related to unvested RSU awards under the 2017 Plan was approximately $281 million, and will be recognized over a weighted-average remaining vesting period of 2.4 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-25-000043:notes:58]
[same as prior period, unchanged from 0000866374-25-000008:notes:63]

[0000866374-25-000043:notes:59]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
|  |  |  |  |  | (In millions, except per share amounts) |
| Numerator: |  |  |  |  |  |  |  |
| Net income |  |  |  |  | $ | 192 |  |  | $ | 139 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding - basic |  |  |  |  | 374 |  |  | 402 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) |  |  |  |  | 7 |  |  | 9 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding - diluted |  |  |  |  | 381 |  |  | 411 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic |  |  |  |  | $ | 0.51 |  |  | $ | 0.35 |  |
| Diluted |  |  |  |  | $ | 0.50 |  |  | $ | 0.34 |  |

[0000866374-25-000043:notes:60]
(1)An immaterial amount of RSU awards for the three-month periods ended June 27, 2025 and June 28, 2024, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-25-000043:notes:61]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 27, 2025 and March 31, 2025 are as follows:

[0000866374-25-000043:notes:62]
|  | Maturity Date |  | As of June 27, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | — |  |  | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 677 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 675 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 290 |  |  | 269 |  |
| Debt issuance costs |  |  | (13) |  |  | (14) |  |
|  |  |  | 3,681 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (677) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,004 |  |  | $ | 2,483 |  |

[0000866374-25-000043:notes:63]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

[0000866374-25-000043:notes:64]
(2)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at SOFR plus 100 basis points.

[0000866374-25-000043:notes:65]
(3)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

[0000866374-25-000043:notes:66]
The weighted-average interest rate for the Company's long-term debt was 4.6% as of June 27, 2025 and March 31, 2025, respectively.

[0000866374-25-000043:notes:67]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 27, 2025 are as follows:

[0000866374-25-000043:notes:68]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2026 (1) |  | $ | 677 |  |
| 2027 |  | — |  |
| 2028 |  | 898 |  |
| 2029 |  | 29 |  |
| 2030 |  | 684 |  |
| Thereafter |  | 1,406 |  |
| Total |  | $ | 3,694 |  |

[0000866374-25-000043:notes:69]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2026.

[0000866374-25-000043:notes:70]
Term Loan due December 2027

[0000866374-25-000043:notes:71]
In March 2025, the Company entered into a delayed draw term loan agreement for an amount of $500 million. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general purposes. All borrowings on the delayed draw term loan will be come due on December 31, 2027. Interest is based on a Term SOFR-based formula plus a margin of 100 basis points. The Company has fully drawn the $500 million loan as of June 27, 2025.


## flex:InterestAndOtherNetTextBlock

[0000866374-25-000043:notes:72]
INTEREST EXPENSE AND INTEREST INCOME
Interest expense and interest income for the three-month periods ended June 27, 2025 and June 28, 2024 are composed of the following:

[0000866374-25-000043:notes:73]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
|  |  |  |  |  | (In millions) |
| Interest expenses on debt obligations |  |  |  |  | $ | 45 |  |  | $ | 43 |  |
| AR sale program related expenses |  |  |  |  | 6 |  |  | 13 |  |
| Interest income |  |  |  |  | (13) |  |  | (16) |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-25-000043:notes:74]
[same as prior period, unchanged from 0000866374-25-000008:notes:85]

[0000866374-25-000043:notes:75]
[same as prior period, unchanged from 0000866374-25-000008:notes:86]

[0000866374-25-000043:notes:76]
As of June 27, 2025, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $6.4 billion as summarized below:

[0000866374-25-000043:notes:77]
|  |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  | p |
| MXN |  | 505 |  |  | — |  |
| HUF |  | 416 |  |  | — |  |
| CNY |  | 203 |  |  | — |  |
| Other |  | 443 |  |  | 22 |  |
|  |  | 1,567 |  |  | 22 |  |
| Other Foreign Currency Contracts |  |  |  |  |
| EUR |  | 592 |  |  | 380 |  |
| CNY |  | 592 |  |  | 221 |  |
| MXN |  | 391 |  |  | 308 |  |
| MYR |  | 223 |  |  | 77 |  |
| BRL |  | — |  |  | 269 |  |
| Other |  | 861 |  |  | 852 |  |
|  |  | 2,659 |  |  | 2,107 |  |
| Total Notional Contract Value in USD |  | $ | 4,226 |  |  | $ | 2,129 |  |

[0000866374-25-000043:notes:78]
As of June 27, 2025, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the condensed consolidated statements of operations. The Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were $30 million as of June 27, 2025, and are expected to be recognized primarily as a component of cost of sales in the condensed

[0000866374-25-000043:notes:79]
consolidated statements of operations over the next twelve-month period, except for gains attributable to changes in fair value of the USD HUF cross currency swaps, which are discussed below.

[0000866374-25-000043:notes:80]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other current liabilities and other non-current liabilities as of June 27, 2025, and in other current assets and other non-current liabilities as of March 31, 2025, respectively. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-25-000043:notes:81]
The following table presents the fair value of the Company’s derivative instruments utilized for foreign currency risk management purposes at June 27, 2025 and March 31, 2025:

[0000866374-25-000043:notes:82]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | June 27,2025 |  | March 31,2025 |  | Balance SheetLocation |  | June 27,2025 |  | March 31,2025 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 50 |  |  | $ | 13 |  |  | Other current liabilities |  | $ | (5) |  |  | $ | (18) |  |
| Foreign currency contracts | Other non-current assets |  | $ | — |  |  | $ | — |  |  | Other non-current liabilities |  | $ | (21) |  |  | $ | (46) |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 21 |  |  | $ | 21 |  |  | Other current liabilities |  | $ | (11) |  |  | $ | (15) |  |

[0000866374-25-000043:notes:83]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with certain counterparties. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements. As such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-25-000043:notes:84]
[same as prior period, unchanged from 0000866374-25-000008:notes:94]

[0000866374-25-000043:notes:85]
|  | Three-Month Periods Ended |
|  | June 27, 2025 |  | June 28, 2024 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (19) |  |  | $ | (205) |  |  | $ | (224) |  |  | $ | 4 |  |  | $ | (199) |  |  | $ | (195) |  |
| Other comprehensive gain (loss) before reclassifications | 57 |  |  | 69 |  |  | 126 |  |  | (30) |  |  | (16) |  |  | (46) |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | (18) |  |  | — |  |  | (18) |  |  | 3 |  |  | — |  |  | 3 |  |
| Net current-period other comprehensive gain (loss) | 39 |  |  | 69 |  |  | 108 |  |  | (27) |  |  | (16) |  |  | (43) |  |
| Ending balance | $ | 20 |  |  | $ | (136) |  |  | $ | (116) |  |  | $ | (23) |  |  | $ | (215) |  |  | $ | (238) |  |

[0000866374-25-000043:notes:86]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended June 27, 2025 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in 
accumulated other comprehensive loss for the three-month periods ended June 27, 2025 and June 28, 2024 were $(11) million and $13 million, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-25-000043:notes:87]
TRADE RECEIVABLES SALES PROGRAMSThe Company sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.7 billion as of June 27, 2025 and March 31, 2025, respectively. For the three-month periods ended June 27, 2025 and June 28, 2024, total accounts receivable sold to certain third-party banking institutions was approximately $0.9 billion and $1.1 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-25-000043:notes:88]
[same as prior period, unchanged from 0000866374-25-000008:notes:99]

[0000866374-25-000043:notes:89]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of June 27, 2025 and March 31, 2025.

[0000866374-25-000043:notes:90]
[same as prior period, unchanged from 0000866374-25-000008:notes:101]

[0000866374-25-000043:notes:91]
[same as prior period, unchanged from 0000866374-25-000008:notes:102]

[0000866374-25-000043:notes:92]
[same as prior period, unchanged from 0000866374-25-000008:notes:103]

[0000866374-25-000043:notes:93]
[same as prior period, unchanged from 0000866374-25-000008:notes:104]

[0000866374-25-000043:notes:94]
[same as prior period, unchanged from 0000866374-25-000008:notes:105]

[0000866374-25-000043:notes:95]
The Company has accrued for contingent consideration related to an acquisition in fiscal year 2025, classified as a level 3 measurement in the fair value hierarchy due to significant unobservable inputs. Fair value is determined using internal cash flow models that incorporate unobservable inputs, including the probability of achieving performance milestones. As of June 27, 2025 and March 31, 2025, the balance of contingent consideration was $5 million.

[0000866374-25-000043:notes:96]
The significant inputs include the Company's probability assessments of expected future revenue during the earn-out periods, associated volatility, and a discount rate reflecting uncertainties in the obligation consistent with the terms of the purchase agreement. Significant changes in expected revenues or in the discount rate and volatility assumptions used would impact fair value estimates. The interrelationship between these inputs is not considered significant.

[0000866374-25-000043:notes:97]
During the three-month periods ended June 27, 2025, and June 28, 2024, there were no other additions to the accrual, payments, fair value adjustments, or unrealized gains or losses included in earnings.

[0000866374-25-000043:notes:98]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended June 27, 2025 and June 28, 2024.

[0000866374-25-000043:notes:99]
[same as prior period, unchanged from 0000866374-25-000008:notes:110]

[0000866374-25-000043:notes:100]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of June 27, 2025 and March 31, 2025:

[0000866374-25-000043:notes:101]
|  | Fair Value Measurements as of June 27, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,653 |  |  | $ | — |  |  | $ | 1,653 |  |
| Foreign currency contracts (Note 8) | — |  |  | 71 |  |  | — |  |  | 71 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 46 |  |  | — |  |  | 46 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (37) |  |  | $ | — |  |  | $ | (37) |  |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (5) |  |  | (5) |  |
|  | Fair Value Measurements as of March 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,535 |  |  | $ | — |  |  | $ | 1,535 |  |
| Foreign currency contracts (Note 8) | — |  |  | 34 |  |  | — |  |  | 34 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (79) |  |  | $ | — |  |  | $ | (79) |  |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (5) |  |  | (5) |  |

[0000866374-25-000043:notes:102]
[same as prior period, unchanged from 0000866374-25-000008:notes:113]

[0000866374-25-000043:notes:103]
[same as prior period, unchanged from 0000866374-25-000008:notes:114]

[0000866374-25-000043:notes:104]
|  | As of June 27, 2025 |  | As of March 31, 2025 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | — |  |  | — |  |  | 531 |  |  | 531 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 677 |  |  | 673 |  |  | 678 |  |  | 672 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 411 |  |  | 398 |  |  | 409 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 655 |  |  | 659 |  |  | 655 |  |  | 651 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 675 |  |  | 678 |  |  | 676 |  |  | 669 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 504 |  |  | 499 |  |  | 497 |  |  | Level 1 |
| Delayed Draw Term Loan due December 2027 | 500 |  |  | 500 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 290 |  |  | 232 |  |  | 269 |  |  | 215 |  |  | Level 2 |

[0000866374-25-000043:notes:105]
The Notes due June 2025, February 2026, January 2028, June 2029, May 2030 and January 2032 are valued based on broker trading prices in active markets. The Delayed Draw Term Loan due December 2027 bears interest at variable interest rates, therefore, as of June 27, 2027, the carrying amount approximates fair value. HUF Bonds are valued based on the broker trading prices in an inactive market.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-25-000043:notes:106]
BUSINESS ACQUISITIONS
On April 30, 2025, the Company completed the acquisition of a manufacturing business in Bielsko Biała, Poland, for total estimated purchase consideration of $35 million. The site is included in the FRS segment. The results of the acquired business are included in the Company’s condensed consolidated financial statements from the acquisition date. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed is based on their estimated fair values as of the date of acquisition. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of the acquisition. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the measurement period.

[0000866374-25-000043:notes:107]
The following represents the Company's initial allocation of the total purchase price to the acquired assets and liabilities of the acquired business (in millions):

[0000866374-25-000043:notes:108]
| Current Assets: |  |
| Inventory | $ | 15 |  |
| Unbilled Accounts Receivable | 9 |  |
| Accounts Receivable | 1 |  |
| Total current assets | 25 |  |
| Operating lease right-of-use assets, net | 28 |  |
| Property and equipment | 4 |  |
| Intangible assets | 2 |  |
| Goodwill | 8 |  |
| Total assets | $ | 67 |  |
| Current Liabilities: |  |
| Accrued payroll | $ | 4 |  |
| Operating lease liabilities | 2 |  |
| Total current liabilities | 6 |  |
| Operating lease liabilities, non-current | 26 |  |
| Total liabilities | 32 |  |
| Total aggregate purchase price | $ | 35 |  |

[0000866374-25-000043:notes:109]
Intangible assets of $2 million are comprised of customer related intangible assets as well as acquired technology, which will both be amortized over a weighted-average estimated useful life of 5 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-25-000043:notes:110]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-25-000043:notes:111]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-25-000043:notes:112]
The Company was involved in a commercial dispute related to a construction matter with related production objectives. Management had assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment recognized $50 million in Selling, general and administrative expenses in the fourth

[0000866374-25-000043:notes:113]
quarter of the fiscal year ended March 31, 2024 as an accrual. The parties reached a settlement in line with the accrued amount during the first quarter of fiscal year 2026 and the Company made an initial payment of $21 million in line with this agreement.

[0000866374-25-000043:notes:114]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. The Company was unsuccessful at the administrative level in two of the remaining assessments and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 37 million Brazilian reals (approximately USD $7 million). The Brazilian court ruled in favor of the Company on the first annulment action on March 7, 2025 and the assessment obligation has been canceled, although it remains subject to appeal. The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 60 million Brazilian reals (approximately USD $11 million). The Company is still awaiting a resolution of the second annulment action. The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on the remaining assessments and annulment actions in the near future.

[0000866374-25-000043:notes:115]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-25-000043:notes:116]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material effect on the Company’s financial position, results of operations or cash flows.

[0000866374-25-000043:notes:117]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-25-000043:notes:118]
SHARE REPURCHASES 
During the three-month period ended June 27, 2025, the Company repurchased 7.2 million shares at an aggregate purchase price of $247 million and retired all of these shares.

[0000866374-25-000043:notes:119]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.7 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 8, 2024. As of June 27, 2025, shares in the aggregate amount of $0.8 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-25-000043:notes:120]
[same as prior period, unchanged from 0000866374-25-000008:notes:137]

[0000866374-25-000043:notes:121]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income.  Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, certain restructuring charges, customer related asset impairment, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-25-000043:notes:122]
The Company's Chief Executive Officer is our Chief Operating Decision Maker ("CODM") who uses segment income in evaluating how we allocate resources, assess performance and make strategic and operational decisions.

[0000866374-25-000043:notes:123]
[same as prior period, unchanged from 0000866374-25-000008:notes:140]

[0000866374-25-000043:notes:124]
| Three Months Ended June 27, 2025 | FAS |  | FRS |  | Corporate & Other |  | Total |
| Net Sales | $ | 3,691 |  |  | $ | 2,884 |  |  | $ | — |  |  | $ | 6,575 |  |
| Cost of inventory | (2,732) |  |  | (1,927) |  |  | — |  |  | (4,659) |  |
| Manufacturing expenses | (634) |  |  | (681) |  |  | (5) |  |  | (1,320) |  |
| Segment selling, general and administrative expenses | (85) |  |  | (104) |  |  | (12) |  |  | (201) |  |
| Segment income | $ | 240 |  |  | $ | 172 |  |  | $ | (17) |  |  | $ | 395 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 21 |  |
| Stock-based compensation |  |  |  |  |  |  | 34 |  |
| Restructuring charges |  |  |  |  |  |  | 23 |  |
| Legal and other (1) |  |  |  |  |  |  | 6 |  |
| Interest expenses |  |  |  |  |  |  | 51 |  |
| Interest income |  |  |  |  |  |  | 13 |  |
| Other charges (income), net |  |  |  |  |  |  | 7 |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (20) |  |
| Income before income taxes |  |  |  |  |  |  | $ | 246 |  |

[0000866374-25-000043:notes:125]
(1)Legal and other consists of costs not directly related to core business results and including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and asset impairment. During the first quarter of fiscal year 2026, legal costs were primarily related to costs from acquisitions occurring in fiscal year 2025 and the first quarter of fiscal year 2026.

[0000866374-25-000043:notes:126]
| Three Months Ended June 28, 2024 | FAS |  | FRS |  | Corporate & Other |  | Total |
| Net Sales | $ | 3,365 |  |  | $ | 2,949 |  |  | $ | — |  |  | $ | 6,314 |  |
| Cost of inventory | (2,496) |  |  | (2,003) |  |  | — |  |  | (4,499) |  |
| Manufacturing expenses | (613) |  |  | (699) |  |  | (8) |  |  | (1,320) |  |
| Segment selling, general and administrative expenses | (77) |  |  | (100) |  |  | (12) |  |  | (189) |  |
| Segment income | $ | 179 |  |  | $ | 147 |  |  | $ | (20) |  |  | $ | 306 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 16 |  |
| Stock-based compensation |  |  |  |  |  |  | 32 |  |
| Restructuring charges |  |  |  |  |  |  | 25 |  |
| Interest expenses |  |  |  |  |  |  | 56 |  |
| Interest income |  |  |  |  |  |  | 16 |  |
| Other charges (income), net |  |  |  |  |  |  | 2 |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | 1 |  |
| Income before income taxes |  |  |  |  |  |  | $ | 192 |  |

[0000866374-25-000043:notes:127]
Corporate and other primarily includes corporate service costs that are not included in the CODM's assessment of the performance of each of the identified reportable segments.

[0000866374-25-000043:notes:128]
[same as prior period, unchanged from 0000866374-25-000008:notes:145]

[0000866374-25-000043:notes:129]
Property and equipment on a segment basis is not separately identified and is not internally reported by segment to the Company's CODM as described above.

[0000866374-25-000043:notes:130]
Total depreciation expense, including amounts allocated to the reportable segments and Corporate and Other for the three-month periods ended June 27, 2025 and June 28, 2024 as follows:

[0000866374-25-000043:notes:131]
|  | Three-Month Periods Ended |
|  | June 27, 2025 |  | June 28, 2024 |
|  | (In millions) |
| Depreciation expense: |  |  |  |
| Flex Agility Solutions | $ | 50 |  |  | $ | 44 |  |
| Flex Reliability Solutions | 62 |  |  | 62 |  |
| Corporate and Other | 3 |  |  | 4 |  |
| Total depreciation expense | $ | 115 |  |  | $ | 110 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-25-000043:notes:132]
RESTRUCTURING CHARGES
The Company continued to improve operational efficiencies through targeted restructuring activities during the first quarter of fiscal year 2026. During the three-month period ended June 27, 2025, the Company recognized approximately $23 million of restructuring charges, most of which related to employee severance.

[0000866374-25-000043:notes:133]
The following table summarizes the provisions, respective payments, and remaining accrued balance for charges incurred as of June 27, 2025:

[0000866374-25-000043:notes:134]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2025 | $ | 51 |  |  | $ | — |  |  | $ | — |  |  | $ | 51 |  |
| Provision for net charges incurred | 19 |  |  | 3 |  |  | 1 |  |  | 23 |  |
| Cash payments | (18) |  |  | — |  |  | (1) |  |  | (19) |  |
| Non-cash reductions | — |  |  | (3) |  |  | — |  |  | (3) |  |
| Other adjustments | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Balance as of June 27, 2025 | 52 |  |  | — |  |  | 1 |  |  | 53 |  |
| Less: Current portion (classified as other current liabilities) | 52 |  |  | — |  |  | 1 |  |  | 53 |  |
| Accrued restructuring costs, net of current portion (classified as other non-current liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:SubsequentEventsTextBlock

[0000866374-25-000043:notes:135]
SUBSEQUENT EVENTS
On July 15, 2025, the Company entered into a new $2.75 billion credit facility (the "New Credit Facility") which matures in July 2030 and consists of a $2.75 billion revolving credit facility with a sub-limit of $400 million available for swing line loans and a sub-limit of $200 million available for the issuance of letters of credit. The New Credit Facility replaced the previous $2.5 billion credit facility. Under the New Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are determined based on standard benchmark interest rates subject to potential adjustment based on the Company’s credit rating.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000866374-25-000043:notes:136]
On June 11, 2025, Daniel J. Wendler, Senior Vice President and Chief Accounting Officer, adopted a trading plan that provides for the sale of up to 10,000 ordinary shares of the Company. The plan will terminate on June 11, 2026, subject to early termination for certain specified events set forth in the plan.

[0000866374-25-000043:notes:137]
On June 17, 2025, Michael P. Hartung, President and Chief Commercial Officer, adopted a trading plan that provides for the sale of up to 90,000 ordinary shares of the Company. The plan will terminate on December 31, 2025, subject to early termination for certain specified events set forth in the plan.
