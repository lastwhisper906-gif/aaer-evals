# FLEX 10-Q controls and the auditor's report


## item_4_controls

[0000866374-25-000043:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000866374-25-000043:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures

[0000866374-25-000043:item_4_controls:3]
The Company's management, with the participation of the Chief Executive Officer and Chief Financial Officer has evaluated the effectiveness of the Company's disclosure controls and procedures (as defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) as of June 27, 2025. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer concluded that, as of June 27, 2025, the Company's disclosure controls and procedures were effective in ensuring that information required to be disclosed by the Company in reports that it

[0000866374-25-000043:item_4_controls:4]
31

[0000866374-25-000043:item_4_controls:5]
files or submits under the Exchange Act, is (i) recorded, processed, summarized and reported within the time periods specified in the SEC's rules and forms and (ii) accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000866374-25-000043:item_4_controls:6]
(b) Changes in Internal Control Over Financial Reporting

[0000866374-25-000043:item_4_controls:7]
There were no changes in our internal control over financial reporting that occurred during our quarter ended June 27, 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000866374-25-000043:item_4_controls:8]
32
