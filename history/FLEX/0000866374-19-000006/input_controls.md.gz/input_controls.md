# FLEX 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000866374-19-000006:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0000866374-19-000006:item_9a:2]
| (a) | Evaluation of Disclosure Controls and Procedures |

[0000866374-19-000006:item_9a:3]
The Company's management, with the participation of the Chief Executive Officer and Chief Financial Officer has evaluated the effectiveness of the Company's disclosure controls and procedures (as defined in Rule 13a-15(e) under the Exchange Act) as of March 31, 2019. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer concluded that, as of March 31, 2019, the Company's disclosure controls and procedures were effective in ensuring that information required to be disclosed by the Company in reports that it files or submits under the Securities Exchange Act of

[0000866374-19-000006:item_9a:4]
1934, as amended, is (i) recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms and (ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000866374-19-000006:item_9a:5]
| (b) | Management's Annual Report on Internal Control over Financial Reporting |

[0000866374-19-000006:item_9a:6]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Rule 13a- 15(f) under the Securities Exchange Act of 1934, as amended. Internal control over financial reporting consists of policies and procedures that: (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (2) are designed and operated to provide reasonable assurance regarding the reliability of the Company's financial reporting and the Company's process for the preparation of financial statements for external purposes in accordance with generally accepted accounting principles and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of the Company’s assets that could have a material effect on the financial statements. Because of its inherent limitations, a system of internal control over financial reporting can provide only reasonable assurance and may not prevent or detect misstatements or prevent or detect instances of fraud. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of simple error or mistake. Additionally, controls may be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the control. The projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000866374-19-000006:item_9a:7]
As of March 31, 2019, under the supervision and with the participation of management, including the Company's Chief Executive Officer and Chief Financial Officer, an evaluation was conducted of the effectiveness of the Company's internal control over financial reporting based on the framework in Internal Control—Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO"). Based on that evaluation, management concluded that the Company's internal control over financial reporting was effective as of March 31, 2019.

[0000866374-19-000006:item_9a:8]
| (c) | Attestation Report of the Registered Public Accounting Firm |

[0000866374-19-000006:item_9a:9]
The effectiveness of the Company's internal control over financial reporting as of March 31, 2019 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, as stated in their report which appears in this Item under the heading "Report of Independent Registered Public Accounting Firm."

[0000866374-19-000006:item_9a:10]
(d)  Changes in Internal Control Over Financial Reporting

[0000866374-19-000006:item_9a:11]
Throughout fiscal year 2019, we implemented enhanced and additional procedures to remediate the control deficiencies that aggregated to material weaknesses in our internal control over financial reporting relating to the accounting for customer contractual obligations and aspects of our control environment and monitoring activities as disclosed in Item 9A on Form 10-K for the fiscal year ended March 31, 2018.

[0000866374-19-000006:item_9a:12]
Management, with the oversight of the Audit Committee, took the following steps as part of our remediation efforts during fiscal 2019:

[0000866374-19-000006:item_9a:13]
| • | Designed and implemented additional site level controls related to accounting for customer contractual obligations including establishing criteria for effective contract reviews and approvals with enhanced documentation to evidence judgements and estimates. |

[0000866374-19-000006:item_9a:14]
| • | Designed and implemented a centralized Contract Management Office responsible for the determination of the appropriate accounting on material contracts including maintaining proper evidence of review. |

[0000866374-19-000006:item_9a:15]
| • | Designed and implemented centralized oversight controls that provide enhanced visibility to the accounting for customer contracts to ensure improved monitoring and detection of material errors related to certain decentralized activities. |

[0000866374-19-000006:item_9a:16]
| • | Enhanced the quality and the frequency of training across all levels to improve awareness of Company policies and knowledge of the expected standards of conduct. |

[0000866374-19-000006:item_9a:17]
Given the remediation efforts noted above, testing of applicable controls completed during the fourth quarter and the determination that controls are designed and operating effectively, management has concluded that the material weaknesses previously identified have been remediated as of March 31, 2019.

[0000866374-19-000006:item_9a:18]
Other than the changes described above there have not been any changes in our internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) as of March 31, 2019 that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000866374-19-000006:item_9a:19]
107

[0000866374-19-000006:item_9a:20]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000866374-19-000006:item_9a:21]
To the Board of Directors and Shareholders of Flex Ltd., Singapore

[0000866374-19-000006:item_9a:22]
Opinion on Internal Control over Financial Reporting

[0000866374-19-000006:item_9a:23]
We have audited the internal control over financial reporting of Flex Ltd. and subsidiaries (the "Company") as of March 31, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission(COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of March 31, 2019, based on the criteria established in Internal Control - Integrated Framework (2013) issued by COSO.

[0000866374-19-000006:item_9a:24]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States), the consolidated financial statements as of and for the year ended March 31, 2019 of the Company and our report dated May 20, 2019, expressed an unqualified opinion on those financial statements and included an explanatory paragraph related to the Company’s change in method of accounting for revenue from contracts with customers in fiscal year 2019 due to the adoption of Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers and the Company’s change in method of accounting for cash receipts on the deferred purchase price from asset-backed securitization programs in fiscal year 2019 due to the adoption of ASU 2016-15 Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments.

[0000866374-19-000006:item_9a:25]
Basis for Opinion

[0000866374-19-000006:item_9a:26]
The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Annual Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company's internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000866374-19-000006:item_9a:27]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000866374-19-000006:item_9a:28]
Definition and Limitations of Internal Control over Financial Reporting

[0000866374-19-000006:item_9a:29]
A company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles.  A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

[0000866374-19-000006:item_9a:30]
Because of the inherent limitations, internal control over financial reporting, may not prevent or detect misstatements. Also, projections of any evaluation of the effectiveness to future periods are subject to the risk that the controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000866374-19-000006:item_9a:31]
/s/ DELOITTE & TOUCHE LLP

[0000866374-19-000006:item_9a:32]
San Jose, California

[0000866374-19-000006:item_9a:33]
May 20, 2019
