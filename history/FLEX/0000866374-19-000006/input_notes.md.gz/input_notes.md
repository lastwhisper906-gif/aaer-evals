# FLEX notes — 0000866374-19-000006


## flex:BasisOfPresentationAndPrinciplesOfConsolidationPolicyTextBlock

[0000866374-19-000006:notes:1]
Basis of Presentation and Principles of Consolidation

[0000866374-19-000006:notes:2]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of March 31, 2019, the noncontrolling interest was not material as a result of the deconsolidation of one of the Company's subsidiaries. In prior years, the noncontrolling interest was included on the consolidated balance sheets as a component of total shareholders' equity. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the consolidated statements of operations.


## flex:InterestAndOtherNetTextBlock

[0000866374-19-000006:notes:3]
INTEREST AND OTHER, NET

[0000866374-19-000006:notes:4]
Interest and other, net for the fiscal years ended March 31, 2019, 2018 and 2017 are primarily composed of the following:

[0000866374-19-000006:notes:5]
|  | Fiscal Year Ended March 31 |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Interest expenses on debt obligations | $ | 145,658 |  |  | $ | 123,098 |  |  | $ | 107,978 |  |
| ABS and AR sales programs related expenses | 46,344 |  |  | 25,002 |  |  | 15,252 |  |
| Interest income | (19,496 | ) |  | (18,840 | ) |  | (12,084 | ) |
| Gain on foreign exchange transactions | (1,175 | ) |  | (15,222 | ) |  | (16,528 | ) |


## flex:ScheduleOfShareBonusAwardsWithMarketConditionsTableTextBlock

[0000866374-19-000006:notes:6]
Of the 14.9 million unvested restricted share unit awards outstanding under all plans as of the fiscal year ended March 31, 2019, approximately 2.5 million unvested restricted share unit awards represent the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-19-000006:notes:7]
|  |  | Targetednumber ofawards as ofMarch 31, 2019(in shares) |  |  |  | Range of sharesthat may be issued (1) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |
|  |  |  | Assessment dates |
| Year of grant |  |  | Minimum |  | Maximum |  |
| Fiscal 2019 |  | 1,316,279 |  |  | $ | 14.00 |  |  | — |  |  | 2,632,558 |  |  | June 2021 |
| Fiscal 2018 |  | 586,077 |  |  | $ | 20.25 |  |  | — |  |  | 1,172,154 |  |  | June 2020 |
| Fiscal 2017 |  | 619,574 |  |  | $ | 17.57 |  |  | — |  |  | 1,239,148 |  |  | June 2019 |
| Totals |  | 2,521,930 |  |  |  |  |  | — |  |  | 5,043,860 |  |  |  |

[0000866374-19-000006:notes:8]
| (1) | Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against the Standard and Poor's ("S&P") 500 Composite Index. |


## flex:ScheduleOfTaxLossesAndOtherCarryforwardsTableTextBlock

[0000866374-19-000006:notes:9]
These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-19-000006:notes:10]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
|  | (In thousands) |
| 2020 - 2025 | $ | 606,378 |  |
| 2026 - 2031 | 444,040 |  |
| 2032 and post | 295,361 |  |
| Indefinite | 691,313 |  |
|  | $ | 2,037,092 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000866374-19-000006:notes:11]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2019, 2018 and 2017:

[0000866374-19-000006:notes:12]
|  | Balance atBeginningof Year |  | Charged toCosts andExpenses |  | Deductions/Write-Offs |  | Balance atEnd ofYear |
|  | (In thousands) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2017 | $ | 64,608 |  |  | $ | (184 | ) |  | $ | (7,122 | ) |  | $ | 57,302 |  |
| Year ended March 31, 2018 | 57,302 |  |  | 8,225 |  |  | (5,476 | ) |  | 60,051 |  |
| Year ended March 31, 2019 (1) | 60,051 |  |  | 41,977 |  |  | (10,632 | ) |  | 91,396 |  |

[0000866374-19-000006:notes:13]
| (1) | Charges incurred during fiscal year 2019 are primarily for costs and expenses related to various distressed customers. |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-19-000006:notes:14]
SUMMARY OF ACCOUNTING POLICIES

[0000866374-19-000006:notes:15]
Use of Estimates

[0000866374-19-000006:notes:16]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments including highly liquid investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-19-000006:notes:17]
Translation of Foreign Currencies

[0000866374-19-000006:notes:18]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive loss, a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for all periods presented, and have been classified as a component of interest and other, net in the consolidated statements of operations.

[0000866374-19-000006:notes:19]
Revenue Recognition

[0000866374-19-000006:notes:20]
In determining the appropriate amount of revenue to recognize, Flex applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). Flex is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, it is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and Flex has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to note 3 "Revenue Recognition" for further details.

[0000866374-19-000006:notes:21]
On April 1, 2018, the Company adopted the Accounting Standard Codification 606 ("ASC 606") using the modified retrospective approach by applying the guidance to all open contracts at the adoption date and has implemented revised accounting policies, new operational and financial reporting processes, enhanced systems capabilities and relevant internal controls.

[0000866374-19-000006:notes:22]
As part of adopting ASC 606, revenue for certain customer contracts where the Company is manufacturing products for which there is no alternative use and the Company has an enforceable right to payment including a reasonable profit for work-in-progress, revenue is recognized over time (i.e., as the Company manufactures the product) instead of upon shipment of products. In addition to the following disclosures, note 3 "Revenue Recognition" provides further disclosures required by the new standard.

[0000866374-19-000006:notes:23]
The cumulative effect of change made to the Company's April 1, 2018 condensed consolidated balance sheet for the adoption of ASC 606 was as follows:

[0000866374-19-000006:notes:24]
| Condensed Consolidated Balance Sheet |  |  |  |  |  |
|  | Impact of Adopting ASC 606 |
|  | Balance at March 31, 2018 |  | Adjustments |  | Balance at April 1, 2018 |
|  | (In thousands) |
| ASSETS |  |  |  |  |  |
| Contract assets | $ | — |  |  | $ | 451,287 |  |  | $ | 451,287 |  |
| Inventories | 3,799,829 |  |  | (447,752 | ) |  | 3,352,077 |  |
| Other current assets | 1,380,466 |  |  | (51,479 | ) |  | 1,328,987 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Other current liabilities | 1,719,418 |  |  | (87,897 | ) |  | 1,631,521 |  |
| Other liabilities | 531,587 |  |  | 2,098 |  |  | 533,685 |  |
| Accumulated deficit | $ | (3,144,114 | ) |  | $ | 37,855 |  |  | $ | (3,106,259 | ) |

[0000866374-19-000006:notes:25]
The adoption of ASC 606 resulted in the establishment of contract asset and contract liability balance sheet accounts and in the reclassification to these new accounts from certain asset and liability accounts, primarily inventories. The decrease in accumulated deficit in the table above reflects $37.9 million of net adjustments to the balance sheet as of April 1, 2018, resulting from the adoption of ASC 606 primarily related to certain customer contracts requiring an over-time method of revenue recognition. The declines in inventories and other current assets reflect reclassifications to contract assets due to the earlier recognition of certain costs of products sold for over-time contracts. The decline in other current liabilities is primarily due to the reclassification of payments from customers in advance of work performed to contract assets to reflect the net position of the related over-time contracts.

[0000866374-19-000006:notes:26]
The following tables summarize the impacts of ASC 606 adoption on the Company’s consolidated balance sheets and consolidated statements of operations:

[0000866374-19-000006:notes:27]
| Condensed Consolidated Balance Sheet |  |  |  |  |  |
| As of March 31, 2019 |  |  |  |  |  |
|  | Impact of Adopting ASC 606 |
|  | As Reported |  | Adjustments |  | Balance without ASC 606 Adoption |
|  | (In thousands) |
| ASSETS |  |  |  |  |  |
| Contract assets | $ | 216,202 |  |  | $ | (216,202 | ) |  | $ | — |  |
| Inventories | 3,722,854 |  |  | 252,844 |  |  | 3,975,698 |  |
| Other current assets | 854,790 |  |  | 8,865 |  |  | 863,655 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Other current liabilities | 1,426,075 |  |  | 65,705 |  |  | 1,491,780 |  |
| Accumulated deficit | $ | (3,012,012 | ) |  | $ | (35,114 | ) |  | $ | (3,047,126 | ) |

[0000866374-19-000006:notes:28]
| Condensed Consolidated Statement of Operations |  |  |  |  |  |
|  | Fiscal Year Ended March 31, 2019 |
|  | Impact of Adopting ASC 606 |
|  | As Reported |  | Adjustments |  | Balance without ASC 606 Adoption |
|  | (In thousands) |
| Net sales | $ | 26,210,511 |  |  | $ | (25,665 | ) |  | $ | 26,184,846 |  |
| Cost of sales (including restructuring charges) | 24,692,736 |  |  | (28,406 | ) |  | 24,664,330 |  |
| Gross profit | $ | 1,517,775 |  |  | $ | 2,741 |  |  | $ | 1,520,516 |  |

[0000866374-19-000006:notes:29]
In the first quarter of fiscal year 2019, to align contractual terms across the vast majority of customers to allow the Company to efficiently and accurately manage its contracts the Company waived certain contractual rights to bill profit for work in progress in the event of a contract termination, which is expected to be infrequent. These modifications resulted in revenue from these customers being recognized upon shipment of products, rather than over time (i.e., as the Company manufactures products) as further explained in note 3. The result of the modifications for the fiscal year 2019 reduced revenue and gross profit by approximately $132.7 million and $9.3 million, respectively, compared to amounts that would have been reported both (i) under ASC 606 had the Company not amended the contracts, and (ii) had the Company not adopted ASC 606.

[0000866374-19-000006:notes:30]
The impacts to revenue and gross profit as a result of the adoption of ASC 606 are driven by a number of factors including the timing of inventory levels for over time ("OT") customers at the end of each reporting period and the mix of customer profitability.

[0000866374-19-000006:notes:31]
For the fiscal year ended March 31, 2019 the as reported revenue was approximately $25.7 million higher and the gross profit approximately $2.7 million lower than it would have been without the adoption of ASC 606. Additional revenue of $158.4 million was reported under ASC 606 due to the accelerated timing of recognition of revenue for contracts which meet the criteria for over-time recognition and revenue recognized for certain contracts that no longer qualify for net revenue treatment. Approximately $6.5 million of additional gross profit was recognized on the customers qualifying for accelerated revenue recognition. These increases were offset by reductions of $132.7 million of revenue and $9.3 million of gross profit respectively, as a result of the waiver of contract rights noted above. There was no material tax impact for the fiscal year ended March 31, 2019 from the adoption of ASC 606.

[0000866374-19-000006:notes:32]
The Company applies the following practical expedients:

[0000866374-19-000006:notes:33]
| • | The Company elected to not disclose information about remaining performance obligations as its performance obligations generally have an expected duration of one year or less. |

[0000866374-19-000006:notes:34]
| • | In accordance with ASC 606-10-25-18B the Company will account for certain shipping and handling as activities to fulfill the promise to transfer the good, instead of a promised service to its customer. |

[0000866374-19-000006:notes:35]
| • | In accordance with ASC 606-10-32-18 the Company elected to not adjust the promised amount of consideration for the effects of a significant financing component as the Company expects, at contract inception, that the period between when the entity transfers a promised good or service to a customer and when the customer pays for that good or service will generally be one year or less. |

[0000866374-19-000006:notes:36]
Concentration of Credit Risk

[0000866374-19-000006:notes:37]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, derivative instruments, and cash and cash equivalents.

[0000866374-19-000006:notes:38]
Customer Credit Risk

[0000866374-19-000006:notes:39]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-19-000006:notes:40]
No customer accounted for greater than 10% of the Company's net sales in fiscal years 2019, 2018 and 2017. One customer within the Company's CTG segment accounted for approximately 11% of the Company's total balance of accounts receivable, net in fiscal year 2019. One customer within the Company's CTG segment accounted for approximately 17% of the Company's total balances of accounts receivable, net in fiscal years 2018 and 2017, respectively.

[0000866374-19-000006:notes:41]
The Company's ten largest customers accounted for approximately 43%, 41% and 43%, of its net sales in fiscal years 2019, 2018 and 2017, respectively.

[0000866374-19-000006:notes:42]
Derivative Instruments

[0000866374-19-000006:notes:43]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 8.

[0000866374-19-000006:notes:44]
Cash and Cash Equivalents

[0000866374-19-000006:notes:45]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-19-000006:notes:46]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-19-000006:notes:47]
Cash and cash equivalents consisted of the following:

[0000866374-19-000006:notes:48]
|  | As of March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Cash and bank balances | $ | 1,222,737 |  |  | $ | 1,019,802 |  |
| Money market funds and time deposits | 473,888 |  |  | 452,622 |  |
|  | $ | 1,696,625 |  |  | $ | 1,472,424 |  |

[0000866374-19-000006:notes:49]
Inventories

[0000866374-19-000006:notes:50]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or net realizable value write-downs, were as follows:

[0000866374-19-000006:notes:51]
|  | As of March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Raw materials | $ | 2,922,101 |  |  | $ | 2,760,410 |  |
| Work-in-progress | 366,135 |  |  | 450,569 |  |
| Finished goods | 434,618 |  |  | 588,850 |  |
|  | $ | 3,722,854 |  |  | $ | 3,799,829 |  |

[0000866374-19-000006:notes:52]
Due to the adoption of ASC 606, amounts that would have been reported as inventory under prior guidance are now included in contract assets or liabilities, depending on the net position of the contract, as disclosed above. As a result of this accounting change, work-in-progress and finished goods as of March 31, 2019 are $252.8 million less than they would have been, had the Company not adopted ASC 606. The comparative information as of March 31, 2018, has not been restated and continues to be reported under the accounting standards in effect at that time.

[0000866374-19-000006:notes:53]
Property and Equipment, Net

[0000866374-19-000006:notes:54]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are depreciated over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment was comprised of the following:

[0000866374-19-000006:notes:55]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2019 |  | 2018 |
|  |  |  | (In thousands) |
| Machinery and equipment | 3 - 10 |  | $ | 3,305,335 |  |  | $ | 3,004,707 |  |
| Buildings | 30 |  | 1,111,708 |  |  | 1,154,881 |  |
| Leasehold improvements | up to 30 |  | 453,119 |  |  | 414,917 |  |
| Furniture, fixtures, computer equipment and software | 3 - 7 |  | 501,994 |  |  | 482,248 |  |
| Land | — |  | 121,976 |  |  | 152,992 |  |
| Construction-in-progress | — |  | 291,458 |  |  | 287,724 |  |
|  |  |  | 5,785,590 |  |  | 5,497,469 |  |
| Accumulated depreciation and amortization |  |  | (3,449,377 | ) |  | (3,257,963 | ) |
| Property and equipment, net |  |  | $ | 2,336,213 |  |  | $ | 2,239,506 |  |

[0000866374-19-000006:notes:56]
Total depreciation expense associated with property and equipment was approximately $433.4 million, $434.4 million and $432.2 million in fiscal years 2019, 2018 and 2017, respectively.

[0000866374-19-000006:notes:57]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-19-000006:notes:58]
Deferred Income Taxes

[0000866374-19-000006:notes:59]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-19-000006:notes:60]
Accounting for Business and Asset Acquisitions

[0000866374-19-000006:notes:61]
The Company has strategically pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. During fiscal year 2019, the Company adopted the Accounting Standard Update (ASU) No. 2017-01 “Clarifying the Definition of a Business” which did not have a material impact to its financial position as there were no material acquisitions during the period (Refer to "Recently Adopted Accounting Pronouncement" below for more details on the ASU). The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0000866374-19-000006:notes:62]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-19-000006:notes:63]
Goodwill

[0000866374-19-000006:notes:64]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require management to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider its budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparable and credit ratings. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of the Company's goodwill. During fiscal year 2019, the Company adopted ASU 2017-04 "Simplifying the Test for Goodwill Impairment", which simplifies the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. The ASU did not have a material impact to Flex's financial position during the period as there were no identified impairments during the period. (Refer to "Recently Adopted Accounting Pronouncement" below for more details on the ASU).

[0000866374-19-000006:notes:65]
If the recorded value of the assets, including goodwill, and liabilities ("net book value") of any reporting unit exceeds its fair value, an impairment loss may be required to be recognized. Further, to the extent the net book value of the Company as a whole is greater than its fair value in the aggregate, all, or a significant portion of its goodwill may be considered impaired.

[0000866374-19-000006:notes:66]
The Company has four reporting units, which correspond to its four reportable operating segments: HRS, IEI, CEC and CTG. The Company concluded that there was no change to its reporting units in fiscal year 2019 and performed its goodwill impairment assessment on January 1, 2019. The Company performed a quantitative assessment of its goodwill and determined that no impairment existed as of the date of the impairment test because the fair value of each one of its reporting units exceeded its respective carrying value. As of the date of the impairment test, all reporting units' fair values were 25% or more, over their respective carrying values, with the exception of the CTG reporting unit which was 22% in excess of its carrying value. The estimated future results for CTG used in the impairment analysis reflect the Company’s revised strategy including the wind down of the Company's NIKE operations in Mexico, further restrictions on capital expenditures related to the Company's expansion into India and the Company's focus on partnering with well-funded, leading multi-national brands that control multiple categories of products and have regional demand requirements.

[0000866374-19-000006:notes:67]
The following table summarizes the activity in the Company's goodwill during fiscal years 2019 and 2018 (in thousands):

[0000866374-19-000006:notes:68]
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Balance, as of March 31, 2017 | $ | 420,935 |  |  | $ | 337,707 |  |  | $ | 115,002 |  |  | $ | 111,223 |  |  | $ | 984,867 |  |
| Additions (1) | 75,280 |  |  | — |  |  | 9,730 |  |  | — |  |  | 85,010 |  |
| Divestitures (2) | — |  |  | — |  |  | — |  |  | (3,475 | ) |  | (3,475 | ) |
| Foreign currency translation adjustments (3) | 54,768 |  |  | — |  |  | — |  |  | — |  |  | 54,768 |  |
| Balance, as of March 31, 2018 | 550,983 |  |  | 337,707 |  |  | 124,732 |  |  | 107,748 |  |  | 1,121,170 |  |
| Additions (1) | — |  |  | — |  |  | 10,984 |  |  | — |  |  | 10,984 |  |
| Divestitures (2) | (5,303 | ) |  | (4,450 | ) |  | (6,391 | ) |  | (4,484 | ) |  | (20,628 | ) |
| Foreign currency translation adjustments (3) | (38,471 | ) |  | — |  |  | — |  |  | — |  |  | (38,471 | ) |
| Balance, as of March 31, 2019 | $ | 507,209 |  |  | $ | 333,257 |  |  | $ | 129,325 |  |  | $ | 103,264 |  |  | $ | 1,073,055 |  |

[0000866374-19-000006:notes:69]
_______________________________________________________________________________

[0000866374-19-000006:notes:70]
| (1) | The goodwill generated from the Company's business combinations completed during the fiscal years 2019 and 2018 are primarily related to value placed on the employee workforce, service offerings, capabilities and expected synergies. The goodwill is not deductible for income tax purposes. Refer to the discussion of the Company's business acquisitions in note 17. Also included in fiscal year 2018 were adjustments based on management's estimates resulting from its review and finalization of the valuation of assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition. These adjustments were not individually, nor in the aggregate, significant to the Company during the fiscal year ended March 31, 2018. |

[0000866374-19-000006:notes:71]
| (2) | During the fiscal year ended March 31, 2019, the Company divested its China-based Multek operations along with another non-strategic immaterial business, and as a result, recorded an aggregate reduction of goodwill of $20.6 million. During the fiscal year ended March 31, 2018, the Company disposed of Wink Labs Inc. ("Wink"), a business within the CTG segment. |

[0000866374-19-000006:notes:72]
| (3) | During the fiscal years ended March 31, 2019 and 2018, the Company recorded $38.5 million and $54.8 million, respectively, of foreign currency translation adjustments primarily related to historical acquisitions, as the U.S. Dollar fluctuated against foreign currencies. |

[0000866374-19-000006:notes:73]
Other Intangible Assets

[0000866374-19-000006:notes:74]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2019 and concluded that such amounts continued to be recoverable.

[0000866374-19-000006:notes:75]
Intangible assets are comprised of customer-related intangible assets that include contractual agreements and customer relationships; and licenses and other intangible assets, that are primarily comprised of licenses and also include patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight-line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability. The components of acquired intangible assets are as follows:

[0000866374-19-000006:notes:76]
|  | As of March 31, 2019 |  | As of March 31, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 297,306 |  |  | $ | (113,627 | ) |  | $ | 183,679 |  |  | $ | 306,943 |  |  | $ | (79,051 | ) |  | $ | 227,892 |  |
| Licenses and other intangibles | 274,604 |  |  | (127,288 | ) |  | 147,316 |  |  | 304,007 |  |  | (107,466 | ) |  | 196,541 |  |
| Total | $ | 571,910 |  |  | $ | (240,915 | ) |  | $ | 330,995 |  |  | $ | 610,950 |  |  | $ | (186,517 | ) |  | $ | 424,433 |  |

[0000866374-19-000006:notes:77]
Total intangible asset amortization expense recognized in operations during fiscal years 2019, 2018 and 2017 was $74.4 million, $78.6 million and $81.4 million, respectively. The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2019, the gross carrying amounts of fully amortized intangible assets totaled $9.4 million. The Company also recorded $21.0 million foreign currency translation adjustments during fiscal year 2019, as the U.S. Dollar fluctuated against foreign currencies for certain intangibles. As of March 31, 2019, the weighted-average remaining useful lives of the Company's intangible assets were approximately 6.3 years for customer-related intangibles and approximately 5.5 years for licenses and other intangible assets. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-19-000006:notes:78]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2020 | $ | 64,917 |  |
| 2021 | 60,604 |  |
| 2022 | 52,099 |  |
| 2023 | 44,390 |  |
| 2024 | 42,830 |  |
| Thereafter | 66,155 |  |
| Total amortization expense | $ | 330,995 |  |

[0000866374-19-000006:notes:79]
The Company owns or licenses various United States and foreign patents relating to a variety of technologies. For certain of the Company's proprietary processes, inventions, and works of authorship, the Company relies on trade secret or copyright protection. The Company also maintains trademark rights (including registrations) for the Company's corporate name and several other trademarks and service marks that the Company uses in the Company's business in the United States and other countries throughout the world. The Company has implemented appropriate policies and procedures (including both technological means and training programs for the Company's employees) to identify and protect the Company's intellectual property, as well as that of the Company's customers and suppliers. As of March 31, 2019 and 2018, the carrying value of the Company's intellectual property was not material.

[0000866374-19-000006:notes:80]
Derivative Instruments and Hedging Activities

[0000866374-19-000006:notes:81]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Additional information is included in note 8.

[0000866374-19-000006:notes:82]
Other Current Assets

[0000866374-19-000006:notes:83]
Other current assets include approximately $292.5 million and $445.4 million as of March 31, 2019 and 2018, respectively for the deferred purchase price receivable from the Company's Asset-Backed Securitization programs. See note 10 for additional information. Assets held for sale related to the China-based Multek operations previously recorded in other current assets have been removed from the consolidated balance sheet as of March 31, 2019, following the execution of the divestiture during the Company's second quarter of fiscal year 2019. See note 17 for additional information.

[0000866374-19-000006:notes:84]
Investments

[0000866374-19-000006:notes:85]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other assets. These privately held companies range from startups to more mature companies with established revenue streams and business models. As of March 31, 2019, and March 31, 2018, the Company's investments in non-consolidated companies totaled $294.1 million and $411.1 million, respectively. During the last half of fiscal year 2019, the Company reassessed its strategy with respect to its investment portfolio. As a result of the change in the Company's strategy and due to market valuation changes, the Company recognized an aggregate net charge related to investment impairments and dispositions of approximately $193 million for the fiscal year ended March 31, 2019, which is recorded in other charges (income), net on the consolidated statement of operations. The aggregate charge was primarily driven by write-downs of the Company's investment positions in a non-core cost method investment and Elementum as well as other investment impairments that were individually immaterial.

[0000866374-19-000006:notes:86]
Non-consolidated investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in the earnings or losses of the Company's equity method investments was not material to the consolidated results of operations for any period presented and is included in interest and other, net. Cost method is used for investments which the Company does not have the ability to significantly influence the operating decisions of the investee, or if the Company’s investment is in securities other than common stock or in-substance common stock.

[0000866374-19-000006:notes:87]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy, and require management to make various judgmental assumptions about primarily comparable company multiples and discounted cash flow projections. Some of the inherent estimates and assumptions used in determining fair value of the investments are outside the control of management. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the investments, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of investments.

[0000866374-19-000006:notes:88]
For investments accounted for under cost method that do not have readily determinable fair values, the Company has elected, per ASU 2016-01 and commencing on April 1, 2018, to measure them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-19-000006:notes:89]
Investment in Elementum SCM (Cayman) Ltd ("Elementum)

[0000866374-19-000006:notes:90]
Starting in fiscal year 2014, the Company had a majority owned subsidiary, Elementum, which qualified as a variable interest entity for accounting purposes. The Company owned a majority of Elementum' s outstanding equity (consisting primarily of preferred stock) and as of March 31, 2017, controlled its board of directors, which gave the Company the power to direct the activities of Elementum that most significantly impact its economic performance. Accordingly, the Company recognized the carrying value of the noncontrolling interest as a component of total shareholders' equity, and the consolidated financial statements included the financial position and results of operations of Elementum as of and for the period ended March 31, 2017.

[0000866374-19-000006:notes:91]
During the second quarter of fiscal year 2018, the Company and other minority shareholders of Elementum amended certain agreements resulting in joint control of the board of directors between the Company and other non-controlling interest holders. As a result, the Company concluded it is no longer the primary beneficiary of Elementum and accordingly, deconsolidated the entity and recognized a gain on deconsolidation of approximately $151.6 million with no related tax impact, which is included in other charges (income), net on the consolidated statement of operations for the year ended March 31, 2018. Further, the Company derecognized approximately $72.6 million of cash of Elementum as of the date of deconsolidation, which was reflected as an outflow from investing activities within other investing activities, net in the consolidated statement of cash flows for the year ended March 31, 2018. The Company no longer recognizes the carrying value of the noncontrolling interest as a component of total shareholder’s equity. As of March 31, 2018, the carrying value of the Company's variable interest in Elementum was approximately $125 million included in other assets on the consolidated balance sheet.

[0000866374-19-000006:notes:92]
During the fourth quarter of fiscal year 2019, the Company and Elementum executed agreements that provided for, among other things, the termination of certain commercial agreements between the Company and Elementum, the repurchase of certain shares of Elementum held by the Company and the removal of certain rights associated with such shares, including the Company’s right to elect certain members of Elementum’s board of directors. Management initiated a valuation of the Company's remaining investment using the public guideline company approach which relied on inputs such as comparable company multiples that would be considered Level 3 inputs in the fair value hierarchy. The latest valuation of the remaining investment resulted in a total charge of approximately $84 million, which is included in other charges (income), net on the consolidated statement of operations for the year ended March 31, 2019. The Company's remaining investment in Elementum is accounted for as a cost method investment, and is included in other assets on the consolidated balance sheet.

[0000866374-19-000006:notes:93]
Joint Venture with RIB Software AG

[0000866374-19-000006:notes:94]
During fiscal year 2017, the Company formed a joint venture with RIB Software AG, a provider of technology for the construction industry. The Company contributed $60.0 million for a non-controlling interest in this joint venture which was included in cash flows from other investing activities net in the consolidated statement of cash flows for the year ended March 31, 2017.

[0000866374-19-000006:notes:95]
During the third quarter of fiscal year 2019, the Company sold its non-controlling interest in the joint venture with RIB Software AG, a provider of technology for the construction industry, to its former joint venture partner, for a total consideration of approximately $48.4 million. The Company recognized an immaterial gain on sale, which is recorded in other charges (income), net on the consolidated statement of operations for the fiscal year ended March 31, 2019. The cash inflows received as consideration have been included in cash flows from other investing activities during the same period.

[0000866374-19-000006:notes:96]
Investment in Unrelated Third-party Company

[0000866374-19-000006:notes:97]
During the third quarter of fiscal year 2019, the Company noted, as part of the evaluation of its investment portfolio, a significant deterioration in a certain investee's performance and near-term projections. Additionally, the Company identified certain risks around that investee's capability to acquire additional funding to support its operation in the near term. The Company considered these facts as triggering events for impairment evaluations, and as a result recognized a $76 million  impairment charge during the fiscal year ended March 31, 2019, which is included in other charges (income), net on the consolidated statement of operations. The remaining carrying value of this investment at March 31, 2019 was immaterial, and was determined using a discounted cash flow approach which relied on inputs that would be considered Level 3 inputs in the fair value hierarchy.

[0000866374-19-000006:notes:98]
Bright Machines (formerly known as AutoLab AI)

[0000866374-19-000006:notes:99]
During the first quarter of fiscal year 2019, the Company transferred existing employees and equipment with a net book value of approximately $35 million along with certain related software and Intellectual Property ("IP"), into the newly created Bright Machines, in exchange for shares of preferred stock and a controlling financial interest in Bright Machines. Bright Machines is a privately held software-as-a service (SaaS) and hardware company focused on developing and deploying an automation solution worldwide. The Company has concluded that Bright Machines does not qualify as a variable interest entity for purposes of evaluating whether it has a controlling financial interest.

[0000866374-19-000006:notes:100]
Subsequent to the initial formation and prior to June 29, 2018, Bright Machines received equity funding from third party investors and expanded the board of directors, resulting in dilution of the Company's voting interest to below 50%. As a result, the Company concluded it no longer held a controlling financial interest in Bright Machines and accordingly, deconsolidated the entity.

[0000866374-19-000006:notes:101]
The fair value of the Company’s non-controlling interest in Bright Machines upon deconsolidation was approximately $127.6 million as of the date of deconsolidation. The Company accounts for its investment in Bright Machines under the equity method, with the carrying amount included in other assets on the consolidated balance sheet. The value of the Company’s interest on the date of deconsolidation was based on management’s estimate of the fair value of Bright Machines at that time. Management relied on a multi-stage process which involved calculating the enterprise and equity value of Bright Machines, then allocating the equity value of the entity to the Company’s securities. The enterprise value of Bright Machines was estimated based on the value implied by the equity funding Bright Machines received from third parties in the same period (i.e., level 2 inputs). The Company recognized a gain on deconsolidation of approximately $87 million with no material tax impact, which is included in other charges (income), net on the consolidated statement of operations.

[0000866374-19-000006:notes:102]
Concurrently with the deconsolidation, the Company engaged Bright Machines as a strategic partner to develop and deploy automation solutions for Flex and entered into a 5-year subscription agreement for use of fixed assets along with other automation services. The subscription agreement provides the Company with the use of the assets previously contributed to Bright Machines and accordingly is accounted for as a capital lease. As a result, the Company has recognized a capital lease asset and obligation with balances of $30.3 million and $34.8 million as of March 31, 2019, respectively, in the consolidated balance sheets.

[0000866374-19-000006:notes:103]
Pro-forma financials have not been presented because the effects were not material to the Company’s consolidated financial position and results of operation for all periods presented. Bright Machines became a related party to the Company starting on the date of deconsolidation. Subscription fees under the Bright Machines agreement were immaterial for the fiscal year ended March 31, 2019.

[0000866374-19-000006:notes:104]
Other Current Liabilities

[0000866374-19-000006:notes:105]
Other current liabilities include customer working capital advances of $266.3 million and $153.6 million, customer-related accruals of $260.1 million and $439.0 million, and deferred revenue of $271.8 million and $329.0 million as of March 31, 2019 and 2018, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Liabilities held for sale related to the China-based Multek operations of approximately $144 million as of March 31, 2018, previously included in other current liabilities have been removed from the consolidated balance sheet as of March 31, 2019, following the execution of the divestiture. See note 17 for additional information.

[0000866374-19-000006:notes:106]
Restructuring Charges

[0000866374-19-000006:notes:107]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and rationalize administrative functions. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-19-000006:notes:108]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed restructuring plans. See note 14 for additional information regarding restructuring charges.

[0000866374-19-000006:notes:109]
Recently Adopted Accounting Pronouncements

[0000866374-19-000006:notes:110]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update (ASU) No. 2017-01 “Business Combinations (Topic 805): Clarifying the Definition of a Business” to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The Company adopted the guidance on a prospective basis during the first quarter of fiscal year 2019, which did not have a material impact to its financial position as there were no material acquisitions during the period of adoption.

[0000866374-19-000006:notes:111]
In January 2017, the FASB issued ASU 2017-04 "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment" to simplify the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. This guidance requires that the change be applied on a prospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2021, with early application permitted. The Company adopted the guidance during fiscal year 2019 without a material impact to its financial position as there were no identified impairments during the period.

[0000866374-19-000006:notes:112]
In August 2016, the FASB issued ASU 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force)." The ASU is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 was consistent with the Company's current cash flow classification. However, cash receipts on the deferred purchase price from the Company's asset-backed securitization programs described in note 10 are now classified as cash flows from investing activities instead of the Company's former presentation as cash flows from operations. The Company adopted the guidance during the first quarter of fiscal year 2019 and retrospectively adjusted cash flows from operating and investing activities for fiscal year 2018. The Company recorded $3.6 billion of cash receipts on the deferred purchase price from the Company's asset-backed securitization programs for the fiscal year ended March 31, 2019 and reclassified $4.6 billion and $5.0 billion of cash receipts on the deferred purchase price for the fiscal years ended March 31, 2018 and 2017, from cash flows from operating activities to cash flows from investing activities, respectively.

[0000866374-19-000006:notes:113]
In January 2016, the FASB issued ASU 2016-01 "Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This guidance generally requires equity investments, except those accounted for under the equity method of accounting or those that result in consolidation of the investee, to be measured at fair value with changes in fair value recognized in net income. This guidance also requires the separate presentation of financial assets and financial liabilities by measurement category and form of financial asset on the balance sheet or in the accompanying notes to the financial statements. The Company adopted this guidance on April 1, 2018 with an immaterial impact on the Company's financial position, results of operations and cash flows.

[0000866374-19-000006:notes:114]
In February 2018, the FASB issued ASU 2018-03 "Technical Corrections and Improvements to Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This standard comes as an addition to ASU 2016-01 which the Company adopted in the first quarter of fiscal year 2019. This update includes amendments to clarify certain aspects of the guidance issued in Update 2016-01. The Company adopted this guidance during the second quarter of fiscal year 2019 with an immaterial impact on its consolidated financial statements.

[0000866374-19-000006:notes:115]
In May 2014, the FASB issued ASU 2014-09 "Revenue from Contracts with Customers (Topic 606)" (also referred to as Accounting Standard Codification 606 ("ASC 606")). As noted above, the Company adopted the standard on April 1, 2018 using the modified retrospective approach by applying the guidance to all open contracts at the adoption date and has implemented revised accounting policies, new operational and financial reporting processes, enhanced systems capabilities and relevant internal controls. Details of the impact of adopting ASC 606 has been described in the Revenue Recognition section above.

[0000866374-19-000006:notes:116]
Recently Issued Accounting Pronouncements

[0000866374-19-000006:notes:117]
In November 2018, the FASB issued ASU 2018-19 “Codification Improvements to Topic 326: Financial Instruments - Credit Losses” to introduce an expected credit loss methodology for the impairment of financial assets measured at amortized cost basis. That methodology replaces the probable, incurred loss model for those assets. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-19-000006:notes:118]
In October 2018, the FASB issued ASU 2018-17 “Consolidation (Topic 810): Targeted Improvements to Related Party Guidance for Variable Interest Entities” to provide a new private company variable interest entity exemption and changes how decision makers apply the variable interest criteria. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-19-000006:notes:119]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is still evaluating the impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-19-000006:notes:120]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-19-000006:notes:121]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-19-000006:notes:122]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-19-000006:notes:123]
In February 2016, the FASB issued ASU No. 2016-02, Leases with subsequent updates through 2018 (together “ASC 842”). The new standard is intended to improve financial reporting of lease transactions by requiring lease assets and liability to be recorded on the balance sheet for the rights and obligations created by leases that extend more than twelve months. ASC 842 also requires additional disclosures for the amount, timing, and uncertainty of cash flows arising from leases.

[0000866374-19-000006:notes:124]
ASC 842 is effective for financial statements issued for annual and interim periods beginning after December 15, 2018 for public business entities. The Company adopted the new standard on its effective date of April 1, 2019, using the effective date method. Under this method, the initial recognition of lease assets and liabilities as required by ASC 842 will occur on April 1, 2019, and financial information for comparative periods prior to that date will not be updated. ASC 842 provides a number of optional practical expedients impacting transition to the new standard. Management elected the package of practical expedients which, among other things, allows the Company to carry forward historical lease classification in place prior to April 1, 2019.

[0000866374-19-000006:notes:125]
ASC 842 also provides practical expedients for an entity’s accounting after transition. Management has elected the short-term lease recognition exemption for all leases that qualify, as well as the practical expedient to not separate lease and non-lease components, Both of these expedients were elected for all classes of underlying leased assets.

[0000866374-19-000006:notes:126]
As a balance sheet impact upon adoption, the Company expects to recognize right-of-use assets and operating lease liabilities, respectively, in the range of approximately $550 million to $750 million. The Company is continuing to assess the impact of adopting the new standard on its consolidated financial statements but does not expect a material impact on its consolidated statement of operations or its consolidated statement of cash flows. The Company is also continuing to adjust its accounting policies, operational and financial reporting processes, systems capabilities and relevant internal controls.

[0000866374-19-000006:notes:127]
In December 2017, the Securities and Exchange Commission ("SEC") staff issued Staff Accounting Bulletin No. 118 (SAB 118), Income Tax Accounting Implications of the Tax Cuts and Jobs Act ("Tax Act"), which allowed the Company to record provisional amounts during a measurement period not to extend beyond one year of the enactment date. As of March 31, 2019, the Company has finalized all provisional amounts related to the Tax Act. Finalizing provisional adjustments related to the Tax Act did not have a material impact on the Company's consolidated financial statements as of March 31, 2019. The Company expects further guidance may be forthcoming from the FASB and the SEC, as well as regulations, interpretations and rulings from federal and state tax agencies, which could result in additional impacts.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-19-000006:notes:128]
BUSINESS AND ASSET ACQUISITIONS & DIVESTITURES

[0000866374-19-000006:notes:129]
Fiscal 2019 Business acquisition

[0000866374-19-000006:notes:130]
In October 2018, the Company completed the acquisition of a business that was not significant to the consolidated financial position, result of operations and cash flows of the Company. The acquired business expanded the Company's design capabilities in the telecom market within the CEC segment. The assets acquired and liabilities assumed were not material to the Company's consolidated financial results. Results of operations were included in the Company’s consolidated financial results beginning on the date of acquisition, and were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-19-000006:notes:131]
Fiscal 2019 Divestitures

[0000866374-19-000006:notes:132]
During the third quarter of fiscal year 2019, the Company disposed of an immaterial non-strategic business in Brazil that operated across all of its segments. The net loss on disposition was not material to the Company's consolidated financial results, and was included in other charges (income), net in the consolidated statement of operation for the fiscal year 2019.

[0000866374-19-000006:notes:133]
During the second quarter of fiscal year 2019, the Company divested its China-based Multek operations, for proceeds of approximately $267.1 million, net of cash. The Company transferred approximately $231.4 million of net assets, primarily property and equipment, accounts receivable, and accounts payable. Further, the Company incurred various selling costs as part of this divestiture and allocated approximately $19.0 million of goodwill to the divested business. This transaction resulted in the recognition of an immaterial loss which is included in other charges (income), net in the consolidated statements of operations for the fiscal year 2019.

[0000866374-19-000006:notes:134]
Pro-forma results of operations for these divestitures have not been presented because the effects were not individually, nor in the aggregate, material to the Company's consolidated financial results for all periods presented.

[0000866374-19-000006:notes:135]
Fiscal 2018 Business and asset acquisitions

[0000866374-19-000006:notes:136]
During the fiscal year ended March 31, 2018, the Company completed two acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operation and cash flows of the Company.

[0000866374-19-000006:notes:137]
In April 2017, the Company completed its acquisition of AGM, which expanded its capabilities in the automotive market, and is included within the HRS segment. The Company paid $213.7 million, net of cash acquired.

[0000866374-19-000006:notes:138]
Additionally, in September 2017, the Company acquired a power modules business, which expanded its capabilities within the CEC segment. The Company paid $54.7 million, net of cash acquired.

[0000866374-19-000006:notes:139]
A summary of the allocation of the total purchase consideration is presented as follows (in thousands):

[0000866374-19-000006:notes:140]
|  |  | Purchase Consideration |  | Net Tangible Assets Acquired |  | Purchased Intangible Assets |  | Goodwill |
| AGM |  | $ | 213,718 |  |  | $ | 56,438 |  |  | $ | 82,000 |  |  | $ | 75,280 |  |
| Power Modules Business |  | 54,659 |  |  | 11,615 |  |  | 33,300 |  |  | 9,744 |  |

[0000866374-19-000006:notes:141]
The intangibles of AGM comprised solely of customer relationships, will amortize over a weighted-average estimated useful life of 10 years. The intangibles of the power modules business, comprised of $16.0 million of customer relationships and $17.3 million of licenses and other intangibles, will amortize over a weighted-average estimated useful life of 10 years and 8 years, respectively.

[0000866374-19-000006:notes:142]
The results of operations of the acquisitions were included in the Company’s consolidated financial results beginning on the respective acquisition dates, and the total amount of net income and revenue, collectively, were immaterial to the Company's consolidated financial results for the fiscal year ended March 31, 2018. Pro-forma results of operations for the acquisitions completed in fiscal year 2018 have not been presented because the effects, individually and in aggregate, were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-19-000006:notes:143]
Fiscal 2017 Business and asset acquisitions

[0000866374-19-000006:notes:144]
During the fiscal year ended March 31, 2017, the Company completed four acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. Most notable is the Company’s acquisition of two manufacturing and development facilities from Bose Corporation (“Bose”), a global leader in audio systems. The acquisition expanded the Company’s capabilities in the audio market and is included in the CTG segment. The other acquired businesses strengthen the Company's capabilities in the communications market and energy market within the CEC and IEI segments, respectively. At the acquisition dates, the Company paid a total of $189.1 million, net of cash acquired, of which $161.7 million, net of $18.0 million of cash acquired is related to the Bose acquisition which is included in cash from investing activities in the consolidated statements of cash flows. The Company acquired primarily $73.1 million of inventory, $60.8 million of property and equipment, and recorded goodwill of $63.8 million and intangible assets of $47.4 million principally related to the Bose acquisition. The intangibles will amortize over a weighted-average estimated useful life of 6.5 years. In connection with these acquisitions, the Company assumed $63.3 million in other liabilities including additional consideration of $28.0 million which was paid in the fourth quarter of fiscal year 2017 and included in other financing activities in the consolidated statements of cash flows. Further, the equity incentive plan of one of the acquirees was assumed as part of the acquisition.

[0000866374-19-000006:notes:145]
The results of operations for each of the acquisitions completed in fiscal year 2017, including the Bose acquisition, were included in the Company’s consolidated financial results beginning on the date of each acquisition, and the total amount of net income and revenue of the acquisitions, collectively, were immaterial to the Company's consolidated financial results for the fiscal year ended March 31, 2017. Pro-forma results of operations for the acquisitions completed in fiscal year 2017 were not presented because the effects, individually and in the aggregate, were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-19-000006:notes:146]
Fiscal 2017 Divestitures

[0000866374-19-000006:notes:147]
During the fiscal year ended March 31, 2017, the Company disposed of two non-strategic businesses within the HRS and IEI segments. The Company received $30.7 million of proceeds, net of an immaterial amount of cash held in one of the divested businesses. The property and equipment and various other assets sold, and liabilities transferred were not material to the Company's consolidated financial results. The loss on disposition was not material to the Company’s consolidated financial results, and was included in other charges, net in the consolidated statements of operations for the fiscal year 2017.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-19-000006:notes:148]
SUPPLEMENTAL CASH FLOW DISCLOSURES

[0000866374-19-000006:notes:149]
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-19-000006:notes:150]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 190,204 |  |  | $ | 152,750 |  |  | $ | 127,346 |  |
| Income taxes | 134,178 |  |  | 91,846 |  |  | 86,651 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 111,989 |  |  | $ | 128,044 |  |  | $ | 84,375 |  |
| Customer-related third party banking institution equipment financing net settlement | — |  |  | — |  |  | 90,576 |  |
| Non-cash investment in Elementum (Note 2) | — |  |  | 132,679 |  |  | — |  |
| Non-cash proceeds from sales of Wink (Note 2) | — |  |  | 59,000 |  |  | — |  |
| Non-cash investment in Bright Machines (Note 2) | 127,641 |  |  | — |  |  | — |  |
| Capital lease for Bright Machines assets (Note 2) | 34,828 |  |  | — |  |  | — |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-19-000006:notes:151]
COMMITMENTS AND CONTINGENCIES

[0000866374-19-000006:notes:152]
Commitments

[0000866374-19-000006:notes:153]
As of March 31, 2019 and 2018, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under capital leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2035 and require the following minimum lease payments:

[0000866374-19-000006:notes:154]
| Fiscal Year Ending March 31, | Operating Lease |
|  | (In thousands) |
| 2020 | $ | 155,391 |  |
| 2021 | 113,245 |  |
| 2022 | 93,777 |  |
| 2023 | 81,335 |  |
| 2024 | 67,341 |  |
| Thereafter | 171,828 |  |
| Total minimum lease payments | $ | 682,917 |  |

[0000866374-19-000006:notes:155]
Total rent expense amounted to $176.8 million, $140.3 million and $124.7 million in fiscal years 2019, 2018 and 2017, respectively.

[0000866374-19-000006:notes:156]
Litigation and other legal matters

[0000866374-19-000006:notes:157]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-19-000006:notes:158]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-19-000006:notes:159]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g. base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

[0000866374-19-000006:notes:160]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. Motions for appointment as lead plaintiff are due June 4, 2019. Defendants’ deadline to move to dismiss is vacated until after the lead plaintiff appointment process is complete and an operative complaint is designated.  In addition, the Court has set a case management conference for July 17, 2019. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-19-000006:notes:161]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-19-000006:notes:162]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 359.9 million Brazilian reals (approximately USD $91.1 million based on the exchange rate as of March 31, 2019). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-19-000006:notes:163]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter. The matter is at a very preliminary stage. The Company cannot predict how long it will take to complete the investigation or to what extent the Company could be subject to penalties.

[0000866374-19-000006:notes:164]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-19-000006:notes:165]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0000866374-19-000006:notes:166]
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2019, 2018 and 2017 are as follows:

[0000866374-19-000006:notes:167]
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance on April 1, 2016 | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |
| Other comprehensive gain (loss) before reclassifications | 6,925 |  |  | (1,198 | ) |  | 5,727 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 2,171 |  |  | (126 | ) |  | 2,045 |  |
| Net current-period other comprehensive gain (loss) | 9,096 |  |  | (1,324 | ) |  | 7,772 |  |
| Ending balance on March 31, 2017 | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |
| Other comprehensive gain before reclassifications | 15,667 |  |  | 46,022 |  |  | 61,689 |  |
| Net gains reclassified from accumulated other comprehensive loss | (18,987 | ) |  | (404 | ) |  | (19,391 | ) |
| Net current-period other comprehensive gain (loss) | (3,320 | ) |  | 45,618 |  |  | 42,298 |  |
| Ending balance on March 31, 2018 | $ | (35,746 | ) |  | $ | (50,099 | ) |  | $ | (85,845 | ) |
| Other comprehensive loss before reclassifications | (48,302 | ) |  | (59,508 | ) |  | (107,810 | ) |
| Net losses reclassified from accumulated other comprehensive loss | 42,492 |  |  | — |  |  | 42,492 |  |
| Net current-period other comprehensive loss | (5,810 | ) |  | (59,508 | ) |  | (65,318 | ) |
| Ending balance on March 31, 2019 | $ | (41,556 | ) |  | $ | (109,607 | ) |  | $ | (151,163 | ) |

[0000866374-19-000006:notes:168]
Net losses reclassified from accumulated other comprehensive loss during fiscal year 2019 relating to derivative instruments and other includes $40.6 million attributable to the Company's cash flow hedge instruments which were recognized as a component of cost of sales in the consolidated statement of operations.

[0000866374-19-000006:notes:169]
Net gains reclassified from accumulated other comprehensive loss during fiscal year 2018 relating to derivative instruments and other includes $20.8 million attributable to the Company's cash flow hedge instruments which were recognized as a component of cost of sales in the consolidated statement of operations.

[0000866374-19-000006:notes:170]
Net (gains) losses reclassified from accumulated other comprehensive loss were immaterial during fiscal year 2017.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000866374-19-000006:notes:171]
The following table summarizes the activity in the Company's contract assets during the fiscal year ended March 31, 2019 (in thousands):

[0000866374-19-000006:notes:172]
|  | Contract Assets |
| Beginning balance, April 1, 2018 | $ | — |  |
| Cumulative effect adjustment at April 1, 2018 | 451,287 |  |
| Revenue recognized | 7,169,638 |  |
| Amounts collected or invoiced | (7,404,723 | ) |
| Ending balance, March 31, 2019 | $ | 216,202 |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-19-000006:notes:173]
BANK BORROWINGS AND LONG-TERM DEBT

[0000866374-19-000006:notes:174]
Bank borrowings and long-term debt are as follows:

[0000866374-19-000006:notes:175]
|  | As of March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 671,563 |  |  | 687,813 |  |
| Term Loan, including current portion, due in installments through June 2022 | 458,531 |  |  | 483,656 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 596,815 |  |  | 596,387 |  |
| India Facilities (1) | 170,206 |  |  | — |  |
| Other | 168,039 |  |  | 186,601 |  |
| Debt issuance costs | (10,639 | ) |  | (13,815 | ) |
|  | 3,054,515 |  |  | 2,940,642 |  |
| Current portion, net of debt issuance costs | (632,611 | ) |  | (43,011 | ) |
| Non-current portion | $ | 2,421,904 |  |  | $ | 2,897,631 |  |

[0000866374-19-000006:notes:176]
| (1) | India Facilities as of March 31, 2019 include approximately $91.4 million drawdown of short-term bank borrowings facility entered in February 2019 and $78.8 million drawdown from the $200 million term loan facility entered in July 2018. |

[0000866374-19-000006:notes:177]
The weighted-average interest rates for the Company's long-term debt were 4.2% and 3.9% as of March 31, 2019 and 2018, respectively.

[0000866374-19-000006:notes:178]
Scheduled repayments of the Company's long-term debt are as follows:

[0000866374-19-000006:notes:179]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2020 | $ | 634,321 |  |
| 2021 | 111,558 |  |
| 2022 | 801,836 |  |
| 2023 | 857,571 |  |
| 2024 | 60,423 |  |
| Thereafter | 599,445 |  |
| Total | $ | 3,065,154 |  |

[0000866374-19-000006:notes:180]
Term Loan due November 2021

[0000866374-19-000006:notes:181]
In August 2013, the Company entered into a $600 million term loan agreement due August 2018. In November 2016, the Company entered into a new arrangement to extend the maturity date of the agreement from August 30, 2018 to November 30, 2021, and borrowed an incremental amount of $130 million under this term loan, thereby increasing the total amount under the term loan to $700 million. This loan is repayable in quarterly installments of $4.1 million, which commenced October 31, 2017 and continue through September 30, 2021, with the remaining amount due at maturity.

[0000866374-19-000006:notes:182]
Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the prime rate in effect on each day as published in The Wall Street Journal, the federal funds rate plus 0.5% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating.

[0000866374-19-000006:notes:183]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term; provided that the requirement to maintain the minimum interest coverage ratio may be suspended in certain circumstances. As of March 31, 2019, the Company was in compliance with the covenants under this term loan agreement.

[0000866374-19-000006:notes:184]
Term Loan Agreement due June 2022 and Revolving Line of Credit

[0000866374-19-000006:notes:185]
In June 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature in March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualified as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the term of the 2022 Credit Facility.

[0000866374-19-000006:notes:186]
Borrowings under the 2022 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate that would be calculated as of each day in respect of a proposed LIBOR loan with a one-month interest period, plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 1.875% per annum, based on the Company’s credit ratings.

[0000866374-19-000006:notes:187]
The 2022 Credit Facility is unsecured and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of March 31, 2019, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.

[0000866374-19-000006:notes:188]
Notes due February 2020 and February 2023

[0000866374-19-000006:notes:189]
In February 2013, the Company issued $500 million of 4.625% Notes due February 15, 2020 and $500 million of 5.000% Notes due February 15, 2023 (collectively the "Notes") in a private offering pursuant to Rule 144A and Regulation S under the Securities Act. In July 2013, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.

[0000866374-19-000006:notes:190]
Interest on the Notes is payable semi-annually, which commenced on August 15, 2013. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and up until June 30, 2017 were guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). The Company replaced its $2.1 billion credit facility, which was due to expire in March 2019 and was guaranteed by the guarantor subsidiaries, with the 2022 Credit Facility, which is not guaranteed by the guarantor subsidiaries. Effective upon the replacement, all guarantor subsidiaries were released from their guarantees under each indenture for the Notes.

[0000866374-19-000006:notes:191]
At any time prior to maturity, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0000866374-19-000006:notes:192]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately. As of March 31, 2019, the note due February 2020 has been included in current liabilities on the consolidated balance sheet, and the Company was in compliance with the covenants in the indenture governing the Notes as of March 31, 2019.

[0000866374-19-000006:notes:193]
Notes due June 2025

[0000866374-19-000006:notes:194]
In June 2015, the Company issued $600 million of 4.750% Notes ("2025 Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at 99.213% of face value, and an effective yield of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which was used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.

[0000866374-19-000006:notes:195]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the 2025 Notes. The issuance costs were capitalized and presented on the balance sheet as a direct deduction from the carrying amount of the 2025 Notes.

[0000866374-19-000006:notes:196]
Interest on the 2025 Notes is payable semi-annually, commencing on December 15, 2015. The 2025 Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and up until June 30, 2017 were guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). The Company replaced its $2.1 billion credit facility, which was due to expire in March 2019 and was guaranteed by the guarantor subsidiaries, with the 2022 Credit Facilities, which is not guaranteed by the guarantor subsidiaries. Effective upon the replacement, all guarantor subsidiaries were released from their guarantees under the indenture for the 2025 Notes.

[0000866374-19-000006:notes:197]
At any time prior to March 15, 2025, the Company may redeem some or all of the 2025 Notes at a redemption price equal to 100% of the principal amount of the 2025 Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the 2025 Notes indenture), the Company must offer to repurchase the 2025 Notes at a repurchase price equal to 101% of the principal amount of the 2025 Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0000866374-19-000006:notes:198]
The indenture governing the 2025 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2025 Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2025 Notes may declare all of the 2025 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2025 Notes. As of March 31, 2019, the Company was in compliance with the covenants in the indenture governing the 2025 Notes.

[0000866374-19-000006:notes:199]
Other Credit Lines

[0000866374-19-000006:notes:200]
In February 2019, a subsidiary of the Company entered into a $100 million uncommitted credit import advance facility (the "Advance Facility"), under which there was $91.4 million advances outstanding as of March 31, 2019. The Advance Facility will be used to assist the Company in the import of goods into India. Advances under this facility are repayable at any time, and bear interest at LIBOR plus a margin of 0.70%. The Company anticipates repaying the facility in fiscal year 2020.

[0000866374-19-000006:notes:201]
In July 2018, a subsidiary of the Company entered into a $200 million term loan facility (the "Facility"), under which there was $78.8 million in borrowings outstanding as of March 31, 2019. The Facility will be used to fund capital expenditure to support the Company's expansion plan for India. The availability period during which drawdowns can be made will be from the date of the agreement to and including June 30, 2019. The maximum maturity of each drawdown will be 5 years from the funded Capex shipment date. As a result, the longest maturity date of any future drawdown under the Facility will be June 30, 2024. Borrowings under this term loan bear interest at LIBOR plus a margin of 0.90% to 1.15% depending on loan duration.

[0000866374-19-000006:notes:202]
In January 2017, the Company borrowed €100 million (approximately $112.5 million as of March 31, 2019), under a 5-year, term-loan agreement due January 2, 2022. Borrowings under this term loan bear interest at EURIBOR minus 0.1% plus the applicable margin ranging between 0.40% and 1.35%, based on the Company's credit ratings. The loan is repayable upon maturity.

[0000866374-19-000006:notes:203]
In October 2015, the Company borrowed €50 million (approximately $56.3 million as of March 31, 2019), under a 5-year, term-loan agreement due September 30, 2020. Borrowings under this term loan bear interest at EURIBOR plus the applicaeble margin ranging between 0.80% and 2.00%, based on the Company’s credit ratings. The loan is repayable beginning December 30, 2016 in quarterly payments of €312,500 through June 30, 2020 with the remainder due upon maturity.

[0000866374-19-000006:notes:204]
These term loans are unsecured and are guaranteed by the Company. These term loan agreements contain customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. These term loan agreements also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during their terms. As of March 31, 2019, the Company was in compliance with the covenants under these term loan agreements.

[0000866374-19-000006:notes:205]
As of March 31, 2019, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities in the amount of $332.2 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2019 and 2018. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin, and generally have maturities that expire on various dates in future fiscal years.

[0000866374-19-000006:notes:206]
Term Loan due April 26, 2024

[0000866374-19-000006:notes:207]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement (approximately $300 million) due April 2024, which was then swapped to U.S. dollars. The term loan will be used to fund general operations and refinance certain other outstanding debt. Borrowings under this term loan bear interest, at LIBOR plus the applicable margin of 1.21%. This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-19-000006:notes:208]
FINANCIAL INSTRUMENTS

[0000866374-19-000006:notes:209]
Foreign Currency Contracts

[0000866374-19-000006:notes:210]
The Company transacts business in various foreign countries and is therefore exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency unit of the operating entity. The Company enters into short-term foreign currency derivatives contracts, including forward, swap, and options contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-19-000006:notes:211]
As of March 31, 2019, the aggregate notional amount of the Company's outstanding foreign currency derivative contracts was $7.8 billion as summarized below:

[0000866374-19-000006:notes:212]
|  | Foreign CurrencyAmount |  | Notional ContractValue in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| CNY | 2,207,000 |  |  | — |  |  | $ | 328,349 |  |  | $ | — |  |
| EUR | 48,763 |  |  | 700 |  |  | 55,445 |  |  | 788 |  |
| HUF | 34,401,000 |  |  | — |  |  | 120,981 |  |  | — |  |
| ILS | 181,000 |  |  | — |  |  | 49,833 |  |  | — |  |
| MXN | 4,123,000 |  |  | — |  |  | 212,987 |  |  | — |  |
| MYR | 286,100 |  |  | 30,200 |  |  | 70,276 |  |  | 7,418 |  |
| PLN | 144,500 |  |  | — |  |  | 37,841 |  |  | — |  |
| RON | 247,000 |  |  | — |  |  | 58,365 |  |  | — |  |
| SGD | 42,500 |  |  | — |  |  | 31,354 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 17,853 |  |  | 7,089 |  |
|  |  |  |  |  | 983,284 |  |  | 15,295 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |
| BRL | — |  |  | 972,000 |  |  | — |  |  | 246,092 |  |
| CAD | 74,484 |  |  | 132,895 |  |  | 55,511 |  |  | 99,042 |  |
| CNY | 3,132,409 |  |  | 458,795 |  |  | 466,085 |  |  | 68,230 |  |
| EUR | 1,793,103 |  |  | 2,043,034 |  |  | 2,019,883 |  |  | 2,303,762 |  |
| GBP | 39,047 |  |  | 30,869 |  |  | 51,590 |  |  | 40,857 |  |
| HUF | 52,526,969 |  |  | 54,425,127 |  |  | 184,727 |  |  | 191,402 |  |
| ILS | 160,775 |  |  | 77,600 |  |  | 44,265 |  |  | 21,365 |  |
| INR | 3,921,500 |  |  | 10,356,508 |  |  | 56,930 |  |  | 150,312 |  |
| MXN | 2,969,832 |  |  | 2,078,128 |  |  | 153,416 |  |  | 107,352 |  |
| MYR | 455,920 |  |  | 255,210 |  |  | 111,989 |  |  | 62,688 |  |
| SEK | 706,435 |  |  | 755,275 |  |  | 76,470 |  |  | 81,479 |  |
| SGD | 83,800 |  |  | 50,280 |  |  | 61,822 |  |  | 37,093 |  |
| Other | N/A |  |  | N/A |  |  | 77,860 |  |  | 57,612 |  |
|  |  |  |  |  | 3,360,548 |  |  | 3,467,286 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 4,343,832 |  |  | $ | 3,482,581 |  |

[0000866374-19-000006:notes:213]
As of March 31, 2019 and 2018, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in non-functional currencies and are not accounted for as hedges under the accounting standards. Accordingly, changes in fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the consolidated statements of operations. As of March 31, 2019 and 2018, the Company also has included net deferred gains and losses, in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred losses totaled $0.2 million as of March 31, 2019, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal years presented and are included as a component of interest and other, net in the consolidated statements of operations.

[0000866374-19-000006:notes:214]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2019 and 2018:

[0000866374-19-000006:notes:215]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31, 2019 |  | March 31, 2018 |  | Balance SheetLocation |  | March 31, 2019 |  | March 31, 2018 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 10,503 |  |  | $ | 19,422 |  |  | Other current liabilities |  | $ | 10,282 |  |  | $ | 7,065 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 16,774 |  |  | $ | 23,912 |  |  | Other current liabilities |  | $ | 17,144 |  |  | $ | 18,246 |  |

[0000866374-19-000006:notes:216]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with the counterparty upon maturity. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:DerivativesPolicyTextBlock

[0000866374-19-000006:notes:217]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period.

[0000866374-19-000006:notes:218]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000866374-19-000006:notes:219]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time for the fiscal year ended March 31, 2019:

[0000866374-19-000006:notes:220]
|  | Fiscal Year Ended March 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
|  | (In thousands) |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 3,773,735 |  |  | $ | 4,395,773 |  |  | $ | 6,126,454 |  |  | $ | 4,744,911 |  |  | $ | 19,040,873 |  |
| Over time | 1,055,215 |  |  | 1,786,864 |  |  | 2,209,876 |  |  | 2,117,683 |  |  | 7,169,638 |  |
| Total segment | $ | 4,828,950 |  |  | $ | 6,182,637 |  |  | $ | 8,336,330 |  |  | $ | 6,862,594 |  |  | $ | 26,210,511 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-19-000006:notes:221]
SHARE-BASED COMPENSATION

[0000866374-19-000006:notes:222]
Equity Compensation Plans

[0000866374-19-000006:notes:223]
The Company's primary plan used for granting equity compensation awards is the 2017 Equity Incentive Plan (the "2017 Plan"), which was approved by the Company's shareholders at the 2017 Annual General Meeting of Shareholders, to replace the former 2010 Equity Incentive Plan.

[0000866374-19-000006:notes:224]
The Company assumed all of the outstanding and unvested restricted shares and options associated with a couple acquisitions and converted all of these shares into Flex awards. As a result, the Company maintains two additional equity compensation plans that are immaterial to the Company for all periods presented. No share options or restricted share unit awards were granted under these plans during fiscal year 2019, nor were there any shares available for grant under these plans as of March 31, 2019.

[0000866374-19-000006:notes:225]
Share-Based Compensation Expense

[0000866374-19-000006:notes:226]
The following table summarizes the Company's share-based compensation expense for all Equity Incentive Plans:

[0000866374-19-000006:notes:227]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Cost of sales | $ | 19,554 |  |  | $ | 19,102 |  |  | $ | 10,023 |  |
| Selling, general and administrative expenses | 56,478 |  |  | 66,142 |  |  | 72,243 |  |
| Total share-based compensation expense | $ | 76,032 |  |  | $ | 85,244 |  |  | $ | 82,266 |  |

[0000866374-19-000006:notes:228]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as operating cash flows. During fiscal years 2019, 2018 and 2017, the Company did not recognize any excess tax benefits as an operating cash inflow.

[0000866374-19-000006:notes:229]
As of March 31, 2019, the Company had approximately 16.1 million shares available for grant under the 2017 Plan. Options issued to employees under this plan generally vest over four years and expire ten years from the date of grant. Options granted to non-employee directors generally expire five years from the date of grant.

[0000866374-19-000006:notes:230]
The exercise price of options granted to employees is determined by the Company's Board of Directors or the Compensation Committee and may not be less than the closing price of the Company's ordinary shares on the date of grant.

[0000866374-19-000006:notes:231]
As of March 31, 2019, the total unrecognized compensation cost related to unvested share options granted to employees under all plans was not material and will be amortized on a straight-line basis over a weighted-average period of approximately 1.8 years.

[0000866374-19-000006:notes:232]
The Company also grants restricted share unit awards under its 2017 Plan. Restricted share unit awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. Restricted share unit awards generally vest in installments over a three to five-year period and unvested restricted share unit awards are forfeited upon termination of employment.

[0000866374-19-000006:notes:233]
Vesting for certain restricted share unit awards is contingent upon both service and market conditions. Further, vesting for certain restricted share unit awards granted to certain executive officers is contingent upon meeting certain free cash flow targets.

[0000866374-19-000006:notes:234]
As of March 31, 2019, the total unrecognized compensation cost related to unvested restricted share unit awards under all plans was approximately $132.9 million. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.4 years. Approximately $14.2 million of the total unrecognized compensation cost is related to restricted share unit awards granted to certain key employees whereby vesting is contingent on meeting a certain market condition.

[0000866374-19-000006:notes:235]
Determining Fair Value - Options and restricted share unit awards

[0000866374-19-000006:notes:236]
Valuation and Amortization Method—The Company estimates the fair value of share options granted under the 2017 Plan using the Black-Scholes valuation method and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period. The fair market value of restricted share unit awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-19-000006:notes:237]
Expected Term—The Company's expected term used in the Black-Scholes valuation method represents the period that the Company's share options are expected to be outstanding and is determined based on historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share options.

[0000866374-19-000006:notes:238]
Expected Volatility—The Company's expected volatility used in the Black-Scholes valuation method is derived from a combination of implied volatility related to publicly traded options to purchase Flex ordinary shares and historical variability in the Company's periodic share price.

[0000866374-19-000006:notes:239]
Expected Dividend—The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-19-000006:notes:240]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0000866374-19-000006:notes:241]
There were no options granted under the 2017 Plan during fiscal years 2019, 2018, and 2017.

[0000866374-19-000006:notes:242]
Determining Fair Value - Restricted share unit awards with service and market conditions

[0000866374-19-000006:notes:243]
Valuation and Amortization Method—The Company estimates the fair value of restricted share unit awards granted under the 2017 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-19-000006:notes:244]
Expected volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the restricted share unit awards granted. The service period is three years for those restricted share unit awards granted in fiscal years 2019, 2018, and 2017.

[0000866374-19-000006:notes:245]
Average peer volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of the Standard and Poor's ("S&P") 500 index for the restricted share unit awards granted in fiscal years 2019, 2018, and 2017.

[0000866374-19-000006:notes:246]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to the S&P 500 index for the restricted share unit awards granted in fiscal years 2019, 2018, and 2017.

[0000866374-19-000006:notes:247]
Expected Dividend and Risk-Free Interest Rate assumptions—Same methodology as discussed above.

[0000866374-19-000006:notes:248]
The fair value of the Company's restricted share unit awards under the 2017 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2019, 2018, and 2017 was estimated using the following weighted-average assumptions:

[0000866374-19-000006:notes:249]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Expected volatility | 27.4 | % |  | 25.1 | % |  | 25.8 | % |
| Average peer volatility | 25.6 | % |  | 28.7 | % |  | 25.1 | % |
| Average peer correlation | 0.5 |  |  | 0.6 |  |  | 0.6 |  |
| Expected dividends | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate | 2.7 | % |  | 1.5 | % |  | 0.9 | % |

[0000866374-19-000006:notes:250]
Share-Based Awards Activity

[0000866374-19-000006:notes:251]
The following is a summary of option activity for all plans ("Price" reflects the weighted-average exercise price):

[0000866374-19-000006:notes:252]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | Options |  | Price |  | Options |  | Price |  | Options |  | Price |
| Outstanding, beginning of fiscal year | 1,189,550 |  |  | $ | 3.28 |  |  | 1,937,400 |  |  | $ | 3.75 |  |  | 5,111,490 |  |  | $ | 5.70 |  |
| Granted | — |  |  | — |  |  | 288,386 |  |  | 0.54 |  |  | 159,057 |  |  | 0.51 |  |
| Exercised | (244,393 | ) |  | 1.00 |  |  | (667,184 | ) |  | 4.15 |  |  | (2,283,201 | ) |  | 5.44 |  |
| Forfeited | (71,927 | ) |  | 3.37 |  |  | (369,052 | ) |  | 5.75 |  |  | (1,049,946 | ) |  | 9.47 |  |
| Outstanding, end of fiscal year | 873,230 |  |  | $ | 3.93 |  |  | 1,189,550 |  |  | $ | 3.28 |  |  | 1,937,400 |  |  | $ | 3.75 |  |
| Options exercisable, end of fiscal year | 546,339 |  |  | $ | 5.34 |  |  | 373,950 |  |  | $ | 4.99 |  |  | 507,965 |  |  | $ | 6.08 |  |

[0000866374-19-000006:notes:253]
The aggregate intrinsic value of options exercised under all plans (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise for options exercised in-the-money) was $2.4 million, $8.9 million and $17.3 million during fiscal years 2019, 2018 and 2017, respectively.

[0000866374-19-000006:notes:254]
Cash received from option exercises under all plans was immaterial for fiscal year 2019. Cash received from option exercises under all plans was $2.8 million and $12.4 million for fiscal years 2018 and 2017, respectively.

[0000866374-19-000006:notes:255]
As of March 31, 2019 the aggregate intrinsic value for options outstanding, options vested and expected to vest, and options exercisable under all plans were immaterial. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2019 for the immaterial amount of options that were in-the-money at March 31, 2019.

[0000866374-19-000006:notes:256]
The following table summarizes the Company's restricted share unit award activity under all plans ("Price" reflects the weighted-average grant-date fair value):

[0000866374-19-000006:notes:257]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested restricted share unit awards outstanding, beginning of fiscal year | 14,619,692 |  |  | $ | 14.39 |  |  | 17,242,019 |  |  | $ | 12.24 |  |  | 19,309,172 |  |  | $ | 10.71 |  |
| Granted (1) | 8,257,502 |  |  | 12.59 |  |  | 6,680,739 |  |  | 16.97 |  |  | 8,261,666 |  |  | 13.46 |  |
| Vested (1) | (5,952,039 | ) |  | 13.12 |  |  | (6,945,393 | ) |  | 11.86 |  |  | (9,311,984 | ) |  | 9.50 |  |
| Forfeited | (2,021,269 | ) |  | 14.51 |  |  | (2,357,673 | ) |  | 12.20 |  |  | (1,016,835 | ) |  | 11.15 |  |
| Unvested restricted share unit awards outstanding, end of fiscal year | 14,903,886 |  |  | $ | 13.76 |  |  | 14,619,692 |  |  | $ | 14.39 |  |  | 17,242,019 |  |  | $ | 12.24 |  |

[0000866374-19-000006:notes:258]
| (1) | Included in the fiscal years 2018 and 2017 amounts are 0.7 million and 1.7 million of restricted share unit awards, respectively, representing the number of awards achieved above target levels based on the achievement of certain market conditions, as further described in the table below. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards. |

[0000866374-19-000006:notes:259]
Of the 8.3 million unvested restricted share unit awards granted in fiscal year 2019, approximately 6.5 million are plain-vanilla unvested restricted share unit awards with no performance or market conditions with an average grant date price of $12.57 per share. Further, approximately 1.3 million of these unvested restricted share unit awards granted in fiscal year 2019 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions, with an average grant date fair value estimated to be $14.00 per award calculated using a Monte Carlo simulation. Vesting information for these shares is further detailed in the table below.

[0000866374-19-000006:notes:260]
The Company will continue to recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2019, 0.6 million shares vested in connection with the restricted share unit awards with market conditions granted in fiscal year 2016.

[0000866374-19-000006:notes:261]
The total intrinsic value of restricted share unit awards vested under all the Company's plans was $80.2 million, $116.4 million and $119.1 million during fiscal years 2019, 2018 and 2017, respectively, based on the closing price of the Company's ordinary shares on the date vested.


## us-gaap:EarningsPerShareTextBlock

[0000866374-19-000006:notes:262]
EARNINGS PER SHARE

[0000866374-19-000006:notes:263]
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-19-000006:notes:264]
Diluted earnings per share reflects the potential dilution from stock options and restricted share unit awards. The potential dilution from stock options exercisable into ordinary share equivalents and restricted share unit awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-19-000006:notes:265]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income per share:

[0000866374-19-000006:notes:266]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands, exceptper share amounts) |
| Basic earnings per share: |  |  |  |  |  |
| Net income | $ | 93,399 |  |  | $ | 428,534 |  |  | $ | 319,564 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 526,519 |  |  | 529,782 |  |  | 540,503 |  |
| Basic earnings per share | $ | 0.18 |  |  | $ | 0.81 |  |  | $ | 0.59 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 93,399 |  |  | $ | 428,534 |  |  | $ | 319,564 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 526,519 |  |  | 529,782 |  |  | 540,503 |  |
| Weighted-average ordinary share equivalents from stock options and restricted share unit awards (1) (2) | 3,551 |  |  | 6,816 |  |  | 5,717 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 530,070 |  |  | 536,598 |  |  | 546,220 |  |
| Diluted earnings per share | $ | 0.18 |  |  | $ | 0.80 |  |  | $ | 0.59 |  |

[0000866374-19-000006:notes:267]
_________________________________________________________________________

[0000866374-19-000006:notes:268]
| (1) | An immaterial amount of options to purchase ordinary shares during fiscal years 2019 and 2018 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. Options to purchase ordinary shares of 0.5 million during fiscal year 2017 were excluded from the computation of diluted earnings per share. |

[0000866374-19-000006:notes:269]
| (2) | Restricted share unit awards of 6.8 million during fiscal year 2019 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. Less than 0.1 million of anti-dilutive restricted share unit awards were excluded from the computation of diluted earnings per share during fiscal years 2018 and 2017, respectively. |


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-19-000006:notes:270]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES

[0000866374-19-000006:notes:271]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-19-000006:notes:272]
Level 1—Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000866374-19-000006:notes:273]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other noncurrent assets on the consolidated balance sheets and include investments in equity securities that are valued using active market prices.

[0000866374-19-000006:notes:274]
Level 2—Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-19-000006:notes:275]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-19-000006:notes:276]
The Company's cash equivalents are comprised of bank deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-19-000006:notes:277]
The Company's deferred compensation plan assets also include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-19-000006:notes:278]
Level 3—Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-19-000006:notes:279]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of March 31, 2019 and 2018.

[0000866374-19-000006:notes:280]
There were no transfers between levels in the fair value hierarchy during fiscal years 2019 and 2018.

[0000866374-19-000006:notes:281]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-19-000006:notes:282]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2019 and 2018:

[0000866374-19-000006:notes:283]
|  | Fair Value Measurements as of March 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 473,888 |  |  | $ | — |  |  | $ | 473,888 |  |
| Foreign exchange forward contracts (Note 8) | — |  |  | 27,277 |  |  | — |  |  | 27,277 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 2,845 |  |  | 76,852 |  |  | — |  |  | 79,697 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) | $ | — |  |  | $ | (27,426 | ) |  | $ | — |  |  | $ | (27,426 | ) |

[0000866374-19-000006:notes:284]
|  | Fair Value Measurements as of March 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 452,622 |  |  | $ | — |  |  | $ | 452,622 |  |
| Foreign exchange forward contracts (Note 8) | — |  |  | 43,334 |  |  | — |  |  | 43,334 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 7,196 |  |  | 67,532 |  |  | — |  |  | 74,728 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) | $ | — |  |  | $ | (25,311 | ) |  | $ | — |  |  | $ | (25,311 | ) |

[0000866374-19-000006:notes:285]
Other financial instruments

[0000866374-19-000006:notes:286]
The following table presents the Company's liabilities not carried at fair value as of March 31, 2019 and 2018:

[0000866374-19-000006:notes:287]
|  | As of March 31, 2019 |  | As of March 31, 2018 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In thousands) |  | (In thousands) |  |  |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 499,950 |  |  | $ | 500,000 |  |  | $ | 513,596 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 671,563 |  |  | 670,724 |  |  | 687,813 |  |  | 689,966 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 458,531 |  |  | 457,958 |  |  | 483,656 |  |  | 485,470 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 499,950 |  |  | 500,000 |  |  | 525,292 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,815 |  |  | 599,940 |  |  | 596,387 |  |  | 627,407 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 52,746 |  |  | 52,746 |  |  | 59,443 |  |  | 59,443 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 112,524 |  |  | 112,524 |  |  | 123,518 |  |  | 123,518 |  |  | Level 2 |
| India Facilities | 170,206 |  |  | 170,206 |  |  | — |  |  | — |  |  | Level 2 |
| Total | $ | 3,062,385 |  |  | $ | 3,063,998 |  |  | $ | 2,950,817 |  |  | $ | 3,024,692 |  |  |  |

[0000866374-19-000006:notes:288]
The Term Loans due November 2021 and June 2022, and the Notes due February 2020, February 2023 and June 2025 are valued based on broker trading prices in active markets.

[0000866374-19-000006:notes:289]
The Company values its Euro Term Loans due September 2020 and January 2022, and India Facilities based on the current market rate, and as of March 31, 2019, the carrying amounts approximate fair values.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-19-000006:notes:290]
INCOME TAXES

[0000866374-19-000006:notes:291]
The domestic (Singapore) and foreign components of income before income taxes were comprised of the following:

[0000866374-19-000006:notes:292]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Domestic | $ | (10,498 | ) |  | $ | 323,522 |  |  | $ | 435,709 |  |
| Foreign | 192,624 |  |  | 197,371 |  |  | (64,861 | ) |
| Total | $ | 182,126 |  |  | $ | 520,893 |  |  | $ | 370,848 |  |

[0000866374-19-000006:notes:293]
The provision for income taxes consisted of the following:

[0000866374-19-000006:notes:294]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Domestic | $ | 1,517 |  |  | $ | 2,894 |  |  | $ | 1,037 |  |
| Foreign | 99,894 |  |  | 50,889 |  |  | 71,773 |  |
|  | 101,411 |  |  | 53,783 |  |  | 72,810 |  |
| Deferred: |  |  |  |  |  |
| Domestic | (40 | ) |  | 422 |  |  | 350 |  |
| Foreign | (12,644 | ) |  | 38,154 |  |  | (21,876 | ) |
|  | (12,684 | ) |  | 38,576 |  |  | (21,526 | ) |
| Provision for income taxes | $ | 88,727 |  |  | $ | 92,359 |  |  | $ | 51,284 |  |

[0000866374-19-000006:notes:295]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2019, 2018 and 2017. The reconciliation of the income tax expense expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0000866374-19-000006:notes:296]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Income taxes based on domestic statutory rates | $ | 30,961 |  |  | $ | 88,552 |  |  | $ | 63,044 |  |
| Effect of tax rate differential | (135,033 | ) |  | (244,128 | ) |  | (85,132 | ) |
| Change in liability for uncertain tax positions | (15,381 | ) |  | 22,180 |  |  | 684 |  |
| Change in valuation allowance | 191,896 |  |  | 297,330 |  |  | 78,728 |  |
| Recognition of prior year taxes recoverable | 5,439 |  |  | (53,757 | ) |  | — |  |
| Expiration of tax attributes | 4,277 |  |  | — |  |  | — |  |
| Other | 6,568 |  |  | (17,818 | ) |  | (6,040 | ) |
| Provision for income taxes | $ | 88,727 |  |  | $ | 92,359 |  |  | $ | 51,284 |  |

[0000866374-19-000006:notes:297]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2019, 2018 and 2017 was $24.4 million, $21.7 million and $15.5 million, respectively. For the fiscal year ended March 31, 2019, the effect on basic and diluted earnings per share was $0.05 and $0.05, respectively, and the effect on basic and diluted earnings per share during fiscal years 2018 and 2017 were $0.04 and $0.04, and $0.03 and $0.03, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in various years through the end of fiscal year 2028.

[0000866374-19-000006:notes:298]
The Company provides a valuation allowance against deferred tax assets that in the Company's estimation are not more likely than not to be realized. During fiscal year 2019, 2018 and 2017, the Company released valuation allowances totaling $2.8 million, $1.3 million and $39.6 million, respectively. For fiscal year 2019, this valuation allowance release was related to the Company's operations in Poland as this amount was deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of that subsidiary. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances. Lastly, these valuation allowance reductions and eliminations were offset by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions. For fiscal years ended March 31, 2019, 2018 and 2017, the offsetting amounts totaled $194.8 million, ($65.9) million and $103.9 million, respectively.

[0000866374-19-000006:notes:299]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years ended March 31, 2019, 2018 and 2017 were $7.5 million, $65.8 million and $67.9 million, respectively.

[0000866374-19-000006:notes:300]
The components of deferred income taxes are as follows:

[0000866374-19-000006:notes:301]
|  | As of March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (39,376 | ) |  | $ | (33,056 | ) |
| Intangible assets | (57,939 | ) |  | (80,565 | ) |
| Others | (14,879 | ) |  | (12,544 | ) |
| Total deferred tax liabilities | (112,194 | ) |  | (126,165 | ) |
| Deferred tax assets: |  |  |  |
| Fixed assets | 67,980 |  |  | 65,155 |  |
| Intangible assets | 7,442 |  |  | 11,237 |  |
| Deferred compensation | 13,864 |  |  | 13,475 |  |
| Inventory valuation | 11,082 |  |  | 6,952 |  |
| Provision for doubtful accounts | 4,797 |  |  | 3,073 |  |
| Net operating loss and other carryforwards | 1,944,782 |  |  | 2,133,097 |  |
| Others | 243,016 |  |  | 236,916 |  |
| Total deferred tax assets | 2,292,963 |  |  | 2,469,905 |  |
| Valuation allowances | (2,083,082 | ) |  | (2,259,956 | ) |
| Total deferred tax assets, net of valuation allowances | 209,881 |  |  | 209,949 |  |
| Net deferred tax asset | $ | 97,687 |  |  | $ | 83,784 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Long-term asset | $ | 164,611 |  |  | $ | 165,319 |  |
| Long-term liability | (66,924 | ) |  | (81,535 | ) |
| Total | $ | 97,687 |  |  | $ | 83,784 |  |

[0000866374-19-000006:notes:302]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-19-000006:notes:303]
The Company has recorded deferred tax assets of approximately $2.0 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $54.7 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-19-000006:notes:304]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-19-000006:notes:305]
The Company does not provide for income taxes on approximately $1.6 billion of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. The estimated amount of the unrecognized deferred tax liability on these undistributed earnings is approximately $150 million. As of March 31, 2019, the Company has provided for earnings in foreign subsidiaries that are not considered to be indefinitely reinvested and therefore subject to withholding taxes on $32.8 million of undistributed foreign earnings, recording a deferred tax liability of approximately $2.0 million thereon.

[0000866374-19-000006:notes:306]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-19-000006:notes:307]
|  | Fiscal Year EndedMarch 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Balance, beginning of fiscal year | $ | 227,590 |  |  | $ | 203,323 |  |
| Additions based on tax position related to the current year | 82,966 |  |  | 24,415 |  |
| Additions for tax positions of prior years | 5,575 |  |  | 5,926 |  |
| Reductions for tax positions of prior years | (15,432 | ) |  | (11,936 | ) |
| Reductions related to lapse of applicable statute of limitations | (14,786 | ) |  | (9,029 | ) |
| Settlements | (22,174 | ) |  | — |  |
| Impact from foreign exchange rates fluctuation | (12,017 | ) |  | 14,891 |  |
| Balance, end of fiscal year | $ | 251,722 |  |  | $ | 227,590 |  |

[0000866374-19-000006:notes:308]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by approximately $20 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-19-000006:notes:309]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2008.

[0000866374-19-000006:notes:310]
Of the $251.7 million of unrecognized tax benefits at March 31, 2019, $166.8 million will affect the annual effective tax rate (ETR) if the benefits are eventually recognized. The amount that doesn’t impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-19-000006:notes:311]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company’s tax expense. During the fiscal years ended March 31, 2019, 2018 and 2017, the Company recognized interest and penalty of approximately ($2.9) million and ($3.3) million and ($1.6) million, respectively. The Company had approximately $13.3 million, $16.2 million and $12.9 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2019, 2018 and 2017, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-19-000006:notes:312]
ORGANIZATION OF THE COMPANY

[0000866374-19-000006:notes:313]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scale® services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and manages complete packaged consumer and enterprise products, from medical devices and connected automotive systems to sustainable lighting and cloud and data center solutions for companies of all sizes in various industries and end-markets, through its activities in the following segments:

[0000866374-19-000006:notes:314]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including surgical equipment, drug delivery, diagnostics, telemedicine, disposable devices, imaging and monitoring, patient mobility and ophthalmology; and our automotive business, including vehicle electrification, connectivity, autonomous, and smart technologies; |

[0000866374-19-000006:notes:315]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, smart solar energy; and industrial, including semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks; |

[0000866374-19-000006:notes:316]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads and small cells for wireless infrastructure; our networking business, which includes optical, routing, and switching products for data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack-level solutions, converged infrastructure and software-defined product solutions; and |

[0000866374-19-000006:notes:317]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in IoT enabled devices, audio and consumer power electronics, mobile devices; and various supply chain solutions for consumer, computing and printing devices. |

[0000866374-19-000006:notes:318]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-19-000006:notes:319]
OTHER CHARGES (INCOME), NET

[0000866374-19-000006:notes:320]
Other charges (income), net for the fiscal years ended March 31, 2019, 2018 and 2017 are primarily composed of the following:

[0000866374-19-000006:notes:321]
|  | Fiscal Year Ended March 31 |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Gain on deconsolidation of subsidiary (1) | $ | (87,348 | ) |  | $ | (151,574 | ) |  | $ | — |  |
| (Gain) loss on sale of non-strategic business (2) | — |  |  | (38,689 | ) |  | 7,400 |  |
| Investment impairments and dispositions (3) | 193,063 |  |  | 21,895 |  |  | — |  |

[0000866374-19-000006:notes:322]
| (1) | During fiscal year ended March 31, 2019 the Company recognized other income of approximately $87 million from the deconsolidation of Bright Machines (formally known as AutoLab AI). The fiscal year ended March 31, 2018 includes a $151.6 million gain from the deconsolidation of Elementum. See note 2 for additional information on the deconsolidation of Bright Machines and Elementum. |

[0000866374-19-000006:notes:323]
| (2) | The Company recognized other income of $38.7 million from the sale of Wink during fiscal year 2018. See note 2 for additional information on the sale of Wink. Fiscal year 2017 includes a $7.4 million loss attributable to a non-strategic facility sold during the second quarter of that year. |

[0000866374-19-000006:notes:324]
| (3) | During fiscal year ended March 31, 2019 the Company recognized investment impairments of $193.1 million, under other charges, which is primarily driven by an $84 million impairment in its investment in Elementum, coupled with a $76 million loss for the portion of its investment in an unrelated third-party venture backed company, also determined to be impaired. See note 2 for additional information on the impairments. The Company recognized $21.9 million of impairment during fiscal year 2018 for certain non-core investments. |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000866374-19-000006:notes:325]
QUARTERLY FINANCIAL DATA (UNAUDITED)

[0000866374-19-000006:notes:326]
The Company's third fiscal quarter ends on December 31, and the fourth fiscal quarter and fiscal year ends on March 31 of each year. The first fiscal quarters of 2019 and 2018 ended on June 29, 2018 and June 30, 2017, respectively, and the second fiscal quarters of 2019 and 2018, ended on September 28, 2018 and September 29, 2017, respectively.

[0000866374-19-000006:notes:327]
The following table contains unaudited quarterly financial data for fiscal years 2019 and 2018. For fiscal year 2019, the Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings, as further described in note 2 to the consolidated financial statements. The comparative information for the fiscal year 2018 has not been restated and continues to be reported under the accounting standards in effect at the time.

[0000866374-19-000006:notes:328]
|  | Fiscal Year Ended March 31, 2019 |  | Fiscal Year Ended March 31, 2018 |
|  | First |  | Second |  | Third |  | Fourth |  | First |  | Second |  | Third |  | Fourth |
| Net sales (1) | $ | 6,398,956 |  |  | $ | 6,662,604 |  |  | $ | 6,922,827 |  |  | $ | 6,226,124 |  |  | $ | 6,008,272 |  |  | $ | 6,270,420 |  |  | $ | 6,751,552 |  |  | $ | 6,410,887 |  |
| Gross profit (2) | 377,854 |  |  | 402,301 |  |  | 357,325 |  |  | 380,295 |  |  | 406,932 |  |  | 393,325 |  |  | 446,328 |  |  | 349,297 |  |
| Net income (loss) (3) | 116,035 |  |  | 86,885 |  |  | (45,169 | ) |  | (64,352 | ) |  | 124,710 |  |  | 205,086 |  |  | 118,333 |  |  | (19,595 | ) |
| Earnings (losses) per share (4): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.22 |  |  | $ | 0.16 |  |  | $ | (0.09 | ) |  | $ | (0.12 | ) |  | $ | 0.24 |  |  | $ | 0.39 |  |  | $ | 0.22 |  |  | $ | (0.04 | ) |
| Diluted | $ | 0.22 |  |  | $ | 0.16 |  |  | $ | (0.09 | ) |  | $ | (0.12 | ) |  | $ | 0.23 |  |  | $ | 0.38 |  |  | $ | 0.22 |  |  | $ | (0.04 | ) |

[0000866374-19-000006:notes:329]
| (1) | The Company has made certain immaterial corrections to net sales previously reported for the first three quarters of fiscal 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result, the amounts presented above for net sales are $25 million, $48 million and $22 million lower than those previously reported for the first, second and third quarters of fiscal year 2019, respectively. These corrections had no impact on gross profit or net income for any period presented, as they were fully offset by corrections to cost of sales. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to previously issued financial statements and will make corrections prospectively in subsequent quarterly filings. |

[0000866374-19-000006:notes:330]
| (2) | The Company recorded a total of $65.8 million restructuring charges during the third quarter of fiscal year 2019. The Company classified $60.4 million of these charges as a component of cost of sales and approximately $5.4 million as a component of selling, general and administrative expenses. Refer to note 14 for additional information on these charges. The Company recorded $82.7 million restructuring charges during the fourth quarter of fiscal year 2018. The Company classified approximately $58.9 million of these charges as a component of cost of sales and approximately $23.8 million of these charges as a component of selling, general and administrative expenses. |

[0000866374-19-000006:notes:331]
| (3) | Net income for the fourth quarter of fiscal year 2019 was primarily affected by an $84 million charge for the impairment of the Company's investment in Elementum. Net income for the third quarter of fiscal year 2019 was primarily affected by a $70 million charge for the impairment of the Company's investment in an unrelated third-party company. Net income for the first quarter of fiscal year 2019 was affected by a $91.8 million gain on the deconsolidation of Bright Machines. Refer to note 2 for further details on the investments impairment charges and the gain on deconsolidation. Net income for the first quarter of fiscal year 2018 was affected by a $38.7 million gain recognized for the disposition of Wink. Net income for the second quarter of fiscal year 2018 was affected by $151.6 million non-cash gain as a result of the deconsolidation of the Company's investment in Elementum. |

[0000866374-19-000006:notes:332]
| (4) | Earnings per share are computed independently for each quarter presented and basic shares are used in the quarters with losses; therefore, the sum of the quarterly earnings per share may not equal the total earnings per share amounts for the fiscal year. |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-19-000006:notes:333]
RESTRUCTURING CHARGES

[0000866374-19-000006:notes:334]
Fiscal Year 2019

[0000866374-19-000006:notes:335]
During fiscal year 2019, the Company took targeted actions to optimize its portfolio, most notably within CTG. The Company recognized restructuring charges of approximately $113.3 million during the fiscal year ended March 31, 2019, of which $73.2 million were non-cash charges primarily for asset impairments. A significant component of its charges were associated with the wind down of its NIKE operations in Mexico in the third quarter of fiscal year 2019 where it recognized charges of $66 million primarily for non-cash asset impairments.

[0000866374-19-000006:notes:336]
In addition, the Company executed targeted head-count reductions at existing operating and design sites and corporate functions and exited certain immaterial businesses. Of these total restructuring charges, approximately $99.0 million was recognized as a component of cost of sales during the fiscal year ended March 31, 2019.

[0000866374-19-000006:notes:337]
Restructuring charges are not included in segment income, as disclosed further in note 19.

[0000866374-19-000006:notes:338]
Fiscal Year 2018

[0000866374-19-000006:notes:339]
During fiscal year 2018, the Company initiated targeted restructuring activities focused on optimizing the Company's cost structure in lower growth areas and, more importantly, streamlining certain corporate and segment functions. Restructuring charges are recorded based upon employee termination dates, site closure and consolidation plans generally in conjunction with an overall corporate initiative to drive cost reduction and realign the Company's global footprint. The Company recognized approximately $78.6 million of cash charges predominantly related to employee severance costs and $12.1 million of non-cash charges for asset impairment and other exit charges under the above plan. Of these total charges, approximately $66.8 million was recognized in cost of sales. A majority of the fiscal year 2018 restructuring activities were completed as of March 31, 2018.

[0000866374-19-000006:notes:340]
Fiscal Year 2017

[0000866374-19-000006:notes:341]
During fiscal year 2017, the Company initiated a restructuring plan to accelerate its ability to support more Sketch-to-Scale® efforts across the Company and reposition away from historical legacy programs and structures through rationalizing its current footprint at existing sites and at corporate SG&A functions. The Company recognized restructuring charges of approximately $49.4 million primarily for employee termination costs under the above plan. Of these total charges, approximately $38.8 million was recognized in cost of sales. All fiscal year 2017 restructuring activities were completed as of March 31, 2017.

[0000866374-19-000006:notes:342]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of March 31, 2019 for charges incurred in fiscal years 2019, 2018 and 2017 and prior periods:

[0000866374-19-000006:notes:343]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In thousands) |
| Balance as of March 31, 2016 | $ | 11,905 |  |  | $ | — |  |  | $ | 1,335 |  |  | $ | 13,240 |  |
| Provision for charges incurred in fiscal year 2017 | 42,253 |  |  | — |  |  | 7,142 |  |  | 49,395 |  |
| Cash payments for charges incurred in fiscal year 2017 | (25,894 | ) |  | — |  |  | — |  |  | (25,894 | ) |
| Cash payments for charges incurred in fiscal year 2016 and prior | (11,905 | ) |  | — |  |  | (1,335 | ) |  | (13,240 | ) |
| Balance as of March 31, 2017 | 16,359 |  |  | — |  |  | 7,142 |  |  | 23,501 |  |
| Provision for charges incurred in fiscal year 2018 | 69,439 |  |  | 9,417 |  |  | 11,835 |  |  | 90,691 |  |
| Cash payments for charges incurred in fiscal year 2017 and prior | (13,237 | ) |  | — |  |  | (3,671 | ) |  | (16,908 | ) |
| Cash payments for charges incurred in fiscal year 2018 | (24,555 | ) |  | — |  |  | — |  |  | (24,555 | ) |
| Non-cash charges incurred in fiscal year 2018 | — |  |  | (9,417 | ) |  | (1,968 | ) |  | (11,385 | ) |
| Balance as of March 31, 2018 | 48,006 |  |  | — |  |  | 13,338 |  |  | 61,344 |  |
| Provision for charges incurred in fiscal year 2019 | 38,634 |  |  | 46,365 |  |  | 28,314 |  |  | 113,313 |  |
| Cash payments for charges incurred in fiscal year 2018 and prior | (40,623 | ) |  | — |  |  | (4,293 | ) |  | (44,916 | ) |
| Cash payments for charges incurred in fiscal year 2019 | (22,783 | ) |  | — |  |  | (1,330 | ) |  | (24,113 | ) |
| Non-cash charges incurred in fiscal year 2019 | — |  |  | (46,365 | ) |  | (26,829 | ) |  | (73,194 | ) |
| Balance as of March 31, 2019 | 23,234 |  |  | — |  |  | 9,200 |  |  | 32,434 |  |
| Less: Current portion (classified as other current liabilities) | 23,234 |  |  | — |  |  | 9,200 |  |  | 32,434 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-19-000006:notes:344]
REVENUE

[0000866374-19-000006:notes:345]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that create enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

[0000866374-19-000006:notes:346]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-19-000006:notes:347]
Customer Contracts and Related Obligations

[0000866374-19-000006:notes:348]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer related accruals in note 2.

[0000866374-19-000006:notes:349]
Performance Obligations

[0000866374-19-000006:notes:350]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

[0000866374-19-000006:notes:351]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-19-000006:notes:352]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-19-000006:notes:353]
Contract Balances

[0000866374-19-000006:notes:354]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to receivables when rights to payment become unconditional. The following table summarizes the activity in the Company's contract assets during the fiscal year ended March 31, 2019 (in thousands):

[0000866374-19-000006:notes:355]
A contract liability, or deferred revenue is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the consolidated balance sheets. Contract liabilities were $271.8 million and $265.3 million as of March 31, 2019 and April 1, 2018, respectively.

[0000866374-19-000006:notes:356]
Disaggregation of Revenue


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0000866374-19-000006:notes:357]
The following table summarized the countries that accounted for more than 10% of property and equipment, net in fiscal year 2019 and 2018.

[0000866374-19-000006:notes:358]
|  | Fiscal Year Ended March 31, |
| Property and equipment, net: | 2019 |  | 2018 |
|  | (In thousands) |
| Mexico | $ | 537,396 |  |  | 23 | % |  | $ | 586,594 |  |  | 26 | % |
| China | 523,124 |  |  | 22 | % |  | 491,664 |  |  | 22 | % |
| U.S. | 361,098 |  |  | 15 | % |  | 305,222 |  |  | 14 | % |

[0000866374-19-000006:notes:359]
Geographic information of property and equipment, net is as follows:

[0000866374-19-000006:notes:360]
|  | As of March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Asia | $ | 903,288 |  |  | 39 | % |  | $ | 747,314 |  |  | 33 | % |
| Americas | 1,003,708 |  |  | 43 | % |  | 1,012,188 |  |  | 45 | % |
| Europe | 429,217 |  |  | 18 | % |  | 480,004 |  |  | 22 | % |
|  | $ | 2,336,213 |  |  |  |  | $ | 2,239,506 |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000866374-19-000006:notes:361]
Geographic information of net sales is as follows:

[0000866374-19-000006:notes:362]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 11,469,617 |  |  | 44 | % |  | $ | 11,210,793 |  |  | 44 | % |  | $ | 10,962,075 |  |  | 46 | % |
| Americas | 9,893,072 |  |  | 38 | % |  | 9,880,626 |  |  | 39 | % |  | 8,582,849 |  |  | 36 | % |
| Europe | 4,847,822 |  |  | 18 | % |  | 4,349,712 |  |  | 17 | % |  | 4,318,010 |  |  | 18 | % |
|  | $ | 26,210,511 |  |  |  |  | $ | 25,441,131 |  |  |  |  | $ | 23,862,934 |  |  |  |

[0000866374-19-000006:notes:363]
The following table summarized the countries that accounted for more than 10% of net sales in fiscal year 2019, 2018, and 2017.

[0000866374-19-000006:notes:364]
|  | Fiscal Year Ended March 31, |
| Net sales: | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| China | $ | 6,648,549 |  |  | 25 | % |  | $ | 7,449,591 |  |  | 29 | % |  | $ | 7,213,614 |  |  | 30 | % |
| Mexico | 4,538,720 |  |  | 17 | % |  | 4,361,814 |  |  | 17 | % |  | 4,075,616 |  |  | 17 | % |
| U.S. | 3,106,222 |  |  | 12 | % |  | 2,860,242 |  |  | 11 | % |  | 2,560,300 |  |  | 11 | % |
| Brazil | 2,181,025 |  |  | 8 | % |  | 2,578,466 |  |  | 10 | % |  | 1,907,591 |  |  | 8 | % |
| Malaysia | 1,996,152 |  |  | 8 | % |  | 2,005,119 |  |  | 8 | % |  | 2,267,478 |  |  | 10 | % |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-19-000006:notes:365]
During fiscal year 2019, 2018 and 2017, depreciation expense included in the segments' measure of operating performance above is as follows. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0000866374-19-000006:notes:366]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Depreciation expense |  |  |  |  |  |
| High Reliability Solutions | $ | 96,854 |  |  | $ | 97,114 |  |  | $ | 88,604 |  |
| Industrial & Emerging Industries | 92,606 |  |  | 75,366 |  |  | 70,814 |  |
| Communication & Enterprise Compute | 103,162 |  |  | 118,150 |  |  | 133,057 |  |
| Consumer Technologies Group | 104,298 |  |  | 110,276 |  |  | 110,379 |  |
| Corporate and Other | 36,493 |  |  | 33,526 |  |  | 29,384 |  |
| Total depreciation expense | $ | 433,413 |  |  | $ | 434,432 |  |  | $ | 432,238 |  |

[0000866374-19-000006:notes:367]
The comparative information for the fiscal years 2018 and 2017 has not been restated and continues to be reported under the accounting standards in effect at the time:

[0000866374-19-000006:notes:368]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |
| High Reliability Solutions | $ | 4,828,950 |  |  | $ | 4,769,464 |  |  | $ | 4,149,438 |  |
| Industrial & Emerging Industries | 6,182,637 |  |  | 5,972,496 |  |  | 4,967,738 |  |
| Communications & Enterprise Compute | 8,336,330 |  |  | 7,729,350 |  |  | 8,383,420 |  |
| Consumer Technologies Group | 6,862,594 |  |  | 6,969,821 |  |  | 6,362,338 |  |
|  | $ | 26,210,511 |  |  | $ | 25,441,131 |  |  | $ | 23,862,934 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |
| High Reliability Solutions | $ | 371,003 |  |  | $ | 380,878 |  |  | $ | 334,108 |  |
| Industrial & Emerging Industries | 269,172 |  |  | 235,422 |  |  | 179,749 |  |
| Communications & Enterprise Compute | 214,723 |  |  | 186,335 |  |  | 229,332 |  |
| Consumer Technologies Group | 121,336 |  |  | 111,629 |  |  | 179,910 |  |
| Corporate and Other | (104,471 | ) |  | (127,810 | ) |  | (107,850 | ) |
| Total income | 871,763 |  |  | 786,454 |  |  | 815,249 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 74,396 |  |  | 78,640 |  |  | 81,396 |  |
| Stock-based compensation | 76,032 |  |  | 85,244 |  |  | 82,266 |  |
| Customer related asset impairments (1) | 87,093 |  |  | 6,251 |  |  | 92,915 |  |
| Restructuring charges (Note 14) | 113,313 |  |  | 90,691 |  |  | 49,395 |  |
| New revenue standard adoption impact (Note 2 & Note 3) | 9,291 |  |  | — |  |  | — |  |
| Contingencies and other (2) | 35,644 |  |  | 51,631 |  |  | 17,704 |  |
| Interest and other, net | 183,454 |  |  | 122,823 |  |  | 99,532 |  |
| Other charges (income), net (Note 15) | 110,414 |  |  | (169,719 | ) |  | 21,193 |  |
| Income before income taxes | $ | 182,126 |  |  | $ | 520,893 |  |  | $ | 370,848 |  |

[0000866374-19-000006:notes:369]
| (1) | Customer related asset impairments for fiscal year 2019, relate to provision for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties and/or the Company is disengaging. |

[0000866374-19-000006:notes:370]
During fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand at the end of the fiscal year 2017 was not fully recoverable and recorded a charge of $60 million to reduce the carrying costs to market in fiscal year 2017. The Company also recognized a $16 million impairment charge for solar module equipment and $17 million primarily related to negative margin sales and other associated direct costs. The total charge of $93 million is included in cost of sales for fiscal year 2017 but is excluded from segment results above.

[0000866374-19-000006:notes:371]
| (2) | Contingencies and other during fiscal year 2019, primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, Contingencies and other also includes certain charges of the China based Multek operations that was divested in the second quarter of fiscal year 2019. |

[0000866374-19-000006:notes:372]
During fiscal year 2018, the Company incurred charges in connection with certain legal matters, for loss contingencies where it believed that losses were probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility, as well as certain assets impairments during fiscal year 2018.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-19-000006:notes:373]
SEGMENT REPORTING

[0000866374-19-000006:notes:374]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the Chief Operating Decision Maker ("CODM"), or a decision making group, in deciding how to allocate resources and in assessing performance. Resource allocation decisions and the Company's performance are assessed by its Chief Executive Officer ("CEO"), with support from certain direct staff who oversee operations of the business, collectively identified as the CODM or the decision making group.

[0000866374-19-000006:notes:375]
During the fourth quarter of fiscal year 2019, the Company announced that Revathi Advaithi was appointed CEO of the Company effective February 11, 2019. As part of her new role and responsibilities, the CEO along with certain direct report that oversee operations of the business, are now considered the CODM. There is a possibility that the CODM will request some changes in the information that it regularly reviews in determining how to allocate resources and in assessing performance, which could eventually result in changes to the Company's reportable segments.

[0000866374-19-000006:notes:376]
The Company has four reportable segments: HRS, IEI, CEC and CTG. These segments represent components of the Company for which separate financial information is available that is utilized on a regular basis by the CODM. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 for a description of the various product categories manufactured under each of these segments.

[0000866374-19-000006:notes:377]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related assets impairments, restructuring charges, the new revenue standard adoption impact, contingencies and other, interest and other, net and other charges (income), net.

[0000866374-19-000006:notes:378]
Selected financial information by segment is in the table below. For fiscal year 2019, the Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings, as further described in note 2 to the consolidated financial statements. The comparative information for the fiscal years 2018 and 2017 has not been restated and continues to be reported under the accounting standards in effect at the time:

[0000866374-19-000006:notes:379]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-19-000006:notes:380]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled in the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segments nor reported by segment to the Company's CODM.

[0000866374-19-000006:notes:381]
Property and equipment on a segment basis is not disclosed as it is not separately identified and is not internally reported by segment to the Company's CODM as described above. During fiscal year 2019, 2018 and 2017, depreciation expense included in the segments' measure of operating performance above is as follows. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0000866374-19-000006:notes:382]
Revenues are attributable to the country in which the product is manufactured, or service is provided.

[0000866374-19-000006:notes:383]
During fiscal years 2019, 2018 and 2017, net sales generated from Singapore, the principal country of domicile, were approximately $642.7 million, $686.9 million and $595.3 million, respectively.

[0000866374-19-000006:notes:384]
No other country accounted for more than 10% of net sales for the fiscal periods presented in the table above.

[0000866374-19-000006:notes:385]
As of March 31, 2019 and 2018, property and equipment, net held in Singapore were approximately $12.3 million and $12.6 million, respectively.

[0000866374-19-000006:notes:386]
No other country accounted for more than 10% of property and equipment, net for the fiscal periods presented in the table above.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-19-000006:notes:387]
TRADE RECEIVABLES SECURITIZATION

[0000866374-19-000006:notes:388]
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-19-000006:notes:389]
Asset-Backed Securitization Programs

[0000866374-19-000006:notes:390]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the "Global Program") and its North American Asset-Backed Securitization Agreement (the "North American Program," collectively, the "ABS Programs") to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables, which are included in other current assets as of March 31, 2019 and March 31, 2018, were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables, and recorded in interest and other, net in the consolidated statements of operations and were immaterial for all periods presented.

[0000866374-19-000006:notes:391]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $900 million for the Global Program, of which $725 million is committed and $175 million is uncommitted, and $250 million for the North American Program, of which $210 million is committed and $40 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0000866374-19-000006:notes:392]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the fiscal years ended March 31, 2019, 2018 and 2017 were not material and are included in interest and other, net within the consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-19-000006:notes:393]
The Company's deferred purchase price receivables relating to its asset-backed securitization program are recorded initially at fair value based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not material. The interrelationship between these inputs is also insignificant.

[0000866374-19-000006:notes:394]
As of March 31, 2019 and 2018, the accounts receivable balances that were sold under the ABS Programs were removed from the consolidated balance sheets and the net cash proceeds received by the Company during fiscal years ended March 31, 2019, 2018 and 2017 were included as cash provided by operating activities in the consolidated statements of cash flows. The Company recognizes these proceeds net of the deferred purchase price, consisting of a receivable from the purchasers that entitles the Company to certain collections on the receivable. The Company recognizes the collection of the deferred purchase price in net cash provided by investing activities in the consolidated statements of cash flows separately as cash collections of deferred purchase price.

[0000866374-19-000006:notes:395]
As of March 31, 2019, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of $0.9 billion and deferred purchase price receivables of $0.3 billion. As of March 31, 2018, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $1.1 billion and deferred purchase price receivables of $0.4 billion. The deferred purchase price balances as of March 31, 2019 and March 31, 2018, also represent the non-cash beneficial interest obtained in exchange for securitized receivables.

[0000866374-19-000006:notes:396]
For the fiscal years ended March 31, 2019, 2018 and 2017, cash flows from sales of receivables under the ABS Programs consisted of approximately $6.8 billion, $8.0 billion and $7.6 billion, respectively, for transfers of receivables, and approximately $3.6 billion, $4.6 billion and $5.0 billion, respectively, for collections on deferred purchase price receivables. The Company's cash flows from transfer of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-19-000006:notes:397]
Trade Accounts Receivable Sale Programs

[0000866374-19-000006:notes:398]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.5 billion and $0.3 billion as of March 31, 2019 and 2018, respectively. For the years ended March 31, 2019, 2018 and 2017, total accounts receivables sold to certain third party banking institutions was approximately $2.7 billion, $1.5 billion and $1.3 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-19-000006:notes:399]
SHARE REPURCHASE PLAN

[0000866374-19-000006:notes:400]
During fiscal year 2019, the Company repurchased approximately 17.7 million shares for an aggregate purchase value of approximately $189.0 million and retired all of these shares.

[0000866374-19-000006:notes:401]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 16, 2018. As of March 31, 2019, shares in the aggregate amount of $324.5 million were available to be repurchased under the current plan.
