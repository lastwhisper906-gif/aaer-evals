# FLEX MD&A — 0000866374-19-000006


## mdna

[0000866374-19-000006:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-19-000006:mdna:2]
OVERVIEW

[0000866374-19-000006:mdna:3]
We are a globally-recognized, provider of Sketch-to-Scale® services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. We design, build, deliver and manage complete packaged consumer and enterprise products, from medical devices and connected automotive systems to sustainable lighting and cloud data center infrastructures, for companies of all sizes in various industries and end-markets, through our activities in the following segments:

[0000866374-19-000006:mdna:4]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including surgical equipment, drug delivery, diagnostics, telemedicine, disposable devices, imaging and monitoring, patient mobility and ophthalmology; and our automotive business, including vehicle electrification, connectivity, autonomous, and smart technologies; |

[0000866374-19-000006:mdna:5]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, smart solar energy; and industrial, including semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks; |

[0000866374-19-000006:mdna:6]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads and small cells for wireless infrastructure; our networking business, which includes optical, routing, and switching products for data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack-level solutions, converged infrastructure and software-defined product solutions; and |

[0000866374-19-000006:mdna:7]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in IoT enabled devices, audio and consumer power electronics, mobile devices; and various supply chain solutions for consumer, computing and printing devices. |

[0000866374-19-000006:mdna:8]
These segments represent components of the Company for which separate financial information is available that is utilized on a regular basis by the Chief Operating Decision Maker (“CODM”). Our segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-19-000006:mdna:9]
During the fourth quarter of fiscal year 2019, we announced that Revathi Advaithi was appointed CEO of the Company effective February 11, 2019. As part of her new role and responsibilities, the CEO along with certain direct reports that oversee operations of the business, are now considered the CODM. There is a possibility that the CODM will request changes in the

[0000866374-19-000006:mdna:10]
information that is regularly reviewed in determining how to allocate resources and in assessing performance, which could eventually result in changes to our reportable segments.

[0000866374-19-000006:mdna:11]
Refer to note 19 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for additional information on our operating segments.

[0000866374-19-000006:mdna:12]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-19-000006:mdna:13]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0000866374-19-000006:mdna:14]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customer's supply chain solutions needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-19-000006:mdna:15]
During the past several years, we have evolved our long-term portfolio towards a mix of businesses which possess longer product life cycles and higher segment operating margins such as reflected in our IEI and HRS businesses. We have expanded our design and engineering relationships through our product innovation centers and global design centers.

[0000866374-19-000006:mdna:16]
During fiscal year 2019, we took action to revise our go-to-market strategy within our CTG business, where we are actively managing under-performing accounts and are focused on partnering with well-funded, leading multi-national brands that control multiple categories of products and have regional demand requirements. We expect this transition to continue in fiscal year 2020 which will continue to put downward pressure on the segment operating margins until fully transitioned. During the fiscal year 2019, we also completed the wind down of our NIKE operations in Mexico and concurrently streamlined our third-party investments. In addition, we developed a measured and sustainable operating plan for India and as of March 31, 2019, we have completed the majority of our regional build-out. We continue to invest in the capital expenditures necessary to support underlying higher margin, long-term programs in our IEI and HRS businesses.

[0000866374-19-000006:mdna:17]
We believe that our continued business transformation is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-19-000006:mdna:18]
We are one of the world's largest providers of global supply chain solutions, with revenues of $26.2 billion in fiscal year 2019. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 35 countries across four continents. As of March 31, 2019, our total manufacturing capacity was approximately 27 million square feet. In fiscal year 2019, our net sales in Asia, the Americas and Europe represented approximately 44%, 38% and 18%, respectively, of our total net sales, based on the location of the manufacturing site. On April 1, 2018, we adopted a new revenue standard and as a result we recognized a cumulative effect of adoption as an adjustment to the opening balance of retained earnings, as further described in note 2 to the consolidated financial statements included under Item 8. The comparative information has not been restated and continues to be reported under the accounting standards in effect at the time. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-19-000006:mdna:19]
|  | Fiscal Year Ended March 31, |
| Net sales: | 2019 |  | 2018 |  | 2017 |
|  | (In millions) |
| China | $ | 6,649 |  |  | 25 | % |  | $ | 7,450 |  |  | 29 | % |  | $ | 7,214 |  |  | 30 | % |
| Mexico | 4,539 |  |  | 17 | % |  | 4,362 |  |  | 17 | % |  | 4,076 |  |  | 17 | % |
| U.S. | 3,106 |  |  | 12 | % |  | 2,860 |  |  | 11 | % |  | 2,560 |  |  | 11 | % |
| Brazil | 2,181 |  |  | 8 | % |  | 2,578 |  |  | 10 | % |  | 1,908 |  |  | 8 | % |
| Malaysia | 1,996 |  |  | 8 | % |  | 2,005 |  |  | 8 | % |  | 2,267 |  |  | 10 | % |
| India | 1,805 |  |  | 7 | % |  | 609 |  |  | 2 | % |  | 511 |  |  | 2 | % |
| Other | 5,935 |  |  | 23 | % |  | 5,577 |  |  | 23 | % |  | 5,327 |  |  | 22 | % |
|  | $ | 26,211 |  |  |  |  | $ | 25,441 |  |  |  |  |  | $ | 23,863 |  |  |  |  |

[0000866374-19-000006:mdna:20]
Amounts may not sum due to rounding.

[0000866374-19-000006:mdna:21]
|  | Fiscal Year Ended March 31, |
| Property and equipment, net: | 2019 |  | 2018 |
|  | (In millions) |
| Mexico | $ | 537 |  |  | 23 | % |  | $ | 587 |  |  | 26 | % |
| China | 523 |  |  | 22 | % |  | 492 |  |  | 22 | % |
| U.S. | 361 |  |  | 15 | % |  | 305 |  |  | 14 | % |
| India | 219 |  |  | 9 | % |  | 78 |  |  | 3 | % |
| Hungary | 103 |  |  | 4 | % |  | 150 |  |  | 7 | % |
| Malaysia | 138 |  |  | 6 | % |  | 153 |  |  | 7 | % |
| Other | 454 |  |  | 21 | % |  | 475 |  |  | 21 | % |
|  | $ | 2,336 |  |  |  |  | $ | 2,240 |  |  |  |

[0000866374-19-000006:mdna:22]
Amounts may not sum due to rounding.

[0000866374-19-000006:mdna:23]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-19-000006:mdna:24]
Our operating results are affected by a number of factors, including the following:

[0000866374-19-000006:mdna:25]
| • | changes in the macro-economic environment and related changes in consumer demand; |

[0000866374-19-000006:mdna:26]
| • | the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors; |

[0000866374-19-000006:mdna:27]
| • | the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance; |

[0000866374-19-000006:mdna:28]
| • | our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers; |

[0000866374-19-000006:mdna:29]
| • | the effects on our business due to certain customers' products having short product life cycles; |

[0000866374-19-000006:mdna:30]
| • | our customers' ability to cancel or delay orders or change production quantities; |

[0000866374-19-000006:mdna:31]
35

[0000866374-19-000006:mdna:32]
| • | our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements; |

[0000866374-19-000006:mdna:33]
| • | our exposure to financially troubled customers; |

[0000866374-19-000006:mdna:34]
| • | integration of acquired businesses and facilities; |

[0000866374-19-000006:mdna:35]
| • | increased labor costs due to adverse labor conditions in the markets we operate; |

[0000866374-19-000006:mdna:36]
| • | the impacts on our business due to component shortages or other supply chain related constraints; |

[0000866374-19-000006:mdna:37]
| • | changes in tax legislation; and |

[0000866374-19-000006:mdna:38]
| • | changes in trade regulations and treaties. |

[0000866374-19-000006:mdna:39]
The attractiveness of our services to customers and our ability to conduct business with certain customers can be affected by changes in U.S. and other countries' trade policies. In 2018, the U.S. imposed tariffs on a large variety of products of Chinese origin. The U.S. government has also indicated a readiness to further expand the scope of the tariffs on Chinese goods if negotiations are not successful, and most recently, effective May 10, 2019, increased tariffs on $200 billion of Chinese goods to 25%. Further, on May 15, 2019, President Trump issued an executive order designed to secure the information and communications technology and services supply chain, which would restrict the acquisition or use in the United States of information and communications technology or services designed, developed, manufactured, or supplied by persons owned by, controlled by, or subject to the jurisdiction or direction of foreign adversaries. The executive order is subject to implementation by the Secretary of Commerce and applies to contracts entered into prior to the effective date of the order. In addition, the U.S. Commerce Department has implemented additional restrictions and may implement further restrictions that would affect conducting business with certain Chinese companies. Depending upon their duration and implementation, as well as our ability to mitigate their impact, these tariffs, the executive order and its implementation and other regulatory actions could materially affect our business, including in the form of increased cost of goods sold, decreased margins, increased pricing for customers, and reduced sales.

[0000866374-19-000006:mdna:40]
We also are subject to other risks as outlined in Item 1A, "Risk Factors".

[0000866374-19-000006:mdna:41]
Net sales for fiscal year 2019 increased 3% or $0.8 billion to $26.2 billion from the prior year. The increase was primarily due to a $0.6 billion increase in our CEC segment and a $0.2 billion increase in our IEI segment. Our fiscal year 2019 gross profit totaled $1.5 billion, representing a decrease of $78 million, or 5%, from the prior year, which is primarily driven by an incremental increase of $32 million of restructuring charges, coupled with approximately $47 million of additional charges related to distressed customers that were included in cost of sales in fiscal year 2019. These incremental charges were part of our targeted actions to optimize our business portfolio, most notably within CTG, as we eliminated certain non-core activities and repositioned ourselves to align with go-forward strategies. The decline in gross margin is also due to the mix of revenues included in our portfolio most notably a decline in revenues from our automotive products and services within HRS which carry higher gross profit margins. Increased revenues from our ramping businesses in India further impacted the decline in gross profit margin from the prior year as the new programs were pressured below our average margins during the ramp. Our net income totaled $93 million, representing a decrease of $335 million, or 78%, compared to fiscal year 2018. The decrease in net income during fiscal year 2019 is primarily due to the same factors explained above in addition to the recognition of $193 million of charges primarily for the impairment of certain of our investments, including our investment in Elementum SCM (Cayman) Ltd ("Elementum"), offset by an $87 million gain from the deconsolidation of Bright Machines (formerly known as AutoLab AI). We also recognized a $152 million gain from the deconsolidation of Elementum in fiscal year 2018, which contributed further to the decrease in net income from fiscal year 2018 to 2019. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details of the investment impairments and the deconsolidation of Bright Machines, respectively.

[0000866374-19-000006:mdna:42]
Cash used in operations decreased by approximately $0.9 billion to $3.0 billion for fiscal year 2019 compared with $3.9 billion for fiscal year 2018 primarily due to a lower level of cash collections on deferred purchase price being reclassed to investing activities offset by elevated levels of investment required to support the business growth and operating through a more constrained inventory marketplace in fiscal year 2019. Our net working capital, defined as accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories, less accounts payable, was redefined upon the adoption of ASC 606 (as further described in note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data"), to include contract assets on a going forward basis. Our net working capital as a percentage of annualized sales for fiscal year 2019 increased by 0.3% to 6.7% from the prior year. Upon adoption of Accounting Standard Update (ASU) 2016-15 during the first quarter of fiscal year

[0000866374-19-000006:mdna:43]
36

[0000866374-19-000006:mdna:44]
2019, cash collections on deferred purchase price from our ABS programs that were previously classified as operating cash inflows are now classified as cash flows from investing activities. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further description on the ASU.

[0000866374-19-000006:mdna:45]
As a result, we redefined our free cash flow as cash from operating activities, plus cash collections of deferred purchase price, less net purchases of property and equipment in order to present free cash flows on a consistent basis for investor transparency. We also excluded the reduction to operating cash flows related to certain vendor programs from the free cash flow calculation. Free cash flow was $3 million for fiscal year 2019 compared to $236 million for fiscal year 2018. The decrease in free cash flow is primarily due to increased capital expenditures in fiscal year 2019 as we built out our regional capacity in India and continued to expand our capacity and capability in support of our expanding IEI and HRS businesses, as well as increased inventory levels due to a more constrained inventory marketplace and higher business levels. Refer to the Liquidity and Capital Resources section for the free cash flows reconciliation to our most directly comparable GAAP financial measure of cash flows from operations. Cash provided by investing activities decreased by approximately $458 million to $3.3 billion for fiscal year 2019, compared with $3.7 billion for fiscal year 2018, primarily due lower cash collection on deferred purchase price and higher capital expenditures as described above. Cash used in financing activities totaled $30 million during fiscal year 2019, which decreased by approximately $158 million from $188 million in the prior year, primarily due to higher net proceeds from bank borrowings and long-term debt in fiscal year 2019.

[0000866374-19-000006:mdna:46]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000866374-19-000006:mdna:47]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results may differ from those estimates and assumptions.

[0000866374-19-000006:mdna:48]
We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-19-000006:mdna:49]
Revenue Recognition

[0000866374-19-000006:mdna:50]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assess whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when we have transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to notes 2 and 3 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-19-000006:mdna:51]
Customer Contracts and Related Obligations

[0000866374-19-000006:mdna:52]
Certain of our customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. We estimate the variable consideration related to these price adjustments as part of the total transaction price and recognize revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. We constrain the amount of revenues recognized for these contractual provisions based on our best estimate of the amount which will not result in a significant reversal of revenue in a future period. We determine the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-19-000006:mdna:53]
Customer Credit Risk

[0000866374-19-000006:mdna:54]
We have an established customer credit policy through which we manage customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. We perform ongoing credit evaluations of our customers' financial condition and make provisions for doubtful accounts based on the outcome of those credit evaluations. We evaluate the collectability of accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent we identify exposures as a result of customer credit issues, we also review other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-19-000006:mdna:55]
Restructuring Charges

[0000866374-19-000006:mdna:56]
We recognize restructuring charges related to our plans to close or consolidate excess manufacturing facilities and rationalize administrative functions and to realign our corporate cost structure. In connection with these activities, we recognize restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-19-000006:mdna:57]
The recognition of these restructuring charges requires that we make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned restructuring activity. To the extent our actual results differ from our estimates and assumptions, we may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, we evaluate the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed exit plans.

[0000866374-19-000006:mdna:58]
Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-19-000006:mdna:59]
Inventory Valuation

[0000866374-19-000006:mdna:60]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regards to inventory procured to fulfill customer demand.

[0000866374-19-000006:mdna:61]
Valuation of Private Company Investments

[0000866374-19-000006:mdna:62]
We assess our investments for impairment whenever events or changes in circumstances indicate that the assets may be impaired. The factors we consider in our evaluation of potential impairment of our investments, include, but are not limited to a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. The carrying value of certain of our investments are individually material, thus there is the potential for material charges in future periods if we determine that those investments are impaired.

[0000866374-19-000006:mdna:63]
During the last half of fiscal year 2019, the Company reassessed its strategy with respect to its investment portfolio. As a result of the change in the Company's strategy and due to market valuation changes, the Company recognized an aggregate net charge related to investment impairments and dispositions of approximately $193 million for the fiscal year ended March 31, 2019, which is recorded in other charges (income), net on the consolidated statement of operations. The aggregate charge was primarily driven by write-downs of the Company's investment positions in a non-core cost method investment and Elementum as well as other investment impairments that were individually immaterial.

[0000866374-19-000006:mdna:64]
Carrying Value of Long-Lived Assets

[0000866374-19-000006:mdna:65]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset may not be recoverable. An impairment loss is recognized when the carrying amount of these long-lived assets exceeds their fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such assets are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, general business environment and other factors. To the extent

[0000866374-19-000006:mdna:66]
our estimates relating to cash flows and fair value of assets change adversely we may have to recognize additional impairment charges in the future.

[0000866374-19-000006:mdna:67]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require us to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider our budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While we believe we have made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If our actual results are not consistent with our estimates and assumptions used to calculate fair value, it could result in material impairments of our goodwill. During fiscal year 2019, we adopted ASU 2017-04 "Simplifying the Test for Goodwill Impairment", which simplifies the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. The ASU did not have a material impact to Flex's financial position during the period (Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail).

[0000866374-19-000006:mdna:68]
We performed our goodwill impairment assessment on January 1, 2019 and determined that no impairment existed as of the date of the impairment test because the fair value of each one of our reporting units exceeded its respective carrying value. As of the date of the impairment test, all reporting units' fair values were 25% or more, over their respective carrying values, with the exception of the CTG reporting unit which was 22% in excess of its carrying value. The estimated future results for CTG used in the impairment analysis reflect our revised strategy including the wind down of our NIKE operations in Mexico, further restrictions on capital expenditures related to our expansion into India and our focus on partnering with well-funded, leading multi-national brands that control multiple categories of products and have regional demand requirements. If we are not successful in driving improved results in our CTG segment it is reasonably possible that material goodwill impairment charges could be recorded in future periods.

[0000866374-19-000006:mdna:69]
Contingent Liabilities

[0000866374-19-000006:mdna:70]
We may be exposed to certain liabilities relating to our business operations, acquisitions of businesses and assets and other activities. We make provisions for such liabilities when it is probable that the settlement of the liability will result in an outflow of economic resources or the impairment of an asset. We make these assessments based on facts and circumstances that may change in the future resulting in additional expenses.

[0000866374-19-000006:mdna:71]
Refer to note 12 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our contingent liabilities.

[0000866374-19-000006:mdna:72]
Income Taxes

[0000866374-19-000006:mdna:73]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-19-000006:mdna:74]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 13 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-19-000006:mdna:75]
RESULTS OF OPERATIONS

[0000866374-19-000006:mdna:76]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data." The data below, and discussion that follows, represents our results from operations. On April 1, 2018, we adopted the new revenue standard and as a result we recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings, as further described in note 2 to the consolidated financial statements included under Item 8. The comparative information has not been restated and continues to be reported under the accounting standards in effect at the time.

[0000866374-19-000006:mdna:77]
|  | Fiscal Year EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.8 |  |  | 93.5 |  |  | 93.5 |  |
| Restructuring charges | 0.4 |  |  | 0.3 |  |  | 0.2 |  |
| Gross profit | 5.8 |  |  | 6.2 |  |  | 6.3 |  |
| Selling, general and administrative expenses | 3.6 |  |  | 4.0 |  |  | 3.9 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.1 |  |  | 0.1 |  |  | — |  |
| Interest and other, net | 0.7 |  |  | 0.5 |  |  | 0.4 |  |
| Other charges (income), net | 0.4 |  |  | (0.7 | ) |  | 0.1 |  |
| Income before income taxes | 0.7 |  |  | 2.0 |  |  | 1.6 |  |
| Provision for income taxes | 0.3 |  |  | 0.4 |  |  | 0.2 |  |
| Net Income | 0.4 | % |  | 1.6 | % |  | 1.4 | % |

[0000866374-19-000006:mdna:78]
Net sales

[0000866374-19-000006:mdna:79]
Net sales during fiscal year 2019 totaled $26.2 billion, representing an increase of $0.8 billion, or 3%, from $25.4 billion during fiscal year 2018. The overall increase in sales was driven by increases in three of our segments offset by a decline in sales in our CTG segment. Net sales was higher across all our regions during fiscal year 2019, with increases of $0.5 billion in Europe, $0.3 billion in Asia, and to a lesser extent, $12 million in the Americas.

[0000866374-19-000006:mdna:80]
Net sales during fiscal year 2018 totaled $25.4 billion, representing an increase of $1.5 billion, or 7%, from $23.9 billion during fiscal year 2017. During fiscal year 2018, the increase in net sales was primarily driven by an increase of $1.3 billion in the Americas and to a lesser extent, $0.2 billion in Asia with Europe remaining relatively consistent from the prior year.

[0000866374-19-000006:mdna:81]
The following table sets forth net sales by segments and their relative percentages. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0000866374-19-000006:mdna:82]
|  | Fiscal Year Ended March 31, |
| Segments: | 2019 |  | 2018 |  | 2017 |
|  | (In millions) |
| High Reliability Solutions | $ | 4,829 |  |  | 18 | % |  | $ | 4,770 |  |  | 19 | % |  | $ | 4,149 |  |  | 17 | % |
| Industrial & Emerging Industries | 6,183 |  |  | 24 | % |  | 5,972 |  |  | 24 | % |  | 4,968 |  |  | 21 | % |
| Communications & Enterprise Compute | 8,336 |  |  | 32 | % |  | 7,729 |  |  | 30 | % |  | 8,384 |  |  | 35 | % |
| Consumer Technologies Group | 6,863 |  |  | 26 | % |  | 6,970 |  |  | 27 | % |  | 6,362 |  |  | 27 | % |
|  | $ | 26,211 |  |  |  |  |  | $ | 25,441 |  |  |  |  |  | $ | 23,863 |  |  |  |  |

[0000866374-19-000006:mdna:83]
Net sales during fiscal year 2019 increased $0.6 billion or 8% in our CEC segment driven by momentum from our cloud and data center business as well as the expansion of network infrastructure programs to support 4G and 5G technology, offset by declines in our data networking business due to weakness with some legacy product lines. Our IEI segment increased $0.2 billion or 4%, which was mainly driven by new programs and customer launches within our industrial, home and lifestyle

[0000866374-19-000006:mdna:84]
businesses, offset by declines in our capital equipment and energy businesses. Our HRS segment increased $59 million or 1% from higher sales in our health solutions business as we benefited from prior year investments in design, engineering and automation that have strengthened and improved our capabilities and competitive positioning that more than offset year over year declines from our automotive customers primarily in Asia. These segment increases were partially offset by a decrease of $107 million or 1.5% in our CTG segment, primarily within the legacy consumer sectors of the segment and as a result of actively repositioning the portfolio of customers and rationalizing underperforming customers and eliminating certain product categories.

[0000866374-19-000006:mdna:85]
Net sales during fiscal year 2018 increased $1.0 billion or 20% in our IEI segment, which was mainly driven by our industrial, home and lifestyle businesses in addition to growth in our solar energy business. Our CTG segment increased $0.6 billion or 10% largely attributable to stronger sales in our connected living and mobile devices businesses, offset by a decrease in gaming. Our HRS segment increased $0.6 billion or 15% from higher sales in our automotive business. These increases were partially offset by a decrease of $0.7 billion or 8% in our CEC segment, largely attributable to lower sales within our telecom and networking businesses, offset by increased sales in our cloud and data center business.

[0000866374-19-000006:mdna:86]
Our ten largest customers during fiscal years 2019, 2018 and 2017 accounted for approximately 43%, 41% and 43% of net sales, respectively. We have made substantial efforts to diversify of our portfolio which allows us to operate at scale in many different industries, and, as a result, no customer accounted for greater than 10% of net sales in fiscal year 2019, 2018 or 2017.

[0000866374-19-000006:mdna:87]
Gross profit

[0000866374-19-000006:mdna:88]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion or consolidation of manufacturing facilities including specific restructuring activities from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-19-000006:mdna:89]
Gross profit decreased $0.1 billion to $1.5 billion from $1.6 billion from fiscal year 2018 to fiscal year 2019. Gross margin decreased 40 basis points, to 5.8% of net sales in fiscal year 2019, from 6.2% of net sales in fiscal year 2018. The decrease is primarily due to an additional $32 million, or 10 basis points, of restructuring charges coupled with approximately $47 million of additional charges related to distressed customers incurred during fiscal year 2019 versus fiscal year 2018. As noted above, during the year we completed the wind down of our NIKE Mexico operations and incurred a total of $66 million of charges primarily for non-cash asset impairments in the second and third quarters of fiscal year 2019. Additional gross profit and gross margin declines were due to revenue reductions in some of our higher margin businesses, such as automotive and semi-cap equipment and further due to the Multek China divestiture. Also negatively pressuring the gross profit margin was the significant revenues from ramping new programs in India which had pressured margins below our average margins during the ramp in fiscal year 2019.

[0000866374-19-000006:mdna:90]
Gross profit during fiscal year 2018 increased $75 million to $1.6 billion from $1.5 billion during fiscal year 2017, primarily as a result of the increase in revenue offset by $67 million, or 30 basis points, of restructuring charges incurred during fiscal year 2018. Gross margin decreased 10 basis points, to 6.2% of net sales in fiscal year 2018, from 6.3% of net sales in fiscal year 2017, mainly attributable to the same factors previously described, coupled with elevated levels of investments in ramping new operations for our strategic footwear customer.

[0000866374-19-000006:mdna:91]
Segment income

[0000866374-19-000006:mdna:92]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales, less cost of sales and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairments, restructuring charges, the new revenue standard adoption impact, contingencies and other, interest and other, net and other charges (income), net. A portion of depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-19-000006:mdna:93]
The following table sets forth segment income and margins. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0000866374-19-000006:mdna:94]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In millions) |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |
| High Reliability Solutions | $ | 371 |  |  | 7.7 | % |  | $ | 381 |  |  | 8.0 | % |  | $ | 334 |  |  | 8.1 | % |
| Industrial & Emerging Industries | 269 |  |  | 4.4 | % |  | 235 |  |  | 3.9 | % |  | 180 |  |  | 3.6 | % |
| Communications & Enterprise Compute | 215 |  |  | 2.6 | % |  | 186 |  |  | 2.4 | % |  | 229 |  |  | 2.7 | % |
| Consumer Technologies Group | 121 |  |  | 1.8 | % |  | 112 |  |  | 1.6 | % |  | 180 |  |  | 2.8 | % |
| Corporate and Other | (104 | ) |  |  |  | (128 | ) |  |  |  | (108 | ) |  |  |
| Total segment income | 872 |  |  | 3.3 | % |  | 786 |  |  | 3.1 | % |  | 815 |  |  | 3.4 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 74 |  |  |  |  | 79 |  |  |  |  | 81 |  |  |  |
| Stock-based compensation | 76 |  |  |  |  | 85 |  |  |  |  | 82 |  |  |  |
| Customer related asset impairments (1) | 87 |  |  |  |  | 6 |  |  |  |  | 93 |  |  |  |
| Restructuring charges (Note 14) | 113 |  |  |  |  | 91 |  |  |  |  | 49 |  |  |  |
| New revenue standard adoption impact (Note 2 & Note 3) | 9 |  |  |  |  | — |  |  |  |  | — |  |  |  |
| Contingencies and other (2) | 35 |  |  |  |  | 52 |  |  |  |  | 18 |  |  |  |
| Interest and other, net | 183 |  |  |  |  | 123 |  |  |  |  | 100 |  |  |  |
| Other charges (income), net (Note 15) | 110 |  |  |  |  | (170 | ) |  |  |  | 21 |  |  |  |
| Income before income taxes | $ | 182 |  |  |  |  | $ | 521 |  |  |  |  | $ | 371 |  |  |  |

[0000866374-19-000006:mdna:95]
Amounts may not sum due to rounding.

[0000866374-19-000006:mdna:96]
| (1) | Customer related asset impairments for fiscal year 2019, relate to provision for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties and/or the Company is disengaging from. |

[0000866374-19-000006:mdna:97]
During fiscal year 2017, prices for solar panel modules declined significantly. We determined that certain solar panel inventory on hand at the end of the fiscal year 2017 was not fully recoverable and recorded a charge of $60 million to reduce the carrying costs to market in fiscal year 2017. We also recognized a $16 million impairment charge for solar module equipment and $17 million primarily related to negative margin sales and other associated direct costs. The total charge of $93 million is included in cost of sales for fiscal year 2017 but is excluded from segment results above.

[0000866374-19-000006:mdna:98]
| (2) | Contingencies and other during fiscal year 2019, primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, Contingencies and other also includes certain charges of the China based Multek operations that was divested in the second quarter of fiscal year 2019. |

[0000866374-19-000006:mdna:99]
During fiscal year 2018, we incurred charges in connection with certain legal matters, for loss contingencies where it believed that losses were probable and estimable. Additionally, we incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility as well as certain assets impairments during fiscal year 2018.

[0000866374-19-000006:mdna:100]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-19-000006:mdna:101]
HRS segment margin decreased 30 basis point to 7.7% for fiscal year 2019, from 8.0% during fiscal year 2018, primarily due to reduced revenues from our automotive products and services, which carry higher gross margins partially offset by greater contribution from our growing health solutions business. HRS segment margin decreased 10 basis points to 8.0% for fiscal year 2018, from 8.1% during fiscal year 2017. The slight decrease reflects investments in expanding the segment's design and engineering capabilities, coupled with ramping up new customers and programs.

[0000866374-19-000006:mdna:102]
IEI segment margin increased 50 basis points to 4.4% for fiscal year 2019, from 3.9% during fiscal year 2018, as a result of improved overhead absorption benefits from the increased revenues and greater levels of design led programs which have higher gross margins, offset by reduced demand in capital equipment and energy. IEI segment margin increased 30 basis points to 3.9% for fiscal year 2018, from 3.6% during fiscal year 2017. This is primarily driven by strong revenue expansion led by

[0000866374-19-000006:mdna:103]
several new customer programs and improving overall demand across its diverse market that has provided to overhead absorption benefits.

[0000866374-19-000006:mdna:104]
CEC segment margin increased 20 basis points to 2.6% for fiscal year 2019, from 2.4% during fiscal year 2018. The increase was driven by operational efficiencies and improved absorption of overhead as a result of the 8% increase in revenues. CEC segment margin decreased 30 basis points to 2.4% for fiscal year 2018, from 2.7% during fiscal year 2017. The decrease was driven by lower revenues which negatively impacted profitability with under-absorbed overhead and higher investment costs.

[0000866374-19-000006:mdna:105]
CTG segment margin increased 20 basis points to 1.8% for fiscal year 2019, from 1.6% during fiscal year 2018, as a result of lower losses from our NIKE operations in Mexico, which we exited in the third quarter of fiscal year 2019, partially offset by under-performance of certain accounts. CTG segment margin decreased 120 basis points to 1.6% for fiscal year 2018, from 2.8% during fiscal year 2017, primarily driven by negatively impacted profits due to a lower contribution, and continued losses from our NIKE operations in Mexico.

[0000866374-19-000006:mdna:106]
Restructuring charges

[0000866374-19-000006:mdna:107]
During fiscal year 2019, we took targeted actions to optimize our portfolio, most notably within CTG. We recognized restructuring charges of approximately $113 million during the fiscal year ended March 31, 2019, of which $73.2 million were non-cash charges primarily for asset impairments. A significant component of our charges were associated with  the wind down of our NIKE operations in Mexico in the third quarter of fiscal year 2019 where we recognized charges of $66 million primarily for non-cash asset impairments. In addition, we executed targeted head-count reductions at existing operating and design sites and corporate functions and exited certain immaterial businesses. Of these total charges, approximately $99 million was recognized as a component of cost of sales during the fiscal year ended March 31, 2019.

[0000866374-19-000006:mdna:108]
During fiscal year 2018, we initiated targeted restructuring activities, focused on optimizing our cost structure in lower growth areas and, more importantly, streamlining certain corporate and segment functions. The objective of the plan is to make Flex a faster, more responsive and agile company, better positioned to react to marketplace opportunities. We recognized $79 million of pre-tax cash charges, predominantly related to employee severance costs, and $12 million of pre-tax non-cash charges for asset impairment and other exit charges. We classified $67 million of these charges as a component of cost of sales and $24 million as a component of selling, general and administrative expenses during fiscal year 2018.

[0000866374-19-000006:mdna:109]
During fiscal year 2017, we initiated a restructuring plan to accelerate our ability to support more Sketch-to-Scale® efforts across the Company and reposition away from historical legacy programs and structures through rationalizing our current footprint at existing sites including certain corporate SG&A functions. We recognized $49 million of pre-tax restructuring charges predominantly for employee termination costs. We classified $39 million of these charges as a component of cost of sales and $10 million as a component of selling, general and administrative expenses.

[0000866374-19-000006:mdna:110]
Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-19-000006:mdna:111]
Selling, general and administrative expenses

[0000866374-19-000006:mdna:112]
Selling, general and administrative expenses ("SG&A") totaled $953 million or 3.6% of net sales, during fiscal year 2019, compared to $1.0 billion, or 4.0% of net sales, during fiscal year 2018, decreasing by $66 million or 7%, due to strong cost discipline focused on driving further productivity improvements and a refined cost structure benefiting from prior restructuring initiatives.

[0000866374-19-000006:mdna:113]
SG&A totaled $1.0 billion or 4.0% of net sales, during fiscal year 2018, compared to $937 million, or 3.9% of net sales, during fiscal year 2017, increasing by $82 million or 9%. This increase in SG&A was due to incremental costs associated with our continued expansion of our design and engineering resources and innovation system but also, due to the recognition of certain contingencies that are probable and estimable of payout. We also incurred incremental costs from our acquisitions in fiscal year 2018.

[0000866374-19-000006:mdna:114]
Intangible amortization

[0000866374-19-000006:mdna:115]
Amortization of intangible assets in fiscal year 2019 decreased by $5 million to $74 million from $79 million in fiscal year 2018, primarily as a result of certain intangible assets being fully amortized during fiscal year 2019.

[0000866374-19-000006:mdna:116]
Amortization of intangible assets in fiscal year 2018 decreased by $2 million to $79 million from $81 million in fiscal year 2017, primarily as a result of certain intangible assets being fully amortized during fiscal year 2018.

[0000866374-19-000006:mdna:117]
Other charges (income), net

[0000866374-19-000006:mdna:118]
During the last half of fiscal year 2019, we reassessed our strategy with respect to our entire investment portfolio. As a result, we recognized an aggregate net charge related to investment impairments and dispositions of approximately $193 million for the year ended March 31, 2019. The aggregate charge was primarily driven by write-downs of our investment positions in a non-core cost method investment and Elementum that were recognized in the third and fourth quarters of fiscal 2019, respectively. We also incurred other investment impairments that were individually immaterial as a result of our strategy shift and due to market valuation changes. Offsetting these charges was an $87 million non-cash gain from the deconsolidation of Bright Machines (formally known as AutoLab AI). Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details on the investment impairments and the deconsolidation of Bright Machines.

[0000866374-19-000006:mdna:119]
During fiscal year 2018, we recognized $152 million of gain from the deconsolidation of Elementum, and $39 million of gain from the sale of Wink. We also recorded $22 million related to the impairment of certain non-core investments during fiscal year 2018. No other components of other charges and income, net incurred during fiscal year 2018 were material.

[0000866374-19-000006:mdna:120]
The fiscal year ended March 31, 2017 includes a $7 million loss attributable to a non-strategic facility sold during the second quarter of fiscal year 2017. No other components of other charges and income, net incurred during fiscal year 2017 were material.

[0000866374-19-000006:mdna:121]
Interest and other, net

[0000866374-19-000006:mdna:122]
Interest and other, net was $183 million during fiscal year 2019, compared to $123 million during fiscal year 2018, increasing $60 million due to a $23 million increase of interest expense primarily from higher weighted average interest rates and a higher average borrowing level, as well as a $21 million increase in interest expense from our accounts receivable sales program, coupled with a $14 million decrease in foreign exchange gains as compared to the prior year.

[0000866374-19-000006:mdna:123]
Interest and other, net was $123 million during fiscal year 2018, compared to $100 million during fiscal year 2017. The increase in interest and other, net of $23 million was primarily due to a $15 million increase of interest expense from higher weighted average interest rates and a higher borrowing level.

[0000866374-19-000006:mdna:124]
Income taxes

[0000866374-19-000006:mdna:125]
We work to ensure that we accrue and pay the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which we operate. Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were 48.7%, 17.7% and 13.8% for the fiscal years 2019, 2018 and 2017, respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0000866374-19-000006:mdna:126]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  | 17.0 | % |
| Effect of tax rate differential | (74.1 | ) |  | (46.9 | ) |  | (23.0 | ) |
| Change in liability for uncertain tax positions | (8.4 | ) |  | 4.3 |  |  | 0.2 |  |
| Change in valuation allowance | 105.4 |  |  | 57.1 |  |  | 21.2 |  |
| Recognition of prior year taxes recoverable | 3.0 |  |  | (10.3 | ) |  | — |  |
| Expiration of tax attributes | 2.3 |  |  | — |  |  | — |  |
| Other | 3.5 |  |  | (3.5 | ) |  | (1.6 | ) |
| Provision for income taxes | 48.7 | % |  | 17.7 | % |  | 13.8 | % |

[0000866374-19-000006:mdna:127]
The variation in our effective tax rate each year is primarily a result of recognition of earnings in foreign jurisdictions which are taxed at rates lower than the Singapore statutory rate including the effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia, Costa Rica, India, Netherlands and Israel of $24 million, $22 million and $16 million in fiscal years 2019, 2018 and 2017, respectively. Additionally, our effective tax rate is impacted by changes in our liabilities for uncertain tax positions of ($15) million, $22 million, and $1 million and changes in our valuation allowances on deferred tax assets of $192 million, $279 million and $79 million in fiscal years 2019, 2018 and 2017, respectively. We generate most of our revenues and profits from operations outside of Singapore.

[0000866374-19-000006:mdna:128]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is

[0000866374-19-000006:mdna:129]
44

[0000866374-19-000006:mdna:130]
reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examinations, there could be a material adverse effect on our tax position, operating results, financial position and cash flows.

[0000866374-19-000006:mdna:131]
We provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized. During fiscal year 2019, we released valuation allowance of $3 million related to our operations in Poland as this amount was deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of this subsidiary. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances. Lastly, these valuation allowance reductions and eliminations were offset by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions.

[0000866374-19-000006:mdna:132]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-19-000006:mdna:133]
As of March 31, 2019, we had cash and cash equivalents of $1.7 billion and bank and other borrowings of $3.1 billion. We have a $1.75 billion revolving credit facility that is due to mature in June 2022, under which we had no borrowings outstanding as of March 31, 2019. We have also entered into two credit facilities in India during fiscal year 2019, (i) a $200 million term loan facility entered in July 2018, under which there were $79 million in borrowings outstanding as of the end of fiscal year 2019, and (ii) a $100 million uncommitted credit import advance facility in India, under which there were $91 million in advances outstanding as of March 31, 2019, which we anticipate repaying in fiscal year 2020. Refer to note 7 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details. As of March 31, 2019, we were in compliance with the covenants under all of our credit facilities and indentures. In April 2019, we entered into an additional $300 million term loan facility as further explained below.

[0000866374-19-000006:mdna:134]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2019, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2019). Repatriation could result in an additional income tax payment; however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-19-000006:mdna:135]
Fiscal Year 2019

[0000866374-19-000006:mdna:136]
Cash used in operating activities was $3.0 billion during fiscal year 2019. As further discussed below, cash collections on the deferred purchase price from our ABS sales program of $3.6 billion are now included in cash from investing activities instead of cash from operating activities in accordance with new accounting guidance. The total cash used in operating activities resulted primarily from $93 million of net income for the period plus $804 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, provision for doubtful accounts, and stock-based compensation, net of a gain of $87 million from the deconsolidation of Bright Machines which are included in the determination of net income. Depreciation expense was $433 million and relatively consistent with prior years. These additions were more than offset by a net change in our operating assets and liabilities of $3.9 billion. In accordance with the new accounting guidance adopted in fiscal 2019 (and further described in note 2 to the consolidated financial statements in Item 8 “Financial Statements and Supplementary Data”), cash collections on deferred purchase price from our ABS programs are now classified as cash flows from investing activities and no longer included in cash receipts related to accounts receivable. As a result, while accounts receivable only increased by approximately $95 million from fiscal year 2018 to fiscal year 2019, the impact to operating cash flows is an outflow of $3.6 billion further described below. Year over year increases in inventory and contract assets also added to the net change in our operating assets and liabilities reflected on our cash flow from operations.

[0000866374-19-000006:mdna:137]
We believe net working capital ("NWC"), and net working capital as a percentage of annualized sales are key metrics that measure our liquidity. NWC was previously calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories, less accounts payable. As part of the adoption of ASC 606, we expanded NWC, to include contract assets. We also included certain other current liabilities related to vendor financing programs, which are immaterial for the fiscal year, in the NWC calculation. NWC increased by $32 million to $1.7 billion as of March 31, 2019, from $1.6 billion as of March 31, 2018. This increase is primarily driven by (i) an increase of $216 million in contract assets upon adoption of ASC 606, (ii) a $58 million decrease in accounts receivable adding back reductions from non-cash accounts receivable sales, and (iii) a $77 million decrease in our inventory levels from March 31, 2018, offset by an approximately $25 million increase in accounts

[0000866374-19-000006:mdna:138]
45

[0000866374-19-000006:mdna:139]
payable. Our net working capital as a percentage of annualized net sales as of March 31, 2019 increased slightly to 6.7% as compared to 6.4% of annualized net sales as of March 31, 2018.

[0000866374-19-000006:mdna:140]
Cash provided by investing activities totaled $3.3 billion during fiscal year 2019. This was primarily driven by the impact of our adoption of ASU 2016-15 during the current fiscal year referred to above, which requires us to classify cash collections on deferred purchase price from our ABS programs that were previously classified as operating cash inflows as cash flows from investing activities. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data", for further description of the ASU. In addition, we received $267 million of proceeds, net of cash held, in connection with the divestitures of our China-based Multek operations as further described in note 17 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data". We also invested $631 million of net capital expenditures for property and equipment to expand capabilities and capacity in support of our expanding IEI and HRS businesses as well as building out capacity in India.

[0000866374-19-000006:mdna:141]
Cash used in financing activities was $30 million during fiscal year 2019. This was primarily the result of repurchases of ordinary shares in the amount of $189 million, offset by $170 million received from the drawdown of India Facilities as further described in note 7 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data".

[0000866374-19-000006:mdna:142]
Fiscal Year 2018

[0000866374-19-000006:mdna:143]
Cash provided by operating activities was $0.8 billion during fiscal year 2018. This resulted primarily from $429 million of net income for the period plus $478 million of non-cash charges such as depreciation, amortization and stock-based compensation, net of a gain from the deconsolidation of Elementum that are included in the determination of net income. Depreciation expense was $434 million of those non-cash charges. These were partially offset by a net change in our operating assets and liabilities of $153 million, driven primarily by a $354 million increase in inventories, an $88 million increase in other current and noncurrent assets, and a $347 million increase in accounts receivable, including the change in sales of accounts receivable, offset by a $623 million increase in accounts payable.

[0000866374-19-000006:mdna:144]
Cash used in investing activities totaled $0.9 billion during fiscal year 2018. This resulted primarily from $214 million paid for the acquisition of AGM Automotive ("AGM") for our HRS segment, net of cash acquired, and $55 million paid for a power module business for our CEC segment, net of cash acquired. Further, we invested $517 million of net capital expenditures for property and equipment to expand capabilities and capacity in support of our automotive, medical, footwear and IEI businesses. In addition, other investing activities includes $73 million of cash derecognized as of the date of the Elementum deconsolidation, and $46 million of payments for non-core investments, net of cash received.

[0000866374-19-000006:mdna:145]
Cash used in financing activities was $188 million during fiscal year 2018. This was primarily the result of repurchases of ordinary shares in the amount of $180 million, and the repayment of $55 million of debt, partially offset by $65 million received from third party investors in fiscal year 2018 in exchange for an additional noncontrolling equity interest in Elementum prior to the deconsolidation described above.

[0000866374-19-000006:mdna:146]
Fiscal Year 2017

[0000866374-19-000006:mdna:147]
Cash provided by operating activities was $1.1 billion during fiscal year 2017. This resulted primarily from $320 million of net income for the period plus $674 million of non-cash charges such as depreciation, amortization, other impairment charges, provision for doubtful accounts and stock-based compensation expense that are included in the determination of net income. Depreciation expense was $432 million of those non-cash charges. We generated $157 million in cash as a result of changes in our operating assets and liabilities, driven primarily by a $268 million increase in accounts payable, offset by a $184 million increase in accounts receivable, including the change in sales of accounts receivable.

[0000866374-19-000006:mdna:148]
Cash used in investing activities was $0.7 billion during fiscal year 2017. This resulted primarily from $490 million of net capital expenditures for property and equipment to expand capability and capacity in support of our automotive and medical businesses and further investments in both automation and expanding technologies to support our innovation services. We also paid $189 million for the acquisition of four businesses, net of cash acquired, including $162 million, net of $18 million of cash acquired related to the acquisition of manufacturing facilities from Bose. Further, $60 million was paid for a non-controlling interest in a joint venture with RIB Software AG as our partner. Offsetting this were proceeds from various other investing activities of $64 million, most notably the receipt of $38 million for the sale of two non-strategic businesses.

[0000866374-19-000006:mdna:149]
Cash used in financing activities was $242 million during fiscal year 2017. This was primarily the result of repurchases of ordinary shares in the amount $350 million, and $31 million of cash paid to a third-party banking institution for certain assets that were financed by the third-party banking institution on behalf of a customer, which is included in other financing activities. These cash outflows were partially offset by $171 million of net proceeds from bank borrowings and long-term debt, of which $130 million is the incremental amount borrowed extending the maturity date of one of our loan agreements from

[0000866374-19-000006:mdna:150]
August 30, 2018 to November 30, 2021, and $107 million is the amount of proceeds from the €100 million term loan, discussed further in note 7 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data".

[0000866374-19-000006:mdna:151]
Free Cash Flow

[0000866374-19-000006:mdna:152]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repurchase company shares, fund acquisitions, make investments, repay debt obligations, and for certain other activities. Upon adoption of ASU 2016-15 effective for fiscal year 2019, our free cash flow was redefined as cash from operations, plus cash collections of deferred purchase price, less net purchases of property and equipment to present cash flows on a consistent basis for investor transparency. We also exclude the reduction to operating cash flows related to certain vendor programs that is required for US GAAP presentation. Our free cash flow was $3 million, $236 million and $660 million for fiscal years 2019, 2018 and 2017, respectively. Free cash flow is not a measure of liquidity under generally accepted accounting principles in the United States, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-19-000006:mdna:153]
|  | Fiscal Year Ended March 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In millions) |
| Net cash used in operating activities | $ | (2,971 | ) |  | $ | (3,866 | ) |  | $ | (3,822 | ) |
| Cash collection of deferred purchase price and other | 3,605 |  |  | 4,620 |  |  | 4,971 |  |
| Purchases of property and equipment | (725 | ) |  | (562 | ) |  | (525 | ) |
| Proceeds from the disposition of property and equipment | 94 |  |  | 44 |  |  | 36 |  |
| Free cash flow | $ | 3 |  |  | $ | 236 |  |  | $ | 660 |  |

[0000866374-19-000006:mdna:154]
Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Cash balances are generated and held in many locations throughout the world. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months.

[0000866374-19-000006:mdna:155]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volumes of customer orders.

[0000866374-19-000006:mdna:156]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. At March 31, 2019 and 2018, the cumulative payments due to suppliers participating to the programs amounted to approximately $0.5 billion and $0.3 billion, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-19-000006:mdna:157]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements.

[0000866374-19-000006:mdna:158]
During fiscal years 2019, 2018 and 2017, we received approximately $6.8 billion, $8.0 billion and $7.6 billion, respectively from transfers of receivables under our ABS programs, and $2.7 billion, $1.5 billion and $1.3 billion, respectively from other sales of receivables. As of March 31, 2019, and 2018, the outstanding balance on receivables sold for cash was $1.3 billion, for both years, respectively, under all our accounts receivable sales programs, which are removed from accounts receivable balances in our consolidated balance sheets.

[0000866374-19-000006:mdna:159]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth.

[0000866374-19-000006:mdna:160]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-19-000006:mdna:161]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In June 2017, we entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $503 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced our $2.1 billion credit facility, which was due to mature in March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6 million from September 30, 2017 through June 30, 2020 and approximately $13 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. As of March 31, 2019, one of our $500 million Notes due February 2020 has been included in current liabilities on the consolidated balance sheet.

[0000866374-19-000006:mdna:162]
In April 2019, we entered into a JPY 33.5 billion term loan agreement (approximately $300 million) due April 2024, which was then swapped to U.S. dollars. The term loan will be used to fund general operations and refinance certain other outstanding debt. Borrowings under this term loan bear interest, at LIBOR plus the applicable margin of 1.21%

[0000866374-19-000006:mdna:163]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 16, 2018. During fiscal year 2019, we paid $189 million to repurchase shares (under the current and prior repurchase plans) at an average price of $10.66 per share. As of March 31, 2019, shares in the aggregate amount of $325 million were available to be repurchased under the current plan.

[0000866374-19-000006:mdna:164]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-19-000006:mdna:165]
Bank borrowings and long-term debt are as follows:

[0000866374-19-000006:mdna:166]
|  | As of March 31, |
|  | 2019 |  | 2018 |
|  | (In millions) |
| 4.625% Notes due February 2020 | $ | 500 |  |  | $ | 500 |  |
| Term Loan, including current portion, due in installments through November 2021 | 672 |  |  | 688 |  |
| Term Loan, including current portion, due in installments through June 2022 | 459 |  |  | 484 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| 4.750% Notes due June 2025 | 597 |  |  | 596 |  |
| India Facilities (1) | 170 |  |  | — |  |
| Other | 168 |  |  | 187 |  |
| Debt issuance costs | (11 | ) |  | (14 | ) |
|  | 3,055 |  |  | 2,941 |  |
| Current portion, net of debt issuance costs | (633 | ) |  | (43 | ) |
| Non-current portion | $ | 2,422 |  |  | $ | 2,898 |  |

[0000866374-19-000006:mdna:167]
| (1) | India Facilities as of March 31, 2019 include an approximately $91.4 million drawdown of short-term bank borrowings under a facility entered in February 2019 and a $78.8 million drawdown from the $200 million term loan facility entered in July 2018. |

[0000866374-19-000006:mdna:168]
Refer to the discussion in note 7 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details of our debt obligations.

[0000866374-19-000006:mdna:169]
We have purchase obligations that arise in the normal course of business, primarily consisting of binding purchase orders for inventory related items and capital expenditures. Additionally, we have leased certain of our property and equipment under capital lease commitments, and certain of our facilities and equipment under operating lease commitments.

[0000866374-19-000006:mdna:170]
Future payments due under our purchase obligations, debt including capital leases and related interest obligations and operating leases are as follows:

[0000866374-19-000006:mdna:171]
|  | Total |  | Less Than1 Year |  | 1 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In millions) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase obligations | $ | 3,299 |  |  | $ | 3,299 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Long-term debt and capital lease obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt | 3,065 |  |  | 634 |  |  | 913 |  |  | 918 |  |  | 600 |  |
| Capital leases | 45 |  |  | 19 |  |  | 19 |  |  | 7 |  |  | — |  |
| Interest on long-term debt obligations | 512 |  |  | 140 |  |  | 253 |  |  | 83 |  |  | 36 |  |
| Operating leases, net of subleases | 683 |  |  | 155 |  |  | 207 |  |  | 149 |  |  | 172 |  |
| Restructuring costs | 32 |  |  | 32 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 7,636 |  |  | $ | 4,279 |  |  | $ | 1,392 |  |  | $ | 1,157 |  |  | $ | 808 |  |

[0000866374-19-000006:mdna:172]
We have excluded $252 million of liabilities for unrecognized tax benefits from the contractual obligations table as we cannot make a reasonably reliable estimate of the periodic settlements with the respective taxing authorities. See note 13, "Income Taxes" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-19-000006:mdna:173]
Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-19-000006:mdna:174]
OFF-BALANCE SHEET ARRANGEMENTS

[0000866374-19-000006:mdna:175]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of March 31, 2019 and 2018, the fair value of our deferred purchase price receivable was approximately $293 million and $445 million, respectively. As of March 31, 2019 and 2018, the outstanding balance on receivables sold for cash was $1.3 billion for both periods, respectively, under all our accounts receivable sales programs, which were removed from accounts receivable balances in our consolidated balance sheets. For further information, see note 10 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data".

[0000866374-19-000006:mdna:176]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-19-000006:mdna:177]
Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for recent accounting pronouncements.

[0000866374-19-000006:mdna:178]
49
