# FLEX 8-K — 0001104659-19-025293 filed 2019-04-30

## item codes, every 8-K on or before 2019-05-21

- 2019-04-30 0001104659-19-025293 — 2.02, 9.01
- 2019-03-07 0001104659-19-013420 — 5.02
- 2019-02-11 0001104659-19-006978 — 5.02, 7.01, 9.01
- 2019-02-06 0001104659-19-005884 — 5.02
- 2019-01-30 0001104659-19-004485 — 2.02, 9.01
- 2019-01-18 0001104659-19-002495 — 5.02
- 2018-12-28 0001104659-18-075143 — 5.02
- 2018-12-11 0001104659-18-072382 — 5.02
- 2018-11-15 0001104659-18-068678 — 5.02, 9.01
- 2018-10-25 0001104659-18-063948 — 2.02, 9.01
- 2018-10-25 0001104659-18-063944 — 5.02, 9.01
- 2018-08-21 0001104659-18-053031 — 5.07, 8.01, 9.01
- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2019-05-21

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-19-025293:8k_2_02:1]
EX-99.1
2
a19-9009_1ex99d1.htm
EX-99.1

[0001104659-19-025293:8k_2_02:2]
Exhibit 99.1

[0001104659-19-025293:8k_2_02:3]
FLEX REPORTS FOURTH QUARTER AND FISCAL 2019 RESULTS

[0001104659-19-025293:8k_2_02:4]
San Jose, Calif., April 30, 2019 — Flex (NASDAQ: FLEX) today announced results for its fourth quarter and fiscal year ended March 31, 2019.

[0001104659-19-025293:8k_2_02:5]
Fourth Quarter Fiscal 2019 Highlights:

[0001104659-19-025293:8k_2_02:6]
·                  Net Sales: $6.2 billion, year over year revenue down 3 percent

[0001104659-19-025293:8k_2_02:7]
·                  GAAP Loss Before Income Taxes: $36 million

[0001104659-19-025293:8k_2_02:8]
·                  Adjusted Operating Income: $204 million

[0001104659-19-025293:8k_2_02:9]
·                  GAAP Net Loss: $64 million

[0001104659-19-025293:8k_2_02:10]
·                  Adjusted Net Income: $141 million

[0001104659-19-025293:8k_2_02:11]
·                  GAAP Net Loss Per Share: $0.12

[0001104659-19-025293:8k_2_02:12]
·                  Adjusted EPS: $0.27

[0001104659-19-025293:8k_2_02:13]
Fiscal Year 2019 Results of Operations:

[0001104659-19-025293:8k_2_02:14]
·                  Net Sales: $26.3 billion, year over year revenue up 3 percent

[0001104659-19-025293:8k_2_02:15]
·                  Communications and Enterprise Compute: year over year revenue growth of 8 percent

[0001104659-19-025293:8k_2_02:16]
·                  Industrial and Emerging Industries: year over year revenue growth of 4 percent

[0001104659-19-025293:8k_2_02:17]
·                  High Reliability Solutions: year over year revenue growth of 1 percent

[0001104659-19-025293:8k_2_02:18]
·                  Consumer Technologies Group: year over year flat

[0001104659-19-025293:8k_2_02:19]
·                  GAAP Income Before Income Taxes: $182 million

[0001104659-19-025293:8k_2_02:20]
·                  Adjusted Operating Income: $872 million

[0001104659-19-025293:8k_2_02:21]
·                  GAAP Net Income: $93 million

[0001104659-19-025293:8k_2_02:22]
·                  Adjusted Net Income: $603 million

[0001104659-19-025293:8k_2_02:23]
·                  GAAP EPS: $0.18

[0001104659-19-025293:8k_2_02:24]
·                  Adjusted EPS: $1.14

[0001104659-19-025293:8k_2_02:25]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedules II and V attached to this press release.

[0001104659-19-025293:8k_2_02:26]
“During the quarter, we expanded adjusted operating margins on slightly lower revenues, improved the quality of our sales mix, generated free cash flow, and continued to streamline our investment portfolio,” said Revathi Advaithi, CEO of Flex. “We achieved adjusted EPS within our target range. These results reflect our unrelenting commitment to customers and our intense focus on disciplined execution within our core businesses.”

[0001104659-19-025293:8k_2_02:27]
Advaithi continued, “During fiscal 2019, Flex grew revenue $865 million or 3% to $26.3 billion, increased adjusted operating income dollars by $86 million or 11% to $872 million, expanded adjusted operating margin to 3.3% from 3.1%, and had a 4.6% increase in adjusted EPS to $1.14 from $1.09.”

[0001104659-19-025293:8k_2_02:28]
“For fiscal 2020, we will be focused on driving disciplined sustainable execution around customer performance, growth and margins, along with managing our product mix and returning to historical free cash flow levels,” said Advaithi.

[0001104659-19-025293:8k_2_02:29]
Balance Sheet and Other Financial Highlights

[0001104659-19-025293:8k_2_02:30]
Flex ended the quarter with approximately $1.7 billion of cash on hand and total debt of approximately $3.1 billion.

[0001104659-19-025293:8k_2_02:31]
Cash flow from operations was negative $642 million for the three-month period ended March 31, 2019, primarily due to cash collections of $888 million for certain receivables sold under our ABS programs reported as investing activities. Adjusted cash flow from operations and free cash flow were $246 million and $120 million, respectively, for the three-month period ended March 31, 2019.

[0001104659-19-025293:8k_2_02:32]
The Company remains committed to return over 50% of annual free cash flow to its shareholders, as it repurchased ordinary shares for approximately $65 million and $189 million during the three-month and twelve-month periods ended March 31, 2019.

[0001104659-19-025293:8k_2_02:33]
First Quarter Fiscal 2020 Guidance

[0001104659-19-025293:8k_2_02:34]
·                  Revenue $6.1 billion to $6.5 billion

[0001104659-19-025293:8k_2_02:35]
·                  GAAP Income Before Income Taxes $110 million to $130 million

[0001104659-19-025293:8k_2_02:36]
·                  Adjusted Operating Income $195 million to $225 million

[0001104659-19-025293:8k_2_02:37]
·                  GAAP EPS $0.18 to $0.22 which includes stock-based compensation expense and intangible amortization

[0001104659-19-025293:8k_2_02:38]
·                  Adjusted EPS $0.25 to $0.29

[0001104659-19-025293:8k_2_02:39]
Looking Ahead

[0001104659-19-025293:8k_2_02:40]
The Company is not providing detailed fiscal 2020 guidance, but is comfortable with the fiscal 2020 consensus adjusted EPS range that spans from $1.20 to $1.30, and currently sits at $1.25. When adjusting for stock-based compensation expenses and intangible amortization, the Company’s GAAP EPS would be $0.28 below adjusted EPS.

[0001104659-19-025293:8k_2_02:41]
Webcast and Conference Call

[0001104659-19-025293:8k_2_02:42]
The Flex management team will host a conference call today at 2:00 PM (PT) / 5:00 PM (ET) to review fourth quarter and fiscal 2019 results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com. An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0001104659-19-025293:8k_2_02:43]
About Flex

[0001104659-19-025293:8k_2_02:44]
Flex Ltd. (Reg. No. 199002645H) is the Sketch-to-Scale® solutions provider that designs and builds intelligent products globally. With approximately 200,000 employees across 30 countries, Flex provides innovative design, engineering, manufacturing, real-time supply chain insight and logistics services to companies of all sizes across industries and markets. For more information, visit flex.com or follow us on Twitter @Flexintl.

[0001104659-19-025293:8k_2_02:45]
Contacts

[0001104659-19-025293:8k_2_02:46]
Kevin Kessel, CFA

[0001104659-19-025293:8k_2_02:47]
Vice President, Investor Relations

[0001104659-19-025293:8k_2_02:48]
(408) 576-7985

[0001104659-19-025293:8k_2_02:49]
kevin.kessel@flex.com

[0001104659-19-025293:8k_2_02:50]
Forward-Looking Statements

[0001104659-19-025293:8k_2_02:51]
Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our reports on Forms 10-K and 10-Q that we file with the U.S. Securities and Exchange Commission. The forward-looking statements in this press release are based on current expectations and Flex assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0001104659-19-025293:8k_2_02:52]
SCHEDULE I

[0001104659-19-025293:8k_2_02:53]
FLEX

[0001104659-19-025293:8k_2_02:54]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-19-025293:8k_2_02:55]
(In thousands, except per share amounts)

[0001104659-19-025293:8k_2_02:56]
|  |  | Three-Month Periods Ended |  |
|  |  | March 31, 2019 |  | March 31, 2018 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 6,226,124 |  | $ | 6,410,887 |  |
| Cost of sales |  | 5,836,336 |  | 6,002,726 |  |
| Restructuring charges |  | 9,493 |  | 58,864 |  |
| Gross profit |  | 380,295 |  | 349,297 |  |
| Selling, general and administrative expenses |  | 230,469 |  | 247,074 |  |
| Intangible amortization |  | 17,337 |  | 22,775 |  |
| Restructuring charges |  | 3,387 |  | 23,846 |  |
| Interest and other, net |  | 46,565 |  | 37,043 |  |
| Other charges, net |  | 118,929 |  | 2,748 |  |
| Income (loss) before income taxes |  | (36,392 | ) | 15,811 |  |
| Provision for income taxes |  | 27,960 |  | 35,406 |  |
| Net loss |  | $ | (64,352 | ) | $ | (19,595 | ) |
| Earnings (losses) per share: |  |  |  |  |  |
| GAAP |  | $ | (0.12 | ) | $ | (0.04 | ) |
| Non-GAAP |  | $ | 0.27 |  | $ | 0.28 |  |
| Basic shares used in computing per share amounts (2) |  | 520,379 |  | 527,809 |  |
| Diluted shares used in computing per share amounts (2) |  | 520,379 |  | 527,809 |  |

[0001104659-19-025293:8k_2_02:57]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release.

[0001104659-19-025293:8k_2_02:58]
FLEX

[0001104659-19-025293:8k_2_02:59]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-19-025293:8k_2_02:60]
(In thousands, except per share amounts)

[0001104659-19-025293:8k_2_02:61]
|  |  | Twelve-Month Periods Ended |  |
|  |  | March 31, 2019 |  | March 31, 2018 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 26,305,511 |  | $ | 25,441,131 |  |
| Cost of sales |  | 24,688,731 |  | 23,778,404 |  |
| Restructuring charges |  | 99,005 |  | 66,845 |  |
| Gross profit |  | 1,517,775 |  | 1,595,882 |  |
| Selling, general and administrative expenses |  | 953,077 |  | 1,019,399 |  |
| Intangible amortization |  | 74,396 |  | 78,640 |  |
| Restructuring charges |  | 14,308 |  | 23,846 |  |
| Interest and other, net |  | 183,454 |  | 122,823 |  |
| Other charges (income), net |  | 110,414 |  | (169,719 | ) |
| Income before income taxes |  | 182,126 |  | 520,893 |  |
| Provision for income taxes |  | 88,727 |  | 92,359 |  |
| Net income |  | $ | 93,399 |  | $ | 428,534 |  |
| Earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.18 |  | $ | 0.80 |  |
| Non-GAAP |  | $ | 1.14 |  | $ | 1.09 |  |
| Diluted shares used in computing per share amounts |  | 530,070 |  | 536,598 |  |

[0001104659-19-025293:8k_2_02:62]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures.

[0001104659-19-025293:8k_2_02:63]
SCHEDULE II

[0001104659-19-025293:8k_2_02:64]
FLEX

[0001104659-19-025293:8k_2_02:65]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-19-025293:8k_2_02:66]
(In thousands, except per share amounts)

[0001104659-19-025293:8k_2_02:67]
|  |  | Three-Month Periods Ended |  |
|  |  | March 31, 2019 |  | March 31, 2018 |  |
| GAAP gross profit |  | $ | 380,295 |  | $ | 349,297 |  |
| Stock-based compensation expense |  | 4,614 |  | 5,440 |  |
| Customer related asset impairments (3) |  | 4,841 |  | — |  |
| Restructuring charges (4) |  | 9,493 |  | 58,864 |  |
| Contingencies and other (5) |  | 8,714 |  | 15,679 |  |
| Non-GAAP gross profit |  | $ | 407,957 |  | $ | 429,280 |  |
| GAAP income (loss) before income taxes |  | $ | (36,392 | ) | $ | 15,811 |  |
| Intangible amortization |  | 17,337 |  | 22,775 |  |
| Stock-based compensation expense |  | 14,971 |  | 22,226 |  |
| Customer related asset impairments (3) |  | 19,576 |  | 1,498 |  |
| Restructuring charges (4) |  | 12,880 |  | 82,710 |  |
| Contingencies and other (5) |  | 10,281 |  | 15,679 |  |
| Other charges, net (6) |  | 118,929 |  | 2,748 |  |
| Interest and other, net |  | 46,565 |  | 37,043 |  |
| Non-GAAP operating income |  | $ | 204,147 |  | $ | 200,490 |  |
| GAAP provision for income taxes |  | $ | 27,960 |  | $ | 35,406 |  |
| Intangible amortization benefit |  | 2,186 |  | 2,605 |  |
| Valuation allowance and tax receivable, net (7) |  | — |  | (27,507 | ) |
| Other adjustments for taxes (7) |  | (12,433 | ) | 5,746 |  |
| Non-GAAP provision for income taxes |  | $ | 17,713 |  | $ | 16,250 |  |
| GAAP net loss |  | $ | (64,352 | ) | $ | (19,595 | ) |
| Intangible amortization |  | 17,337 |  | 22,775 |  |
| Stock-based compensation expense |  | 14,971 |  | 22,226 |  |
| Restructuring charges (4) |  | 12,880 |  | 82,710 |  |
| Customer related asset impairments (3) |  | 19,576 |  | 1,498 |  |
| Contingencies and other (5) |  | 10,281 |  | 15,679 |  |
| Other charges interest and other, net (6) |  | 120,293 |  | 5,083 |  |
| Adjustments for taxes (7) |  | 10,247 |  | 19,156 |  |
| Non-GAAP net income |  | $ | 141,233 |  | $ | 149,532 |  |
| Diluted earnings (losses) per share(2): |  |  |  |  |  |
| GAAP |  | $ | (0.12 | ) | $ | (0.04 | ) |
| Non-GAAP |  | $ | 0.27 |  | $ | 0.28 |  |

[0001104659-19-025293:8k_2_02:68]
See the accompanying notes on Schedule V attached to this press release.

[0001104659-19-025293:8k_2_02:69]
FLEX

[0001104659-19-025293:8k_2_02:70]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-19-025293:8k_2_02:71]
(In thousands, except per share amounts)

[0001104659-19-025293:8k_2_02:72]
|  |  | Twelve-Month Periods Ended |  |
|  |  | March 31, 2019 |  | March 31, 2018 |  |
| GAAP gross profit |  | $ | 1,517,775 |  | $ | 1,595,882 |  |
| Stock-based compensation expense |  | 19,554 |  | 19,102 |  |
| Customer related asset impairments (3) |  | 46,684 |  | — |  |
| Restructuring charges (4) |  | 99,005 |  | 66,845 |  |
| New revenue standard adoption impact (8) |  | 9,291 |  | — |  |
| Contingencies and other (5) |  | 15,123 |  | 26,631 |  |
| Non-GAAP gross profit |  | $ | 1,707,432 |  | $ | 1,708,460 |  |
| GAAP income before income taxes |  | $ | 182,126 |  | $ | 520,893 |  |
| Intangible amortization |  | 74,396 |  | 78,640 |  |
| Stock-based compensation expense |  | 76,032 |  | 85,244 |  |
| Customer related asset impairments (3) |  | 87,093 |  | 6,251 |  |
| Restructuring charges (4) |  | 113,313 |  | 90,691 |  |
| New revenue standard adoption impact (8) |  | 9,291 |  | — |  |
| Contingencies and other (5) |  | 35,644 |  | 51,631 |  |
| Other charges (income), net (6) |  | 110,414 |  | (169,719 | ) |
| Interest and other, net |  | 183,454 |  | 122,823 |  |
| Non-GAAP operating income |  | $ | 871,763 |  | $ | 786,454 |  |
| GAAP provision for income taxes |  | $ | 88,727 |  | $ | 92,359 |  |
| Intangible amortization benefit |  | 8,888 |  | 8,806 |  |
| Tax impact on tax receivable, net (7) |  | (4,799 | ) | (27,507 | ) |
| Other adjustments for taxes (7) |  | (8,067 | ) | 8,484 |  |
| Non-GAAP provision for income taxes |  | $ | 84,749 |  | $ | 82,142 |  |
| GAAP net income |  | $ | 93,399 |  | $ | 428,534 |  |
| Intangible amortization |  | 74,396 |  | 78,640 |  |
| Stock-based compensation expense |  | 76,032 |  | 85,244 |  |
| Restructuring charges (4) |  | 113,313 |  | 90,691 |  |
| Customer related asset impairments (3) |  | 87,093 |  | 6,251 |  |
| New revenue standard adoption impact (8) |  | 9,291 |  | — |  |
| Contingencies and other (5) |  | 35,644 |  | 51,631 |  |
| Other charges interest and other, net (6) |  | 109,980 |  | (166,357 | ) |
| Adjustments for taxes (7) |  | 3,978 |  | 10,217 |  |
| Non-GAAP net income |  | $ | 603,126 |  | $ | 584,851 |  |
| Diluted earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.18 |  | $ | 0.80 |  |
| Non-GAAP |  | $ | 1.14 |  | $ | 1.09 |  |

[0001104659-19-025293:8k_2_02:73]
See the accompanying notes on Schedule V attached to this press release.

[0001104659-19-025293:8k_2_02:74]
SCHEDULE III

[0001104659-19-025293:8k_2_02:75]
FLEX

[0001104659-19-025293:8k_2_02:76]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-19-025293:8k_2_02:77]
(In thousands)

[0001104659-19-025293:8k_2_02:78]
|  |  | As of March 31, 2019 |  | As of March 31, 2018 |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,696,625 |  | $ | 1,472,424 |  |
| Accounts receivable, net of allowance for doubtful accounts |  | 2,612,961 |  | 2,517,695 |  |
| Contract assets |  | 216,202 |  | — |  |
| Inventories |  | 3,722,854 |  | 3,799,829 |  |
| Other current assets |  | 854,790 |  | 1,380,466 |  |
| Total current assets |  | 9,103,432 |  | 9,170,414 |  |
| Property and equipment, net |  | 2,336,213 |  | 2,239,506 |  |
| Goodwill |  | 1,073,055 |  | 1,121,170 |  |
| Other intangible assets, net |  | 330,995 |  | 424,433 |  |
| Other assets |  | 655,672 |  | 760,332 |  |
| Total assets |  | $ | 13,499,367 |  | $ | 13,715,855 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 632,611 |  | $ | 43,011 |  |
| Accounts payable |  | 5,147,236 |  | 5,122,303 |  |
| Accrued payroll |  | 391,591 |  | 383,332 |  |
| Other current liabilities |  | 1,426,075 |  | 1,719,418 |  |
| Total current liabilities |  | 7,597,513 |  | 7,268,064 |  |
| Long-term debt, net of current portion |  | 2,421,904 |  | 2,897,631 |  |
| Other liabilities |  | 507,590 |  | 531,587 |  |
| Total shareholders’ equity |  | 2,972,360 |  | 3,018,573 |  |
| Total liabilities and shareholders’ equity |  | $ | 13,499,367 |  | $ | 13,715,855 |  |

[0001104659-19-025293:8k_2_02:79]
SCHEDULE IV

[0001104659-19-025293:8k_2_02:80]
FLEX

[0001104659-19-025293:8k_2_02:81]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-19-025293:8k_2_02:82]
(In thousands)

[0001104659-19-025293:8k_2_02:83]
|  |  | Twelve-Month Periods Ended |  |
|  |  | March 31, 2019 |  | March 31, 2018 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income |  | $ | 93,399 |  | $ | 428,534 |  |
| Depreciation, amortization and other impairment charges |  | 764,952 |  | 555,364 |  |
| Gain from deconsolidation of Bright Machines |  | (86,614 | ) | — |  |
| Gain from deconsolidation of Elementum |  | — |  | (151,574 | ) |
| Changes in working capital and other, net |  | (3,742,761 | ) | (4,698,659 | ) |
| Net cash used in operating activities |  | (2,971,024 | ) | (3,866,335 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property and equipment |  | (725,606 | ) | (561,997 | ) |
| Proceeds from the disposition of property and equipment |  | 94,219 |  | 44,780 |  |
| Acquisition of businesses, net of cash acquired |  | (12,796 | ) | (268,377 | ) |
| Proceeds from divestiture of businesses, net of cash held in divested businesses |  | 267,147 |  | (2,949 | ) |
| Cash collections of deferred purchase price |  | 3,585,901 |  | 4,619,933 |  |
| Other investing activities, net |  | 44,032 |  | (120,442 | ) |
| Net cash provided by investing activities |  | 3,252,897 |  | 3,710,948 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 3,199,460 |  | 1,366,000 |  |
| Repayments of bank borrowings and long-term debt |  | (3,059,828 | ) | (1,420,977 | ) |
| Payments for repurchases of ordinary shares |  | (188,979 | ) | (180,050 | ) |
| Net proceeds from issuance of ordinary shares |  | 245 |  | 2,774 |  |
| Other financing activities, net |  | 19,398 |  | 44,468 |  |
| Net cash used in financing activities |  | (29,704 | ) | (187,785 | ) |
| Effect of exchange rates on cash and cash equivalents |  | (27,968 | ) | (15,079 | ) |
| Net change in cash and cash equivalents |  | 224,201 |  | (358,251 | ) |
| Cash and cash equivalents, beginning of period |  | 1,472,424 |  | 1,830,675 |  |
| Cash and cash equivalents, end of period |  | $ | 1,696,625 |  | $ | 1,472,424 |  |

[0001104659-19-025293:8k_2_02:84]
SCHEDULE V

[0001104659-19-025293:8k_2_02:85]
FLEX AND SUBSIDIARIES

[0001104659-19-025293:8k_2_02:86]
NOTES TO SCHEDULES I AND II,

[0001104659-19-025293:8k_2_02:87]
(1)   To supplement Flex’s unaudited selected financial data presented consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges and gains, including non-GAAP gross profit, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude restructuring charges, stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP and may be different from non-GAAP measures used by other companies. We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-19-025293:8k_2_02:88]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-19-025293:8k_2_02:89]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-19-025293:8k_2_02:90]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-19-025293:8k_2_02:91]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-19-025293:8k_2_02:92]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-19-025293:8k_2_02:93]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-19-025293:8k_2_02:94]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions. The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types. In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-19-025293:8k_2_02:95]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions. The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-19-025293:8k_2_02:96]
Customer related asset impairments consist primarily of non-cash impairments of certain property and equipment to estimated fair value for customers we are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing significant financial difficulties. Certain inventory on hand was written down to net realizable value for these customers as well. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-19-025293:8k_2_02:97]
Contingencies and other consists primarily of costs not directly related to ongoing or core business results such as (1) costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors completed in June 2018, (2) certain charges related to Multek China that was divested in the second quarter of fiscal year 2019, (3) damages incurred from a typhoon that impacted a China facility in the second quarter of fiscal year 2018, and (4) certain legal matters for which loss contingencies are believed to be probable and estimable in the second quarter of fiscal year 2018. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-19-025293:8k_2_02:98]
Restructuring charges include severance for rationalization at existing sites and corporate SG&A functions as well as asset impairment, lease termination, and other charges relate to the closures and consolidations of certain operating sites. These costs may vary in size based on the Company’s initiatives and are not directly related to ongoing or core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-19-025293:8k_2_02:99]
Other charges (income), net consists of various other types of items that are not directly related to ongoing or core business results, such as the gain or loss from certain divestitures, gain from deconsolidation of certain entities, and impairment charges associated with certain non-core investments. We exclude these items because they are not related to the Company’s ongoing operating performance or do not affect core operations.  Excluding these amounts provides investors with a basis to compare Company performance against the performance of other companies without this variability.

[0001104659-19-025293:8k_2_02:100]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies or other non-recurring tax charges, when applicable.

[0001104659-19-025293:8k_2_02:101]
Adjustment for operating cash flows and free cash flow metrics due to a recently issued accounting standard.   In Q1 fiscal year 2019, the adoption of the new cash flow accounting standard resulted in a reclassification of cash flows related to the collection of certain receivables sold through the Company’s asset-backed receivable securitization program from operating activities to investing activities. The Company utilizes net cash flow from its various A/R sales programs as a low-cost source to fund operations and as a critical net working capital management tool.  Cash flow from operations is also a critical metric that investors use to evaluate a company’s earnings power. The Company views and manages all collections under the program similarly without bifurcation and accordingly provides the adjustment to reflect cash flows from operations inclusive of all collections of receivables sold through the programs.  The Company also excludes the reduction to operating cash flows related to certain vendor programs that is required for GAAP.

[0001104659-19-025293:8k_2_02:102]
In addition, we define our free cash flow metric to be adjusted operating cash flows described above less purchases of property and equipment net of proceeds from dispositions and present cash flows on a consistent basis for investor transparency.  We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash used in operating activities.” See below for the three and twelve-month periods ended March 31, 2019 reconciliation of GAAP to Non-GAAP measures:

[0001104659-19-025293:8k_2_02:103]
|  |  | Three-Month Period Ended |  | Twelve-Month Period Ended |  |
|  |  | March 31, 2019 |  | March 31, 2019 |  |
| Net cash used in operating activities |  | $ | (642,418 | ) | $ | (2,971,024 | ) |
| Cash collections of deferred purchase price and other |  | 888,048 |  | 3,605,299 |  |
| Adjusted net cash provided by operating activities |  | 245,630 |  | 634,275 |  |
| Net Capital Expenditures |  | (126,019 | ) | (631,387 | ) |
| Free Cash Flow |  | $ | 119,611 |  | $ | 2,888 |  |

[0001104659-19-025293:8k_2_02:104]
2) Basic shares were used in calculating diluted GAAP EPS for the quarter ended March 31, 2019 and March 31, 2018 due to the net loss recognized during the respective periods. Diluted shares for Q4 fiscal 2019 and fiscal 2018 were 522,460 thousand and 535,234 thousand which were used in calculating diluted non-GAAP EPS for the respective quarters.

[0001104659-19-025293:8k_2_02:105]
(3) Customer related asset impairments for the three-month and twelve-month periods ended March 31, 2019 and March 31, 2018 primarily relate to additional provisions for doubtful accounts receivable, inventory and impairment of property and equipment for certain customers experiencing significant financial difficulties and /or we are disengaging from.

[0001104659-19-025293:8k_2_02:106]
(4)  Throughout fiscal year 2018 and 2019, the Company incurred certain restructuring charges primarily related to severance for rationalization at certain existing operating sites and corporate functions.

[0001104659-19-025293:8k_2_02:107]
We completed the wind-down of our Nike operations in Mexico in Q3 fiscal year 2019 and recognized in total $66 million for the fiscal year. The charge primarily consisted of non-cash asset impairments.

[0001104659-19-025293:8k_2_02:108]
(5) Contingencies and other during fiscal year 2019 primarily consist of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, it also includes certain charges of the China based Multek operation that was divested in the second quarter of fiscal year 2019.

[0001104659-19-025293:8k_2_02:109]
During fiscal year 2018, the Company incurred charges in connection with certain legal matters where it believed losses were probable and estimable. The Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility. Additionally, certain asset impairments were recorded during fiscal year 2018.

[0001104659-19-025293:8k_2_02:110]
(6) As further described in the Company’s fiscal 2018 10K, the Company deconsolidated Elementum and recognized a non-cash gain of $151.6 million.  The Company also completed a sale of its Wink business in fiscal year 2018 and recognized a gain on sale of $38.7 million.  During the last half of fiscal 2019, the Company reassessed its strategy with respect to its entire investment portfolio.  As a result, the Company recognized an aggregate net charge related to investment impairments and dispositions of approximately $119 million and $193 million for the three- and twelve-month periods ended March 31, 2019, respectively.  The aggregate charge was primarily driven by write-downs of our investment positions in a non-core cost method investment and Elementum that were recognized in the third and fourth quarter of fiscal 2019, respectively.  The Company also incurred other investment impairments that were individually immaterial as a result of our strategy shift and due to market valuation changes.  We continue to assess our strategy with respect to the remaining investment portfolio and have not identified any additional impairment indicators with respect to these investments as of March 31, 2019.

[0001104659-19-025293:8k_2_02:111]
During the first quarter of fiscal year 2019, the Company transferred employees and equipment along with certain related software and IP, into Bright Machines which later received additional equity funding from third party investors and changed the composition of the Board of directors removing Flex’s control.  As such, we deconsolidated the entity and recognized a gain of approximately $87 million in other income, net for the year ended March 31, 2019.

[0001104659-19-025293:8k_2_02:112]
(7) During the fourth quarter of fiscal year 2019, the company incurred an expense of $15 million pertaining to initial implementation of advanced pricing arrangements finalized with the Mexican tax authorities during the fiscal year.

[0001104659-19-025293:8k_2_02:113]
The remaining balance is primarily related to adjustment for exchange rate fluctuation on income tax receivable position of an operating subsidiary recognized in a prior period and tax effects of the various adjustments that we incorporate into Non-GAAP measures.

[0001104659-19-025293:8k_2_02:114]
(8) During the first quarter of fiscal year 2019, the Company amended certain non-substantive terms of its existing contracts for its smaller customers. The amendments removed the consideration regarding over-time recognition under ASC 606. Accordingly, these customer contracts are now accounted for consistent with prior accounting and revenue is recognized upon shipment of product.
