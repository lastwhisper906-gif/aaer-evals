# FLEX 8-K — 0001104659-20-088503 filed 2020-07-30

## item codes, every 8-K on or before 2020-08-05

- 2020-07-30 0001104659-20-088503 — 2.02, 9.01
- 2020-06-09 0001104659-20-071371 — 5.02, 9.01
- 2020-06-03 0001104659-20-069435 — 5.02, 9.01
- 2020-05-12 0001104659-20-060179 — 1.01, 8.01, 9.01
- 2020-05-07 0001104659-20-058102 — 2.02, 8.01, 9.01
- 2020-04-20 0000866374-20-000005 — 5.02, 9.01 — amendment of 0001104659-20-044212
- 2020-04-07 0001104659-20-044212 — 5.02, 7.01, 9.01
- 2020-04-02 0001104659-20-042445 — 5.02, 8.01, 9.01
- 2020-03-09 0001104659-20-030489 — 7.01, 9.01
- 2020-01-30 0001104659-20-008704 — 2.02, 9.01
- 2019-11-07 0001104659-19-061133 — 8.01, 9.01
- 2019-10-24 0001104659-19-056135 — 2.02, 9.01
- 2019-08-23 0001410578-19-000891 — 3.03, 5.07, 8.01, 9.01
- 2019-08-08 0001410578-19-000722 — 8.01
- 2019-07-25 0001104659-19-041852 — 2.02, 2.05, 9.01
- 2019-06-10 0001410578-19-000371 — 5.02
- 2019-06-06 0001104659-19-034315 — 1.01, 8.01, 9.01
- 2019-05-31 0001104659-19-032835 — 8.01, 9.01
- 2019-05-30 0001104659-19-032818 — 8.01, 9.01
- 2019-05-30 0001104659-19-032593 — 8.01, 9.01
- 2019-04-30 0001104659-19-025293 — 2.02, 9.01
- 2019-03-07 0001104659-19-013420 — 5.02
- 2019-02-11 0001104659-19-006978 — 5.02, 7.01, 9.01
- 2019-02-06 0001104659-19-005884 — 5.02
- 2019-01-30 0001104659-19-004485 — 2.02, 9.01
- 2019-01-18 0001104659-19-002495 — 5.02
- 2018-12-28 0001104659-18-075143 — 5.02
- 2018-12-11 0001104659-18-072382 — 5.02
- 2018-11-15 0001104659-18-068678 — 5.02, 9.01
- 2018-10-25 0001104659-18-063948 — 2.02, 9.01
- 2018-10-25 0001104659-18-063944 — 5.02, 9.01
- 2018-08-21 0001104659-18-053031 — 5.07, 8.01, 9.01
- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2020-08-05

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-20-088503:8k_2_02:1]
EX-99.1
2
tm2025860d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-20-088503:8k_2_02:2]
Exhibit 99.1

[0001104659-20-088503:8k_2_02:3]
FLEX REPORTS FIRST QUARTER
FISCAL 2021 RESULTS

[0001104659-20-088503:8k_2_02:4]
San
Jose, Calif., July 30, 2020 – Flex (NASDAQ: FLEX) today announced results for its first quarter ended June 26,
2020.

[0001104659-20-088503:8k_2_02:5]
First Quarter Fiscal Year 2021 Highlights:

[0001104659-20-088503:8k_2_02:6]
|  | · | Net Sales: $5.2 billion |

[0001104659-20-088503:8k_2_02:7]
|  | · | GAAP Income Before Income Taxes: $67 million |

[0001104659-20-088503:8k_2_02:8]
|  | · | Adjusted Operating Income: $163 million |

[0001104659-20-088503:8k_2_02:9]
|  | · | GAAP Net Income: $52 million |

[0001104659-20-088503:8k_2_02:10]
|  | · | Adjusted Net Income: $116 million |

[0001104659-20-088503:8k_2_02:11]
|  | · | GAAP Earnings Per Share: $0.10 |

[0001104659-20-088503:8k_2_02:12]
|  | · | Adjusted Earnings Per Share: $0.23 |

[0001104659-20-088503:8k_2_02:13]
An explanation and reconciliation
of non-GAAP financial measures to GAAP financial measures is presented in Schedules II and V attached to this press release.

[0001104659-20-088503:8k_2_02:14]
“The Flex team delivered
strong results in Q1, overcoming the challenges presented by the COVID-19 pandemic. Our ability to deliver better than expected
results, even in this difficult environment, is a testament to our disciplined, world-class execution,” said Revathi Advaithi,
Chief Executive Officer of Flex. “We continue to make progress on our long-term strategy which has been validated during
this dynamic time through our ability to focus and scale to meet the needs of our diverse customer base.”

[0001104659-20-088503:8k_2_02:15]
“We made solid progress
on driving efficiencies and reducing costs during the quarter which better positions the company to effectively manage through
this environment,” added Chris Collier, Chief Financial Officer of Flex. “We anticipate a sequential recovery for all
of our end markets in the second quarter of fiscal 2021, however we expect overall revenue to be under pressure due to the uncertainty
of the crisis. We will continue to make sequential improvements in profitability and adjusted earnings per share.”

[0001104659-20-088503:8k_2_02:16]
Second Quarter Fiscal 2021 Guidance

[0001104659-20-088503:8k_2_02:17]
|  | · | Revenue: $5.4 billion to $5.7 billion |

[0001104659-20-088503:8k_2_02:18]
|  | · | GAAP Income Before Income Taxes: $35 million to $70 million |

[0001104659-20-088503:8k_2_02:19]
|  | · | Adjusted Operating Income: $180 million to $220 million |

[0001104659-20-088503:8k_2_02:20]
|  | · | GAAP EPS: $0.05 to $0.11 which includes $0.07 for stock-based compensation expense and net intangible amortization and $0.13 for estimated restructuring and other charges |

[0001104659-20-088503:8k_2_02:21]
|  | · | Adjusted EPS: $0.25 to $0.31 |

[0001104659-20-088503:8k_2_02:22]
Webcast and Conference Call

[0001104659-20-088503:8k_2_02:23]
The Flex management team will host a conference call today at 2:00 PM (PT) / 5:00 PM (ET), to review first quarter fiscal 2021
results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com.
An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0001104659-20-088503:8k_2_02:24]
About Flex

[0001104659-20-088503:8k_2_02:25]
Flex (Reg. No. 199002645H) is the manufacturing partner of choice
that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global
workforce across 30 countries and responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing
solutions to diverse industries and end markets.

[0001104659-20-088503:8k_2_02:26]
Contacts

[0001104659-20-088503:8k_2_02:27]
Investors & Analysts

[0001104659-20-088503:8k_2_02:28]
David Rubin

[0001104659-20-088503:8k_2_02:29]
Vice President, Investor Relations

[0001104659-20-088503:8k_2_02:30]
(408) 577-4632

[0001104659-20-088503:8k_2_02:31]
David.Rubin@flex.com

[0001104659-20-088503:8k_2_02:32]
Media & Press

[0001104659-20-088503:8k_2_02:33]
Silvia Gianelli

[0001104659-20-088503:8k_2_02:34]
Senior Director, Corporate Communications

[0001104659-20-088503:8k_2_02:35]
(408) 797-7130

[0001104659-20-088503:8k_2_02:36]
Silvia.Gianelli@flex.com

[0001104659-20-088503:8k_2_02:37]
Forward-Looking Statements

[0001104659-20-088503:8k_2_02:38]
Additional information
concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis
of Financial Condition and Results of Operations” in our annual report on Form 10-K for the fiscal year ended March 31, 2020.
The forward-looking statements in this press release are based on current expectations and Flex assumes no obligation to update
these forward-looking statements.

[0001104659-20-088503:8k_2_02:39]
SCHEDULE I

[0001104659-20-088503:8k_2_02:40]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
|  |  | Three-Month Periods Ended |  |
|  |  | June 26, 2020 |  |  | June 28, 2019 |  |
| GAAP: |  |  |  |  |  |  |
| Net sales |  | $ | 5,153,333 |  |  | $ | 6,175,939 |  |
| Cost of sales |  |  | 4,840,114 |  |  |  | 5,775,775 |  |
| Restructuring charges |  |  | 9,666 |  |  |  | 47,405 |  |
| Gross profit |  |  | 303,553 |  |  |  | 352,759 |  |
| Selling, general and administrative expenses |  |  | 190,721 |  |  |  | 209,624 |  |
| Intangible amortization |  |  | 15,176 |  |  |  | 17,082 |  |
| Restructuring charges |  |  | 16 |  |  |  | 8,787 |  |
| Interest and other, net |  |  | 30,257 |  |  |  | 53,157 |  |
| Income before income taxes |  |  | 67,383 |  |  |  | 64,109 |  |
| Provision for income taxes |  |  | 15,563 |  |  |  | 19,237 |  |
| Net income |  | $ | 51,820 |  |  | $ | 44,872 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.10 |  |  | $ | 0.09 |  |
| Non-GAAP |  | $ | 0.23 |  |  | $ | 0.27 |  |
| Diluted shares used in computing per share amounts |  |  | 501,632 |  |  |  | 517,550 |  |

[0001104659-20-088503:8k_2_02:41]
| See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. |  |  |  |  |  |  |  |  |

[0001104659-20-088503:8k_2_02:42]
SCHEDULE II

[0001104659-20-088503:8k_2_02:43]
| FLEX |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1) |
| (In thousands, except per share amounts) |
|  |  | Three-Month Periods Ended |  |
|  |  | June 26, 2020 |  |  | June 28, 2019 |  |
| GAAP gross profit |  | $ | 303,553 |  |  | $ | 352,759 |  |
| Stock-based compensation expense |  |  | 4,006 |  |  |  | 2,940 |  |
| Customer related asset impairments |  |  | 437 |  |  |  | 483 |  |
| Restructuring charges |  |  | 9,666 |  |  |  | 47,405 |  |
| Legal and other |  |  | 350 |  |  |  | - |  |
| Non-GAAP gross profit |  | $ | 318,012 |  |  | $ | 403,587 |  |
| GAAP income before income taxes |  | $ | 67,383 |  |  | $ | 64,109 |  |
| Intangible amortization |  |  | 15,176 |  |  |  | 17,082 |  |
| Stock-based compensation expense |  |  | 12,769 |  |  |  | 15,227 |  |
| Customer related asset impairments |  |  | (76 | ) |  |  | 483 |  |
| Restructuring charges |  |  | 9,682 |  |  |  | 56,192 |  |
| Legal and other |  |  | 27,681 |  |  |  | 1,610 |  |
| Interest and other, net |  |  | 30,257 |  |  |  | 53,157 |  |
| Non-GAAP operating income |  | $ | 162,872 |  |  | $ | 207,860 |  |
| GAAP provision for income taxes |  | $ | 15,563 |  |  | $ | 19,237 |  |
| Intangible amortization benefit |  |  | 2,049 |  |  |  | 2,156 |  |
| Other tax related adjustments |  |  | (1,212 | ) |  |  | 1,576 |  |
| Tax benefit on restructuring and other |  |  | 1,674 |  |  |  | 1,140 |  |
| Non-GAAP provision for income taxes |  | $ | 18,074 |  |  | $ | 24,109 |  |
| GAAP net income |  | $ | 51,820 |  |  | $ | 44,872 |  |
| Intangible amortization |  |  | 15,176 |  |  |  | 17,082 |  |
| Stock-based compensation expense |  |  | 12,769 |  |  |  | 15,227 |  |
| Restructuring charges |  |  | 9,682 |  |  |  | 56,192 |  |
| Customer related asset impairments |  |  | (76 | ) |  |  | 483 |  |
| Legal and other |  |  | 27,681 |  |  |  | 1,610 |  |
| Other charges, interest and other, net |  |  | 1,346 |  |  |  | 7,091 |  |
| Adjustments for taxes |  |  | (2,511 | ) |  |  | (4,872 | ) |
| Non-GAAP net income |  | $ | 115,887 |  |  | $ | 137,685 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.10 |  |  | $ | 0.09 |  |
| Non-GAAP |  | $ | 0.23 |  |  | $ | 0.27 |  |

[0001104659-20-088503:8k_2_02:44]
| See the accompanying notes on Schedule V attached to this press release. |  |  |  |  |  |  |  |  |

[0001104659-20-088503:8k_2_02:45]
SCHEDULE III

[0001104659-20-088503:8k_2_02:46]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
|  |  | As of June 26, 2020 |  |  | As of March 31, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,935,081 |  |  | $ | 1,922,686 |  |
| Accounts receivable, net of allowance for doubtful accounts |  |  | 3,280,837 |  |  |  | 2,435,982 |  |
| Contract assets |  |  | 306,198 |  |  |  | 282,444 |  |
| Inventories |  |  | 3,483,475 |  |  |  | 3,785,073 |  |
| Other current assets |  |  | 556,786 |  |  |  | 660,085 |  |
| Total current assets |  |  | 9,562,377 |  |  |  | 9,086,270 |  |
| Property and equipment, net |  |  | 2,162,715 |  |  |  | 2,215,991 |  |
| Operating lease right-of-use assets, net |  |  | 611,047 |  |  |  | 605,070 |  |
| Goodwill |  |  | 1,074,604 |  |  |  | 1,064,553 |  |
| Other intangible assets, net |  |  | 250,455 |  |  |  | 262,418 |  |
| Other assets |  |  | 471,870 |  |  |  | 455,315 |  |
| Total assets |  | $ | 14,133,068 |  |  | $ | 13,689,617 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 162,287 |  |  | $ | 149,130 |  |
| Accounts payable |  |  | 4,595,409 |  |  |  | 5,108,251 |  |
| Accrued payroll |  |  | 390,544 |  |  |  | 363,644 |  |
| Other current liabilities |  |  | 1,647,011 |  |  |  | 1,590,060 |  |
| Total current liabilities |  |  | 6,795,251 |  |  |  | 7,211,085 |  |
| Long-term debt, net of current portion |  |  | 3,423,162 |  |  |  | 2,689,109 |  |
| Operating lease liabilities, non-current |  |  | 539,441 |  |  |  | 528,967 |  |
| Other liabilities |  |  | 435,609 |  |  |  | 429,303 |  |
| Total shareholders' equity |  |  | 2,939,605 |  |  |  | 2,831,153 |  |
| Total liabilities and shareholders' equity |  | $ | 14,133,068 |  |  | $ | 13,689,617 |  |

[0001104659-20-088503:8k_2_02:47]
SCHEDULE IV

[0001104659-20-088503:8k_2_02:48]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In thousands) |
|  |  | Three-Month Periods Ended |  |
|  |  | June 26, 2020 |  |  | June 28, 2019 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 51,820 |  |  | $ | 44,872 |  |
| Depreciation, amortization and other impairment charges |  |  | 156,215 |  |  |  | 190,163 |  |
| Changes in working capital and other, net |  |  | (837,425 | ) |  |  | (891,901 | ) |
| Net cash used in operating activities |  |  | (629,390 | ) |  |  | (656,866 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property and equipment |  |  | (110,259 | ) |  |  | (162,115 | ) |
| Proceeds from the disposition of property and equipment |  |  | 7,853 |  |  |  | 38,901 |  |
| Cash collections of deferred purchase price |  |  | — |  |  |  | 899,260 |  |
| Other investing activities, net |  |  | 2,027 |  |  |  | (920 | ) |
| Net cash (used in) provided by investing activities |  |  | (100,379 | ) |  |  | 775,126 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  |  | 1,247,835 |  |  |  | 771,533 |  |
| Repayments of bank borrowings and long-term debt |  |  | (510,554 | ) |  |  | (601,240 | ) |
| Payments for repurchases of ordinary shares |  |  | — |  |  |  | (51,999 | ) |
| Other financing activities, net |  |  | 3,513 |  |  |  | (11,979 | ) |
| Net cash provided by financing activities |  |  | 740,794 |  |  |  | 106,315 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | 1,370 |  |  |  | (749 | ) |
| Net change in cash and cash equivalents |  |  | 12,395 |  |  |  | 223,826 |  |
| Cash and cash equivalents, beginning of period |  |  | 1,922,686 |  |  |  | 1,696,625 |  |
| Cash and cash equivalents, end of period |  | $ | 1,935,081 |  |  | $ | 1,920,451 |  |

[0001104659-20-088503:8k_2_02:49]
SCHEDULE V

[0001104659-20-088503:8k_2_02:50]
FLEX AND SUBSIDIARIES

[0001104659-20-088503:8k_2_02:51]
NOTES TO SCHEDULES I,
II

[0001104659-20-088503:8k_2_02:52]
|  | (1) | To supplement Flex’s unaudited selected financial data presented consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges and gains, including non-GAAP gross profit, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share. These supplemental measures exclude restructuring charges, customer-related asset impairments, stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP and may be different from non-GAAP measures used by other companies. We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures. The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures. We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance. |

[0001104659-20-088503:8k_2_02:53]
In calculating non-GAAP
financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance
on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance.
We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans,
for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s
incentive compensation is determined using certain non-GAAP measures. Also, when evaluating potential acquisitions, we exclude
certain of the items described below from consideration of the target’s performance and valuation. Since we find these measures
to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to
seeing GAAP results. We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials,
provide useful information to investors by offering:

[0001104659-20-088503:8k_2_02:54]
|  | · | the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results; |
|  | · | the ability to better identify trends in the Company’s underlying business and perform related trend analyses; |
|  | · | a better understanding of how management plans and measures the Company’s underlying business; and |
|  | · | an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures. |

[0001104659-20-088503:8k_2_02:55]
The following are explanations
of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual
items in the reconciliations of these non-GAAP financial measures:

[0001104659-20-088503:8k_2_02:56]
Stock-based
compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted
share unit awards granted to employees and assumed in business acquisitions. The Company believes that the exclusion of these charges
provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies,
subjective assumptions and the variety of award types. In addition, the Company believes it is useful to investors to understand
the specific impact stock-based compensation expense has on its operating results.

[0001104659-20-088503:8k_2_02:57]
Intangible
amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude
of acquisitions. The Company considers its operating results without these charges when evaluating its ongoing performance and
forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures. The Company believes
that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons
to the performance of its competitors.

[0001104659-20-088503:8k_2_02:58]
Customer
related asset impairments may consist of non-cash impairments of property and equipment to estimated fair value for
customers we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable
for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down
to net realizable value. These costs are excluded by the Company’s management in assessing current operating performance
and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-20-088503:8k_2_02:59]
Restructuring
charges include severance for rationalization at existing sites and corporate SG&A functions as well as asset impairment,
and other charges related to the closures and consolidations of certain operating sites and targeted activities to restructure
the business. These costs may vary in size based on the Company’s initiatives and are not directly related to ongoing or
core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management
in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its
non-GAAP measures.

[0001104659-20-088503:8k_2_02:60]
In order to support the Company’s
strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower
than anticipated, the Company has identified and is engaging in certain structural and portfolio changes. These restructuring actions
will eliminate non-core activities primarily within the Company’s corporate function, align the Company’s cost structure
with its reorganizing and optimizing of its operations model along its two reporting segments, and further sharpen its focus to
winning business in end markets where it has competitive advantages and deep domain expertise. During the three-month period ended
June 26, 2020, the Company recognized approximately $10 million of restructuring charges, most of which related to employee
severance.

[0001104659-20-088503:8k_2_02:61]
During the first quarter of fiscal
year 2020 in connection with geopolitical developments and uncertainties at the time, primarily impacting one customer in China,
the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its
strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated
targeted activities to restructure its business to further reduce and streamline its cost structure. During the three-month period
ended June 28, 2019, the Company recognized $56 million of restructuring charges, comprised of approximately $31 million
of cash charges predominantly for employee severance, and $25 million of non-cash charges related to impairment of equipment
and inventory.

[0001104659-20-088503:8k_2_02:62]
Legal
and other consist primarily of costs not directly related to ongoing or core business results and may include various
loss contingencies that arise that could involve matters relating to commercial disputes, government regulatory and compliance,
intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global
basis. During the first quarter of fiscal 2021, the Company accrued for certain loss contingencies where losses are considered
probable and estimable. These costs are excluded by the Company’s management in assessing current operating performance and
forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-20-088503:8k_2_02:63]
Other
charges (income), interest and other, net consists of various other types of items that are not directly related to
ongoing or core business results, such as the gain or losses related certain divestitures, debt extinguishment costs and impairment
charges or gains associated with certain non-core investments. We exclude these items because they are not related to the Company’s
ongoing operating performance or do not affect core operations. Excluding these amounts provides investors with a basis to compare
company performance against the performance of other companies without this variability.

[0001104659-20-088503:8k_2_02:64]
Adjustment
for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order
to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax
contingencies or other non-recurring tax charges, when applicable.

[0001104659-20-088503:8k_2_02:65]
Adjustments for free
cash flow.

[0001104659-20-088503:8k_2_02:66]
Prior to fiscal 2021, the Company utilized net cash
flow from its various A/R sales programs as a low-cost financing source to fund operations and as a critical net working capital
management tool. The Company viewed and managed all collections under the programs similarly without bifurcation and accordingly
provided the adjustment to reflect adjusted free cash flow inclusive of all collections of receivables sold through the programs
described above as well as collections on the repurchased receivables as part of the ABS program amendment. In the first quarter
of fiscal year 2021, we proactively and strategically utilized the proceeds of our debt issuance during the quarter to reduce the
outstanding balance of our ABS programs. We reduced the balance on this short-term financing product by $655 million sequentially,
which has the accounting effect of reducing our cash flow from operations and is excluded from the calculation of adjusted free
cash flow.

[0001104659-20-088503:8k_2_02:67]
We define our adjusted free
cash flow metric to be operating cash flows plus the impacts described above less purchases of property and equipment net of proceeds
from dispositions and present cash flows on a consistent basis for investor transparency. We believe adjusted free cash flow is
an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay
debt obligations, make investments, fund acquisitions and for certain other activities. Since adjusted free cash flow includes
investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable
GAAP measure – “net cash provided by operating activities.” See below for the three-month periods ended June
26, 2020, and June 28, 2019 reconciliation of GAAP to Non-GAAP measures:

[0001104659-20-088503:8k_2_02:68]
|  |  | Three-Month Period Ended |  |  | Three-Month Period Ended |  |
|  |  | June 26, 2020 |  |  | June 28, 2019 |  |
| Net cash used in operating activities |  | $ | (629,390 | ) |  | $ | (656,866 | ) |
| Reduction in ABS levels |  |  | 654,769 |  |  |  | - |  |
| Cash collections of deferred purchase price and other |  |  | 3,460 |  |  |  | 893,735 |  |
| Net capital expenditures |  |  | (102,406 | ) |  |  | (123,214 | ) |
| Adjusted free cash flow |  | $ | (73,567 | ) |  | $ | 113,655 |  |
