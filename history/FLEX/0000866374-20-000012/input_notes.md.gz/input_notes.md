# FLEX notes — 0000866374-20-000012


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-20-000012:notes:1]
[same as prior period, unchanged from 0000866374-20-000003:notes:1]

[0000866374-20-000012:notes:2]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In the first quarter of fiscal year 2021, the Company made certain changes in its organizational structure as part of its strategy to further drive growth and productivity with two focused delivery models. As a result, beginning in the first quarter of fiscal year 2021, the Company reports its financial performance based on two operating and reportable segments:

[0000866374-20-000012:notes:3]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-20-000012:notes:4]
◦Consumer Devices, including mobile and high velocity consumer devices;

[0000866374-20-000012:notes:5]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

[0000866374-20-000012:notes:6]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure.

[0000866374-20-000012:notes:7]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-20-000012:notes:8]
◦Automotive, including autonomous, connectivity, electrification, and smart technologies;

[0000866374-20-000012:notes:9]
◦Health Solutions, including medical devices, medical equipment and drug delivery; and

[0000866374-20-000012:notes:10]
◦Industrial, including capital equipment, industrial devices, renewable and grid edge, and power systems.

[0000866374-20-000012:notes:11]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers).

[0000866374-20-000012:notes:12]
[same as prior period, unchanged from 0000866374-20-000003:notes:8]

[0000866374-20-000012:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2020 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month periods ended June 26, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021.

[0000866374-20-000012:notes:14]
The first quarters for fiscal years 2021 and 2020 ended on June 26, 2020, which is comprised of 87 days in the period, and June 28, 2019, which is comprised of 89 days in the period, respectively.

[0000866374-20-000012:notes:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

[0000866374-20-000012:notes:16]
The changes to the Company’s organizational structure noted above had no impact to the condensed consolidated financial statements. For comparability purposes, segment reporting for prior periods have been restated to conform to the current

[0000866374-20-000012:notes:17]
presentation. Refer to note 14, “Segments Reporting,” for additional information on the changes in operating and reportable segments.

[0000866374-20-000012:notes:18]
Use of Estimates

[0000866374-20-000012:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments including highly liquid investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rate in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-20-000012:notes:20]
Recently Adopted Accounting Pronouncement

[0000866374-20-000012:notes:21]
In March 2020, the FASB issued ASU 2020-04 "Facilitation of the Effects of Reference Rate Reform on Financial Reporting", which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

[0000866374-20-000012:notes:22]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04,  ASU 2019-05, ASU 2019-10, and ASU 2019-11, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

[0000866374-20-000012:notes:23]
Recently Issued Accounting Pronouncements

[0000866374-20-000012:notes:24]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

[0000866374-20-000012:notes:25]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes", which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-20-000012:notes:26]
[same as prior period, unchanged from 0000866374-20-000003:notes:29]

[0000866374-20-000012:notes:27]
[same as prior period, unchanged from 0000866374-20-000003:notes:30]

[0000866374-20-000012:notes:28]
|  | As of June 26, 2020 |  | As of March 31, 2020 |
|  | (In thousands) |  |  |
| Raw materials | $ | 2,626,618 |  |  | $ | 2,835,582 |  |
| Work-in-progress | 336,469 |  |  | 373,513 |  |
| Finished goods | 520,388 |  |  | 575,978 |  |
|  | $ | 3,483,475 |  |  | $ | 3,785,073 |  |

[0000866374-20-000012:notes:29]
[same as prior period, unchanged from 0000866374-20-000003:notes:32]

[0000866374-20-000012:notes:30]
In accordance with accounting guidance on goodwill and other intangible assets, the Company evaluates goodwill for impairment at the reporting unit level annually, and in certain circumstances such as a change in reporting units or whenever there are indications that goodwill might be impaired. As described in note 1, the Company made certain changes in its organizational structure during the first quarter of fiscal year 2021 as part of its strategy to further drive growth and productivity through two separate delivery models that represent reportable segments, FAS and FRS. With these changes, the Company also revised its reporting units. Accordingly, the Company completed an interim test as of April 1, 2020. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require management to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider the Company's budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of the Company's goodwill.

[0000866374-20-000012:notes:31]
Based on the latest assessment of its goodwill as of April 1, 2020, the Company determined that no impairment existed as of the date of the impairment test, because the fair value of each one of its reporting units exceeds its respective carrying value. In addition, goodwill was reallocated among each of the Company's six reporting units based on each reporting unit’s relative fair value as of April 1, 2020. The following table summarizes the goodwill allocation as of April 1, 2020 and the activity during the three-month period ended June 26, 2020:

[0000866374-20-000012:notes:32]
|  | FAS |  |  |  |  |  | FRS |  |  |  |  |  |  |
|  | Communications, Enterprise and Cloud |  | Lifestyle |  | Consumer Devices |  | Automotive |  | Health Solutions |  | Industrial |  | Total |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Balance at April 1, 2020 | $ | 188,179 |  |  | $ | 130,705 |  |  | $ | 50,328 |  |  | $ | 174,123 |  |  | $ | 192,498 |  |  | $ | 328,720 |  |  | $ | 1,064,553 |  |
| Foreign currency translation adjustments | — |  |  | — |  |  | — |  |  | 9,231 |  |  | 820 |  |  | — |  |  | 10,051 |  |
| Balance at June 26, 2020 | $ | 188,179 |  |  | $ | 130,705 |  |  | $ | 50,328 |  |  | $ | 183,354 |  |  | $ | 193,318 |  |  | $ | 328,720 |  |  | $ | 1,074,604 |  |

[0000866374-20-000012:notes:33]
[same as prior period, unchanged from 0000866374-20-000003:notes:35]

[0000866374-20-000012:notes:34]
|  | As of June 26, 2020 |  |  |  |  |  | As of March 31, 2020 |  |  |  |  |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |  |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 276,087 |  |  | $ | (135,299) |  |  | $ | 140,788 |  |  | $ | 275,678 |  |  | $ | (128,155) |  |  | $ | 147,523 |  |
| Licenses and other intangibles | 248,966 |  |  | (139,299) |  |  | 109,667 |  |  | 244,917 |  |  | (130,022) |  |  | 114,895 |  |
| Total | $ | 525,053 |  |  | $ | (274,598) |  |  | $ | 250,455 |  |  | $ | 520,595 |  |  | $ | (258,177) |  |  | $ | 262,418 |  |

[0000866374-20-000012:notes:35]
[same as prior period, unchanged from 0000866374-20-000003:notes:38]

[0000866374-20-000012:notes:36]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2021 (1) |  | $ | 45,161 |  |
| 2022 |  | 52,100 |  |
| 2023 |  | 44,375 |  |
| 2024 |  | 42,820 |  |
| 2025 |  | 37,836 |  |
| Thereafter |  | 28,163 |  |
| Total amortization expense |  | $ | 250,455 |  |

[0000866374-20-000012:notes:37]
[same as prior period, unchanged from 0000866374-20-000003:notes:40]

[0000866374-20-000012:notes:38]
(1)Represents estimated amortization for the remaining fiscal nine-month period ending March 31, 2021.

[0000866374-20-000012:notes:39]
Other Current Liabilities
Other current liabilities include customer working capital advances of $325.7 million and $264.2 million, and customer-related accruals of $231.3 million and $195.1 million, as of June 26, 2020 and March 31, 2020, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Current operating lease liabilities were $116.1 million and $114.1 million as of June 26, 2020 and March 31, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-20-000012:notes:40]
[same as prior period, unchanged from 0000866374-20-000003:notes:59]

[0000866374-20-000012:notes:41]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-20-000012:notes:42]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion

[0000866374-20-000012:notes:43]
of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-20-000012:notes:44]
[same as prior period, unchanged from 0000866374-20-000003:notes:63]

[0000866374-20-000012:notes:45]
[same as prior period, unchanged from 0000866374-20-000003:notes:64]

[0000866374-20-000012:notes:46]
[same as prior period, unchanged from 0000866374-20-000003:notes:65]

[0000866374-20-000012:notes:47]
[same as prior period, unchanged from 0000866374-20-000003:notes:66]

[0000866374-20-000012:notes:48]
[same as prior period, unchanged from 0000866374-20-000003:notes:67]

[0000866374-20-000012:notes:49]
[same as prior period, unchanged from 0000866374-20-000003:notes:68]

[0000866374-20-000012:notes:50]
[same as prior period, unchanged from 0000866374-20-000003:notes:69]

[0000866374-20-000012:notes:51]
[same as prior period, unchanged from 0000866374-20-000003:notes:70]

[0000866374-20-000012:notes:52]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $362.1 million and $361.5 million as of June 26, 2020 and March 31, 2020, respectively.

[0000866374-20-000012:notes:53]
Disaggregation of Revenue
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 26, 2020 and June 28, 2019 (in thousands), respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-20-000012:notes:54]
[same as prior period, unchanged from 0000866374-20-000003:notes:78]

[0000866374-20-000012:notes:55]
[same as prior period, unchanged from 0000866374-20-000003:notes:79]

[0000866374-20-000012:notes:56]
|  | Three-Month Periods Ended |  |  |  |  |  |  |
|  | June 26, 2020 |  | June 28, 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Cost of sales | $ | 4,006 |  |  | $ | 2,940 |  |  |  |  |  |
| Selling, general and administrative expenses | 8,763 |  |  | 12,287 |  |  |  |  |  |
| Total share-based compensation expense | $ | 12,769 |  |  | $ | 15,227 |  |  |  |  |  |

[0000866374-20-000012:notes:57]
Total unrecognized compensation expense related to share options under all plans as well as the number of options outstanding and exercisable were immaterial as of June 26, 2020.

[0000866374-20-000012:notes:58]
During the three-month period ended June 26, 2020, the Company granted 10.2 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 8.8 million are plain-vanilla unvested RSU awards that vest over a period of three to four years, with no performance or market conditions, and with an average grant date price of $10.25 per award. Further, approximately 1.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $15.02 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 2.8 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-20-000012:notes:59]
As of June 26, 2020, approximately 22.5 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 4.5 million awards is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 9.0 million based on the achievement levels of the respective conditions. No shares are expected to vest in connection with the awards with market conditions granted in fiscal year 2018.

[0000866374-20-000012:notes:60]
As of June 26, 2020, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $203.3 million, and will be recognized over a weighted-average remaining vesting period of 2.4 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-20-000012:notes:61]
EARNINGS PER SHARE 
The following table reflects basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share attributable to the shareholders of Flex:

[0000866374-20-000012:notes:62]
|  | Three-Month Periods Ended |  |  |  |  |  |  |
|  | June 26, 2020 |  | June 28, 2019 |  |  |  |  |
|  | (In thousands, except per share amounts) |  |  |  |  |  |  |
| Basic earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 51,820 |  |  | $ | 44,872 |  |  |  |  |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 497,920 |  |  | 514,238 |  |  |  |  |  |
| Basic earnings per share | $ | 0.10 |  |  | $ | 0.09 |  |  |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 51,820 |  |  | $ | 44,872 |  |  |  |  |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 497,920 |  |  | 514,238 |  |  |  |  |  |
| Weighted-average ordinary share equivalents from stock options and RSU awards (1) (2) | 3,712 |  |  | 3,312 |  |  |  |  |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 501,632 |  |  | 517,550 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.10 |  |  | $ | 0.09 |  |  |  |  |  |

[0000866374-20-000012:notes:63]
(1)An immaterial number of options to purchase ordinary shares were excluded from the computation of diluted earnings per share during the three-month periods ended June 26, 2020 and June 28, 2019, respectively, due to their anti-dilutive impact on the weighted-average ordinary share equivalents.

[0000866374-20-000012:notes:64]
(2)RSU awards of 3.2 million and 6.1 million for the three-month periods ended June 26, 2020 and June 28, 2019 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-20-000012:notes:65]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 26, 2020 are as follows:

[0000866374-20-000012:notes:66]
|  | As of June 26, 2020 |  | As of March 31, 2020 |
|  | (In thousands) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | 433,406 |  |  | 433,406 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 313,596 |  |  | 310,115 |  |
| 4.750% Notes due June 2025 | 597,380 |  |  | 597,265 |  |
| 3.750% Notes due February 2026 | 423,411 |  |  | — |  |
| 4.875% Notes due June 2029 | 661,610 |  |  | 661,908 |  |
| 4.875% Notes due May 2030 | 323,595 |  |  | — |  |
| India Facilities | 138,238 |  |  | 138,238 |  |
| Other | 213,881 |  |  | 210,684 |  |
| Debt issuance costs | (19,668) |  |  | (13,377) |  |
|  | 3,585,449 |  |  | 2,838,239 |  |
| Current portion, net of debt issuance costs | (162,287) |  |  | (149,130) |  |
| Non-current portion | $ | 3,423,162 |  |  | $ | 2,689,109 |  |

[0000866374-20-000012:notes:67]
The weighted-average interest rate for the Company's long-term debt was 3.8% and 4.0% as of June 26, 2020 and March 31, 2020, respectively.

[0000866374-20-000012:notes:68]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 26, 2020 are as follows:

[0000866374-20-000012:notes:69]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2021 (1) |  | $ | 149,983 |  |
| 2022 |  | 212,255 |  |
| 2023 |  | 870,178 |  |
| 2024 |  | 53,109 |  |
| 2025 |  | 313,596 |  |
| Thereafter |  | 2,005,996 |  |
| Total |  | $ | 3,605,117 |  |

[0000866374-20-000012:notes:70]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2021.

[0000866374-20-000012:notes:71]
Notes due February 2026 and May 2030

[0000866374-20-000012:notes:72]
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026 (the "2026 Notes"), at 99.617% of face value and $325 million aggregate principal amount of 4.875% Notes due May 2020 (the "2030 Notes" and , together with the 2026 Notes, the " Notes"), at 99.562% of face value. The Company received in aggregate, proceeds of approximately $747 million, net of discount, from the issuance which were used for working capital and other general corporate purposes. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet approximately $7.1 million of costs in conjunction with the issuance of the Notes.

[0000866374-20-000012:notes:73]
Interest on the 2026 Notes and the 2030 Notes is payable semi-annually, commencing on August 1, 2020 and November 12, 2020, respectively. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.

[0000866374-20-000012:notes:74]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of 
default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2026 Notes or 2030 Notes may declare all of such series of Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of such series of Notes. As of June 26, 2020, the Company was in compliance with the covenants in the indenture governing the Notes.


## flex:InterestAndOtherNetTextBlock

[0000866374-20-000012:notes:75]
INTEREST AND OTHER, NET 
Interest and other, net for the three-month periods ended June 26, 2020 and June 28, 2019 are primarily composed of the following:

[0000866374-20-000012:notes:76]
|  | Three-Month Periods Ended |  |  |  |  |  |  |
|  | June 26, 2020 |  | June 28, 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Interest expenses on debt obligations (1) | $ | 33,374 |  |  | $ | 40,428 |  |  |  |  |  |
| ABS and AR sales programs related expenses | 4,832 |  |  | 12,981 |  |  |  |  |  |
| Interest income | (2,803) |  |  | (4,592) |  |  |  |  |  |

[0000866374-20-000012:notes:77]
(1)Interest expense on debt obligations for the three-month period ended June 28, 2019 include debt extinguishment costs of $4.1 million related to the partial repayments of the Notes due February 2020 and the Term Loan due November 2021. There were no debt extinguishment costs incurred during the first quarter of fiscal year 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-20-000012:notes:78]
[same as prior period, unchanged from 0000866374-20-000003:notes:111]

[0000866374-20-000012:notes:79]
[same as prior period, unchanged from 0000866374-20-000003:notes:112]

[0000866374-20-000012:notes:80]
As of June 26, 2020, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $9.5 billion as summarized below:

[0000866374-20-000012:notes:81]
|  |  | Foreign Currency Amount |  |  |  | Notional Contract Value in USD |  |  |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In thousands) |  |  |  |  |  |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| CNY |  | 1,405,500 |  |  | — |  |  | $ | 198,674 |  |  | $ | — |  |
| JPY |  | 33,525,000 |  |  | — |  |  | 300,000 |  |  | — |  |
| MXN |  | 4,416,000 |  |  | — |  |  | 195,603 |  |  | — |  |
| Other |  | N/A |  | N/A |  | 341,318 |  |  | 34,874 |  |
|  |  |  |  |  |  | 1,035,595 |  |  | 34,874 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 814,000 |  |  | — |  |  | 154,865 |  |
| CNY |  | 6,248,223 |  |  | 2,609,172 |  |  | 880,450 |  |  | 368,858 |  |
| EUR |  | 2,068,053 |  |  | 2,262,983 |  |  | 2,327,007 |  |  | 2,541,864 |  |
| GBP |  | 62,624 |  |  | 82,744 |  |  | 77,883 |  |  | 102,857 |  |
| HUF |  | 63,675,232 |  |  | 63,537,453 |  |  | 204,053 |  |  | 203,611 |  |
| ILS |  | 403,491 |  |  | 64,100 |  |  | 117,427 |  |  | 18,655 |  |
| INR |  | 5,500,000 |  |  | 6,495,390 |  |  | 72,630 |  |  | 85,722 |  |
| MXN |  | 3,885,763 |  |  | 2,446,456 |  |  | 172,117 |  |  | 108,364 |  |
| MYR |  | 1,163,860 |  |  | 934,940 |  |  | 272,222 |  |  | 218,679 |  |
| SEK |  | 652,526 |  |  | 734,086 |  |  | 68,873 |  |  | 78,835 |  |
| Other |  | N/A |  | N/A |  | 213,584 |  |  | 147,837 |  |
|  |  |  |  |  |  | 4,406,246 |  |  | 4,030,147 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 5,441,841 |  |  | $ | 4,065,021 |  |

[0000866374-20-000012:notes:82]
As of June 26, 2020, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of June 26, 2020 and March 31, 2020, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred losses were immaterial as of June 26, 2020, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-20-000012:notes:83]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of June 26, 2020. The changes in fair value of the USD JPY cross currency swap are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also impacts the same line.

[0000866374-20-000012:notes:84]
[same as prior period, unchanged from 0000866374-20-000003:notes:118]

[0000866374-20-000012:notes:85]
|  | Fair Values of Derivative Instruments |  |  |  |  |  |  |  |  |  |  |
|  | Asset Derivatives |  |  |  |  |  | Liability Derivatives |  |  |  |  |
|  |  |  | Fair Value |  |  |  |  |  | Fair Value |  |  |
|  | Balance SheetLocation |  | June 26,2020 |  | March 31,2020 |  | Balance SheetLocation |  | June 26,2020 |  | March 31,2020 |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 16,150 |  |  | $ | 7,257 |  |  | Other current liabilities |  | $ | 16,983 |  |  | $ | 46,645 |  |
| Foreign currency contracts | Other assets |  | $ | 15,314 |  |  | $ | 13,849 |  |  | Other liabilities |  | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 29,816 |  |  | $ | 83,086 |  |  | Other current liabilities |  | $ | 31,291 |  |  | $ | 102,709 |  |

[0000866374-20-000012:notes:86]
[same as prior period, unchanged from 0000866374-20-000003:notes:120]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-20-000012:notes:87]
[same as prior period, unchanged from 0000866374-20-000003:notes:121]

[0000866374-20-000012:notes:88]
|  | Three-Month Periods Ended |  |  |  |  |  |  |  |  |  |  |
|  | June 26, 2020 |  |  |  |  |  | June 28, 2019 |  |  |  |  |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |  |
| Beginning balance | $ | (81,663) |  |  | $ | (133,004) |  |  | $ | (214,667) |  |  | $ | (41,556) |  |  | $ | (109,607) |  |  | $ | (151,163) |  |
| Other comprehensive gain (loss) before reclassifications | 18,286 |  |  | 14,050 |  |  | 32,336 |  |  | (6,068) |  |  | 4,404 |  |  | (1,664) |  |
| Net losses reclassified from accumulated other comprehensive loss | 11,474 |  |  | — |  |  | 11,474 |  |  | 593 |  |  | — |  |  | 593 |  |
| Net current-period other comprehensive gain (loss) | 29,760 |  |  | 14,050 |  |  | 43,810 |  |  | (5,475) |  |  | 4,404 |  |  | (1,071) |  |
| Ending balance | $ | (51,903) |  |  | $ | (118,954) |  |  | $ | (170,857) |  |  | $ | (47,031) |  |  | $ | (105,203) |  |  | $ | (152,234) |  |

[0000866374-20-000012:notes:89]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended June 26, 2020 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-20-000012:notes:90]
[same as prior period, unchanged from 0000866374-20-000003:notes:125]

[0000866374-20-000012:notes:91]
[same as prior period, unchanged from 0000866374-20-000003:notes:126]

[0000866374-20-000012:notes:92]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” and together with the Global Program, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells the receivables to unaffiliated financial institutions. Under these programs, the entire purchase price of sold receivables are paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The fair value of the guarantee obligation was immaterial as of June 26, 2020 and March 31, 2020, respectively. The accounts receivable balances sold under the ABS Programs were removed from the condensed consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-20-000012:notes:93]
[same as prior period, unchanged from 0000866374-20-000003:notes:133]

[0000866374-20-000012:notes:94]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month periods ended June 26, 2020 and June 28, 2019 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-20-000012:notes:95]
As of June 26, 2020 and March 31, 2020, approximately $0.1 billion and $0.8 billion, respectively, of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds for the same amount.

[0000866374-20-000012:notes:96]
For the three-month periods ended June 26, 2020 and June 28, 2019, cash flows from sales of receivables under the ABS Programs consisted of approximately $2.7 billion and $1.6 billion, respectively, for transfers of receivables. The three-month period ended June 28, 2019 also included approximately $0.9 billion for collections on deferred purchase price receivables (effective November 2019, the Company no longer holds a deferred purchase price receivables balance). The Company's cash flows from transfers of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-20-000012:notes:97]
Trade Accounts Receivable Sale Programs
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.3 billion and $0.4 billion as of June 26, 2020 and March 31, 2020, respectively. For the three-month periods ended June 26, 2020 and June 28, 2019, total accounts receivable sold to certain third-party banking institutions was approximately $0.3 billion and $0.5 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received were included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-20-000012:notes:98]
[same as prior period, unchanged from 0000866374-20-000003:notes:138]

[0000866374-20-000012:notes:99]
[same as prior period, unchanged from 0000866374-20-000003:notes:139]

[0000866374-20-000012:notes:100]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager. The Company’s deferred compensation plan assets are included in other noncurrent assets on the condensed consolidated balance

[0000866374-20-000012:notes:101]
sheets and include investments in equity securities that are valued using active market prices. There were no investments  classified as level 1 in the fair value hierarchy as of June 26, 2020.

[0000866374-20-000012:notes:102]
[same as prior period, unchanged from 0000866374-20-000003:notes:141]

[0000866374-20-000012:notes:103]
[same as prior period, unchanged from 0000866374-20-000003:notes:142]

[0000866374-20-000012:notes:104]
The Company’s cash equivalents are comprised of bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-20-000012:notes:105]
[same as prior period, unchanged from 0000866374-20-000003:notes:144]

[0000866374-20-000012:notes:106]
[same as prior period, unchanged from 0000866374-20-000003:notes:145]

[0000866374-20-000012:notes:107]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of June 26, 2020 and March 31, 2020.

[0000866374-20-000012:notes:108]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended June 26, 2020 and June 28, 2019.

[0000866374-20-000012:notes:109]
[same as prior period, unchanged from 0000866374-20-000003:notes:149]

[0000866374-20-000012:notes:110]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of June 26, 2020 and March 31, 2020:

[0000866374-20-000012:notes:111]
|  | Fair Value Measurements as of June 26, 2020 |  |  |  |  |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,656,647 |  |  | $ | — |  |  | $ | 1,656,647 |  |
| Foreign currency contracts (Note 8) | — |  |  | 61,280 |  |  | — |  |  | 61,280 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 53,837 |  |  | — |  |  | 53,837 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (48,274) |  |  | $ | — |  |  | $ | (48,274) |  |
|  | Fair Value Measurements as of March 31, 2020 |  |  |  |  |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 403,657 |  |  | $ | — |  |  | $ | 403,657 |  |
| Foreign currency contracts (Note 8) | — |  |  | 104,192 |  |  | — |  |  | 104,192 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 49,086 |  |  | — |  |  | 49,086 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (149,354) |  |  | $ | — |  |  | $ | (149,354) |  |

[0000866374-20-000012:notes:112]
[same as prior period, unchanged from 0000866374-20-000003:notes:152]

[0000866374-20-000012:notes:113]
[same as prior period, unchanged from 0000866374-20-000003:notes:153]

[0000866374-20-000012:notes:114]
|  | As of June 26, 2020 |  |  |  | As of March 31, 2020 |  |  |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |  |  |  |  |  |  |  |  |
| Term Loan, including current portion, due in installments through June 2022 | 433,406 |  |  | 433,363 |  |  | 433,406 |  |  | 413,903 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 535,591 |  |  | 500,000 |  |  | 499,710 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 313,596 |  |  | 313,596 |  |  | 310,115 |  |  | 310,115 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,380 |  |  | 663,623 |  |  | 597,265 |  |  | 613,152 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 423,411 |  |  | 449,958 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 661,610 |  |  | 734,043 |  |  | 661,908 |  |  | 628,419 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 323,595 |  |  | 358,899 |  |  | — |  |  | — |  |  | Level 1 |
| Euro Term Loans | 212,678 |  |  | 212,678 |  |  | 207,646 |  |  | 207,646 |  |  | Level 2 |
| India Facilities | 138,238 |  |  | 138,238 |  |  | 138,238 |  |  | 138,238 |  |  | Level 2 |

[0000866374-20-000012:notes:115]
The Term Loan due June 2022, and the Notes due February 2023, June 2025, February 2026, June 2029 and May 2030 are valued based on broker trading prices in active markets.

[0000866374-20-000012:notes:116]
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans due September 2020, March 2021, and January 2022 based on the current market rate, and as of June 26, 2020, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-20-000012:notes:117]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-20-000012:notes:118]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-20-000012:notes:119]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-20-000012:notes:120]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions and have agreed in principle to an immaterial settlement.

[0000866374-20-000012:notes:121]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, Defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted Defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, Defendants filed a motion to dismiss the amended complaint. Defendants’ motion to dismiss is set for hearing on December 3, 2020. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-20-000012:notes:122]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible

[0000866374-20-000012:notes:123]
contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-20-000012:notes:124]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling 373.7 million Brazilian reals (approximately USD $71.1 million based on the exchange rate as of June 26, 2020). Four of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60.5 million Brazilian reals or USD $11.5 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Sao Paolo, Brazil on March 23, 2020; the value of that assessment is 33.9 million Brazilian reals (approximately USD $6.4 million). The Company believes there is no legal basis for any of these assessments and has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-20-000012:notes:125]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter which is ongoing. The Company expects to complete the investigation and report to OFAC by the end of the second quarter of fiscal year 2021, and it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-20-000012:notes:126]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-20-000012:notes:127]
A different foreign Tax Authority has issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for the periods fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80 million. The Company disagrees with the Tax Authority’s assertion and is actively contesting through administrative processes and will defend through judicial processes if necessary.

[0000866374-20-000012:notes:128]
As the final resolutions of the above items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-20-000012:notes:129]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-20-000012:notes:130]
SHARE REPURCHASES 
During the three-month period ended June 26, 2020, the Company made no repurchases of shares.

[0000866374-20-000012:notes:131]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 20, 2019. As of June 26, 2020, shares in the aggregate amount of $315.2 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-20-000012:notes:132]
SEGMENT REPORTING
In March 2020, the Company announced a change in organizational structure as part of its strategy to further drive efficiency and productivity with two focused delivery models. The Company’s chief operating decision maker ("CODM") changed from the CEO and certain direct staff who oversee operations of the business, to the CEO herself. As a result, beginning in fiscal year 2021, the Company now reports its financial performance based on two operating and reportable segments, Flex Agility Solutions (“FAS”) and Flex Reliability Solutions (“FRS”) and analyzes operating income as the measure of segment profitability.

[0000866374-20-000012:notes:133]
The FAS segment is optimized for speed to market at any volume based on a highly flexible supply and manufacturing system. The Company realigned the majority of the customers under the former CEC and CTG segments under the new FAS segment. Certain customers that were in the former Industrial segment that meet the above delivery model were also consolidated into the FAS segment. FAS is now comprised of the following end markets that represent reportable units:

[0000866374-20-000012:notes:134]
•Consumer Devices, including mobile and high velocity consumer devices;

[0000866374-20-000012:notes:135]
•Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

[0000866374-20-000012:notes:136]
•Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure.

[0000866374-20-000012:notes:137]
The FRS segment is optimized for longer product lifecycles requiring complex ramps at any volume with specialized production models and critical environments. The Company consolidated the majority of its customers under the former HRS and IEI segments into the new FRS segment. FRS is now comprised of the following end markets that represent reportable units:

[0000866374-20-000012:notes:138]
•Automotive, including autonomous, connectivity, electrification, and smart technologies;

[0000866374-20-000012:notes:139]
•Health Solutions, including medical devices, medical equipment and drug delivery; and

[0000866374-20-000012:notes:140]
•Industrial, including capital equipment, industrial devices, renewable and grid edge, and power systems.

[0000866374-20-000012:notes:141]
The determination of the FAS and FRS segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-20-000012:notes:142]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment charges, restructuring charges, legal and other, interest and other, net.

[0000866374-20-000012:notes:143]
Selected financial information by segment is in the table below. Fiscal year 2020 historical information has been recast to reflect the new operating and reportable segments in Item 2, "Management's Discussion and Analysis of Financial Condition and Results of Operations."

[0000866374-20-000012:notes:144]
|  | Three-Month Periods Ended |  |  |  |  |  |  |
|  | June 26, 2020 |  | June 28, 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 2,912,030 |  |  | $ | 3,908,176 |  |  |  |  |  |
| Flex Reliability Solutions | 2,241,303 |  |  | 2,267,763 |  |  |  |  |  |
|  | $ | 5,153,333 |  |  | $ | 6,175,939 |  |  |  |  |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 71,807 |  |  | $ | 108,958 |  |  |  |  |  |
| Flex Reliability Solutions | 114,737 |  |  | 129,994 |  |  |  |  |  |
| Corporate and Other | (23,672) |  |  | (31,092) |  |  |  |  |  |
| Total segment income | 162,872 |  |  | 207,860 |  |  |  |  |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 15,176 |  |  | 17,082 |  |  |  |  |  |
| Stock-based compensation | 12,769 |  |  | 15,227 |  |  |  |  |  |
| Customer related asset impairments | (76) |  |  | 483 |  |  |  |  |  |
| Restructuring charges (Note 15) | 9,682 |  |  | 56,192 |  |  |  |  |  |
| Legal and other (1) | 27,681 |  |  | 1,610 |  |  |  |  |  |
| Interest and other, net | 30,257 |  |  | 53,157 |  |  |  |  |  |
| Income before income taxes | $ | 67,383 |  |  | $ | 64,109 |  |  |  |  |  |

[0000866374-20-000012:notes:145]
(1)Legal and other during the three-month period ended June 26, 2020 consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis. During the first quarter of fiscal year 2021, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-20-000012:notes:146]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-20-000012:notes:147]
[same as prior period, unchanged from 0000866374-20-000003:notes:177]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-20-000012:notes:148]
RESTRUCTURING CHARGES
In order to support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, the Company has identified and is engaging in certain structural changes. These restructuring actions will eliminate non-core activities primarily within the Company’s corporate function, align the Company’s cost structure with its reorganizing and optimizing of its operations model along its two reporting segments, and further sharpen its focus to winning business in end markets where it has competitive advantages and deep domain expertise. During the three-month period ended June 26, 2020, the Company recognized approximately $9.7 million of restructuring charges, most of which related to employee severance.

[0000866374-20-000012:notes:149]
During the first quarter of fiscal year 2020 in connection with geopolitical developments and uncertainties at the time, primarily impacting one customer in China, the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and streamline its cost structure. During the three-month period ended June 28, 2019, the Company recognized $56.2 million of restructuring

[0000866374-20-000012:notes:150]
charges, comprised of approximately $30.8 million of cash charges predominantly for employee severance, and $25.4 million of non-cash charges related to impairment of equipment and inventory.

[0000866374-20-000012:notes:151]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of June 26, 2020 for charges incurred during the three-month period ended June 26, 2020:

[0000866374-20-000012:notes:152]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In thousands) |  |  |  |  |  |  |
| Balance as of March 31, 2020 | $ | 19,502 |  |  | $ | — |  |  | $ | 3,900 |  |  | $ | 23,402 |  |
| Provision for charges incurred during the three-month period ended June 26, 2020 | 6,538 |  |  | 3,508 |  |  | (364) |  |  | 9,682 |  |
| Cash payments for charges incurred in the fiscal year 2020 and prior | (11,187) |  |  | — |  |  | (197) |  |  | (11,384) |  |
| Cash payments for charges incurred during the three-month period ended June 26, 2020 | (1,273) |  |  | — |  |  | — |  |  | (1,273) |  |
| Non-cash charges incurred during the three-month period ended June 26, 2020 | — |  |  | (3,508) |  |  | 971 |  |  | (2,537) |  |
| Balance as of June 26, 2020 | 13,580 |  |  | — |  |  | 4,310 |  |  | 17,890 |  |
| Less: Current portion (classified as other current liabilities) | 13,580 |  |  | — |  |  | 4,310 |  |  | 17,890 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
