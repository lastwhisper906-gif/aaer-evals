# FLEX MD&A — 0000866374-20-000012


## mdna

[0000866374-20-000012:mdna:1]
[same as prior period, unchanged from 0000866374-20-000003:mdna:1]

[0000866374-20-000012:mdna:2]
[same as prior period, unchanged from 0000866374-20-000003:mdna:2]

[0000866374-20-000012:mdna:3]
[same as prior period, unchanged from 0000866374-20-000003:mdna:4]

[0000866374-20-000012:mdna:4]
We are the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In the first quarter of fiscal year 2021, the Company made certain changes in its organization structure as part of its strategy to further drive efficiency and productivity with two focused delivery models. As a result, the Company now reports its financial performance based on two reportable segments:

[0000866374-20-000012:mdna:5]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-20-000012:mdna:6]
◦Consumer Devices, including mobile and high velocity consumer devices;

[0000866374-20-000012:mdna:7]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

[0000866374-20-000012:mdna:8]
27

[0000866374-20-000012:mdna:9]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure.

[0000866374-20-000012:mdna:10]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-20-000012:mdna:11]
◦Automotive, including autonomous, connectivity, electrification, and smart technologies;

[0000866374-20-000012:mdna:12]
◦Health Solutions, including medical devices, medical equipment and drug delivery; and

[0000866374-20-000012:mdna:13]
◦Industrial, including capital equipment, industrial devices, renewable and grid edge, and power systems.

[0000866374-20-000012:mdna:14]
Refer to "note 14 - Segments Reporting,” to the condensed consolidated financial statements for additional information on the changes in operating and reportable segments.

[0000866374-20-000012:mdna:15]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-20-000012:mdna:16]
[same as prior period, unchanged from 0000866374-20-000003:mdna:11]

[0000866374-20-000012:mdna:17]
[same as prior period, unchanged from 0000866374-20-000003:mdna:12]

[0000866374-20-000012:mdna:18]
During the first quarter of fiscal year 2020 in connection with geopolitical developments and uncertainties at the time, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During the first quarter of fiscal year 2021, in order to support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, the Company has identified and is engaging in certain structural changes.

[0000866374-20-000012:mdna:19]
[same as prior period, unchanged from 0000866374-20-000003:mdna:15]

[0000866374-20-000012:mdna:20]
Update on the Impact of COVID-19 on our Business

[0000866374-20-000012:mdna:21]
As anticipated, our results were negatively impacted by COVID-19 disruptions to our factories, workforce, and suppliers. In the first quarter our COVID-19 related costs roughly doubled sequentially from the March quarter to over $100 million as the impact from the pandemic extended throughout the entire quarter. These costs are primarily comprised of enhanced health and safety protocols, incremental labor incentives, incremental supply chain costs and forced under-absorption of idle and underutilized labor and overhead costs. While we expect that these incremental costs will persist in our second quarter, we believe that these incremental costs will be significantly lower as demand improves.

[0000866374-20-000012:mdna:22]
The decrease in sales during the three-month period ended June 26, 2020 was also impacted by demand pressures and disruptions due to COVID-19. Other than our Health Solutions and Industrial businesses which performed well during the quarter, our other businesses were impacted by demand pressures and disruptions, most notably our automotive business where our automotive facilities were closed for nearly half of the quarter due to shutdowns by our automotive customers. While we anticipate revenue to improve across our end markets, we believe that our businesses tied to consumer spending, such as Lifestyle and Consumer Devices, will continue to be impacted if there is a prolonged demand slowdown. Refer to “Risk actors - The COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material,” as disclosed in Part I, “Item 1A. Risk Factors” in our Annual Report on Form 10-K for the year ended March 31, 2020.

[0000866374-20-000012:mdna:23]
28

[0000866374-20-000012:mdna:24]
As part of our continuous response to the outbreak, we have maintained salary cuts, furloughs and other programs to cut costs initiated at the beginning of our first quarter, including aggressively reducing discretionary corporate spend. Employees that have been operating on a work-from-home basis are continuing to do so. Further, to support our strategy and build a sustainable organization, and after considering that the economic recovery will be slower than anticipated, we have identified and are engaging in certain structural changes. See additional discussion regarding these restructuring actions below under "Restructuring charges".

[0000866374-20-000012:mdna:25]
We are continuously evaluating our capital structure in response to the current environment and expect that our current financial condition, including our liquidity sources are adequate to fund future commitments. See additional discussion in the Liquidity and Capital Resources section below.

[0000866374-20-000012:mdna:26]
Business Overview

[0000866374-20-000012:mdna:27]
We are one of the world's largest providers of global supply chain solutions, with revenues of $5.2 billion for the three-month period ended June 26, 2020 and $24.2 billion in fiscal year 2020. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-20-000012:mdna:28]
|  | Three-Month Periods Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales: | June 26, 2020 |  |  |  | June 28, 2019 |  |  |  |  |  |  |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 1,417 |  |  | 27 | % |  | $ | 1,450 |  |  | 23 | % |  |  |  |  |  |  |  |  |
| Mexico | 907 |  |  | 18 | % |  | 1,079 |  |  | 17 | % |  |  |  |  |  |  |  |  |
| U.S. | 869 |  |  | 17 | % |  | 804 |  |  | 13 | % |  |  |  |  |  |  |  |  |
| Brazil | 322 |  |  | 6 | % |  | 555 |  |  | 9 | % |  |  |  |  |  |  |  |  |
| Malaysia | 299 |  |  | 6 | % |  | 427 |  |  | 7 | % |  |  |  |  |  |  |  |  |
| Hungary | 250 |  |  | 5 | % |  | 321 |  |  | 5 | % |  |  |  |  |  |  |  |  |
| Israel | 187 |  |  | 4 | % |  | 184 |  |  | 3 | % |  |  |  |  |  |  |  |  |
| Other | 902 |  |  | 17 | % |  | 1,356 |  |  | 23 | % |  |  |  |  |  |  |  |  |
|  | $ | 5,153 |  |  |  |  | $ | 6,176 |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-20-000012:mdna:29]
|  | As of |  |  |  | As of |  |  |
| Property and equipment, net: | June 26, 2020 |  |  |  | March 31, 2020 |  |  |
|  | (In millions) |  |  |  |  |  |  |
| Mexico | $ | 543 |  |  | 25 | % |  | $ | 555 |  |  | 25 | % |
| China | 375 |  |  | 17 | % |  | 396 |  |  | 18 | % |
| U.S. | 375 |  |  | 17 | % |  | 378 |  |  | 17 | % |
| India | 199 |  |  | 9 | % |  | 207 |  |  | 9 | % |
| Malaysia | 106 |  |  | 5 | % |  | 111 |  |  | 5 | % |
| Hungary | 98 |  |  | 5 | % |  | 100 |  |  | 4 | % |
| Other | 467 |  |  | 22 | % |  | 469 |  |  | 22 | % |
|  | $ | 2,163 |  |  |  |  | $ | 2,216 |  |  |  |

[0000866374-20-000012:mdna:30]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we offer our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-20-000012:mdna:31]
[same as prior period, unchanged from 0000866374-20-000003:mdna:23]

[0000866374-20-000012:mdna:32]
•the impacts on our business due to component shortages or other supply chain related constraints including as a result of the COVID-19 pandemic;

[0000866374-20-000012:mdna:33]
•the effects of the COVID-19 pandemic on our business and results of operations;

[0000866374-20-000012:mdna:34]
•changes in the macro-economic environment and related changes in consumer demand;

[0000866374-20-000012:mdna:35]
•the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors;

[0000866374-20-000012:mdna:36]
•the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance;

[0000866374-20-000012:mdna:37]
•our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers;

[0000866374-20-000012:mdna:38]
•the effects that current credit and market conditions (including as a result of the COVID-19 pandemic) could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-20-000012:mdna:39]
•the effects on our business due to certain customers’ products having short product life cycles;

[0000866374-20-000012:mdna:40]
•our customers’ ability to cancel or delay orders or change production quantities;

[0000866374-20-000012:mdna:41]
•our customers’ decisions to choose internal manufacturing instead of outsourcing for their product requirements;

[0000866374-20-000012:mdna:42]
•integration of acquired businesses and facilities;

[0000866374-20-000012:mdna:43]
•increased labor costs due to adverse labor conditions in the markets we operate;

[0000866374-20-000012:mdna:44]
•changes in tax legislation; and

[0000866374-20-000012:mdna:45]
•changes in trade regulations and treaties.

[0000866374-20-000012:mdna:46]
We are also subject to other risks as outlined in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0000866374-20-000012:mdna:47]
[same as prior period, unchanged from 0000866374-20-000003:mdna:38]

[0000866374-20-000012:mdna:48]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from those estimates and assumptions.

[0000866374-20-000012:mdna:49]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0000866374-20-000012:mdna:50]
[same as prior period, unchanged from 0000866374-20-000003:mdna:46]

[0000866374-20-000012:mdna:51]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our 2020 Annual Report on Form 10-K. As previously disclosed, we made certain changes in our organization structure. As a result of these changes, we revised our reportable segments as further discussed in note 14 to the condensed consolidated financial statements. There was no change to our condensed consolidated financial statements. For comparability purposes, segment reporting for the prior period has been recast to conform to the current presentation.

[0000866374-20-000012:mdna:52]
30

[0000866374-20-000012:mdna:53]
|  | Three-Month Periods Ended |  |  |  |  |  |  |
|  | June 26, 2020 |  | June 28, 2019 |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of sales | 93.9 |  |  | 93.5 |  |  |  |  |  |
| Restructuring charges | 0.2 |  |  | 0.8 |  |  |  |  |  |
| Gross profit | 5.9 |  |  | 5.7 |  |  |  |  |  |
| Selling, general and administrative expenses | 3.7 |  |  | 3.4 |  |  |  |  |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  |  |  |  |
| Restructuring charges | 0.0 |  |  | 0.1 |  |  |  |  |  |
| Interest and other, net | 0.6 |  |  | 0.9 |  |  |  |  |  |
| Income before income taxes | 1.3 |  |  | 1.0 |  |  |  |  |  |
| Provision for income taxes | 0.3 |  |  | 0.3 |  |  |  |  |  |
| Net income | 1.0 | % |  | 0.7 | % |  |  |  |  |

[0000866374-20-000012:mdna:54]
[same as prior period, unchanged from 0000866374-20-000003:mdna:49]

[0000866374-20-000012:mdna:55]
[same as prior period, unchanged from 0000866374-20-000003:mdna:50]

[0000866374-20-000012:mdna:56]
|  | Three-Month Periods Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segments: | June 26, 2020 |  |  |  | June 28, 2019 |  |  |  |  |  |  |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 2,912 |  |  | 57 | % |  | $ | 3,908 |  |  | 63 | % |  |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 2,241 |  |  | 43 | % |  | $ | 2,268 |  |  | 37 | % |  |  |  |  |  |  |  |  |
|  | $ | 5,153 |  |  |  |  | $ | 6,176 |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-20-000012:mdna:57]
[same as prior period, unchanged from 0000866374-20-000003:mdna:18]

[0000866374-20-000012:mdna:58]
Net sales during the three-month period ended June 26, 2020 totaled $5.2 billion, representing a decrease of approximately $1.0 billion, or 17% from $6.2 billion during the three-month period ended June 28, 2019. The decrease in sales impacted both of our segments reflecting significant COVID-19 demand and production pressure. Our FAS segment decreased $996 million, driven by lower demand in all of the end markets we serve, and more specifically in our Consumer Devices business, further impacted by COVID-19 related supply chain constraints, coupled with our targeted disengagement of high volatility, short cycle businesses we launched in the prior year. Our FRS segment modestly decreased $27 million, primarily due to disruptions directly impacting our automotive business towards the end of fiscal year 2020 and extending throughout the first quarter of fiscal year 2021. That decline more than offset increases in sales in both of our Health Solution and Industrial businesses. Net sales decreased $566 million to $2.0 billion in Asia, $355 million to $2.1 billion in the Americas, and $102 million to $1.0 billion in Europe.

[0000866374-20-000012:mdna:59]
Our ten largest customers, during the three-month periods ended June 26, 2020 and June 28, 2019, accounted for approximately 39% and 42% of net sales, respectively. No customer accounted for more than 10% of net sales during the three-month periods ended June 26, 2020 or June 28, 2019.

[0000866374-20-000012:mdna:60]
[same as prior period, unchanged from 0000866374-20-000003:mdna:56]

[0000866374-20-000012:mdna:61]
[same as prior period, unchanged from 0000866374-20-000003:mdna:57]

[0000866374-20-000012:mdna:62]
Gross profit during the three-month period ended June 26, 2020 decreased $49 million to $304 million, or 5.9% of net sales, from $353 million, or 5.7% of net sales, during the three-month period ended June 28, 2019, driven by the lower sales referred

[0000866374-20-000012:mdna:63]
to above. Gross margin improved 20 basis points during the same period primarily resulting from lower restructuring costs for the three-month period ended June 26, 2020, compared to the prior year period.

[0000866374-20-000012:mdna:64]
[same as prior period, unchanged from 0000866374-20-000003:mdna:60]

[0000866374-20-000012:mdna:65]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment charges, restructuring charges, legal and other, interest and other, net. A portion of depreciation is allocated to the respective segment, together with other general corporate research and development and administrative expenses.

[0000866374-20-000012:mdna:66]
The following table sets forth segment income and margins (amounts may not sum due to rounding):

[0000866374-20-000012:mdna:67]
|  | Three-Month Periods Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | June 26, 2020 |  |  |  | June 28, 2019 |  |  |  |  |  |  |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 72 |  |  | 2.5 | % |  | $ | 109 |  |  | 2.8 | % |  |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 115 |  |  | 5.1 | % |  | 130 |  |  | 5.7 | % |  |  |  |  |  |  |  |  |
| Corporate and Other | (24) |  |  |  |  | (31) |  |  |  |  |  |  |  |  |  |  |  |
| Total segment income | 163 |  |  | 3.2 | % |  | 208 |  |  | 3.4 | % |  |  |  |  |  |  |  |  |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 15 |  |  |  |  | 17 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | 13 |  |  |  |  | 15 |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges (Note 15) | 10 |  |  |  |  | 56 |  |  |  |  |  |  |  |  |  |  |  |
| Legal and other (1) | 28 |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 30 |  |  |  |  | 53 |  |  |  |  |  |  |  |  |  |  |  |
| Income before income taxes | $ | 67 |  |  |  |  | $ | 64 |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-20-000012:mdna:68]
(1)Legal and other during the three-month period ended June 26, 2020 consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis. During the first quarter of fiscal year 2021, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-20-000012:mdna:69]
FAS segment margin decreased 30 basis points, to 2.5% for the three-month period ended June 26, 2020, from 2.8% for the three-month period ended June 28, 2019. The decrease in FAS segment margin during the period is primarily the result of elevated under-absorption specifically in our Consumer Devices end market.

[0000866374-20-000012:mdna:70]
FRS segment margin decreased 60 basis points, to 5.1% for the three-month period ended June 26, 2020, from 5.7% for the three-month period ended June 28, 2019. The decrease in FRS segment margin is primarily the results of plant shutdowns that affected the entire automotive ecosystem across all regions, coupled with under-absorption and efficiency impacts.

[0000866374-20-000012:mdna:71]
As a result of the organizational structure changes, as previously disclosed, we revised our reportable segments as further discussed in note 14 to the condensed consolidated financial statements. Selected unaudited quarterly financial information for fiscal year 2020 in the table below have been recast reflecting the new reportable segments.

[0000866374-20-000012:mdna:72]
|  | Three-Month Periods Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Fiscal Year Ended |  |  |
|  | June 28, 2019 |  |  |  | September 27, 2019 |  |  |  | December 31, 2019 |  |  |  | March 31, 2020 |  |  |  | March 31, 2020 |  |  |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,908,176 |  |  | 63 | % |  | $ | 3,582,900 |  |  | 59 | % |  | $ | 3,631,082 |  |  | 56 | % |  | $ | 2,930,956 |  |  | 53 | % |  | $ | 14,053,114 |  |  | 58 | % |
| Flex Reliability Solutions | 2,267,763 |  |  | 37 | % |  | 2,505,154 |  |  | 41 | % |  | 2,830,305 |  |  | 44 | % |  | 2,553,534 |  |  | 47 | % |  | 10,156,756 |  |  | 42 | % |
|  | $ | 6,175,939 |  |  |  |  | $ | 6,088,054 |  |  |  |  | $ | 6,461,387 |  |  |  |  | $ | 5,484,490 |  |  |  |  | $ | 24,209,870 |  |  |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 108,958 |  |  | 2.8 | % |  | $ | 94,194 |  |  | 2.6 | % |  | $ | 98,022 |  |  | 2.7 | % |  | $ | 67,856 |  |  | 2.3 | % |  | $ | 369,030 |  |  | 2.6 | % |
| Flex Reliability Solutions | 129,994 |  |  | 5.7 | % |  | 159,186 |  |  | 6.4 | % |  | 186,249 |  |  | 6.6 | % |  | 167,120 |  |  | 6.5 | % |  | 642,549 |  |  | 6.3 | % |
| Corporate and Other | (31,092) |  |  |  |  | (26,238) |  |  |  |  | (28,233) |  |  |  |  | (27,985) |  |  |  |  | (113,548) |  |  |  |
| Total segment income | 207,860 |  |  | 3.4 | % |  | 227,142 |  |  | 3.7 | % |  | 256,038 |  |  | 4.0 | % |  | 206,991 |  |  | 3.8 | % |  | 898,031 |  |  | 3.7 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 17,082 |  |  |  |  | 16,223 |  |  |  |  | 15,598 |  |  |  |  | 15,203 |  |  |  |  | 64,106 |  |  |  |
| Stock-based compensation | 15,227 |  |  |  |  | 18,890 |  |  |  |  | 19,215 |  |  |  |  | 18,214 |  |  |  |  | 71,546 |  |  |  |
| Customer related asset impairments | 483 |  |  |  |  | 90,973 |  |  |  |  | 3,754 |  |  |  |  | 10,730 |  |  |  |  | 105,940 |  |  |  |
| Restructuring charges | 56,192 |  |  |  |  | 128,315 |  |  |  |  | 14,616 |  |  |  |  | 17,284 |  |  |  |  | 216,407 |  |  |  |
| Legal and other | 1,610 |  |  |  |  | 19,538 |  |  |  |  | 6,864 |  |  |  |  | (1,742) |  |  |  |  | 26,270 |  |  |  |
| Interest and other, net | 51,694 |  |  |  |  | 47,749 |  |  |  |  | 36,207 |  |  |  |  | 28,077 |  |  |  |  | 163,727 |  |  |  |
| Other charges, net | 1,463 |  |  |  |  | 1,147 |  |  |  |  | 14,395 |  |  |  |  | 74,545 |  |  |  |  | 91,550 |  |  |  |
| Income (loss) before income taxes | $ | 64,109 |  |  |  |  | $ | (95,693) |  |  |  |  | $ | 145,389 |  |  |  |  | $ | 44,680 |  |  |  |  | $ | 158,485 |  |  |  |

[0000866374-20-000012:mdna:73]
During fiscal year 2020, depreciation expense included in the segments' measure of operating performance above is as follows.

[0000866374-20-000012:mdna:74]
|  |  | Fiscal Year Ended |
|  |  | March 31, 2020 |
|  |  | (In thousands) |
|  |  | (Unaudited) |
| Depreciation expense: |  |  |
| Flex Agility Solutions |  | $ | 217,678 |  |
| Flex Reliability Solutions |  | 172,960 |  |
| Corporate and Other |  | 31,769 |  |
| Total depreciation expense |  | $ | 422,407 |  |

[0000866374-20-000012:mdna:75]
Property and equipment on a segment basis is not disclosed as it is not separately identified and is not internally reported by segment to the Company's CODM.

[0000866374-20-000012:mdna:76]
[same as prior period, unchanged from 0000866374-20-000003:mdna:73]

[0000866374-20-000012:mdna:77]
In order to support our strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, we have identified and are engaging in certain structural changes. These restructuring actions will eliminate non-core activities primarily within our corporate function, align our cost structure with our reorganizing and optimizing of our operations model along our two reporting segments, and further sharpen our focus to winning business in end markets where we have competitive advantages and deep domain expertise. During the first quarter of

[0000866374-20-000012:mdna:78]
[same as prior period, unchanged from 0000866374-20-000003:mdna:3]

[0000866374-20-000012:mdna:79]
fiscal year 2021, we recognized an immaterial amount of restructuring charges. We expect to recognize additional charges of approximately $100 million, the majority of which is planned severance for employee terminations over the remaining fiscal year 2021.

[0000866374-20-000012:mdna:80]
During the three-month period ended June 28, 2019, the Company recognized $56.2 million of restructuring charges, comprised of approximately $30.8 million of cash charges predominantly for employee severance, and $25.4 million of non-cash charges related to impairment of equipment and inventory.

[0000866374-20-000012:mdna:81]
[same as prior period, unchanged from 0000866374-20-000003:mdna:76]

[0000866374-20-000012:mdna:82]
Selling, general and administrative expenses (“SG&A”) was $191 million, or 3.7% of net sales, during the three-month period ended June 26, 2020, decreasing $19 million from $210 million, or 3.4% of net sales, during the three-month period ended June 28, 2019. The decrease reflects strong cost discipline practiced across the enterprise as well as the benefits from our distinct actions taken to temporarily reduce compensation costs across our employee base and aggressively reduce our discretionary spend levels.

[0000866374-20-000012:mdna:83]
[same as prior period, unchanged from 0000866374-20-000003:mdna:78]

[0000866374-20-000012:mdna:84]
Amortization of intangible assets marginally declined during the three-month period ended June 26, 2020, to $15 million , from $17 million for the three-month period ended June 28, 2019, primarily due to certain intangibles now being fully amortized.

[0000866374-20-000012:mdna:85]
[same as prior period, unchanged from 0000866374-20-000003:mdna:80]

[0000866374-20-000012:mdna:86]
Interest and other, net was $30 million during the three-month period ended June 26, 2020 compared to $53 million during the three-month period ended June 28, 2019. The decrease in interest other, net was primarily due to lower expenses from our asset-backed securitization programs coupled with lower interest expense from our new borrowings compared to the prior year period.

[0000866374-20-000012:mdna:87]
[same as prior period, unchanged from 0000866374-20-000003:mdna:85]

[0000866374-20-000012:mdna:88]
Certain of our subsidiaries, at various times, have been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 14, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020 for further discussion.

[0000866374-20-000012:mdna:89]
[same as prior period, unchanged from 0000866374-20-000003:mdna:87]

[0000866374-20-000012:mdna:90]
The consolidated effective tax rate was 23% and 30% for the  three-month periods ended June 26, 2020 and June 28, 2019, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, India, the Netherlands and Israel. The effective tax rate for the three-month period ended June 26, 2020 is lower than the effective tax rate for the three-month period ended June 28, 2019, primarily due to a changing jurisdictional mix of incomes.

[0000866374-20-000012:mdna:91]
[same as prior period, unchanged from 0000866374-20-000003:mdna:89]

[0000866374-20-000012:mdna:92]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of June 26, 2020, we had cash and cash equivalents of approximately $1.9 billion and bank and other borrowings of approximately $3.6 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. We also issued $425 million of 3.750% Notes due February 2026 and $325 million of 4.875% Notes due May 2030.  Refer to note 6 to the condensed consolidated financial statement for details. As of June 26, 2020, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-20-000012:mdna:93]
Cash used in operating activities was $629 million during the three-month period ended June 26, 2020, primarily driven by cash outflows related to accounts receivables as we reduced our outstanding balance on our ABS programs, and used proceeds

[0000866374-20-000012:mdna:94]
from our debt funding in accordance with our revised capital strategy. These were offset by $52 million of net income for the period plus $154 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation.

[0000866374-20-000012:mdna:95]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. Net working capital increased $1.1 billion as of June 26, 2020, from $1.4 billion as of March 31, 2020. This increase is primarily driven by a $0.8 billion increase in net receivables, coupled with a $0.5 billion decrease in accounts payable, partially offset by a $0.3 billion decrease in inventories. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended June 26, 2020, increased to 11.9% from 6.3% of annualized net sales for the quarter ended March 31, 2020 as a direct result of reducing the outstanding balance of our ABS programs. As a result of carrying reduced ABS levels, the Company expects to operate in this range going forward. Though we have mitigated most of the initial supplier constraints and component shortages that we had encountered back in the last quarter of fiscal year 2020, we continue to operate in an unusual and dynamic environment with respect to virus-related production limitations and fluctuating demand. We expect it will take a few quarters to adequately drive down our inventory levels to align with the current demand environment. We are actively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative resetting our load planning.

[0000866374-20-000012:mdna:96]
Cash used in investing activities was $100 million during the three-month period ended June 26, 2020. This was primarily driven by $102 million of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding health solutions and industrial businesses.

[0000866374-20-000012:mdna:97]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, plus cash collections of deferred purchase price receivables, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency (refer to Part II, Item 8, note 11 of our Annual Report on Form 10-K for the year ended March 31, 2020, for discussion of the amendment of the ABS Programs). We also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation. In the first quarter of fiscal year 2021, we proactively and strategically utilized the proceeds of our debt issuance during the quarter to reduce the outstanding balance of our ABS programs. We reduced the balance on this short-term financing product by $655 million sequentially, which has the accounting effect of reducing our cash flow from operations. Our adjusted free cash flows for the three-month period ended June 26, 2020 was a use of $74 million compared to an inflow of $114 million for the three-month period ended June 28, 2019. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-20-000012:mdna:98]
|  | Three-Month Periods Ended |  |  |
|  | June 26, 2020 |  | June 28, 2019 |
|  | (In millions) |  |  |
| Net cash used in operating activities | $ | (629) |  |  | $ | (657) |  |
| Reduction in ABS levels | 655 |  |  | — |  |
| Cash collection of deferred purchase price and other | 2 |  |  | 894 |  |
| Purchases of property and equipment | (110) |  |  | (162) |  |
| Proceeds from the disposition of property and equipment | 8 |  |  | 39 |  |
| Adjusted free cash flow | $ | (74) |  |  | $ | 114 |  |

[0000866374-20-000012:mdna:99]
Cash provided by financing activities was $741 million during the three-month period ended June 26, 2020, which was primarily driven by $747 million of proceeds received in aggregate, and net of discount, following the issuance of the 2026 Notes and the 2030 Notes. For further information, see note 6 to the condensed consolidated financial statements.

[0000866374-20-000012:mdna:100]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our

[0000866374-20-000012:mdna:101]
existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of June 26, 2020, and March 31, 2020, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.4 billion as of March 31, 2020). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-20-000012:mdna:102]
[same as prior period, unchanged from 0000866374-20-000003:mdna:98]

[0000866374-20-000012:mdna:103]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs amounted to approximately $0.2 billion and $0.1 billion for the three-month periods ended June 26, 2020 and June 28, 2019, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-20-000012:mdna:104]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to commercial paper program, and revolving sale and repurchase of subordinated note established under the securitization facility, under which there were no borrowings outstanding as of June 26, 2020.

[0000866374-20-000012:mdna:105]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed.

[0000866374-20-000012:mdna:106]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-20-000012:mdna:107]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 20, 2019. During the three-month period ended June 26, 2020, there were no purchases of our ordinary shares made by us. As of June 26, 2020, shares in the aggregate amount of $315 million were available to be repurchased under the current plan.

[0000866374-20-000012:mdna:108]
[same as prior period, unchanged from 0000866374-20-000003:mdna:105]

[0000866374-20-000012:mdna:109]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2020.

[0000866374-20-000012:mdna:110]
During the first quarter of fiscal year 2021, we issued $425 million of 3.750% Notes due February 2026 and $325 million of 4.875% Notes due May 2030.

[0000866374-20-000012:mdna:111]
Other than the changes discussed above, there were no material changes in our contractual obligations and commitments since March 31, 2020.

[0000866374-20-000012:mdna:112]
[same as prior period, unchanged from 0000866374-20-000003:mdna:109]

[0000866374-20-000012:mdna:113]
As of June 26, 2020, and March 31, 2020, the outstanding balance on receivables sold for cash was $0.4 billion and $1.2 billion, respectively, under our asset-backed securitization programs and accounts receivable factoring program, which were removed from accounts receivable balances in our condensed consolidated balance sheets. For further information, see note 10 to the condensed consolidated financial statements.
