# FLEX 10-Q controls and the auditor's report


## item_4_controls

[0000866374-20-000012:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000866374-20-000012:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures

[0000866374-20-000012:item_4_controls:3]
The Company's management, with the participation of the Chief Executive Officer and Chief Financial Officer has evaluated the effectiveness of the Company's disclosure controls and procedures (as defined in Rule 13a-15(e) under the Exchange Act) as of June 26, 2020. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer concluded that, as of June 26, 2020, the Company's disclosure controls and procedures were effective in ensuring that information required to be disclosed by the Company in reports that it files or submits under the Securities Exchange Act of 1934, as amended, is (i) recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms and (ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000866374-20-000012:item_4_controls:4]
(b) Changes in Internal Control Over Financial Reporting

[0000866374-20-000012:item_4_controls:5]
There were no changes in our internal control over financial reporting that occurred during our first quarter of fiscal year 2021 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000866374-20-000012:item_4_controls:6]
37
