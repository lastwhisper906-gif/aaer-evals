# FLEX note change history — 0000866374-20-000003 → 0000866374-20-000012


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000866374-20-000012:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.
  (was, 2020-01-31, similarity 0.9757):
[0000866374-20-000003:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- changed (2020-08-05):
[0000866374-20-000012:note_history:2]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions and have agreed in principle to an immaterial settlement.
  (was, 2020-01-31, similarity 0.616):
[0000866374-20-000003:note_history:2]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

- changed (2020-08-05):
[0000866374-20-000012:note_history:3]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, Defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted Defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, Defendants filed a motion to dismiss the amended complaint. Defendants’ motion to dismiss is set for hearing on December 3, 2020. The Company believes that the claims are without merit and intends to vigorously defend this case.
  (was, 2020-01-31, similarity 0.815):
[0000866374-20-000003:note_history:3]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019,  lead plaintiff filed a further amended complaint. On December 4, 2019, Defendants filed a motion to dismiss the amended complaint. Defendants’ motion to dismiss is set for hearing on April 9, 2020. The Company believes that the claims are without merit and intends to vigorously defend this case.

- added (2020-08-05):
[0000866374-20-000012:note_history:4]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling 373.7 million Brazilian reals (approximately USD $71.1 million based on the exchange rate as of June 26, 2020). Four of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60.5 million Brazilian reals or USD $11.5 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Sao Paolo, Brazil on March 23, 2020; the value of that assessment is 33.9 million Brazilian reals (approximately USD $6.4 million). The Company believes there is no legal basis for any of these assessments and has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

- changed (2020-08-05):
[0000866374-20-000012:note_history:5]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter which is ongoing. The Company expects to complete the investigation and report to OFAC by the end of the second quarter of fiscal year 2021, and it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.
  (was, 2020-01-31, similarity 0.725):
[0000866374-20-000003:note_history:5]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter which is ongoing. The Company cannot predict how long it will take to complete the investigation or to what extent the Company could be subject to penalties.

- changed (2020-08-05):
[0000866374-20-000012:note_history:6]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.
  (was, 2020-01-31, similarity 0.6599):
[0000866374-20-000003:note_history:6]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes. As the final resolution of the assessment remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- added (2020-08-05):
[0000866374-20-000012:note_history:7]
A different foreign Tax Authority has issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for the periods fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80 million. The Company disagrees with the Tax Authority’s assertion and is actively contesting through administrative processes and will defend through judicial processes if necessary.

- added (2020-08-05):
[0000866374-20-000012:note_history:8]
As the final resolutions of the above items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2020-08-05):
[0000866374-20-000003:note_history:9]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There are six tax assessments totaling 340 million Brazilian reals (approximately USD $83.8 million based on the exchange rate as of December 31, 2019). The assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60 million Brazilian reals or USD $14.8 million), but that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-08-05):
[0000866374-20-000012:note_history:10]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In the first quarter of fiscal year 2021, the Company made certain changes in its organizational structure as part of its strategy to further drive growth and productivity with two focused delivery models. As a result, beginning in the first quarter of fiscal year 2021, the Company reports its financial performance based on two operating and reportable segments:

- added (2020-08-05):
[0000866374-20-000012:note_history:11]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

- added (2020-08-05):
[0000866374-20-000012:note_history:12]
◦Consumer Devices, including mobile and high velocity consumer devices;

- added (2020-08-05):
[0000866374-20-000012:note_history:13]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

- added (2020-08-05):
[0000866374-20-000012:note_history:14]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure.

- added (2020-08-05):
[0000866374-20-000012:note_history:15]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

- added (2020-08-05):
[0000866374-20-000012:note_history:16]
◦Automotive, including autonomous, connectivity, electrification, and smart technologies;

- added (2020-08-05):
[0000866374-20-000012:note_history:17]
◦Health Solutions, including medical devices, medical equipment and drug delivery; and

- added (2020-08-05):
[0000866374-20-000012:note_history:18]
◦Industrial, including capital equipment, industrial devices, renewable and grid edge, and power systems.

- changed (2020-08-05):
[0000866374-20-000012:note_history:19]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers).
  (was, 2020-01-31, similarity 0.9958):
[0000866374-20-000003:note_history:19]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).

- changed (2020-08-05):
[0000866374-20-000012:note_history:20]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2020 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month periods ended June 26, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021.
  (was, 2020-01-31, similarity 0.9891):
[0000866374-20-000003:note_history:20]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2019 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020.

- added (2020-08-05):
[0000866374-20-000012:note_history:21]
The first quarters for fiscal years 2021 and 2020 ended on June 26, 2020, which is comprised of 87 days in the period, and June 28, 2019, which is comprised of 89 days in the period, respectively.

- changed (2020-08-05):
[0000866374-20-000012:note_history:22]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.
  (was, 2020-01-31, similarity 0.7104):
[0000866374-20-000003:note_history:22]
owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

- added (2020-08-05):
[0000866374-20-000012:note_history:23]
The changes to the Company’s organizational structure noted above had no impact to the condensed consolidated financial statements. For comparability purposes, segment reporting for prior periods have been restated to conform to the current

- added (2020-08-05):
[0000866374-20-000012:note_history:24]
presentation. Refer to note 14, “Segments Reporting,” for additional information on the changes in operating and reportable segments.

- added (2020-08-05):
[0000866374-20-000012:note_history:25]
Use of Estimates

- added (2020-08-05):
[0000866374-20-000012:note_history:26]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments including highly liquid investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rate in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- added (2020-08-05):
[0000866374-20-000012:note_history:27]
In March 2020, the FASB issued ASU 2020-04 "Facilitation of the Effects of Reference Rate Reform on Financial Reporting", which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

- changed (2020-08-05):
[0000866374-20-000012:note_history:28]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04,  ASU 2019-05, ASU 2019-10, and ASU 2019-11, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.
  (was, 2020-01-31, similarity 0.7298):
[0000866374-20-000003:note_history:28]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04,  ASU 2019-05, ASU 2019-10, and ASU 2019-11, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is currently assessing and expects the new guidance to have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

- added (2020-08-05):
[0000866374-20-000012:note_history:29]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

- changed (2020-08-05):
[0000866374-20-000012:note_history:30]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes", which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.
  (was, 2020-01-31, similarity 0.9994):
[0000866374-20-000003:note_history:30]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes", which removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

- removed (2020-08-05):
[0000866374-20-000003:note_history:31]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scale® services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and manages complete packaged consumer and enterprise products, from medical devices and connected automotive systems to sustainable lighting and cloud and data center solutions for companies of all sizes in various industries and end-markets, through its activities in the following segments:

- removed (2020-08-05):
[0000866374-20-000003:note_history:32]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including surgical equipment, drug delivery, diagnostics, telemedicine, disposable devices, imaging and monitoring, patient mobility and ophthalmology; and our automotive business, including vehicle electrification, connectivity, autonomous, and smart technologies; |

- removed (2020-08-05):
[0000866374-20-000003:note_history:33]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, smart solar energy; and industrial, including semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks; |

- removed (2020-08-05):
[0000866374-20-000003:note_history:34]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads and small cells for wireless infrastructure; our networking business, which includes optical, routing, and switching products for data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack-level solutions, converged infrastructure and software-defined product solutions; and |

- removed (2020-08-05):
[0000866374-20-000003:note_history:35]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in IoT enabled devices, audio and consumer power electronics, mobile devices; and various supply chain solutions for consumer, computing and printing devices. |

- removed (2020-08-05):
[0000866374-20-000003:note_history:36]
The first quarters for fiscal years 2020 and 2019 ended on June 28, 2019, which is comprised of 89 days in the period, and June 29, 2018, which is comprised of 90 days in the period, respectively. The second quarters for fiscal years 2020 and 2019 ended on September 27, 2019 and September 28, 2018, which are comprised of 91 days in both periods. The Company's third quarters ended on December 31 of each year, which are comprised of 95 days and 94 days for fiscal years 2020 and 2019, respectively.

- removed (2020-08-05):
[0000866374-20-000003:note_history:37]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-

- removed (2020-08-05):
[0000866374-20-000003:note_history:38]
As previously disclosed, the Company has made certain immaterial corrections to net sales previously reported for the first, second, and third quarters of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result of correcting these errors, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month and nine-month periods ended December 31, 2018 have been reduced by $22 million and $95 million, respectively, from previously reported amounts. These corrections had no impact on gross profit, segment income or net income for the periods presented. Amounts presented for the three-month and nine-month periods ended December 31, 2018 related to the disaggregation of revenue in the CTG segment in Note 4, and CTG segment net sales and total net sales in Note 16, have also been restated accordingly. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to the previously issued financial statements.

- removed (2020-08-05):
[0000866374-20-000003:note_history:39]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU No. 2016-02, "Leases", and subsequent updates (collectively, referred to as Accounting Standard Codification 842 or “ASC 842”). ASC 842 requires a lessee to recognize a right of use (“ROU”) asset and lease liability. Leases will be classified as finance or operating, with classification affecting the recognition of expense and presentation in the income statement.

- removed (2020-08-05):
[0000866374-20-000003:note_history:40]
The Company adopted ASC 842 on April 1, 2019 using the optional transition method, by which companies may elect not to recast the comparative periods presented in financial statements in the period of adoption and recognize a cumulative effect adjustment in the period of adoption. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before the Company's adoption date. The Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. In addition, the Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for its leases, the Company uses its estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company’s estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company’s leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

- removed (2020-08-05):
[0000866374-20-000003:note_history:41]
The adoption of ASC 842 had a material impact to the Company’s consolidated balance sheet, but did not materially impact the consolidated statement of income or consolidated statement of cash flows. The most significant changes to the consolidated balance sheet relate to the recognition of new ROU assets and lease liabilities for operating leases. The Company’s accounting for finance leases remains substantially unchanged and the balances are not material for any periods presented.

- removed (2020-08-05):
[0000866374-20-000003:note_history:42]
As a result of adopting ASC 842 as of April 1, 2019, the Company recognized additional operating liabilities of $658 million with a corresponding ROU asset of $624 million and a deferred gain of $22 million for sale leaseback transactions to opening retained earnings.

- removed (2020-08-05):
[0000866374-20-000003:note_history:43]
In October 2018, the FASB issued ASU 2018-16 “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” to expand the lists of eligible benchmark interest rates to include OIS based on SOFR to facilitate the marketplace transition from LIBOR. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.

- removed (2020-08-05):
[0000866374-20-000003:note_history:44]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing

- removed (2020-08-05):
[0000866374-20-000003:note_history:45]
arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company early adopted the guidance during the second quarter of fiscal year 2020 with an immaterial impact to its condensed consolidated financial statements.

- removed (2020-08-05):
[0000866374-20-000003:note_history:46]
In August 2018, the FASB issued ASU 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.

- removed (2020-08-05):
[0000866374-20-000003:note_history:47]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

- removed (2020-08-05):
[0000866374-20-000003:note_history:48]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

- removed (2020-08-05):
[0000866374-20-000003:note_history:49]
In October 2018, the FASB issued ASU 2018-17 “Consolidation (Topic 810): Targeted Improvements to Related Party Guidance for Variable Interest Entities” to provide a new private company variable interest entity exemption and change how decision makers apply the variable interest criteria. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000866374-20-000012:note_history:50]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 26, 2020 are as follows:
  (was, 2020-01-31, similarity 0.951):
[0000866374-20-000003:note_history:50]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2019 are as follows:

- changed (2020-08-05):
[0000866374-20-000012:note_history:51]
|  | As of June 26, 2020 |  | As of March 31, 2020 |
|  | (In thousands) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | 433,406 |  |  | 433,406 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 313,596 |  |  | 310,115 |  |
| 4.750% Notes due June 2025 | 597,380 |  |  | 597,265 |  |
| 3.750% Notes due February 2026 | 423,411 |  |  | — |  |
| 4.875% Notes due June 2029 | 661,610 |  |  | 661,908 |  |
| 4.875% Notes due May 2030 | 323,595 |  |  | — |  |
| India Facilities | 138,238 |  |  | 138,238 |  |
| Other | 213,881 |  |  | 210,684 |  |
| Debt issuance costs | (19,668) |  |  | (13,377) |  |
|  | 3,585,449 |  |  | 2,838,239 |  |
| Current portion, net of debt issuance costs | (162,287) |  |  | (149,130) |  |
| Non-current portion | $ | 3,423,162 |  |  | $ | 2,689,109 |  |
  (was, 2020-01-31, similarity 0.603):
[0000866374-20-000003:note_history:51]
|  | As of December 31, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | — |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 439,688 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305,927 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,150 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 662,205 |  |  | — |  |
| India Facilities | 133,145 |  |  | 170,206 |  |
| Other | 165,897 |  |  | 168,039 |  |
| Debt issuance costs | (14,031 | ) |  | (10,639 | ) |
|  | 2,789,981 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (88,869 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,701,112 |  |  | $ | 2,421,904 |  |

- changed (2020-08-05):
[0000866374-20-000012:note_history:52]
The weighted-average interest rate for the Company's long-term debt was 3.8% and 4.0% as of June 26, 2020 and March 31, 2020, respectively.
  (was, 2020-01-31, similarity 0.8992):
[0000866374-20-000003:note_history:52]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.2% as of December 31, 2019 and March 31, 2019.

- changed (2020-08-05):
[0000866374-20-000012:note_history:53]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 26, 2020 are as follows:
  (was, 2020-01-31, similarity 0.8421):
[0000866374-20-000003:note_history:53]
Scheduled repayments of the Company's long-term debt as of December 31, 2019 are as follows:

- changed (2020-08-05):
[0000866374-20-000012:note_history:54]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2021.
  (was, 2020-01-31, similarity 0.8889):
[0000866374-20-000003:note_history:54]
| (1) | Represents estimated repayments for the remaining three-month period ending March 31, 2020. |

- added (2020-08-05):
[0000866374-20-000012:note_history:55]
Notes due February 2026 and May 2030

- added (2020-08-05):
[0000866374-20-000012:note_history:56]
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026 (the "2026 Notes"), at 99.617% of face value and $325 million aggregate principal amount of 4.875% Notes due May 2020 (the "2030 Notes" and , together with the 2026 Notes, the " Notes"), at 99.562% of face value. The Company received in aggregate, proceeds of approximately $747 million, net of discount, from the issuance which were used for working capital and other general corporate purposes. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet approximately $7.1 million of costs in conjunction with the issuance of the Notes.

- added (2020-08-05):
[0000866374-20-000012:note_history:57]
Interest on the 2026 Notes and the 2030 Notes is payable semi-annually, commencing on August 1, 2020 and November 12, 2020, respectively. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.

- changed (2020-08-05):
[0000866374-20-000012:note_history:58]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of 
default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2026 Notes or 2030 Notes may declare all of such series of Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of such series of Notes. As of June 26, 2020, the Company was in compliance with the covenants in the indenture governing the Notes.
  (was, 2020-01-31, similarity 0.9649):
[0000866374-20-000003:note_history:58]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of December 31, 2019, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.

- removed (2020-08-05):
[0000866374-20-000003:note_history:59]
During fiscal year 2020, and as further discussed below, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, in addition to issuing $650 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay the outstanding balances of the Company's existing 4.625% Notes due February 2020, and the Term Loan due November 2021. As both transactions were determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during the three-month and nine-month periods ended December 31, 2019, which was recorded in interest and other, net on the condensed consolidated statements of operations during the period.

- removed (2020-08-05):
[0000866374-20-000003:note_history:60]
Term Loan due April 2024

- removed (2020-08-05):
[0000866374-20-000003:note_history:61]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 10 for additional details.

- removed (2020-08-05):
[0000866374-20-000003:note_history:62]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are

- removed (2020-08-05):
[0000866374-20-000003:note_history:63]
subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2019, the Company was in compliance with the covenants under this term loan agreement.

- removed (2020-08-05):
[0000866374-20-000003:note_history:64]
Notes due June 2029

- removed (2020-08-05):
[0000866374-20-000003:note_history:65]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “Existing 2029 Notes”), at 99.607% of face value. In November 2019, as a further issuance of the Existing 2029 Notes, the Company issued under the same terms, an additional $200 million of 4.875% Notes due June 15, 2029 (together with the "Existing 2029 Notes" above, the "2029 Notes"), at 107.289% of face value. Immediately after the issuance of the notes issued in November 2019, the Company has $650 million aggregate principal amount of 4.875% Notes due 2029 outstanding. The Company received in aggregate, proceeds of approximately $662.8 million, net of discount and premium, from the issuances which were used, together with available cash, to refinance certain other outstanding debt. The Company incurred and capitalized as a direct reduction to the carrying amount of the notes presented on the balance sheet approximately $6.6 million of costs in conjunction with the issuance of the 2029 Notes.

- removed (2020-08-05):
[0000866374-20-000003:note_history:66]
Interest on the 2029 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2019. The 2029 Notes are senior unsecured obligations of the Company and rank equally with all of the Company’s other existing and future senior and unsecured indebtedness.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000866374-20-000012:note_history:67]
|  | As of June 26, 2020 |  |  |  | As of March 31, 2020 |  |  |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |  |  |  |  |  |  |  |  |
| Term Loan, including current portion, due in installments through June 2022 | 433,406 |  |  | 433,363 |  |  | 433,406 |  |  | 413,903 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 535,591 |  |  | 500,000 |  |  | 499,710 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 313,596 |  |  | 313,596 |  |  | 310,115 |  |  | 310,115 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,380 |  |  | 663,623 |  |  | 597,265 |  |  | 613,152 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 423,411 |  |  | 449,958 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 661,610 |  |  | 734,043 |  |  | 661,908 |  |  | 628,419 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 323,595 |  |  | 358,899 |  |  | — |  |  | — |  |  | Level 1 |
| Euro Term Loans | 212,678 |  |  | 212,678 |  |  | 207,646 |  |  | 207,646 |  |  | Level 2 |
| India Facilities | 138,238 |  |  | 138,238 |  |  | 138,238 |  |  | 138,238 |  |  | Level 2 |
  (was, 2020-01-31, similarity 0.6264):
[0000866374-20-000003:note_history:67]
|  | As of December 31, 2019 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through June 2022 | 439,688 |  |  | 441,337 |  |  | 458,531 |  |  | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 534,733 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305,927 |  |  | 305,927 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,150 |  |  | 647,854 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 662,205 |  |  | 717,955 |  |  | — |  |  | — |  |  | Level 1 |
| India Facilities | 133,145 |  |  | 133,145 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |
| Euro Term Loan due September 2020 | 51,281 |  |  | 51,281 |  |  | 52,746 |  |  | 52,746 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 111,632 |  |  | 111,632 |  |  | 112,524 |  |  | 112,524 |  |  | Level 2 |
| Total | $ | 2,801,028 |  |  | $ | 2,943,864 |  |  | $ | 1,890,822 |  |  | $ | 1,893,324 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000866374-20-000012:note_history:68]
Bank borrowings and long-term debt as of June 26, 2020 are as follows:
  (was, 2020-01-31, similarity 0.9254):
[0000866374-20-000003:note_history:68]
Bank borrowings and long-term debt as of December 31, 2019 are as follows:

- changed (2020-08-05):
[0000866374-20-000012:note_history:69]
|  | As of June 26, 2020 |  | As of March 31, 2020 |
|  | (In thousands) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | 433,406 |  |  | 433,406 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 313,596 |  |  | 310,115 |  |
| 4.750% Notes due June 2025 | 597,380 |  |  | 597,265 |  |
| 3.750% Notes due February 2026 | 423,411 |  |  | — |  |
| 4.875% Notes due June 2029 | 661,610 |  |  | 661,908 |  |
| 4.875% Notes due May 2030 | 323,595 |  |  | — |  |
| India Facilities | 138,238 |  |  | 138,238 |  |
| Other | 213,881 |  |  | 210,684 |  |
| Debt issuance costs | (19,668) |  |  | (13,377) |  |
|  | 3,585,449 |  |  | 2,838,239 |  |
| Current portion, net of debt issuance costs | (162,287) |  |  | (149,130) |  |
| Non-current portion | $ | 3,423,162 |  |  | $ | 2,689,109 |  |
  (was, 2020-01-31, similarity 0.603):
[0000866374-20-000003:note_history:69]
|  | As of December 31, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | — |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 439,688 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 305,927 |  |  | — |  |
| 4.75% Notes due June 2025 | 597,150 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 662,205 |  |  | — |  |
| India Facilities | 133,145 |  |  | 170,206 |  |
| Other | 165,897 |  |  | 168,039 |  |
| Debt issuance costs | (14,031 | ) |  | (10,639 | ) |
|  | 2,789,981 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (88,869 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,701,112 |  |  | $ | 2,421,904 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000866374-20-000012:note_history:70]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 26, 2020 are as follows:
  (was, 2020-01-31, similarity 0.8421):
[0000866374-20-000003:note_history:70]
Scheduled repayments of the Company's long-term debt as of December 31, 2019 are as follows:

- changed (2020-08-05):
[0000866374-20-000012:note_history:71]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2021.
  (was, 2020-01-31, similarity 0.905):
[0000866374-20-000003:note_history:71]
Represents estimated repayments for the remaining three-month period ending March 31, 2020.

- removed (2020-08-05):
[0000866374-20-000003:note_history:72]
(1)


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000866374-20-000012:note_history:73]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 26, 2020 and June 28, 2019 (in thousands), respectively.
  (was, 2020-01-31, similarity 0.8833):
[0000866374-20-000003:note_history:73]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2019 and December 31, 2018 (in thousands), respectively.

- removed (2020-08-05):
[0000866374-20-000003:note_history:74]
|  | Three-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 978,026 |  |  | $ | 1,471,116 |  |  | $ | 1,513,721 |  |  | $ | 1,191,491 |  |  | $ | 5,154,354 |  |
| Over time | 266,689 |  |  | 517,749 |  |  | 367,690 |  |  | 154,905 |  |  | 1,307,033 |  |
| Total segment | $ | 1,244,715 |  |  | $ | 1,988,865 |  |  | $ | 1,881,411 |  |  | $ | 1,346,396 |  |  | $ | 6,461,387 |  |

- removed (2020-08-05):
[0000866374-20-000003:note_history:75]
|  | Nine-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,843,866 |  |  | $ | 3,734,151 |  |  | $ | 4,263,144 |  |  | $ | 3,319,972 |  |  | $ | 14,161,133 |  |
| Over time | 767,523 |  |  | 1,677,196 |  |  | 1,205,713 |  |  | 913,815 |  |  | 4,564,247 |  |
| Total segment | $ | 3,611,389 |  |  | $ | 5,411,347 |  |  | $ | 5,468,857 |  |  | $ | 4,233,787 |  |  | $ | 18,725,380 |  |

- removed (2020-08-05):
[0000866374-20-000003:note_history:76]
|  | Three-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 929,638 |  |  | $ | 1,198,669 |  |  | $ | 1,663,262 |  |  | $ | 1,232,712 |  |  | $ | 5,024,281 |  |
| Over time | 276,714 |  |  | 460,256 |  |  | 596,966 |  |  | 564,610 |  |  | 1,898,546 |  |
| Total segment | $ | 1,206,352 |  |  | $ | 1,658,925 |  |  | $ | 2,260,228 |  |  | $ | 1,797,322 |  |  | $ | 6,922,827 |  |

- removed (2020-08-05):
[0000866374-20-000003:note_history:77]
|  | Nine-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,827,959 |  |  | $ | 3,351,886 |  |  | $ | 4,675,809 |  |  | $ | 3,732,545 |  |  | $ | 14,588,199 |  |
| Over time | 801,790 |  |  | 1,319,302 |  |  | 1,679,502 |  |  | 1,595,594 |  |  | 5,396,188 |  |
| Total segment | $ | 3,629,749 |  |  | $ | 4,671,188 |  |  | $ | 6,355,311 |  |  | $ | 5,328,139 |  |  | $ | 19,984,387 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000866374-20-000012:note_history:78]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.
  (was, 2020-01-31, similarity 0.9988):
[0000866374-20-000003:note_history:78]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

- changed (2020-08-05):
[0000866374-20-000012:note_history:79]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion
  (was, 2020-01-31, similarity 0.8568):
[0000866374-20-000003:note_history:79]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable

- changed (2020-08-05):
[0000866374-20-000012:note_history:80]
of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.
  (was, 2020-01-31, similarity 0.8273):
[0000866374-20-000003:note_history:80]
profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- changed (2020-08-05):
[0000866374-20-000012:note_history:81]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $362.1 million and $361.5 million as of June 26, 2020 and March 31, 2020, respectively.
  (was, 2020-01-31, similarity 0.9821):
[0000866374-20-000003:note_history:81]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $523.2 million and $271.8 million as of December 31, 2019 and March 31, 2019, respectively.

- changed (2020-08-05):
[0000866374-20-000012:note_history:82]
Disaggregation of Revenue
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 26, 2020 and June 28, 2019 (in thousands), respectively.
  (was, 2020-01-31, similarity 0.8337):
[0000866374-20-000003:note_history:82]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2019 and December 31, 2018 (in thousands), respectively.

- removed (2020-08-05):
[0000866374-20-000003:note_history:83]
Disaggregation of Revenue

- removed (2020-08-05):
[0000866374-20-000003:note_history:84]
|  | Three-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 978,026 |  |  | $ | 1,471,116 |  |  | $ | 1,513,721 |  |  | $ | 1,191,491 |  |  | $ | 5,154,354 |  |
| Over time | 266,689 |  |  | 517,749 |  |  | 367,690 |  |  | 154,905 |  |  | 1,307,033 |  |
| Total segment | $ | 1,244,715 |  |  | $ | 1,988,865 |  |  | $ | 1,881,411 |  |  | $ | 1,346,396 |  |  | $ | 6,461,387 |  |

- removed (2020-08-05):
[0000866374-20-000003:note_history:85]
|  | Nine-Month Period Ended December 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,843,866 |  |  | $ | 3,734,151 |  |  | $ | 4,263,144 |  |  | $ | 3,319,972 |  |  | $ | 14,161,133 |  |
| Over time | 767,523 |  |  | 1,677,196 |  |  | 1,205,713 |  |  | 913,815 |  |  | 4,564,247 |  |
| Total segment | $ | 3,611,389 |  |  | $ | 5,411,347 |  |  | $ | 5,468,857 |  |  | $ | 4,233,787 |  |  | $ | 18,725,380 |  |

- removed (2020-08-05):
[0000866374-20-000003:note_history:86]
|  | Three-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 929,638 |  |  | $ | 1,198,669 |  |  | $ | 1,663,262 |  |  | $ | 1,232,712 |  |  | $ | 5,024,281 |  |
| Over time | 276,714 |  |  | 460,256 |  |  | 596,966 |  |  | 564,610 |  |  | 1,898,546 |  |
| Total segment | $ | 1,206,352 |  |  | $ | 1,658,925 |  |  | $ | 2,260,228 |  |  | $ | 1,797,322 |  |  | $ | 6,922,827 |  |

- removed (2020-08-05):
[0000866374-20-000003:note_history:87]
|  | Nine-Month Period Ended December 31, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,827,959 |  |  | $ | 3,351,886 |  |  | $ | 4,675,809 |  |  | $ | 3,732,545 |  |  | $ | 14,588,199 |  |
| Over time | 801,790 |  |  | 1,319,302 |  |  | 1,679,502 |  |  | 1,595,594 |  |  | 5,396,188 |  |
| Total segment | $ | 3,629,749 |  |  | $ | 4,671,188 |  |  | $ | 6,355,311 |  |  | $ | 5,328,139 |  |  | $ | 19,984,387 |  |
