# FLEX notes — 0000866374-24-000021


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000866374-24-000021:notes:1]
| Document |  | Parts into Which Incorporated |
| Proxy Statement to be delivered to shareholders in connection with the Registrant's 2024 Annual General Meeting of Shareholders |  | Part III |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-24-000021:notes:2]
ORGANIZATION OF THE COMPANY
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities include design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of March 31, 2024, as a result of the Spin-off (defined below) of Nextracker Inc. ("Nextracker"), formerly Flex's subsidiary and Nextracker segment, in the fourth quarter of fiscal year 2024, Flex now reports its financial performance based on two operating and reportable segments as follows:

[0000866374-24-000021:notes:3]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-24-000021:notes:4]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-24-000021:notes:5]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio

[0000866374-24-000021:notes:6]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-24-000021:notes:7]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-24-000021:notes:8]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies

[0000866374-24-000021:notes:9]
◦Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-24-000021:notes:10]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings, and renewables and grid edge.

[0000866374-24-000021:notes:11]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain  management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).

[0000866374-24-000021:notes:12]
Nextracker Follow-on Offering and Spin-off

[0000866374-24-000021:notes:13]
On February 13, 2023, Nextracker completed an initial public offering (the “IPO”) of its Class A common stock. Prior to the IPO, the Company maintained an 82.6% indirect ownership in Nextracker and consolidated Nextracker. On July 3, 2023, Nextracker completed a follow-on offering to its IPO and issued 15,631,562 shares of Class A common stock and received net proceeds of $552 million. The entire net proceeds were used by Nextracker to acquire 14,025,000 Nextracker LLC common units from Yuma, Inc., the Company’s indirect wholly-owned subsidiary, and 1,606,562 Nextracker LLC common units from TPG Rise Flash, L.P., an affiliate of the global alternative asset management firm TPG. As a result of the repurchase of Nextracker LLC common units by Nextracker, 15,631,562 shares of Nextracker Class B common stock were cancelled. The Company received approximately $495 million from the follow-on offering, after distribution of net proceeds to TPG and expenses. After the follow-on transaction, Flex held approximately 51.5% of Nextracker's common stock.

[0000866374-24-000021:notes:14]
In connection with the IPO, Nextracker entered into a Tax Receivable Agreement ("TRA") with Flex and TPG wherein 85% of the tax benefits realized in relation to the IPO would be paid to those parties. Flex has not recorded an asset in relation to amounts potentially due to Flex under the TRA as the amounts are contingent upon Nextracker realizing the IPO related tax benefits. As such, amounts will be recognized in income, if and when they are received. Amounts that could be received by Flex, over a 20 year period, range from zero to approximately $300 million.

[0000866374-24-000021:notes:15]
On January 2, 2024, the Company completed its previously announced spin-off of its remaining interest in Nextracker (the "Spin-off") to Flex shareholders on a pro-rata basis based on the number of ordinary shares of Flex held by each shareholder of Flex (the “Distribution”) as of December 29, 2023, which was the record date of the Distribution, pursuant to the Agreement

[0000866374-24-000021:notes:16]
and Plan of Merger, dated as of February 7, 2023. Under the terms of the Spin-off, Flex shareholders received approximately 0.17 shares of Nextracker Class A common stock for each Flex ordinary share held as of the record date of the Distribution. Flex shareholders received cash in lieu of any fractional shares. The Spin-off qualifies as a tax-free transaction for U.S. federal income tax purposes.

[0000866374-24-000021:notes:17]
As a result of the completion of the Spin-off, Nextracker became a fully independent public company, Flex no longer directly or indirectly holds any shares of Nextracker common stock or any securities convertible into or exchangeable for shares of Nextracker common stock and Flex no longer consolidates Nextracker into its financial results. All noncontrolling interest related to Nextracker have been eliminated through additional paid-in capital. Prior to or in connection with the Spin-off, Flex entered into various agreements to effect the Spin-off and provide a framework for the relationship between Flex and Nextracker following the Spin-off, including a Separation Agreement, a Tax Matters Agreement, a Transition Services Agreement, as well as agreements governing future trading relationships.

[0000866374-24-000021:notes:18]
Subsequent to the Spin-off, Flex will present Nextracker’s historical operations as discontinued operations and, as such, Nextracker’s historical results have been excluded from continuing operations and unless otherwise indicated Flex’s disclosures are presented on a continuing operations basis.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-24-000021:notes:19]
SUMMARY OF ACCOUNTING POLICIES
Basis of Presentation and Principles of Consolidation

[0000866374-24-000021:notes:20]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners.

[0000866374-24-000021:notes:21]
As a result of the Spin-off in the fourth quarter of fiscal year 2024, the historical financial results and financial position of Nextracker are presented as discontinued operations in the consolidated statements of operations and balance sheets for all periods presented. The historical statements of comprehensive income and cash flows and the balances related to stockholders’ equity have not been revised to reflect the effect of the Spin-off. See note 7 "Discontinued Operations" for additional information.

[0000866374-24-000021:notes:22]
Use of Estimates

[0000866374-24-000021:notes:23]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-24-000021:notes:24]
Translation of Foreign Currencies

[0000866374-24-000021:notes:25]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these

[0000866374-24-000021:notes:26]
subsidiaries' financial statements are reported as other comprehensive income (loss), a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in the Company's consolidated results of operations. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for all periods presented, and have been classified as a component of other charges (income), net in the consolidated statements of operations.

[0000866374-24-000021:notes:27]
Revenue Recognition

[0000866374-24-000021:notes:28]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company recognizes estimates of this variable consideration that are not expected to result in a significant revenue reversal in the future, primarily based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 4 "Revenue" for further details.

[0000866374-24-000021:notes:29]
Government Incentives and Grants

[0000866374-24-000021:notes:30]
The Company receives incentives from federal, state and local governments in different regions of the world that primarily encourage the Company to establish, maintain, or increase investment, employment, or production in the regions. The Company accounts for government incentives as a reduction in the cost of the capital investment or a reduction of expense, based on the substance of the incentives received. Benefits are generally recorded when all conditions attached to the incentive have been met and there is reasonable assurance of receipt. The Company records capital-related incentives as a reduction to Property and equipment, net on the consolidated balance sheets and recognizes a reduction to depreciation and amortization expense over the useful life of the corresponding acquired asset. The Company records operating grants as a reduction to expense in the same line item on the consolidated statements of operations as the expenditure for which the grant is intended to compensate. Government incentives and grants transactions are not material to the Company's financial position, results of operations or cash flows.

[0000866374-24-000021:notes:31]
Concentration of Credit Risk

[0000866374-24-000021:notes:32]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, derivative instruments, and cash and cash equivalents.

[0000866374-24-000021:notes:33]
Customer Credit Risk

[0000866374-24-000021:notes:34]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-24-000021:notes:35]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2024, 2023 and 2022:

[0000866374-24-000021:notes:36]
|  | Balance atBeginningof Year |  | Charges (Recoveries) to Costs and Expenses(1) |  | Deductions/Write-Offs (2) |  | Balance atEnd ofYear |
|  | (In millions) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2022 | $ | 57 |  |  | $ | (3) |  |  | $ | (2) |  |  | $ | 52 |  |
| Year ended March 31, 2023 | 52 |  |  | 4 |  |  | (50) |  |  | 6 |  |
| Year ended March 31, 2024 | 6 |  |  | 9 |  |  | (3) |  |  | 12 |  |

[0000866374-24-000021:notes:37]
(1)Charges and recoveries incurred during fiscal years 2024, 2023 and 2022 are primarily for costs and expenses or bad debt recoveries related to various distressed customers.

[0000866374-24-000021:notes:38]
(2)Deductions and write-offs during fiscal year 2023 is primarily as a result of a settlement reached with a certain former customer.

[0000866374-24-000021:notes:39]
No customer accounted for greater than 10% of the Company's net sales in fiscal years 2024, 2023 or 2022. No customer accounted for greater than 10% of the Company's total balance of accounts receivable, net as of the fiscal year ended March 31, 2024, March 31, 2023 or March 31, 2022.

[0000866374-24-000021:notes:40]
The Company's ten largest customers accounted for approximately 37%, 37% and 36%, of its net sales in fiscal years 2024, 2023 and 2022, respectively.

[0000866374-24-000021:notes:41]
Derivative Instruments

[0000866374-24-000021:notes:42]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 10.

[0000866374-24-000021:notes:43]
Cash and Cash Equivalents

[0000866374-24-000021:notes:44]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-24-000021:notes:45]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-24-000021:notes:46]
Cash and cash equivalents consisted of the following:

[0000866374-24-000021:notes:47]
|  | As of March 31, |
|  | 2024 |  | 2023 |
|  | (In millions) |
| Cash and bank balances | $ | 1,715 |  |  | $ | 840 |  |
| Money market funds and time deposits | 759 |  |  | 2,324 |  |
|  | $ | 2,474 |  |  | $ | 3,164 |  |

[0000866374-24-000021:notes:48]
Inventories

[0000866374-24-000021:notes:49]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or net realizable value write-downs, were as follows:

[0000866374-24-000021:notes:50]
|  | As of March 31, |
|  | 2024 |  | 2023 |
|  | (In millions) |
| Raw materials | $ | 5,045 |  |  | $ | 6,111 |  |
| Work-in-progress | 623 |  |  | 705 |  |
| Finished goods | 537 |  |  | 572 |  |
|  | $ | 6,205 |  |  | $ | 7,388 |  |

[0000866374-24-000021:notes:51]
Property and Equipment, Net

[0000866374-24-000021:notes:52]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are depreciated over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment is comprised of the following:

[0000866374-24-000021:notes:53]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2024 |  | 2023 |
|  |  |  | (In millions) |
| Machinery and equipment | 2 - 10 |  | $ | 3,960 |  |  | $ | 3,728 |  |
| Buildings | 30 |  | 1,212 |  |  | 1,162 |  |
| Leasehold improvements | Shorter of lease term or useful life of the improvement |  | 651 |  |  | 586 |  |
| Furniture, fixtures, computer equipment and software, and other | 3 - 7 |  | 549 |  |  | 543 |  |
| Land | — |  | 123 |  |  | 124 |  |
| Construction-in-progress | — |  | 214 |  |  | 399 |  |
|  |  |  | 6,709 |  |  | 6,542 |  |
| Accumulated depreciation and amortization |  |  | (4,440) |  |  | (4,200) |  |
| Property and equipment, net |  |  | $ | 2,269 |  |  | $ | 2,342 |  |

[0000866374-24-000021:notes:54]
Total depreciation expense associated with property and equipment was approximately $428 million, $411 million and $406 million in fiscal years 2024, 2023 and 2022, respectively.

[0000866374-24-000021:notes:55]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-24-000021:notes:56]
Deferred Income Taxes

[0000866374-24-000021:notes:57]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-24-000021:notes:58]
Accounting for Business and Asset Acquisitions

[0000866374-24-000021:notes:59]
The Company has strategically pursued business and asset acquisitions. For business combinations, the fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0000866374-24-000021:notes:60]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-24-000021:notes:61]
Goodwill

[0000866374-24-000021:notes:62]
The Company evaluates goodwill for impairment at the reporting unit level annually, and in certain circumstances such as a change in reporting units or whenever there are indications that goodwill might be impaired. The Company performed its annual goodwill impairment assessment on January 1, 2024 and as a result of the quantitative assessment of its goodwill, the Company determined that no impairment existed as of the date of the impairment test because the fair value of each one of its six reporting units exceeded its respective carrying value.

[0000866374-24-000021:notes:63]
Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market valuations, market multiples for comparable companies as well as a discounted cash flow analysis. Certain of these approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require management to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider the Company's budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of the Company's goodwill.

[0000866374-24-000021:notes:64]
If the recorded value of the assets, including goodwill, and liabilities ("net book value") of any reporting unit exceeds its fair value, an impairment loss may be required to be recognized.

[0000866374-24-000021:notes:65]
The following table summarizes the activity in the Company's goodwill during fiscal years 2024 and 2023:

[0000866374-24-000021:notes:66]
|  |  | FAS |  | FRS |  |  |  | Total |
|  |  | (In millions) |
| Balance at March 31, 2022 |  | $ | 371 |  |  | $ | 767 |  |  |  |  | $ | 1,138 |  |
| Acquisitions (1) |  | — |  |  | (2) |  |  |  |  | (2) |  |
| Foreign currency translation adjustments |  | — |  |  | 3 |  |  |  |  | 3 |  |
| Balance at March 31, 2023 |  | 371 |  |  | 768 |  |  |  |  | 1,139 |  |
| Divestitures (2) |  | — |  |  | (1) |  |  |  |  | (1) |  |
| Foreign currency translation adjustments |  | — |  |  | (3) |  |  |  |  | (3) |  |
| Balance at March 31, 2024 |  | $ | 371 |  |  | $ | 764 |  |  |  |  | $ | 1,135 |  |

[0000866374-24-000021:notes:67]
(1)Represents purchase price adjustment for the acquisition of Anord Mardix in fiscal year 2023.

[0000866374-24-000021:notes:68]
(2)A reduction of approximately $1 million as a result of the divestiture of a non-strategic immaterial business within the FRS segment in fiscal year 2024.

[0000866374-24-000021:notes:69]
Goodwill of $204 million was derecognized as part of the Spin-off in the fiscal year ended March 31, 2024. Following the Spin-off, all assets and liabilities of Nextracker are presented separately and so the $204 million of goodwill is presented in non-current assets of discontinued operations in the consolidated balance sheet as of March 31, 2023 in these financial statements.

[0000866374-24-000021:notes:70]
Other Intangible Assets

[0000866374-24-000021:notes:71]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2024 and concluded that such amounts continued to be recoverable.

[0000866374-24-000021:notes:72]
Intangible assets are comprised of customer-related intangible assets that include contractual agreements and customer relationships, and licenses and other intangible assets that are primarily comprised of licenses, patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight-line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability.

[0000866374-24-000021:notes:73]
The components of acquired intangible assets are as follows:

[0000866374-24-000021:notes:74]
|  | As of March 31, 2024 |  | As of March 31, 2023 |
|  | Weighted-Average Remaining Useful life (in Years) |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  |  |  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | 6.2 |  | $ | 316 |  |  | $ | (186) |  |  | $ | 130 |  |  | $ | 373 |  |  | $ | (204) |  |  | $ | 169 |  |
| Licenses and other intangibles | 5.5 |  | 298 |  |  | (183) |  |  | 115 |  |  | 297 |  |  | (151) |  |  | 146 |  |
| Total |  |  | $ | 614 |  |  | $ | (369) |  |  | $ | 245 |  |  | $ | 670 |  |  | $ | (355) |  |  | $ | 315 |  |

[0000866374-24-000021:notes:75]
Total intangible asset amortization expense recognized in operations during fiscal years 2024, 2023 and 2022 was $70 million, $81 million and $60 million, respectively. The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2024, the gross carrying amounts of fully amortized intangible assets totaled $50 million. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-24-000021:notes:76]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2025 | $ | 63 |  |
| 2026 | 43 |  |
| 2027 | 35 |  |
| 2028 | 27 |  |
| 2029 | 24 |  |
| Thereafter | 53 |  |
| Total amortization expense | $ | 245 |  |

[0000866374-24-000021:notes:77]
The Company owns or licenses various United States and foreign patents relating to a variety of technologies. For certain of the Company's proprietary processes, inventions, and works of authorship, the Company relies on trade secret or copyright protection. The Company also maintains trademark rights (including registrations) for the Company's corporate name and several other trademarks and service marks that the Company uses in the Company's business in the United States and other countries throughout the world. The Company has policies and procedures (including both technological means and training programs for the Company's employees) to identify and protect the Company's intellectual property, as well as that of the Company's customers and suppliers. As of March 31, 2024 and 2023, the carrying value of the Company's intellectual property was not material.

[0000866374-24-000021:notes:78]
Derivative Instruments and Hedging Activities

[0000866374-24-000021:notes:79]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Cash receipts and cash payments related to derivative instruments are recorded in the same category as the cash flows from the items being hedged on the consolidated statements of cash flows. Additional information is included in note 10.

[0000866374-24-000021:notes:80]
Investments

[0000866374-24-000021:notes:81]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other non-current assets. These privately held companies range from startups to more mature companies with established revenue streams and business models. As of March 31, 2024, and March 31, 2023, the Company's investments in non-consolidated companies totaled $123 million and $115 million, respectively.

[0000866374-24-000021:notes:82]
The Company recognized $8 million of net equity in earnings and $4 million of equity in losses, associated with its equity method investments, in equity in earnings of unconsolidated affiliates on the consolidated statement of operations during fiscal years 2024 and 2023, respectively.

[0000866374-24-000021:notes:83]
Non-consolidated investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage generally equal to or greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. Cost method is used for investments where the Company does not have the ability to significantly influence the operating decisions of the investee, or if the Company’s investment is in securities other than common stock or in-substance common stock.

[0000866374-24-000021:notes:84]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy, and require management to make various judgmental assumptions primarily about comparable company multiples and discounted cash flow projections. Some of the inherent estimates and assumptions used in determining the fair value of the investments are outside the control of management. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the investments, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of investments.

[0000866374-24-000021:notes:85]
For investments accounted for under the cost method that do not have readily determinable fair values, the Company measures them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-24-000021:notes:86]
Customer Working Capital Advances

[0000866374-24-000021:notes:87]
Customer working capital advances were $2.2 billion and $2.3 billion, as of March 31, 2024 and 2023, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-24-000021:notes:88]
Other non-current assets

[0000866374-24-000021:notes:89]
Other non-current assets include deferred tax assets of $644 million and $153 million as of March 31, 2024 and 2023, respectively.

[0000866374-24-000021:notes:90]
Other Current Liabilities

[0000866374-24-000021:notes:91]
Other current liabilities include customer-related accruals of $277 million and $301 million as of March 31, 2024 and 2023, respectively.

[0000866374-24-000021:notes:92]
Leases

[0000866374-24-000021:notes:93]
The Company is a lessee with several non-cancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. The Company determines if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the Company has the right to control the use of the identified asset. The Company recognizes a right-of-use (“ROU”) asset and a lease liability at the lease commencement date for the Company's operating leases. For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at the lease commencement date. The Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and non-lease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for the Company's leases, the Company uses the Company's estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company's estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company's leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-24-000021:notes:94]
As of March 31, 2024 and 2023, current operating lease liabilities were $136 million and $124 million, respectively, which are included in other current liabilities on the consolidated balance sheets.

[0000866374-24-000021:notes:95]
Restructuring Charges

[0000866374-24-000021:notes:96]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and reduce excess workforce capacity. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-24-000021:notes:97]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed restructuring plans. See note 16 for additional information regarding restructuring charges.

[0000866374-24-000021:notes:98]
Recently Issued Accounting Pronouncements

[0000866374-24-000021:notes:99]
In March 2024, the FASB issued ASU 2024-02 "Codification Improvements—Amendments to Remove References to the Concepts Statements", which removes various references to concepts statements from the FASB Accounting Standards Codification. This ASU is effective for the Company beginning in the first quarter of fiscal year 2026, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2026.

[0000866374-24-000021:notes:100]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

[0000866374-24-000021:notes:101]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company is currently assessing the impact of ASU 2023-07 on its consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the fourth quarter of fiscal year 2025.

[0000866374-24-000021:notes:102]
In October 2023, the FASB issued ASU 2023-06 "Disclosure Improvements - Codification Amendments in Response to the SEC's Disclosure Update and Simplification Initiative", which amends the disclosure or presentation requirements related to various subtopics in the FASB Accounting Standard Codification (the "Codification"). This ASU will become effective on the date the SEC removes the applicable disclosure from Regulation S-X or Regulation S-K, with early adoption prohibited. If by June 30, 2027, the SEC has not removed the applicable requirement from Regulation S-X or Regulation S-K, the pending content of the related amendment will be removed from the Codification and will not be become effective for any entity. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective.

[0000866374-24-000021:notes:103]
Recently Adopted Accounting Pronouncements

[0000866374-24-000021:notes:104]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance programs. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on roll-forward information which is effective in fiscal year 2025, with early adoption permitted. The Company adopted the guidance retrospectively during the first quarter of fiscal year 2024, including a roll-forward of changes in those obligations, with immaterial impacts on its consolidated financial statements.

[0000866374-24-000021:notes:105]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the receivables' due date. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. We have no economic interest in a supplier’s decision to participate in the supplier finance programs.

[0000866374-24-000021:notes:106]
Obligations under these programs are classified within accounts payable on the consolidated balance sheets, with the associated payments reflected in the operating activities section of the consolidated statement of cash flows. The roll-forward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the fiscal year ended March 31, 2024 is as follows.

[0000866374-24-000021:notes:107]
|  |  | Fiscal Year Ended |
|  |  | March 31, 2024 |
|  |  | (In millions) |
| Confirmed obligations outstanding at the beginning of the year |  | $ | 157 |  |
| Invoices confirmed during the year |  | 604 |  |
| Confirmed invoices paid during the year |  | (643) |  |
| Foreign currency exchange impact |  | 5 |  |
| Confirmed obligations outstanding at the end of the year |  | $ | 123 |  |


## us-gaap:DerivativesPolicyTextBlock

[0000866374-24-000021:notes:108]
Derivative Instruments
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions.
Derivative Instruments and Hedging Activities
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Cash receipts and cash payments related to derivative instruments are recorded in the same category as the cash flows from the items being hedged on the consolidated statements of cash flows.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-24-000021:notes:109]
LEASES
The Company has several commitments under operating leases for warehouses, buildings, and equipment. The Company also has a minimal number of finance leases with an immaterial impact on its consolidated financial statements. Leases have remaining lease terms ranging from approximately 1 year to 20 years.

[0000866374-24-000021:notes:110]
The components of lease cost recognized were as follow (in millions):

[0000866374-24-000021:notes:111]
| Lease cost | Fiscal Year Ended |
|  | March 31, 2024 |  | March 31, 2023 |
| Operating lease cost | $ | 167 |  |  | $ | 149 |  |

[0000866374-24-000021:notes:112]
Amounts reported in the consolidated balance sheet as of the fiscal years ended March 31, 2024 and 2023 were (in millions, except weighted average lease term and discount rate):

[0000866374-24-000021:notes:113]
|  | As of March 31, 2024 |  | As of March 31, 2023 |
| Operating Leases: |  |  |  |
| Operating lease right of use assets | $ | 601 |  | $ | 605 |
| Operating lease liabilities | 626 |  | 628 |
| Weighted-average remaining lease term (In years) |  |  |  |
| Operating leases | 6.3 |  | 6.6 |
| Weighted-average discount rate |  |  |  |
| Operating leases | 4.4 | % |  | 4.3 | % |

[0000866374-24-000021:notes:114]
Other information related to leases was as follow (in millions):

[0000866374-24-000021:notes:115]
|  | Fiscal Year Ended |
|  | March 31, 2024 |  | March 31, 2023 |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 160 |  |  | $ | 149 |  |
| Right‑of‑use assets obtained in exchange for lease liabilities |  |  |  |
| Operating Lease | $ | 134 |  |  | $ | 119 |  |

[0000866374-24-000021:notes:116]
Future lease payments under non-cancellable leases as of March 31, 2024 were as follows (in millions):

[0000866374-24-000021:notes:117]
| Fiscal Year Ended March 31, | Operating Leases |
| 2025 | $ | 160 |  |
| 2026 | 135 |  |
| 2027 | 104 |  |
| 2028 | 88 |  |
| 2029 | 69 |  |
| Thereafter | 157 |  |
| Total undiscounted lease payments | 713 |  |
| Less: imputed interest | 87 |  |
| Total lease liabilities | $ | 626 |  |

[0000866374-24-000021:notes:118]
Total rent expense amounted to $188 million, $182 million, and $178 million in fiscal years 2024, 2023 and 2022, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-24-000021:notes:119]
REVENUE
Revenue Recognition

[0000866374-24-000021:notes:120]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, forecast commitments, emails or other communications that embody the commitment by the customer.

[0000866374-24-000021:notes:121]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract are transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has

[0000866374-24-000021:notes:122]
transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-24-000021:notes:123]
Customer Contracts and Related Obligations

[0000866374-24-000021:notes:124]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-24-000021:notes:125]
Performance Obligations

[0000866374-24-000021:notes:126]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

[0000866374-24-000021:notes:127]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-24-000021:notes:128]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-24-000021:notes:129]
Contract Balances

[0000866374-24-000021:notes:130]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to receivables when rights to payment become unconditional and invoiced.

[0000866374-24-000021:notes:131]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $490 million and $662 million as of March 31, 2024 and 2023, respectively, of which $449 million and $607 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-24-000021:notes:132]
Disaggregation of Revenue

[0000866374-24-000021:notes:133]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time for the fiscal years ended March 31, 2024, 2023 and 2022:

[0000866374-24-000021:notes:134]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |
| Point in time | $ | 12,811 |  |  | $ | 14,942 |  |  | $ | 13,288 |  |
| Over time | 1,112 |  |  | 827 |  |  | 739 |  |
| Total | 13,923 |  |  | 15,769 |  |  | 14,027 |  |
| FRS |  |  |  |  |  |
| Point in time | 11,706 |  |  | 12,004 |  |  | 9,904 |  |
| Over time | 786 |  |  | 729 |  |  | 702 |  |
| Total | 12,492 |  |  | 12,733 |  |  | 10,606 |  |
| Flex |  |  |  |  |  |
| Point in time | 24,517 |  |  | 26,946 |  |  | 23,192 |  |
| Over time | 1,898 |  |  | 1,556 |  |  | 1,441 |  |
| Total | $ | 26,415 |  |  | $ | 28,502 |  |  | $ | 24,633 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-24-000021:notes:135]
SHARE-BASED COMPENSATION
Equity Compensation Plan

[0000866374-24-000021:notes:136]
Flex historically maintains stock-based compensation plans at a corporate level. The Company granted equity compensation awards under its 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-24-000021:notes:137]
Share-Based Compensation Expense

[0000866374-24-000021:notes:138]
The following table summarizes the Company's share-based compensation expense for the 2017 Plan:

[0000866374-24-000021:notes:139]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Cost of sales | $ | 28 |  |  | $ | 24 |  |  | $ | 23 |  |
| Selling, general and administrative expenses | 85 |  |  | 77 |  |  | 65 |  |
| Total share-based compensation expense | $ | 113 |  |  | $ | 101 |  |  | $ | 88 |  |

[0000866374-24-000021:notes:140]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as operating cash flows. During fiscal years 2024, 2023 and 2022, the Company did not recognize any excess tax benefits as an operating cash inflow.

[0000866374-24-000021:notes:141]
The 2017 Plan

[0000866374-24-000021:notes:142]
As of March 31, 2024, the Company had approximately 23.0 million shares available for grant under the 2017 Plan. The Company grants restricted share unit ("RSU") awards under its 2017 Plan. RSU awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. RSU awards generally vest in installments over a two to three-year period and unvested RSU awards are generally forfeited upon termination of employment.

[0000866374-24-000021:notes:143]
Vesting for certain RSU awards is contingent upon both service and market conditions or both service and performance conditions.

[0000866374-24-000021:notes:144]
As of March 31, 2024, the total unrecognized compensation cost related to unvested RSU awards under the 2017 Plan was approximately $173 million. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.0 years. Approximately $14 million of the total unrecognized compensation cost is related to RSU awards

[0000866374-24-000021:notes:145]
granted to certain key employees whereby vesting is contingent on meeting certain market conditions. Approximately $10 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain performance conditions.

[0000866374-24-000021:notes:146]
Determining Fair Value - RSU awards

[0000866374-24-000021:notes:147]
Valuation and Amortization Method—The fair market value of RSU awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-24-000021:notes:148]
Determining Fair Value - RSU awards with service and market conditions

[0000866374-24-000021:notes:149]
Valuation and Amortization Method—The Company estimates the fair value of RSU awards granted under the 2017 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-24-000021:notes:150]
Expected volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the RSU awards granted. The service period is three years for those RSU awards granted in fiscal years 2024, 2023, and 2022.

[0000866374-24-000021:notes:151]
Average peer volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of Flex's peer companies for the RSU awards granted in fiscal years 2024, 2023, and 2022.

[0000866374-24-000021:notes:152]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to Flex's peer companies for the RSU awards granted in fiscal years 2024, 2023, and 2022.

[0000866374-24-000021:notes:153]
Expected Dividend —The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-24-000021:notes:154]
Risk-Free Interest Rate assumptions—The Company bases the risk-free interest rate used in the Monte Carlo simulation on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the RSU awards.

[0000866374-24-000021:notes:155]
The fair value of the Company's RSU awards under the 2017 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2024, 2023, and 2022 was estimated using the following weighted-average assumptions:

[0000866374-24-000021:notes:156]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Expected volatility | 36.9 | % |  | 49.0 | % |  | 54.6 | % |
| Average peer volatility | 35.2 | % |  | 41.4 | % |  | 39.8 | % |
| Average peer correlation | 0.4 |  |  | 0.4 |  |  | 0.4 |  |
| Expected dividends | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 4.3 | % |  | 3.0 | % |  | 0.3 | % |

[0000866374-24-000021:notes:157]
Share-Based Awards Activity

[0000866374-24-000021:notes:158]
The following table summarizes the Company's RSU award activity under the 2017 Plan ("Price" reflects the weighted-average grant-date fair value):

[0000866374-24-000021:notes:159]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested RSU awards outstanding, beginning of fiscal year | 15,348,615 |  |  | $ | 16.79 |  |  | 17,019,559 |  |  | $ | 14.13 |  |  | 17,308,625 |  |  | $ | 11.14 |  |
| Granted (1) | 6,162,067 |  |  | 27.86 |  |  | 8,416,650 |  |  | 18.22 |  |  | 7,276,643 |  |  | 18.48 |  |
| Vested (1) | (8,529,857) |  |  | 14.34 |  |  | (9,229,198) |  |  | 12.51 |  |  | (5,933,605) |  |  | 10.87 |  |
| Forfeited (2) | (994,150) |  |  | 19.76 |  |  | (858,396) |  |  | 15.31 |  |  | (1,632,104) |  |  | 12.42 |  |
| Adjustment due to the Spin-off (3) | 3,380,381 |  |  |  |  | — |  |  |  |  | — |  |  |  |
| Unvested RSU awards outstanding, end of fiscal year (4) | 15,367,056 |  |  | $ | 17.73 |  |  | 15,348,615 |  |  | $ | 16.79 |  |  | 17,019,559 |  |  | $ | 14.13 |  |

[0000866374-24-000021:notes:160]
(1)Included in both the fiscal years 2024 and 2023 amounts are 1.2 million of share bonus awards representing the number of awards achieved above target levels based on the achievement of certain market conditions for awards granted in the fiscal years 2021 and 2020, respectively. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-24-000021:notes:161]
(2)Includes immaterial RSU awards previously granted to Nextracker employees under the 2017 Plan canceled due to the Spin-off.

[0000866374-24-000021:notes:162]
(3)Represents an adjustment to the outstanding RSU awards under the terms of the 2017 Plan using a conversion ratio of approximately 1.29 as a result of the Spin-off.

[0000866374-24-000021:notes:163]
(4)The weighted-average grant date fair value of the RSUs included in the line item “Adjustment due to the Spin-off” is equal to the weighted-average grant date fair value of the awards at their respective grant date divided by a factor of approximately 1.29. The weighted-average grant date fair value of the unvested RSUs as of March 31, 2024 reflects the adjustment.

[0000866374-24-000021:notes:164]
Of the 6.2 million unvested RSU awards granted in fiscal year 2024, approximately 4.3 million are plain-vanilla unvested RSU awards with no performance or market conditions with an average grant date price of $27.29 per share. Further, approximately 0.4 million of these unvested RSU awards granted in fiscal year 2024 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions, with an average grant date fair value estimated to be $35.55 per award calculated using a Monte Carlo simulation. Vesting information for these shares is further detailed in the table below.

[0000866374-24-000021:notes:165]
Of the 15.4 million unvested RSU awards outstanding under the 2017 Plan as of the fiscal year ended March 31, 2024, approximately 1.5 million unvested RSU awards represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-24-000021:notes:166]
|  |  | Targetnumber ofawards as ofMarch 31, 2024(in shares) (1) |  |  |  |  |  | Range of sharesthat may be issued (2) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment dates |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2024 |  | 443,253 |  |  | $ | 35.55 |  |  |  |  | — |  |  | 886,506 |  |  | June 2026 |
| Fiscal 2023 |  | 628,720 |  |  | $ | 23.45 |  |  |  |  | — |  |  | 1,257,440 |  |  | June 2025 |
| Fiscal 2022 |  | 436,006 |  |  | $ | 25.86 |  |  |  |  | — |  |  | 872,012 |  |  | June 2024 |
| Totals |  | 1,507,979 |  |  |  |  |  |  |  |  | 3,015,958 |  |  |  |

[0000866374-24-000021:notes:167]
(1)    Includes an adjustment to the outstanding RSU awards under the terms of the 2017 Plan using a conversion ratio of approximately 1.29 as a result of the Spin-off.

[0000866374-24-000021:notes:168]
(2)    Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against Flex's peer companies for RSU awards granted in fiscal years 2024, 2023 and 2022.

[0000866374-24-000021:notes:169]
The Company will continue to recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2024, 2.3 million shares vested in connection with the awards with market conditions granted in fiscal year 2021.

[0000866374-24-000021:notes:170]
Approximately 0.4 million of these unvested RSU awards granted in fiscal year 2024 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, with an average grant date price of $26.67 per share. Vesting information for these shares is further detailed in the table below.

[0000866374-24-000021:notes:171]
Of the 15.4 million unvested RSU awards outstanding under the 2017 Plan as of the fiscal year ended March 31, 2024, approximately 1.5 million unvested RSU awards represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain performance conditions summarized as follows:

[0000866374-24-000021:notes:172]
|  |  | Targetnumber ofawards as ofMarch 31, 2024(in shares) (1) |  |  |  |  |  | Range of sharesthat may be issued (2) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment date |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2024 |  | 443,253 |  |  | $ | 26.67 |  |  |  |  | — |  |  | 886,506 |  |  | Mar 2027 |
| Fiscal 2023 |  | 628,720 |  |  | $ | 16.52 |  |  |  |  | — |  |  | 1,257,440 |  |  | Mar 2026 |
| Fiscal 2022 |  | 436,003 |  |  | $ | 18.24 |  |  |  |  | — |  |  | 872,006 |  |  | Mar 2025 |
| Totals |  | 1,507,976 |  |  |  |  |  |  |  |  | 3,015,952 |  |  |  |

[0000866374-24-000021:notes:173]
(2)    Vesting ranges from zero to 200% based on performance of Flex's average earnings per share growth.

[0000866374-24-000021:notes:174]
The total intrinsic value of RSU awards vested under the Company's 2017 Plan was $227 million, $148 million and $108 million during fiscal years 2024, 2023 and 2022, respectively, based on the closing price of the Company's ordinary shares on the date vested.

[0000866374-24-000021:notes:175]
Impact from Nextracker Spin-off on Equity Awards

[0000866374-24-000021:notes:176]
Starting from fiscal year 2023, Nextracker granted equity compensation awards to Nextracker employees under the First Amended and Restated 2022 Nextracker LLC Equity Incentive Plan (the "2022 Nextracker Plan"), which was administered by Nextracker, a majority owned subsidiary of the Company prior to the Spin-off. Subsequent to the Spin-off, no stock-based compensation expense for the Nextracker awards granted under the 2022 Nextracker Plan will be included in Flex's consolidated financial statements.

[0000866374-24-000021:notes:177]
In connection with the Spin-off, the Company was required to make certain adjustments to the number of share-based compensation awards under the 2017 Plan using a conversion ratio designed to preserve the intrinsic value of the awards to the holders immediately prior to the Spin-off. Adjustments to the outstanding share-based compensation awards did not result in material additional compensation expense. All outstanding RSU awards under the 2017 Plan for employees transferred to Nextracker were canceled in connection with the Spin-off. The Company did not recognize any compensation cost related to awards held by Nextracker employees post the Spin-off. Approximately $39 million of stock-based compensation expense was recognized in respect of Nextracker employees for fiscal year 2024 (prior to the Spin-off) and is included in net income from discontinued operations, net of tax.


## us-gaap:EarningsPerShareTextBlock

[0000866374-24-000021:notes:178]
EARNINGS PER SHARE
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-24-000021:notes:179]
Diluted earnings per share reflects the potential dilution from share-based compensation awards. The potential dilution from restricted share unit awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-24-000021:notes:180]
The computation of earnings per share and weighted average shares outstanding of the Company’s common stock for the following periods is presented below:

[0000866374-24-000021:notes:181]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions, except per share amounts) |
| Numerator: |  |  |  |  |  |
| Net income from continuing operations | $ | 872 |  |  | $ | 683 |  |  | $ | 872 |  |
| Net income from discontinued operations, net of tax (Note 7) | 373 |  |  | 350 |  |  | 68 |  |
| Less: Net income attributable to noncontrolling interest and redeemable noncontrolling interest (Note 7) | 239 |  |  | 240 |  |  | 4 |  |
| Net income from discontinued operations attributable to Flex Ltd. (Note 7) | 134 |  |  | 110 |  |  | 64 |  |
| Total net income attributable to Flex Ltd. | $ | 1,006 |  |  | $ | 793 |  |  | $ | 936 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding - basic | 435 |  |  | 454 |  |  | 476 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 6 |  |  | 8 |  |  | 7 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding - diluted | 441 |  |  | 462 |  |  | 483 |  |
| Earnings per share - basic |  |  |  |  |  |
| Continuing operations | $ | 2.00 |  |  | $ | 1.50 |  |  | $ | 1.83 |  |
| Discontinued operations, net of tax (Note 7) | 0.31 |  |  | 0.25 |  |  | 0.14 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 2.31 |  |  | $ | 1.75 |  |  | $ | 1.97 |  |
| Earnings per share - diluted |  |  |  |  |  |
| Continuing operations | $ | 1.98 |  |  | $ | 1.48 |  |  | $ | 1.81 |  |
| Discontinued operations, net of tax (Note 7) | 0.30 |  |  | 0.24 |  |  | 0.13 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 2.28 |  |  | $ | 1.72 |  |  | $ | 1.94 |  |

[0000866374-24-000021:notes:182]
_________________________________________________________________________
(1)An immaterial amount of RSU awards during fiscal years 2024, 2023, and 2022, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000866374-24-000021:notes:183]
DISCONTINUED OPERATIONS
On January 2, 2024, Flex completed the Spin-off of our remaining interests in Nextracker to Flex shareholders on a pro-rata basis based on the number ordinary shares of Flex held by each shareholder of Flex as of December 29, 2023, which was the record date of the Distribution.

[0000866374-24-000021:notes:184]
Nextracker's financial results for periods prior to the Spin-off have been reflected in our consolidated statement of operations, retrospectively, as discontinued operations. Details of net income from discontinued operations included in our consolidated statements of operations are as follows:

[0000866374-24-000021:notes:185]
|  | Fiscal Year Ended March 31, |
|  | 2024 (1) |  | 2023 |  | 2022 |
|  | (In millions) |
| Net sales (2) | $ | 1,664 |  |  | $ | 1,844 |  |  | $ | 1,408 |  |
| Cost of sales (2) | 1,198 |  |  | 1,555 |  |  | 1,256 |  |
| Gross profit | 466 |  |  | 289 |  |  | 152 |  |
| Selling, general and administrative expenses | 145 |  |  | 121 |  |  | 62 |  |
| Intangible amortization | — |  |  | 1 |  |  | 8 |  |
| Operating income | 321 |  |  | 167 |  |  | 82 |  |
| Interest, net | 1 |  |  | 1 |  |  | — |  |
| Other charges (income), net | (2) |  |  | (1) |  |  | 1 |  |
| Income before income taxes | 322 |  |  | 167 |  |  | 81 |  |
| (Benefit from) provision for income taxes | (51) |  |  | (183) |  |  | 13 |  |
| Net income from discontinued operations | 373 |  |  | 350 |  |  | 68 |  |
| Net income from discontinued operations attributable to noncontrolling interest and redeemable noncontrolling interest (3) | 239 |  |  | 240 |  |  | 4 |  |
| Net income from discontinued operations attributable to Flex Ltd. | $ | 134 |  |  | $ | 110 |  |  | $ | 64 |  |

[0000866374-24-000021:notes:186]
(1)Represents the financial results for the nine-month period prior to the Spin-off. The financial results for the period from January 1, 2024 to the Spin-off date were immaterial.

[0000866374-24-000021:notes:187]
(2)Both net sales and cost of sales from discontinued operations includes the effect of intercompany transactions that were eliminated from Flex's consolidated operations of approximately $99 million, $59 million, and $50 million for fiscal years ended March 31, 2024, 2023, and 2022, respectively.

[0000866374-24-000021:notes:188]
(3)Net income from discontinued operations attributable to noncontrolling interest represented a share of pre-tax income of $145 million, zero, and zero and of income tax benefits of $94 million, $197 million, and zero and distributions to redeemable noncontrolling interest of zero, $43 million, and $4 million for the fiscal years ended March 31, 2024, 2023, and 2022, respectively. As such, pre-tax income attributable to Flex Ltd. from discontinued operations was $177 million, $167 million and $81 million for the same periods.

[0000866374-24-000021:notes:189]
Details of cash flows from discontinued operations are as follows:

[0000866374-24-000021:notes:190]
|  | Fiscal Year Ended March 31, |
|  | 2024 (1) |  | 2023 |  | 2022 |
|  | (In millions) |
| Net cash provided by (used in) discontinued operations operating activities (2) | $ | 317 |  |  | $ | 108 |  |  | $ | (147) |  |
| Net cash used in discontinued operations investing activities | (4) |  |  | (3) |  |  | (6) |  |

[0000866374-24-000021:notes:191]
(1)Represents the financial results for the nine-month period prior to the Spin-off.

[0000866374-24-000021:notes:192]
(2)Cash flows from discontinued operations operating activities includes the effect of intercompany transactions that were eliminated from Flex's consolidated operations of $54 million, ($23) million, and $11 million for the fiscal years ended March 31, 2024, 2023, and 2022, respectively.

[0000866374-24-000021:notes:193]
The following table summarizes the major classes of assets and liabilities of discontinued operations that were included in the Company's consolidated balance sheet as of March 31, 2023. There were no assets and liabilities of discontinued operations as of March 31, 2024.

[0000866374-24-000021:notes:194]
|  |  |  |  | As of March 31, |
|  |  |  |  | 2023 |
|  |  |  |  | (In millions) |
| Cash and cash equivalents |  |  |  | $ | 130 |  |
| Accounts receivable, net |  |  |  | 271 |  |
| Contract assets |  |  |  | 298 |  |
| Inventories |  |  |  | 142 |  |
| Other current assets |  |  |  | 42 |  |
| Current assets of discontinued operations |  |  |  | $ | 883 |  |
| Property and equipment, net |  |  |  | $ | 7 |  |
| Operating lease right-of-use assets, net |  |  |  | 3 |  |
| Goodwill |  |  |  | 204 |  |
| Other intangible assets, net |  |  |  | 1 |  |
| Other non-current assets |  |  |  | 268 |  |
| Non-current assets of discontinued operations |  |  |  | $ | 483 |  |
| Accounts payable |  |  |  | $ | 206 |  |
| Accrued payroll and benefits |  |  |  | 16 |  |
| Deferred revenue and customer working capital advances |  |  |  | 188 |  |
| Other current liabilities |  |  |  | 103 |  |
| Current liabilities of discontinued operations |  |  |  | $ | 513 |  |
| Long-term debt |  |  |  | $ | 147 |  |
| Operating lease liabilities, non-current |  |  |  | 2 |  |
| Other non-current liabilities |  |  |  | 83 |  |
| Non-current liabilities of discontinued operations |  |  |  | $ | 232 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-24-000021:notes:195]
SUPPLEMENTAL CASH FLOW DISCLOSURES
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-24-000021:notes:196]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 226 |  |  | $ | 227 |  |  | $ | 169 |  |
| Income taxes | 243 |  |  | 124 |  |  | 122 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 97 |  |  | $ | 184 |  |  | $ | 126 |  |
| Pre-IPO paid-in-kind dividend to redeemable noncontrolling interest | — |  |  | 21 |  |  | 4 |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-24-000021:notes:197]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt are as follows:

[0000866374-24-000021:notes:198]
|  | Maturity Date |  | As of March 31, |
|  |  |  | 2024 |  | 2023 |
|  |  |  | (In millions) |
| 4.750% Notes ("2025 Notes") (1)(2) | June 2025 |  | 584 |  |  | 599 |  |
| 3.750% Notes ("2026 Notes") (1)(2) | February 2026 |  | 682 |  |  | 686 |  |
| 6.000% Notes ("2028 Notes") (1)(2) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes ("2029 Notes") (1)(2) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes ("2030 Notes") (1)(2) | May 2030 |  | 681 |  |  | 685 |  |
| JPY Term Loan (3) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (4) | November 2023 |  | — |  |  | 150 |  |
| 3.600% HUF Bonds (5) | December 2031 |  | 274 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (15) |  |  | (18) |  |
|  |  |  | 3,261 |  |  | 3,694 |  |
| Current portion, net of debt issuance costs |  |  | — |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,261 |  |  | $ | 3,544 |  |

[0000866374-24-000021:notes:199]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs.

[0000866374-24-000021:notes:200]
(2)The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

[0000866374-24-000021:notes:201]
(3)In April 2019, the Company entered into a JPY 33.5 billion term loan agreement at three-month TIBOR plus 0.430%, which was then swapped to U.S. dollars. The term loan, which is subject to quarterly interest payments, was used to fund general operations and refinance certain other outstanding debt. During fiscal year 2024, the Company repaid the outstanding balance.

[0000866374-24-000021:notes:202]
(4)In September 2022, the Company entered into a $450 million delayed draw term loan credit agreement, under which $300 million was repaid during fiscal year 2023. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. Interest is based on either (a) a Term SOFR-based formula plus a margin of 100.0 basis points to 162.5 basis points, depending on the Company's credit ratings, or (b) a Base Rate (the greatest of the agent's prime rate, the federal funds rate plus 0.50%, and the Term SOFR plus 1.00%) formula plus a margin of 0.0 basis point to 62.5 basis points, depending on the Company's credit ratings. During fiscal year 2024, the Company repaid the remaining $150 million outstanding balance.

[0000866374-24-000021:notes:203]
(5)In December 2021, the Company issued HUF 100 billion (approximately $274 million as of March 31, 2024) in aggregate principal amount of bonds under the National Bank of Hungary’s Bond Funding for Growth Scheme. The bonds are unsecured and unsubordinated obligations of the Company and rank equally with all of the Company’s other existing and future unsecured and unsubordinated obligations. The outstanding principal amount of the bonds bear interest at 3.60% per annum. The proceeds of the bonds were used for general corporate purposes.

[0000866374-24-000021:notes:204]
Revolving Credit Facilities:

[0000866374-24-000021:notes:205]
In July 2022, the Company entered into a $2.5 billion credit agreement which matures in July 2027 (the "2027 Credit Facility") and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2027 Credit Facility replaced the previous $2.0 billion revolving credit facility, which was due to mature in January 2026. As of March 31, 2024 and 2023, no borrowings were outstanding.

[0000866374-24-000021:notes:206]
Borrowings under the 2027 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate (as defined in the 2027 Credit Facility), plus 1.0% and an applicable margin ranging from 0.125% to 0.750% per annum based on credit ratings or (ii) Term SOFR (or an Alternative Currency Term Rate based on the applicable currency at issue or Alternative Currency Daily Rate based on Sterling Overnight Index Average) plus the applicable margin ranging between 1.125% and 1.750% per annum based on credit ratings, plus an adjustment for Term SOFR loans of 0.10% per annum and an adjustment for Sterling Overnight Index Average loans of 0.0326% per annum. Interest on the outstanding borrowings is payable, (i) in the

[0000866374-24-000021:notes:207]
case of borrowings at the Base Rate, on the last business day of March, June, September and December of each calendar year and the maturity date, (ii) in the case of borrowings at the Term SOFR rate (or Alternative Currency Term Rate), on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month and the maturity date and (iii) in the case of borrowings at the Alternative Currency Daily Rate, on the last day of each calendar month and the maturity date. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2027 Credit Facility ranging from 0.125% to 0.275% per annum, based on credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.125% to 1.750% per annum (based on the credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

[0000866374-24-000021:notes:208]
Under the 2027 Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

[0000866374-24-000021:notes:209]
As of March 31, 2024, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities in the amount of $318 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2024 and 2023. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin.

[0000866374-24-000021:notes:210]
Debt Covenants:

[0000866374-24-000021:notes:211]
Borrowings under the Company’s debt agreements are subject to various covenants that limit the Company’s ability to incur additional indebtedness, sell assets, effect mergers and certain transactions, and effect certain transactions with subsidiaries and affiliates. In addition, the 2027 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio. The Company is also subject to certain covenants requiring the Company to offer to repurchase the 2025 Notes, 2026 Notes, 2028 Notes, 2029 Notes, and 2030 Notes upon a change of control. As of March 31, 2024 and 2023, the Company was in compliance with its debt covenants.

[0000866374-24-000021:notes:212]
The weighted-average interest rates for the Company's long-term debt were 4.5% and 4.6% as of March 31, 2024 and 2023, respectively.

[0000866374-24-000021:notes:213]
Scheduled repayments of the Company's bank borrowings and long-term debt are as follows:

[0000866374-24-000021:notes:214]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2025 | $ | — |  |
| 2026 | 1,266 |  |
| 2027 | — |  |
| 2028 | 397 |  |
| 2029 | 27 |  |
| Thereafter | 1,586 |  |
| Total | $ | 3,276 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-24-000021:notes:215]
FINANCIAL INSTRUMENTS
Foreign Currency Contracts

[0000866374-24-000021:notes:216]
The Company transacts business in various foreign countries and is therefore exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, forecasted sales and cost of sales, and monetary assets and liabilities in currencies other than the functional currency of the operating entity. The Company enters into short-term and long-term foreign currency derivative contracts, including forward, swap, and option contracts, to hedge only those currency exposures associated with certain assets and liabilities,

[0000866374-24-000021:notes:217]
primarily accounts receivable, accounts payable, debt, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and, accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-24-000021:notes:218]
As of March 31, 2024, the aggregate notional amount of the Company's outstanding foreign currency derivative contracts was $8.6 billion as summarized below:

[0000866374-24-000021:notes:219]
|  |  |  | Notional ContractValue in USD |
| Currency |  |  |  |  | Buy |  | Sell |
|  |  |  |  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| HUF |  |  |  |  | $ | 443 |  |  | $ | — |  |
| MXN |  |  |  |  | 609 |  |  | — |  |
| Other |  |  |  |  | 550 |  |  | 20 |  |
|  |  |  |  |  | 1,602 |  |  | 20 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |
| BRL |  |  |  |  | — |  |  | 361 |  |
| CNY |  |  |  |  | 321 |  |  | 84 |  |
| EUR |  |  |  |  | 1,883 |  |  | 1,815 |  |
| MXN |  |  |  |  | 532 |  |  | 448 |  |
| MYR |  |  |  |  | 264 |  |  | 120 |  |
| Other |  |  |  |  | 707 |  |  | 458 |  |
|  |  |  |  |  | 3,707 |  |  | 3,286 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 5,309 |  |  | $ | 3,306 |  |

[0000866374-24-000021:notes:220]
As of March 31, 2024 and 2023, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the consolidated statements of operations. The Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were $19 million as of March 31, 2024, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations primarily over the next twelve-month period, except for gain attributable to changes in fair value of  the USD HUF cross currency swaps, which are discussed below.

[0000866374-24-000021:notes:221]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other current assets and other non-current liabilities as of March 31, 2024 and March 31, 2023, respectively. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-24-000021:notes:222]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2024 and 2023:

[0000866374-24-000021:notes:223]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31,2024 |  | March 31,2023 |  | Balance SheetLocation |  | March 31,2024 |  | March 31,2023 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 45 |  |  | $ | 46 |  |  | Other current liabilities |  | $ | (9) |  |  | $ | 22 |  |
| Foreign currency contracts | Other non-current assets |  | — |  |  | — |  |  | Other non-current liabilities |  | (33) |  |  | 88 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 14 |  |  | $ | 26 |  |  | Other current liabilities |  | $ | (10) |  |  | $ | 19 |  |

[0000866374-24-000021:notes:224]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with certain counterparties. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-24-000021:notes:225]
ACCUMULATED OTHER COMPREHENSIVE LOSS
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2024, 2023 and 2022 are as follows:

[0000866374-24-000021:notes:226]
|  | Unrealized gains (loss) onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Ending balance on March 31, 2021 | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |
| Other comprehensive loss before reclassifications | (49) |  |  | (44) |  |  | (93) |  |
| Net loss reclassified from accumulated other comprehensive loss | 25 |  |  | 5 |  |  | 30 |  |
| Net current-period other comprehensive loss | (24) |  |  | (39) |  |  | (63) |  |
| Ending balance on March 31, 2022 | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |
| Other comprehensive loss before reclassifications | (25) |  |  | (67) |  |  | (92) |  |
| Net loss reclassified from accumulated other comprehensive loss | 77 |  |  | 3 |  |  | 80 |  |
| Net current-period other comprehensive gains (loss) | 52 |  |  | (64) |  |  | (12) |  |
| Ending balance on March 31, 2023 | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |
| Other comprehensive gains (loss) before reclassifications | 95 |  |  | (19) |  |  | 76 |  |
| Net (gains) loss reclassified from accumulated other comprehensive loss | (77) |  |  | — |  |  | (77) |  |
| Net current-period other comprehensive gains (loss) | 18 |  |  | (19) |  |  | (1) |  |
| Ending balance on March 31, 2024 | $ | 4 |  |  | $ | (199) |  |  | $ | (195) |  |

[0000866374-24-000021:notes:227]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the fiscal year 2024 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the consolidated statement of operations, which primarily relate to the Company's foreign currency contracts accounted for as cash flow hedges.
The tax impact to other comprehensive loss was immaterial for all periods presented.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-24-000021:notes:228]
TRADE RECEIVABLES SALES PROGRAMS
The Company sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.8 billion and $0.8 billion as of March 31, 2024 and 2023, respectively. For the fiscal years ended March 31, 2024, 2023 and 2022, total accounts receivable sold to certain third party banking institutions was approximately $3.6 billion, $3.5 billion and $1.6 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and the cash received was included as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-24-000021:notes:229]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-24-000021:notes:230]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of March 31, 2024.

[0000866374-24-000021:notes:231]
Level 2 - Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-24-000021:notes:232]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-24-000021:notes:233]
The Company's cash equivalents include bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-24-000021:notes:234]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other non-current assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-24-000021:notes:235]
Level 3 - Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-24-000021:notes:236]
There were no transfers between levels in the fair value hierarchy during fiscal years 2024 and 2023.

[0000866374-24-000021:notes:237]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-24-000021:notes:238]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2024 and 2023:

[0000866374-24-000021:notes:239]
|  | Fair Value Measurements as of March 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 759 |  |  | $ | — |  |  | $ | 759 |  |
| Foreign currency contracts (Note 10) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (52) |  |  | $ | — |  |  | $ | (52) |  |

[0000866374-24-000021:notes:240]
|  | Fair Value Measurements as of March 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 2,324 |  |  | $ | — |  |  | $ | 2,324 |  |
| Foreign currency contracts (Note 10) | — |  |  | 72 |  |  | — |  |  | 72 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (129) |  |  | $ | — |  |  | $ | (129) |  |

[0000866374-24-000021:notes:241]
Other financial instruments

[0000866374-24-000021:notes:242]
The following table presents the Company's major debts not carried at fair value as of March 31, 2024 and 2023:

[0000866374-24-000021:notes:243]
|  | As of March 31, 2024 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In millions) |  | (In millions) |  |  |
| JPY Term Loan due April 2024 | — |  |  | — |  |  | 253 |  |  | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 584 |  |  | 578 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 682 |  |  | 662 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 404 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 657 |  |  | 643 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 681 |  |  | 662 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan | — |  |  | — |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 274 |  |  | 219 |  |  | 284 |  |  | 196 |  |  | Level 2 |

[0000866374-24-000021:notes:244]
The Notes due June 2025, February 2026, January 2028, June 2029 and May 2030 are valued based on broker trading prices in active markets. HUF Bonds are valued based on the broker trading prices in an inactive market.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-24-000021:notes:245]
COMMITMENTS AND CONTINGENCIES
Commitments

[0000866374-24-000021:notes:246]
As of March 31, 2024 and 2023, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under finance leases, and the related obligations was not material. The Company also leases

[0000866374-24-000021:notes:247]
certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2044. Refer to note 3 for additional details on the minimum lease payments.

[0000866374-24-000021:notes:248]
Litigation and other legal matters

[0000866374-24-000021:notes:249]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-24-000021:notes:250]
The Company is currently involved in a commercial dispute related to a construction matter with related production objectives. Management has assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment has recognized $50 million in Selling, general and administrative expenses in the fiscal quarter ended March 31, 2024 as an accrual. The ultimate resolution of this dispute is uncertain, and the actual outcome may differ from the estimates made by management. Changes in circumstances or additional information may impact the Company’s assessment of its loss and could result in adjustments to the $50 million accrual, however, management currently believes that the resolution of this dispute will not have a material effect on the Company’s financial position, results of operations or cash flows. The Company will continue to monitor developments related to this matter and will adjust its accrual and disclosures accordingly in future reporting periods as additional information becomes available.

[0000866374-24-000021:notes:251]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $84 million based on the exchange rate as of March 31, 2024). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $12 million) and the government lost its appeal on February 21, 2024. The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $52 million). These three assessments are pending appeal by the government. The Company was unsuccessful at the administrative level for the remaining two assessments and filed annulment actions in federal court in Brasilia, Brazil on March 23, 2020 and September 19, 2023, respectively; the updated amount of those assessments inclusive of interest and penalties is approximately 94 million Brazilian reals (approximately USD $19 million). The Company believes that it has meritorious defenses to each of these assessments and will continue to vigorously oppose all of them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-24-000021:notes:252]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter.  On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company received a No Action Letter dated February 22, 2024 from OFAC, stating that OFAC had closed its investigation without taking further action.

[0000866374-24-000021:notes:253]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $221 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-24-000021:notes:254]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material effect on the Company’s financial position, results of operations or cash flows.

[0000866374-24-000021:notes:255]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-24-000021:notes:256]
INCOME TAXES
The domestic (Singapore) and foreign components of income from continuing operations before income taxes were comprised of the following:

[0000866374-24-000021:notes:257]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Domestic | $ | (165) |  |  | $ | 99 |  |  | $ | 352 |  |
| Foreign | 831 |  |  | 708 |  |  | 612 |  |
| Total | $ | 666 |  |  | $ | 807 |  |  | $ | 964 |  |

[0000866374-24-000021:notes:258]
The (benefit from) provision for income taxes from continuing operations consisted of the following:

[0000866374-24-000021:notes:259]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Current: |  |  |  |  |  |
| Domestic | $ | 3 |  |  | $ | 6 |  |  | $ | 3 |  |
| Foreign | 161 |  |  | 117 |  |  | 133 |  |
|  | 164 |  |  | 123 |  |  | 136 |  |
| Deferred: |  |  |  |  |  |
| Domestic | (1) |  |  | 1 |  |  | — |  |
| Foreign | (369) |  |  | — |  |  | (44) |  |
|  | (370) |  |  | 1 |  |  | (44) |  |
| (Benefit from) provision for income taxes | $ | (206) |  |  | $ | 124 |  |  | $ | 92 |  |

[0000866374-24-000021:notes:260]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2024, 2023 and 2022. The reconciliation of the income tax expense (benefit) from continuing operations expected based on domestic statutory income tax rates to the expense (benefit) for income taxes included in the consolidated statements of operations is as follows:

[0000866374-24-000021:notes:261]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Income taxes based on domestic statutory rates | $ | 113 |  |  | $ | 137 |  |  | $ | 164 |  |
| Effect of jurisdictional tax rate differential | 68 |  |  | 52 |  |  | (97) |  |
| Change in unrecognized tax benefit | (10) |  |  | (7) |  |  | 12 |  |
| Change in valuation allowance | (685) |  |  | (290) |  |  | (135) |  |
| Foreign exchange movement on prior year taxes recoverable | (1) |  |  | 4 |  |  | (9) |  |
| Liability for undistributed earnings | 135 |  |  | — |  |  | — |  |
| Global intangible low-taxed income (GILTI) / Subpart F income | 13 |  |  | 18 |  |  | 30 |  |
| Nextracker related transactions gains | 115 |  |  | 158 |  |  | 110 |  |
| Earnings from partnership | 47 |  |  | 39 |  |  | — |  |
| U.S. state taxes | 10 |  |  | 2 |  |  | 5 |  |
| Excess compensation (Section 162(m)) | 15 |  |  | 9 |  |  | 4 |  |
| Other | (26) |  |  | 2 |  |  | 8 |  |
| (Benefit from) provision for income taxes | $ | (206) |  |  | $ | 124 |  |  | $ | 92 |  |

[0000866374-24-000021:notes:262]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2024, 2023 and 2022 was $20 million, $14 million and $23 million, respectively. For the fiscal year ended March 31, 2024, the effect on basic and diluted earnings per share was $0.05, and the effects on basic and diluted earnings per share during fiscal years 2023 and 2022 were $0.03, and $0.05, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in various years through the end of fiscal year 2032.

[0000866374-24-000021:notes:263]
The Company provides a valuation allowance against deferred tax assets that in the Company's estimation are not more likely than not to be realized. During fiscal years 2024, 2023 and 2022, the Company released net valuation allowances totaling $447 million, $6 million and $26 million, respectively. For fiscal year 2024, included in the $447 million net release was a $461 million valuation allowance release related to the Company’s U.S. operations as these amounts were deemed to be more likely than not to be realized. As of each reporting date, the Company considers new evidence, both positive and negative, that could affect its view of the future realization of deferred tax assets. The net deferred tax asset before valuation allowance of the Company’s U.S. group totaled $509 million and $701 million as of March 31, 2024 and 2023, respectively, $358 million and $541 million of which relate to tax loss carryforwards generated in prior years. The Company has, until the current year, carried a valuation allowance ($692 million as of March 31, 2023) against the net deferred tax assets of the U.S. group due to a long-term trend of historical losses as well as unpredictability of U.S. taxable income, particularly with regard to its Nextracker subsidiary. This trend represented negative evidence that outweighed positive evidence of taxable income in the U.S. in fiscal years ended March 31, 2023 and 2022. During fiscal year ended March 31, 2024, the Company has experienced a further year of taxable income in the U.S. and successfully divested its Nextracker business in the fourth quarter, providing greater stability in its U.S. profits and giving visibility to continued taxable income in the U.S. This three-year trend of objective and verifiable taxable income, forecasts showing continued taxable income and removal of uncertainty about Flex’s ownership of Nextracker and the contribution of that business to U.S. taxable income, represent, in the three months and fiscal year ended March 31, 2024, positive evidence that outweighed the negative evidence of historical losses and volatility. This positive evidence enabled the Company to conclude that it is more likely than not that additional deferred taxes of $461 million are realizable. It therefore reduced the valuation allowance accordingly.

[0000866374-24-000021:notes:264]
In addition, various other valuation allowance positions in other jurisdictions were increased or decreased to offset movement in deferred tax positions due to varying factors such as one-time income recognition in loss entities with existing valuation allowances, liquidation of entities with existing valuation allowances, recognition of uncertain tax positions impacting deferred tax assets with existing valuation allowances, foreign exchange impacts on deferred tax balances with existing valuation allowances, and current period losses in legal entities with existing valuation allowance positions. These offsetting

[0000866374-24-000021:notes:265]
changes in the valuation allowance included an increase of $43 million in the fiscal year ended March 31, 2024 and decreases of $254 million and $69 million in the fiscal years ended March 31, 2023 and 2022, respectively.

[0000866374-24-000021:notes:266]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years ended March 31, 2024, 2023 and 2022 were zero, $31 million and $105 million, respectively.

[0000866374-24-000021:notes:267]
The components of deferred income taxes are as follows:

[0000866374-24-000021:notes:268]
|  | As of March 31, |
|  | 2024 |  | 2023 |
|  | (In millions) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (59) |  |  | $ | (63) |  |
| Intangible assets | (56) |  |  | (71) |  |
| Others | (149) |  |  | (23) |  |
| Total deferred tax liabilities | (264) |  |  | (157) |  |
| Deferred tax assets: |  |  |  |
| Fixed assets | 82 |  |  | 77 |  |
| Intangible assets | 4 |  |  | 5 |  |
| Deferred compensation | 25 |  |  | 27 |  |
| Inventory valuation | 26 |  |  | 24 |  |
| Provision for doubtful accounts | 2 |  |  | 3 |  |
| Net operating loss and other carryforwards | 1,168 |  |  | 1,354 |  |
| Tax receivable agreement | 77 |  |  | — |  |
| Others | 184 |  |  | 131 |  |
| Total deferred tax assets | 1,568 |  |  | 1,621 |  |
| Valuation allowances | (838) |  |  | (1,371) |  |
| Total deferred tax assets, net of valuation allowances | 730 |  |  | 250 |  |
| Net deferred tax asset | $ | 466 |  |  | $ | 93 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Long-term asset | $ | 644 |  |  | $ | 164 |  |
| Long-term liability | (178) |  |  | (71) |  |
| Total | $ | 466 |  |  | $ | 93 |  |

[0000866374-24-000021:notes:269]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-24-000021:notes:270]
The Company has recorded deferred tax assets of approximately $1.2 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $436 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-24-000021:notes:271]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
| Fiscal year | (In millions) |
| 2025 - 2030 | $ | 244 |  |
| 2031 - 2036 | 157 |  |
| 2037 and post | 57 |  |
| Indefinite | 741 |  |
|  | $ | 1,199 |  |

[0000866374-24-000021:notes:272]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-24-000021:notes:273]
The Company does not provide for income taxes on approximately $659 million of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. The estimated amount of the unrecognized deferred tax liability on these undistributed earnings is approximately $77 million. During fiscal year 2024, the Company, as part of its regular process, assessed its cash position in overseas territories relative to the levels needed to manage operations and fund future investment in those territories. Following a sustained improvement in the working capital position in China and a trend of customers near shoring their manufacturing operations, management noted that the current and forecasted cash position in China was in excess of levels required to fund the Company’s business in the country. As a result, in the fourth quarter, management declared a dividend of the equivalent of $100 million to be paid from China. This dividend was subject to withholding tax of $10 million and the distribution from China represented a change in intention to indefinitely reinvest earnings in the country. As a result, a deferred tax liability of $135 million was recorded on the remaining distributable earnings from China of approximately $1.4 billion.

[0000866374-24-000021:notes:274]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-24-000021:notes:275]
|  | Fiscal Year EndedMarch 31, |
|  | 2024 |  | 2023 |
|  | (In millions) |
| Balance, beginning of fiscal year | $ | 268 |  |  | $ | 282 |  |
| Additions based on tax position related to the current year | 10 |  |  | 15 |  |
| Additions for tax positions of prior years | 22 |  |  | 8 |  |
| Reductions for tax positions of prior years | (82) |  |  | (5) |  |
| Reductions related to lapse of applicable statute of limitations | (17) |  |  | (13) |  |
| Settlements | — |  |  | (7) |  |
| Impact from foreign exchange rates fluctuation | (4) |  |  | (12) |  |
| Balance, end of fiscal year | $ | 197 |  |  | $ | 268 |  |

[0000866374-24-000021:notes:276]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an additional approximate $24 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-24-000021:notes:277]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2008.

[0000866374-24-000021:notes:278]
Of the $197 million of unrecognized tax benefits at March 31, 2024, $170 million will affect the annual effective tax rate (“ETR”) if the benefits are eventually recognized. The amount that doesn’t impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-24-000021:notes:279]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company’s tax expense. During the fiscal years ended March 31, 2024, 2023 and 2022, the Company recognized interest and penalties of approximately ($2) million, ($1) million and $2 million, respectively. The Company had approximately $13 million, $15 million and $16 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2024, 2023, and 2022, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-24-000021:notes:280]
RESTRUCTURING CHARGES
Fiscal Year 2024

[0000866374-24-000021:notes:281]
During fiscal year 2024, the Company committed to targeted restructuring activities to improve operational efficiency by reducing excess workforce capacity. As a result, the Company recognized approximately $175 million of restructuring charges, most of which related to employee severance. Restructuring charges are not included in segment income, as disclosed further in note 21.

[0000866374-24-000021:notes:282]
Fiscal Year 2023

[0000866374-24-000021:notes:283]
The Company identified certain structural changes to restructure its business throughout fiscal year 2023. During fiscal year 2023, the Company recognized approximately $27 million of restructuring charges, most of which related to employee severance. Restructuring charges are not included in segment income.

[0000866374-24-000021:notes:284]
Fiscal Year 2022

[0000866374-24-000021:notes:285]
The Company identified certain structural changes to restructure its business throughout fiscal year 2022. During fiscal year 2022, the Company recognized approximately $15 million of restructuring charges, most of which related to employee severance. Restructuring charges are not included in segment income.

[0000866374-24-000021:notes:286]
The following table summarizes the provisions for charges incurred, respective payments for the fiscal years ended March 31, 2024, 2023, and 2022, respectively, and remaining accrued balances as of the same periods:

[0000866374-24-000021:notes:287]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2021 | $ | 45 |  |  | $ | — |  |  | $ | 8 |  |  | $ | 53 |  |
| Provision for charges incurred in fiscal year 2022 | 11 |  |  | 1 |  |  | 3 |  |  | 15 |  |
| Cash payments for charges incurred in fiscal year 2021 and prior | (15) |  |  | — |  |  | — |  |  | (15) |  |
| Cash payments for charges incurred in fiscal year 2022 | (6) |  |  | — |  |  | — |  |  | (6) |  |
| Non-cash reductions incurred in fiscal year 2022 | — |  |  | (1) |  |  | (3) |  |  | (4) |  |
| Balance as of March 31, 2022 | 35 |  |  | — |  |  | 8 |  |  | 43 |  |
| Provision for charges incurred in fiscal year 2023 | 27 |  |  | — |  |  | — |  |  | 27 |  |
| Cash payments for charges incurred in fiscal year 2022 and prior | (7) |  |  | — |  |  | — |  |  | (7) |  |
| Cash payments for charges incurred in fiscal year 2023 | (11) |  |  | — |  |  | — |  |  | (11) |  |
| Non-cash reductions incurred in fiscal year 2023 | — |  |  | — |  |  | (2) |  |  | (2) |  |
| Balance as of March 31, 2023 | 44 |  |  | — |  |  | 6 |  |  | 50 |  |
| Provision for charges incurred in fiscal year 2024 | 161 |  |  | 14 |  |  | — |  |  | 175 |  |
| Cash payments for charges incurred in fiscal year 2023 and prior | (13) |  |  | — |  |  | — |  |  | (13) |  |
| Cash payments for charges incurred in fiscal year 2024 | (115) |  |  | — |  |  | — |  |  | (115) |  |
| Non-cash reductions incurred in fiscal year 2024 | — |  |  | (14) |  |  | (3) |  |  | (17) |  |
| Balance as of March 31, 2024 | 77 |  |  | — |  |  | 3 |  |  | 80 |  |
| Less: Current portion (classified as other current liabilities) | 76 |  |  | — |  |  | 3 |  |  | 79 |  |
| Accrued restructuring costs, net of current portion (classified as other non-current liabilities) | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-24-000021:notes:288]
OTHER CHARGES (INCOME), NET
Other charges (income), net for the fiscal years ended March 31, 2024, 2023 and 2022 are comprised of the following:

[0000866374-24-000021:notes:289]
|  | Fiscal Year Ended March 31 |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| (Gain)/Loss on foreign exchange transactions | $ | 24 |  |  | $ | (7) |  |  | $ | (33) |  |
| Brazil tax credit (1) | — |  |  | — |  |  | (150) |  |
| Others | 20 |  | 13 |  | 18 |

[0000866374-24-000021:notes:290]
(1)The Company recognized a $150 million gain related to a certain tax credit upon approval of a "Credit Habilitation" request by the relevant Brazil tax authorities for fiscal year 2022.


## flex:InterestAndOtherNetTextBlock

[0000866374-24-000021:notes:291]
INTEREST EXPENSE AND INTEREST INCOME
Interest expense and interest income for the fiscal years ended March 31, 2024, 2023 and 2022 are primarily comprised of the following:

[0000866374-24-000021:notes:292]
|  | Fiscal Year Ended March 31 |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 161 |  |  | $ | 191 |  |  | $ | 160 |  |
| AR sales programs related expenses | 46 |  |  | 39 |  |  | 6 |  |
| Interest income | (56) |  |  | (30) |  |  | (14) |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000866374-24-000021:notes:293]
BUSINESS AND ASSET ACQUISITIONS & DIVESTITURES
Fiscal 2024 Divestitures

[0000866374-24-000021:notes:294]
During the fiscal year ended March 31, 2024, the Company completed the spin-off of Nextracker. See "Note 7 - Discontinued Operations" for additional information.

[0000866374-24-000021:notes:295]
In addition, the Company disposed of a non-strategic business within the FRS segment and received proceeds of approximately $14 million. The property and equipment and various other assets sold and liabilities transferred were not material to the Company's consolidated financial results. The net loss on dispositions was not material to the Company’s consolidated financial results, and was included in other charges (income), net in the consolidated statements of operations for fiscal year 2024.

[0000866374-24-000021:notes:296]
Fiscal 2023 Divestitures

[0000866374-24-000021:notes:297]
During the fiscal year ended March 31, 2023, the Company disposed of a non-strategic business within the FRS segment and received approximately $4 million of proceeds. The property and equipment and various other assets sold and liabilities transferred were not material to the Company's consolidated financial results. The net gain on dispositions was not material to the Company’s consolidated financial results, and was included in other charges (income), net in the consolidated statements of operations for the fiscal year 2023.

[0000866374-24-000021:notes:298]
Fiscal 2022 Business acquisition

[0000866374-24-000021:notes:299]
On December 1, 2021, the Company completed the business acquisition of Anord Mardix, a global leader in critical power solutions for an initial purchase consideration of $523 million, net of $25 million cash acquired, with an additional $17 million deferred purchase price paid out in the fourth quarter of fiscal year 2022, for a total purchase consideration of $539 million. The acquisition added to the Company's portfolio of Power products and expanded its offering in the data center market. For reporting purposes, Anord Mardix was included in the Industrial reporting unit within the FRS segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill. The results of operations of the acquisition were included in the Company’s consolidated financial results beginning on the date of acquisition, and the total amount of net income and revenue were not material to the Company's consolidated financial results for fiscal year 2022.

[0000866374-24-000021:notes:300]
The intangible assets of $273 million are comprised of customer related intangible assets of $147 million and licenses and other intangible assets such as trade names and developed technology of $126 million. Customer related assets are amortized over a weighted-average estimated useful life of 8.7 years while licensed and other intangibles are amortized over a weighted-average estimated useful life of 8.9 years.


## us-gaap:TreasuryStockTextBlock

[0000866374-24-000021:notes:301]
SHARE REPURCHASE PLAN
During fiscal year 2024, the Company repurchased approximately 50.6 million shares for an aggregate purchase price of approximately $1.3 billion and retired all of these shares. During fiscal year 2024, the Company also retired an additional 50.2 million shares of treasury stock which were repurchased in prior periods, at an aggregate purchase price of $388 million.

[0000866374-24-000021:notes:302]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $2.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 2, 2023. As of March 31, 2024, shares in the aggregate amount of $1.0 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-24-000021:notes:303]
SEGMENT REPORTING
The Company's Chief Executive Officer is our Chief Operating Decision Maker ("CODM") who evaluates how we allocate resources, assess performance and make strategic and operational decisions. Based on such evaluation, the Company determined as of and for the period ended March 31, 2024, that Flex has two operating and reportable segments. During the fourth quarter of fiscal year 2024, following the Spin-off, the Company has classified the results of Nextracker, formerly our Nextracker segment, as discontinued operations in our consolidated statement of income for all periods presented. See note 7 "Discontinued Operations" for additional information.

[0000866374-24-000021:notes:304]
The FAS segment is optimized for speed to market based on a highly flexible supply and manufacturing system. FAS is comprised of the following end markets that represent reporting units:

[0000866374-24-000021:notes:305]
•Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-24-000021:notes:306]
•Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio

[0000866374-24-000021:notes:307]
•Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-24-000021:notes:308]
The FRS segment is optimized for longer product lifecycles requiring complex ramps with specialized production models and critical environments. FRS is comprised of the following end markets that represent reporting units:

[0000866374-24-000021:notes:309]
•Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies

[0000866374-24-000021:notes:310]
•Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-24-000021:notes:311]
•Industrial, including capital equipment, industrial devices, embedded and critical power offerings, and renewables and grid edge.

[0000866374-24-000021:notes:312]
The determination of the separate operating and reporting segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-24-000021:notes:313]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges, customer related asset impairment, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-24-000021:notes:314]
Selected financial information by segment is in the table below.

[0000866374-24-000021:notes:315]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |
| Flex Agility Solutions | $ | 13,923 |  |  | $ | 15,769 |  |  | $ | 14,027 |  |
| Flex Reliability Solutions | 12,492 |  |  | 12,733 |  |  | 10,606 |  |
|  | $ | 26,415 |  |  | $ | 28,502 |  |  | $ | 24,633 |  |
| Segment income and reconciliation of income from continuing operations before income taxes: |  |  |  |  |  |
| Flex Agility Solutions | $ | 669 |  |  | $ | 694 |  |  | $ | 605 |  |
| Flex Reliability Solutions | 666 |  |  | 607 |  |  | 546 |  |
| Corporate and Other | (68) |  |  | (69) |  |  | (81) |  |
| Total segment income | 1,267 |  |  | 1,232 |  |  | 1,070 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 70 |  |  | 81 |  |  | 60 |  |
| Stock-based compensation | 113 |  |  | 101 |  |  | 88 |  |
| Restructuring charges | 172 |  |  | 27 |  |  | 15 |  |
| Customer related asset impairment | 14 |  |  | — |  |  | — |  |
| Legal and other (1) | 45 |  |  | 6 |  |  | 17 |  |
| Interest expenses | 207 |  |  | 230 |  |  | 166 |  |
| Interest income | 56 |  |  | 30 |  |  | 14 |  |
| Other charges (income), net | 44 |  |  | 6 |  |  | (165) |  |
| Equity in earnings (losses) of unconsolidated affiliates | 8 |  |  | (4) |  |  | 61 |  |
| Income from continuing operations before income taxes | $ | 666 |  |  | $ | 807 |  |  | $ | 964 |  |

[0000866374-24-000021:notes:316]
(1)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During fiscal year 2024, the Company recognized a $50 million loss contingency for a commercial dispute related to a construction matter with related production objectives.

[0000866374-24-000021:notes:317]
During fiscal years 2023 and 2022, the Company accrued for certain loss contingencies where losses are considered probable and estimable offset by a gain upon successful settlement of certain supplier claims.

[0000866374-24-000021:notes:318]
Corporate and Other primarily includes corporate service costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-24-000021:notes:319]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled in the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segment nor reported by segment to the Company's CODM.

[0000866374-24-000021:notes:320]
Property and equipment on a segment basis is not separately identified and is not internally reported by segment to the Company's CODM as described above. During fiscal years 2024, 2023 and 2022, depreciation expense included in the segments' measure of operating performance above is as follows.

[0000866374-24-000021:notes:321]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Depreciation expense: |  |  |  |  |  |
| Flex Agility Solutions | $ | 171 |  |  | $ | 177 |  |  | $ | 184 |  |
| Flex Reliability Solutions | 241 |  |  | 217 |  |  | 204 |  |
| Total depreciation expense | $ | 412 |  |  | $ | 394 |  |  | $ | 388 |  |

[0000866374-24-000021:notes:322]
Geographic information of net sales is as follows:

[0000866374-24-000021:notes:323]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 12,232 |  |  | 46 | % |  | $ | 11,906 |  |  | 42 | % |  | $ | 9,414 |  |  | 38 | % |
| Asia | 8,540 |  |  | 32 | % |  | 10,384 |  |  | 36 | % |  | 9,615 |  |  | 39 | % |
| Europe | 5,643 |  |  | 22 | % |  | 6,212 |  |  | 22 | % |  | 5,604 |  |  | 23 | % |
|  | $ | 26,415 |  |  |  |  | $ | 28,502 |  |  |  |  | $ | 24,633 |  |  |  |

[0000866374-24-000021:notes:324]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0000866374-24-000021:notes:325]
During fiscal years 2024, 2023 and 2022, net sales generated from Singapore, the country of domicile, were approximately $660 million, $552 million and $519 million, respectively.

[0000866374-24-000021:notes:326]
The following table summarizes the countries that accounted for more than 10% of net sales in fiscal years 2024, 2023, and 2022:

[0000866374-24-000021:notes:327]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In millions) |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 6,935 |  |  | 26 | % |  | $ | 6,626 |  |  | 23 | % |  | $ | 5,092 |  |  | 21 | % |
| China | 5,117 |  |  | 19 | % |  | 6,562 |  |  | 23 | % |  | 6,160 |  |  | 25 | % |
| U.S. | 3,598 |  |  | 14 | % |  | 3,394 |  |  | 12 | % |  | 2,414 |  |  | 10 | % |

[0000866374-24-000021:notes:328]
No other country accounted for more than 10% of net sales for the fiscal periods presented in the table above.

[0000866374-24-000021:notes:329]
Geographic information of property and equipment, net is as follows:

[0000866374-24-000021:notes:330]
|  | As of March 31, |
|  | 2024 |  | 2023 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Americas | $ | 1,220 |  |  | 54 | % |  | $ | 1,214 |  |  | 52 | % |
| Asia | 565 |  |  | 25 | % |  | 618 |  |  | 26 | % |
| Europe | 484 |  |  | 21 | % |  | 510 |  |  | 22 | % |
|  | $ | 2,269 |  |  |  |  | $ | 2,342 |  |  |  |

[0000866374-24-000021:notes:331]
As of March 31, 2024 and 2023, property and equipment, net held in Singapore was approximately $5 million and $5 million, respectively.

[0000866374-24-000021:notes:332]
The following table summarizes the countries that accounted for more than 10% of property and equipment, net in fiscal years 2024 and 2023:

[0000866374-24-000021:notes:333]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 793 |  |  | 35 | % |  | $ | 763 |  |  | 33 | % |
| U.S. | 334 |  |  | 15 | % |  | 358 |  |  | 15 | % |
| China | 307 |  |  | 14 | % |  | 338 |  |  | 14 | % |

[0000866374-24-000021:notes:334]
No other country accounted for more than 10% of property and equipment, net for the fiscal periods presented in the table above.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-24-000021:notes:335]
During fiscal years 2023 and 2022, the Company accrued for certain loss contingencies where losses are considered probable and estimable offset by a gain upon successful settlement of certain supplier claims. 
During fiscal years 2024, 2023 and 2022, depreciation expense included in the segments' measure of operating performance above is as follows.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000866374-24-000021:notes:336]
NONCONTROLLING INTEREST
On January 2, 2024, the Company completed its previously announced Spin-off of its remaining interests in Nextracker to Flex shareholders on a pro-rata basis based on the number of ordinary shares of Flex held by each shareholder of Flex as of December 29, 2023, which was the record date of the Distribution, pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023.

[0000866374-24-000021:notes:337]
Flex's noncontrolling and redeemable noncontrolling interest related solely to Nextracker. As of March 31, 2024 and 2023, noncontrolling interest was zero and $355 million, respectively. Net income attributable to noncontrolling interest was $239 million, $197 million and zero in fiscal years 2024, 2023, and 2022, respectively. Net income attributable to redeemable noncontrolling interest was zero, $43 million and $4 million in fiscal years 2024, 2023 and 2022, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000866374-24-000021:notes:338]
QUARTERLY FINANCIAL DATA (UNAUDITED)
The Company's third fiscal quarter ends on December 31, and the fourth fiscal quarter and fiscal year ends on March 31 of each year. The first fiscal quarters of 2024 and 2023 ended on June 30, 2023 and July 1, 2022, respectively, and the second fiscal quarters of 2024 and 2023, ended on September 29, 2023 and September 30, 2022, respectively.

[0000866374-24-000021:notes:339]
The Company completed the Spin-off in the fourth quarter of fiscal year 2024, which resulted in material retrospective changes to our consolidated statements of operations. See note 7 "Discontinued Operations" for further information. The following tables contain unaudited quarterly financial data for fiscal year 2024 and 2023:

[0000866374-24-000021:notes:340]
|  | Fiscal Year 2024 |
|  | Three Months Ended |
|  | June 30, 2023 |  | September 29, 2023 |  | December 31, 2023 |  | March 31, 2024 |
|  | (In millions, except per share amounts) |
| Net sales | $ | 6,892 |  |  | $ | 6,933 |  |  | $ | 6,421 |  |  | $ | 6,169 |  |
| Gross profit | 476 |  |  | 519 |  |  | 433 |  |  | 437 |  |
| Operating income | 215 |  |  | 281 |  |  | 198 |  |  | 159 |  |
| Net income from continuing operations | 147 |  |  | 201 |  |  | 129 |  |  | 395 |  |
| Net income from discontinued operations, net of tax | 64 |  |  | 205 |  |  | 104 |  |  | — |  |
| Net income | 211 |  |  | 406 |  |  | 233 |  |  | 395 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 25 |  |  | 178 |  |  | 36 |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 186 |  |  | $ | 228 |  |  | $ | 197 |  |  | $ | 395 |  |
| Weighted-average ordinary shares outstanding - basic | 447 |  | 443 |  | 431 |  | 417 |
| Weighted-average ordinary shares outstanding - diluted | 455 |  | 448 |  | 436 |  | 425 |
| Earnings per share - basic (1) |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.33 |  |  | $ | 0.45 |  |  | $ | 0.30 |  |  | $ | 0.95 |  |
| Discontinued operations, net of tax | 0.09 |  |  | 0.06 |  |  | 0.16 |  |  | — |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.42 |  |  | $ | 0.51 |  |  | $ | 0.46 |  |  | $ | 0.95 |  |
| Earnings per share - diluted (1) |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.32 |  |  | $ | 0.45 |  |  | $ | 0.30 |  |  | $ | 0.93 |  |
| Discontinued operations, net of tax | 0.09 |  |  | 0.06 |  |  | 0.15 |  |  | — |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.41 |  |  | $ | 0.51 |  |  | $ | 0.45 |  |  | $ | 0.93 |  |

[0000866374-24-000021:notes:341]
(1)    Earnings per share are computed independently for each quarter presented; therefore, the sum of the quarterly earnings per share may not equal the total earnings per share amounts for the fiscal year.

[0000866374-24-000021:notes:342]
|  | Fiscal Year 2023 |
|  | Three Months Ended |
|  | July 1, 2022 |  | September 30, 2022 |  | December 31, 2022 |  | March 31, 2023 |
|  | (In millions, except per share amounts) |
| Net sales | $ | 6,961 |  |  | $ | 7,303 |  |  | $ | 7,254 |  |  | $ | 6,984 |  |
| Gross profit | 487 |  |  | 525 |  |  | 499 |  |  | 465 |  |
| Operating income | 253 |  |  | 282 |  |  | 259 |  |  | 223 |  |
| Net income from continuing operations | 176 |  |  | 195 |  |  | 173 |  |  | 139 |  |
| Net income from discontinued operations, net of tax | 19 |  |  | 43 |  |  | 64 |  |  | 224 |  |
| Net income | 195 |  |  | 238 |  |  | 237 |  |  | 363 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 6 |  |  | 6 |  |  | 7 |  |  | 221 |  |
| Net income attributable to Flex Ltd. | $ | 189 |  |  | $ | 232 |  |  | $ | 230 |  |  | $ | 142 |  |
| Weighted-average ordinary shares outstanding - basic | 458 |  | 455 |  | 452 |  | 451 |
| Weighted-average ordinary shares outstanding - diluted | 468 |  | 460 |  | 459 |  | 459 |
| Earnings per share - basic (1) |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.38 |  |  | $ | 0.43 |  |  | $ | 0.38 |  |  | $ | 0.30 |  |
| Discontinued operations, net of tax | 0.03 |  |  | 0.08 |  |  | 0.13 |  |  | 0.01 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.41 |  |  | $ | 0.51 |  |  | $ | 0.51 |  |  | $ | 0.31 |  |
| Earnings per share - diluted (1) |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.38 |  |  | $ | 0.42 |  |  | $ | 0.38 |  |  | $ | 0.30 |  |
| Discontinued operations, net of tax | 0.02 |  |  | 0.08 |  |  | 0.12 |  |  | 0.01 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.40 |  |  | $ | 0.50 |  |  | $ | 0.50 |  |  | $ | 0.31 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000866374-24-000021:notes:343]
On March 5, 2024, Paul R. Lundstrom, Chief Financial Officer, adopted a trading plan that provides for the sale of up to 200,000 ordinary shares of the Company. The plan will terminate on June 13, 2024, subject to early termination for certain specified events set forth in the plan.
