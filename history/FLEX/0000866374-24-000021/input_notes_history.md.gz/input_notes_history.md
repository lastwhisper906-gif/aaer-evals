# FLEX note change history — 0000866374-23-000066 → 0000866374-24-000012


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000866374-24-000012:note_history:1]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $87 million based on the exchange rate as of December 31, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $13 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $54 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes that it has meritorious defenses to each of these assessments and will continue to vigorously oppose all of them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.
  (was, 2023-10-30, similarity 0.9974):
[0000866374-23-000066:note_history:1]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $83 million based on the exchange rate as of September 29, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $12 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $52 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes that it has meritorious defenses to each of these assessments and will continue to vigorously oppose all of them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000866374-24-000012:note_history:2]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of December 31, 2023, Flex's three operating and reportable segments were as follows:
  (was, 2023-10-30, similarity 0.9962):
[0000866374-23-000066:note_history:2]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of September 29, 2023, Flex's three operating and reportable segments were as follows:

- changed (2024-02-02):
[0000866374-24-000012:note_history:3]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions that are used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.
  (was, 2023-10-30, similarity 0.9858):
[0000866374-23-000066:note_history:3]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

- added (2024-02-02):
[0000866374-24-000012:note_history:4]
Nextracker Spin-off

- added (2024-02-02):
[0000866374-24-000012:note_history:5]
On January 2, 2024, the Company completed its previously announced spin-off of its remaining interests in Nextracker (the "Spin-off") to Flex shareholders on a pro-rata basis based on the number ordinary shares of Flex held by each shareholder of Flex (the “Distribution”) as of December 29, 2023, which was the record date of the Distribution, pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023. Refer to note 17, “Subsequent Events” to the condensed consolidated financial statement for further details.

- changed (2024-02-02):
[0000866374-24-000012:note_history:6]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.
  (was, 2023-10-30, similarity 0.9939):
[0000866374-23-000066:note_history:6]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 29, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

- added (2024-02-02):
[0000866374-24-000012:note_history:7]
The third quarters for fiscal years 2024 and 2023 ended on December 31 of each year and are comprised of 93 and 92 days, respectively. The Company's first three quarters for fiscal years 2024 and 2023 both are comprised of 275 days.

- changed (2024-02-02):
[0000866374-24-000012:note_history:8]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest. A controlling financial interest may exist in variable interest entities (“VIEs”), through governance provisions and arrangements to provide services to VIEs. The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The condensed consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of December 31, 2023, we presented noncontrolling interest as permanent equity in the condensed balance sheets, reflecting the equity held by other parties. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the condensed consolidated statements of operations.
  (was, 2023-10-30, similarity 0.8689):
[0000866374-23-000066:note_history:8]
through governance provisions and arrangements to provide services to VIEs. The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The condensed consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of September 29, 2023, we presented noncontrolling interest as permanent equity in the condensed balance sheets, reflecting the equity held by other parties. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the condensed consolidated statements of operations.

- changed (2024-02-02):
[0000866374-24-000012:note_history:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2023-10-30, similarity 0.9892):
[0000866374-23-000066:note_history:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas war), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- added (2024-02-02):
[0000866374-24-000012:note_history:10]
Recently Issued Accounting Pronouncements

- added (2024-02-02):
[0000866374-24-000012:note_history:11]
In October 2023, the FASB issued ASU 2023-06 "Disclosure Improvements - Codification Amendments in Response to the SEC's Disclosure Update and Simplification Initiative", which amends the disclosure or presentation requirements related to various subtopics in the FASB Accounting Standard Codification (the "Codification"). This ASU will become effective on the date the SEC removes the applicable disclosure from Regulation S-X or Regulation S-K, with early adoption prohibited. If by June 30, 2027, the SEC has not removed the applicable requirement from Regulation S-X or Regulation S-K, the pending content of the related amendment will be removed from the Codification and will not be become effective for any entity. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective.

- added (2024-02-02):
[0000866374-24-000012:note_history:12]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the fourth quarter of fiscal year 2025.

- added (2024-02-02):
[0000866374-24-000012:note_history:13]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The

- added (2024-02-02):
[0000866374-24-000012:note_history:14]
Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

- changed (2024-02-02):
[0000866374-24-000012:note_history:15]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The rollforward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the nine-month period ended December 31, 2023 is as follows.
  (was, 2023-10-30, similarity 0.7493):
[0000866374-23-000066:note_history:15]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The

- changed (2024-02-02):
[0000866374-24-000012:note_history:16]
|  | Nine-Month Period Ended |
|  | December 31, 2023 |
|  | (In millions) |
| Confirmed obligations outstanding at the beginning of the period | $ | 275 |  |
| Invoices confirmed during the period | 812 |  |
| Confirmed invoices paid during the period | (897) |  |
| Foreign currency exchange impact | 4 |  |
| Confirmed obligations outstanding at the end of the period | $ | 194 |  |
  (was, 2023-10-30, similarity 0.978):
[0000866374-23-000066:note_history:16]
|  | Six-Month Period Ended |
|  | September 29, 2023 |
|  | (In millions) |
| Confirmed obligations outstanding at the beginning of the period | $ | 275 |  |
| Invoices confirmed during the period | 605 |  |
| Confirmed invoices paid during the period | (556) |  |
| Foreign currency exchange impact | — |  |
| Confirmed obligations outstanding at the end of the period | $ | 324 |  |

- removed (2024-02-02):
[0000866374-23-000066:note_history:17]
The first quarters for fiscal years 2024 and 2023 ended on June 30, 2023, which is comprised of 91 days in the period, and July 1, 2022, which is comprised of 92 days in the period, respectively. The second quarters for fiscal years 2024 and 2023 ended on September 29, 2023 and September 30, 2022, respectively, which are comprised of 91 days in both periods.

- removed (2024-02-02):
[0000866374-23-000066:note_history:18]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest. A controlling financial interest may exist in variable interest entities (“VIEs”),

- removed (2024-02-02):
[0000866374-23-000066:note_history:19]
rollforward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the six-month period ended September 29, 2023 is as follows.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000866374-24-000012:note_history:20]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2023 and March 31, 2023 are as follows:
  (was, 2023-10-30, similarity 0.9789):
[0000866374-23-000066:note_history:20]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 29, 2023 and March 31, 2023 are as follows:

- changed (2024-02-02):
[0000866374-24-000012:note_history:21]
|  | Maturity Date |  | As of December 31, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 592 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 683 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 682 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 290 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (18) |  |  | (21) |  |
|  |  |  | 3,434 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (3) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,431 |  |  | $ | 3,691 |  |
  (was, 2023-10-30, similarity 0.9925):
[0000866374-23-000066:note_history:21]
|  | Maturity Date |  | As of September 29, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 591 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 684 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 683 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 268 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (19) |  |  | (21) |  |
|  |  |  | 3,412 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | — |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,412 |  |  | $ | 3,691 |  |

- changed (2024-02-02):
[0000866374-24-000012:note_history:22]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.7% as of December 31, 2023 and March 31, 2023, respectively.
  (was, 2023-10-30, similarity 0.9805):
[0000866374-23-000066:note_history:22]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.7% as of September 29, 2023 and March 31, 2023, respectively.

- changed (2024-02-02):
[0000866374-24-000012:note_history:23]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2023 are as follows:
  (was, 2023-10-30, similarity 0.9767):
[0000866374-23-000066:note_history:23]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 29, 2023 are as follows:

- changed (2024-02-02):
[0000866374-24-000012:note_history:24]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | 3 |  |
| 2026 |  | 1,275 |  |
| 2027 |  | — |  |
| 2028 |  | 544 |  |
| Thereafter |  | 1,630 |  |
| Total |  | $ | 3,452 |  |
  (was, 2023-10-30, similarity 0.9946):
[0000866374-23-000066:note_history:24]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | — |  |
| 2026 |  | 1,276 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,608 |  |
| Total |  | $ | 3,431 |  |

- changed (2024-02-02):
[0000866374-24-000012:note_history:25]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2024.
  (was, 2023-10-30, similarity 0.9574):
[0000866374-23-000066:note_history:25]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2024.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000866374-24-000012:note_history:26]
|  | As of December 31, 2023 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| JPY Term Loan due April 2024 | $ | — |  |  | $ | — |  |  | $ | 253 |  |  | $ | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 592 |  |  | 585 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 683 |  |  | 662 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 411 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 657 |  |  | 646 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 682 |  |  | 671 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan due November 2023 | — |  |  | — |  |  | 150 |  |  | 150 |  |  | Level 2 |
| Nextracker Term Loan due February 2028 | 150 |  |  | 148 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 290 |  |  | 212 |  |  | 284 |  |  | 196 |  |  | Level 2 |
  (was, 2023-10-30, similarity 0.9958):
[0000866374-23-000066:note_history:26]
|  | As of September 29, 2023 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| JPY Term Loan due April 2024 | $ | — |  |  | $ | — |  |  | $ | 253 |  |  | $ | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 591 |  |  | 577 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 684 |  |  | 648 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 394 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 657 |  |  | 613 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 683 |  |  | 637 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan due November 2023 | — |  |  | — |  |  | 150 |  |  | 150 |  |  | Level 2 |
| Nextracker Term Loan due February 2028 | 150 |  |  | 148 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 268 |  |  | 196 |  |  | 284 |  |  | 196 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000866374-24-000012:note_history:27]
Bank borrowings and long-term debt as of December 31, 2023 and March 31, 2023 are as follows:
  (was, 2023-10-30, similarity 0.9701):
[0000866374-23-000066:note_history:27]
Bank borrowings and long-term debt as of September 29, 2023 and March 31, 2023 are as follows:

- changed (2024-02-02):
[0000866374-24-000012:note_history:28]
|  | Maturity Date |  | As of December 31, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 592 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 683 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 682 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 290 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (18) |  |  | (21) |  |
|  |  |  | 3,434 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (3) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,431 |  |  | $ | 3,691 |  |
  (was, 2023-10-30, similarity 0.9925):
[0000866374-23-000066:note_history:28]
|  | Maturity Date |  | As of September 29, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 591 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 684 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 683 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 268 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (19) |  |  | (21) |  |
|  |  |  | 3,412 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | — |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,412 |  |  | $ | 3,691 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000866374-24-000012:note_history:29]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2023 are as follows:
  (was, 2023-10-30, similarity 0.9767):
[0000866374-23-000066:note_history:29]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 29, 2023 are as follows:

- changed (2024-02-02):
[0000866374-24-000012:note_history:30]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | 3 |  |
| 2026 |  | 1,275 |  |
| 2027 |  | — |  |
| 2028 |  | 544 |  |
| Thereafter |  | 1,630 |  |
| Total |  | $ | 3,452 |  |
  (was, 2023-10-30, similarity 0.9946):
[0000866374-23-000066:note_history:30]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | — |  |
| 2026 |  | 1,276 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,608 |  |
| Total |  | $ | 3,431 |  |

- changed (2024-02-02):
[0000866374-24-000012:note_history:31]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2024.
  (was, 2023-10-30, similarity 0.9574):
[0000866374-23-000066:note_history:31]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2024.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000866374-24-000012:note_history:32]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2023 and December 31, 2022, respectively.
  (was, 2023-10-30, similarity 0.8825):
[0000866374-23-000066:note_history:32]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 29, 2023 and September 30, 2022, respectively.

- changed (2024-02-02):
[0000866374-24-000012:note_history:33]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,152 |  |  | $ | 3,812 |  |  | $ | 9,868 |  |  | $ | 11,378 |  |
| Over time | 314 |  |  | 217 |  |  | 817 |  |  | 646 |  |
| Total | 3,466 |  |  | 4,029 |  |  | 10,685 |  |  | 12,024 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,793 |  |  | 3,038 |  |  | 9,069 |  |  | 8,938 |  |
| Over time | 163 |  |  | 187 |  |  | 492 |  |  | 555 |  |
| Total | 2,956 |  |  | 3,225 |  |  | 9,561 |  |  | 9,493 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 8 |  |  | 33 |  |  | 41 |  |
| Over time | 704 |  |  | 508 |  |  | 1,730 |  |  | 1,343 |  |
| Total | 710 |  |  | 516 |  |  | 1,763 |  |  | 1,384 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,922 |  |  | 6,844 |  |  | 18,871 |  |  | 20,325 |  |
| Over time | 1,181 |  |  | 912 |  |  | 3,039 |  |  | 2,544 |  |
| Total | $ | 7,103 |  |  | $ | 7,756 |  |  | $ | 21,910 |  |  | $ | 22,869 |  |
  (was, 2023-10-30, similarity 0.9828):
[0000866374-23-000066:note_history:33]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,280 |  |  | $ | 3,787 |  |  | $ | 6,716 |  |  | $ | 7,566 |  |
| Over time | 338 |  |  | 217 |  |  | 503 |  |  | 429 |  |
| Total | 3,618 |  |  | 4,004 |  |  | 7,219 |  |  | 7,995 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,144 |  |  | 3,110 |  |  | 6,276 |  |  | 5,900 |  |
| Over time | 170 |  |  | 189 |  |  | 329 |  |  | 368 |  |
| Total | 3,314 |  |  | 3,299 |  |  | 6,605 |  |  | 6,268 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 21 |  |  | 10 |  |  | 27 |  |  | 33 |  |
| Over time | 552 |  |  | 463 |  |  | 1,026 |  |  | 835 |  |
| Total | 573 |  |  | 473 |  |  | 1,053 |  |  | 868 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,411 |  |  | 6,897 |  |  | 12,949 |  |  | 13,481 |  |
| Over time | 1,060 |  |  | 869 |  |  | 1,858 |  |  | 1,632 |  |
| Total | $ | 7,471 |  |  | $ | 7,766 |  |  | $ | 14,807 |  |  | $ | 15,113 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000866374-24-000012:note_history:34]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $755 million and $885 million as of December 31, 2023 and March 31, 2023, respectively, of which $626 million and $795 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.
  (was, 2023-10-30, similarity 0.9912):
[0000866374-23-000066:note_history:34]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $904 million and $885 million as of September 29, 2023 and March 31, 2023, respectively, of which $796 million and $795 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2024-02-02):
[0000866374-24-000012:note_history:35]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2023 and December 31, 2022, respectively.
  (was, 2023-10-30, similarity 0.8825):
[0000866374-23-000066:note_history:35]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 29, 2023 and September 30, 2022, respectively.

- changed (2024-02-02):
[0000866374-24-000012:note_history:36]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,152 |  |  | $ | 3,812 |  |  | $ | 9,868 |  |  | $ | 11,378 |  |
| Over time | 314 |  |  | 217 |  |  | 817 |  |  | 646 |  |
| Total | 3,466 |  |  | 4,029 |  |  | 10,685 |  |  | 12,024 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,793 |  |  | 3,038 |  |  | 9,069 |  |  | 8,938 |  |
| Over time | 163 |  |  | 187 |  |  | 492 |  |  | 555 |  |
| Total | 2,956 |  |  | 3,225 |  |  | 9,561 |  |  | 9,493 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 8 |  |  | 33 |  |  | 41 |  |
| Over time | 704 |  |  | 508 |  |  | 1,730 |  |  | 1,343 |  |
| Total | 710 |  |  | 516 |  |  | 1,763 |  |  | 1,384 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,922 |  |  | 6,844 |  |  | 18,871 |  |  | 20,325 |  |
| Over time | 1,181 |  |  | 912 |  |  | 3,039 |  |  | 2,544 |  |
| Total | $ | 7,103 |  |  | $ | 7,756 |  |  | $ | 21,910 |  |  | $ | 22,869 |  |
  (was, 2023-10-30, similarity 0.9828):
[0000866374-23-000066:note_history:36]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,280 |  |  | $ | 3,787 |  |  | $ | 6,716 |  |  | $ | 7,566 |  |
| Over time | 338 |  |  | 217 |  |  | 503 |  |  | 429 |  |
| Total | 3,618 |  |  | 4,004 |  |  | 7,219 |  |  | 7,995 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,144 |  |  | 3,110 |  |  | 6,276 |  |  | 5,900 |  |
| Over time | 170 |  |  | 189 |  |  | 329 |  |  | 368 |  |
| Total | 3,314 |  |  | 3,299 |  |  | 6,605 |  |  | 6,268 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 21 |  |  | 10 |  |  | 27 |  |  | 33 |  |
| Over time | 552 |  |  | 463 |  |  | 1,026 |  |  | 835 |  |
| Total | 573 |  |  | 473 |  |  | 1,053 |  |  | 868 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,411 |  |  | 6,897 |  |  | 12,949 |  |  | 13,481 |  |
| Over time | 1,060 |  |  | 869 |  |  | 1,858 |  |  | 1,632 |  |
| Total | $ | 7,471 |  |  | $ | 7,766 |  |  | $ | 14,807 |  |  | $ | 15,113 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-02-02):
[0000866374-24-000012:note_history:37]
SUBSEQUENT EVENTS
On January 2, 2024, Flex completed the Spin-off of our remaining interests in Nextracker to Flex shareholders on a pro rata basis based on the number ordinary shares of Flex held by each shareholder of Flex as of December 29, 2023, which was the record date of the Distribution. Under the previously disclosed terms of the Spin-off, Flex shareholders received approximately 0.17 shares of Nextracker Class A common stock for every Flex ordinary share held as of the record date of the Distribution. Flex shareholders received cash in lieu of any fractional shares.

- added (2024-02-02):
[0000866374-24-000012:note_history:38]
As a result of the completion of the Spin-off, Nextracker became a fully independent public company, Flex no longer directly or indirectly holds any shares of Nextracker common stock or any securities convertible into or exchangeable for shares of Nextracker common stock and Flex will no longer consolidate Nextracker into its future financial results. Following the Spin-off, Flex ordinary shares continue to trade on Nasdaq under the ticker symbol “FLEX” and shares of Nextracker Class A common stock continue to trade on Nasdaq under the ticker symbol “NXT”.

- added (2024-02-02):
[0000866374-24-000012:note_history:39]
The historical results of Nextracker will be reported in Flex's consolidated financial statements as discontinued operations beginning in Flex's fourth quarter ending March 31, 2024.

- added (2024-02-02):
[0000866374-24-000012:note_history:40]
Prior to or in connection with the Spin-off, Flex entered into various agreements to effect the Spin-off and provide a framework for the relationship between Flex and Nextracker following the Spin-off, including a Separation Agreement, a Tax Matters Agreement, a Transition Services Agreement, as well as agreements governing future trading relationships.

- removed (2024-02-02):
[0000866374-23-000066:note_history:41]
SUBSEQUENT EVENTS
On October 25, 2023, Flex announced its plan to effect a spin-off of all of its remaining interests in Nextracker to Flex shareholders on a pro rata basis pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023 (the “Merger Agreement”). The spin-off is subject to a number of conditions as set forth in the Merger Agreement, including the approval of Flex shareholders in accordance with Singapore law, and there is no assurance that any such conditions will be satisfied or waived. The spin-off is currently expected to be completed in Flex’s fourth quarter ending March 31, 2024.

- removed (2024-02-02):
[0000866374-23-000066:note_history:42]
On October 25, 2023, the Company’s management committed to targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. While a detailed action plan has not been finalized, the Company currently estimates charges of approximately $100 million will be recognized in the third quarter of the fiscal year ending March 31, 2024. The charges are expected to primarily relate to employee termination benefits and are expected to be settled in cash in the fiscal year ending March 31, 2024.
