# FLEX 8-K — 0000866374-24-000017 filed 2024-05-01

## item codes, every 8-K on or before 2024-05-17

- 2024-05-01 0000866374-24-000017 — 2.02, 2.05, 5.02, 9.01
- 2024-01-31 0000866374-24-000009 — 2.02, 9.01
- 2024-01-02 0000866374-24-000005 — 1.01, 2.01, 7.01, 9.01
- 2023-12-18 0000866374-23-000072 — 8.01, 9.01
- 2023-11-20 0000866374-23-000070 — 5.07, 8.01
- 2023-10-25 0000866374-23-000063 — 2.02, 7.01, 8.01, 9.01
- 2023-08-07 0000866374-23-000060 — 5.02, 5.07, 8.01
- 2023-07-26 0000866374-23-000054 — 2.02, 9.01
- 2023-06-30 0000866374-23-000048 — 8.01, 9.01
- 2023-06-29 0000866374-23-000043 — 8.01, 9.01
- 2023-06-26 0000866374-23-000038 — 8.01, 9.01
- 2023-06-16 0000866374-23-000035 — 5.02
- 2023-05-10 0000866374-23-000023 — 2.02, 9.01
- 2023-02-13 0001193125-23-035922 — 1.01, 9.01
- 2023-02-10 0000866374-23-000016 — 8.01, 9.01
- 2023-02-09 0000866374-23-000014 — 8.01, 9.01
- 2023-02-01 0000866374-23-000011 — 7.01, 8.01, 9.01
- 2023-01-25 0000866374-23-000004 — 2.02, 9.01
- 2022-12-07 0001104659-22-125181 — 1.01, 9.01
- 2022-12-01 0001104659-22-123665 — 8.01, 9.01
- 2022-11-17 0000866374-22-000078 — 8.01
- 2022-10-26 0000866374-22-000070 — 2.02, 9.01
- 2022-09-27 0000866374-22-000066 — 5.02, 9.01
- 2022-08-26 0000866374-22-000063 — 5.07, 8.01
- 2022-07-27 0000866374-22-000048 — 2.02, 9.01
- 2022-07-22 0000866374-22-000045 — 1.01, 1.02, 2.03, 9.01
- 2022-06-03 0000866374-22-000041 — 5.02
- 2022-05-04 0000866374-22-000030 — 2.02, 9.01
- 2022-03-30 0000866374-22-000026 — 7.01, 9.01
- 2022-03-25 0000866374-22-000022 — 5.02
- 2022-02-17 0000866374-22-000019 — 5.02
- 2022-02-02 0000866374-22-000014 — 8.01, 9.01
- 2022-01-27 0000866374-22-000010 — 5.02, 9.01
- 2022-01-26 0000866374-22-000005 — 2.02, 9.01
- 2021-12-01 0000866374-21-000065 — 7.01, 9.01
- 2021-10-27 0000866374-21-000059 — 2.02, 9.01
- 2021-10-18 0000866374-21-000054 — 7.01, 9.01
- 2021-08-05 0000866374-21-000050 — 5.07, 8.01
- 2021-07-29 0000866374-21-000040 — 2.02, 9.01
- 2021-06-15 0000866374-21-000036 — 5.02
- 2021-05-05 0000866374-21-000027 — 2.02, 9.01
- 2021-02-26 0000866374-21-000021 — 5.02
- 2021-01-28 0000866374-21-000016 — 2.02, 9.01
- 2021-01-22 0000866374-21-000012 — 5.02 — amendment of 0000866374-20-000037
- 2021-01-13 0000866374-21-000006 — 1.01, 1.02, 2.03, 9.01
- 2020-11-24 0000866374-20-000037 — 5.02, 9.01
- 2020-11-23 0000866374-20-000034 — 5.02, 7.01, 9.01
- 2020-10-29 0000866374-20-000028 — 2.02, 9.01
- 2020-09-21 0000866374-20-000021 — 5.02, 9.01
- 2020-09-18 0000866374-20-000017 — 5.02
- 2020-08-17 0001104659-20-096092 — 1.01, 8.01, 9.01
- 2020-08-11 0001104659-20-093288 — 5.02, 5.07, 9.01
- 2020-08-07 0001104659-20-092018 — 5.02, 7.01, 9.01
- 2020-07-30 0001104659-20-088503 — 2.02, 9.01
- 2020-06-09 0001104659-20-071371 — 5.02, 9.01
- 2020-06-03 0001104659-20-069435 — 5.02, 9.01
- 2020-05-12 0001104659-20-060179 — 1.01, 8.01, 9.01
- 2020-05-07 0001104659-20-058102 — 2.02, 8.01, 9.01
- 2020-04-20 0000866374-20-000005 — 5.02, 9.01 — amendment of 0001104659-20-044212
- 2020-04-07 0001104659-20-044212 — 5.02, 7.01, 9.01
- 2020-04-02 0001104659-20-042445 — 5.02, 8.01, 9.01
- 2020-03-09 0001104659-20-030489 — 7.01, 9.01
- 2020-01-30 0001104659-20-008704 — 2.02, 9.01
- 2019-11-07 0001104659-19-061133 — 8.01, 9.01
- 2019-10-24 0001104659-19-056135 — 2.02, 9.01
- 2019-08-23 0001410578-19-000891 — 3.03, 5.07, 8.01, 9.01
- 2019-08-08 0001410578-19-000722 — 8.01
- 2019-07-25 0001104659-19-041852 — 2.02, 2.05, 9.01
- 2019-06-10 0001410578-19-000371 — 5.02
- 2019-06-06 0001104659-19-034315 — 1.01, 8.01, 9.01
- 2019-05-31 0001104659-19-032835 — 8.01, 9.01
- 2019-05-30 0001104659-19-032818 — 8.01, 9.01
- 2019-05-30 0001104659-19-032593 — 8.01, 9.01
- 2019-04-30 0001104659-19-025293 — 2.02, 9.01
- 2019-03-07 0001104659-19-013420 — 5.02
- 2019-02-11 0001104659-19-006978 — 5.02, 7.01, 9.01
- 2019-02-06 0001104659-19-005884 — 5.02
- 2019-01-30 0001104659-19-004485 — 2.02, 9.01
- 2019-01-18 0001104659-19-002495 — 5.02
- 2018-12-28 0001104659-18-075143 — 5.02
- 2018-12-11 0001104659-18-072382 — 5.02
- 2018-11-15 0001104659-18-068678 — 5.02, 9.01
- 2018-10-25 0001104659-18-063948 — 2.02, 9.01
- 2018-10-25 0001104659-18-063944 — 5.02, 9.01
- 2018-08-21 0001104659-18-053031 — 5.07, 8.01, 9.01
- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2024-05-17

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0000866374-24-000017:8k_2_02:1]
EX-99.1
2
flexex991-512024.htm
EX-99.1

[0000866374-24-000017:8k_2_02:2]
Document

[0000866374-24-000017:8k_2_02:3]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:4]
EXHIBIT 99.1

[0000866374-24-000017:8k_2_02:5]
FLEX REPORTS FOURTH QUARTER AND FISCAL 2024 RESULTS AND

[0000866374-24-000017:8k_2_02:6]
HOSTS INVESTOR AND ANALYST DAY

[0000866374-24-000017:8k_2_02:7]
Austin, Texas, May 1, 2024 – Flex (NASDAQ: FLEX) today announced results for its fourth quarter and fiscal year ended March 31, 2024.

[0000866374-24-000017:8k_2_02:8]
Fourth Quarter Fiscal Year 2024 Highlights:

[0000866374-24-000017:8k_2_02:9]
•Net Sales: $6.2 billion

[0000866374-24-000017:8k_2_02:10]
•GAAP Operating Income: $159 million

[0000866374-24-000017:8k_2_02:11]
•Adjusted Operating Income: $333 million

[0000866374-24-000017:8k_2_02:12]
•GAAP Net Income from continuing operations: $395 million

[0000866374-24-000017:8k_2_02:13]
•Adjusted Net Income from continuing operations: $244 million

[0000866374-24-000017:8k_2_02:14]
•GAAP Earnings Per Share from continuing operations: $0.93

[0000866374-24-000017:8k_2_02:15]
•Adjusted Earnings Per Share from continuing operations: $0.57

[0000866374-24-000017:8k_2_02:16]
Fiscal Year 2024 Results of Continuing Operations (excluding contribution from Nextracker):

[0000866374-24-000017:8k_2_02:17]
•Net Sales: $26.4 billion

[0000866374-24-000017:8k_2_02:18]
•GAAP Operating Income: $853 million

[0000866374-24-000017:8k_2_02:19]
•Adjusted Operating Income: $1,267 million

[0000866374-24-000017:8k_2_02:20]
•GAAP Net Income from continuing operations: $872 million

[0000866374-24-000017:8k_2_02:21]
•Adjusted Net Income from continuing operations: $947 million

[0000866374-24-000017:8k_2_02:22]
•GAAP Earnings Per Share from continuing operations: $1.98

[0000866374-24-000017:8k_2_02:23]
•Adjusted Earnings Per Share from continuing operations: $2.15

[0000866374-24-000017:8k_2_02:24]
As a result of the spin-off of Nextracker in the fourth quarter of fiscal year 2024, Nextracker's historical results of operations and balance sheets for periods prior to the spin-off are presented as discontinued operations.

[0000866374-24-000017:8k_2_02:25]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedules II and V attached to this press release.

[0000866374-24-000017:8k_2_02:26]
“We delivered another quarter and fiscal year of solid performance, including strong margin expansion and EPS growth,” said Revathi Advaithi, CEO of Flex. “Our results show that we can effectively navigate through the cycle and increase value to our stakeholders.”

[0000866374-24-000017:8k_2_02:27]
First Quarter Fiscal 2025 Guidance

[0000866374-24-000017:8k_2_02:28]
•Revenue: $5.6 billion to $6.2 billion

[0000866374-24-000017:8k_2_02:29]
•GAAP Operating Income: $130 million to $170 million

[0000866374-24-000017:8k_2_02:30]
•Adjusted Operating Income: $240 million to $280 million

[0000866374-24-000017:8k_2_02:31]
•GAAP EPS: $0.11 to $0.19

[0000866374-24-000017:8k_2_02:32]
•Adjusted EPS: $0.37 to $0.45 which excludes $0.16 for restructuring charges, $0.07 for stock-based compensation expense, and $0.03 for net intangible amortization

[0000866374-24-000017:8k_2_02:33]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:34]
Fiscal Year 2025 Guidance

[0000866374-24-000017:8k_2_02:35]
•Revenue: $25.4 billion to $26.4 billion

[0000866374-24-000017:8k_2_02:36]
•GAAP EPS: $1.61 to $1.81

[0000866374-24-000017:8k_2_02:37]
•Adjusted EPS: $2.30 to $2.50 which excludes $0.31 for stock-based compensation expense, $0.25 for restructuring charges, and $0.13 for net intangible amortization

[0000866374-24-000017:8k_2_02:38]
Webcast and Conference Call

[0000866374-24-000017:8k_2_02:39]
The Flex management team will host a conference call today at 7:30 AM (CT) / 8:30 AM (ET) to review fourth quarter and fiscal 2024 results. Additionally, as previously announced, Flex's CEO, Revathi Advaithi, will be joined by other members of the leadership team to discuss how the company is delivering on its commitments, outline strategic initiatives to drive profitable growth, and provide an update on the long-term financial framework. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com. An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0000866374-24-000017:8k_2_02:40]
About Flex

[0000866374-24-000017:8k_2_02:41]
Flex (Reg. No. 199002645H) is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across 30 countries and responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets.

[0000866374-24-000017:8k_2_02:42]
Contacts

[0000866374-24-000017:8k_2_02:43]
Investors & Analysts

[0000866374-24-000017:8k_2_02:44]
David Rubin

[0000866374-24-000017:8k_2_02:45]
Vice President, Investor Relations

[0000866374-24-000017:8k_2_02:46]
(408) 577-4632

[0000866374-24-000017:8k_2_02:47]
David.Rubin@flex.com

[0000866374-24-000017:8k_2_02:48]
Media & Press

[0000866374-24-000017:8k_2_02:49]
Yvette Lorenz

[0000866374-24-000017:8k_2_02:50]
Director, Corporate PR and Executive Communications

[0000866374-24-000017:8k_2_02:51]
(415) 225-7315

[0000866374-24-000017:8k_2_02:52]
Yvette.Lorenz@flex.com

[0000866374-24-000017:8k_2_02:53]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:54]
Forward-Looking Statements

[0000866374-24-000017:8k_2_02:55]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:56]
incur significant legal and financial exposure and disrupt our operations; physical and operational risks from natural disasters, severe weather events, or climate change; our ability to meet environmental, social and governance expectations or standards or achieve sustainability goals; we may be exposed to product liability and product warranty liability; that recently proposed changes or future changes in tax laws in certain jurisdictions where we operate could materially impact our tax expense; and the impact and effects on our business, results of operations and financial condition of a public health issue, including a pandemic, or catastrophic event.

[0000866374-24-000017:8k_2_02:57]
Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our most recent Annual Report on 
Form 10-K and in our subsequent filings with the U.S. Securities and Exchange Commission. Flex assumes no obligation to update any forward-looking statements, which speak only as of the date they are made.

[0000866374-24-000017:8k_2_02:58]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:59]
SCHEDULE I

[0000866374-24-000017:8k_2_02:60]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In millions, except per share amounts) |
|  |  | Three-Month Periods Ended |
|  |  | March 31, 2024 |  | March 31, 2023 |
| GAAP: |  |  |  |
|  | Net sales | $ | 6,169 |  |  | $ | 6,984 |  |
|  | Cost of sales | 5,658 |  |  | 6,501 |  |
|  | Restructuring charges | 74 |  |  | 18 |  |
|  | Gross profit | 437 |  |  | 465 |  |
|  | Selling, general and administrative expenses | 261 |  |  | 218 |  |
|  | Restructuring charges | 1 |  |  | 4 |  |
|  | Intangible amortization | 16 |  |  | 20 |  |
|  | Operating income | 159 |  |  | 223 |  |
|  | Interest expense | 52 |  |  | 63 |  |
|  | Interest income | 12 |  |  | 13 |  |
|  | Other charges (income), net | 8 |  |  | 7 |  |
|  | Equity in earnings (losses) of unconsolidated affiliates | 6 |  |  | (1) |  |
|  | Income from continuing operations before income taxes | 117 |  |  | 165 |  |
|  | Provision for (benefit from) income taxes | (278) |  |  | 26 |  |
|  | Net income from continuing operations | 395 |  |  | 139 |  |
|  | Net income from discontinued operations, net of tax | — |  |  | 224 |  |
|  | Net income | 395 |  |  | 363 |  |
|  | Net income attributable to noncontrolling interest and redeemable noncontrolling interest | — |  |  | 221 |  |
|  | Net income attributable to Flex Ltd. | $ | 395 |  |  | $ | 142 |  |
| GAAP EPS: |
|  | Diluted earnings per share from continuing operations | $ | 0.93 |  |  | $ | 0.30 |  |
|  | Diluted earnings per share from discontinued operations | — |  |  | 0.01 |  |
|  | Diluted earnings per share attributable to the shareholders of Flex Ltd. | $ | 0.93 |  |  | $ | 0.31 |  |
|  | Diluted shares used in computing per share amounts | 425 |  |  | 459 |  |

[0000866374-24-000017:8k_2_02:61]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:62]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In millions, except per share amounts) |
|  |  | Twelve-Month Periods Ended |
|  |  | March 31, 2024 |  | March 31, 2023 |  | March 31, 2022 |
| GAAP: |  |  |  |  |  |
|  | Net sales | $ | 26,415 |  |  | $ | 28,502 |  |  | $ | 24,633 |  |
|  | Cost of sales | 24,395 |  |  | 26,503 |  |  | 22,838 |  |
|  | Restructuring charges | 155 |  |  | 23 |  |  | 15 |  |
|  | Gross profit | 1,865 |  |  | 1,976 |  |  | 1,780 |  |
|  | Selling, general and administrative expenses | 922 |  |  | 874 |  |  | 830 |  |
|  | Restructuring charges | 20 |  |  | 4 |  |  | — |  |
|  | Intangible amortization | 70 |  |  | 81 |  |  | 60 |  |
|  | Operating income | 853 |  |  | 1,017 |  |  | 890 |  |
|  | Interest expense | 207 |  |  | 230 |  |  | 166 |  |
|  | Interest income | 56 |  |  | 30 |  |  | 14 |  |
|  | Other charges (income), net | 44 |  |  | 6 |  |  | (165) |  |
|  | Equity in earnings (losses) of unconsolidated affiliates | 8 |  |  | (4) |  |  | 61 |  |
|  | Income from continuing operations before income taxes | 666 |  |  | 807 |  |  | 964 |  |
|  | Provision for (benefit from) income taxes | (206) |  |  | 124 |  |  | 92 |  |
|  | Net income from continuing operations | 872 |  |  | 683 |  |  | 872 |  |
|  | Net income from discontinued operations, net of tax | 373 |  |  | 350 |  |  | 68 |  |
|  | Net income | 1,245 |  |  | 1,033 |  |  | 940 |  |
|  | Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 239 |  |  | 240 |  |  | 4 |  |
|  | Net income attributable to Flex Ltd. | $ | 1,006 |  |  | $ | 793 |  |  | $ | 936 |  |
| GAAP EPS: |  |  |
|  | Diluted earnings per share from continuing operations | $ | 1.98 |  |  | $ | 1.48 |  |  | $ | 1.81 |  |
|  | Diluted earnings per share from discontinued operations | 0.30 |  |  | 0.24 |  |  | 0.13 |  |
|  | Diluted earnings per share attributable to the shareholders of Flex Ltd. | $ | 2.28 |  |  | $ | 1.72 |  |  | $ | 1.94 |  |
|  | Diluted shares used in computing per share amounts | 441 |  |  | 462 |  |  | 483 |  |

[0000866374-24-000017:8k_2_02:63]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:64]
SCHEDULE II

[0000866374-24-000017:8k_2_02:65]
| FLEX |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1) |
| (In millions, except per share amounts) |
|  |  | Three-Month Periods Ended |
|  |  | March 31, 2024 |  | March 31, 2023 |
| GAAP operating income | $ | 159 |  |  | $ | 223 |  |
|  | Intangible amortization | 16 |  |  | 20 |  |
|  | Stock-based compensation expense | 27 |  |  | 25 |  |
|  | Restructuring charges | 75 |  |  | 22 |  |
|  | Customer related asset impairment | 14 |  |  | — |  |
|  | Legal and other | 42 |  |  | 3 |  |
| Non-GAAP operating income | 333 |  |  | 293 |  |
| GAAP provision for (benefit from) income taxes | (278) |  |  | 26 |  |
|  | Intangible amortization benefit | 2 |  |  | 3 |  |
|  | Tax benefit on release of U.S. valuation allowance | 461 |  |  | — |  |
|  | Tax expense on foreign subsidiaries indefinite reinvestment assertion change | (135) |  |  | — |  |
|  | Other tax related adjustments | (9) |  |  | 4 |  |
| Non-GAAP provision for income taxes | 41 |  |  | 33 |  |
| GAAP net income from continuing operations | 395 |  |  | 139 |  |
|  | Intangible amortization | 16 |  |  | 20 |  |
|  | Stock-based compensation expense | 27 |  |  | 25 |  |
|  | Restructuring charges | 75 |  |  | 22 |  |
|  | Customer related asset impairment | 14 |  |  | — |  |
|  | Legal and other | 42 |  |  | 3 |  |
|  | Equity in earnings (losses) of unconsolidated affiliates | (6) |  |  | (1) |  |
|  | Adjustments for taxes | (319) |  |  | (7) |  |
| Non-GAAP net income from continuing operations | 244 |  |  | 201 |  |
| Diluted earnings per share from continuing operations: |
|  | GAAP | $ | 0.93 |  |  | $ | 0.30 |  |
|  | Non-GAAP | $ | 0.57 |  |  | $ | 0.44 |  |
|  | See the accompanying notes on Schedule V attached to this press release. |

[0000866374-24-000017:8k_2_02:66]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:67]
| FLEX |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1) |
| (In millions, except per share amounts) |
|  |  | Twelve-Month Periods Ended |
|  |  | March 31, 2024 |  | March 31, 2023 |  | March 31, 2022 |
| GAAP operating income | 853 |  |  | 1,017 |  |  | 890 |  |
|  | Intangible amortization | 70 |  |  | 81 |  |  | 60 |  |
|  | Stock-based compensation expense | 113 |  |  | 101 |  |  | 88 |  |
|  | Restructuring charges | 172 |  |  | 27 |  |  | 15 |  |
|  | Customer related asset impairment | 14 |  |  | — |  |  | — |  |
|  | Legal and other | 45 |  |  | 6 |  |  | 17 |  |
| Non-GAAP operating income | $ | 1,267 |  |  | $ | 1,232 |  |  | $ | 1,070 |  |
| GAAP provision for (benefit from) income taxes | (206) |  |  | 124 |  |  | 92 |  |
|  | Intangible amortization benefit | 11 |  |  | 12 |  |  | 10 |  |
|  | Tax benefit on release of U.S. valuation allowance | 461 |  |  | — |  |  | — |  |
|  | Tax expense on foreign subsidiaries indefinite reinvestment assertion change | (135) |  |  | — |  |  | — |  |
|  | Other tax related adjustments | 7 |  |  | (1) |  |  | 28 |  |
| Non-GAAP provision for income taxes | $ | 138 |  |  | $ | 135 |  |  | $ | 130 |  |
| GAAP net income from continuing operations | 872 |  |  | 683 |  |  | 872 |  |
|  | Intangible amortization | 70 |  |  | 81 |  |  | 60 |  |
|  | Stock-based compensation expense | 113 |  |  | 101 |  |  | 88 |  |
|  | Restructuring charges | 172 |  |  | 27 |  |  | 15 |  |
|  | Customer related asset impairment | 14 |  |  | — |  |  | — |  |
|  | Legal and other | 45 |  |  | 6 |  |  | 17 |  |
|  | Interest and other, net | 11 |  |  | 4 |  |  | (135) |  |
|  | Equity in earnings (losses) of unconsolidated affiliates | (6) |  |  | (1) |  |  | (32) |  |
|  | Adjustments for taxes | (344) |  |  | (11) |  |  | (38) |  |
| Non-GAAP net income from continuing operations | $ | 947 |  |  | $ | 890 |  |  | $ | 847 |  |
| Diluted earnings per share from continuing operations: |
|  | GAAP | $ | 1.98 |  |  | $ | 1.48 |  |  | $ | 1.81 |  |
|  | Non-GAAP | $ | 2.15 |  |  | $ | 1.93 |  |  | $ | 1.75 |  |
|  | See the accompanying notes on Schedule V attached to this press release. |  |  |

[0000866374-24-000017:8k_2_02:68]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:69]
SCHEDULE III

[0000866374-24-000017:8k_2_02:70]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
|  |  | As of March 31, 2024 |  | As of March 31, 2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
|  | Cash and cash equivalents | $ | 2,474 |  |  | $ | 3,164 |  |
|  | Accounts receivable, net of allowance for doubtful accounts | 3,033 |  |  | 3,480 |  |
|  | Contract assets | 249 |  |  | 243 |  |
|  | Inventories | 6,205 |  |  | 7,388 |  |
|  | Other current assets | 1,031 |  |  | 875 |  |
|  | Current assets of discontinued operations | — |  |  | 883 |  |
| Total current assets | 12,992 |  |  | 16,033 |  |
| Property and equipment, net | 2,269 |  |  | 2,342 |  |
| Operating lease right-of-use assets, net | 601 |  |  | 605 |  |
| Goodwill | 1,135 |  |  | 1,139 |  |
| Other intangible assets, net | 245 |  |  | 315 |  |
| Other non-current assets | 1,015 |  |  | 490 |  |
| Non-current assets of discontinued operations | — |  |  | 483 |  |
| Total assets | $ | 18,257 |  |  | $ | 21,407 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |
|  | Bank borrowings and current portion of long-term debt | $ | — |  |  | $ | 150 |  |
|  | Accounts payable | 4,468 |  |  | 5,724 |  |
|  | Accrued payroll and benefits | 488 |  |  | 506 |  |
|  | Deferred revenue and customer working capital advances | 2,615 |  |  | 2,955 |  |
|  | Other current liabilities | 968 |  |  | 1,019 |  |
|  | Current liabilities of discontinued operations | — |  |  | 513 |  |
| Total current liabilities | 8,539 |  |  | 10,867 |  |
| Long-term debt, net of current portion | 3,261 |  |  | 3,544 |  |
| Operating lease liabilities, non-current | 490 |  |  | 504 |  |
| Other non-current liabilities | 642 |  |  | 554 |  |
| Non-current liabilities of discontinued operations | — |  |  | 232 |  |
| Total liabilities | 12,932 |  |  | 15,701 |  |
| Total Flex Ltd. shareholders' equity | 5,325 |  |  | 5,351 |  |
| Noncontrolling interest of discontinued operations | — |  |  | 355 |  |
| Total shareholders' equity | 5,325 |  |  | 5,706 |  |
| Total liabilities and shareholders' equity | $ | 18,257 |  |  | $ | 21,407 |  |

[0000866374-24-000017:8k_2_02:71]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:72]
SCHEDULE IV

[0000866374-24-000017:8k_2_02:73]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
|  |  | Twelve-Month Periods Ended |
|  |  | March 31, 2024 |  | March 31, 2023 |  | March 31, 2022 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
|  | Net income | $ | 1,245 |  |  | $ | 1,033 |  |  | $ | 936 |  |
|  | Depreciation, amortization and other impairment charges | 537 |  |  | 501 |  |  | 484 |  |
|  | Changes in working capital and other, net | (456) |  |  | (584) |  |  | (396) |  |
|  | Net cash provided by operating activities | 1,326 |  |  | 950 |  |  | 1,024 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |
|  | Purchases of property and equipment | (530) |  |  | (635) |  |  | (443) |  |
|  | Proceeds from the disposition of property and equipment | 25 |  |  | 20 |  |  | 11 |  |
|  | Acquisitions of businesses, net of cash acquired | — |  |  | 2 |  |  | (539) |  |
|  | Other investing activities, net | 13 |  |  | 9 |  |  | 20 |  |
|  | Net cash used in investing activities | (492) |  |  | (604) |  |  | (951) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |
|  | Proceeds from bank borrowings and long-term debt | 2 |  |  | 718 |  |  | 759 |  |
|  | Repayments of bank borrowings and long-term debt | (409) |  |  | (1,024) |  |  | (284) |  |
|  | Payments for repurchases of ordinary shares | (1,298) |  |  | (337) |  |  | (686) |  |
|  | Proceeds from issuances of Nextracker shares | 552 |  |  | 694 |  |  | — |  |
|  | Payment for pre-IPO dividend to redeemable noncontrolling interest | — |  |  | (22) |  |  | — |  |
|  | Payment for purchase of Nextracker LLC units from TPG | (57) |  |  | — |  |  | — |  |
|  | Capital reduction from Nextracker spin off | (368) |  |  | — |  |  | — |  |
|  | Proceeds from sale of subsidiary's redeemable preferred units | — |  |  | — |  |  | 488 |  |
|  | Other financing activities, net | (78) |  |  | (27) |  |  | 3 |  |
|  | Net cash provided by (used in) financing activities | (1,656) |  |  | 2 |  |  | 280 |  |
| Effect of exchange rates on cash and cash equivalents | 2 |  |  | (18) |  |  | (26) |  |
|  | Net increase in cash and cash equivalents | (820) |  |  | 330 |  |  | 327 |  |
|  | Cash and cash equivalents, beginning of year | 3,294 |  |  | 2,964 |  |  | 2,637 |  |
|  | Cash and cash equivalents, end of year | $ | 2,474 |  |  | $ | 3,294 |  |  | $ | 2,964 |  |

[0000866374-24-000017:8k_2_02:74]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:75]
SCHEDULE V

[0000866374-24-000017:8k_2_02:76]
FLEX AND SUBSIDIARIES

[0000866374-24-000017:8k_2_02:77]
NOTES TO SCHEDULE II

[0000866374-24-000017:8k_2_02:78]
(1)To supplement Flex’s unaudited selected financial data presented consistent with U.S. Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges and gains, including non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share. These supplemental measures exclude certain legal and other charges, restructuring charges, customer-related asset impairments (recoveries), stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP and may be different from non-GAAP measures used by other companies. We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures. The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures. We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0000866374-24-000017:8k_2_02:79]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures. Also, when evaluating potential acquisitions, we exclude certain items described below from consideration of the target’s performance and valuation. Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results. We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0000866374-24-000017:8k_2_02:80]
•the ability to make more meaningful period-to-period comparisons of the Company’s ongoing operating results;

[0000866374-24-000017:8k_2_02:81]
•the ability to better identify trends in the Company’s underlying business and perform related trend analysis;

[0000866374-24-000017:8k_2_02:82]
•a better understanding of how management plans and measures the Company’s underlying business; and

[0000866374-24-000017:8k_2_02:83]
•an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0000866374-24-000017:8k_2_02:84]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0000866374-24-000017:8k_2_02:85]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of unvested restricted share unit awards granted to employees and assumed in business acquisitions. The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types. In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0000866374-24-000017:8k_2_02:86]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:87]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions. The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures. The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0000866374-24-000017:8k_2_02:88]
Restructuring charges include severance charges at existing sites and corporate SG&A functions as well as asset impairment, and other charges related to the closures and consolidations of certain operating sites and targeted activities to restructure the business. These costs may vary in size based on the Company’s initiatives, are not directly related to ongoing or core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0000866374-24-000017:8k_2_02:89]
During the three and twelve-month periods ended March 31, 2024, the Company recognized approximately $75 million and $172 million of restructuring charges, respectively, most of which related to employee severance. During the three and twelve-month periods ended March 31, 2023, the Company recognized approximately $22 million and $27 million of restructuring charges, respectively, most of which related to employee severance. During the twelve-month period ended March 31, 2022, the Company recognized approximately $15 million of restructuring charges, most of which related to employee severance.

[0000866374-24-000017:8k_2_02:90]
Customer related asset impairments may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. During the three and twelve-month periods ended March 31, 2024, the Company recognized approximately $14 million of customer related asset impairments. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0000866374-24-000017:8k_2_02:91]
Legal and other consist primarily of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs. During the fourth quarter and for the fiscal years ended March 31, 2024, 2023, and 2022, the Company accrued for certain loss contingencies where losses were considered probable and estimable. During the fourth quarter of fiscal year 2024, the Company accrued $50 million related to a commercial dispute related to a construction matter with related production objectives. In the fiscal year ended March 31, 2022, the Company recognized a net $17 million loss accrual related to settled litigation claims partially offset by the successful settlement of certain supplier claims. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0000866374-24-000017:8k_2_02:92]
Interest and other, net consist of various other types of items that are not directly related to ongoing or core business results, such as the gain or losses related to certain divestitures, currency translation reserve write-offs upon liquidation of certain legal entities, and debt extinguishment costs. The Company excludes these items because they are not related to the Company’s ongoing operating performance or do not affect core operations. Excluding these amounts provides investors with a basis to compare Company performance against the performance of other companies without this variability.

[0000866374-24-000017:8k_2_02:93]
P R E S S   R E L E A S E

[0000866374-24-000017:8k_2_02:94]
In fiscal year 2022, the Company received approval from the relevant tax authorities in Brazil of the Credit Habilitation request related to certain federal operational tax credits and the Company recorded a total gain of 809.6 million Brazilian reals (approximately USD $149.3 million based on the exchange rate as of October 1, 2021) under other charges (income), net in the condensed statements of operations. The total gain recorded included credits from February 2003 to September 2021, net of additional taxes, as the Credit Habilitation received covering the period from February 2003 to December 2019 resolved any uncertainty regarding the Company's ability to claim such credits. This gain is non-cash and has been used to offset tax obligations.

[0000866374-24-000017:8k_2_02:95]
Equity in earnings (losses) of unconsolidated affiliates consists of various other types of items that are not directly related to ongoing or core business results, such as gains (losses) associated with certain non-core investments. The Company excludes these items because they are not related to the Company’s ongoing operating performance or do not affect core operations. Excluding these amounts provides investors with a basis to compare Company performance against the performance of other companies without this variability. In fiscal years 2022 and 2024, the Company recognized approximately $32 million and $6 million, respectively, equity in earnings from the value increases in certain non-core investment funds. No such significant events occurred in fiscal year 2023.

[0000866374-24-000017:8k_2_02:96]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies or other non-recurring tax charges, when applicable. During the three and twelve-month periods ended March 31, 2024, the Company recorded $319 million and $344 million net benefits, respectively, of which the majority relates to a $461 million benefit from a release of a valuation allowance previously applied to the Company’s U.S. deferred tax assets, partially offset by an expense of $135 million reflecting a change in the Company’s assertion to indefinitely reinvest its earnings in China. During fiscal year 2022, the Company recorded a $19 million benefit for the release of valuation allowances on certain of its deferred tax assets due to its acquisition of the Anord Mardix business. No such significant events occurred in fiscal year 2023.

## item 5.02 — body, verbatim

[0000866374-24-000017:8k_body:1]
Item 5.02. Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0000866374-24-000017:8k_body:2]
(b) On April 29, 2024, Michael D. Capellas, Chair of the Company's Board of Directors (the “Board”), informed the Board of his decision not to stand for re-election to the Board at the Company’s 2024 Annual General Meeting of shareholders to be held on August 8, 2024. Mr. Capellas’ decision not to stand for re-election is not due to any disagreement with the Company on any matter relating to its operations, policies, or practices. The Company is very grateful to Mr. Capellas for his valuable contributions during his many years of dedicated Board service.

[0000866374-24-000017:8k_body:3]
William D. Watkins, a current independent director of the Board, has been appointed by the Board to serve as Chair of the Board effective upon the conclusion of the 2024 Annual General Meeting of shareholders, subject to his re-election to the Board at the meeting.

[0000866374-24-000017:8k_body:4]
A copy of the press release announcing these changes is attached hereto as Exhibit 99.2 and is incorporated herein by reference.
