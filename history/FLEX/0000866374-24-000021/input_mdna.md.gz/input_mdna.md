# FLEX MD&A — 0000866374-24-000021


## mdna

[0000866374-24-000021:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-24-000021:mdna:2]
OVERVIEW

[0000866374-24-000021:mdna:3]
We are the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we support our customers' entire product lifecycle with a broad array of services in every major region. Our full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. We partner with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of March 31, 2024, as a result of the Spin-off in the fourth quarter of fiscal year 2024, we now report our financial performance based on two operating and reportable segments as follows:

[0000866374-24-000021:mdna:4]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-24-000021:mdna:5]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-24-000021:mdna:6]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio

[0000866374-24-000021:mdna:7]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-24-000021:mdna:8]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-24-000021:mdna:9]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies

[0000866374-24-000021:mdna:10]
◦Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-24-000021:mdna:11]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings, and renewables and grid edge.

[0000866374-24-000021:mdna:12]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product lifecycle.

[0000866374-24-000021:mdna:13]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solution requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0000866374-24-000021:mdna:14]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-24-000021:mdna:15]
We believe that our strategy is positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-24-000021:mdna:16]
We are continuously evaluating our capital structure in response to the current environment and expect that our current financial condition, including our liquidity sources are adequate to fund future commitments. See additional discussion in the Liquidity and Capital Resources section below.

[0000866374-24-000021:mdna:17]
38

[0000866374-24-000021:mdna:18]
Nextracker Spin-off

[0000866374-24-000021:mdna:19]
On February 13, 2023, our former subsidiary, Nextracker completed an initial public offering (the “IPO”) of its Class A common stock and on July 3, 2023 completed a follow-on offering to the IPO. Prior to the IPO, we maintained an 82.6% indirect ownership in Nextracker and consolidated Nextracker. Subsequent to the IPO and follow-on offering, we retained a 51.5% indirect ownership in Nextracker and continued to consolidate Nextracker and report Nextracker as an operating segment.

[0000866374-24-000021:mdna:20]
On January 2, 2024, we completed the previously announced Spin-off to Flex shareholders on a pro-rata basis based on the number ordinary shares of Flex held by each shareholder of Flex (the “Distribution”) as of December 29, 2023, which was the record date of the Distribution, pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023. Under the terms of the Spin-off, Flex shareholders received approximately 0.17 shares of Nextracker Class A common stock for each Flex ordinary share held as of the record date of the Distribution. Flex shareholders received cash in lieu of any fractional shares.

[0000866374-24-000021:mdna:21]
As a result of the completion of the Spin-off, Nextracker became a fully independent public company, we no longer directly or indirectly hold any shares of Nextracker common stock or any securities convertible into or exchangeable for shares of Nextracker common stock and subsequent to the third quarter ended December 31, 2023 we no longer consolidate Nextracker into our financial results. Flex ordinary shares continue to trade on Nasdaq under the ticker symbol “FLEX” and shares of Nextracker Class A common stock continue to trade on Nasdaq under the ticker symbol “NXT”.

[0000866374-24-000021:mdna:22]
The historical financial results and financial position of Nextracker are presented as discontinued operations in the consolidated statements of operations and balance sheets for all periods presented. The historical statements of comprehensive income and cash flows and the balances related to stockholders’ equity have not been revised to reflect the effect of the Spin-off. See note 7 "Discontinued Operations" to the consolidated financial statements in Item 8, “Financial Statements and Supplementary Data” for further information. Unless otherwise indicated, any reference to income statement items in this "Management’s Discussion and Analysis of Financial Condition and Results of Operations" refers to results from continuing operations.

[0000866374-24-000021:mdna:23]
Update on Component Shortages and Logistical Constraints on our Business

[0000866374-24-000021:mdna:24]
Component shortages and logistical constraints improved as the year progressed. We continue to monitor potential supply chain disruptions, including disruptions in international commerce as a result of attacks on shipping vessels in the Red Sea. Refer to “Risk Factors - Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, have in the past affected, and may in the future affect, our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory.”

[0000866374-24-000021:mdna:25]
Russian Invasion of Ukraine and Israel-Hamas War

[0000866374-24-000021:mdna:26]
We continue to monitor and respond to the conflict in Ukraine and the associated sanctions and other restrictions. We also are monitoring and responding to the Israel-Hamas war. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine and Israel. The full impact of the conflicts on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflicts and their impact on regional and global economic conditions. We will continue to monitor the conflicts and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-24-000021:mdna:27]
Business Overview

[0000866374-24-000021:mdna:28]
We are one of the world's largest providers of global supply chain solutions, with revenues from continuing operations of $26.4 billion in the fiscal year ended March 31, 2024. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of approximately 100 facilities in approximately 30 countries across four continents. As of March 31, 2024, our total manufacturing capacity was approximately 27 million square feet. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment, by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-24-000021:mdna:29]
39

[0000866374-24-000021:mdna:30]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |  |  |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 12,232 |  |  | 46 | % |  | $ | 11,906 |  |  | 42 | % |  | $ | 9,414 |  |  | 38 | % |  |  |  |  |
| Asia | 8,540 |  |  | 32 | % |  | 10,384 |  |  | 36 | % |  | 9,615 |  |  | 39 | % |  |  |  |  |
| Europe | 5,643 |  |  | 22 | % |  | 6,212 |  |  | 22 | % |  | 5,604 |  |  | 23 | % |  |  |  |  |
|  | $ | 26,415 |  |  |  |  | $ | 28,502 |  |  |  |  | $ | 24,633 |  |  |  |  |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 6,935 |  |  | 26 | % |  | $ | 6,626 |  |  | 23 | % |  | $ | 5,092 |  |  | 21 | % |  |  |  |  |
| China | 5,117 |  |  | 19 | % |  | 6,562 |  |  | 23 | % |  | 6,160 |  |  | 25 | % |  |  |  |  |
| U.S. | 3,598 |  |  | 14 | % |  | 3,394 |  |  | 12 | % |  | 2,414 |  |  | 10 | % |  |  |  |  |
| Malaysia | 2,122 |  |  | 8 | % |  | 2,448 |  |  | 9 | % |  | 1,866 |  |  | 8 | % |  |  |  |  |
| Brazil | 1,529 |  |  | 6 | % |  | 1,769 |  |  | 6 | % |  | 1,842 |  |  | 7 | % |  |  |  |  |
| Hungary | 1,368 |  |  | 5 | % |  | 1,310 |  |  | 5 | % |  | 1,230 |  |  | 5 | % |  |  |  |  |
| Other | 5,746 |  |  | 22 | % |  | 6,393 |  |  | 22 | % |  | 6,029 |  |  | 24 | % |  |  |  |  |
|  | $ | 26,415 |  |  |  |  | $ | 28,502 |  |  |  |  | $ | 24,633 |  |  |  |  |  |  |  |

[0000866374-24-000021:mdna:31]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 793 |  |  | 35 | % |  | $ | 763 |  |  | 33 | % |
| U.S. | 334 |  |  | 15 | % |  | 358 |  |  | 15 | % |
| China | 307 |  |  | 14 | % |  | 338 |  |  | 14 | % |
| Malaysia | 142 |  |  | 6 | % |  | 152 |  |  | 6 | % |
| Hungary | 124 |  |  | 5 | % |  | 140 |  |  | 6 | % |
| Brazil | 88 |  |  | 4 | % |  | 89 |  |  | 4 | % |
| Other | 481 |  |  | 21 | % |  | 502 |  |  | 22 | % |
|  | $ | 2,269 |  |  |  |  | $ | 2,342 |  |  |  |

[0000866374-24-000021:mdna:32]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we offer our customers the ability to simplify their global product development, manufacturing process, and after-sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-24-000021:mdna:33]
Our operating results are affected by a number of factors, including the following:

[0000866374-24-000021:mdna:34]
•global economic conditions, including inflationary pressures, currency volatility, slower growth or recession, higher interest rates, and geopolitical uncertainty (including arising from the ongoing conflict between Russia and Ukraine and the Israel-Hamas war);

[0000866374-24-000021:mdna:35]
•the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, and other factors;

[0000866374-24-000021:mdna:36]
•the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance;

[0000866374-24-000021:mdna:37]
40

[0000866374-24-000021:mdna:38]
•our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers;

[0000866374-24-000021:mdna:39]
•the effects on our business due to certain customers' products having short product lifecycles, our customers' ability to cancel or delay orders or change production quantities or locations, the short-term nature of our customers' commitments and rapid changes in demand;

[0000866374-24-000021:mdna:40]
•the effects that current credit and market conditions (including as a result of the ongoing conflict between Russia and Ukraine and the Israel-Hamas war) could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-24-000021:mdna:41]
•the impacts on our business due to supply chain issues, including component shortages, disruptions in transportation or other supply chain related constraints including disruptions in international commerce as a result of attacks on shipping vessels in the Red Sea;

[0000866374-24-000021:mdna:42]
•integration of acquired businesses and facilities;

[0000866374-24-000021:mdna:43]
•increased labor costs due to adverse labor conditions in the markets we operate;

[0000866374-24-000021:mdna:44]
•changes in tax legislation;

[0000866374-24-000021:mdna:45]
•changes in trade regulations and treaties; and

[0000866374-24-000021:mdna:46]
•exposure to infectious disease, epidemics and pandemics on our business operations in geographic locations impacted by an outbreak and on the business operations of our customers and suppliers.

[0000866374-24-000021:mdna:47]
We also are subject to other risks as outlined in Item 1A, "Risk Factors".

[0000866374-24-000021:mdna:48]
Net sales for fiscal year 2024 decreased approximately 7%, or $2.1 billion, to $26.4 billion from the prior year. Net sales for our FAS segment decreased $1.8 billion, or 12%, from the prior year, primarily driven by a decrease in net sales of 24% in our Consumer Devices business, a 17% decrease in our Lifestyle business and a 7% decrease in our CEC business due to softer demand in consumer end markets and difficult year-over-year comparisons in CEC. Net sales for our FRS segment decreased $0.2 billion, or 2%, from the prior year, primarily driven by a decrease in net sales of 8% in our Industrial business due to lower customer demand, partially offset by a 6% increase in our Automotive business and a 3% increase in our Health Solutions business which benefited from ramps across various end markets. Our fiscal year 2024 gross profit totaled $1.9 billion, representing a decrease of $0.1 billion, or 6%, from the prior year. The decrease in gross profit due to lower sales was mitigated by higher gross profit margins and the $0.1 billion gross profit decrease was primarily driven by $0.1 billion in higher restructuring charges. Our net income totaled $0.9 billion, representing an increase of $0.2 billion, or 28%, compared to fiscal year 2023, due to the factors explained above and a net $0.2 billion income tax benefit in fiscal year 2024 attributed primarily to the release of a U.S. deferred tax asset valuation allowance.

[0000866374-24-000021:mdna:49]
Cash provided by operating activities increased by approximately $0.4 billion primarily driven by the $0.2 billion increase in net income and improvement in net working capital, offset by a change in deferred income taxes.

[0000866374-24-000021:mdna:50]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. Our adjusted free cash flow was $0.8 billion and $0.3 billion for fiscal years 2024 and 2023, respectively. Refer to the Liquidity and Capital Resources section for the adjusted free cash flows reconciliation to the most directly comparable GAAP financial measure of cash flows from operations. Cash used in investing activities decreased by approximately $0.1 billion to a cash outflow of $0.5 billion for fiscal year 2024, compared with a cash outflow of $0.6 billion for fiscal year 2023, primarily due to a decrease of approximately $0.1 billion cash paid for purchases of property and equipment in fiscal year 2024. Cash provided by financing activities decreased by approximately $1.7 billion to a cash outflow of $1.7 billion for fiscal year 2024, primarily driven by an approximately $1.0 billion increase in cash paid for share repurchases, a $0.4 billion increase in capital reduction as part of the Spin-off, a $0.1 billion increase in net debt payment, along with a $0.1 billion decrease in proceeds from the issuance of Nextracker shares in fiscal year 2024 compared to fiscal year 2023.

[0000866374-24-000021:mdna:51]
CRITICAL ACCOUNTING ESTIMATES

[0000866374-24-000021:mdna:52]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas war), there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-24-000021:mdna:53]
We believe the following critical accounting estimates affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-24-000021:mdna:54]
Revenue Recognition

[0000866374-24-000021:mdna:55]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assess whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when we have transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-24-000021:mdna:56]
Customer Contracts and Related Obligations

[0000866374-24-000021:mdna:57]
Certain of our customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. We estimate the variable consideration related to these price adjustments as part of the total transaction price and recognize revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. We constrain the amount of revenues recognized for these contractual provisions based on our best estimate of the amount which will not result in a significant reversal of revenue in a future period. We determine the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-24-000021:mdna:58]
Inventory Valuation

[0000866374-24-000021:mdna:59]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand and anticipated component shortages, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regards to inventory procured to fulfill customer demand.

[0000866374-24-000021:mdna:60]
42

[0000866374-24-000021:mdna:61]
Carrying Value of Long-Lived Assets

[0000866374-24-000021:mdna:62]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. An impairment loss is recognized when the carrying amount of the asset group exceeds its fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such asset groups are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, the general business environment and other factors including geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas war), which remain highly uncertain and unpredictable. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize material impairment charges in the future.

[0000866374-24-000021:mdna:63]
Goodwill

[0000866374-24-000021:mdna:64]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require us to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider our budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA market comparables and credit ratings. While we believe we have made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If our actual results are not consistent with our estimates and assumptions used to calculate fair value, it could result in material impairments of our goodwill. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail on our goodwill.

[0000866374-24-000021:mdna:65]
Income Taxes

[0000866374-24-000021:mdna:66]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-24-000021:mdna:67]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-24-000021:mdna:68]
43

[0000866374-24-000021:mdna:69]
RESULTS OF OPERATIONS

[0000866374-24-000021:mdna:70]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data." As further discussed in note 2 to the consolidated financial statements in Item 8, as a result of the Spin-off in the fourth quarter of fiscal year 2024, the historical results of operations and balance sheets for periods prior to the Spin-off are presented as discontinued operations in these consolidated financial statements. For comparability purposes, the prior periods have been recast to conform to the current presentation.

[0000866374-24-000021:mdna:71]
The data below, and discussion that follows, represents our results from operations, and relative percentages.

[0000866374-24-000021:mdna:72]
|  | Fiscal Year EndedMarch 31, |
|  | 2024 |  | 2023 |  | 2022 |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |  |
| Cost of sales | 92.4 |  |  | 93.0 |  |  | 92.7 |  |  |  |
| Restructuring charges | 0.5 |  |  | 0.1 |  |  | 0.1 |  |  |  |
| Gross profit | 7.1 |  |  | 6.9 |  |  | 7.2 |  |  |  |
| Selling, general and administrative expenses | 3.5 |  |  | 3.1 |  |  | 3.4 |  |  |  |
| Intangible amortization | 0.3 |  |  | 0.2 |  |  | 0.2 |  |  |  |
| Restructuring charges | 0.1 |  |  | — |  |  | — |  |  |  |
| Operating income | 3.2 |  |  | 3.6 |  |  | 3.6 |  |  |  |
| Interest expense | 0.8 |  |  | 0.8 |  |  | 0.7 |  |  |  |
| Interest income | 0.2 |  |  | — |  |  | 0.1 |  |  |  |
| Other charges (income), net | 0.2 |  |  | — |  |  | (0.7) |  |  |  |
| Equity in earnings (losses) of unconsolidated affiliates | 0.1 |  |  | — |  |  | 0.2 |  |  |  |
| Income from continuing operations before income taxes | 2.5 |  |  | 2.8 |  |  | 3.9 |  |  |  |
| (Benefit from) provision for income taxes | (0.8) |  |  | 0.4 |  |  | 0.4 |  |  |  |
| Net income from continuing operations | 3.3 |  |  | 2.4 |  |  | 3.5 |  |  |  |
| Net income from discontinued operations, net of tax | 1.4 |  |  | 1.2 |  |  | 0.3 |  |  |  |
| Net income | 4.7 |  |  | 3.6 |  |  | 3.8 |  |  |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 0.9 |  |  | 0.8 |  |  | — |  |  |  |
| Net income attributable to Flex Ltd. | 3.8 | % |  | 2.8 | % |  | 3.8 | % |  |  |

[0000866374-24-000021:mdna:73]
Net sales

[0000866374-24-000021:mdna:74]
The following table sets forth our net sales by segment, and their relative percentages:

[0000866374-24-000021:mdna:75]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |  |  |
| Net sales: | (In millions) |
| Flex Agility Solutions | $ | 13,923 |  |  | 53 | % |  | $ | 15,769 |  |  | 55 | % |  | $ | 14,027 |  |  | 57 | % |  |  |  |  |
| Flex Reliability Solutions | 12,492 |  |  | 47 | % |  | 12,733 |  |  | 45 | % |  | 10,606 |  |  | 43 | % |  |  |  |  |
|  | $ | 26,415 |  |  |  |  | $ | 28,502 |  |  |  |  | $ | 24,633 |  |  |  |  |  |  |  |

[0000866374-24-000021:mdna:76]
Net sales for the fiscal year ended March 31, 2024 totaled $26.4 billion, representing a decrease of approximately $2.1 billion, or 7%, from $28.5 billion for the fiscal year ended March 31, 2023. Net sales for our FAS segment decreased $1.8 billion, or 12%, from fiscal year 2023, mainly due to a decrease in net sales of 24% in our Consumer Devices business, a 17% decrease in our Lifestyle business and a 7% decrease in our CEC business due to softer demand in consumer end markets and difficult year-over-year comparisons in CEC. Net sales in our FRS segment decreased $0.2 billion, or 2%, from fiscal year 2023, driven primarily by a decrease in net sales of 8% in our Industrial business due to lower customer demand, offset by a 6% increase in our Automotive business, and a 3% increase in our Health Solution business which benefited from ramps across various end markets.

[0000866374-24-000021:mdna:77]
Net sales for the fiscal year ended March 31, 2023 totaled $28.5 billion, representing an increase of approximately $3.9 billion, or 16%, from $24.6 billion for the fiscal year ended March 31, 2022. Net sales for our FAS segment increased $1.7 billion, or 12%, from the prior year, mainly due to an increase in net sales of 30% in our CEC business and 2% in our Lifestyle business due to new ramps, customer expansion, along with some effect from inflation pass-through while overcoming challenges from supply constraints. These increases in FAS were offset by a 19% decrease in net sales in our Consumer Devices business due to relatively softer market demand and a planned project completion in the fiscal year ended 2022. Net sales in our FRS segment increased $2.1 billion, or 20%, driven primarily by an increase of 24% in net sales in our Industrial business, a 22% increase in our Automotive business, and a 9% increase in our Health Solutions business from the prior year due to strong customer demand and ramps across various end markets coupled with incremental revenues from our Anord Mardix acquisition and the recovery of inflationary costs, despite continued supply constraints.

[0000866374-24-000021:mdna:78]
Net sales for the fiscal year ended March 31, 2024 increased $0.3 billion to $12.2 billion in the Americas, decreased $1.8 billion to $8.5 billion in Asia, and decreased $0.6 billion to $5.6 billion in Europe.

[0000866374-24-000021:mdna:79]
Net sales for the fiscal year ended March 31, 2023 increased $2.5 billion to $11.9 billion in the Americas, increased $0.8 billion to $10.4 billion in Asia, and increased $0.6 billion to $6.2 billion in Europe.

[0000866374-24-000021:mdna:80]
Our ten largest customers during fiscal years 2024, 2023 and 2022 accounted for approximately 37%, 37% and 36% of net sales, respectively. We have made substantial efforts to maintain a diverse portfolio which allows us to operate at scale in many different industries, and, as a result, no customer accounted for greater than 10% of net sales in fiscal year 2024, 2023 or 2022.

[0000866374-24-000021:mdna:81]
Cost of sales

[0000866374-24-000021:mdna:82]
Cost of sales is affected by a number of factors, including the number and size of new manufacturing programs, product mix, labor cost fluctuations by region, component costs and availability and capacity utilization.

[0000866374-24-000021:mdna:83]
Cost of sales during fiscal year 2024 totaled $24.4 billion, representing a decrease of approximately $2.1 billion, or 8% from $26.5 billion during fiscal year 2023. The decrease in cost of sales is primarily driven by decreased consolidated sales of $2.1 billion, or 7%. Cost of sales in FAS decreased $1.8 billion or approximately 12%, from fiscal year 2023, which is in line with the 12% decrease in FAS revenue primarily as a result of lower revenue in our Consumer Devices, Lifestyle, and CEC businesses. Cost of sales in FRS for fiscal year 2024 decreased $0.3 billion, or approximately 3% from fiscal year 2023, which is in line with the 2% decrease in FRS revenue, primarily driven by lower revenue in our Industrial business.

[0000866374-24-000021:mdna:84]
Cost of sales during fiscal year 2023 totaled $26.5 billion, representing an increase of approximately $3.7 billion or 16% from $22.8 billion during fiscal year 2022. The increase in cost of sales is most notable in our FRS segment. Cost of sales in FRS for fiscal year 2023 increased $2.0 billion, or approximately 21% from fiscal year 2022, which is in line with the 20% increase in revenue, primarily as a result of higher revenue in our Industrial and Automotive businesses. Cost of sales in FAS increased $1.6 billion, or approximately 12%, from fiscal year 2022, which is relatively consistent with the 12% increase in revenue, primarily as a result of higher revenue in our CEC and Lifestyle businesses, and partially offset by improved efficiencies.

[0000866374-24-000021:mdna:85]
Gross profit

[0000866374-24-000021:mdna:86]
Gross profit is affected by a fluctuation in cost of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all markets. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-24-000021:mdna:87]
Gross profit during fiscal year 2024 decreased $0.1 billion to $1.9 billion, or 7.1% of net sales, from $2.0 billion, or 6.9% of net sales, during fiscal year 2023. The decrease in gross profit during fiscal year 2024 due to lower sales was mitigated by higher gross profit margins and the $0.1 billion gross profit decrease was primarily driven by $0.1 billion in higher restructuring charges, compared to the prior year.

[0000866374-24-000021:mdna:88]
Gross profit during fiscal year 2023 increased $0.2 billion to $2.0 billion, or 6.9% of net sales, from $1.8 billion, or 7.2% of net sales, during fiscal year 2022. The increase in gross profit during fiscal year 2023 primarily resulted from the overall stronger customer demand across various end markets which allowed for improved fixed cost absorption, despite continued

[0000866374-24-000021:mdna:89]
45

[0000866374-24-000021:mdna:90]
pressure on margins from component shortages, logistics constraints and the pass-through effect of inflationary cost recoveries, compared to the prior year.

[0000866374-24-000021:mdna:91]
Segment income

[0000866374-24-000021:mdna:92]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges, customer related asset impairment, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-24-000021:mdna:93]
The following table sets forth segment income and margins. Segment margins in the table below may not recalculate exactly due to rounding.

[0000866374-24-000021:mdna:94]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |  |  |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 669 |  |  | 4.8 | % |  | $ | 694 |  |  | 4.4 | % |  | $ | 605 |  |  | 4.3 | % |  |  |  |  |
| Flex Reliability Solutions | 666 |  |  | 5.3 | % |  | 607 |  |  | 4.8 | % |  | 546 |  |  | 5.1 | % |  |  |  |  |

[0000866374-24-000021:mdna:95]
FAS segment margin increased 40 basis points, to 4.8% for fiscal year 2024, from 4.4% for fiscal year 2023. The margin increase during the period was driven by strong execution, product mix and cost actions taken.

[0000866374-24-000021:mdna:96]
FRS segment margin increased 50 basis points, to 5.3% for fiscal year 2024, from 4.8% for fiscal year 2023. The margin increase in the FRS segment was primarily driven by improving margins in our Health Solutions and Automotive businesses due to increased productivity and favorable mix, the resolution of previous supply-chain-related disruptions and cost actions taken, partially offset by lower sales in our Industrial business.

[0000866374-24-000021:mdna:97]
FAS segment margin increased 10 basis points, to 4.4% for fiscal year 2023, from 4.3% for fiscal year 2022. The margin increase during the period was driven by strong execution against new project ramps and product mix, partially offset by elevated costs due to component shortages and logistics constraints and the effect of certain inflation pass-through recoveries.

[0000866374-24-000021:mdna:98]
FRS segment margin decreased 30 basis points, to 4.8% for fiscal year 2023, from 5.1% for fiscal year 2022. The margin decrease in the FRS segment was primarily driven by component shortage-related production disruptions, inflationary cost pressures as well as program investments impacting our Automotive and Health Solutions businesses during fiscal year 2023.

[0000866374-24-000021:mdna:99]
Restructuring charges

[0000866374-24-000021:mdna:100]
During fiscal year 2024, we committed to targeted restructuring activities to improve operational efficiency by reducing excess workforce capacity. As a result, we recognized approximately $175 million of restructuring charges, primarily related to employee severance. During fiscal year 2023, we recognized approximately $27 million of restructuring charges, primarily related to employee severance. During fiscal year 2022, we recognized approximately $15 million of restructuring charges, primarily related to employee severance.

[0000866374-24-000021:mdna:101]
Refer to note 16 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-24-000021:mdna:102]
Selling, general and administrative expenses

[0000866374-24-000021:mdna:103]
Selling, general and administrative expenses ("SG&A") totaled $0.9 billion, or 3.5% of net sales, during fiscal year 2024, compared to $0.9 billion, or 3.1% of net sales, during fiscal year 2023, increasing by $48 million or 5%, which was attributed to  the recognition of an accrual of a $50 million loss contingency for a commercial dispute related to a construction matter with related production objectives.

[0000866374-24-000021:mdna:104]
SG&A totaled $0.9 billion, or 3.1% of net sales, during fiscal year 2023, compared to $0.8 billion, or 3.4% of net sales, during fiscal year 2022, increasing by $44 million or 5%, which reflects our enhanced cost control efforts to support higher revenue growth while keeping our SG&A expenses relatively flat.

[0000866374-24-000021:mdna:105]
46

[0000866374-24-000021:mdna:106]
Intangible amortization

[0000866374-24-000021:mdna:107]
Amortization of intangible assets in fiscal years 2024 and 2023 were $70 million and $81 million, respectively, representing a decrease of $11 million, from fiscal year 2023, primarily due to certain intangibles being fully amortized during fiscal year 2024.

[0000866374-24-000021:mdna:108]
Amortization of intangible assets in fiscal years 2023 and 2022 were $81 million and $60 million, respectively, representing an increase of $21 million, from fiscal year 2022, primarily due to amortization expense related to new intangible assets from the Anord Mardix acquisition completed in December 2021, partially offset by certain intangible assets being fully amortized during fiscal year 2023.

[0000866374-24-000021:mdna:109]
Interest expense

[0000866374-24-000021:mdna:110]
Interest expense was $207 million during fiscal year 2024, compared to $230 million during fiscal year 2023, decreasing $23 million primarily due to lower bank borrowings and repayment of bank loans during fiscal year 2024.

[0000866374-24-000021:mdna:111]
Interest expense was $230 million during fiscal year 2023, compared to $166 million during fiscal year 2022, increasing  $64 million primarily due to new bank borrowings and higher variable interest expense during fiscal year 2023.

[0000866374-24-000021:mdna:112]
Interest income

[0000866374-24-000021:mdna:113]
Interest income was $56 million during fiscal year 2024, compared to $30 million during fiscal year 2023, increasing $26 million primarily due to increased cash deposits and higher interest rates.

[0000866374-24-000021:mdna:114]
Interest income was $30 million during fiscal year 2023, compared to $14 million during fiscal year 2022, increasing $16 million primarily due to the same drivers as discussed above.

[0000866374-24-000021:mdna:115]
Other charges (income), net

[0000866374-24-000021:mdna:116]
During fiscal year 2024, we recorded $44 million of other charges, net, compared to $6 million of other charges, net, in fiscal year 2023, which was primarily driven by an increase of approximately $31 million in foreign exchange transaction losses compared to fiscal year 2023.

[0000866374-24-000021:mdna:117]
During fiscal year 2023, we recorded $6 million of other charges, net, compared to $165 million of other income, net, in fiscal year 2022, which was primarily driven by a $150 million gain related to a Brazilian tax credit recognized in fiscal year 2022 coupled with an approximately $26 million reduction in foreign exchange transaction gains compared to fiscal year 2022.

[0000866374-24-000021:mdna:118]
Refer to note 17 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our other charges (income), net.

[0000866374-24-000021:mdna:119]
Equity in earnings (losses) of unconsolidated affiliates

[0000866374-24-000021:mdna:120]
During fiscal year 2024, we recorded $8 million of equity in earnings of unconsolidated affiliates, compared to $4 million of equity in losses of unconsolidated affiliates during fiscal year 2023. The increase during fiscal year 2024 was primarily due to higher investment fund gains versus fiscal year 2023, resulting from discrete market events such as financing rounds completed by certain companies included in those funds.

[0000866374-24-000021:mdna:121]
During fiscal year 2023, we recorded $4 million of equity in losses of unconsolidated affiliates, compared to $61 million of equity in earnings of unconsolidated affiliates during fiscal year 2022. The decrease during fiscal year 2023 was primarily due to lower investment fund gains versus fiscal year 2022, resulting from discrete market events such as initial public offerings and financing rounds completed by certain companies included in those funds.

[0000866374-24-000021:mdna:122]
47

[0000866374-24-000021:mdna:123]
Income taxes

[0000866374-24-000021:mdna:124]
We work to ensure that we accrue and pay the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which we operate. Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were (30.9)%, 15.4% and 9.5% for the fiscal years 2024, 2023 and 2022 respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0000866374-24-000021:mdna:125]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |  |  |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  | 17.0 | % |  |  |
| Effect of jurisdictional tax rate differential | 10.3 | % |  | 6.4 | % |  | (10.1) | % |  |  |
| Change in unrecognized tax benefit | (1.4) | % |  | (0.8) | % |  | 1.2 | % |  |  |
| Change in valuation allowance | (102.9) | % |  | (35.9) | % |  | (14.0) | % |  |  |
| Foreign exchange movement on prior year taxes recoverable | (0.2) | % |  | 0.5 | % |  | (0.9) | % |  |  |
| Liability for undistributed earnings | 20.3 | % |  | — | % |  | 0.1 | % |  |  |
| Global intangible low-taxes income (GILTI) / Subpart F income | 1.9 | % |  | 2.2 | % |  | 3.1 | % |  |  |
| Nextracker related transactions gains | 17.2 | % |  | 19.5 | % |  | 11.5 | % |  |  |
| Earnings from partnership | 7.0 | % |  | 4.8 | % |  | — | % |  |  |
| U.S. state taxes | 1.5 | % |  | 0.2 | % |  | 0.5 | % |  |  |
| Excess compensation (Section 162(m)) | 2.3 | % |  | 1.2 | % |  | 0.5 | % |  |  |
| Other | (3.9) | % |  | 0.3 | % |  | 0.6 | % |  |  |
| (Benefit from) provision for income taxes | (30.9) | % |  | 15.4 | % |  | 9.5 | % |  |  |

[0000866374-24-000021:mdna:126]
The variation in our effective tax rate each year to the statutory rate is primarily a result of recognition of earnings in foreign jurisdictions which are taxed at rates lower than the Singapore statutory rate including the effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia, Netherlands, Costa Rica, and Israel of $20 million, $14 million and $23 million in fiscal years 2024, 2023 and 2022, respectively. The primary driver of the negative effective tax rate for fiscal year 2024 relates to changes in valuation allowances of the Company's U.S. operations on deferred tax assets of $447 million in fiscal year 2024. Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion. We generate most of our revenues and profits from operations outside of Singapore.

[0000866374-24-000021:mdna:127]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our effective tax rate, tax position, operating results, financial position and cash flows.

[0000866374-24-000021:mdna:128]
On August 16, 2022, the Inflation Reduction Act of 2022 (“IRA”) was enacted into law, which includes a new corporate minimum tax, a stock repurchase excise tax, numerous green energy credits, other tax provisions, and significantly increased enforcement resources. While detailed regulations on some aspects of the act are still outstanding, we do not anticipate a material impact to our consolidated financial statements from these provisions.

[0000866374-24-000021:mdna:129]
Net income from continuing operations

[0000866374-24-000021:mdna:130]
Net income from continuing operations was $872 million during fiscal year 2024, compared to $683 million during fiscal year 2023, primarily driven by the same factors attributable to income from continuing operations before income taxes and the release of U.S. deferred tax asset valuation allowances in fiscal year 2024 as discussed above.

[0000866374-24-000021:mdna:131]
Net income from continuing operations was $683 million during fiscal year 2023, compared to $872 million during fiscal year 2022, primarily driven by the same factors attributable to income from continuing operations before income taxes as discussed above and offset by a $150 million gain related to a Brazilian tax credit recognized in fiscal year 2022

[0000866374-24-000021:mdna:132]
Net income from discontinued operations

[0000866374-24-000021:mdna:133]
Net income from discontinued operations was $373 million, which represented the nine months prior to the Spin-off in the fourth quarter of fiscal year 2024, compared to $350 million for the full year of fiscal year 2023. Operating results for

[0000866374-24-000021:mdna:134]
Nextracker were strong in fiscal year 2024 with a 37% increase in gigawatts delivered (on a like-for-like basis), improved pricing and cost control and a reduction in global freight rates leading to a 93% increase in income before income taxes (comparing the nine month period in fiscal year 2024 to the full fiscal year 2023). This effect was offset by greater tax benefits in fiscal year 2023 as compared to fiscal year 2024, principally as the result of the Nextracker IPO in fiscal year 2023.

[0000866374-24-000021:mdna:135]
Net income from discontinued operations was $350 million during fiscal year 2023, compared to $68 million during fiscal year 2022, due to improved operational performance with a 20% increase in gigawatts delivered, an easing of global freight rates and tax benefits associated with the Nextracker IPO in fiscal year 2023.

[0000866374-24-000021:mdna:136]
Net income attributable to noncontrolling interest and redeemable noncontrolling interest

[0000866374-24-000021:mdna:137]
Net income attributable to noncontrolling interest and redeemable noncontrolling interest was $239 million, prior to the Spin-off during fiscal year 2024, compared to $240 million during fiscal year 2023, primarily driven by the same factors noted in the discussion above for net income from discontinued operations in fiscal year 2024.

[0000866374-24-000021:mdna:138]
Net income attributable to noncontrolling interest and redeemable noncontrolling interest was $240 million during fiscal year 2023, compared to $4 million during fiscal year 2022, primarily due to tax benefits and distributions associated with the Nextracker IPO during fiscal year 2023.

[0000866374-24-000021:mdna:139]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-24-000021:mdna:140]
We continuously evaluate our ability to meet our obligations over the next 12 months and have proactively adjusted our capital structure to improve maturities and liquidity. We expect that our current financial condition, including our liquidity sources, are adequate to fund current and future commitments. As of March 31, 2024, we had cash and cash equivalents of approximately $2.5 billion and bank and other borrowings of approximately $3.3 billion. We have a $2.5 billion revolving credit facility that is due to mature in July 2027 (the "2027 Credit Facility"), under which we had no borrowings outstanding as of March 31, 2024. During fiscal year 2024, the Company repaid its JPY term and delayed draw term loans. The Company also settled the associated USD JPY cross currency swap. Refer to note 9 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details. As of March 31, 2024, we were in compliance with the covenants under all of our credit facilities and indentures and expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-24-000021:mdna:141]
In fiscal year 2024, we implemented a 10b5-1 bond buyback program, aiming to repurchase certain outstanding bonds issued by us. During the twelve- month period ended March 31, 2024, we repurchased approximately $15 million of our 4.750% Notes due 2025, resulting in an immaterial gain in our consolidated statement of operations.

[0000866374-24-000021:mdna:142]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2024, approximately 55% of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $0.7 billion as of March 31, 2024). Repatriation could result in an additional income tax payment; however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-24-000021:mdna:143]
Fiscal Year 2024

[0000866374-24-000021:mdna:144]
Cash provided by operating activities was $1.3 billion during fiscal year 2024. The total cash provided by operating activities resulted primarily from $1.2 billion of net income for the period plus $0.3 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, provision for doubtful accounts, deferred income taxes and stock-based compensation. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were offset by a net change in our operating assets and liabilities of $0.3 billion.

[0000866374-24-000021:mdna:145]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital decreased by $0.7 billion to $4.5 billion as of March 31, 2024 from $5.2 billion as of March 31, 2023. This decrease was primarily driven by a $1.2 billion decrease in inventories, a $0.5 billion decrease in accounts receivable, net and derecognition of $0.4 billion of Nextracker's working capital following the Spin-off, partially offset by a $1.3 billion decrease in accounts payables.

[0000866374-24-000021:mdna:146]
Cash used in investing activities totaled $0.5 billion during fiscal year 2024. This was primarily driven by $0.5 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our CEC, Automotive, and Industrial businesses.

[0000866374-24-000021:mdna:147]
Cash used in financing activities was $1.7 billion during fiscal year 2024. This was primarily driven by $1.3 billion of cash paid for the repurchase of our ordinary shares and $0.4 billion net cash for repayments of bank borrowings and long-term debt, as cash received from the sale of Nextracker shares was offset by the capital reduction from the Nextracker Spin-off and other financing items. Refer to note 9 and note 20 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details.

[0000866374-24-000021:mdna:148]
Fiscal Year 2023

[0000866374-24-000021:mdna:149]
Cash provided by operating activities was $1.0 billion during fiscal year 2023. The total cash provided by operating activities resulted primarily from $1.0 billion of net income for the period plus $0.5 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, provision for doubtful accounts, deferred income taxes and stock-based compensation. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were offset by a net change in our operating assets and liabilities of $0.6 billion primarily driven by changes in net working capital.

[0000866374-24-000021:mdna:150]
Cash used in investing activities totaled $0.6 billion during fiscal year 2023. This was primarily driven by $0.6 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding CEC, Industrial, Health Solutions and Automotive businesses.

[0000866374-24-000021:mdna:151]
Cash provided by financing activities was $2 million during fiscal year 2023. This was primarily driven by $0.7 billion of net proceeds received from the sale of Nextracker Class A common stock through the IPO and $0.7 billion of proceeds from bank borrowings and long-term debt, partially offset by $1.0 billion net cash for repayments of bank borrowings and long-term debt, and $0.3 billion of cash paid for the repurchase of our ordinary shares.

[0000866374-24-000021:mdna:152]
Fiscal Year 2022

[0000866374-24-000021:mdna:153]
Cash provided by operating activities was $1.0 billion during fiscal year 2022. The total cash provided by operating activities resulted primarily from $0.9 billion of net income for the period plus $0.6 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, provision for doubtful accounts, deferred income taxes and stock-based compensation. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were offset by a net change in our operating assets and liabilities of $0.5 billion as increases in inventory holdings were not fully offset by growth in accounts payable and working capital advances.

[0000866374-24-000021:mdna:154]
Cash used in investing activities totaled $1.0 billion during fiscal year 2022. This was primarily driven by approximately $0.5 billion of cash paid for the acquisition of Anord Mardix in December 2021, net of cash acquired, and approximately $0.4 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Lifestyle, Automotive, and Industrial businesses.

[0000866374-24-000021:mdna:155]
Cash provided by financing activities was $0.3 billion during fiscal year 2022. This was primarily driven by $0.7 billion of proceeds received in aggregate, after premiums, following the issuance of the HUF 100 billion Bonds due December 2031 and the €350 million term loan due December 2022, and $0.5 billion of proceeds received from the sale of Nextracker redeemable preferred units, partially offset by $0.7 billion of cash paid for the repurchase of our ordinary shares and $0.2 billion of cash paid for the repayment of the Euro term loan due January 2022.

[0000866374-24-000021:mdna:156]
Adjusted Free Cash Flow

[0000866374-24-000021:mdna:157]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investors. Our adjusted free cash flow was $0.8 billion, $0.3 billion and $0.6 billion for fiscal years 2024, 2023 and 2022, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-24-000021:mdna:158]
|  | Fiscal Year Ended March 31, |
|  | 2024 |  | 2023 |  | 2022 |  |  |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,326 |  |  | $ | 950 |  |  | $ | 1,024 |  |  |  |
| Purchases of property and equipment | (530) |  |  | (635) |  |  | (443) |  |  |  |
| Proceeds from the disposition of property and equipment | 25 |  |  | 20 |  |  | 11 |  |  |  |
| Adjusted free cash flow (1) | $ | 821 |  |  | $ | 335 |  |  | $ | 593 |  |  |  |

[0000866374-24-000021:mdna:159]
(1)Fiscal year 2022 figures in the table may not foot exactly due to rounding.

[0000866374-24-000021:mdna:160]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months and beyond.

[0000866374-24-000021:mdna:161]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volume of customer orders.

[0000866374-24-000021:mdna:162]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of March 31, 2024.

[0000866374-24-000021:mdna:163]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of debt securities, bank debt and lease financings. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed. During fiscal year 2024, 2023 and 2022, we received approximately $3.6 billion, $3.5 billion, and $1.6 billion, respectively, from other sales of receivables under our factoring programs. As of March 31, 2024 and 2023, the outstanding balance on receivables sold for cash was $0.8 billion and $0.8 billion, respectively, under our accounts receivable factoring programs, which were removed from accounts receivable balances in our consolidated balance sheets.

[0000866374-24-000021:mdna:164]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In July 2022, the Company entered into a new $2.5 billion credit agreement which matures in July 2027 and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit.

[0000866374-24-000021:mdna:165]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-24-000021:mdna:166]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $2 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 2, 2023. During fiscal year 2024, we paid $1.3 billion to repurchase shares under the current and prior repurchase plans at an average price of $25.65 per share. As of March 31, 2024, shares in the aggregate amount of $1.0 billion were available to be repurchased under the current plan.

[0000866374-24-000021:mdna:167]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-24-000021:mdna:168]
Refer to the note 9 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details of our debt obligations.

[0000866374-24-000021:mdna:169]
In addition. we have leased certain of our property and equipment under finance lease commitments, and certain of our facilities and equipment under operating lease commitments. The following table summarizes current and non-current material cash requirements as of March 31, 2024 including future payments due under our debt including finance leases and related interest obligations and operating leases (amounts may not sum due to rounding):

[0000866374-24-000021:mdna:170]
|  | Total |  | 1 Year or Less |  | 2 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In millions) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings, long-term debt and finance lease obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and long-term debt | $ | 3,276 |  |  | $ | — |  |  | $ | 1,266 |  |  | $ | 424 |  |  | $ | 1,586 |  |
| Finance leases | 1 |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Interest on long-term debt obligations | 558 |  |  | 139 |  |  | 207 |  |  | 153 |  |  | 59 |  |
| Operating leases, net of subleases | 712 |  |  | 160 |  |  | 239 |  |  | 157 |  |  | 156 |  |
| Restructuring costs | 80 |  |  | 79 |  |  | 1 |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 4,627 |  |  | $ | 379 |  |  | $ | 1,713 |  |  | $ | 734 |  |  | $ | 1,801 |  |

[0000866374-24-000021:mdna:171]
We also have outstanding firm purchase orders with certain suppliers for the purchase of inventory, which are not included in the table above. The majority of the purchase obligations are generally short-term in nature. We generally do not enter into non-cancelable purchase orders for materials until we receive a corresponding production forecast from our customers. Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-24-000021:mdna:172]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-24-000021:mdna:173]
Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for recent accounting pronouncements.

[0000866374-24-000021:mdna:174]
52
