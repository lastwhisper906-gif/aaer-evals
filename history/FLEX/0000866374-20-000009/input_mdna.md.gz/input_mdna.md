# FLEX MD&A — 0000866374-20-000009


## mdna

[0000866374-20-000009:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-20-000009:mdna:2]
OVERVIEW

[0000866374-20-000009:mdna:3]
We are the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, we deliver technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. As of March 31, 2020, our reporting business segments were as follows:

[0000866374-20-000009:mdna:4]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including surgical equipment, drug delivery, diagnostics, telemedicine, disposable devices, imaging and monitoring, patient mobility and ophthalmology; and our automotive business, including vehicle electrification, connectivity, autonomous, and smart technologies; |

[0000866374-20-000009:mdna:5]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, smart solar energy; and industrial, including semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks; |

[0000866374-20-000009:mdna:6]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads and small cells for wireless infrastructure; our networking business, which includes optical, routing, and switching products for data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack-level solutions, converged infrastructure and software-defined product solutions; and |

[0000866374-20-000009:mdna:7]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in IoT enabled devices, audio and consumer power electronics, mobile devices; and various supply chain solutions for consumer, computing and printing devices. |

[0000866374-20-000009:mdna:8]
These segments represent components of the Company for which separate financial information is available that is utilized on a regular basis by our Chief Operating Decision Maker (“CODM”). Our segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 20 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for additional information on our operating segments.

[0000866374-20-000009:mdna:9]
In March 2020, we announced a change in organization structure as part of our strategy to further drive growth and productivity with two focused delivery models. As a result, beginning in fiscal year 2021, we expect to report our financial performance based on two reportable segments (Flex Agility Solutions Group and Flex Reliability Solutions Group) and analyze operating income as the measure of segment profitability.

[0000866374-20-000009:mdna:10]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-20-000009:mdna:11]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0000866374-20-000009:mdna:12]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customer's supply chain solutions needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-20-000009:mdna:13]
During the past several years, we have evolved our long-term portfolio towards a mix of businesses which possess longer product life cycles and higher segment operating margins as reflected in our IEI and HRS businesses. We have expanded our design and engineering relationships through our product innovation centers and global design centers.

[0000866374-20-000009:mdna:14]
During fiscal year 2019, we took actions to optimize our portfolio with greater focus to be placed on higher margin, less volatile businesses. During the first half of fiscal year 2020, in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. We recognized $216 million of charges during the fiscal year 2020, comprised of approximately $159 million of cash charges predominantly for employee severance, and $57 million of non-cash charges primarily related to asset impairments. While the bulk of the restructuring activities were executed in fiscal year 2020 and prior, we may be required to execute additional restructuring activities as we continue to streamline our cost structure while focusing on higher margin, less volatile businesses and in response to the economic challenges in light of recent events with COVID-19 as discussed below.

[0000866374-20-000009:mdna:15]
We believe that our continued business transformation is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-20-000009:mdna:16]
Impact of COVID-19 on Our Business

[0000866374-20-000009:mdna:17]
The COVID-19 pandemic has resulted in a widespread public health crisis and numerous disease control measures being taken to limit its spread, including travel bans and restrictions, quarantines, shelter-in-place orders, and shutdowns. These measures have materially impacted and are continuing to impact our workforce and operations, the operations of our customers, and those of our respective vendors and suppliers. We have significant operations worldwide, including in China, Mexico, the United States, Brazil, India, Malaysia and Europe, and each of these geographies has been affected by the outbreak and taken measures to try to contain it, resulting in disruptions at many of our manufacturing operations and facilities. The extent to which the COVID-19 pandemic will continue to impact our business and financial results going forward will be dependent on future developments such as the length and severity of the crisis, the potential resurgence of COVID-19 in the future, future government actions in response to the crisis and the overall impact of the COVID-19 pandemic on the global economy and capital markets, among many other factors, all of which remain highly uncertain and unpredictable. See “Risk Factors - The COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material.”

[0000866374-20-000009:mdna:18]
In response to the outbreak, we deployed our contingency and resiliency plans that are encompassed in our business continuity programs. Our resiliency advisory and crisis management teams defined work streams and set up “war” rooms with hundreds of employees, organizing across our global footprint, and coordinating and communicating with our suppliers and customers. Our leadership teams initiated enhanced health and safety measures across all facilities, as our foremost focus has been the health and safety of our employees. We modified practices at our manufacturing locations and offices to require personal protective equipment, sanitization measures, temperature checks and social distancing well before these measures were mandated. Our protocols to protect employees and safely operate our facilities have been implemented in partnership with several governments, including in China, Mexico, Malaysia, Brazil, and Europe. These measures also have enabled us to

[0000866374-20-000009:mdna:19]
continue to conduct operations which are considered to be essential services, including but not limited to the manufacture of critical health care products.

[0000866374-20-000009:mdna:20]
As one of the largest medical device manufacturers, we recognized that we had a responsibility to do our part to make a difference in the fight against this disease. With many of the products we make for our healthcare customers related to critical care quickly running in short supply, we ramped our efforts to expand delivery of critical products, including oxygen concentrators, patient monitors, infusion pumps, and ICU beds. We are also greatly increasing our testing equipment production for both point of care and large laboratory systems and are currently partnering with our customers to manufacture ventilators at six sites around the globe.

[0000866374-20-000009:mdna:21]
We are presently operating in the majority of our manufacturing facilities across the globe. Our China operations are now fully up and running. There are a few regions that were impacted by acute outbreaks, such as Italy, or have seen complete country shutdowns, including India and Malaysia. In these geographies, we remain in contact with the local and national governments, and have received or are in the process of receiving waivers to safely return factories to full capacity. In addition, we have also shut down our automotive facilities (including in Mexico and Europe) in line with shutdowns executed by the major North American and European auto makers. For those employees who are not working at our manufacturing facilities, including corporate and regional headquarters, we have been operating on a work-from-home basis. We do not believe that our work-from-home protocols have materially adversely impacted our internal controls, financial reporting systems or our operations.

[0000866374-20-000009:mdna:22]
All of our business segments were impacted in the fourth quarter of our fiscal year 2020, with our High Reliability Solutions segment impacted by factory shutdowns by several of our large OEM customers of our automotive business, although our health solutions business has experienced a significant increased demand for critical health care products. Our Industrial and Emerging Industries segment was impacted by supply chain disruptions that impacted product ramps for various industrial and home and lifestyle customers. Our Communications & Enterprise Compute segment was impacted by production disruptions in certain of our Asian facilities and late quarter disruptions in our Mexican facilities. Finally, our Consumer Technologies Group segment was impacted by significant China-based supply chain constraints. Overall, we absorbed additional direct incremental costs of approximately $52 million primarily related to costs associated with enhanced health and safety infrastructure, labor incentives and incremental supply chain expenses. The facility and supply chain constraints, increased incremental costs, as well as lower customer demand for certain product categories have continued in the first quarter of our fiscal year 2021.

[0000866374-20-000009:mdna:23]
To ensure that we are prepared for an uncertain demand environment, we have aggressively cut costs and are preserving cash. Our goal is to maintain as many jobs as we can and maintain our ability to invest where we need to enable future business. To accomplish these objectives, we implemented a combination of graduated salary cuts, furloughs and other programs to cut costs, including aggressively reducing discretionary corporate spend. In particular, our Chief Executive Officer and the Board agreed to reduce her base salary by 50% during the first two quarters of fiscal year 2021. Our other named executive officers proposed and the Board agreed to reduce their base salaries by 30% during the first two quarters of fiscal year 2021. We also made the decision to suspend our share repurchase program during the first quarter of our fiscal year 2021 and postponed all non-critical capital expenditures. We have established a robust contingency planning methodology and will adjust our actions based on how future events evolve.

[0000866374-20-000009:mdna:24]
Business Overview

[0000866374-20-000009:mdna:25]
We are one of the world's largest providers of global supply chain solutions, with revenues of $24.2 billion in fiscal year 2020. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. As of March 31, 2020, our total manufacturing capacity was approximately 27 million square feet. In fiscal year 2020, our net sales in the Americas, Asia and Europe represented approximately 42%, 39% and 19%, respectively, of our total net sales, based on the location of the manufacturing site. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-20-000009:mdna:26]
35

[0000866374-20-000009:mdna:27]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 5,665 |  |  | 23 | % |  | $ | 6,649 |  |  | 25 | % |  | $ | 7,450 |  |  | 29 | % |
| Mexico | 4,449 |  |  | 18 | % |  | 4,539 |  |  | 17 | % |  | 4,362 |  |  | 17 | % |
| U.S. | 3,719 |  |  | 15 | % |  | 3,106 |  |  | 12 | % |  | 2,860 |  |  | 11 | % |
| Brazil | 1,831 |  |  | 8 | % |  | 2,181 |  |  | 8 | % |  | 2,578 |  |  | 10 | % |
| Malaysia | 1,539 |  |  | 6 | % |  | 1,996 |  |  | 8 | % |  | 2,005 |  |  | 8 | % |
| Hungary | 1,355 |  |  | 6 | % |  | 1,290 |  |  | 5 | % |  | 1,175 |  |  | 5 | % |
| India | 1,298 |  |  | 5 | % |  | 1,805 |  |  | 7 | % |  | 609 |  |  | 2 | % |
| Other | 4,354 |  |  | 19 | % |  | 4,646 |  |  | 18 | % |  | 4,402 |  |  | 18 | % |
|  | $ | 24,210 |  |  |  |  | $ | 26,211 |  |  |  |  |  | $ | 25,441 |  |  |  |  |

[0000866374-20-000009:mdna:28]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 555 |  |  | 25 | % |  | $ | 537 |  |  | 23 | % |
| China | 396 |  |  | 18 | % |  | 523 |  |  | 22 | % |
| U.S. | 378 |  |  | 17 | % |  | 361 |  |  | 15 | % |
| India | 207 |  |  | 9 | % |  | 219 |  |  | 9 | % |
| Malaysia | 111 |  |  | 5 | % |  | 138 |  |  | 6 | % |
| Hungary | 100 |  |  | 4 | % |  | 103 |  |  | 4 | % |
| Other | 469 |  |  | 22 | % |  | 454 |  |  | 21 | % |
|  | $ | 2,216 |  |  |  |  | $ | 2,336 |  |  |  |

[0000866374-20-000009:mdna:29]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-20-000009:mdna:30]
Our operating results are affected by a number of factors, including the following:

[0000866374-20-000009:mdna:31]
| • | the impacts on our business due to component shortages or other supply chain related constraints including as a result of the COVID-19 pandemic; |

[0000866374-20-000009:mdna:32]
| • | the effects of the COVID-19 pandemic on our business and results of operations; |

[0000866374-20-000009:mdna:33]
| • | changes in the macro-economic environment and related changes in consumer demand; |

[0000866374-20-000009:mdna:34]
| • | the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors; |

[0000866374-20-000009:mdna:35]
| • | the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance; |

[0000866374-20-000009:mdna:36]
36

[0000866374-20-000009:mdna:37]
| • | our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers; |

[0000866374-20-000009:mdna:38]
| • | the effects that current credit and market conditions (including as a result of the COVID-19 pandemic) could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations; |

[0000866374-20-000009:mdna:39]
| • | the effects on our business due to certain customers' products having short product life cycles; |

[0000866374-20-000009:mdna:40]
| • | our customers' ability to cancel or delay orders or change production quantities; |

[0000866374-20-000009:mdna:41]
| • | our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements; |

[0000866374-20-000009:mdna:42]
| • | integration of acquired businesses and facilities; |

[0000866374-20-000009:mdna:43]
| • | increased labor costs due to adverse labor conditions in the markets we operate; |

[0000866374-20-000009:mdna:44]
| • | changes in tax legislation; and |

[0000866374-20-000009:mdna:45]
| • | changes in trade regulations and treaties. |

[0000866374-20-000009:mdna:46]
The attractiveness of our services to customers and our ability to conduct business with certain customers can be affected by changes in U.S. and other countries' trade policies. In 2018, the U.S. imposed tariffs on a large variety of products of Chinese origin. The U.S. government has also indicated a readiness to further expand the scope of the tariffs on Chinese goods if negotiations are not successful, and most recently, effective May 10, 2019, increased tariffs on $200 billion of Chinese goods to 25%. Further, on May 15, 2019, President Trump issued an executive order designed to secure the information and communications technology and services supply chain, which would restrict the acquisition or use in the United States of information and communications technology or services designed, developed, manufactured, or supplied by persons owned by, controlled by, or subject to the jurisdiction or direction of foreign adversaries. The executive order is subject to implementation by the Secretary of Commerce and applies to contracts entered into prior to the effective date of the order. In addition, the U.S. Commerce Department has implemented additional restrictions and may implement further restrictions that would affect conducting business with certain Chinese companies. A “phase one” trade deal signed between the U.S. and China on January 15, 2020 accompanied a U.S. decision to cancel a plan to increase tariffs on an additional list of Chinese products and to reduce the tariffs imposed on May 13, 2019 from 15% to 7.5% effective February 14, 2020. While the signing of the agreement and granting of several tariff exclusions by the U.S. Trade Representative signal a cooling of tensions between the U.S. and China over trade, many of the additional tariffs on Chinese origin goods remain as do concerns over the stability of bilateral trade relations, particularly given the limited scope of the phase one agreement. In addition, the economic disruption caused by the COVID-19 pandemic could make it harder for China to meet its obligations under the deal and increases the potential for China to invoke the deal’s “disaster clause,” which could further challenge US-China bilateral trade relations. Depending upon their duration and implementation, as well as our ability to mitigate their impact, these tariffs, the executive order and its implementation and other regulatory actions could materially affect our business, including in the form of increased cost of goods sold, decreased margins, increased pricing for customers, and reduced sales. Further, one of our former customers, Huawei Technologies Co., Ltd., and some of its affiliates have been added to the U.S. Department of Commerce’s Entity List, and were recently made subject to enhanced restrictions designed to prevent them from having access to foreign-produced items using U.S.-origin semiconductor technology and equipment; we could be subject to reputational harm based on its business activities, including activities with sanctioned countries.

[0000866374-20-000009:mdna:47]
We also are subject to other risks as outlined in Item 1A, "Risk Factors".

[0000866374-20-000009:mdna:48]
Net sales for fiscal year 2020 decreased 8%, or $2.0 billion, to $24.2 billion from the prior year. With the exception of our IEI segment whose net sales increased $1.1 billion, net sales for all of our remaining segments declined from the previous year. Our CTG segment decreased $1.7 billion, primarily resulting from our targeted reductions of high volatility, low margin, short-cycle customers and product categories, in addition to significant COVID-19 related supply chain constraints in our fourth quarter. Our CEC segment decreased $1.4 billion, driven by reduced demand in our networking and telecommunication businesses due to the slower roll-out of 5G technology, in addition to our previously announced disengagement with Huawei Technologies Co., coupled with production disruptions in our fourth quarter due to COVID-19. Our HRS segment modestly declined $87 million driven primarily by COVID-19 disruptions directly impacting our automotive business towards the end of our fiscal year as multiple factories shut down late in the fourth quarter. This decline in our HRS segment was offset to some extent by the growth we saw in the earlier part of the fiscal year as we ramped new programs. Our IEI segment increased $1.1

[0000866374-20-000009:mdna:49]
billion, mainly driven by strong sales within our solar energy business and our home and lifestyle business throughout the year which more than offset the underlying supply chain disruptions due to COVID-19 that impacted product ramps for various industrial and home and lifestyle businesses in our fourth quarter. Our fiscal year 2020 gross profit totaled $1.3 billion, representing a decrease of $180 million, or 12%, from the prior year. The decline was primarily driven by the geopolitical challenges and uncertainties which impacted specific customers resulting in restructuring charges recorded in the first half of fiscal year 2020 as well as the write-down of inventory in the second quarter of fiscal year 2020 that will not be recovered due to significant reductions in future customer demand as we reduce our exposure to certain higher volatility businesses. In addition, we also incurred direct incremental costs absorbed in the fourth quarter of fiscal year 2020 due to COVID-19. These were partially offset by the favorable product mix and the increased revenues and gross profit from our IEI segment and benefits realized from our earlier restructuring activities initiated in fiscal year 2019. Our net income totaled $88 million, representing a decrease of $6 million, or 6%, compared to fiscal year 2019, due to the factors explained above, coupled with our ongoing investment portfolio strategy as part of which we incurred certain charges. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details of the investment impairments.

[0000866374-20-000009:mdna:50]
Cash used in operations decreased by approximately $1.5 billion to $1.5 billion for fiscal year 2020 compared with $3.0 billion for fiscal year 2019 primarily due to reduced cash outflows related to accounts receivable. Cash collections from the securitized portion of our Asset-Backed Securitization agreements ("ABS Programs"), called the deferred purchase price, of $2.6 billion were included in cash from investing activities compared to $3.6 billion in fiscal year 2019 (refer to note 11 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data"). Our net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. Our net working capital as a percentage of annualized sales for fiscal year 2020 decreased slightly by 0.4% to 6.3% from the prior year.

[0000866374-20-000009:mdna:51]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operating activities, plus cash collections of deferred purchase price receivables, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. We also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation. Our adjusted free cash flow was $672 million for fiscal year 2020 compared to $3 million for fiscal year 2019. The increase in adjusted free cash flow is primarily due to the lower level of cash used in operating activities, as discussed above, coupled with a lower level of capital expenditures in the current fiscal year. Refer to the Liquidity and Capital Resources section for the adjusted free cash flows reconciliation to the most directly comparable GAAP financial measure of cash flows from operations. Cash provided by investing activities decreased by approximately $1.0 billion to $2.3 billion for fiscal year 2020, compared with $3.3 billion for fiscal year 2019, primarily due to lower cash collections on deferred purchase price receivables and lower capital expenditures as described above. Cash used in financing activities totaled $508 million during fiscal year 2020, which increased by approximately $478 million from $30 million in the prior year, primarily due to higher net repayments of bank borrowings and long-term debt, and higher incremental share repurchases in fiscal year 2020.

[0000866374-20-000009:mdna:52]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000866374-20-000009:mdna:53]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from those estimates and assumptions.

[0000866374-20-000009:mdna:54]
We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-20-000009:mdna:55]
Leases

[0000866374-20-000009:mdna:56]
We are a lessee with several non-cancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. We determine if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the customer has the right to control the use of the identified asset.

[0000866374-20-000009:mdna:57]
Beginning with the adoption of ASC 842 on April 1, 2019, we recognize a right-of-use (“ROU”) asset and a lease liability

[0000866374-20-000009:mdna:58]
at the lease commencement date for our operating leases. For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at the lease commencement date. We have elected the short-term lease recognition and measurement exemption for all classes of assets, which allows us to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option we are reasonably certain of exercising. We have also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As we cannot determine the interest rate implicit in the lease for our leases, we use our estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. Our estimated incremental borrowing rate is the rate of interest we would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of our leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that we are reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor. Refer to note 3 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-20-000009:mdna:59]
Revenue Recognition

[0000866374-20-000009:mdna:60]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assess whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when we have transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-20-000009:mdna:61]
Customer Contracts and Related Obligations

[0000866374-20-000009:mdna:62]
Certain of our customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. We estimate the variable consideration related to these price adjustments as part of the total transaction price and recognize revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. We constrain the amount of revenues recognized for these contractual provisions based on our best estimate of the amount which will not result in a significant reversal of revenue in a future period. We determine the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-20-000009:mdna:63]
Customer Credit Risk

[0000866374-20-000009:mdna:64]
We have an established customer credit policy through which we manage customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. We perform ongoing credit evaluations of our customers' financial condition and make provisions for doubtful accounts based on the outcome of those credit evaluations. We evaluate the collectability of accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent we identify exposures as a result of customer credit issues, we also review other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-20-000009:mdna:65]
Restructuring Charges

[0000866374-20-000009:mdna:66]
We recognize restructuring charges related to our plans to close or consolidate excess manufacturing facilities and rationalize administrative functions and to realign our corporate cost structure. In connection with these activities, we recognize restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-20-000009:mdna:67]
The recognition of these restructuring charges requires that we make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned restructuring activity. To the extent our actual results differ from our estimates and assumptions, we may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, we evaluate the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed exit plans.

[0000866374-20-000009:mdna:68]
Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-20-000009:mdna:69]
Inventory Valuation

[0000866374-20-000009:mdna:70]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regards to inventory procured to fulfill customer demand.

[0000866374-20-000009:mdna:71]
Valuation of Private Company Investments

[0000866374-20-000009:mdna:72]
We assess our investments for impairment whenever events or changes in circumstances indicate that the assets may be impaired. The factors we consider in our evaluation of potential impairment of our investments, include, but are not limited to a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. The carrying value of certain of our investments are individually material, thus there is the potential for material charges in future periods if we determine that those investments are impaired.

[0000866374-20-000009:mdna:73]
During fiscal year 2020, and in connection with the Company’s ongoing assessment of its investment portfolio strategy, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $98 million total impairment in other charges (income), net on the consolidated statement of operations. The impairments in fiscal year 2020 were primarily related to Elementum and certain other non-core investments, reflecting recent market valuation changes, in addition to capturing additional risks due to the economic challenges in light of COVID-19.

[0000866374-20-000009:mdna:74]
During the last half of fiscal year 2019, the Company reassessed its strategy with respect to its entire investment portfolio. As a result the Company recognized aggregate net charges related to investment impairments and dispositions of approximately $193 million for the fiscal year ended March 31, 2019, primarily related to a non-core cost method investment and Elementum.

[0000866374-20-000009:mdna:75]
Carrying Value of Goodwill and Long-Lived Assets

[0000866374-20-000009:mdna:76]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. An impairment loss is recognized when the carrying amount of the asset group exceeds its fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such asset groups are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, general business environment and other factors including future developments of the COVID-19 pandemic which remain highly uncertain and unpredictable. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize additional impairment charges in the future.

[0000866374-20-000009:mdna:77]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require us to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider our budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates

[0000866374-20-000009:mdna:78]
and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While we believe we have made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If our actual results are not consistent with our estimates and assumptions used to calculate fair value, it could result in material impairments of our goodwill. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail.

[0000866374-20-000009:mdna:79]
During the fourth quarter of fiscal year 2020, due to the ongoing COVID-19 global pandemic which negatively impacted the overall macroeconomy as well as the Company's market capitalization and estimated near-term financial performance, the Company considered this a triggering event and performed an interim impairment test via a quantitative valuation as of March 31, 2020. Based on the results of the impairment test, the fair values exceed the respective carrying values for each reporting unit, with the percentage excess ranging from 17% for CTG to 108% for IEI. Accordingly, the Company concluded that no impairment of goodwill existed as of March 31, 2020. The estimated forecasted results used in the discounted cash flow portion of the impairment analysis reflect the Company's best estimates as of March 31, 2020 and include near term negative impacts to our auto businesses from the plant closures, challenged CEC telecommunication businesses, and weaker consumer demand for our customers' mobility products due to COVID-19. These estimates could change depending on the future developments of the COVID-19 pandemic such as the length and severity of the crisis, the potential resurgence of COVID-19 in the future, future government actions in response to the crisis and the overall impact of the COVID-19 pandemic on the global economy and capital markets, among many other factors, all of which remain highly uncertain and unpredictable.

[0000866374-20-000009:mdna:80]
Contingent Liabilities

[0000866374-20-000009:mdna:81]
We may be exposed to certain liabilities relating to our business operations, acquisitions of businesses and assets and other activities. We make provisions for such liabilities when it is probable that the settlement of the liability will result in an outflow of economic resources or the impairment of an asset. We make these assessments based on facts and circumstances that may change in the future resulting in additional expenses.

[0000866374-20-000009:mdna:82]
Refer to note 13 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our contingent liabilities.

[0000866374-20-000009:mdna:83]
Income Taxes

[0000866374-20-000009:mdna:84]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-20-000009:mdna:85]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-20-000009:mdna:86]
RESULTS OF OPERATIONS

[0000866374-20-000009:mdna:87]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data." The data below, and discussion that follows, represents our results from operations.

[0000866374-20-000009:mdna:88]
|  | Fiscal Year EndedMarch 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.7 |  |  | 93.8 |  |  | 93.5 |  |
| Restructuring charges | 0.8 |  |  | 0.4 |  |  | 0.3 |  |
| Gross profit | 5.5 |  |  | 5.8 |  |  | 6.2 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.6 |  |  | 4.0 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Interest and other, net | 0.7 |  |  | 0.7 |  |  | 0.5 |  |
| Other charges (income), net | 0.4 |  |  | 0.4 |  |  | (0.7 | ) |
| Income before income taxes | 0.6 |  |  | 0.7 |  |  | 2.0 |  |
| Provision for income taxes | 0.3 |  |  | 0.3 |  |  | 0.4 |  |
| Net Income | 0.3 | % |  | 0.4 | % |  | 1.6 | % |

[0000866374-20-000009:mdna:89]
Net sales

[0000866374-20-000009:mdna:90]
Net sales during fiscal year 2020 totaled $24.2 billion, representing a decrease of $2.0 billion, or 8%, from $26.2 billion during fiscal year 2019. With the exception of our IEI segment whose net sales increased $1.1 billion, net sales for all of our remaining segments declined from the previous year. Net sales were also lower in our Asia and Europe regions during fiscal year 2020, with decreases of $2.1 billion and $66 million, respectively, partially offset by slightly higher sales in Americas with an increase of $172 million during the same period.

[0000866374-20-000009:mdna:91]
Net sales during fiscal year 2019 totaled $26.2 billion, representing an increase of $0.8 billion, or 3%, from $25.4 billion during fiscal year 2018. The overall increase in sales was driven by increases in three of our segments offset by a decline in sales in our CTG segment. During fiscal year 2019, the increase in net sales was primarily driven by an increase of $0.5 billion in Europe, $0.3 billion in Asia, and to a lesser extent, $12 million in the Americas.

[0000866374-20-000009:mdna:92]
The following table sets forth net sales by segments and their relative percentages. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0000866374-20-000009:mdna:93]
|  | Fiscal Year Ended March 31, |
| Segments: | 2020 |  | 2019 |  | 2018 |
|  | (In millions) |
| High Reliability Solutions | $ | 4,742 |  |  | 20 | % |  | $ | 4,829 |  |  | 18 | % |  | $ | 4,770 |  |  | 19 | % |
| Industrial & Emerging Industries | 7,277 |  |  | 30 | % |  | 6,183 |  |  | 24 | % |  | 5,972 |  |  | 24 | % |
| Communications & Enterprise Compute | 6,986 |  |  | 29 | % |  | 8,336 |  |  | 32 | % |  | 7,729 |  |  | 30 | % |
| Consumer Technologies Group | 5,204 |  |  | 21 | % |  | 6,863 |  |  | 26 | % |  | 6,970 |  |  | 27 | % |
|  | $ | 24,210 |  |  |  |  |  | $ | 26,211 |  |  |  |  |  | $ | 25,441 |  |  |  |  |

[0000866374-20-000009:mdna:94]
Net sales during fiscal year 2020 decreased $1.7 billion, or 24%, in our CTG segment driven by our targeted reductions of high volatility, low margin, short-cycle customers and product categories and further impacted by significant COVID-19 related supply chain constraints in our fourth quarter. Net sales in our CEC segment decreased $1.4 billion, or 16%, driven by reduced demand in our networking and telecommunication businesses due to the slower roll-out of 5G technology and our previously announced disengagement with Huawei Technologies Co., coupled with production disruptions due to COVID-19 in our fourth quarter. Net sales in our HRS segment modestly decreased $87 million, or 2%, driven primarily by COVID-19

[0000866374-20-000009:mdna:95]
disruptions directly impacting our automotive business towards the end of our fiscal year as multiple factories shut down late in the fourth quarter. This decline was offset to some extent by the growth we saw in the earlier part of the fiscal year from ramping programs. Our IEI segment increased by $1.1 billion, or 18%, mainly driven by strong sales within our solar energy business and our home and lifestyle business throughout the year which more than offset the underlying supply chain disruptions due to COVID-19 that impacted product ramps for various industrial and home and lifestyle businesses in our fourth quarter.

[0000866374-20-000009:mdna:96]
Net sales during fiscal year 2019 increased $0.6 billion, or 8%, in our CEC segment driven by momentum from our cloud and data center business as well as the expansion of network infrastructure programs to support 4G and 5G technology, offset by declines in our data networking business due to weakness with some legacy product lines. Net sales in our IEI segment increased $0.2 billion or 4%, which was mainly driven by new programs and customer launches within our industrial, home and lifestyle businesses, offset by declines in our capital equipment and energy businesses. Net sales in our HRS segment increased $59 million, or 1%, from higher sales in our health solutions business as we benefited from prior year investments in design, engineering and automation that have strengthened and improved our capabilities and competitive positioning that more than offset year over year declines from our automotive customers primarily in Asia. These segment increases were partially offset by a decrease of $107 million, or 1.5%, in our CTG segment, primarily within the legacy consumer sectors of the segment and as a result of actively repositioning the portfolio of customers and rationalizing underperforming customers and eliminating certain product categories.

[0000866374-20-000009:mdna:97]
Our ten largest customers during fiscal years 2020, 2019 and 2018 accounted for approximately 39%, 43% and 41% of net sales, respectively. We have made substantial efforts to diversify our portfolio which allows us to operate at scale in many different industries, and, as a result, no customer accounted for greater than 10% of net sales in fiscal year 2020, 2019 or 2018.

[0000866374-20-000009:mdna:98]
Gross profit

[0000866374-20-000009:mdna:99]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion or consolidation of manufacturing facilities including specific restructuring activities from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-20-000009:mdna:100]
Gross profit decreased $0.2 billion to $1.3 billion in fiscal year 2020, from $1.5 billion in fiscal year 2019. Gross margin decreased 30 basis points, to 5.5% of net sales in fiscal year 2020, from 5.8% of net sales in fiscal year 2019. The decrease in both gross profit and gross margin is primarily due to lower sales coupled with an additional $91 million, or 40 basis points, of restructuring charges incurred during fiscal year 2020 versus fiscal year 2019. In addition, we wrote down inventory in the second quarter of fiscal year 2020 that will not be recovered due to significant reductions in future customer demand as we reduced our exposure to certain high volatility businesses. We also incurred approximately $52 million, or 21 basis points, of direct incremental costs due to COVID-19 in the fourth quarter of fiscal year 2020. These were partially offset by the favorable product mix and the increased revenues and gross profit from our IEI segment and benefits realized from our earlier restructuring activities initiated in fiscal year 2019.

[0000866374-20-000009:mdna:101]
Gross profit decreased $0.1 billion to $1.5 billion from $1.6 billion from fiscal year 2018 to fiscal year 2019. Gross margin decreased 40 basis points, to 5.8% of net sales in fiscal year 2019, from 6.2% of net sales in fiscal year 2018. The decrease is primarily due to an additional $32 million, or 10 basis points, of restructuring charges coupled with approximately $47 million of additional charges related to distressed customers incurred during fiscal year 2019 versus fiscal year 2018. During the year, we completed the wind down of our NIKE Mexico operations and incurred a total of $66 million of charges primarily for non-cash asset impairments in the second and third quarters of fiscal year 2019. Additional gross profit and gross margin declines were due to revenue reductions in some of our higher margin businesses, such as automotive and semi-cap equipment and further due to the Multek China divestiture. Also negatively pressuring the gross profit margin was the significant revenues from ramping new programs in India.

[0000866374-20-000009:mdna:102]
Segment income

[0000866374-20-000009:mdna:103]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related assets impairments, restructuring charges,

[0000866374-20-000009:mdna:104]
the new revenue standard adoption impact, legal and other, interest and other, net and other charges (income), net. A portion of depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-20-000009:mdna:105]
The following table sets forth segment income and margins. Historical information has been recast to reflect realignment of customers and/or products between segments (amounts may not sum due to rounding):

[0000866374-20-000009:mdna:106]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In millions) |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |
| High Reliability Solutions | $ | 316 |  |  | 6.7 | % |  | $ | 371 |  |  | 7.7 | % |  | $ | 381 |  |  | 8.0 | % |
| Industrial & Emerging Industries | 466 |  |  | 6.4 | % |  | 269 |  |  | 4.4 | % |  | 235 |  |  | 3.9 | % |
| Communications & Enterprise Compute | 142 |  |  | 2.0 | % |  | 215 |  |  | 2.6 | % |  | 186 |  |  | 2.4 | % |
| Consumer Technologies Group | 88 |  |  | 1.7 | % |  | 121 |  |  | 1.8 | % |  | 112 |  |  | 1.6 | % |
| Corporate and Other | (114 | ) |  |  |  | (104 | ) |  |  |  | (128 | ) |  |  |
| Total segment income | 898 |  |  | 3.7 | % |  | 872 |  |  | 3.3 | % |  | 786 |  |  | 3.1 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 64 |  |  |  |  | 74 |  |  |  |  | 79 |  |  |  |
| Stock-based compensation | 72 |  |  |  |  | 76 |  |  |  |  | 85 |  |  |  |
| Customer related asset impairments (1) | 106 |  |  |  |  | 87 |  |  |  |  | 6 |  |  |  |
| Restructuring charges (Note 15) | 216 |  |  |  |  | 113 |  |  |  |  | 91 |  |  |  |
| New revenue standard adoption impact (Note 4) | — |  |  |  |  | 9 |  |  |  |  | — |  |  |  |
| Legal and other (2) | 26 |  |  |  |  | 35 |  |  |  |  | 52 |  |  |  |
| Interest and other, net | 164 |  |  |  |  | 183 |  |  |  |  | 123 |  |  |  |
| Other charges (income), net (Note 16) | 92 |  |  |  |  | 110 |  |  |  |  | (170 | ) |  |  |
| Income before income taxes | $ | 158 |  |  |  |  | $ | 182 |  |  |  |  | $ | 521 |  |  |  |

[0000866374-20-000009:mdna:107]
| (1) | Customer related asset impairments for fiscal year 2020, primarily relate to non-cash impairments of certain property and equipment for customers we have disengaged or are in the process of disengaging, additional provision for doubtful accounts receivable, charges for other asset impairments, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand. |

[0000866374-20-000009:mdna:108]
Customer related asset impairments for fiscal year 2019, primarily relate to provision for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties and/or the Company is disengaging.

[0000866374-20-000009:mdna:109]
| (2) | Legal and other during fiscal year 2020, primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India, offset by certain gains resulting from the recognition of prior year expenses paid to the government now considered probable of recovery and reasonably estimable due to a favorable tax ruling. |

[0000866374-20-000009:mdna:110]
Legal and other during fiscal year 2019, primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, Legal and other also includes certain charges related to the China based Multek operations that was divested in the second quarter of fiscal year 2019.

[0000866374-20-000009:mdna:111]
During fiscal year 2018, the Company incurred charges in connection with certain legal matters, for loss contingencies where it believed that losses were probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility, as well as certain assets impairments during fiscal year 2018.

[0000866374-20-000009:mdna:112]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-20-000009:mdna:113]
HRS segment margin decreased 100 basis point to 6.7% for fiscal year 2020, from 7.7% during fiscal year 2019, primarily due to accelerated investments and costs associated with new program ramps and pricing pressure with demand declines in the global market that impacted product mix, coupled with under absorption of costs associated with the temporary closure of several automotive sites in the fourth quarter of fiscal year 2020 due to COVID-19. HRS segment

[0000866374-20-000009:mdna:114]
44

[0000866374-20-000009:mdna:115]
margin decreased 30 basis point to 7.7% for fiscal year 2019, from 8.0% during fiscal year 2018, primarily due to reduced revenues from our automotive products and services, which carry higher gross margins partially offset by greater contribution from our growing health solutions business.

[0000866374-20-000009:mdna:116]
IEI segment margin increased 200 basis points to 6.4% for fiscal year 2020, from 4.4% during fiscal year 2019, as a result of a favorable business mix resulting from increased demand from new business particularly in Energy and in Home & Lifestyle, greater levels of design and engineering led engagements and improved operational execution. IEI segment margin increased 50 basis points to 4.4% for fiscal year 2019, from 3.9% during fiscal year 2018, as a result of improved overhead absorption benefits from the increased revenues and greater levels of design led programs which have higher gross margins, as well as leverage of its installed cost structure.

[0000866374-20-000009:mdna:117]
CEC segment margin decreased 60 basis points to 2.0% for fiscal year 2020, from 2.6% during fiscal year 2019. The decrease in CEC margin during fiscal year 2020 is primarily due to geopolitical challenges and uncertainties which impacted demand from specific customers as well as a specific drop in demand in our networking and telecommunication businesses due to the slower roll-out of 5G technology. We also encountered disruptions in production in the fourth quarter of fiscal year 2020 due to COVID-19. These pressured margins due to the underabsorbed manufacturing overhead costs resulting from the lower revenue levels. CEC segment margin increased 20 basis points to 2.6% for fiscal year 2019, from 2.4% during fiscal year 2018. The increase was driven by operational efficiencies and improved absorption of overhead as a result of the 8% increase in revenues.

[0000866374-20-000009:mdna:118]
CTG segment margin decreased 10 basis points to 1.7% for fiscal year 2020, from 1.8% during fiscal year 2019, as it remained pressured during our portfolio transition and ongoing repositioning of our operating structure. In addition, we experienced manufacturing inefficiencies due to supply chain disruptions and constraints in the fourth quarter of fiscal year 2020 due to COVID-19. CTG segment margin increased 20 basis points to 1.8% for fiscal year 2019, from 1.6% during fiscal year 2018, as a result of lower losses from our NIKE operations in Mexico, which we exited in the third quarter of fiscal year 2019, partially offset by under-performance of certain accounts.

[0000866374-20-000009:mdna:119]
Restructuring charges

[0000866374-20-000009:mdna:120]
During fiscal year 2019, we took actions to optimize our portfolio with greater focus to be placed on higher margin, less volatile businesses. During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During fiscal year 2020, we recognized $216 million of restructuring charges. We incurred cash charges of approximately $159 million, that were predominantly for employee severance, in addition to non-cash charges of $57 million, respectively, primarily related to asset impairments.

[0000866374-20-000009:mdna:121]
During fiscal year 2019, we took targeted actions to optimize our portfolio, most notably within CTG. We recognized restructuring charges of approximately $113 million during the fiscal year ended March 31, 2019, of which $73 million were non-cash charges primarily for asset impairments. A significant component of our charges were associated with the wind down of our NIKE operations in Mexico in the third quarter of fiscal year 2019. In addition, we executed targeted head-count reductions at existing operating and design sites and corporate functions and exited certain immaterial businesses. Of these total charges, approximately $99 million was recognized as a component of cost of sales during the fiscal year ended March 31, 2019.

[0000866374-20-000009:mdna:122]
During fiscal year 2018, we initiated targeted restructuring activities, focused on optimizing our cost structure in lower growth areas and, more importantly, streamlining certain corporate and segment functions in order to make Flex a faster, more responsive and agile company, better positioned to react to marketplace opportunities. We recognized $79 million of pre-tax cash charges, predominantly related to employee severance costs, and $12 million of pre-tax non-cash charges for asset impairment and other exit charges. We classified $67 million of these charges as a component of cost of sales and $24 million as a component of selling, general and administrative expenses during fiscal year 2018.

[0000866374-20-000009:mdna:123]
Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-20-000009:mdna:124]
Selling, general and administrative expenses

[0000866374-20-000009:mdna:125]
Selling, general and administrative expenses ("SG&A") totaled $834 million, or 3.4% of net sales, during fiscal year 2020, compared to $953 million, or 3.6% of net sales, during fiscal year 2019, decreasing by $119 million or 12%, due to strict cost discipline focused on driving further productivity improvements which enabled us to respond quickly to current market

[0000866374-20-000009:mdna:126]
conditions by taking targeted actions on our discretionary spends coupled with a refined cost structure benefiting from prior restructuring initiatives.

[0000866374-20-000009:mdna:127]
SG&A totaled $953 million or 3.6% of net sales, during fiscal year 2019, compared to $1.0 billion, or 4.0% of net sales, during fiscal year 2018, decreasing by $66 million or 7%, due to strong cost discipline focused on driving further productivity improvements and a refined cost structure benefiting from prior restructuring initiatives.

[0000866374-20-000009:mdna:128]
Intangible amortization

[0000866374-20-000009:mdna:129]
Amortization of intangible assets in fiscal years 2020 and 2019 were $64 million and $74 million, respectively, representing a decrease of $10 million and $5 million, from their respective prior years as a result of certain intangible assets being fully amortized during the respective periods.

[0000866374-20-000009:mdna:130]
Interest and other, net

[0000866374-20-000009:mdna:131]
Interest and other, net was $164 million during fiscal year 2020, compared to $183 million during fiscal year 2019, decreasing $19 million primarily due to increases in net foreign exchange gains, a lower interest rate environment and lower expenses from our asset-backed securitization programs, partially offset by debt extinguishment costs incurred during fiscal year 2020.

[0000866374-20-000009:mdna:132]
Interest and other, net was $183 million during fiscal year 2019, compared to $123 million during fiscal year 2018, increasing $60 million due to a $23 million increase of interest expense primarily from higher weighted average interest rates and a higher average borrowing level, as well as a $21 million increase in interest expense from our accounts receivable sales program, partially offset by a $14 million decrease in foreign exchange gains as compared to the prior year.

[0000866374-20-000009:mdna:133]
Other charges (income), net

[0000866374-20-000009:mdna:134]
During fiscal year 2020, and in connection with the Company’s ongoing assessment of its investment portfolio strategy, we concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $98 million total impairment charge. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details on the investment impairments. No other components of other charges and income, net incurred during fiscal year 2020 were material.

[0000866374-20-000009:mdna:135]
During the last half of fiscal year 2019, we reassessed our strategy with respect to our entire investment portfolio. As a result, we recognized an aggregate net charge related to investment impairments and dispositions of approximately $193 million for the year ended March 31, 2019. The aggregate charge was primarily driven by write-downs of our investment positions in a non-core cost method investment and Elementum that were recognized in the third and fourth quarters of fiscal 2019, respectively. We also incurred other investment impairments that were individually immaterial as a result of our strategy shift and due to market valuation changes. Offsetting these charges was an $87 million non-cash gain from the deconsolidation of Bright Machines.

[0000866374-20-000009:mdna:136]
During fiscal year 2018, we recognized $152 million of gain from the deconsolidation of Elementum, and $39 million of gain from the sale of a non-strategic cost basis investment. We also recorded $22 million related to the impairment of certain non-core investments during fiscal year 2018. No other components of other charges and income, net incurred during fiscal year 2018 were material.

[0000866374-20-000009:mdna:137]
Income taxes

[0000866374-20-000009:mdna:138]
We work to ensure that we accrue and pay the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which we operate. Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were 44.7%, 48.7% and 17.7% for the fiscal years 2020, 2019 and 2018, respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0000866374-20-000009:mdna:139]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  | 17.0 | % |
| Effect of tax rate differential | (51.2 | ) |  | (74.1 | ) |  | (46.9 | ) |
| Change in unrecognized tax benefit | (0.6 | ) |  | (8.4 | ) |  | 4.3 |  |
| Change in valuation allowance | 58.4 |  |  | 105.4 |  |  | 57.1 |  |
| Recognition of prior year taxes recoverable | 8.4 |  |  | 3.0 |  |  | (10.3 | ) |
| Expiration of tax attributes | — |  |  | 2.3 |  |  | — |  |
| APB23 tax liability | 5.5 |  |  | 1.1 |  |  | 0.3 |  |
| Other | 7.2 |  |  | 2.4 |  |  | (3.8 | ) |
| Provision for income taxes | 44.7 | % |  | 48.7 | % |  | 17.7 | % |

[0000866374-20-000009:mdna:140]
The variation in our effective tax rate each year is primarily a result of recognition of earnings in foreign jurisdictions which are taxed at rates lower than the Singapore statutory rate including the effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia, Costa Rica, India, Netherlands and Israel of $16 million, $24 million and $22 million in fiscal years 2020, 2019 and 2018, respectively. Additionally, our effective tax rate is impacted by changes in our liabilities for uncertain tax positions of ($1) million, ($15) million, and $22 million and changes in our valuation allowances on deferred tax assets of $93 million, $192 million and $279 million in fiscal years 2020, 2019 and 2018, respectively. We generate most of our revenues and profits from operations outside of Singapore.

[0000866374-20-000009:mdna:141]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examinations, there could be a material adverse effect on our tax position, operating results, financial position and cash flows.

[0000866374-20-000009:mdna:142]
We provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized. During fiscal year 2020, we released valuation allowance of $1 million related to certain operations in China as this amount was deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those subsidiaries. In addition, a valuation allowance of $3 million was added for a different operating subsidiary in China due to continued losses and the determination the company would be less likely than not to utilize its deferred tax assets. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances. Lastly, these valuation allowance reductions and eliminations were offset by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions.

[0000866374-20-000009:mdna:143]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-20-000009:mdna:144]
As of March 31, 2020, we had cash and cash equivalents of $1.9 billion and bank and other borrowings of approximately $2.8 billion. We have a $1.75 billion revolving credit facility that is due to mature in June 2022, under which we had no borrowings outstanding as of March 31, 2020. We also entered into a JPY 33.525 billion term loan (approximately USD $310 million as of March 31, 2020) due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. In addition, we issued $650 million of 4.875% Notes due 2029 (the "2029 Notes") in fiscal year 2020. The proceeds were used to repay the outstanding balance of our existing 4.625% Notes due February 2020, and the Term Loan due November 2021, resulting in a net debt reduction of $216 million. Refer to note 8 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details. As of March 31, 2020, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-20-000009:mdna:145]
In May 2020, we issued $425 million aggregate principal amount of 3.750% Notes due February 2026, at 99.617% of face value, and $325 million aggregate principal amount of 4.875% Notes due May 2030, at 99.562% of face value. The total proceeds of $740 million, net of discount and issuance costs, are expected to be used for general corporate purposes, which may include repaying, redeeming or repurchasing outstanding debt and for working capital, capital expenditures and acquisitions.

[0000866374-20-000009:mdna:146]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2020, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside

[0000866374-20-000009:mdna:147]
of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.4 billion as of March 31, 2020). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-20-000009:mdna:148]
Fiscal Year 2020

[0000866374-20-000009:mdna:149]
Cash used in operating activities was $1.5 billion during fiscal year 2020. The total cash used in operating activities resulted primarily from $88 million of net income for the period plus $811 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, provision for doubtful accounts, and stock-based compensation. Depreciation expense was $422 million and slightly lower than prior years. These additions were more than offset by a net change in our operating assets and liabilities of $2.4 billion, primarily driven by cash outflows related to accounts receivable. Cash collections from the deferred purchase price on our ABS sales programs of $2.6 billion were included in cash from investing activities (refer to note 11 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for a discussion of the amendments to the ABS Programs).

[0000866374-20-000009:mdna:150]
We believe net working capital ("NWC"), and net working capital as a percentage of annualized sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. NWC decreased by $289 million to $1.4 billion as of March 31, 2020, from $1.7 billion as of March 31, 2019. This decrease is primarily driven by a $470 million decrease in accounts receivable adding back reductions from non-cash accounts receivable sales, offset by a $66 million increase in contract assets, a $62 million increase in inventories, and a $39 million decrease in accounts payable. We no longer have any non-cash accounts receivable sales balance outstanding as of March 31, 2020 due to the amendments of our ABS Programs. Our net working capital as a percentage of annualized net sales as of March 31, 2020 decreased slightly to 6.3% as compared to 6.7% of annualized net sales as of March 31, 2019.

[0000866374-20-000009:mdna:151]
Cash provided by investing activities totaled $2.3 billion during fiscal year 2020. This was primarily driven by $2.6 billion of cash collections on deferred purchase price receivables from our ABS Programs offset by approximately $356 million of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding IEI and HRS businesses. In addition, other investing activities include $44 million of proceeds from the sale of our partial investment in Bright Machines (refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for discussion of the sale).

[0000866374-20-000009:mdna:152]
Cash used in financing activities was $508 million during fiscal year 2020. This was primarily the result of (i) $672 million of cash paid for the repayment of the term loan due November 2021, (ii) $500 million of cash paid for the tender and redemption of the outstanding balance of our 4.625% Notes due February 2020, (iii) $91 million of cash paid to pay off the outstanding balance of our short-term bank borrowings facility in India, and (iv) $260 million of cash paid for the repurchase of our ordinary shares. Partially offsetting the payments described above were $663 million of proceeds, net of discount and premium, received following the issuance of the 2029 Notes, $300 million of proceeds following the execution of our term loan agreement due in April 2024, $59 million of proceeds from drawdowns from our India term loan facility coupled with $47 million of proceeds from the execution of our term loan due in March 2021. For further information, see note 8 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data".

[0000866374-20-000009:mdna:153]
Fiscal Year 2019

[0000866374-20-000009:mdna:154]
Cash used in operating activities was $3.0 billion during fiscal year 2019. As further discussed below, cash collections on the deferred purchase price from our ABS Programs of $3.6 billion were included in cash from investing activities instead of cash from operating activities in accordance with new accounting guidance adopted in fiscal year 2019. The total cash used in operating activities resulted primarily from $93 million of net income for the period plus $804 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, provision for doubtful accounts, and stock-based compensation, net of a gain of $87 million from the deconsolidation of Bright Machines which were included in the determination of net income. Depreciation expense was $433 million and relatively consistent with prior years. These additions were more than offset by a net change in our operating assets and liabilities of $3.9 billion. In accordance with the new accounting guidance adopted in fiscal year 2019, cash collections on deferred purchase price from our ABS Programs were classified as cash flows from investing activities and no longer included in cash receipts related to accounts receivable. As a result, while accounts receivable only increased by approximately $95 million from fiscal year 2018 to fiscal year 2019, the

[0000866374-20-000009:mdna:155]
impact to operating cash flows is an outflow of $3.6 billion. Year over year increases in inventory and contract assets also added to the net change in our operating assets and liabilities reflected on our cash flow from operations.

[0000866374-20-000009:mdna:156]
Cash provided by investing activities totaled $3.3 billion during fiscal year 2019. This was primarily driven by the impact of our adoption of ASU 2016-15 during fiscal year 2019 referred to above, which requires us to classify cash collections on deferred purchase price from our ABS Programs that were previously classified as operating cash inflows as cash flows from investing activities. In addition, we received $267 million of proceeds, net of cash held, in connection with the divestitures of our China-based Multek operations as further described in note 18 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data". We also invested $631 million of net capital expenditures for property and equipment to expand capabilities and capacity in support of our expanding IEI and HRS businesses.

[0000866374-20-000009:mdna:157]
Cash used in financing activities was $30 million during fiscal year 2019. This was primarily the result of repurchases of ordinary shares in the amount of $189 million, offset by $170 million received from the drawdown of India Facilities.

[0000866374-20-000009:mdna:158]
Fiscal Year 2018

[0000866374-20-000009:mdna:159]
Cash used in operating activities for fiscal year 2018 was recast to $3.9 billion, subsequent to the adoption of ASU 2016-15 in fiscal year 2019, as further described above. Cash collections on the deferred purchase price from our ABS Programs of $4.6 billion were included in cash from investing activities instead of cash from operating activities in accordance with new accounting guidance. The total cash used in operating activities resulted primarily from $429 million of net income for the period plus $478 million of non-cash charges such as depreciation, amortization and stock-based compensation, net of a gain from the deconsolidation of Elementum that are included in the determination of net income. Depreciation expense was $434 million of those non-cash charges. These were more than offset by a net change in our operating assets and liabilities of $4.8 billion, driven primarily by the $4.6 billion reclass of cash collection on deferred purchase price discussed above, coupled with a $354 million increase in inventories, an $88 million increase in other current and noncurrent assets, and a $347 million increase in accounts receivable, including the change in sales of accounts receivable, offset by a $623 million increase in accounts payable.

[0000866374-20-000009:mdna:160]
Cash provided by investing activities for fiscal year 2018 was also recast to $3.7 billion subsequent to the adoption of ASU 2016-15 in fiscal year 2019, as further described above. This resulted primarily from the $4.6 billion reclassification of cash collections on the deferred purchase price, partially offset by $214 million paid for the acquisition of AGM Automotive for our HRS segment, net of cash acquired, and $55 million paid for a power module business for our CEC segment, net of cash acquired. Further, we invested $517 million of net capital expenditures for property and equipment to expand capabilities and capacity in support of our automotive, medical, footwear and IEI businesses. In addition, other investing activities includes $73 million of cash derecognized as of the date of the Elementum deconsolidation, and $46 million of payments for non-core investments, net of cash received.

[0000866374-20-000009:mdna:161]
Cash used in financing activities was $188 million during fiscal year 2018. This was primarily the result of repurchases of ordinary shares in the amount of $180 million, and the repayment of $55 million of debt, partially offset by $65 million received from third party investors in fiscal year 2018 in exchange for an additional noncontrolling equity interest in Elementum prior to the deconsolidation described above.

[0000866374-20-000009:mdna:162]
Adjusted Free Cash Flow

[0000866374-20-000009:mdna:163]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligation, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, plus cash collections of deferred purchase price receivables, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency (refer to note 8 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for discussion of the amendments of the ABS Programs). We also excluded the impact to cash flows related to certain vendor programs that is required for U.S. GAAP presentation. Our adjusted free cash flow was $672 million, $3 million and $236 million for fiscal years 2020, 2019 and 2018, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-20-000009:mdna:164]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In millions) |
| Net cash used in operating activities | $ | (1,533 | ) |  | $ | (2,971 | ) |  | $ | (3,866 | ) |
| Cash collection of deferred purchase price and other | 2,561 |  |  | 3,605 |  |  | 4,620 |  |
| Purchases of property and equipment | (462 | ) |  | (725 | ) |  | (562 | ) |
| Proceeds from the disposition of property and equipment | 106 |  |  | 94 |  |  | 44 |  |
| Adjusted free cash flow | $ | 672 |  |  | $ | 3 |  |  | $ | 236 |  |

[0000866374-20-000009:mdna:165]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months.

[0000866374-20-000009:mdna:166]
In response to the recent challenging environment following the COVID-19 pandemic, we have evaluated our ability to meet our obligations over the next 12 months and expect that our current financial condition, including our liquidity sources are adequate to fund future commitments. As of March 31, 2020, we had cash and cash equivalents of $1.9 billion and access to a $1.75 billion revolving credit facility that is due to mature in June 2022, under which we had no borrowings outstanding. The revolving credit facility provides us flexibility to manage working capital and capital expenditures. Further, in May 2020, we issued $425 million aggregate principal amount of 3.750% Notes due February 2026, at 99.617% of face value, and $325 million aggregate principal amount of 4.875% Notes due May 2030, at 99.562% of face value. The total proceeds of $740 million, net of discount and issuance costs, are expected to be used for general corporate purposes, which may include repaying, redeeming or repurchasing outstanding debt and for working capital, capital expenditures and acquisitions. As discussed above, we also took a number of steps to enhance our liquidity positions including (1) suspending share repurchases, (2) further tightening capital expenditures to only fund critical investments in our highest margin opportunities, and (3) aggressively reducing discretionary corporate spend and enacting targeted pay reductions. We believe we are well positioned with ample access to liquidity.

[0000866374-20-000009:mdna:167]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volumes of customer orders.

[0000866374-20-000009:mdna:168]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. During fiscal years ended March 31, 2020 and 2019, the cumulative payments due to suppliers participating in the programs amounted to approximately $0.9 billion and $0.5 billion, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-20-000009:mdna:169]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to commercial paper program and revolving sale and repurchase of subordinated note established under the securitization facility, under which there were no borrowings outstanding as of March 31, 2020.

[0000866374-20-000009:mdna:170]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under ABS Programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth.

[0000866374-20-000009:mdna:171]
During fiscal years 2020, 2019 and 2018, we received approximately $7.6 billion, $6.8 billion and $8.0 billion, respectively from transfers of receivables under our ABS Programs, and $1.6 billion, $2.7 billion and $1.5 billion, respectively from other sales of receivables. As of March 31, 2020, and 2019, the outstanding balance on receivables sold for cash was $1.2 billion and $1.3 billion, respectively, under all our asset-backed securitization programs and accounts receivable factoring program, which were removed from accounts receivable balances in our consolidated balance sheets.

[0000866374-20-000009:mdna:172]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In June 2017, we entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $503 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6 million from September 30, 2017 through June 30, 2020 and approximately $13 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity.

[0000866374-20-000009:mdna:173]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares. Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 20, 2019. During fiscal year 2020, we paid $260 million to repurchase shares (under the current and prior repurchase plans) at an average price of $10.98 per share. As of March 31, 2020, shares in the aggregate amount of $315 million were available to be repurchased under the current plan.

[0000866374-20-000009:mdna:174]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-20-000009:mdna:175]
Bank borrowings and long-term debt are as follows:

[0000866374-20-000009:mdna:176]
|  | As of March 31, |
|  | 2020 |  | 2019 |
|  | (In millions) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500 |  |
| Term Loan, including current portion, due in installments through November 2021 | — |  |  | 672 |  |
| Term Loan, including current portion, due in installments through June 2022 | 433 |  |  | 459 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 310 |  |  | — |  |
| 4.750% Notes due June 2025 | 597 |  |  | 597 |  |
| 4.875% Notes due June 2029 | 662 |  |  | — |  |
| India Facilities (1) | 138 |  |  | 170 |  |
| Other | 211 |  |  | 168 |  |
| Debt issuance costs | (13 | ) |  | (11 | ) |
|  | 2,838 |  |  | 3,055 |  |
| Current portion, net of debt issuance costs | (149 | ) |  | (633 | ) |
| Non-current portion | $ | 2,689 |  |  | $ | 2,422 |  |

[0000866374-20-000009:mdna:177]
| (1) | India Facilities as of March 31, 2019 include an approximately $91.4 million drawdown of short-term bank borrowings under a facility entered in February 2019 which was repaid in May 2019 and a $78.8 million drawdown from the $200 million term loan facility entered in July 2018. |

[0000866374-20-000009:mdna:178]
Refer to the discussion in note 8 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details of our debt obligations. In May 2020, we issued $425 million aggregate principal amount of 3.750% Notes due February 2026, at 99.617% of face value, and $325 million aggregate principal amount of  4.875% Notes due May 2030, at 99.562% of face value. The total proceeds of $740 million, net of discount and issuance costs, are expected to be used for general corporate purposes, which may include repaying, redeeming or repurchasing outstanding debt and for working capital, capital expenditures and acquisitions.

[0000866374-20-000009:mdna:179]
We have purchase obligations that arise in the normal course of business, primarily consisting of binding purchase orders for inventory related items and capital expenditures. Additionally, we have leased certain of our property and equipment under finance lease commitments, and certain of our facilities and equipment under operating lease commitments.

[0000866374-20-000009:mdna:180]
Future payments due under our purchase obligations, debt including finance leases and related interest obligations and operating leases are as follows (amounts may not sum due to rounding):

[0000866374-20-000009:mdna:181]
|  | Total |  | Less Than1 Year |  | 1 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In millions) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase obligations | $ | 3,706 |  |  | $ | 3,706 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Bank borrowings, long-term debt and finance lease obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and long-term debt | 2,852 |  |  | 149 |  |  | 1,080 |  |  | 363 |  |  | 1,259 |  |
| Finance leases | 29 |  |  | 12 |  |  | 16 |  |  | 1 |  |  | — |  |
| Interest on long-term debt obligations | 550 |  |  | 110 |  |  | 198 |  |  | 105 |  |  | 137 |  |
| Operating leases, net of subleases | 755 |  |  | 133 |  |  | 216 |  |  | 152 |  |  | 254 |  |
| Restructuring costs | 23 |  |  | 23 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 7,915 |  |  | $ | 4,133 |  |  | $ | 1,510 |  |  | $ | 621 |  |  | $ | 1,650 |  |

[0000866374-20-000009:mdna:182]
We have excluded $246 million of liabilities for unrecognized tax benefits from the contractual obligations table as we cannot make a reasonably reliable estimate of the periodic settlements with the respective taxing authorities. See note 14, "Income Taxes" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-20-000009:mdna:183]
Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-20-000009:mdna:184]
OFF-BALANCE SHEET ARRANGEMENTS

[0000866374-20-000009:mdna:185]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS Programs. Effective November 2019, we amended the structure and removed the requirement for the deferred purchase price receivable. Under the amended ABS Programs, the entire purchase price of sold receivables are paid in cash and are guaranteed. For further information on the amendment see note 11 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data". Prior to November 2019, under the ABS Programs, in addition to cash, we received a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables served as additional credit support to the financial institutions and was recorded at its estimated fair value. As of March 31, 2019, the fair value of our deferred purchase price receivable was approximately $293 million. There are no deferred purchase price receivables outstanding as of March 31, 2020.

[0000866374-20-000009:mdna:186]
As of March 31, 2020 and 2019, the outstanding balance on receivables sold for cash was $1.2 billion and $1.3 billion, respectively, under our asset-backed securitization programs and accounts receivable factoring program, which were removed from accounts receivable balances in our consolidated balance sheets. For further information, see note 11 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data".

[0000866374-20-000009:mdna:187]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-20-000009:mdna:188]
Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for recent accounting pronouncements.

[0000866374-20-000009:mdna:189]
52
