# FLEX 10-K controls and the auditor's report


## auditors_report

[0000866374-20-000009:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000866374-20-000009:auditors_report:2]
To the Board of Directors and Shareholders of Flex Ltd., Singapore

[0000866374-20-000009:auditors_report:3]
Opinion on the Financial Statements

[0000866374-20-000009:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Flex Ltd. and subsidiaries (the "Company") as of March 31, 2020 and 2019, and the related consolidated statements of operations, comprehensive income, shareholders' equity, and cash flows for each of the three years in the period ended March 31, 2020, and the related notes (collectively referred to as the “financial statements”). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of March 31, 2020 and 2019, and the results of its operations and its cash flows for each of the three years in the period ended March 31, 2020, in conformity with accounting principles generally accepted in the United States of America.

[0000866374-20-000009:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of March 31, 2020, based on the criteria established in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated May 28, 2020, expressed an unqualified opinion on the Company's internal control over financial reporting.

[0000866374-20-000009:auditors_report:6]
Change in Accounting Principles

[0000866374-20-000009:auditors_report:7]
As discussed in Note 2 to the financial statements, the Company changed its method of accounting for leases in fiscal year 2020 due to the adoption of Accounting Standard Update (ASU) No. 2016-02, Leases. In fiscal year 2019, the Company changed its method of accounting for revenue from contracts with customers due to the adoption of ASU No. 2014-09, Revenue from Contracts with Customers, using the modified retrospective approach.

[0000866374-20-000009:auditors_report:8]
Basis of Opinion

[0000866374-20-000009:auditors_report:9]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on these financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the US federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000866374-20-000009:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence supporting the amounts and disclosures in the financial statements. Our audits also included assessing the accounting principles used and significant estimates made by management, as well as evaluating the overall financial statement presentation. We believe that our audits provide a reasonable basis for our opinion.

[0000866374-20-000009:auditors_report:11]
Critical Audit Matters

[0000866374-20-000009:auditors_report:12]
The critical audit matters communicated below are matters arising from the current-period audit of the financial statements that were communicated or required to be communicated to the audit committee and that (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0000866374-20-000009:auditors_report:13]
Goodwill - Consumer Technologies Group and Communications & Enterprise Compute Reporting Units - Refer to Note 2 to the financial statements

[0000866374-20-000009:auditors_report:14]
Critical Audit Matter Description

[0000866374-20-000009:auditors_report:15]
The Company’s evaluation of goodwill for impairment involves the comparison of the fair value of each reporting unit to its carrying value. The Company determines the fair value of its reporting units using a combination of a discounted cash flow model and the market approach. The determination of the fair value using the discounted cash flow model and market approach requires management to make significant judgments and assumptions related to forecasts of future revenues, earnings before interest, taxes, depreciation, and amortization (EBITDA), and capital expenditures, and the selection of the discount rate.

[0000866374-20-000009:auditors_report:16]
55

[0000866374-20-000009:auditors_report:17]
As of March 31, 2020, the goodwill balance was approximately $1.1 billion, of which $103.3 million and $129.3 million was allocated to the Consumer Technologies Group (“CTG”) and Communications & Enterprise Compute (“CEC”) reporting units, respectively. The fair values of the CTG and CEC reporting units exceeded their carrying values as of the measurement date and, therefore, no impairment was recognized.

[0000866374-20-000009:auditors_report:18]
We identified the goodwill valuation for CTG and CEC as a critical audit matter due to the relatively small excess of each reporting unit’s fair value over its book value, the significant judgments and assumptions made by management to estimate the fair value of the reporting units, and the inherent uncertainty of future forecasts that are dependent on the Company executing against its strategy for CTG and CEC. These factors required a high degree of auditor judgement and an increased extent of effort, including the need to involve our fair value specialists, when performing audit procedures to evaluate the reasonableness of management’s judgments and assumptions related to forecasts of future revenues, EBITDA and capital expenditures, and the selection of the discount rate. For these reasons we identified the valuation of CTG and CEC goodwill as a critical audit matter.

[0000866374-20-000009:auditors_report:19]
How the Critical Audit Matter Was Addressed in the Audit

[0000866374-20-000009:auditors_report:20]
Our audit procedures related to the forecasts of the CTG and CEC reporting units’ future revenues, EBITDA and capital expenditures, and the selection of the discount rate, included the following, among others:

[0000866374-20-000009:auditors_report:21]
| • | We tested the effectiveness of internal controls over management’s goodwill impairment evaluation, including those over the forecasts of future revenue, EBITDA and capital expenditures, and selection of the discount rate. |

[0000866374-20-000009:auditors_report:22]
| • | We evaluated the reasonableness of management’s revenue, EBITDA and capital expenditures forecasts by comparing the forecasts to: |

[0000866374-20-000009:auditors_report:23]
| • | Historical revenues, EBITDA, and capital expenditures; |

[0000866374-20-000009:auditors_report:24]
| • | Internal communications to management and the Board of Directors; |

[0000866374-20-000009:auditors_report:25]
| • | Forecasted information included in Company press releases as well as in analyst and industry reports of the Company and companies in its peer group. |

[0000866374-20-000009:auditors_report:26]
| • | With the assistance of our fair value specialists, we evaluated the reasonableness of (1) the valuation methodology and (2) the discount rate by: |

[0000866374-20-000009:auditors_report:27]
| • | Testing the source information underlying the determination of the discount rate and the mathematical accuracy of the calculation; |

[0000866374-20-000009:auditors_report:28]
| • | Developing a range of independent estimates and comparing those to the discount rate selected by management. |

[0000866374-20-000009:auditors_report:29]
Revenue - Customer Contracts and Related Obligations - Refer to Notes 2 and 4 to the financial statements

[0000866374-20-000009:auditors_report:30]
Critical Audit Matter Description

[0000866374-20-000009:auditors_report:31]
Certain of the Company’s customer agreements include potential price adjustments which are accounted for as variable consideration under the relevant accounting literature. For arrangements that include potential price adjustments the Company limits the amount of revenue recognized to that amount which is not probable of significant reversal, considering potential refunds required by the contract, historical experience and other surrounding facts and circumstances. The amount of variable consideration that is deferred is recorded in ‘customer-related accruals’ on the consolidated balance sheets, which totaled $195.1 million as of March 31, 2020.

[0000866374-20-000009:auditors_report:32]
Auditing the Company’s estimates of variable consideration required extensive audit effort and a high degree of auditor judgment. For these reasons we identified the measurement of variable consideration and the associated customer-related accruals as a critical audit matter.

[0000866374-20-000009:auditors_report:33]
How the Critical Audit Matter Was Addressed in the Audit

[0000866374-20-000009:auditors_report:34]
Our audit procedures related to variable consideration and associated customer related accruals included the following, among others:

[0000866374-20-000009:auditors_report:35]
| • | We tested the effectiveness of controls the Company has in place relating to reviewing customer contracts to identify price adjustment clauses, estimating variable consideration and assessing the reasonableness of customer related accrual balances. |

[0000866374-20-000009:auditors_report:36]
| • | We evaluated the Company’s accounting policy with respect to variable consideration, as well as its process for identifying contracts that include potential price adjustment clauses. |

[0000866374-20-000009:auditors_report:37]
| • | We selected a sample of contracts with customers that included potential price adjustment clauses and performed the following: |

[0000866374-20-000009:auditors_report:38]
| • | We read the customer contracts to develop an understanding of clauses that could give rise to variable consideration and evaluated whether the Company’s accounting conclusions with respect to those clauses were reasonable. |

[0000866374-20-000009:auditors_report:39]
56

[0000866374-20-000009:auditors_report:40]
| • | We obtained and tested the mathematical accuracy of the Company’s calculations of customer related accruals and evaluated the Company’s judgments regarding the amount of variable consideration that should be deferred. In making this evaluation we considered both the terms included in the customer contract and the Company’s historical experience in settling amounts with the customer. |

[0000866374-20-000009:auditors_report:41]
| • | We tested the recognition of previous deferrals for variable consideration to determine whether the conditions that resulted in the prior deferral had been resolved to support recognition of revenues in the current year. |

[0000866374-20-000009:auditors_report:42]
/s/ DELOITTE & TOUCHE LLP

[0000866374-20-000009:auditors_report:43]
San Jose, California

[0000866374-20-000009:auditors_report:44]
May 28, 2020

[0000866374-20-000009:auditors_report:45]
We have served as the Company’s auditors since 2002.

[0000866374-20-000009:auditors_report:46]
57

[0000866374-20-000009:auditors_report:47]
FLEX LTD.


## item_9a

[0000866374-20-000009:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0000866374-20-000009:item_9a:2]
| (a) | Evaluation of Disclosure Controls and Procedures |

[0000866374-20-000009:item_9a:3]
The Company's management, with the participation of the Chief Executive Officer and Chief Financial Officer has evaluated the effectiveness of the Company's disclosure controls and procedures (as defined in Rule 13a-15(e) under the Exchange Act) as of March 31, 2020. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer concluded that, as of March 31, 2020, the Company's disclosure controls and procedures were effective in ensuring that information required to be disclosed by the Company in reports that it files or submits under the Securities Exchange Act of 1934, as amended, is (i) recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms and (ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000866374-20-000009:item_9a:4]
| (b) | Management's Annual Report on Internal Control over Financial Reporting |

[0000866374-20-000009:item_9a:5]
107

[0000866374-20-000009:item_9a:6]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Rule 13a-15(f) under the Securities Exchange Act of 1934, as amended. Internal control over financial reporting consists of policies and procedures that: (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (2) are designed and operated to provide reasonable assurance regarding the reliability of the Company's financial reporting and the Company's process for the preparation of financial statements for external purposes in accordance with generally accepted accounting principles and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of the Company’s assets that could have a material effect on the financial statements. Because of its inherent limitations, a system of internal control over financial reporting can provide only reasonable assurance and may not prevent or detect misstatements or prevent or detect instances of fraud. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of simple error or mistake. Additionally, controls may be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the control. The projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000866374-20-000009:item_9a:7]
As of March 31, 2020, under the supervision and with the participation of management, including the Company's Chief Executive Officer and Chief Financial Officer, an evaluation was conducted of the effectiveness of the Company's internal control over financial reporting based on the framework in Internal Control—Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO"). Based on that evaluation, management concluded that the Company's internal control over financial reporting was effective as of March 31, 2020.

[0000866374-20-000009:item_9a:8]
| (c) | Attestation Report of the Registered Public Accounting Firm |

[0000866374-20-000009:item_9a:9]
The effectiveness of the Company's internal control over financial reporting as of March 31, 2020 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, as stated in their report which appears in this Item under the heading "Report of Independent Registered Public Accounting Firm."

[0000866374-20-000009:item_9a:10]
| (d) | Changes in Internal Control Over Financial Reporting |

[0000866374-20-000009:item_9a:11]
There were no changes in our internal control over financial reporting that occurred during the fourth quarter ended March 31, 2020 that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000866374-20-000009:item_9a:12]
108

[0000866374-20-000009:item_9a:13]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000866374-20-000009:item_9a:14]
To the Board of Directors and Shareholders of Flex Ltd., Singapore

[0000866374-20-000009:item_9a:15]
Opinion on Internal Control over Financial Reporting

[0000866374-20-000009:item_9a:16]
We have audited the internal control over financial reporting of Flex Ltd. and subsidiaries (the "Company") as of March 31, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of March 31, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by COSO.

[0000866374-20-000009:item_9a:17]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended March 31, 2020 of the Company and our report dated May 28, 2020, expressed an unqualified opinion on those financial statements and included an explanatory paragraph related to the Company’s change in method of accounting for leases in fiscal year 2020 due to the adoption of Accounting Standard Update (ASU) No. 2016-02, Leases, and change in method of accounting for revenue from contracts with customers in fiscal year 2019 due to the adoption of ASU No. 2014-09, Revenue from Contracts with Customers.

[0000866374-20-000009:item_9a:18]
Basis for Opinion

[0000866374-20-000009:item_9a:19]
The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Annual Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company's internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000866374-20-000009:item_9a:20]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000866374-20-000009:item_9a:21]
Definition and Limitations of Internal Control over Financial Reporting

[0000866374-20-000009:item_9a:22]
A company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

[0000866374-20-000009:item_9a:23]
Because of its inherent limitations, internal control over financial reporting, may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000866374-20-000009:item_9a:24]
/s/ DELOITTE & TOUCHE LLP

[0000866374-20-000009:item_9a:25]
San Jose, California

[0000866374-20-000009:item_9a:26]
May 28, 2020

[0000866374-20-000009:item_9a:27]
109
