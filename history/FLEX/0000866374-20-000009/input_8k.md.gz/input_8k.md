# FLEX 8-K — 0001104659-20-058102 filed 2020-05-07

## item codes, every 8-K on or before 2020-05-28

- 2020-05-12 0001104659-20-060179 — 1.01, 8.01, 9.01
- 2020-05-07 0001104659-20-058102 — 2.02, 8.01, 9.01
- 2020-04-20 0000866374-20-000005 — 5.02, 9.01 — amendment of 0001104659-20-044212
- 2020-04-07 0001104659-20-044212 — 5.02, 7.01, 9.01
- 2020-04-02 0001104659-20-042445 — 5.02, 8.01, 9.01
- 2020-03-09 0001104659-20-030489 — 7.01, 9.01
- 2020-01-30 0001104659-20-008704 — 2.02, 9.01
- 2019-11-07 0001104659-19-061133 — 8.01, 9.01
- 2019-10-24 0001104659-19-056135 — 2.02, 9.01
- 2019-08-23 0001410578-19-000891 — 3.03, 5.07, 8.01, 9.01
- 2019-08-08 0001410578-19-000722 — 8.01
- 2019-07-25 0001104659-19-041852 — 2.02, 2.05, 9.01
- 2019-06-10 0001410578-19-000371 — 5.02
- 2019-06-06 0001104659-19-034315 — 1.01, 8.01, 9.01
- 2019-05-31 0001104659-19-032835 — 8.01, 9.01
- 2019-05-30 0001104659-19-032818 — 8.01, 9.01
- 2019-05-30 0001104659-19-032593 — 8.01, 9.01
- 2019-04-30 0001104659-19-025293 — 2.02, 9.01
- 2019-03-07 0001104659-19-013420 — 5.02
- 2019-02-11 0001104659-19-006978 — 5.02, 7.01, 9.01
- 2019-02-06 0001104659-19-005884 — 5.02
- 2019-01-30 0001104659-19-004485 — 2.02, 9.01
- 2019-01-18 0001104659-19-002495 — 5.02
- 2018-12-28 0001104659-18-075143 — 5.02
- 2018-12-11 0001104659-18-072382 — 5.02
- 2018-11-15 0001104659-18-068678 — 5.02, 9.01
- 2018-10-25 0001104659-18-063948 — 2.02, 9.01
- 2018-10-25 0001104659-18-063944 — 5.02, 9.01
- 2018-08-21 0001104659-18-053031 — 5.07, 8.01, 9.01
- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2020-05-28

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-20-058102:8k_2_02:1]
EX-99.1
2
tm2018557d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-20-058102:8k_2_02:2]
Exhibit 99.1

[0001104659-20-058102:8k_2_02:3]
FLEX REPORTS FOURTH QUARTER
AND FISCAL 2020 RESULTS

[0001104659-20-058102:8k_2_02:4]
San Jose, Calif., May 7, 2020 –
Flex (NASDAQ: FLEX) today announced results for its fourth quarter and fiscal year ended March 31, 2020.

[0001104659-20-058102:8k_2_02:5]
Fourth Quarter Fiscal Year 2020 Highlights:

[0001104659-20-058102:8k_2_02:6]
|  | · | Net Sales: $5.5 billion |

[0001104659-20-058102:8k_2_02:7]
|  | · | GAAP Income Before Income Taxes: $45 million |

[0001104659-20-058102:8k_2_02:8]
|  | · | Adjusted Operating Income: $207 million |

[0001104659-20-058102:8k_2_02:9]
|  | · | GAAP Net Income: $48 million |

[0001104659-20-058102:8k_2_02:10]
|  | · | Adjusted Net Income: $143 million |

[0001104659-20-058102:8k_2_02:11]
|  | · | GAAP Earnings Per Share: $0.10 |

[0001104659-20-058102:8k_2_02:12]
|  | · | Adjusted Earnings Per Share: $0.28 |

[0001104659-20-058102:8k_2_02:13]
Fiscal Year 2020 Results of Operations:

[0001104659-20-058102:8k_2_02:14]
|  | · | Net Sales: $24.2 billion |

[0001104659-20-058102:8k_2_02:15]
|  | · | GAAP Income Before Income Taxes: $158 million |

[0001104659-20-058102:8k_2_02:16]
|  | · | Adjusted Operating Income: $898 million |

[0001104659-20-058102:8k_2_02:17]
|  | · | GAAP Net Income: $88 million |

[0001104659-20-058102:8k_2_02:18]
|  | · | Adjusted Net Income: $632 million |

[0001104659-20-058102:8k_2_02:19]
|  | · | GAAP Earnings Per Share: $0.17 |

[0001104659-20-058102:8k_2_02:20]
|  | · | Adjusted Earnings Per Share: $1.23 |

[0001104659-20-058102:8k_2_02:21]
An explanation and reconciliation
of non-GAAP financial measures to GAAP financial measures is presented in Schedules II and V attached to this press release.

[0001104659-20-058102:8k_2_02:22]
“We are pleased with
our fourth quarter results despite the negative impact from the COVID-19 pandemic,” said Revathi Advaithi, Flex’s Chief
Executive Officer. “Our Fiscal 2020 results demonstrate our progress on shifting our portfolio, operating with disciplined
execution, managing our costs, focusing on generating free cash flow, and being prudent with our capital.”

[0001104659-20-058102:8k_2_02:23]
Response to COVID-19

[0001104659-20-058102:8k_2_02:24]
The Company’s fourth
quarter results were negatively impacted by the ongoing COVID-19 global pandemic, and the resulting supply chain and demand disruptions.
Since the last update at the Investor and Analyst webcast on March 11, 2020, the Company has continued to take proactive actions
to protect employee safety, mitigate work stoppages, support customers and suppliers, and strengthen liquidity. These measures
include:

[0001104659-20-058102:8k_2_02:25]
|  | · | Enforcing strict health and sanitation measures at global sites in compliance with governmental policies |

[0001104659-20-058102:8k_2_02:26]
|  | · | Enacting work from home policies for workers that can safely and effectively do so |

[0001104659-20-058102:8k_2_02:27]
|  | · | Reducing component shortages significantly from peak levels in February |

[0001104659-20-058102:8k_2_02:28]
|  | · | Partnering with healthcare customers on products such as ventilators, oxygen concentrators, patient monitors, infusion pumps and ICU beds |

[0001104659-20-058102:8k_2_02:29]
|  | · | Deploying a combination of graduated salary cuts and furloughs |

[0001104659-20-058102:8k_2_02:30]
|  | · | Suspending capital expenditures for non-critical investments |

[0001104659-20-058102:8k_2_02:31]
|  | · | Temporarily suspending share repurchases from mid-March |

[0001104659-20-058102:8k_2_02:32]
“As always, our priority
remains on the health and safety of our employees,” said Advaithi. “I am incredibly proud of our company’s response
and ability to bring our customers’ life-saving products rapidly to market. I want to especially thank our Flex employees
working in our factories who are delivering our customers’ essential products. I also want to thank our suppliers for their
partnership and commitment to supporting us during this challenging time.”

[0001104659-20-058102:8k_2_02:33]
“We began the quarter
with strong liquidity and acted quickly to further improve our financial position in this uncertain environment,” added Chris
Collier, Flex’s Chief Financial Officer. “Our actions put us on good footing to meet the demands of operating our business
through this downturn. We will continue to drive cost savings, improvements to inventory and working capital, and prudent capital
management, to ensure the durability of our strong financial position.”

[0001104659-20-058102:8k_2_02:34]
Looking Ahead

[0001104659-20-058102:8k_2_02:35]
As a result of the material impact from
the COVID-19 pandemic on our workforce and operations, as well as the lack of visibility as to the duration and potential outcomes
of the pandemic, the Company is electing to suspend quarterly guidance for the June quarter and is unable to provide detailed fiscal
year 2021 guidance at this time. However, the Company expects June quarter sales to decline by a high-single to low-double digits
percentage sequentially, due to the ongoing impact of COVID-19.

[0001104659-20-058102:8k_2_02:36]
Change in Reportable Segments

[0001104659-20-058102:8k_2_02:37]
In March 2020, the Company announced a
change in organization structure as part of its strategy to further drive efficiency and productivity with two focused delivery
models. During the first quarter of fiscal year 2021, the Company’s chief operating decision maker (“CODM”) changed
the information she regularly reviews to allocate resources and to assess performance. As a result, beginning in fiscal year 2021,
the Company expects to report its financial performance based on two reportable segments (Flex Agility Solutions Group and Flex
Reliability Solutions Group) and analyze operating income as the measure of segment profitability.

[0001104659-20-058102:8k_2_02:38]
Webcast and Conference Call

[0001104659-20-058102:8k_2_02:39]
The
Flex management team will host a conference call today at 2:00 PM (PT) / 5:00 PM (ET), to review fourth quarter and fiscal 2020
results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com.
An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0001104659-20-058102:8k_2_02:40]
About Flex

[0001104659-20-058102:8k_2_02:41]
Flex (Reg. No. 199002645H) is the manufacturing partner of choice
that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global
workforce across 30 countries and responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing
solutions to diverse industries and end markets.

[0001104659-20-058102:8k_2_02:42]
Contacts

[0001104659-20-058102:8k_2_02:43]
Investors & Analysts

[0001104659-20-058102:8k_2_02:44]
David Rubin

[0001104659-20-058102:8k_2_02:45]
Vice President, Investor Relations

[0001104659-20-058102:8k_2_02:46]
(408) 577-4632

[0001104659-20-058102:8k_2_02:47]
David.Rubin@flex.com

[0001104659-20-058102:8k_2_02:48]
Media & Press

[0001104659-20-058102:8k_2_02:49]
Silvia Gianelli

[0001104659-20-058102:8k_2_02:50]
Senior Director, Corporate Communications

[0001104659-20-058102:8k_2_02:51]
(408) 797-7130

[0001104659-20-058102:8k_2_02:52]
Silvia.gianelli@flex.com

[0001104659-20-058102:8k_2_02:53]
Forward-Looking Statements

[0001104659-20-058102:8k_2_02:54]
Additional information
concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis
of Financial Condition and Results of Operations” in our annual report on Form 10-K for the fiscal year ended March 31, 2019
and our quarterly reports on Form 10-Q for the fiscal quarters ended September 27, 2019 and December 31, 2019, and in the risk
factor included in our Current Report on Form 8-K dated May 7, 2020. The forward-looking statements in this press release are based
on current expectations and Flex assumes no obligation to update these forward-looking statements. Our share repurchase program
does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without
prior notice.

[0001104659-20-058102:8k_2_02:55]
P R E S S R E L E A S E

[0001104659-20-058102:8k_2_02:56]
SCHEDULE I

[0001104659-20-058102:8k_2_02:57]
FLEX

[0001104659-20-058102:8k_2_02:58]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-20-058102:8k_2_02:59]
(In thousands, except per share amounts)

[0001104659-20-058102:8k_2_02:60]
|  |  | Three-Month Periods Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| GAAP: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,484,490 |  |  | $ | 6,226,124 |  |
| Cost of sales |  |  | 5,103,434 |  |  |  | 5,836,336 |  |
| Restructuring charges |  |  | 15,429 |  |  |  | 9,493 |  |
| Gross profit |  |  | 365,627 |  |  |  | 380,295 |  |
| Selling, general and administrative expenses |  |  | 201,267 |  |  |  | 230,469 |  |
| Intangible amortization |  |  | 15,203 |  |  |  | 17,337 |  |
| Restructuring charges |  |  | 1,855 |  |  |  | 3,387 |  |
| Interest and other, net |  |  | 28,077 |  |  |  | 46,565 |  |
| Other charges, net |  |  | 74,545 |  |  |  | 118,929 |  |
| Income (loss) before income taxes |  |  | 44,680 |  |  |  | (36,392 | ) |
| Provision for (benefit from) income taxes |  |  | (3,579 | ) |  |  | 27,960 |  |
| Net income (loss) |  | $ | 48,259 |  |  | $ | (64,352 | ) |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.10 |  |  | $ | (0.12 | ) |
| Non-GAAP |  | $ | 0.28 |  |  | $ | 0.27 |  |
| Basic shares used in computing per share amounts (2) |  |  | 501,446 |  |  |  | 520,379 |  |
| Diluted shares used in computing per share amounts (2) |  |  | 505,593 |  |  |  | 520,379 |  |

[0001104659-20-058102:8k_2_02:61]
|  | See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |

[0001104659-20-058102:8k_2_02:62]
P R E S S R E L E A S E

[0001104659-20-058102:8k_2_02:63]
FLEX

[0001104659-20-058102:8k_2_02:64]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-20-058102:8k_2_02:65]
(In thousands, except per share amounts)

[0001104659-20-058102:8k_2_02:66]
|  |  | Twelve-Month Periods Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| GAAP: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 24,209,870 |  |  | $ | 26,210,511 |  |
| Cost of sales |  |  | 22,681,490 |  |  |  | 24,593,731 |  |
| Restructuring charges |  |  | 190,424 |  |  |  | 99,005 |  |
| Gross profit |  |  | 1,337,956 |  |  |  | 1,517,775 |  |
| Selling, general and administrative expenses |  |  | 834,105 |  |  |  | 953,077 |  |
| Intangible amortization |  |  | 64,106 |  |  |  | 74,396 |  |
| Restructuring charges |  |  | 25,983 |  |  |  | 14,308 |  |
| Interest and other, net |  |  | 163,727 |  |  |  | 183,454 |  |
| Other charges, net |  |  | 91,550 |  |  |  | 110,414 |  |
| Income before income taxes |  |  | 158,485 |  |  |  | 182,126 |  |
| Provision for income taxes |  |  | 70,906 |  |  |  | 88,727 |  |
| Net income |  | $ | 87,579 |  |  | $ | 93,399 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.17 |  |  | $ | 0.18 |  |
| Non-GAAP |  | $ | 1.23 |  |  | $ | 1.14 |  |
| Diluted shares used in computing per share amounts |  |  | 512,437 |  |  |  | 530,070 |  |

[0001104659-20-058102:8k_2_02:67]
|  | See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |

[0001104659-20-058102:8k_2_02:68]
P R E S S R E L E A S E

[0001104659-20-058102:8k_2_02:69]
SCHEDULE II

[0001104659-20-058102:8k_2_02:70]
FLEX

[0001104659-20-058102:8k_2_02:71]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-20-058102:8k_2_02:72]
(In thousands, except per share amounts)

[0001104659-20-058102:8k_2_02:73]
|  |  | Three-Month Periods Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| GAAP gross profit |  | $ | 365,627 |  |  | $ | 380,295 |  |
| Stock-based compensation expense |  |  | 3,747 |  |  |  | 4,614 |  |
| Customer related asset impairments (3) |  |  | 8,665 |  |  |  | 4,841 |  |
| Restructuring charges (4) |  |  | 15,429 |  |  |  | 9,493 |  |
| Legal and other (5) |  |  | (1,859 | ) |  |  | 8,714 |  |
| Non-GAAP gross profit |  | $ | 391,609 |  |  | $ | 407,957 |  |
| GAAP income (loss) before income taxes |  | $ | 44,680 |  |  | $ | (36,392 | ) |
| Intangible amortization |  |  | 15,203 |  |  |  | 17,337 |  |
| Stock-based compensation expense |  |  | 18,214 |  |  |  | 14,971 |  |
| Customer related asset impairments (3) |  |  | 10,730 |  |  |  | 19,576 |  |
| Restructuring charges (4) |  |  | 17,284 |  |  |  | 12,880 |  |
| Legal and other (5) |  |  | (1,742 | ) |  |  | 10,281 |  |
| Other charges, net (6) |  |  | 74,545 |  |  |  | 118,929 |  |
| Interest and other, net (6) |  |  | 28,077 |  |  |  | 46,565 |  |
| Non-GAAP operating income |  | $ | 206,991 |  |  | $ | 204,147 |  |
| GAAP provision for (benefit from) income taxes |  | $ | (3,579 | ) |  | $ | 27,960 |  |
| Intangible amortization benefit |  |  | 2,064 |  |  |  | 2,186 |  |
| Other tax related adjustments (7) |  |  | (11,779 | ) |  |  | (15,640 | ) |
| Tax benefit on restructuring and other (7) |  |  | 40,719 |  |  |  | 3,207 |  |
| Non-GAAP provision for income taxes |  | $ | 27,425 |  |  | $ | 17,713 |  |
| GAAP net income (loss) |  | $ | 48,259 |  |  | $ | (64,352 | ) |
| Intangible amortization |  |  | 15,203 |  |  |  | 17,337 |  |
| Stock-based compensation expense |  |  | 18,214 |  |  |  | 14,971 |  |
| Restructuring charges (4) |  |  | 17,284 |  |  |  | 12,880 |  |
| Customer related asset impairments (3) |  |  | 10,730 |  |  |  | 19,576 |  |
| Legal and other (5) |  |  | (1,742 | ) |  |  | 10,281 |  |
| Other charges, interest and other, net (6) |  |  | 66,217 |  |  |  | 120,293 |  |
| Adjustments for taxes (7) |  |  | (31,004 | ) |  |  | 10,247 |  |
| Non-GAAP net income |  | $ | 143,161 |  |  | $ | 141,233 |  |
| Diluted earnings (loss) per share (2): |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.10 |  |  | $ | (0.12 | ) |
| Non-GAAP |  | $ | 0.28 |  |  | $ | 0.27 |  |

[0001104659-20-058102:8k_2_02:74]
See the accompanying notes on Schedule V attached to this press release.

[0001104659-20-058102:8k_2_02:75]
FLEX

[0001104659-20-058102:8k_2_02:76]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-20-058102:8k_2_02:77]
(In thousands, except per share amounts)

[0001104659-20-058102:8k_2_02:78]
|  |  | Twelve-Month Periods Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| GAAP gross profit |  | $ | 1,337,956 |  |  | $ | 1,517,775 |  |
| Stock-based compensation expense |  |  | 15,174 |  |  |  | 19,554 |  |
| Customer related asset impairments (3) |  |  | 101,578 |  |  |  | 46,684 |  |
| Restructuring charges (4) |  |  | 190,424 |  |  |  | 99,005 |  |
| New revenue standard adoption impact (8) |  |  | - |  |  |  | 9,291 |  |
| Legal and other (5) |  |  | 22,701 |  |  |  | 15,123 |  |
| Non-GAAP gross profit |  | $ | 1,667,833 |  |  | $ | 1,707,432 |  |
| GAAP income before income taxes |  | $ | 158,485 |  |  | $ | 182,126 |  |
| Intangible amortization |  |  | 64,106 |  |  |  | 74,396 |  |
| Stock-based compensation expense |  |  | 71,546 |  |  |  | 76,032 |  |
| Customer related asset impairments (3) |  |  | 105,940 |  |  |  | 87,093 |  |
| Restructuring charges (4) |  |  | 216,407 |  |  |  | 113,313 |  |
| New revenue standard adoption impact (8) |  |  | - |  |  |  | 9,291 |  |
| Legal and other (5) |  |  | 26,270 |  |  |  | 35,644 |  |
| Other charges, net (6) |  |  | 91,550 |  |  |  | 110,414 |  |
| Interest and other, net (6) |  |  | 163,727 |  |  |  | 183,454 |  |
| Non-GAAP operating income |  | $ | 898,031 |  |  | $ | 871,763 |  |
| GAAP provision for income taxes |  | $ | 70,906 |  |  | $ | 88,727 |  |
| Intangible amortization benefit |  |  | 8,379 |  |  |  | 8,888 |  |
| Other tax related adjustments (7) |  |  | (30,579 | ) |  |  | (20,439 | ) |
| Tax benefit on restructuring and other (7) |  |  | 56,030 |  |  |  | 7,573 |  |
| Non-GAAP provision for income taxes |  | $ | 104,736 |  |  | $ | 84,749 |  |
| GAAP net income |  | $ | 87,579 |  |  | $ | 93,399 |  |
| Intangible amortization |  |  | 64,106 |  |  |  | 74,396 |  |
| Stock-based compensation expense |  |  | 71,546 |  |  |  | 76,032 |  |
| Restructuring charges (4) |  |  | 216,407 |  |  |  | 113,313 |  |
| Customer related asset impairments (3) |  |  | 105,940 |  |  |  | 87,093 |  |
| New revenue standard adoption impact (8) |  |  | - |  |  |  | 9,291 |  |
| Legal and other (5) |  |  | 26,453 |  |  |  | 35,644 |  |
| Other charges, interest and other, net (6) |  |  | 93,411 |  |  |  | 109,980 |  |
| Adjustments for taxes (7) |  |  | (33,830 | ) |  |  | 3,978 |  |
| Non-GAAP net income |  | $ | 631,612 |  |  | $ | 603,126 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.17 |  |  | $ | 0.18 |  |
| Non-GAAP |  | $ | 1.23 |  |  | $ | 1.14 |  |

[0001104659-20-058102:8k_2_02:79]
See the
accompanying notes on Schedule V attached to this press release.

[0001104659-20-058102:8k_2_02:80]
SCHEDULE III

[0001104659-20-058102:8k_2_02:81]
FLEX

[0001104659-20-058102:8k_2_02:82]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-20-058102:8k_2_02:83]
(In thousands)

[0001104659-20-058102:8k_2_02:84]
|  |  | As of March 31, 2020 |  |  | As of March 31, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,922,686 |  |  | $ | 1,696,625 |  |
| Accounts receivable, net of allowance for doubtful accounts |  |  | 2,435,982 |  |  |  | 2,612,961 |  |
| Contract assets |  |  | 282,444 |  |  |  | 216,202 |  |
| Inventories |  |  | 3,785,073 |  |  |  | 3,722,854 |  |
| Other current assets |  |  | 660,085 |  |  |  | 854,790 |  |
| Total current assets |  |  | 9,086,270 |  |  |  | 9,103,432 |  |
| Property and equipment, net |  |  | 2,215,991 |  |  |  | 2,336,213 |  |
| Operating lease right-of-use assets, net (9) |  |  | 605,070 |  |  |  | — |  |
| Goodwill |  |  | 1,064,553 |  |  |  | 1,073,055 |  |
| Other intangible assets, net |  |  | 262,418 |  |  |  | 330,995 |  |
| Other assets |  |  | 455,315 |  |  |  | 655,672 |  |
| Total assets |  | $ | 13,689,617 |  |  | $ | 13,499,367 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 149,130 |  |  | $ | 632,611 |  |
| Accounts payable |  |  | 5,108,251 |  |  |  | 5,147,236 |  |
| Accrued payroll |  |  | 363,644 |  |  |  | 391,591 |  |
| Other current liabilities (9) |  |  | 1,590,060 |  |  |  | 1,426,075 |  |
| Total current liabilities |  |  | 7,211,085 |  |  |  | 7,597,513 |  |
| Long-term debt, net of current portion |  |  | 2,689,109 |  |  |  | 2,421,904 |  |
| Operating lease liabilities, non-current (9) |  |  | 528,967 |  |  |  | — |  |
| Other liabilities |  |  | 429,303 |  |  |  | 507,590 |  |
| Total shareholders' equity |  |  | 2,831,153 |  |  |  | 2,972,360 |  |
| Total liabilities and shareholders' equity |  | $ | 13,689,617 |  |  | $ | 13,499,367 |  |

[0001104659-20-058102:8k_2_02:85]
See the accompanying
notes on Schedule V attached to this press release.

[0001104659-20-058102:8k_2_02:86]
SCHEDULE IV

[0001104659-20-058102:8k_2_02:87]
FLEX

[0001104659-20-058102:8k_2_02:88]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-20-058102:8k_2_02:89]
(In thousands)

[0001104659-20-058102:8k_2_02:90]
|  |  | Twelve-Month Periods Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 87,579 |  |  | $ | 93,399 |  |
| Depreciation, amortization and other impairment charges |  |  | 748,050 |  |  |  | 764,952 |  |
| Gain from deconsolidation of Bright Machines |  |  | — |  |  |  | (86,614 | ) |
| Changes in working capital and other |  |  | (2,368,905 | ) |  |  | (3,742,761 | ) |
| Net cash used in operating activities |  |  | (1,533,276 | ) |  |  | (2,971,024 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property and equipment |  |  | (461,745 | ) |  |  | (725,606 | ) |
| Proceeds from the disposition of property and equipment |  |  | 105,750 |  |  |  | 94,219 |  |
| Acquisition of businesses, net of cash acquired |  |  | (1,390 | ) |  |  | (12,796 | ) |
| Proceeds from divestiture of businesses, net of cash held in divested businesses |  |  | 3,402 |  |  |  | 267,147 |  |
| Cash collections of deferred purchase price |  |  | 2,565,555 |  |  |  | 3,585,901 |  |
| Other investing activities, net |  |  | 67,458 |  |  |  | 44,032 |  |
| Net cash provided by investing activities |  |  | 2,279,030 |  |  |  | 3,252,897 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  |  | 1,069,578 |  |  |  | 3,199,460 |  |
| Repayments of bank borrowings and long-term debt |  |  | (1,315,691 | ) |  |  | (3,059,828 | ) |
| Payments for repurchases of ordinary shares |  |  | (259,912 | ) |  |  | (188,979 | ) |
| Other financing activities, net |  |  | (2,435 | ) |  |  | 19,643 |  |
| Net cash used in financing activities |  |  | (508,460 | ) |  |  | (29,704 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (11,233 | ) |  |  | (27,968 | ) |
| Net change in cash and cash equivalents |  |  | 226,061 |  |  |  | 224,201 |  |
| Cash and cash equivalents, beginning of period |  |  | 1,696,625 |  |  |  | 1,472,424 |  |
| Cash and cash equivalents, end of period |  | $ | 1,922,686 |  |  | $ | 1,696,625 |  |

[0001104659-20-058102:8k_2_02:91]
SCHEDULE V

[0001104659-20-058102:8k_2_02:92]
FLEX AND SUBSIDIARIES

[0001104659-20-058102:8k_2_02:93]
NOTES TO SCHEDULES I,
II, III

[0001104659-20-058102:8k_2_02:94]
| (1) | To supplement Flex’s unaudited selected financial data presented consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges and gains, including non-GAAP gross profit, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share. These supplemental measures exclude restructuring charges, customer-related asset impairments, stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP and may be different from non-GAAP measures used by other companies. We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures. The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures. We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance. |

[0001104659-20-058102:8k_2_02:95]
In calculating non-GAAP
financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance
on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance.
We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans,
for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s
incentive compensation is determined using certain non-GAAP measures. Also, when evaluating potential acquisitions, we exclude
certain of the items described below from consideration of the target’s performance and valuation. Since we find these measures
to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to
seeing GAAP results. We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials,
provide useful information to investors by offering:

[0001104659-20-058102:8k_2_02:96]
|  | · | the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results; |
|  | · | the ability to better identify trends in the Company’s underlying business and perform related trend analyses; |
|  | · | a better understanding of how management plans and measures the Company’s underlying business; and |
|  | · | an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures. |

[0001104659-20-058102:8k_2_02:97]
The following are explanations
of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual
items in the reconciliations of these non-GAAP financial measures:

[0001104659-20-058102:8k_2_02:98]
Stock-based compensation
expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards
granted to employees and assumed in business acquisitions. The Company believes that the exclusion of these charges provides for
more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective
assumptions and the variety of award types. In addition, the Company believes it is useful to investors to understand the specific
impact stock-based compensation expense has on its operating results.

[0001104659-20-058102:8k_2_02:99]
Intangible amortization
consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions. The
Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings
trends, and therefore excludes such charges when presenting non-GAAP financial measures. The Company believes that the assessment
of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance
of its competitors.

[0001104659-20-058102:8k_2_02:100]
Customer related asset
impairments consist of non-cash impairments of certain property and equipment to estimated fair value for customers we have
disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers
that are experiencing financial difficulties. Certain inventory on hand was written down to net realizable value and other assets
were written down to estimated recoverable value for these customers as well. In addition, it includes write down of inventory
that will not be recovered due to significant reductions in future customer demand as the Company reduced its exposure to certain
high volatility business in the second quarter of fiscal year 2020. These costs are excluded by the Company’s management
in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its
non-GAAP measures.

[0001104659-20-058102:8k_2_02:101]
Legal and other consists
primarily of costs not directly related to ongoing or core business results such as (1) costs incurred relating to the independent
investigation undertaken by the Audit Committee of the Company’s Board of Directors completed in June 2018, (2) certain charges
related to Multek China that was divested in the second quarter of fiscal year 2019, (3) certain direct and incremental costs associated
with the disengagement of a certain customer in the second, third, and fourth quarters of fiscal year 2020, and (4) certain gains
resulting from the recognition of prior year expenses paid to the government now considered probable of recovery and reasonably
estimable due to a favorable tax ruling received in fiscal year 2020. These costs are excluded by the Company’s management
in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its
non-GAAP measures.

[0001104659-20-058102:8k_2_02:102]
Restructuring charges include
severance for rationalization at existing sites and corporate SG&A functions as well as asset impairment, and other charges
related to the closures and consolidations of certain operating sites and targeted activities to restructure the business. These
costs may vary in size based on the Company’s initiatives and are not directly related to ongoing or core business results,
and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing
current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-20-058102:8k_2_02:103]
Other charges (income), interest
and other, net consists of various other types of items that are not directly related to ongoing or core business results,
such as the gain or loss from certain divestitures, debt extinguishment costs and impairment charges associated with certain non-core
investments. We exclude these items because they are not related to the Company’s ongoing operating performance or do not
affect core operations. Excluding these amounts provides investors with a basis to compare company performance against the performance
of other companies without this variability.

[0001104659-20-058102:8k_2_02:104]
Adjustment for taxes
relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful
measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies or other non-recurring
tax charges, when applicable.

[0001104659-20-058102:8k_2_02:105]
Adjustment for free cash
flow metrics. In the first quarter of fiscal year 2019, the adoption of the new cash flow accounting standard resulted in a
reclassification of cash flows related to the collection of certain receivables sold through the Company’s asset-backed receivable
securitization (“ABS”) program from operating activities to investing activities.

[0001104659-20-058102:8k_2_02:106]
In the third quarter of
fiscal year 2020, the Company amended the existing ABS program and removed the requirement for the deferred purchase price receivable.
At the effective date of the amendment, approximately $1.3 billion representing the outstanding balance of sold receivables was
repurchased by the Company by exchanging outstanding deferred purchase price receivable of $0.4 billion and re-investing $0.9 billion
of trade account receivables into the new ABS Programs. Cash collections on repurchased deferred purchase price receivables are
reported as investing activities in the condensed consolidated statements of cash flows and were approximately $0.1 billion and
$0.4 billion for the three-month and twelve-month periods ended March 31, 2020.

[0001104659-20-058102:8k_2_02:107]
The Company utilizes
net cash flow from its various A/R sales programs as a low-cost source to fund operations and as a critical net working
capital management tool. The Company views and manages all collections under the programs similarly without bifurcation and
accordingly provides the adjustment to reflect adjusted free cash flow inclusive of all collections of receivables sold
through the programs described above as well as collections on the repurchased receivables as part of the ABS program
amendment. The Company also excludes the impact related to certain vendor programs that is required for GAAP. We define our
adjusted free cash flow metric to be operating cash flows plus the impacts described above less purchases of property and
equipment net of proceeds from dispositions and present cash flows on a consistent basis for investor transparency. We
believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of
cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other
activities. Since adjusted free cash flow includes investments in operating assets, we believe this non-GAAP liquidity
measure is useful in addition to the most directly comparable GAAP measure – “net cash provided by (used in)
operating activities.” See below for the three-month and twelve-month periods ended March 31, 2020 reconciliation of
GAAP to Non-GAAP measures:

[0001104659-20-058102:8k_2_02:108]
|  |  | Three-Month Period Ended |  |  | Twelve-Month Period Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2020 |  |
| Net cash provided by (used in) operating activities |  | $ | 166,030 |  |  | $ | (1,533,276 | ) |
| Cash collections of ABS positions and other |  |  | 50,525 |  |  |  | 2,561,619 |  |
| Net capital expenditures |  |  | (82,545 | ) |  |  | (355,995 | ) |
| Adjusted Free Cash Flow |  | $ | 134,010 |  |  | $ | 672,348 |  |

[0001104659-20-058102:8k_2_02:109]
(2) Basic shares were used in
calculating diluted GAAP EPS for the quarter ended March 31, 2019 due to the net loss recognized during that period. Diluted shares
for Q4 fiscal 2019 was 522,460 thousand which was used in calculating diluted non-GAAP EPS for the quarter.

[0001104659-20-058102:8k_2_02:110]
(3) Customer related asset impairments
for the three-month and twelve-month periods ended March 31, 2020 and March 31, 2019 primarily relate to additional provision for
doubtful accounts receivable, asset impairment, and reserves for excess and obsolete inventory for certain customers experiencing
financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer
demand as the Company reduces its exposure to certain higher volatility businesses.

[0001104659-20-058102:8k_2_02:111]
(4) During the first half of fiscal year
2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, the
Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic
decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted
activities to restructure its business to further reduce and streamline its cost structure. During fiscal year 2020, the Company
recognized $216.4 million of restructuring charges. The Company incurred cash charges of approximately $159.3 million, that were
predominantly for employee severance, in addition to non-cash charges of $57.1 million, primarily related to asset impairments.

[0001104659-20-058102:8k_2_02:112]
During fiscal year 2019, the Company completed
the wind-down of our Nike operations in Mexico and recognized in total $66 million for the fiscal year. The charge primarily consisted
of non-cash asset impairments.

[0001104659-20-058102:8k_2_02:113]
(5) Legal and other consists
primarily of costs not directly related to the Company’s ongoing or core business results as described further in footnote
1.

[0001104659-20-058102:8k_2_02:114]
(6) During fiscal year 2020,
and in connection with the Company’s ongoing assessment of its investment portfolio strategy, the Company concluded that
the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $97.7 million total
impairment, of which $74.8 million was recorded in the fourth quarter. The impairments in the fourth quarter of fiscal year 2020
were primarily related to Elementum and certain other non-core investments, reflecting recent market valuation changes, in addition
to capturing additional risks due to the economic challenges in light of COVID-19. This was offset by a $10.9 million realized
gain from a distribution by one of our non-core investments in the fourth quarter of fiscal year 2020.

[0001104659-20-058102:8k_2_02:115]
In addition, during fiscal year
2020, the Company incurred debt extinguishment costs of $7.2 million, related to full repayments of the Notes due February 2020
and Term Loan due November 2021.

[0001104659-20-058102:8k_2_02:116]
During the last half of fiscal
2019, the Company reassessed its strategy with respect to its entire investment portfolio. As a result, the Company recognized
an aggregate net charge related to investment impairments and dispositions of approximately $119 million and $193 million for the
three-month and twelve-month periods ended March 31, 2019, respectively, primarily related to a non-core investment and Elementum.

[0001104659-20-058102:8k_2_02:117]
During the first quarter of
fiscal year 2019, the Company transferred primarily employees and equipment into Bright Machines which later received additional
equity funding from third party investors upon which the Company deconsolidated the entity and recognized a gain of approximately
$87 million in other income, net for the year ended March 31, 2019.

[0001104659-20-058102:8k_2_02:118]
(7) During the third quarter
of fiscal year 2020, the Company recorded $9.2 million related to the remeasurement of deferred tax positions with specific countries
due to the change in their corporate income tax rates.

[0001104659-20-058102:8k_2_02:119]
During the second quarter of
fiscal year 2020, the Company recorded $8 million of withholding tax liabilities for future planned liquidations of certain legal
entities.

[0001104659-20-058102:8k_2_02:120]
During the fourth quarter of
fiscal year 2019, the company incurred an expense of $15 million pertaining to initial implementation of advanced pricing arrangements
finalized with the Mexican tax authorities during the fiscal year. The remaining balance is primarily related to adjustment for
exchange rate fluctuation on income tax receivable position of an operating subsidiary recognized in a prior period.

[0001104659-20-058102:8k_2_02:121]
In addition, the Company has
included the tax effects of the various adjustments that are incorporated into Non-GAAP measures under tax benefits on restructuring
and other.

[0001104659-20-058102:8k_2_02:122]
(8) During the first quarter
of fiscal year 2019, the Company amended certain non-substantive terms of its existing contracts for its smaller customers. The
amendments removed the consideration regarding over-time recognition under ASC 606. Accordingly, these customer contracts are now
accounted for consistent with prior accounting and revenue is recognized upon shipment of product.

[0001104659-20-058102:8k_2_02:123]
(9) The Company adopted ASU
No. 2016-02, Leases and subsequent updates (collectively, referred to as Accounting Standard Codification 842 or “ASC 842”)
on April 1, 2019 using the optional transition method, by which companies may elect not to recast the comparative periods presented
in financial statements in the period of adoption and recognize a cumulative effect adjustment in the period of adoption. As a
result, the Company was not required to adjust its comparative period financial information for effects of the standard. ASC 842
requires a lessee to recognize a right of use (“ROU”) asset and lease liability. The Company’s ROU assets are
$605 million and operating lease liabilities are $643 million (of which $114 million was current and recorded under other current
liabilities and $529 million was non-current) as of March 31, 2020.
