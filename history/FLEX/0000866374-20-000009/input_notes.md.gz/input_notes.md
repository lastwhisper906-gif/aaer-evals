# FLEX notes — 0000866374-20-000009


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000866374-20-000009:notes:1]
Proxy Statement to be delivered to shareholders in connection with the Registrant's 2020 Annual General Meeting of Shareholders


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-20-000009:notes:2]
ORGANIZATION OF THE COMPANY
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. As of March 31, 2020, the Company's reportable segments were as follows:

[0000866374-20-000009:notes:3]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including surgical equipment, drug delivery, diagnostics, telemedicine, disposable devices, imaging and monitoring, patient mobility and ophthalmology; and our automotive business, including vehicle electrification, connectivity, autonomous, and smart technologies; |

[0000866374-20-000009:notes:4]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, smart solar energy; and industrial, including semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks; |

[0000866374-20-000009:notes:5]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads and small cells for wireless infrastructure; our networking business, which includes optical, routing, and switching products for data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack-level solutions, converged infrastructure and software-defined product solutions; and |

[0000866374-20-000009:notes:6]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in IoT enabled devices, audio and consumer power electronics, mobile devices; and various supply chain solutions for consumer, computing and printing devices. |

[0000866374-20-000009:notes:7]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-20-000009:notes:8]
SUMMARY OF ACCOUNTING POLICIES
Basis of Presentation and Principles of Consolidation

[0000866374-20-000009:notes:9]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the consolidated statements of operations.

[0000866374-20-000009:notes:10]
Use of Estimates

[0000866374-20-000009:notes:11]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments including highly liquid investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rate in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-20-000009:notes:12]
Translation of Foreign Currencies

[0000866374-20-000009:notes:13]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive loss, a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for all periods presented, and have been classified as a component of interest and other, net in the consolidated statements of operations.

[0000866374-20-000009:notes:14]
Revenue Recognition

[0000866374-20-000009:notes:15]
In determining the appropriate amount of revenue to recognize, Flex applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). Flex is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, it is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and Flex has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to note 4 "Revenue Recognition" for further details.

[0000866374-20-000009:notes:16]
On April 1, 2018, the Company adopted the Accounting Standard Codification 606 ("ASC 606") using the modified retrospective approach by applying the guidance to all open contracts at the adoption date and has implemented revised accounting policies, new operational and financial reporting processes, enhanced systems capabilities and relevant internal controls. In addition to the following disclosures, note 4 "Revenue Recognition" provides further disclosures required by the new standard.

[0000866374-20-000009:notes:17]
Concentration of Credit Risk

[0000866374-20-000009:notes:18]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, derivative instruments, and cash and cash equivalents.

[0000866374-20-000009:notes:19]
Customer Credit Risk

[0000866374-20-000009:notes:20]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-20-000009:notes:21]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2020, 2019 and 2018:

[0000866374-20-000009:notes:22]
|  | Balance atBeginningof Year |  | Charged toCosts andExpenses |  | Deductions/Write-Offs |  | Balance atEnd ofYear |
|  | (In thousands) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2018 | $ | 57,302 |  |  | $ | 8,225 |  |  | $ | (5,476 | ) |  | $ | 60,051 |  |
| Year ended March 31, 2019 (1) | 60,051 |  |  | 41,977 |  |  | (10,632 | ) |  | 91,396 |  |
| Year ended March 31, 2020 (1) | 91,396 |  |  | 23,732 |  |  | (19,198 | ) |  | 95,930 |  |

[0000866374-20-000009:notes:23]
| (1) | Charges incurred during fiscal years 2020 and 2019 are primarily for costs and expenses related to various distressed customers. |

[0000866374-20-000009:notes:24]
No customer accounted for greater than 10% of the Company's net sales in fiscal years 2020, 2019 and 2018. One customer within the Company's CTG segment accounted for approximately 10% of the Company's total balance of accounts receivable, net in fiscal year 2020. One customer within the Company's CTG segment accounted for approximately 11% and 17% of the Company's total balances of accounts receivable, net in fiscal years 2019 and 2018, respectively.

[0000866374-20-000009:notes:25]
The Company's ten largest customers accounted for approximately 39%, 43% and 41%, of its net sales in fiscal years 2020, 2019 and 2018, respectively.

[0000866374-20-000009:notes:26]
Derivative Instruments

[0000866374-20-000009:notes:27]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 9.

[0000866374-20-000009:notes:28]
Cash and Cash Equivalents

[0000866374-20-000009:notes:29]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-20-000009:notes:30]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-20-000009:notes:31]
Cash and cash equivalents consisted of the following:

[0000866374-20-000009:notes:32]
|  | As of March 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Cash and bank balances | $ | 1,519,029 |  |  | $ | 1,222,737 |  |
| Money market funds and time deposits | 403,657 |  |  | 473,888 |  |
|  | $ | 1,922,686 |  |  | $ | 1,696,625 |  |

[0000866374-20-000009:notes:33]
Inventories

[0000866374-20-000009:notes:34]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or net realizable value write-downs, were as follows:

[0000866374-20-000009:notes:35]
|  | As of March 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Raw materials | $ | 2,835,582 |  |  | $ | 2,922,101 |  |
| Work-in-progress | 373,513 |  |  | 366,135 |  |
| Finished goods | 575,978 |  |  | 434,618 |  |
|  | $ | 3,785,073 |  |  | $ | 3,722,854 |  |

[0000866374-20-000009:notes:36]
Property and Equipment, Net

[0000866374-20-000009:notes:37]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are depreciated over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment is comprised of the following:

[0000866374-20-000009:notes:38]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2020 |  | 2019 |
|  |  |  | (In thousands) |
| Machinery and equipment | 3 - 10 |  | $ | 3,265,387 |  |  | $ | 3,305,335 |  |
| Buildings | 30 |  | 1,085,887 |  |  | 1,111,708 |  |
| Leasehold improvements | up to 30 |  | 510,404 |  |  | 453,119 |  |
| Furniture, fixtures, computer equipment and software | 3 - 7 |  | 491,959 |  |  | 501,994 |  |
| Land | — |  | 112,016 |  |  | 121,976 |  |
| Construction-in-progress | — |  | 271,026 |  |  | 291,458 |  |
|  |  |  | 5,736,679 |  |  | 5,785,590 |  |
| Accumulated depreciation and amortization |  |  | (3,520,688 | ) |  | (3,449,377 | ) |
| Property and equipment, net |  |  | $ | 2,215,991 |  |  | $ | 2,336,213 |  |

[0000866374-20-000009:notes:39]
Total depreciation expense associated with property and equipment was approximately $422.4 million, $433.4 million and $434.4 million in fiscal years 2020, 2019 and 2018, respectively.

[0000866374-20-000009:notes:40]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment

[0000866374-20-000009:notes:41]
is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-20-000009:notes:42]
Deferred Income Taxes

[0000866374-20-000009:notes:43]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-20-000009:notes:44]
Accounting for Business and Asset Acquisitions

[0000866374-20-000009:notes:45]
The Company has strategically pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0000866374-20-000009:notes:46]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-20-000009:notes:47]
Goodwill

[0000866374-20-000009:notes:48]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require management to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider its budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparable and credit ratings. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of the Company's goodwill.

[0000866374-20-000009:notes:49]
If the recorded value of the assets, including goodwill, and liabilities ("net book value") of any reporting unit exceeds its fair value, an impairment loss may be required to be recognized. Further, to the extent the net book value of the Company as a whole is greater than its fair value in the aggregate, all, or a significant portion of its goodwill may be considered impaired.

[0000866374-20-000009:notes:50]
The Company has four reporting units as of March 31, 2020, which correspond to its four reportable operating segments: HRS, IEI, CEC and CTG. The Company concluded that there was no change to its reporting units in fiscal year 2020 and performed its annual goodwill impairment assessment on January 1, 2020. The Company performed a quantitative assessment of its goodwill and determined that no impairment existed as of the date of the impairment test because the fair value of each one of its reporting units exceeded its respective carrying value.

[0000866374-20-000009:notes:51]
During the fourth quarter of fiscal year 2020, due to the ongoing COVID-19 global pandemic which negatively impacted the overall macroeconomy as well as the Company's market capitalization and estimated near-term financial performance, the Company considered this a triggering event and performed an interim impairment test via a quantitative valuation as of March 31, 2020. Based on the results of the impairment test, the fair values exceed the respective carrying values for each reporting unit, with the percentage excess ranging from 17% for CTG to 108% for IEI. Accordingly, the Company concluded that no impairment of goodwill existed as of March 31, 2020. The estimated forecasted results used in the discounted cash flow portion of the impairment analysis reflect the Company's best estimates as of March 31, 2020 and include near term negative impacts to our auto businesses from the plant closures, challenged CEC telecommunication businesses, and weaker consumer demand for our customers' mobility products due to COVID-19. These estimates could change depending on the future developments of the COVID-19 pandemic such as the length and severity of the crisis, the potential resurgence of COVID-19 in the future, future government actions in response to the crisis and the overall impact of the COVID-19 pandemic on the global economy and capital markets, among many other factors, all of which remain highly uncertain and unpredictable.

[0000866374-20-000009:notes:52]
The following table summarizes the activity in the Company's goodwill during fiscal years 2020 and 2019 (in thousands):

[0000866374-20-000009:notes:53]
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Balance, as of March 31, 2018 | $ | 550,983 |  |  | $ | 337,707 |  |  | $ | 124,732 |  |  | $ | 107,748 |  |  | $ | 1,121,170 |  |
| Additions (1) | — |  |  | — |  |  | 10,984 |  |  | — |  |  | 10,984 |  |
| Divestitures (2) | (5,303 | ) |  | (4,450 | ) |  | (6,391 | ) |  | (4,484 | ) |  | (20,628 | ) |
| Foreign currency translation adjustments (3) | (38,471 | ) |  | — |  |  | — |  |  | — |  |  | (38,471 | ) |
| Balance, as of March 31, 2019 | 507,209 |  |  | 333,257 |  |  | 129,325 |  |  | 103,264 |  |  | 1,073,055 |  |
| Divestitures (2) | (1,102 | ) |  | (137 | ) |  | — |  |  | — |  |  | (1,239 | ) |
| Foreign currency translation adjustments (3) | (7,263 | ) |  | — |  |  | — |  |  | — |  |  | (7,263 | ) |
| Balance, as of March 31, 2020 | $ | 498,844 |  |  | $ | 333,120 |  |  | $ | 129,325 |  |  | $ | 103,264 |  |  | $ | 1,064,553 |  |

[0000866374-20-000009:notes:54]
_______________________________________________________________________________

[0000866374-20-000009:notes:55]
| (1) | The goodwill generated from the Company's business combinations completed during the fiscal year 2019 are primarily related to value placed on the employee workforce, service offerings, capabilities and expected synergies. The goodwill is not deductible for income tax purposes. Refer to the discussion of the Company's business acquisitions in note 18. |

[0000866374-20-000009:notes:56]
| (2) | During the fiscal year ended March 31, 2019, the Company divested its China-based Multek operations along with another non-strategic immaterial business, and as a result, recorded an aggregate reduction of goodwill of $20.6 million. |

[0000866374-20-000009:notes:57]
| (3) | During the fiscal years ended March 31, 2020 and 2019, the Company recorded $7.3 million and $38.5 million, respectively, of foreign currency translation adjustments primarily related to historical acquisitions, as the U.S. Dollar fluctuated against foreign currencies. |

[0000866374-20-000009:notes:58]
Other Intangible Assets

[0000866374-20-000009:notes:59]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2020 and concluded that such amounts continued to be recoverable.

[0000866374-20-000009:notes:60]
Intangible assets are comprised of customer-related intangible assets that include contractual agreements and customer relationships; and licenses and other intangible assets, that are primarily comprised of licenses and also include patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight-line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability. The components of acquired intangible assets are as follows:

[0000866374-20-000009:notes:61]
|  | As of March 31, 2020 |  | As of March 31, 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 275,678 |  |  | $ | (128,155 | ) |  | $ | 147,523 |  |  | $ | 297,306 |  |  | $ | (113,627 | ) |  | $ | 183,679 |  |
| Licenses and other intangibles | 244,917 |  |  | (130,022 | ) |  | 114,895 |  |  | 274,604 |  |  | (127,288 | ) |  | 147,316 |  |
| Total | $ | 520,595 |  |  | $ | (258,177 | ) |  | $ | 262,418 |  |  | $ | 571,910 |  |  | $ | (240,915 | ) |  | $ | 330,995 |  |

[0000866374-20-000009:notes:62]
Total intangible asset amortization expense recognized in operations during fiscal years 2020, 2019 and 2018 was $64.1 million,$74.4 million and $78.6 million, respectively. The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2020, the gross carrying amounts of fully amortized intangible assets totaled $43.4 million. The Company also recorded $5.2 million foreign currency translation adjustments during fiscal year 2020, as the U.S. Dollar fluctuated against foreign currencies for certain intangibles. As of March 31, 2020, the weighted-average remaining useful lives of the Company's intangible assets was approximately 5.6 years for customer-related intangibles and approximately 4.7 years for licenses and other intangible assets. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-20-000009:notes:63]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2021 | $ | 59,798 |  |
| 2022 | 51,422 |  |
| 2023 | 43,797 |  |
| 2024 | 42,262 |  |
| 2025 | 37,343 |  |
| Thereafter | 27,796 |  |
| Total amortization expense | $ | 262,418 |  |

[0000866374-20-000009:notes:64]
The Company owns or licenses various United States and foreign patents relating to a variety of technologies. For certain of the Company's proprietary processes, inventions, and works of authorship, the Company relies on trade secret or copyright protection. The Company also maintains trademark rights (including registrations) for the Company's corporate name and several other trademarks and service marks that the Company uses in the Company's business in the United States and other countries throughout the world. The Company has implemented appropriate policies and procedures (including both technological means and training programs for the Company's employees) to identify and protect the Company's intellectual property, as well as that of the Company's customers and suppliers. As of March 31, 2020 and 2019, the carrying value of the Company's intellectual property was not material.

[0000866374-20-000009:notes:65]
Derivative Instruments and Hedging Activities

[0000866374-20-000009:notes:66]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Additional information is included in note 9.

[0000866374-20-000009:notes:67]
Other Current Assets

[0000866374-20-000009:notes:68]
Other current assets include approximately $292.5 million as of March 31, 2019, for the deferred purchase price receivable from the Company's Asset-Backed Securitization programs. There are no deferred purchase price receivables outstanding as of March 31, 2020. See note 11 for additional information.

[0000866374-20-000009:notes:69]
Investments

[0000866374-20-000009:notes:70]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other assets. These privately held companies range from startups to more mature companies with established revenue streams and business models. As of March 31, 2020, and March 31, 2019, the Company's investments in non-consolidated companies totaled $128.1 million and $294.1 million, respectively.

[0000866374-20-000009:notes:71]
During fiscal year 2020, and in connection with the Company’s ongoing assessment of its investment portfolio strategy, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $98 million total impairment in other charges (income), net on the consolidated statement of operations. The impairments in fiscal year 2020 were primarily related to Elementum and certain other non-core investments, reflecting recent market valuation changes, in addition to capturing additional risks due to the economic challenges in light of COVID-19.

[0000866374-20-000009:notes:72]
During the last half of fiscal year 2019, the Company reassessed its strategy with respect to its entire investment portfolio. As a result the Company recognized aggregate net charges related to investment impairments and dispositions of approximately  $193 million for the fiscal year ended March 31, 2019, primarily related to a non-core cost method investment and Elementum.

[0000866374-20-000009:notes:73]
Non-consolidated investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in the earnings or losses of the Company's equity method investments was not material to the consolidated results of operations for any period presented and is included in interest and other, net. Cost method is used for investments which the Company does not have the ability to significantly influence the operating decisions of the investee, or if the Company’s investment is in securities other than common stock or in-substance common stock.

[0000866374-20-000009:notes:74]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy, and require management to make various judgmental assumptions about primarily comparable company multiples and discounted cash flow projections. Some of the inherent estimates and assumptions used in determining fair value of the investments are outside the control of management. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the investments, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of investments.

[0000866374-20-000009:notes:75]
For investments accounted for under cost method that do not have readily determinable fair values, the Company has elected, per ASU 2016-01 and commencing on April 1, 2018, to measure them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-20-000009:notes:76]
Investment in Elementum SCM (Cayman) Ltd ("Elementum")

[0000866374-20-000009:notes:77]
Starting in fiscal year 2014, the Company had a majority owned subsidiary, Elementum, which qualified as a variable interest entity for accounting purposes. The Company owned a majority of Elementum' s outstanding equity (consisting primarily of preferred stock) and as of March 31, 2017, controlled its board of directors, which gave the Company the power to direct the activities of Elementum that most significantly impacted its economic performance.

[0000866374-20-000009:notes:78]
During the second quarter of fiscal year 2018, the Company and other minority shareholders of Elementum amended certain agreements resulting in joint control of the board of directors between the Company and other non-controlling interest holders. As a result, the Company concluded it was no longer the primary beneficiary of Elementum and accordingly, deconsolidated the entity and recognized a gain on deconsolidation of approximately $151.6 million with no related tax impact, which is included in other charges (income), net on the consolidated statement of operations for the year ended March 31, 2018. Further, the Company derecognized approximately $72.6 million of cash of Elementum as of the date of deconsolidation, which was reflected as an outflow from investing activities within other investing activities, net in the consolidated statement of cash flows for the year ended March 31, 2018. The Company no longer recognizes the carrying value of the noncontrolling interest as a component of total shareholder’s equity.

[0000866374-20-000009:notes:79]
During the fourth quarter of fiscal year 2019, the Company and Elementum executed agreements that provided for, among other things, the termination of certain commercial agreements between the Company and Elementum, the repurchase of certain shares of Elementum held by the Company and the removal of certain rights associated with such shares, including the Company’s right to elect certain members of Elementum’s board of directors. Management initiated a valuation of the Company's remaining investment using the guideline public company approach which relied on inputs such as comparable company multiples that would be considered Level 3 inputs in the fair value hierarchy. The valuation of the remaining investment, at that time, resulted in a total charge of approximately $84 million, which is included in other charges (income), net on the consolidated statement of operations for the year ended March 31, 2019.

[0000866374-20-000009:notes:80]
During the fourth quarter of fiscal year 2020, the Company recorded an additional impairment charge of approximately $38 million, reflecting recent market valuation changes and a significant deterioration of Elementum’s business.

[0000866374-20-000009:notes:81]
The Company's remaining investment in Elementum is accounted for as a cost method investment and is immaterial as of March 31, 2020.

[0000866374-20-000009:notes:82]
Bright Machines

[0000866374-20-000009:notes:83]
During the first quarter of fiscal year 2019, the Company transferred existing employees and equipment with a net book value of approximately $35 million along with certain related software and Intellectual Property ("IP"), into the newly created Bright Machines, in exchange for shares of preferred stock and a controlling financial interest in Bright Machines. Bright Machines is a privately held software-as-a service (SaaS) and hardware company focused on developing and deploying an automation solution worldwide. The Company has concluded that Bright Machines does not qualify as a variable interest entity for purposes of evaluating whether it has a controlling financial interest.

[0000866374-20-000009:notes:84]
Subsequent to the initial formation and prior to June 29, 2018, Bright Machines received equity funding from third party investors and expanded the board of directors, resulting in dilution of the Company's voting interest to below 50%. As a result, the Company concluded it no longer held a controlling financial interest in Bright Machines and accordingly, deconsolidated the entity.

[0000866374-20-000009:notes:85]
The fair value of the Company’s non-controlling interest in Bright Machines upon deconsolidation was approximately $127.6 million as of the date of deconsolidation. The Company initially accounted for its investment in Bright Machines under the equity method, with the carrying amount included in other assets on the consolidated balance sheet. The value of the Company’s interest on the date of deconsolidation was based on management’s estimate of the fair value of Bright Machines at that time. Management relied on a multi-stage process which involved calculating the enterprise and equity value of Bright Machines, then allocating the equity value of the entity to the Company’s securities. The enterprise value of Bright Machines was estimated based on the value implied by the equity funding Bright Machines received from third parties in the same period (i.e., Level 2 inputs). The Company recognized a gain on deconsolidation of approximately $87 million with no material tax impact, which is included in other charges (income), net on the consolidated statement of operations for the year ended March 31, 2019.

[0000866374-20-000009:notes:86]
Concurrently with the deconsolidation, the Company engaged Bright Machines as a strategic partner to develop and deploy automation solutions for Flex and entered into a 5-year subscription agreement for use of fixed assets along with other automation services. The subscription agreement provides the Company with the use of the assets previously contributed to Bright Machines and accordingly is accounted for as a finance lease. As a result, the Company has recognized a finance lease asset with balances of $25.4 million and $30.3 million and obligation with balances of $22.8 million and $34.8 million as of March 31, 2020 and 2019, respectively, in the consolidated balance sheets.

[0000866374-20-000009:notes:87]
Pro-forma financials have not been presented because the effects were not material to the Company’s consolidated financial position and results of operation for all periods presented. Subscription fees under the Bright Machines agreement were immaterial for the fiscal years ended March 31, 2020 and 2019.

[0000866374-20-000009:notes:88]
During fiscal year 2020, the Company and Bright Machines executed agreements that provided for, among other things, the repurchase of certain preferred stock of Bright Machines held by the Company and the removal of certain rights associated with such shares, including the Company’s right to elect certain members of Bright Machines' board of directors. In conjunction with this transaction, the Company received consideration of approximately $44 million and recognized a total charge of $23 million, which is included in other charges (income), net on the consolidated statement of operations.

[0000866374-20-000009:notes:89]
As a result of the transaction, the Company no longer has the ability to exercise significant influence, and therefore accounts for its remaining investment in Bright Machines as a cost method investment, which is included in other assets on the consolidated balance sheet as of March 31, 2020. Bright Machines is no longer a related party of the Company subsequent to the transaction described above.

[0000866374-20-000009:notes:90]
Other Current Liabilities

[0000866374-20-000009:notes:91]
Other current liabilities include customer working capital advances of $264.2 million and $266.3 million, customer-related accruals of $195.1 million and $260.1 million, and contract liabilities, identified as deferred revenue of $361.5 million and $271.8 million as of March 31, 2020 and 2019, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.

[0000866374-20-000009:notes:92]
Leases

[0000866374-20-000009:notes:93]
The Company is a lessee with several non-cancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. The Company determines if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the customer has the right to control the use of the identified asset. Beginning with the adoption of ASC 842 on April 1, 2019, the Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. The Company recognizes a right-of-use (“ROU”) asset and a lease liability at the lease commencement date for the Company's operating leases. For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at the lease commencement date. The Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for the Company's leases, the Company uses the Company's estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company's estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company's leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-20-000009:notes:94]
The adoption of ASC 842 had a material impact to the Company’s consolidated balance sheet, but did not materially impact the consolidated statement of operations or consolidated statement of cash flows. The most significant changes to the consolidated balance sheet relate to the recognition of ROU assets and lease liabilities for operating leases. The Company’s accounting for finance leases remains substantially unchanged and the balances are not material for any periods presented.

[0000866374-20-000009:notes:95]
As a result of adopting ASC 842 as of April 1, 2019, the Company recognized additional operating liabilities of $658 million with a corresponding ROU asset of $624 million and a deferred gain of $22 million for sale leaseback transactions to opening retained earnings.

[0000866374-20-000009:notes:96]
As of March 31, 2020, current operating lease liabilities were $114.1 million which are included in other current liabilities on the consolidated balance sheets.

[0000866374-20-000009:notes:97]
Restructuring Charges

[0000866374-20-000009:notes:98]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and rationalize administrative functions. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-20-000009:notes:99]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed restructuring plans. See note 15 for additional information regarding restructuring charges.

[0000866374-20-000009:notes:100]
Recently Adopted Accounting Pronouncements

[0000866374-20-000009:notes:101]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU No. 2016-02, "Leases", and subsequent updates (collectively, referred to as Accounting Standard Codification 842 or “ASC 842”). ASC 842 requires a lessee to recognize a right of use (“ROU”) asset and lease liability. Leases will be classified as finance or operating, with classification affecting the recognition of expense and presentation in the income statement. The Company adopted ASC 842 on April 1, 2019 using the optional transition method, by which companies may elect not to recast the comparative periods presented in financial statements in the period of adoption and recognize a cumulative effect adjustment in the period of adoption. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before the Company's adoption date. Details of the impact of adopting ASC 842 has been described in the Leases section above.

[0000866374-20-000009:notes:102]
In October 2018, the FASB issued ASU 2018-16 “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” to expand the lists of eligible benchmark interest rates to include OIS based on SOFR to facilitate the marketplace transition from LIBOR. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on its financial position, results of operations and cash flows.

[0000866374-20-000009:notes:103]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company early adopted the guidance during the second quarter of fiscal year 2020 with an immaterial impact to its  consolidated financial statements.

[0000866374-20-000009:notes:104]
In August 2018, the FASB issued ASU 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on its financial position, results of operations and cash flows.

[0000866374-20-000009:notes:105]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

[0000866374-20-000009:notes:106]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

[0000866374-20-000009:notes:107]
Recently Issued Accounting Pronouncements

[0000866374-20-000009:notes:108]
In March 2020, the FASB issued ASU 2020-04 "Facilitation of the Effects of Reference Rate Reform on Financial Reporting", which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The guidance is effective upon issuance and may be applied prospectively to contract modifications made and hedging relationships entered into or evaluated on or before December 31, 2022. The Company is currently evaluating the impact of the transition from LIBOR to alternative reference interest rates and expects the new guidance will have an immaterial impact on its consolidated financial statements.

[0000866374-20-000009:notes:109]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

[0000866374-20-000009:notes:110]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes", which removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

[0000866374-20-000009:notes:111]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04, ASU 2019-05, ASU 2019-10, ASU 2019-11, ASU 2020-02, and ASU 2020-03, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021. The Company is assessing the impacts and currently expects the new guidance will have an immaterial impact on its consolidated financial statements.


## us-gaap:DerivativesPolicyTextBlock

[0000866374-20-000009:notes:112]
Derivative Instruments and Hedging Activities
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period.
Derivative Instruments
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-20-000009:notes:113]
LEASES
The Company has several commitments under operating leases for warehouses, buildings, and equipment. The Company also has a minimal number of finance leases with an immaterial impact on its consolidated financial statements. Leases have initial lease terms ranging from 1 year to 23 years.

[0000866374-20-000009:notes:114]
The components of lease cost recognized under ASC 842 were as follow (in thousands):

[0000866374-20-000009:notes:115]
| Lease cost | Year Ended |
|  | March 31, 2020 |
| Operating lease cost | $ | 162,749 |  |

[0000866374-20-000009:notes:116]
Amounts reported in the consolidated balance sheet as of the period ended March 31, 2020 were (in thousands, except weighted average lease term and discount rate):

[0000866374-20-000009:notes:117]
|  | As of March 31, 2020 |
| Operating Leases: |  |
| Operating lease right of use assets | $ | 605,070 |  |
| Operating lease liabilities | 643,054 |  |
| Weighted-average remaining lease term (In years) |  |
| Operating leases | 7.9 |  |
| Weighted-average discount rate |  |
| Operating leases | 4.1 | % |

[0000866374-20-000009:notes:118]
Other information related to leases was as follow (in thousands):

[0000866374-20-000009:notes:119]
|  | Year Ended |
| Cash paid for amounts included in the measurement of lease liabilities: | March 31, 2020 |
| Operating cash flows from operating leases | $ | 149,948 |  |

[0000866374-20-000009:notes:120]
During the fiscal year ended March 31, 2020, the Company sold and leased back certain properties and received cash proceeds of $69.6 million, resulting in total gains of $32.7 million, recorded in cost of sales within the consolidated statements of operations. During the fiscal year ended March 31, 2019 the Company sold and leased back certain properties and received cash proceeds of $67.6 million and recorded a deferred gain of $22 million. As a result of adopting ASC 842 as of April 1, 2019, the Company recognized the deferred gain to prior year retained earnings.

[0000866374-20-000009:notes:121]
Future lease payments under non-cancellable leases as of March 31, 2020 are as follows (in thousands):

[0000866374-20-000009:notes:122]
| Fiscal Year Ended March 31, | Operating Leases |
| 2021 | $ | 134,817 |  |
| 2022 | 115,465 |  |
| 2023 | 100,779 |  |
| 2024 | 84,374 |  |
| 2025 | 67,772 |  |
| Thereafter | 253,768 |  |
| Total undiscounted lease payments | 756,975 |  |
| Less: imputed interest | 113,921 |  |
| Total lease liabilities | $ | 643,054 |  |

[0000866374-20-000009:notes:123]
As previously disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2019 and under the previous lease accounting standard ASC 840, the aggregate future non-cancellable minimum rental payments on our operating lease, as of March 31, 2019, are as follows:

[0000866374-20-000009:notes:124]
| Fiscal Year Ending March 31, | Operating Leases |
|  | (In thousands) |
| 2020 | $ | 155,391 |  |
| 2021 | 113,245 |  |
| 2022 | 93,777 |  |
| 2023 | 81,335 |  |
| 2024 | 67,341 |  |
| Thereafter | 171,828 |  |
| Total minimum lease payments | $ | 682,917 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-20-000009:notes:125]
REVENUE
Revenue Recognition

[0000866374-20-000009:notes:126]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

[0000866374-20-000009:notes:127]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-20-000009:notes:128]
Customer Contracts and Related Obligations

[0000866374-20-000009:notes:129]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note

[0000866374-20-000009:notes:130]
applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-20-000009:notes:131]
Performance Obligations

[0000866374-20-000009:notes:132]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

[0000866374-20-000009:notes:133]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-20-000009:notes:134]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-20-000009:notes:135]
Contract Balances

[0000866374-20-000009:notes:136]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to receivables when rights to payment become unconditional.

[0000866374-20-000009:notes:137]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $361.5 million and $271.8 million as of March 31, 2020 and 2019, respectively.

[0000866374-20-000009:notes:138]
Disaggregation of Revenue

[0000866374-20-000009:notes:139]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time for the fiscal years ended March 31, 2020 and 2019:

[0000866374-20-000009:notes:140]
|  | Year Ended March 31, 2020 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
|  | (In thousands) |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 3,705,387 |  |  | $ | 5,045,270 |  |  | $ | 5,503,322 |  |  | $ | 4,196,530 |  |  | $ | 18,450,509 |  |
| Over time | 1,037,037 |  |  | 2,232,080 |  |  | 1,482,347 |  |  | 1,007,897 |  |  | 5,759,361 |  |
| Total segment | $ | 4,742,424 |  |  | $ | 7,277,350 |  |  | $ | 6,985,669 |  |  | $ | 5,204,427 |  |  | $ | 24,209,870 |  |

[0000866374-20-000009:notes:141]
|  | Year Ended March 31, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
|  | (In thousands) |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 3,773,735 |  |  | $ | 4,395,773 |  |  | $ | 6,126,454 |  |  | $ | 4,744,911 |  |  | $ | 19,040,873 |  |
| Over time | 1,055,215 |  |  | 1,786,864 |  |  | 2,209,876 |  |  | 2,117,683 |  |  | 7,169,638 |  |
| Total segment | $ | 4,828,950 |  |  | $ | 6,182,637 |  |  | $ | 8,336,330 |  |  | $ | 6,862,594 |  |  | $ | 26,210,511 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-20-000009:notes:142]
SHARE-BASED COMPENSATION
Equity Compensation Plans

[0000866374-20-000009:notes:143]
The Company's primary plan used for granting equity compensation awards is the Company's 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-20-000009:notes:144]
Share-Based Compensation Expense

[0000866374-20-000009:notes:145]
The following table summarizes the Company's share-based compensation expense for all equity incentive plans:

[0000866374-20-000009:notes:146]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Cost of sales | $ | 15,174 |  |  | $ | 19,554 |  |  | $ | 19,102 |  |
| Selling, general and administrative expenses | 56,372 |  |  | 56,478 |  |  | 66,142 |  |
| Total share-based compensation expense | $ | 71,546 |  |  | $ | 76,032 |  |  | $ | 85,244 |  |

[0000866374-20-000009:notes:147]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as operating cash flows. During fiscal years 2020, 2019 and 2018, the Company did not recognize any excess tax benefits as an operating cash inflow.

[0000866374-20-000009:notes:148]
As of March 31, 2020, the Company had approximately 10.5 million shares available for grant under the 2017 Plan. Options issued to employees under this plan generally vest over four years and expire ten years from the date of grant. Options granted to non-employee directors generally expire five years from the date of grant.

[0000866374-20-000009:notes:149]
The exercise price of options granted to employees is determined by the Company's Board of Directors or the Compensation Committee and may not be less than the closing price of the Company's ordinary shares on the date of grant.

[0000866374-20-000009:notes:150]
As of March 31, 2020, the total unrecognized compensation cost related to unvested share options granted to employees under all plans was not material.

[0000866374-20-000009:notes:151]
The Company also grants restricted share unit ("RSU") awards under its 2017 Plan. RSU awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. RSU awards generally vest in installments over a three to four-year period and unvested RSU awards are forfeited upon termination of employment.

[0000866374-20-000009:notes:152]
Vesting for certain RSU awards is contingent upon both service and market conditions.

[0000866374-20-000009:notes:153]
As of March 31, 2020, the total unrecognized compensation cost related to unvested RSU awards under all plans was approximately $116.7 million. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.3 years. Approximately $20.0 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting a certain market condition.

[0000866374-20-000009:notes:154]
Determining Fair Value - Options and RSU awards

[0000866374-20-000009:notes:155]
Valuation and Amortization Method—The Company estimates the fair value of share options granted under the 2017 Plan using the Black-Scholes valuation method and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period. The fair market value of RSU awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-20-000009:notes:156]
Expected Term—The Company's expected term used in the Black-Scholes valuation method represents the period that the Company's share options are expected to be outstanding and is determined based on historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share options.

[0000866374-20-000009:notes:157]
Expected Volatility—The Company's expected volatility used in the Black-Scholes valuation method is derived from a combination of implied volatility related to publicly traded options to purchase Flex ordinary shares and historical variability in the Company's periodic share price.

[0000866374-20-000009:notes:158]
Expected Dividend—The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-20-000009:notes:159]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0000866374-20-000009:notes:160]
There were no options granted under the 2017 Plan during fiscal years 2020, 2019, and 2018.

[0000866374-20-000009:notes:161]
Determining Fair Value - RSU awards with service and market conditions

[0000866374-20-000009:notes:162]
Valuation and Amortization Method—The Company estimates the fair value of RSU awards granted under the 2017 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-20-000009:notes:163]
Expected volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the RSU awards granted. The service period is three years for those RSU awards granted in fiscal years 2020, 2019, and 2018.

[0000866374-20-000009:notes:164]
Average peer volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of the Standard and Poor's ("S&P") 500 index for the RSU awards granted in fiscal years 2020, 2019, and 2018.

[0000866374-20-000009:notes:165]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to the S&P 500 index for the RSU awards granted in fiscal years 2020, 2019, and 2018.

[0000866374-20-000009:notes:166]
Expected Dividend and Risk-Free Interest Rate assumptions—Same methodology as discussed above.

[0000866374-20-000009:notes:167]
The fair value of the Company's RSU awards under the 2017 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2020, 2019, and 2018 was estimated using the following weighted-average assumptions:

[0000866374-20-000009:notes:168]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Expected volatility | 38.8 | % |  | 27.4 | % |  | 25.1 | % |
| Average peer volatility | 24.9 | % |  | 25.6 | % |  | 28.7 | % |
| Average peer correlation | 0.5 |  |  | 0.5 |  |  | 0.6 |  |
| Expected dividends | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 1.8 | % |  | 2.7 | % |  | 1.5 | % |

[0000866374-20-000009:notes:169]
Share-Based Awards Activity

[0000866374-20-000009:notes:170]
Option activity for all plans is immaterial for all periods presented.

[0000866374-20-000009:notes:171]
Cash received from option exercises under all plans, which was reflected within other financing activities in the consolidated statement of cash flows, was immaterial for fiscal years 2020 and 2019, and totaled $2.8 million for fiscal year 2018.

[0000866374-20-000009:notes:172]
The following table summarizes the Company's RSU award activity under all plans ("Price" reflects the weighted-average grant-date fair value):

[0000866374-20-000009:notes:173]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested RSU awards outstanding, beginning of fiscal year | 14,903,886 |  |  | $ | 13.76 |  |  | 14,619,692 |  |  | $ | 14.39 |  |  | 17,242,019 |  |  | $ | 12.24 |  |
| Granted (1) | 8,259,272 |  |  | 9.81 |  |  | 8,257,502 |  |  | 12.59 |  |  | 6,680,739 |  |  | 16.97 |  |
| Vested (1) | (4,222,524 | ) |  | 13.33 |  |  | (5,952,039 | ) |  | 13.12 |  |  | (6,945,393 | ) |  | 11.86 |  |
| Forfeited | (2,889,994 | ) |  | 12.89 |  |  | (2,021,269 | ) |  | 14.51 |  |  | (2,357,673 | ) |  | 12.20 |  |
| Unvested RSU awards outstanding, end of fiscal year | 16,050,640 |  |  | $ | 11.87 |  |  | 14,903,886 |  |  | $ | 13.76 |  |  | 14,619,692 |  |  | $ | 14.39 |  |

[0000866374-20-000009:notes:174]
| (1) | Included in the fiscal years 2018 amounts are 0.7 million of RSU awards, representing the number of awards achieved above target levels based on the achievement of certain market conditions, as further described in the table below. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards. |

[0000866374-20-000009:notes:175]
Of the 8.3 million unvested RSU awards granted in fiscal year 2020, approximately 6.5 million are plain-vanilla unvested RSU awards with no performance or market conditions with an average grant date price of $9.24 per share. Further, approximately 1.8 million of these unvested RSU awards granted in fiscal year 2020 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions, with an average grant date fair value estimated to be $11.92 per award calculated using a Monte Carlo simulation. Vesting information for these shares is further detailed in the table below.

[0000866374-20-000009:notes:176]
Of the 16.1 million unvested RSU awards outstanding under all plans as of the fiscal year ended March 31, 2020, approximately 3.3 million unvested RSU awards represent the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-20-000009:notes:177]
|  |  | Targetednumber ofawards as ofMarch 31, 2020(in shares) |  |  |  | Range of sharesthat may be issued (1) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |
|  |  |  | Assessment dates |
| Year of grant |  |  | Minimum |  | Maximum |  |
| Fiscal 2020 |  | 1,721,031 |  |  | $ | 11.92 |  |  | — |  |  | 3,442,062 |  |  | June 2022 |
| Fiscal 2019 |  | 1,103,198 |  |  | $ | 14.00 |  |  | — |  |  | 2,206,396 |  |  | June 2021 |
| Fiscal 2018 (2) |  | 491,417 |  |  | $ | 20.25 |  |  | — |  |  | 982,834 |  |  | June 2020 |
| Totals |  | 3,315,646 |  |  |  |  |  | — |  |  | 6,631,292 |  |  |  |

[0000866374-20-000009:notes:178]
| (1) | Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against the Standard and Poor's ("S&P") 500 Composite Index. |

[0000866374-20-000009:notes:179]
| (2) | As of March 31, 2020, the Company deemed the vesting of RSU awards with market conditions granted in fiscal year 2018 as not probable. |

[0000866374-20-000009:notes:180]
The Company will continue to recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2020, no shares vested in connection with the RSU awards with market conditions granted in fiscal year 2017.

[0000866374-20-000009:notes:181]
The total intrinsic value of RSU awards vested under all the Company's plans was $41.7 million, $80.2 million and $116.4 million during fiscal years 2020, 2019 and 2018, respectively, based on the closing price of the Company's ordinary shares on the date vested.


## us-gaap:EarningsPerShareTextBlock

[0000866374-20-000009:notes:182]
EARNINGS PER SHARE
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-20-000009:notes:183]
Diluted earnings per share reflects the potential dilution from stock options and RSU awards. The potential dilution from stock options exercisable into ordinary share equivalents and restricted share unit awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-20-000009:notes:184]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income per share:

[0000866374-20-000009:notes:185]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands, exceptper share amounts) |
| Basic earnings per share: |  |  |  |  |  |
| Net income | $ | 87,579 |  |  | $ | 93,399 |  |  | $ | 428,534 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 508,774 |  |  | 526,519 |  |  | 529,782 |  |
| Basic earnings per share | $ | 0.17 |  |  | $ | 0.18 |  |  | $ | 0.81 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 87,579 |  |  | $ | 93,399 |  |  | $ | 428,534 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 508,774 |  |  | 526,519 |  |  | 529,782 |  |
| Weighted-average ordinary share equivalents from stock options and RSU awards (1) (2) | 3,663 |  |  | 3,551 |  |  | 6,816 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 512,437 |  |  | 530,070 |  |  | 536,598 |  |
| Diluted earnings per share | $ | 0.17 |  |  | $ | 0.18 |  |  | $ | 0.80 |  |

[0000866374-20-000009:notes:186]
_________________________________________________________________________

[0000866374-20-000009:notes:187]
| (1) | An immaterial amount of options to purchase ordinary shares during fiscal years 2020, 2019, and 2018 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. |

[0000866374-20-000009:notes:188]
(2)

[0000866374-20-000009:notes:189]
RSU awards of 3.6 million and 6.8 million during fiscal years 2020 and 2019 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. Less than 0.1 million of anti-dilutive RSU awards were excluded from the computation of diluted earnings per share during fiscal year 2018.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-20-000009:notes:190]
SUPPLEMENTAL CASH FLOW DISCLOSURES
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-20-000009:notes:191]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 171,719 |  |  | $ | 190,204 |  |  | $ | 152,750 |  |
| Income taxes | 98,943 |  |  | 134,178 |  |  | 91,846 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 104,260 |  |  | $ | 111,989 |  |  | $ | 128,044 |  |
| Non-cash investment in Elementum (Note 2) | — |  |  | — |  |  | 132,679 |  |
| Non-cash proceeds from sales of a non-strategic cost basis investment | — |  |  | — |  |  | 59,000 |  |
| Non-cash investment in Bright Machines (Note 2) | — |  |  | 127,641 |  |  | — |  |
| Finance lease for Bright Machines assets (Note 2) | 22,806 |  |  | 34,828 |  |  | — |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-20-000009:notes:192]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt are as follows:

[0000866374-20-000009:notes:193]
|  | As of March 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | — |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | — |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 433,406 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 310,115 |  |  | — |  |
| 4.750% Notes due June 2025 | 597,265 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 661,908 |  |  | — |  |
| India Facilities (1) | 138,238 |  |  | 170,206 |  |
| Other | 210,684 |  |  | 168,039 |  |
| Debt issuance costs | (13,377 | ) |  | (10,639 | ) |
|  | 2,838,239 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (149,130 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,689,109 |  |  | $ | 2,421,904 |  |

[0000866374-20-000009:notes:194]
| (1) | India Facilities as of March 31, 2019 include an approximately $91.4 million drawdown from a short-term bank borrowings facility entered in February 2019 which was repaid in May 2019 and a $78.8 million drawdown from the $200 million term loan facility entered in July 2018. |

[0000866374-20-000009:notes:195]
The weighted-average interest rates for the Company's long-term debt were 4.0% and 4.2% as of March 31, 2020 and 2019, respectively.

[0000866374-20-000009:notes:196]
Scheduled repayments of the Company's bank borrowings and long-term debt are as follows:

[0000866374-20-000009:notes:197]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2021 | $ | 149,456 |  |
| 2022 | 209,586 |  |
| 2023 | 870,178 |  |
| 2024 | 53,109 |  |
| 2025 | 310,115 |  |
| Thereafter | 1,259,172 |  |
| Total | $ | 2,851,616 |  |

[0000866374-20-000009:notes:198]
Term Loan due November 2021

[0000866374-20-000009:notes:199]
During fiscal year 2020, the Company repaid the total outstanding balance under the Term Loan due November 2021 with parts of the proceeds obtained from the new JPY 33.525 billion term loan (approximately USD $310 million as of March 31, 2020) due April 2024 and the new $650 million of 4.875% Notes due June 15, 2029 (see below for additional details on the new debts). As the transaction was determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during its fiscal year ended March 31, 2020, which was recorded in interest and other, net on the consolidated statements of operations.

[0000866374-20-000009:notes:200]
Term Loan Agreement due June 2022 and Revolving Line of Credit

[0000866374-20-000009:notes:201]
In June 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature in March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualified as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and are being amortized over the term of the 2022 Credit Facility.

[0000866374-20-000009:notes:202]
Borrowings under the 2022 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate that would be calculated as of each day in respect of a proposed LIBOR loan with a one-month interest period, plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 1.875% per annum, based on the Company’s credit ratings.

[0000866374-20-000009:notes:203]
The 2022 Credit Facility is unsecured and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of March 31, 2020, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.

[0000866374-20-000009:notes:204]
Notes due February 2020 and February 2023

[0000866374-20-000009:notes:205]
In February 2013, the Company issued $500 million of 4.625% Notes due February 15, 2020 and $500 million of 5.000% Notes due February 15, 2023 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act. In July 2013, the Company exchanged these notes for new notes (collectively the "Notes") with substantially similar terms and completed the registration of the Notes with the Securities and Exchange Commission.

[0000866374-20-000009:notes:206]
Interest on the Notes is payable semi-annually, which commenced on August 15, 2013. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and up until June 30, 2017 were guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). The Company replaced its $2.1 billion credit facility, which was due to expire in March 2019 and was guaranteed by the guarantor subsidiaries, with the 2022 Credit Facility, which is not guaranteed by the guarantor subsidiaries. Effective upon the replacement, all guarantor subsidiaries were released from their guarantees under the indenture governing the Notes.

[0000866374-20-000009:notes:207]
At any time prior to maturity, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date. During fiscal year 2020, the Company tendered and redeemed the total outstanding balance under the Notes due February 15, 2020 with parts of the proceeds obtained from the new JPY 33.525 billion term loan due April 2024 and the new $650 million of 4.875% Notes due June 15, 2029. As the transaction was determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during its fiscal year ended March 31, 2020, which was recorded in interest and other, net on the consolidated statements of operations.

[0000866374-20-000009:notes:208]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately. As of March 31, 2020, the Company was in compliance with the covenants in the indenture governing the Notes.

[0000866374-20-000009:notes:209]
Term Loan due April 2024

[0000866374-20-000009:notes:210]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 9 for additional details.

[0000866374-20-000009:notes:211]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2020, the Company was in compliance with the covenants under this term loan agreement.

[0000866374-20-000009:notes:212]
Notes due June 2025

[0000866374-20-000009:notes:213]
In June 2015, the Company issued $600 million of 4.750% Notes ("2025 Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at 99.213% of face value, and an effective yield of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which was used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.

[0000866374-20-000009:notes:214]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the 2025 Notes. The issuance costs were capitalized and presented on the balance sheet as a direct deduction from the carrying amount of the 2025 Notes.

[0000866374-20-000009:notes:215]
Interest on the 2025 Notes is payable semi-annually, commencing on December 15, 2015. The 2025 Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and up until June 30, 2017 were guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). The Company replaced its $2.1 billion credit facility, which was due to expire in March 2019 and was guaranteed by the guarantor subsidiaries, with the 2022 Credit Facility, which is not guaranteed by the guarantor subsidiaries. Effective upon the replacement, all guarantor subsidiaries were released from their guarantees under the indenture for the 2025 Notes.

[0000866374-20-000009:notes:216]
At any time prior to March 15, 2025, the Company may redeem some or all of the 2025 Notes at a redemption price equal to 100% of the principal amount of the 2025 Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the 2025 Notes indenture), the Company must offer to repurchase the 2025 Notes at a repurchase price equal to 101% of the principal amount of the 2025 Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0000866374-20-000009:notes:217]
The indenture governing the 2025 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2025 Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2025 Notes may declare all of the 2025 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2025 Notes. As of March 31, 2020, the Company was in compliance with the covenants in the indenture governing the 2025 Notes.

[0000866374-20-000009:notes:218]
Notes due June 2029

[0000866374-20-000009:notes:219]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “Existing 2029 Notes”), at 99.607% of face value. In November 2019, as a further issuance of the Existing 2029 Notes, the Company issued under the same terms, an additional $200 million of 4.875% Notes due June 15, 2029 (together with the "Existing 2029 Notes", the "2029 Notes"), at 107.289% of face value. Immediately after the issuance of the notes issued in November 2019, the Company has $650 million aggregate principal amount of 4.875% Notes due 2029 outstanding. The Company received in aggregate, proceeds of approximately $662.8 million, net of discount and premium, from the issuances which were used, together with available cash, to refinance certain other outstanding debt. The Company incurred and capitalized as a direct reduction to the carrying amount of the notes presented on the balance sheet approximately $6.6 million of costs in conjunction with the issuance of the 2029 Notes.

[0000866374-20-000009:notes:220]
Interest on the 2029 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2019. The 2029 Notes are senior unsecured obligations of the Company and rank equally with all of the Company’s other existing and future senior and unsecured indebtedness.

[0000866374-20-000009:notes:221]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of March 31, 2020, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.

[0000866374-20-000009:notes:222]
Other Borrowings

[0000866374-20-000009:notes:223]
In July 2018, a subsidiary of the Company entered into a $200 million term loan facility (the "Facility"), under which there was $138.2 million in borrowings outstanding as of March 31, 2020. The Facility was used to fund capital expenditures to support the Company's expansion plans for India. The availability period during which drawdowns can be made was from the date of the agreement to and including January 2020. The maximum maturity of each drawdown will be 5 years from the funded Capex shipment date. As a result, the longest maturity date of any drawdown under the Facility will be June 2023. Borrowings under this term loan bear interest at LIBOR plus a margin of 0.90% to 1.15% depending on loan duration.

[0000866374-20-000009:notes:224]
In January 2017, the Company borrowed €100 million (approximately $110.1 million as of March 31, 2020), under a 5-year, term-loan agreement due January 2, 2022. Borrowings under this term loan bear interest at EURIBOR minus 0.1% plus the applicable margin ranging between 0.40% and 1.35%, based on the Company's credit ratings. The loan is repayable upon maturity.

[0000866374-20-000009:notes:225]
In October 2015, the Company borrowed €50 million (approximately $50.2 million as of March 31, 2020), under a 5-year, term-loan agreement due September 30, 2020. Borrowings under this term loan bear interest at EURIBOR plus the applicable margin ranging between 0.80% and 2.00%, based on the Company’s credit ratings. The loan is repayable beginning December 30, 2016 in quarterly payments of €312,500 through June 30, 2020 with the remainder due upon maturity. As of March 31, 2020, the borrowings have been included as current liabilities under the consolidated balance sheet.

[0000866374-20-000009:notes:226]
These term loans are unsecured and are guaranteed by the Company. These term loan agreements contain customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. These term loan agreements also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during their terms. As of March 31, 2020, the Company was in compliance with the covenants under these term loan agreements.

[0000866374-20-000009:notes:227]
As of March 31, 2020, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities in the amount of $327.7 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2020 and 2019. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin.

[0000866374-20-000009:notes:228]
In April 2020, the Company executed amendments to increase the allowable cash restructuring charges excludable in the debt to EBITDA covenant calculation in its existing credit facilities. These amendments increase the Company's flexibility in the event that additional cost reduction activities are required given the uncertainty in future demand that could impact profitability as a result of the COVID-19 pandemic.
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026, at 99.617% of face value, and $325 million aggregate principal amount of 4.875% Notes due May 2030, at 99.562% of face value. The total proceeds of $740 million, net of discount and issuance costs, are expected to be used for general corporate purposes, which may include repaying, redeeming or repurchasing outstanding debt and for working capital, capital expenditures and acquisitions.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-20-000009:notes:229]
FINANCIAL INSTRUMENTS
Foreign Currency Contracts

[0000866374-20-000009:notes:230]
The Company transacts business in various foreign countries and is therefore exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency unit of the operating entity. The Company enters into short-term and long-term foreign currency derivatives contracts, including forward, swap, and options contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains

[0000866374-20-000009:notes:231]
and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-20-000009:notes:232]
As of March 31, 2020, the aggregate notional amount of the Company's outstanding foreign currency derivative contracts was $9.8 billion as summarized below:

[0000866374-20-000009:notes:233]
|  | Foreign CurrencyAmount |  | Notional ContractValue in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| CNY | 1,430,500 |  |  | — |  |  | $ | 201,755 |  |  | $ | — |  |
| EUR | 45,679 |  |  | 38,009 |  |  | 50,075 |  |  | 43,078 |  |
| ILS | 344,500 |  |  | — |  |  | 96,283 |  |  | — |  |
| JPY | 33,525,000 |  |  | — |  |  | 300,000 |  |  |  |
| MXN | 5,111,000 |  |  | — |  |  | 218,442 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 239,421 |  |  | 9,524 |  |
|  |  |  |  |  | 1,105,976 |  |  | 52,602 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |
| BRL | — |  |  | 603,000 |  |  | — |  |  | 117,999 |  |
| CNY | 4,250,664 |  |  | 331,088 |  |  | 604,494 |  |  | 46,749 |  |
| EUR | 2,080,415 |  |  | 2,203,938 |  |  | 2,278,226 |  |  | 2,413,824 |  |
| GBP | 55,892 |  |  | 78,988 |  |  | 68,333 |  |  | 96,952 |  |
| HUF | 55,435,797 |  |  | 59,591,932 |  |  | 171,813 |  |  | 184,694 |  |
| ILS | 271,500 |  |  | 134,500 |  |  | 75,880 |  |  | 37,591 |  |
| INR | 5,685,000 |  |  | 5,931,167 |  |  | 75,957 |  |  | 79,185 |  |
| JPY | 3,705,195 |  |  | 34,778,855 |  |  | 34,287 |  |  | 321,655 |  |
| MXN | 4,839,428 |  |  | 3,576,516 |  |  | 206,835 |  |  | 152,859 |  |
| MYR | 2,919,100 |  |  | 2,653,490 |  |  | 661,927 |  |  | 601,698 |  |
| SEK | 649,418 |  |  | 711,823 |  |  | 65,373 |  |  | 70,713 |  |
| Other | N/A |  |  | N/A |  |  | 179,509 |  |  | 114,956 |  |
|  |  |  |  |  | 4,422,634 |  |  | 4,238,875 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 5,528,610 |  |  | $ | 4,291,477 |  |

[0000866374-20-000009:notes:234]
As of March 31, 2020 and 2019, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the consolidated statements of operations. As of March 31, 2020 and 2019, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred losses totaled $30.8 million as of March 31, 2020, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-20-000009:notes:235]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of March 31, 2020. The changes in fair value of the USD JPY cross currency swap are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also impacts the same line.

[0000866374-20-000009:notes:236]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2020 and 2019:

[0000866374-20-000009:notes:237]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31, 2020 |  | March 31, 2019 |  | Balance SheetLocation |  | March 31, 2020 |  | March 31, 2019 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 7,257 |  |  | $ | 10,503 |  |  | Other current liabilities |  | $ | 46,645 |  |  | $ | 10,282 |  |
| Foreign currency contracts | Other assets |  | $ | 13,849 |  |  | $ | — |  |  | Other liabilities |  | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 83,086 |  |  | $ | 16,774 |  |  | Other current liabilities |  | $ | 102,709 |  |  | $ | 17,144 |  |

[0000866374-20-000009:notes:238]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-20-000009:notes:239]
ACCUMULATED OTHER COMPREHENSIVE LOSS
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2020, 2019 and 2018 are as follows:

[0000866374-20-000009:notes:240]
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance on April 1, 2017 | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |
| Other comprehensive gain before reclassifications | 15,667 |  |  | 46,022 |  |  | 61,689 |  |
| Net gains reclassified from accumulated other comprehensive loss | (18,987 | ) |  | (404 | ) |  | (19,391 | ) |
| Net current-period other comprehensive gain (loss) | (3,320 | ) |  | 45,618 |  |  | 42,298 |  |
| Ending balance on March 31, 2018 | $ | (35,746 | ) |  | $ | (50,099 | ) |  | $ | (85,845 | ) |
| Other comprehensive loss before reclassifications | (48,302 | ) |  | (59,508 | ) |  | (107,810 | ) |
| Net losses reclassified from accumulated other comprehensive loss | 42,492 |  |  | — |  |  | 42,492 |  |
| Net current-period other comprehensive loss | (5,810 | ) |  | (59,508 | ) |  | (65,318 | ) |
| Ending balance on March 31, 2019 | $ | (41,556 | ) |  | $ | (109,607 | ) |  | $ | (151,163 | ) |
| Other comprehensive loss before reclassifications | (42,837 | ) |  | (21,951 | ) |  | (64,788 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 2,730 |  |  | (1,446 | ) |  | 1,284 |  |
| Net current-period other comprehensive loss | (40,107 | ) |  | (23,397 | ) |  | (63,504 | ) |
| Ending balance on March 31, 2020 | $ | (81,663 | ) |  | $ | (133,004 | ) |  | $ | (214,667 | ) |

[0000866374-20-000009:notes:241]
Net (gains) losses reclassified from accumulated other comprehensive loss were immaterial during fiscal year 2020.

[0000866374-20-000009:notes:242]
Net losses reclassified from accumulated other comprehensive loss during fiscal year 2019 relating to derivative instruments and other includes $40.6 million attributable to the Company's cash flow hedge instruments which were recognized as a component of cost of sales in the consolidated statement of operations.

[0000866374-20-000009:notes:243]
Net gains reclassified from accumulated other comprehensive loss during fiscal year 2018 relating to derivative instruments and other includes $20.8 million attributable to the Company's cash flow hedge instruments which were recognized as a component of cost of sales in the consolidated statement of operations.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-20-000009:notes:244]
TRADE RECEIVABLES SECURITIZATION
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-20-000009:notes:245]
Asset-Backed Securitization Programs

[0000866374-20-000009:notes:246]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the "Global Program") and its North American Asset-Backed Securitization Agreement (the "North American Program," collectively, the "ABS Programs") to affiliated special purpose entities, each of which in turn sells the receivables to unaffiliated financial institutions.

[0000866374-20-000009:notes:247]
Prior to November 2019, these programs allowed the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. The portion of the purchase price for the receivables which was not paid by the unaffiliated financial institutions in cash was a deferred purchase price receivable, which was paid to the special purpose entity as payments on the receivables were collected from account debtors. The deferred purchase price receivable represented a beneficial interest in the transferred financial assets and was recognized at fair value as part of the sale transaction. The accounts receivable balances that were sold under the ABS Programs were removed from the consolidated balance sheets and

[0000866374-20-000009:notes:248]
the net cash proceeds received by the Company were included as cash provided by operating activities in the consolidated statements of cash flows. The Company recognized these proceeds net of the deferred purchase price, consisting of a receivable from the purchasers that entitled the Company to certain collections on the receivable. The Company recognized the collection of the deferred purchase price in net cash provided by investing activities in the consolidated statements of cash flows.

[0000866374-20-000009:notes:249]
Effective November 2019, the Company amended the ABS Programs to extend the facilities to November 26, 2021, and removed the requirement for the deferred purchase price receivable. Under the amended ABS Programs,  the entire purchase price of sold receivables are paid in cash. The amended ABS Programs contain a guarantee of payment by the special purpose entity, in an amount equal to approximately the net cash proceeds under the programs, and is collateralized by certain receivables held by the special purpose entity. The fair value of the guarantee obligation was immaterial as of March 31, 2020. The accounts receivable balances sold under the amended ABS Programs were removed from the consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the consolidated statements of cash flows.

[0000866374-20-000009:notes:250]
At the effective date of the amended ABS Programs, approximately $1.3 billion representing the outstanding balance of sold receivables was repurchased by the Company by exchanging outstanding deferred purchase price receivable of $0.4 billion and re-investing $0.9 billion of trade account receivables into the amended ABS Programs. These repurchases are considered non-cash investing activities in the consolidated statements of cash flows. As of March 31, 2020, the Company collected on all repurchased deferred purchase price receivables, which are reported as cash collections under deferred purchase price in the consolidated statements of cash flows.

[0000866374-20-000009:notes:251]
The deferred purchase price receivables, included in other current assets as of March 31, 2019 were carried at the expected recovery amount of the related receivables. Prior to the amendments of the ABS Programs, the difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer was recognized as a loss on sale of the related receivables, and recorded in interest and other, net in the consolidated statements of operations and were immaterial for all periods presented. There are no deferred purchase price receivables outstanding as of March 31, 2020.

[0000866374-20-000009:notes:252]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are legally isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which have the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $790 million for the Global Program, of which $615 million is committed and $175 million is uncommitted, and $285 million for the North American Program, of which $210 million is committed and $75 million is uncommitted.

[0000866374-20-000009:notes:253]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the fiscal years ended March 31, 2020, 2019 and 2018 were not material and are included in interest and other, net within the consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-20-000009:notes:254]
As of March 31, 2020, approximately $0.8 billion of accounts receivable had been sold to the special purpose entities under the amended ABS Programs for which the Company had received net cash proceeds for the same amount. As of March 31, 2019, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $0.9 billion and deferred purchase price receivables of $0.3 billion. The deferred purchase price balance as of March 31, 2019, also represent the non-cash beneficial interest obtained in exchange for securitized receivables.

[0000866374-20-000009:notes:255]
For the fiscal years ended March 31, 2020, 2019 and 2018, cash flows from sales of receivables under the ABS Programs consisted of approximately $7.6 billion, $6.8 billion and $8.0 billion, respectively, for transfers of receivables, and approximately $2.6 billion, $3.6 billion and $4.6 billion, respectively, for collections on deferred purchase price receivables. The Company's cash flows from transfer of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-20-000009:notes:256]
Trade Accounts Receivable Sale Programs

[0000866374-20-000009:notes:257]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.4 billion and $0.5 billion as of March 31, 2020 and 2019, respectively. For the fiscal years ended March 31, 2020, 2019 and 2018, total accounts receivable sold to certain third party banking institutions was approximately $1.6 billion, $2.7 billion and $1.5 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-20-000009:notes:258]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-20-000009:notes:259]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000866374-20-000009:notes:260]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other noncurrent assets on the consolidated balance sheets and include investments in equity securities that are valued using active market prices. There were no investments classified as level 1 in the fair value hierarchy as of March 31, 2020.

[0000866374-20-000009:notes:261]
Level 2 - Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-20-000009:notes:262]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-20-000009:notes:263]
The Company's cash equivalents are comprised of bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-20-000009:notes:264]
The Company's deferred compensation plan assets also include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-20-000009:notes:265]
Level 3 - Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-20-000009:notes:266]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of March 31, 2020 and 2019.

[0000866374-20-000009:notes:267]
The Company's deferred purchase price receivables relating to its asset-backed securitization program are recorded initially at fair value based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short-term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not material. The interrelationship between these inputs is also insignificant. There are no deferred purchase price receivables outstanding as of March 31, 2020 due to the amended ABS Programs as further discussed in Note 11.

[0000866374-20-000009:notes:268]
There were no transfers between levels in the fair value hierarchy during fiscal years 2020 and 2019.

[0000866374-20-000009:notes:269]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-20-000009:notes:270]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2020 and 2019:

[0000866374-20-000009:notes:271]
|  | Fair Value Measurements as of March 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 403,657 |  |  | $ | — |  |  | $ | 403,657 |  |
| Foreign currency contracts (Note 9) | — |  |  | 104,192 |  |  | — |  |  | 104,192 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 49,086 |  |  | — |  |  | 49,086 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (149,354 | ) |  | $ | — |  |  | $ | (149,354 | ) |

[0000866374-20-000009:notes:272]
|  | Fair Value Measurements as of March 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 473,888 |  |  | $ | — |  |  | $ | 473,888 |  |
| Foreign currency contracts (Note 9) | — |  |  | 27,277 |  |  | — |  |  | 27,277 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 2,845 |  |  | 76,852 |  |  | — |  |  | 79,697 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (27,426 | ) |  | $ | — |  |  | $ | (27,426 | ) |

[0000866374-20-000009:notes:273]
Other financial instruments

[0000866374-20-000009:notes:274]
The following table presents the Company's major debts not carried at fair value as of March 31, 2020 and 2019:

[0000866374-20-000009:notes:275]
|  | As of March 31, 2020 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In thousands) |  | (In thousands) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | $ | 433,406 |  |  | $ | 413,903 |  |  | $ | 458,531 |  |  | $ | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 499,710 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 310,115 |  |  | 310,115 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,265 |  |  | 613,152 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 661,908 |  |  | 628,419 |  |  | — |  |  | — |  |  | Level 1 |
| Euro Term Loans | 207,646 |  |  | 207,646 |  |  | 165,270 |  |  | 165,270 |  |  | Level 2 |
| India Facilities | 138,238 |  |  | 138,238 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |

[0000866374-20-000009:notes:276]
The Term Loan due June 2022, and the Notes due February 2023, June 2025 and June 2029 are valued based on broker trading prices in active markets.
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans due September 2020, March 2021 and January 2022, based on the current market rate, and as of March 31, 2020, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-20-000009:notes:277]
COMMITMENTS AND CONTINGENCIES
Commitments

[0000866374-20-000009:notes:278]
As of March 31, 2020 and 2019, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under finance leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2038 and require the following minimum lease payments:

[0000866374-20-000009:notes:279]
| Fiscal Year Ending March 31, | Operating Lease |
|  | (In thousands) |
| 2021 | $ | 134,817 |  |
| 2022 | 115,465 |  |
| 2023 | 100,779 |  |
| 2024 | 84,374 |  |
| 2025 | 67,772 |  |
| Thereafter | 253,768 |  |
| Total minimum lease payments | $ | 756,975 |  |

[0000866374-20-000009:notes:280]
Litigation and other legal matters

[0000866374-20-000009:notes:281]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in

[0000866374-20-000009:notes:282]
early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-20-000009:notes:283]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-20-000009:notes:284]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

[0000866374-20-000009:notes:285]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December  4, 2019, Defendants filed a motion to dismiss the amended complaint. The motion has been fully briefed. On March 12, 2020, the Court vacated the hearing date and took the motion under submission without argument. No decision has yet been issued. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-20-000009:notes:286]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-

[0000866374-20-000009:notes:287]
related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-20-000009:notes:288]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling 373.7 million Brazilian reals (approximately USD $73.1 million based on the exchange rate as of March 31, 2020). Four of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60.5 million Brazilian reals or USD $11.8 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and has filed an annulment action in federal court in Sao Paolo, Brazil on March 23, 2020; the value of that assessment is 33.9 million Brazilian reals (approximately USD $6.6 million). The Company believes there is no legal basis for any of these assessments and has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-20-000009:notes:289]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter which is ongoing. The Company expects to complete the investigation and report to OFAC by the end of the second quarter of fiscal year 2021, and cannot at this time estimate the amount, or the range of reasonably possible amounts, of penalties the Company could be subject to, which could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-20-000009:notes:290]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes. As the final resolution of the assessment remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-20-000009:notes:291]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-20-000009:notes:292]
INCOME TAXES
The domestic (Singapore) and foreign components of income before income taxes were comprised of the following:

[0000866374-20-000009:notes:293]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Domestic | $ | (2,903 | ) |  | $ | (10,498 | ) |  | $ | 323,522 |  |
| Foreign | 161,388 |  |  | 192,624 |  |  | 197,371 |  |
| Total | $ | 158,485 |  |  | $ | 182,126 |  |  | $ | 520,893 |  |

[0000866374-20-000009:notes:294]
The provision for income taxes consisted of the following:

[0000866374-20-000009:notes:295]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Domestic | $ | 1,781 |  |  | $ | 1,517 |  |  | $ | 2,894 |  |
| Foreign | 62,558 |  |  | 99,894 |  |  | 50,889 |  |
|  | 64,339 |  |  | 101,411 |  |  | 53,783 |  |
| Deferred: |  |  |  |  |  |
| Domestic | (38 | ) |  | (40 | ) |  | 422 |  |
| Foreign | 6,605 |  |  | (12,644 | ) |  | 38,154 |  |
|  | 6,567 |  |  | (12,684 | ) |  | 38,576 |  |
| Provision for income taxes | $ | 70,906 |  |  | $ | 88,727 |  |  | $ | 92,359 |  |

[0000866374-20-000009:notes:296]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2020, 2019 and 2018. The reconciliation of the income tax expense expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0000866374-20-000009:notes:297]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Income taxes based on domestic statutory rates | $ | 26,943 |  |  | $ | 30,961 |  |  | $ | 88,552 |  |
| Effect of tax rate differential | (81,213 | ) |  | (135,033 | ) |  | (244,128 | ) |
| Change in unrecognized tax benefit | (896 | ) |  | (15,381 | ) |  | 22,180 |  |
| Change in valuation allowance | 92,543 |  |  | 191,896 |  |  | 297,330 |  |
| Recognition of prior year taxes recoverable | 13,305 |  |  | 5,439 |  |  | (53,757 | ) |
| Expiration of tax attributes | — |  |  | 4,277 |  |  | — |  |
| APB23 tax liability | 8,653 |  |  | 2,047 |  |  | 1,741 |  |
| Other | 11,571 |  |  | 4,521 |  |  | (19,559 | ) |
| Provision for income taxes | $ | 70,906 |  |  | $ | 88,727 |  |  | $ | 92,359 |  |

[0000866374-20-000009:notes:298]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2020, 2019 and 2018 was $15.6 million, $24.4 million and $21.7 million, respectively. For the fiscal year ended March 31, 2020, the effect on basic and diluted earnings per share was $0.03 and $0.03, respectively, and the effect on basic and diluted earnings per share during fiscal years 2019 and 2018 were $0.05 and $0.05, and $0.04 and $0.04, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in various years through the end of fiscal year 2028.

[0000866374-20-000009:notes:299]
The Company provides a valuation allowance against deferred tax assets that in the Company's estimation are not more likely than not to be realized. During fiscal year 2020, 2019 and 2018, the Company released valuation allowances totaling $1.1 million, $2.8 million and $1.3 million, respectively. For fiscal year 2020, this valuation allowance release was related to certain operations in China as this amount was deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those subsidiaries. In addition, a valuation allowance of $3.4 million was added for a different operating subsidiary in China due to continued losses and the determination the company would be less likely than not to utilize its deferred tax assets. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances. Lastly, these valuation allowance reductions

[0000866374-20-000009:notes:300]
and eliminations were offset by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions. For fiscal years ended March 31, 2020, 2019 and 2018, the offsetting amounts totaled $90.2 million, $194.8 million and ($65.9) million, respectively.

[0000866374-20-000009:notes:301]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years ended March 31, 2020, 2019 and 2018 were $27.9 million, $7.5 million and $65.8 million, respectively.

[0000866374-20-000009:notes:302]
The components of deferred income taxes are as follows:

[0000866374-20-000009:notes:303]
|  | As of March 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (36,789 | ) |  | $ | (39,376 | ) |
| Intangible assets | (49,637 | ) |  | (57,939 | ) |
| Others | (25,818 | ) |  | (14,879 | ) |
| Total deferred tax liabilities | (112,244 | ) |  | (112,194 | ) |
| Deferred tax assets: |  |  |  |
| Fixed assets | 58,623 |  |  | 67,980 |  |
| Intangible assets | 6,568 |  |  | 7,442 |  |
| Deferred compensation | 17,456 |  |  | 13,864 |  |
| Inventory valuation | 26,742 |  |  | 11,082 |  |
| Provision for doubtful accounts | 5,120 |  |  | 4,797 |  |
| Net operating loss and other carryforwards | 1,820,980 |  |  | 1,944,782 |  |
| Others | 207,910 |  |  | 243,016 |  |
| Total deferred tax assets | 2,143,399 |  |  | 2,292,963 |  |
| Valuation allowances | (1,939,279 | ) |  | (2,083,082 | ) |
| Total deferred tax assets, net of valuation allowances | 204,120 |  |  | 209,881 |  |
| Net deferred tax asset | $ | 91,876 |  |  | $ | 97,687 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Long-term asset | $ | 162,737 |  |  | $ | 164,611 |  |
| Long-term liability | (70,861 | ) |  | (66,924 | ) |
| Total | $ | 91,876 |  |  | $ | 97,687 |  |

[0000866374-20-000009:notes:304]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-20-000009:notes:305]
The Company has recorded deferred tax assets of approximately $1.9 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $81.9 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-20-000009:notes:306]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
|  | (In thousands) |
| 2021 - 2026 | $ | 613,769 |  |
| 2027 - 2032 | 476,336 |  |
| 2033 and post | 199,327 |  |
| Indefinite | 629,835 |  |
|  | $ | 1,919,267 |  |

[0000866374-20-000009:notes:307]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-20-000009:notes:308]
The Company does not provide for income taxes on approximately $1.4 billion of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. The estimated amount of the unrecognized deferred tax liability on these undistributed earnings is approximately $128 million. As a result, as of March 31, 2020, the Company has provided for earnings in foreign subsidiaries that are not considered to be indefinitely reinvested and therefore subject to withholding taxes on $97.6 million of undistributed foreign earnings, recording a deferred tax liability of approximately $8.7 million thereon.

[0000866374-20-000009:notes:309]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-20-000009:notes:310]
|  | Fiscal Year EndedMarch 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Balance, beginning of fiscal year | $ | 251,722 |  |  | $ | 227,590 |  |
| Additions based on tax position related to the current year | 24,052 |  |  | 82,966 |  |
| Additions for tax positions of prior years | 4,137 |  |  | 5,575 |  |
| Reductions for tax positions of prior years | (3,162 | ) |  | (15,432 | ) |
| Reductions related to lapse of applicable statute of limitations | (18,355 | ) |  | (14,786 | ) |
| Settlements | — |  |  | (22,174 | ) |
| Impact from foreign exchange rates fluctuation | (12,386 | ) |  | (12,017 | ) |
| Balance, end of fiscal year | $ | 246,008 |  |  | $ | 251,722 |  |

[0000866374-20-000009:notes:311]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an estimated of an additional approximately $16 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-20-000009:notes:312]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2008.

[0000866374-20-000009:notes:313]
Of the $246.0 million of unrecognized tax benefits at March 31, 2020, $165.6 million will affect the annual effective tax rate (ETR) if the benefits are eventually recognized. The amount that doesn’t impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-20-000009:notes:314]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company’s tax expense. During the fiscal years ended March 31, 2020, 2019 and 2018, the Company recognized interest and penalty of approximately ($0.9) million and ($2.9) million and ($3.3) million, respectively. The Company had approximately $12.3 million, $13.3 million and $16.2 million accrued for the payment of interest and penalty as of the fiscal years ended March 31, 2020, 2019 and 2018, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-20-000009:notes:315]
RESTRUCTURING CHARGES
Fiscal Year 2020

[0000866374-20-000009:notes:316]
During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and streamline its cost structure. During fiscal year 2020, the Company recognized $216.4 million of restructuring charges. The Company incurred cash charges of approximately $159.3 million, that were predominantly for employee severance, in addition to non-cash charges of $57.1 million, respectively, primarily related to asset impairments.

[0000866374-20-000009:notes:317]
Restructuring charges are not included in segment income, as disclosed further in note 20.

[0000866374-20-000009:notes:318]
Fiscal Year 2019

[0000866374-20-000009:notes:319]
During fiscal year 2019, the Company took targeted actions to optimize its portfolio, most notably within CTG. The Company recognized restructuring charges of approximately $113.3 million during the fiscal year ended March 31, 2019, of which $73.2 million were non-cash charges primarily for asset impairments. A significant component of its charges were associated with the wind down of its NIKE operations in Mexico in the third quarter of fiscal year 2019 where it recognized charges of $66 million primarily for non-cash asset impairments.

[0000866374-20-000009:notes:320]
In addition, the Company executed targeted head-count reductions at existing operating and design sites and corporate functions and exited certain immaterial businesses. Of these total restructuring charges, approximately $99.0 million was recognized as a component of cost of sales during the fiscal year ended March 31, 2019.

[0000866374-20-000009:notes:321]
Fiscal Year 2018

[0000866374-20-000009:notes:322]
During fiscal year 2018, the Company initiated targeted restructuring activities focused on optimizing the Company's cost structure in lower growth areas and, more importantly, streamlining certain corporate and segment functions. Restructuring charges are recorded based upon employee termination dates, site closure and consolidation plans generally in conjunction with an overall corporate initiative to drive cost reduction and realign the Company's global footprint. The Company recognized approximately $78.6 million of cash charges predominantly related to employee severance costs and $12.1 million of non-cash charges for asset impairment and other exit charges under the above plan. Of these total charges, approximately $66.8 million was recognized in cost of sales. A majority of the fiscal year 2018 restructuring activities were completed as of March 31, 2018.

[0000866374-20-000009:notes:323]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In thousands) |
| Balance as of March 31, 2017 | $ | 16,359 |  |  | $ | — |  |  | $ | 7,142 |  |  | $ | 23,501 |  |
| Provision for charges incurred in fiscal year 2018 | 69,439 |  |  | 9,417 |  |  | 11,835 |  |  | 90,691 |  |
| Cash payments for charges incurred in fiscal year 2017 and prior | (13,237 | ) |  | — |  |  | (3,671 | ) |  | (16,908 | ) |
| Cash payments for charges incurred in fiscal year 2018 | (24,555 | ) |  | — |  |  | — |  |  | (24,555 | ) |
| Non-cash charges incurred in fiscal year 2018 | — |  |  | (9,417 | ) |  | (1,968 | ) |  | (11,385 | ) |
| Balance as of March 31, 2018 | 48,006 |  |  | — |  |  | 13,338 |  |  | 61,344 |  |
| Provision for charges incurred in fiscal year 2019 | 38,634 |  |  | 46,365 |  |  | 28,314 |  |  | 113,313 |  |
| Cash payments for charges incurred in fiscal year 2018 and prior | (40,623 | ) |  | — |  |  | (4,293 | ) |  | (44,916 | ) |
| Cash payments for charges incurred in fiscal year 2019 | (22,783 | ) |  | — |  |  | (1,330 | ) |  | (24,113 | ) |
| Non-cash charges incurred in fiscal year 2019 | — |  |  | (46,365 | ) |  | (26,829 | ) |  | (73,194 | ) |
| Balance as of March 31, 2019 | 23,234 |  |  | — |  |  | 9,200 |  |  | 32,434 |  |
| Provision for charges incurred in fiscal year 2020 | 123,341 |  |  | 45,623 |  |  | 47,443 |  |  | 216,407 |  |
| Cash payments for charges incurred in fiscal year 2019 and prior | (14,610 | ) |  | — |  |  | (2,800 | ) |  | (17,410 | ) |
| Cash payments for charges incurred in fiscal year 2020 | (112,463 | ) |  | — |  |  | (34,647 | ) |  | (147,110 | ) |
| Non-cash charges incurred in fiscal year 2020 | — |  |  | (45,623 | ) |  | (15,296 | ) |  | (60,919 | ) |
| Balance as of March 31, 2020 | 19,502 |  |  | — |  |  | 3,900 |  |  | 23,402 |  |
| Less: Current portion (classified as other current liabilities) | 19,502 |  |  | — |  |  | 3,900 |  |  | 23,402 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-20-000009:notes:324]
OTHER CHARGES (INCOME), NET
Other charges (income), net for the fiscal years ended March 31, 2020, 2019 and 2018 are primarily composed of the following:

[0000866374-20-000009:notes:325]
|  | Fiscal Year Ended March 31 |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Gain on deconsolidation of subsidiary (1) | $ | — |  |  | $ | (87,348 | ) |  | $ | (151,574 | ) |
| Gain on sale of non-strategic business (2) | — |  |  | — |  |  | (38,689 | ) |
| Investment impairments and dispositions (3) | 97,691 |  |  | 193,063 |  |  | 21,895 |  |

[0000866374-20-000009:notes:326]
| (1) | During fiscal year 2019, the Company recognized other income of approximately $87 million from the deconsolidation of Bright Machines. The fiscal year ended March 31, 2018 includes a $151.6 million gain from the deconsolidation of Elementum. See note 2 for additional information on the deconsolidations of Bright Machines and Elementum. |

[0000866374-20-000009:notes:327]
| (2) | The Company recognized other income of $38.7 million from the sale of a non-strategic cost basis investment during fiscal year 2018. |

[0000866374-20-000009:notes:328]
(3)

[0000866374-20-000009:notes:329]
During fiscal year 2020, and in connection with the Company’s ongoing assessment of its investment portfolio strategy, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $97.7 million total impairment charge (See note 2 for additional information). During fiscal year 2019, the Company recognized investment impairments of $193.1 million, under other charges, which is primarily driven by an $84 million impairment in its investment in Elementum, coupled with a $76 million loss for the portion of its investment in an unrelated third-party venture backed company, also determined to be impaired. The Company recognized $21.9 million of impairment during fiscal year 2018 for certain non-core investments.


## flex:InterestAndOtherNetTextBlock

[0000866374-20-000009:notes:330]
INTEREST AND OTHER, NET
Interest and other, net for the fiscal years ended March 31, 2020, 2019 and 2018 are primarily composed of the following:

[0000866374-20-000009:notes:331]
|  | Fiscal Year Ended March 31 |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Interest expenses on debt obligations (1) | $ | 145,978 |  |  | $ | 145,658 |  |  | $ | 123,098 |  |
| ABS and AR sales programs related expenses | 42,807 |  |  | 46,344 |  |  | 25,002 |  |
| Interest income | (19,382 | ) |  | (19,496 | ) |  | (18,840 | ) |
| Gain on foreign exchange transactions | (9,677 | ) |  | (1,175 | ) |  | (15,222 | ) |

[0000866374-20-000009:notes:332]
(1)

[0000866374-20-000009:notes:333]
Interest expense on debt obligations for the fiscal year 2020 include debt extinguishment costs of $7.2 million, related to the full repayments of the Notes due February 2020 and the Term Loan due November 2021. There were no debt extinguishment costs incurred during the fiscal years 2019 or 2018.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-20-000009:notes:334]
BUSINESS AND ASSET ACQUISITIONS & DIVESTITURES
Fiscal 2020 Business acquisition and divestitures

[0000866374-20-000009:notes:335]
During fiscal year 2020, the Company completed an acquisition that was not significant to the consolidated financial position, result of operations and cash flows of the Company.

[0000866374-20-000009:notes:336]
Further, during fiscal year 2020, the Company disposed of two immaterial non-strategic businesses that operated across most of its segments. The net gain on disposition was not material to the Company’s consolidated financial results, and was included in other charges (income), net in the consolidated statements of operations for the fiscal year 2020.

[0000866374-20-000009:notes:337]
Pro-forma results of operations for the acquisition and divestitures have not been presented because the effects were not individually, nor in the aggregate, material to the Company's consolidated financial results for all periods presented.

[0000866374-20-000009:notes:338]
Fiscal 2019 Business acquisition

[0000866374-20-000009:notes:339]
In October 2018, the Company completed the acquisition of a business that was not significant to the consolidated financial position, result of operations and cash flows of the Company. The acquired business expanded the Company's design capabilities in the telecom market within the CEC segment. The assets acquired and liabilities assumed were not material to the Company's consolidated financial results. Results of operations were included in the Company’s consolidated financial results beginning on the date of acquisition, and were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-20-000009:notes:340]
Fiscal 2019 Divestitures

[0000866374-20-000009:notes:341]
During the third quarter of fiscal year 2019, the Company disposed of an immaterial non-strategic business in Brazil that operated across all of its segments. The net loss on disposition was not material to the Company's consolidated financial results, and was included in other charges (income), net in the consolidated statement of operation for the fiscal year 2019.

[0000866374-20-000009:notes:342]
During the second quarter of fiscal year 2019, the Company divested its China-based Multek operations, for proceeds of approximately $267.1 million, net of cash. The Company transferred approximately $231.4 million of net assets, primarily

[0000866374-20-000009:notes:343]
property and equipment, accounts receivable, and accounts payable. Further, the Company incurred various selling costs as part of this divestiture and allocated approximately $19.0 million of goodwill to the divested business. This transaction resulted in the recognition of an immaterial loss which is included in other charges (income), net in the consolidated statements of operations for the fiscal year 2019.

[0000866374-20-000009:notes:344]
Pro-forma results of operations for these divestitures have not been presented because the effects were not individually, nor in the aggregate, material to the Company's consolidated financial results for all periods presented.

[0000866374-20-000009:notes:345]
Fiscal 2018 Business and asset acquisitions

[0000866374-20-000009:notes:346]
During the fiscal year ended March 31, 2018, the Company completed two acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operation and cash flows of the Company.

[0000866374-20-000009:notes:347]
In April 2017, the Company completed its acquisition of AGM, which expanded its capabilities in the automotive market, and is included within the HRS segment. The Company paid $213.7 million, net of cash acquired.

[0000866374-20-000009:notes:348]
Additionally, in September 2017, the Company acquired a power modules business, which expanded its capabilities within the CEC segment. The Company paid $54.7 million, net of cash acquired.

[0000866374-20-000009:notes:349]
The intangibles of AGM comprised solely of customer relationships, will amortize over a weighted-average estimated useful life of 10 years. The intangibles of the power modules business, comprised of $16.0 million of customer relationships and $17.3 million of licenses and other intangibles, will amortize over a weighted-average estimated useful life of 10 years and 8 years, respectively.

[0000866374-20-000009:notes:350]
The results of operations of the acquisitions were included in the Company’s consolidated financial results beginning on the respective acquisition dates, and the total amount of net income and revenue, collectively, were immaterial to the Company's consolidated financial results for the fiscal year ended March 31, 2018. Pro-forma results of operations for the acquisitions completed in fiscal year 2018 have not been presented because the effects, individually and in aggregate, were not material to the Company’s consolidated financial results for all periods presented.


## us-gaap:TreasuryStockTextBlock

[0000866374-20-000009:notes:351]
SHARE REPURCHASE PLAN
During fiscal year 2020, the Company repurchased approximately 23.7 million shares for an aggregate purchase value of approximately $259.9 million and retired all of these shares.

[0000866374-20-000009:notes:352]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 20, 2019. As of March 31, 2020, shares in the aggregate amount of $315.2 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-20-000009:notes:353]
SEGMENT REPORTING
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the Chief Operating Decision Maker ("CODM"), or a decision making group, in deciding how to allocate resources and in assessing performance. Resource allocation decisions and the Company's performance are assessed by its Chief Executive Officer ("CEO"), with support from certain direct staff who oversee operations of the Company's businesses, collectively identified as the CODM or the decision making group.

[0000866374-20-000009:notes:354]
The Company has four reportable segments as of March 31, 2020: HRS, IEI, CEC and CTG. These segments represent components of the Company for which separate financial information is available that is utilized on a regular basis by the CODM. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 for a description of the various product categories manufactured under each of these segments.

[0000866374-20-000009:notes:355]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related assets impairments, restructuring charges, the new revenue standard adoption impact, legal and other, interest and other, net and other charges (income), net.

[0000866374-20-000009:notes:356]
Selected financial information by segment is in the table below.

[0000866374-20-000009:notes:357]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |
| High Reliability Solutions | $ | 4,742,424 |  |  | $ | 4,828,950 |  |  | $ | 4,769,464 |  |
| Industrial & Emerging Industries | 7,277,350 |  |  | 6,182,637 |  |  | 5,972,496 |  |
| Communications & Enterprise Compute | 6,985,669 |  |  | 8,336,330 |  |  | 7,729,350 |  |
| Consumer Technologies Group | 5,204,427 |  |  | 6,862,594 |  |  | 6,969,821 |  |
|  | $ | 24,209,870 |  |  | $ | 26,210,511 |  |  | $ | 25,441,131 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |
| High Reliability Solutions | $ | 316,007 |  |  | $ | 371,003 |  |  | $ | 380,878 |  |
| Industrial & Emerging Industries | 465,707 |  |  | 269,172 |  |  | 235,422 |  |
| Communications & Enterprise Compute | 142,347 |  |  | 214,723 |  |  | 186,335 |  |
| Consumer Technologies Group | 87,518 |  |  | 121,336 |  |  | 111,629 |  |
| Corporate and Other | (113,548 | ) |  | (104,471 | ) |  | (127,810 | ) |
| Total income | 898,031 |  |  | 871,763 |  |  | 786,454 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 64,106 |  |  | 74,396 |  |  | 78,640 |  |
| Stock-based compensation | 71,546 |  |  | 76,032 |  |  | 85,244 |  |
| Customer related asset impairments (1) | 105,940 |  |  | 87,093 |  |  | 6,251 |  |
| Restructuring charges (Note 15) | 216,407 |  |  | 113,313 |  |  | 90,691 |  |
| New revenue standard adoption impact (Note 4) | — |  |  | 9,291 |  |  | — |  |
| Legal and other (2) | 26,270 |  |  | 35,644 |  |  | 51,631 |  |
| Interest and other, net | 163,727 |  |  | 183,454 |  |  | 122,823 |  |
| Other charges (income), net (Note 16) | 91,550 |  |  | 110,414 |  |  | (169,719 | ) |
| Income before income taxes | $ | 158,485 |  |  | $ | 182,126 |  |  | $ | 520,893 |  |

[0000866374-20-000009:notes:358]
| (1) | Customer related asset impairments for fiscal year 2020, primarily relate to non-cash impairments of certain property and equipment for customers we have disengaged or are in the process of disengaging, additional provision for doubtful accounts receivable, charges for other asset impairments, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand. |

[0000866374-20-000009:notes:359]
Customer related asset impairments for fiscal year 2019, primarily relate to provision for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties and/or the Company is disengaging.

[0000866374-20-000009:notes:360]
| (2) | Legal and other during fiscal year 2020, primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India, offset by certain gains resulting from the recognition of prior year expenses paid to the government now considered probable of recovery and reasonably estimable due to a favorable tax ruling. |

[0000866374-20-000009:notes:361]
Legal and other during fiscal year 2019, primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, Legal and other also includes certain charges related to the China based Multek operations that was divested in the second quarter of fiscal year 2019.

[0000866374-20-000009:notes:362]
During fiscal year 2018, the Company incurred charges in connection with certain legal matters, for loss contingencies where it believed that losses were probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility, as well as certain assets impairments during fiscal year 2018.

[0000866374-20-000009:notes:363]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-20-000009:notes:364]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled in the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segments nor reported by segment to the Company's CODM.

[0000866374-20-000009:notes:365]
Property and equipment on a segment basis is not disclosed as it is not separately identified and is not internally reported by segment to the Company's CODM as described above. During fiscal year 2020, 2019 and 2018, depreciation expense included in the segments' measure of operating performance above is as follows. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0000866374-20-000009:notes:366]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Depreciation expense: |  |  |  |  |  |
| High Reliability Solutions | $ | 103,266 |  |  | $ | 96,854 |  |  | $ | 97,114 |  |
| Industrial & Emerging Industries | 85,273 |  |  | 92,606 |  |  | 75,366 |  |
| Communication & Enterprise Compute | 89,286 |  |  | 103,162 |  |  | 118,150 |  |
| Consumer Technologies Group | 112,813 |  |  | 104,298 |  |  | 110,276 |  |
| Corporate and Other | 31,769 |  |  | 36,493 |  |  | 33,526 |  |
| Total depreciation expense | $ | 422,407 |  |  | $ | 433,413 |  |  | $ | 434,432 |  |

[0000866374-20-000009:notes:367]
Geographic information of net sales is as follows:

[0000866374-20-000009:notes:368]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 9,362,089 |  |  | 39 | % |  | $ | 11,469,617 |  |  | 44 | % |  | $ | 11,210,793 |  |  | 44 | % |
| Americas | 10,065,568 |  |  | 42 | % |  | 9,893,072 |  |  | 38 | % |  | 9,880,626 |  |  | 39 | % |
| Europe | 4,782,213 |  |  | 19 | % |  | 4,847,822 |  |  | 18 | % |  | 4,349,712 |  |  | 17 | % |
|  | $ | 24,209,870 |  |  |  |  | $ | 26,210,511 |  |  |  |  | $ | 25,441,131 |  |  |  |

[0000866374-20-000009:notes:369]
Revenues are attributable to the country in which the product is manufactured, or service is provided.

[0000866374-20-000009:notes:370]
During fiscal years 2020, 2019 and 2018, net sales generated from Singapore, the principal country of domicile, were approximately $574.6 million, $642.7 million and $686.9 million, respectively.

[0000866374-20-000009:notes:371]
The following table summarizes the countries that accounted for more than 10% of net sales in fiscal year 2020, 2019, and 2018:

[0000866374-20-000009:notes:372]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 5,664,742 |  |  | 23 | % |  | $ | 6,648,549 |  |  | 25 | % |  | $ | 7,449,591 |  |  | 29 | % |
| Mexico | 4,449,266 |  |  | 18 | % |  | 4,538,720 |  |  | 17 | % |  | 4,361,814 |  |  | 17 | % |
| U.S. | 3,719,095 |  |  | 15 | % |  | 3,106,222 |  |  | 12 | % |  | 2,860,242 |  |  | 11 | % |
| Brazil | 1,831,214 |  |  | 8 | % |  | 2,181,025 |  |  | 8 | % |  | 2,578,466 |  |  | 10 | % |

[0000866374-20-000009:notes:373]
No other country accounted for more than 10% of net sales for the fiscal periods presented in the table above.

[0000866374-20-000009:notes:374]
Geographic information of property and equipment, net is as follows:

[0000866374-20-000009:notes:375]
|  | As of March 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Americas | $ | 1,037,018 |  |  | 47 | % |  | $ | 1,003,708 |  |  | 43 | % |
| Asia | 737,551 |  |  | 33 | % |  | 903,288 |  |  | 39 | % |
| Europe | 441,422 |  |  | 20 | % |  | 429,217 |  |  | 18 | % |
|  | $ | 2,215,991 |  |  |  |  | $ | 2,336,213 |  |  |  |

[0000866374-20-000009:notes:376]
As of March 31, 2020 and 2019, property and equipment, net held in Singapore were approximately $8.6 million and $12.3 million, respectively.

[0000866374-20-000009:notes:377]
The following table summarizes the countries that accounted for more than 10% of property and equipment, net in fiscal year 2020 and 2019:

[0000866374-20-000009:notes:378]
|  | Fiscal Year Ended March 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 555,077 |  |  | 25 | % |  | $ | 537,396 |  |  | 23 | % |
| China | 396,179 |  |  | 18 | % |  | 523,124 |  |  | 22 | % |
| U.S. | 377,800 |  |  | 17 | % |  | 361,098 |  |  | 15 | % |

[0000866374-20-000009:notes:379]
No other country accounted for more than 10% of property and equipment, net for the fiscal periods presented in the table above.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-20-000009:notes:380]
During fiscal year 2020, 2019 and 2018, depreciation expense included in the segments' measure of operating performance above is as follows. Historical information has been recast to reflect realignment of customers and/or products between segments:


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000866374-20-000009:notes:381]
QUARTERLY FINANCIAL DATA (UNAUDITED)
The Company's third fiscal quarter ends on December 31, and the fourth fiscal quarter and fiscal year ends on March 31 of each year. The first fiscal quarters of 2020 and 2019 ended on June 28, 2019 and June 29, 2018, respectively, and the second fiscal quarters of 2020 and 2019, ended on September 27, 2019 and September 28, 2018, respectively.

[0000866374-20-000009:notes:382]
The following table contains unaudited quarterly financial data for fiscal years 2020 and 2019. For fiscal year 2019, the Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings.

[0000866374-20-000009:notes:383]
|  | Fiscal Year Ended March 31, 2020 |  | Fiscal Year Ended March 31, 2019 |
|  | First |  | Second |  | Third |  | Fourth |  | First |  | Second |  | Third |  | Fourth |
|  | (In thousands, except per share amounts) |
| Net sales | $ | 6,175,939 |  |  | $ | 6,088,054 |  |  | $ | 6,461,387 |  |  | $ | 5,484,490 |  |  | $ | 6,398,956 |  |  | $ | 6,662,604 |  |  | $ | 6,922,827 |  |  | $ | 6,226,124 |  |
| Gross profit (1) | 352,759 |  |  | 189,093 |  |  | 430,477 |  |  | 365,627 |  |  | 377,854 |  |  | 402,301 |  |  | 357,325 |  |  | 380,295 |  |
| Net income (loss) (2) | 44,872 |  |  | (116,940 | ) |  | 111,388 |  |  | 48,259 |  |  | 116,035 |  |  | 86,885 |  |  | (45,169 | ) |  | (64,352 | ) |
| Earnings (loss) per share (3): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.09 |  |  | $ | (0.23 | ) |  | $ | 0.22 |  |  | $ | 0.10 |  |  | $ | 0.22 |  |  | $ | 0.16 |  |  | $ | (0.09 | ) |  | $ | (0.12 | ) |
| Diluted | $ | 0.09 |  |  | $ | (0.23 | ) |  | $ | 0.22 |  |  | $ | 0.10 |  |  | $ | 0.22 |  |  | $ | 0.16 |  |  | $ | (0.09 | ) |  | $ | (0.12 | ) |

[0000866374-20-000009:notes:384]
| (1) | The Company recorded a total of $128.3 million of restructuring charges during the second quarter of fiscal year 2020. The Company classified approximately $114.0 million of these charges as a component of cost of sales and $14.4 million as a component of selling, general and administrative expenses. Refer to note 15 for additional information on these charges. The Company recorded a total of $56.2 million of restructuring charges during the first quarter of fiscal year 2020. The Company classified approximately $47.4 million of these charges as a component of cost of sales and $8.8 million as a component of selling, general and administrative expenses. The Company recorded a total of $65.8 million of restructuring charges during the third quarter of fiscal year 2019. The Company classified $60.4 million of these charges as a component of cost of sales and approximately $5.4 million as a component of selling, general and administrative expenses. |

[0000866374-20-000009:notes:385]
| (2) | During the fourth quarter of fiscal year 2020, and in connection with the Company’s ongoing assessment of its investment portfolio strategy, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $74.8 million total impairment charge. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for additional information on investment impairment. Net income for the fourth quarter of fiscal year 2019 was primarily affected by an $84 million charge for the impairment of the Company's investment in Elementum. Net income for the third quarter of fiscal year 2019 was primarily affected by a $70 million charge for the impairment of the Company's investment in an unrelated third-party company. Net income for the first quarter of fiscal year 2019 was affected by a $91.8 million gain on the deconsolidation of Bright Machines. |

[0000866374-20-000009:notes:386]
Earnings per share are computed independently for each quarter presented and basic shares are used in the quarters with losses; therefore, the sum of the quarterly earnings per share may not equal the total earnings per share amounts for the fiscal year.
