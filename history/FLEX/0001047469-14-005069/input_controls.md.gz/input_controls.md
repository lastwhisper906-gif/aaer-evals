# FLEX 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001047469-14-005069:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001047469-14-005069:item_9a:2]
(a)    Evaluation of Disclosure Controls and Procedures

[0001047469-14-005069:item_9a:3]
Under the supervision and with the participation of the Company's management, including the Company's Chief Executive Officer and Chief
Financial Officer, the Company has evaluated the effectiveness of the Company's disclosure controls and procedures (as defined in Rule 13a-15(e) under the Exchange Act) as of March 31,
2014. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer concluded that, as of March 31, 2014, such disclosure controls and procedures were effective in
ensuring that information required to be disclosed by the Company in reports that it files or submits under the Securities Exchange Act of 1934, as amended, is (i) recorded, processed,
summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms and (ii) accumulated and communicated to our management, including our
principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0001047469-14-005069:item_9a:4]
(b)    Management's Annual Report on Internal Control over Financial Reporting

[0001047469-14-005069:item_9a:5]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined
in Rule 13a-15(f) under the Securities Exchange Act of 1934, as amended. As of March 31, 2014, under the supervision and with the participation of management, including the Company's
Chief Executive Officer and Chief Financial Officer, an evaluation was conducted of the effectiveness of the Company's internal control over financial reporting based on the framework in  Internal Control—Integrated
Framework (1992) issued by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO"). Based
on that evaluation, management concluded that the Company's internal control over financial reporting was effective as of March 31, 2014.

[0001047469-14-005069:item_9a:6]
Because
of its inherent limitations, a system of internal control over financial reporting can provide only reasonable assurance and may not prevent or detect misstatements or prevent or
detect instances of fraud. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of simple error or mistake.
Additionally, controls may be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the control. The projections of any evaluation of
effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may
deteriorate.

[0001047469-14-005069:item_9a:7]
Management's
annual assessment of the effectiveness of our internal control over financial reporting as of March 31, 2014 excluded the internal control over financial reporting of
certain manufacturing operations acquired from Google's Motorola Mobility LLC and Riwisa AG, which constitutes, in aggregate, 10.9% of total assets and 11.6% of net sales of the consolidated
financial statements as of and for the fiscal year ended March 31, 2014.

[0001047469-14-005069:item_9a:8]
(c)    Attestation Report of the Registered Public Accounting Firm

[0001047469-14-005069:item_9a:9]
The effectiveness of the Company's internal control over financial reporting as of March 31, 2014 has been audited by
Deloitte & Touche LLP, an independent registered public accounting firm, as stated in their report which appears in this Item under the heading "Report of Independent Registered Public
Accounting Firm."

[0001047469-14-005069:item_9a:10]
122

[0001047469-14-005069:item_9a:11]
(d)    Changes in Internal Control Over Financial Reporting

[0001047469-14-005069:item_9a:12]
On April 16, 2013, we completed the acquisition of certain manufacturing operations from Google's Motorola Mobility LLC,
and on November 4, 2013, we completed the acquisition of Riwisa AG, at which time each respectively became a subsidiary of the Company. See note 17 to the consolidated financial
statements for additional information. Other than these business acquisitions, there were no changes in the Company's internal controls over financial reporting that occurred during the year ended
March 31, 2014 that have materially affected, or are reasonably likely to materially affect, its internal controls over financial reporting.

[0001047469-14-005069:item_9a:13]
123

[0001047469-14-005069:item_9a:14]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001047469-14-005069:item_9a:15]
To
the Board of Directors and Stockholders of

[0001047469-14-005069:item_9a:16]
Flextronics International Ltd.

[0001047469-14-005069:item_9a:17]
Singapore

[0001047469-14-005069:item_9a:18]
We
have audited the internal control over financial reporting of Flextronics International Ltd. and subsidiaries (the "Company") as of March 31, 2014, based on criteria
established in Internal Control—Integrated Framework (1992) issued by the Committee of Sponsoring Organizations of the Treadway Commission.
As described in Management's Annual Report on Internal Control over Financial Reporting, management excluded from its assessment the internal control over financial reporting at Google's Motorola
Mobility LLC, which was acquired on April 16, 2013 and Riwisa AG, which was acquired on November 4, 2013, whose financial statements in aggregate constitute 10.9% of total assets
and 11.6% of net sales of the consolidated financial statement amounts as of and for the year ended March 31, 2014.
Accordingly, our audit did not include the internal control over financial reporting at Google's Motorola Mobility LLC and Riwisa AG. The Company's management is responsible for maintaining
effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management's Annual Report on
Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company's internal control over financial reporting based on our audit.

[0001047469-14-005069:item_9a:19]
We
conducted our audit in accordance with the standards of the Public Company Accounting Oversight Board (United States). Those standards require that we plan and perform the audit to
obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control
over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and
performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001047469-14-005069:item_9a:20]
A
company's internal control over financial reporting is a process designed by, or under the supervision of, the company's principal executive and principal financial officers, or
persons performing similar functions, and effected by the company's board of directors, management, and other personnel to provide reasonable assurance regarding the reliability of financial reporting
and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those
policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company;
(2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that
receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding
prevention or timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

[0001047469-14-005069:item_9a:21]
Because
of the inherent limitations of internal control over financial reporting, including the possibility of collusion or improper management override of controls, material
misstatements due to error or fraud may not be prevented or detected on a timely basis. Also, projections of any evaluation of the effectiveness of the internal control over financial reporting to
future periods are subject to the risk that the controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001047469-14-005069:item_9a:22]
In
our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of March 31, 2014, based on the criteria established in  Internal Control—Integrated Framework
(1992) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001047469-14-005069:item_9a:23]
We
have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States), the consolidated financial statements as of and for the year
ended March 31, 2014 of the Company and our report dated May 20, 2014 expressed an unqualified opinion on those financial statements.

[0001047469-14-005069:item_9a:24]
/s/ DELOITTE & TOUCHE LLP

[0001047469-14-005069:item_9a:25]
San
Jose, California

[0001047469-14-005069:item_9a:26]
May 20, 2014

[0001047469-14-005069:item_9a:27]
124
