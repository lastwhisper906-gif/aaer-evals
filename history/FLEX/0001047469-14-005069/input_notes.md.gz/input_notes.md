# FLEX notes — 0001047469-14-005069


## flex:BasisOfPresentationAndPrinciplesOfConsolidationPolicyTextBlock

[0001047469-14-005069:notes:1]
Basis of Presentation and Principles of Consolidation

[0001047469-14-005069:notes:2]
The Company's third fiscal quarter ends on December 31, and the fourth fiscal quarter and year ends on March 31 of each year. The first fiscal quarter ended on June 28, 2013 and June 29, 2012, respectively, and the second fiscal quarter ended on September 27, 2013 and September 28, 2012, respectively. Amounts included in the consolidated financial statements are expressed in U.S. dollars unless otherwise designated.

[0001047469-14-005069:notes:3]
The accompanying consolidated financial statements include the accounts of Flextronics and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates all majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a non-controlling interest for the ownership of the non-controlling owners. As of March 31, 2014, the non-controlling interest has been included on the consolidated balance sheets as a component of total shareholders' equity. The associated non-controlling owners' interest in the income or losses of these companies has not been material to the Company's results of operations for any of the periods presented, and has been classified as a component of interest and other, net, in the consolidated statements of operations.

[0001047469-14-005069:notes:4]
During fiscal year 2013, the Company finalized the sale of two of its non-core businesses. In accordance with the accounting guidance, these non-core businesses represent separate asset groups and the divestitures qualify as discontinued operations, and accordingly, the Company has reported the results of operations and financial position of these businesses in discontinued operations within the consolidated statements of operation and consolidated balance sheets for all periods presented as applicable.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001047469-14-005069:notes:5]
Translation of Foreign Currencies

[0001047469-14-005069:notes:6]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive loss, a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for any of the periods presented, and have been classified as a component of interest and other, net in the consolidated statements of operations.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001047469-14-005069:notes:7]
Revenue Recognition

[0001047469-14-005069:notes:8]
The Company recognizes manufacturing revenue when it ships goods or the goods are received by its customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then the Company recognizes the related revenues at the time when such requirements are completed and the obligations are fulfilled. Some of the Company's customer contracts allow the recovery of certain costs related to manufacturing services that are over and above the prices charged for the related products. The Company determines the amount of costs that are recoverable based on historical experiences and agreements with those customers. Also, certain customer contracts may contain certain commitments and obligations that may result in additional expenses or decrease in revenue. The Company accrues for these commitments and obligations based on facts and circumstances and contractual terms. The Company also makes provisions for estimated sales returns and other adjustments at the time revenue is recognized based upon contractual terms and an analysis of historical returns. Provisions for sales returns and other adjustments were not material to the consolidated financial statements for any of the periods presented.

[0001047469-14-005069:notes:9]
The Company provides a comprehensive suite of services for our customers that range from advanced product design to manufacturing and logistics to after-sales services. The Company recognizes service revenue when the services have been performed, and the related costs are expensed as incurred. Sales for services were less than 10% of the Company's total sales for all periods presented, and accordingly, are included in net sales in the consolidated statements of operations. The Company recognized research and development costs related to its ODM personal computing business of $78.9 million for the fiscal years ended March 31, 2012. Research and development activities related to ODM personal computing had ceased by the end of fiscal year 2012.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001047469-14-005069:notes:10]
Cash and Cash Equivalents

[0001047469-14-005069:notes:11]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0001047469-14-005069:notes:12]
Cash and cash equivalents consisted of the following:

[0001047469-14-005069:notes:13]
|  |  | As of March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Cash and bank balances |  | $ | 1,040,800 |  | $ | 1,089,697 |  |
| Money market funds and time deposits |  |  | 552,928 |  |  | 497,390 |  |
|  |  | $ | 1,593,728 |  | $ | 1,587,087 |  |


## us-gaap:InventoryPolicyTextBlock

[0001047469-14-005069:notes:14]
Inventories

[0001047469-14-005069:notes:15]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or market value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or market write-downs, were as follows:

[0001047469-14-005069:notes:16]
|  |  | As of March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Raw materials |  | $ | 2,349,278 |  | $ | 1,683,098 |  |
| Work-in-progress |  |  | 608,284 |  |  | 421,706 |  |
| Finished goods |  |  | 641,446 |  |  | 617,696 |  |
|  |  | $ | 3,599,008 |  | $ | 2,722,500 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001047469-14-005069:notes:17]
Property and Equipment, Net

[0001047469-14-005069:notes:18]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization is recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are amortized over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment was comprised of the following:

[0001047469-14-005069:notes:19]
|  |  |  |  | As of March 31, |  |
|  |  | Depreciable Life (In Years) |  |
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | (In thousands) |  |
| Machinery and equipment |  | 3 - 10 |  | $ | 2,929,449 |  | $ | 2,668,996 |  |
| Buildings |  | 30 |  |  | 1,069,376 |  |  | 1,032,595 |  |
| Leasehold improvements |  | up to 30 |  |  | 470,960 |  |  | 384,519 |  |
| Furniture, fixtures, computer equipment and software |  | 3 - 7 |  |  | 427,038 |  |  | 399,368 |  |
| Land |  | — |  |  | 127,567 |  |  | 127,241 |  |
| Construction-in-progress |  | — |  |  | 88,687 |  |  | 139,032 |  |
|  |  |  |  |  | 5,113,077 |  |  | 4,751,751 |  |
| Accumulated depreciation and amortization |  |  |  |  | (2,824,421 | ) |  | (2,577,163 | ) |
| Property and equipment, net |  |  |  | $ | 2,288,656 |  | $ | 2,174,588 |  |

[0001047469-14-005069:notes:20]
Total depreciation expense associated with property and equipment amounted to approximately $424.8 million, $412.3 million and $407.5 million in fiscal years 2014, 2013 and 2012, respectively. Property and equipment excludes assets no longer in use and held for sale as a result of restructuring activities, as discussed in note 11 to the consolidated financial statements.

[0001047469-14-005069:notes:21]
The Company reviews property and equipment for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is measured by comparing its carrying amount to the projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.


## us-gaap:IncomeTaxPolicyTextBlock

[0001047469-14-005069:notes:22]
Deferred Income Taxes

[0001047469-14-005069:notes:23]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001047469-14-005069:notes:24]
Goodwill and Other Intangible Assets

[0001047469-14-005069:notes:25]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. The Company has one reporting unit: Electronics Manufacturing Services ("EMS"). If the recorded value of the assets, including goodwill, and liabilities ("net book value") of the reporting unit exceeds its fair value, an impairment loss may be required to be recognized. Further, to the extent the net book value of the Company as a whole is greater than its fair value in the aggregate, all, or a significant portion of its goodwill may be considered impaired. The Company performed its goodwill impairment assessment on January 31, 2014 and did not elect to perform the qualitative "Step Zero" assessment. Instead the Company performed a quantitative assessment of its goodwill at the afore-mentioned date. Based on this assessment the Company determined that no impairment existed as of the date of the impairment test. The fair value of the reporting unit exceeded the carrying value.

[0001047469-14-005069:notes:26]
The following table summarizes the activity in the Company's goodwill account during fiscal years 2014 and 2013 (in thousands):

[0001047469-14-005069:notes:27]
|  |  | As of March 31, |  |
|  |  | 2014 |  | 2013 |  |
| Balance, beginning of the year, net of accumulated impairment of $5,949,977 |  | $ | 262,005 |  | $ | 101,670 |  |
| Additions(1) |  |  | 26,270 |  |  | 160,609 |  |
| Purchase accounting adjustments(2) |  |  | 4,034 |  |  | — |  |
| Foreign currency translation adjustments |  |  | 449 |  |  | (274 | ) |
| Balance, end of period, net of accumulated impairment of $5,949,977 |  | $ | 292,758 |  | $ | 262,005 |  |

[0001047469-14-005069:notes:28]
(1)

[0001047469-14-005069:notes:29]
The goodwill generated from the Company's business combinations completed during the years 2014 and 2013 are primarily related to value placed on the employee workforce, service offerings and capabilities and expected synergies. The goodwill is not deductible for income tax purposes. Refer to the discussion of the Company's business acquisitions in note 17 to the consolidated financial statements.

[0001047469-14-005069:notes:30]
(2)

[0001047469-14-005069:notes:31]
Includes adjustments based on management's estimates resulting from their review and finalization of the valuation of assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition. These adjustments were not individually, nor in the aggregate, significant to the Company.

[0001047469-14-005069:notes:32]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2014 and concluded that such amounts continued to be recoverable.

[0001047469-14-005069:notes:33]
Intangible assets are comprised of customer-related intangible assets, which primarily include contractual agreements and customer relationships; and licenses and other intangible assets, which is primarily comprised of licenses and also includes patents and trademarks, and developed technologies. Generally customer-related intangible assets are amortized on an accelerated method based on expected cash flows, primarily over a period of up to eight years. Licenses and other intangible assets are generally amortized on a straight line basis over a period of up to seven years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is principally determined based on management's estimates of cash flow and recoverability. The components of acquired intangible assets are as follows:

[0001047469-14-005069:notes:34]
|  |  | As of March 31, 2014 |  | As of March 31, 2013 |  |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  |
|  |  | (In thousands) |  |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles |  | $ | 204,369 |  | $ | (140,713 | ) | $ | 63,656 |  | $ | 294,310 |  | $ | (224,517 | ) | $ | 69,793 |  |
| Licenses and other intangibles |  |  | 32,564 |  |  | (11,760 | ) |  | 20,804 |  |  | 21,040 |  |  | (9,286 | ) |  | 11,754 |  |
| Total |  | $ | 236,933 |  | $ | (152,473 | ) | $ | 84,460 |  | $ | 315,350 |  | $ | (233,803 | ) | $ | 81,547 |  |

[0001047469-14-005069:notes:35]
The gross carrying amounts of intangible assets are removed when the recorded amounts have been fully amortized. During fiscal year 2014, the gross carrying amounts of such intangible assets fully amortized and removed totaled $117.9 million. During the year ended March 31, 2014, the Company's customer-related intangible assets, and licenses and other intangible assets increased by $15.8 million and $6.9 million respectively, primarily due to the acquisition of Riwisa AG as further discussed in note 17 to the consolidated financial statements. Total intangible asset amortization expense recognized in continuing operations during fiscal years 2014, 2013 and 2012 was $28.9 million, $29.5 million and $49.6 million, respectively. As of March 31, 2014, the weighted-average remaining useful lives of the Company's intangible assets were approximately 2.7 years and 4.1 years for customer-related intangibles, and licenses and other intangible assets, respectively. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0001047469-14-005069:notes:36]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2015 |  | $ | 26,216 |  |
| 2016 |  |  | 21,385 |  |
| 2017 |  |  | 13,960 |  |
| 2018 |  |  | 8,748 |  |
| 2019 |  |  | 4,709 |  |
| Thereafter |  |  | 9,442 |  |
| Total amortization expense |  | $ | 84,460 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001047469-14-005069:notes:37]
Derivative Instruments and Hedging Activities

[0001047469-14-005069:notes:38]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in the spot currency rates and the change in the present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency LIBOR rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Additional information is included in note 8 to the consolidated financial statements.


## us-gaap:OtherAssetsDisclosureTextBlock

[0001047469-14-005069:notes:39]
Other Current Assets

[0001047469-14-005069:notes:40]
Other current assets includes approximately $470.9 million and $412.4 million as of March 31, 2014 and 2013, respectively for the deferred purchase price receivable from our Global and North American Asset-Backed Securitization programs. See note 10 to the consolidated financial statements for additional information regarding the Company's participation in its trade receivables securitization programs. Also included in other current assets as of March 31, 2014 and 2013 were certain assets purchased on behalf of a customer and financed by a third party banking institution of $267.5 million and $251.3 million, respectively, as further described in note 17 to the consolidated financial statements.


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001047469-14-005069:notes:41]
Other Current Liabilities

[0001047469-14-005069:notes:42]
Other current liabilities include customer working capital advances of $754.7 million and $214.1 million, and deferred revenue of $296.3 million and $227.0 million as of March 31, 2014 and 2013, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Also included in other current liabilities as of March 31, 2014 and 2013 were amounts financed by a third party banking institution for the purchase of assets on behalf of a customer of $286.5 million and $272.8 million, respectively, as further described in note 17 to the consolidated financial statements.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001047469-14-005069:notes:43]
Restructuring Charges

[0001047469-14-005069:notes:44]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing and administrative facilities. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0001047469-14-005069:notes:45]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed exit plans. See note 14 to the consolidated financial statements for additional information regarding restructuring charges.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001047469-14-005069:notes:46]
Recent Accounting Pronouncements

[0001047469-14-005069:notes:47]
In April 2014, the Financial Accounting Standards Board ("FASB") issued guidance which requires an entity to report a disposal of a component of an entity in discontinued operations if the disposal represents a strategic shift that has a major effect on an entity's operations and financial results when the component of an entity meets certain criteria to be classified as held for sale when the component of an entity is disposed of by a sale or disposed of other than by a sale. Further, additional disclosures about discontinued operations should include the following for the periods in which the results of operations of the discontinued operations are presented in the statement of operations: the major classes of line items constituting pretax profit or loss of discontinued operations; total operating and investing cash flows of discontinued operations; depreciation, amortization, capital expenditures, and significant operating and investing noncash items of discontinued operations; pretax profit or loss attributable to the parent if a discontinued operation includes a non-controlling interest; a reconciliation of major classes of assets, liabilities of the discontinued operation classified as held for sale; and a reconciliation of major classes of line items constituting the pretax profit or loss of the discontinued operation. This guidance is effective for the Company beginning in fiscal year 2016, and will impact the Company's assessment of any future discontinued operations.

[0001047469-14-005069:notes:48]
In July 2013, the FASB issued guidance which requires an entity to present unrecognized tax benefits in the financial statements as a reduction to deferred tax assets for net operating loss carryforwards, similar tax losses, or tax credit carryforwards. To the extent these are not available at the reporting date, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This disclosure is effective for the Company beginning in fiscal year 2015, and is not expected to have a significant impact to the Company's consolidated financial statements.

[0001047469-14-005069:notes:49]
In February 2013, the FASB issued guidance which requires an entity to measure obligations resulting from joint and several liability arrangements, including the amount the reporting entity agreed to pay on the basis of its arrangement among its co-obligors and any additional amount the reporting entity expects to pay on behalf of its co-obligors, as well as discussion of the nature of such obligations. This disclosure is effective for the Company beginning in fiscal year 2015, and is not expected to have a significant impact to the Company's consolidated financial statements.


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001047469-14-005069:notes:50]
|  |  | Balance at Beginning of Year |  | Charged to Costs and Expenses |  | Deductions/ Write-Offs |  | Balance at End of Year |  |
|  |  | (In thousands) |  |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Year ended March 31, 2012(1)(2) |  | $ | 13,222 |  | $ | 30,122 |  | $ | (4,439 | ) | $ | 38,905 |  |
| Year ended March 31, 2013(2)(3) |  | $ | 38,905 |  | $ | 6,643 |  | $ | (34,671 | ) | $ | 10,877 |  |
| Year ended March 31, 2014 |  | $ | 10,877 |  | $ | 2,029 |  | $ | (7,377 | ) | $ | 5,529 |  |

[0001047469-14-005069:notes:51]
Deductions/write-offs amount for fiscal year 2012 includes $3.9 million, which was previously reserved and the underlying accounts receivable balance was reclassified to non-current assets in fiscal year 2012, and carried net of its specific reserve.

[0001047469-14-005069:notes:52]
Included in amounts charged to costs and expenses in fiscal year 2012 is $28.0 million related to a distressed customer, which was written off in fiscal year 2013 and $0.2 million, related to discontinued operations.

[0001047469-14-005069:notes:53]
(3)

[0001047469-14-005069:notes:54]
Deductions/write-offs amount for fiscal year 2013 includes $5.8 million, which was previously reserved and the underlying accounts receivable balance was reclassified to non-current assets in fiscal year 2013 and is carried net of its specific reserve.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001047469-14-005069:notes:55]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings from continuing and discontinued operations per share: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 365,594 |  | $ | 302,502 |  | $ | 520,770 |  |
| Loss from discontinued operations |  | $ | — |  | $ | (25,451 | ) | $ | (32,005 | ) |
| Net income |  | $ | 365,594 |  | $ | 277,051 |  | $ | 488,765 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  |  | 610,497 |  |  | 662,874 |  |  | 716,247 |  |
| Basic earnings from continuing operations per share |  | $ | 0.60 |  | $ | 0.46 |  | $ | 0.73 |  |
| Basic loss from discontinued operations per share |  | $ | — |  | $ | (0.04 | ) | $ | (0.04 | ) |
| Basic earnings per share |  | $ | 0.60 |  | $ | 0.42 |  | $ | 0.68 |  |
| Diluted earnings from continuing and discontinued operations per share: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 365,594 |  | $ | 302,502 |  | $ | 520,770 |  |
| Loss from discontinued operations |  | $ | — |  | $ | (25,451 | ) | $ | (32,005 | ) |
| Net income |  | $ | 365,594 |  | $ | 277,051 |  | $ | 488,765 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  |  | 610,497 |  |  | 662,874 |  |  | 716,247 |  |
| Weighted-average ordinary share equivalents from stock options and awards(1) |  |  | 12,982 |  |  | 12,159 |  |  | 11,560 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding |  |  | 623,479 |  |  | 675,033 |  |  | 727,807 |  |
| Diluted earnings from continuing operations per share |  | $ | 0.59 |  | $ | 0.45 |  | $ | 0.72 |  |
| Diluted loss from discontinued operations per share |  | $ | — |  | $ | (0.04 | ) | $ | (0.04 | ) |
| Diluted earnings per share |  | $ | 0.59 |  | $ | 0.41 |  | $ | 0.67 |  |

[0001047469-14-005069:notes:56]
Options to purchase ordinary shares of 17.1 million, 20.6 million and 24.2 million during fiscal years 2014, 2013 and 2012, respectively, and share bonus awards of 0.3 million and 1.2 million during fiscal years 2013 and 2012, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. There were no anti-dilutive share bonus awards in fiscal year 2014.


## us-gaap:ScheduleOfCashFlowSupplementalDisclosuresTableTextBlock

[0001047469-14-005069:notes:57]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | (In thousands) |  |
| Net cash paid for: |  |  |  |  |  |  |  |  |  |  |
| Interest |  | $ | 86,406 |  | $ | 66,071 |  | $ | 42,067 |  |
| Income taxes |  | $ | 87,561 |  | $ | 52,306 |  | $ | 66,013 |  |
| Non-cash investing activity: |  |  |  |  |  |  |  |  |  |  |
| Accounts payable for fixed assets purchases |  | $ | 42,902 |  | $ | 89,718 |  | $ | 63,671 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001047469-14-005069:notes:58]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | (In thousands) |  |
| Cost of sales |  | $ | 6,540 |  | $ | 5,163 |  | $ | 7,446 |  |
| Selling, general and administrative expenses |  |  | 33,899 |  |  | 29,366 |  |  | 41,008 |  |
| Total share-based compensation expense |  | $ | 40,439 |  | $ | 34,529 |  | $ | 48,454 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001047469-14-005069:notes:59]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2013 |  | 2012 |  |
| Expected term |  |  | 4.1 years |  |  | 4.1 years |  |
| Expected volatility |  |  | 46.9 | % |  | 46.9 | % |
| Expected dividends |  |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate |  |  | 0.9 | % |  | 1.1 | % |
| Weighted-average fair value |  | $ | 2.48 |  | $ | 2.57 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001047469-14-005069:notes:60]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | Options |  | Price |  | Options |  | Price |  | Options |  | Price |  |
| Outstanding, beginning of fiscal year |  |  | 34,405,564 |  | $ | 8.29 |  |  | 43,933,660 |  | $ | 7.78 |  |  | 53,942,458 |  | $ | 7.61 |  |
| Granted |  |  | — |  |  | — |  |  | 19,000 |  |  | 6.57 |  |  | 599,800 |  |  | 6.80 |  |
| Exercised |  |  | (6,572,383 | ) |  | 4.28 |  |  | (5,398,331 | ) |  | 4.12 |  |  | (5,879,405 | ) |  | 3.92 |  |
| Forfeited |  |  | (4,220,309 | ) |  | 12.93 |  |  | (4,148,765 | ) |  | 8.32 |  |  | (4,729,193 | ) |  | 10.45 |  |
| Outstanding, end of fiscal year |  |  | 23,612,872 |  | $ | 8.57 |  |  | 34,405,564 |  | $ | 8.29 |  |  | 43,933,660 |  | $ | 7.78 |  |
| Options exercisable, end of fiscal year |  |  | 23,373,101 |  | $ | 8.58 |  |  | 33,662,480 |  | $ | 8.31 |  |  | 37,021,049 |  | $ | 8.44 |  |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0001047469-14-005069:notes:61]
|  |  | Options Outstanding |  | Options Exercisable |  |
| Range of Exercise Prices |  | Number of Shares Outstanding |  | Weighted Average Remaining Contractual Life (In Years) |  | Weighted Average Exercise Price |  | Number of Shares Exercisable |  | Weighted Average Exercise Price |  |
| $1.94 - $2.26 |  |  | 5,420,232 |  |  | 1.77 |  | $ | 2.14 |  |  | 5,420,232 |  | $ | 2.14 |  |
| $3.39 - $5.75 |  |  | 3,604,664 |  |  | 2.36 |  |  | 5.54 |  |  | 3,583,720 |  |  | 5.54 |  |
| $5.87 - $7.07 |  |  | 233,183 |  |  | 3.28 |  |  | 6.65 |  |  | 198,130 |  |  | 6.67 |  |
| $7.08 - $10.59 |  |  | 5,506,846 |  |  | 1.56 |  |  | 10.18 |  |  | 5,323,072 |  |  | 10.26 |  |
| $10.67 - $11.41 |  |  | 1,104,933 |  |  | 2.13 |  |  | 11.23 |  |  | 1,104,933 |  |  | 11.23 |  |
| $11.53 - $13.98 |  |  | 6,619,666 |  |  | 0.88 |  |  | 12.23 |  |  | 6,619,666 |  |  | 12.23 |  |
| $14.34 - $23.02 |  |  | 1,123,348 |  |  | 0.13 |  |  | 17.59 |  |  | 1,123,348 |  |  | 17.59 |  |
| $1.94 - $23.02 |  |  | 23,612,872 |  |  | 1.52 |  | $ | 8.57 |  |  | 23,373,101 |  | $ | 8.58 |  |
| Options vested and expected to vest |  |  | 23,602,204 |  |  | 1.52 |  | $ | 8.59 |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0001047469-14-005069:notes:62]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |  |
| Unvested share bonus awards outstanding, beginning of fiscal year |  |  | 21,807,069 |  | $ | 6.80 |  |  | 15,965,268 |  | $ | 6.91 |  |  | 13,801,942 |  | $ | 8.04 |  |
| Granted |  |  | 8,978,941 |  |  | 8.07 |  |  | 9,582,867 |  |  | 6.74 |  |  | 9,213,456 |  |  | 6.78 |  |
| Vested |  |  | (5,481,153 | ) |  | 6.66 |  |  | (1,506,234 | ) |  | 7.51 |  |  | (2,555,165 | ) |  | 9.34 |  |
| Forfeited |  |  | (3,456,737 | ) |  | 7.07 |  |  | (2,234,832 | ) |  | 6.86 |  |  | (4,494,965 | ) |  | 8.60 |  |
| Unvested share bonus awards outstanding, end of fiscal year |  |  | 21,848,120 |  | $ | 7.32 |  |  | 21,807,069 |  | $ | 6.80 |  |  | 15,965,268 |  | $ | 6.91 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001047469-14-005069:notes:63]
|  |  | Fiscal Year Ended March 31, 2014 |  |
|  |  | Unrealized loss on derivative instruments and other |  | Foreign currency translation adjustments |  | Total |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | (18,857 | ) | $ | (58,624 | ) | $ | (77,481 | ) |
| Other comprehensive loss before reclassifications |  |  | (15,851 | ) |  | (34,683 | ) |  | (50,534 | ) |
| Net losses reclassified from accumulated other comprehensive loss |  |  | 1,859 |  |  | — |  |  | 1,859 |  |
| Net current-period other comprehensive loss |  |  | (13,992 | ) |  | (34,683 | ) |  | (48,675 | ) |
| Ending balance |  | $ | (32,849 | ) | $ | (93,307 | ) | $ | (126,156 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001047469-14-005069:notes:64]
|  |  | As of March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Term Loan, including current portion, due October 2014 |  | $ | — |  | $ | 170,340 |  |
| Term Loan, including current portion, due in installments through August 2018 |  |  | 600,000 |  |  | — |  |
| Term Loan, including current portion, due in installments through March 2019 |  |  | 500,000 |  |  | 517,500 |  |
| 4.625% Notes due February 2020 |  |  | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 |  |  | 500,000 |  |  | 500,000 |  |
| Asia Term Loans |  |  | — |  |  | 375,000 |  |
| Other |  |  | 2,595 |  |  | 4,787 |  |
|  |  |  | 2,102,595 |  |  | 2,067,627 |  |
| Current portion |  |  | (32,575 | ) |  | (416,654 | ) |
| Non-current portion |  | $ | 2,070,020 |  | $ | 1,650,973 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001047469-14-005069:notes:65]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2015 |  | $ | 32,575 |  |
| 2016 |  |  | 40,000 |  |
| 2017 |  |  | 52,500 |  |
| 2018 |  |  | 52,500 |  |
| 2019 |  |  | 922,500 |  |
| Thereafter |  |  | 1,002,520 |  |
| Total |  | $ | 2,102,595 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001047469-14-005069:notes:66]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |  |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |  |
|  |  | (In thousands) |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CNY |  |  | 3,521,000 |  |  | — |  | $ | 566,733 |  | $ | — |  |
| EUR |  |  | 7,832 |  |  | 45,485 |  |  | 10,767 |  |  | 62,231 |  |
| HUF |  |  | 11,459,000 |  |  | — |  |  | 50,699 |  |  | — |  |
| MXN |  |  | 1,726,500 |  |  | — |  |  | 131,898 |  |  | — |  |
| MYR |  |  | 279,180 |  |  | — |  |  | 84,857 |  |  | — |  |
| Other |  |  | N/A |  |  | N/A |  |  | 65,272 |  |  | 550 |  |
|  |  |  |  |  |  |  |  |  | 910,226 |  |  | 62,781 |  |
| Other Forward/Swap Contracts |  |  |  |  |  |  |  |  |  |  |  |  |  |
| BRL |  |  | 46,000 |  |  | 343,000 |  |  | 20,372 |  |  | 151,904 |  |
| CAD |  |  | 124,451 |  |  | 113,476 |  |  | 112,392 |  |  | 102,563 |  |
| CNY |  |  | 870,314 |  |  | 682,984 |  |  | 140,842 |  |  | 110,000 |  |
| EUR |  |  | 491,950 |  |  | 727,495 |  |  | 675,990 |  |  | 999,693 |  |
| GBP |  |  | 30,148 |  |  | 55,101 |  |  | 50,092 |  |  | 91,562 |  |
| HUF |  |  | 17,044,300 |  |  | 19,714,600 |  |  | 75,411 |  |  | 87,225 |  |
| JPY |  |  | 7,179,535 |  |  | 4,274,776 |  |  | 70,261 |  |  | 41,834 |  |
| MXN |  |  | 1,252,670 |  |  | 700,850 |  |  | 95,699 |  |  | 53,542 |  |
| MYR |  |  | 232,953 |  |  | 28,675 |  |  | 70,806 |  |  | 8,716 |  |
| SEK |  |  | 413,618 |  |  | 684,395 |  |  | 63,854 |  |  | 105,507 |  |
| Other |  |  | N/A |  |  | N/A |  |  | 204,306 |  |  | 154,186 |  |
|  |  |  |  |  |  |  |  |  | 1,580,025 |  |  | 1,906,732 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  |  | $ | 2,490,251 |  | $ | 1,969,513 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001047469-14-005069:notes:67]
|  |  | Fair Values of Derivative Instruments |  |
|  |  | Asset Derivatives |  | Liability Derivatives |  |
|  |  |  |  | Fair Value |  |  |  | Fair Value |  |
|  |  | Balance Sheet Location |  | March 31, 2014 |  | March 31, 2013 |  | Balance Sheet Location |  | March 31, 2014 |  | March 31, 2013 |  |
|  |  | (In thousands) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 3,464 |  | $ | 11,032 |  | Other current liabilities |  | $ | 10,457 |  | $ | 3,999 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 4,722 |  | $ | 16,531 |  | Other current liabilities |  | $ | 6,949 |  | $ | 11,291 |  |


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0001047469-14-005069:notes:68]
|  |  | As of March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 412,357 |  | $ | 514,895 |  |
| Transfers of receivables |  |  | 3,778,420 |  |  | 3,896,495 |  |
| Collections |  |  | (3,719,869 | ) |  | (3,999,033 | ) |
| Ending balance |  | $ | 470,908 |  | $ | 412,357 |  |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionContingentConsiderationTextBlock

[0001047469-14-005069:notes:69]
|  |  | As of March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 25,000 |  | $ | 1,151 |  |
| Additions to accrual |  |  | — |  |  | 25,000 |  |
| Payments |  |  | — |  |  | (1,151 | ) |
| Fair value adjustments |  |  | (13,700 | ) |  | — |  |
| Ending balance |  | $ | 11,300 |  | $ | 25,000 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0001047469-14-005069:notes:70]
|  |  | Fair Value Measurements as of March 31, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets held for sale |  | $ | — |  | $ | 43,504 |  | $ | — |  | $ | 43,504 |  |

[0001047469-14-005069:notes:71]
|  |  | Fair Value Measurements as of March 31, 2013 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets held for sale |  | $ | — |  | $ | 11,089 |  | $ | — |  | $ | 11,089 |  |
| Property and equipment |  |  | — |  |  | 25,331 |  |  | — |  |  | 25,331 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001047469-14-005069:notes:72]
|  |  | Fair Value Measurements as of March 31, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) |  | $ | — |  | $ | 552,928 |  | $ | — |  | $ | 552,928 |  |
| Deferred purchase price receivable (Note 10) |  |  | — |  |  | — |  |  | 470,908 |  |  | 470,908 |  |
| Foreign exchange forward contracts (Note 8) |  |  | — |  |  | 8,186 |  |  | — |  |  | 8,186 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities |  |  | 9,456 |  |  | 36,751 |  |  | — |  |  | 46,207 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) |  | $ | — |  | $ | (17,406 | ) | $ | — |  | $ | (17,406 | ) |
| Contingent consideration in connection with acquistions |  |  | — |  |  | — |  |  | (11,300 | ) |  | (11,300 | ) |

[0001047469-14-005069:notes:73]
|  |  | Fair Value Measurements as of March 31, 2013 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) |  | $ | — |  | $ | 497,390 |  | $ | — |  | $ | 497,390 |  |
| Deferred purchase price receivable (Note 10) |  |  | — |  |  | — |  |  | 412,357 |  |  | 412,357 |  |
| Foreign exchange forward contracts (Note 8) |  |  | — |  |  | 27,563 |  |  | — |  |  | 27,563 |  |
| Warrants to purchase common shares (Note 2) |  |  | — |  |  | — |  |  | 74,437 |  |  | 74,437 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities |  |  | 6,931 |  |  | 40,972 |  |  | — |  |  | 47,903 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) |  | $ | — |  | $ | (15,290 | ) | $ | — |  | $ | (15,290 | ) |
| Contingent consideration in connection with acquistions |  |  | — |  |  | — |  |  | (25,000 | ) |  | (25,000 | ) |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0001047469-14-005069:notes:74]
|  |  | As of March 31, 2014 |  | As of March 31, 2013 |  |  |
|  |  | Carrying Amount |  | Fair Value |  | Carrying Amount |  | Fair Value |  | Fair Value Hierarchy |
|  |  | (In thousands) |  | (In thousands) |  |  |
| Term Loan, including current portion, due October 2014 |  |  | — |  |  | — |  | $ | 170,340 |  | $ | 170,496 |  | Level 1 |
| Term Loan, including current portion, due in installments through August 2018 |  |  | 600,000 |  |  | 591,750 |  |  | — |  |  | — |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 |  |  | 500,000 |  |  | 497,190 |  |  | 517,500 |  |  | 518,794 |  | Level 1 |
| 4.625% Notes due February 2020 |  |  | 500,000 |  |  | 504,688 |  |  | 500,000 |  |  | 507,190 |  | Level 1 |
| 5.000% Notes due February 2023 |  |  | 500,000 |  |  | 517,650 |  |  | 500,000 |  |  | 500,000 |  | Level 1 |
| Asia Term Loans |  |  | — |  |  | — |  |  | 375,000 |  |  | 375,343 |  | Level 2 |
| Total |  | $ | 2,100,000 |  | $ | 2,111,278 |  | $ | 2,062,840 |  | $ | 2,071,823 |  |  |


## us-gaap:OperatingLeasesOfLesseeDisclosureTextBlock

[0001047469-14-005069:notes:75]
| Fiscal Year Ending March 31, |  | Operating Lease |  |
|  |  | (In thousands) |  |
| 2015 |  | $ | 137,274 |  |
| 2016 |  |  | 106,310 |  |
| 2017 |  |  | 84,636 |  |
| 2018 |  |  | 66,466 |  |
| 2019 |  |  | 54,422 |  |
| Thereafter |  |  | 106,013 |  |
| Total minimum lease payments |  | $ | 555,121 |  |


## us-gaap:ScheduleOfIncomeBeforeIncomeTaxDomesticAndForeignTableTextBlock

[0001047469-14-005069:notes:76]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | (In thousands) |  |
| Domestic |  | $ | 314,639 |  | $ | 170,071 |  | $ | 186,855 |  |
| Foreign |  |  | 85,815 |  |  | 158,744 |  |  | 387,875 |  |
| Total |  | $ | 400,454 |  | $ | 328,815 |  | $ | 574,730 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001047469-14-005069:notes:77]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | (In thousands) |  |
| Current: |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | (681 | ) | $ | 680 |  | $ | 303 |  |
| Foreign |  |  | 73,992 |  |  | 60,466 |  |  | 56,100 |  |
|  |  |  | 73,311 |  |  | 61,146 |  |  | 56,403 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |
| Domestic |  |  | 9 |  |  | (1,187 | ) |  | 386 |  |
| Foreign |  |  | (38,460 | ) |  | (33,646 | ) |  | (2,829 | ) |
|  |  |  | (38,451 | ) |  | (34,833 | ) |  | (2,443 | ) |
| Provision for income taxes |  | $ | 34,860 |  | $ | 26,313 |  | $ | 53,960 |  |


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001047469-14-005069:notes:78]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | (In thousands) |  |
| Income taxes based on domestic statutory rates |  | $ | 68,077 |  | $ | 55,899 |  | $ | 95,858 |  |
| Effect of tax rate differential |  |  | (68,654 | ) |  | (120,785 | ) |  | (177,540 | ) |
| Intangible amortization |  |  | 4,750 |  |  | 4,881 |  |  | 9,502 |  |
| Change in liability for uncertain tax positions |  |  | (2,178 | ) |  | 15,268 |  |  | 34,517 |  |
| Change in valuation allowance |  |  | 26,838 |  |  | 68,596 |  |  | 93,336 |  |
| Other |  |  | 6,027 |  |  | 2,454 |  |  | (1,713 | ) |
| Provision for income taxes |  | $ | 34,860 |  | $ | 26,313 |  | $ | 53,960 |  |


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001047469-14-005069:notes:79]
|  |  | As of March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |
| Fixed assets |  | $ | (76,524 | ) | $ | (36,542 | ) |
| Others |  |  | (54,900 | ) |  | (61,621 | ) |
| Total deferred tax liabilities |  |  | (131,424 | ) |  | (98,163 | ) |
| Deferred tax assets: |  |  |  |  |  |  |  |
| Fixed assets |  |  | 80,801 |  |  | 66,959 |  |
| Intangible assets |  |  | 62,951 |  |  | 112,327 |  |
| Deferred compensation |  |  | 10,263 |  |  | 10,341 |  |
| Inventory valuation |  |  | 9,255 |  |  | 12,514 |  |
| Provision for doubtful accounts |  |  | 3,558 |  |  | 13,807 |  |
| Net operating loss and other carryforwards |  |  | 2,613,095 |  |  | 2,600,895 |  |
| Others |  |  | 201,906 |  |  | 167,085 |  |
|  |  |  | 2,981,829 |  |  | 2,983,928 |  |
| Valuation allowances |  |  | (2,749,040 | ) |  | (2,825,579 | ) |
| Net deferred tax assets, net of valuation allowance |  |  | 232,789 |  |  | 158,349 |  |
| Net deferred tax asset |  | $ | 101,365 |  | $ | 60,186 |  |
| The net deferred tax asset is classified as follows: |  |  |  |  |  |  |  |
| Current asset (classified as other current assets) |  | $ | 13,522 |  | $ | 7,881 |  |
| Long-term asset (classified as other assets) |  |  | 219,267 |  |  | 150,468 |  |
| Long-term liability (classified as other liabilities) |  |  | (131,424 | ) |  | (98,163 | ) |
| Total |  | $ | 101,365 |  | $ | 60,186 |  |


## us-gaap:ScheduleOfUnrecognizedTaxBenefitsRollForwardTableTextBlock

[0001047469-14-005069:notes:80]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Balance, beginning of fiscal year |  | $ | 230,018 |  | $ | 166,432 |  |
| Additions based on tax position related to the current year |  |  | 16,823 |  |  | 22,185 |  |
| Additions for tax positions of prior years |  |  | 36,689 |  |  | 62,610 |  |
| Reductions for tax positions of prior years |  |  | (19,755 | ) |  | (15,001 | ) |
| Reductions related to lapse of applicable statute of limitations |  |  | (10,261 | ) |  | (5,444 | ) |
| Settlements |  |  | (8,964 | ) |  | (1,220 | ) |
| Other |  |  | (686 | ) |  | 456 |  |
| Balance, end of fiscal year |  | $ | 243,864 |  | $ | 230,018 |  |


## us-gaap:ScheduleOfRestructuringAndRelatedCostsTextBlock

[0001047469-14-005069:notes:81]
The components of the restructuring charges by geographic region incurred in fiscal 2014 are as follows:

[0001047469-14-005069:notes:82]
|  |  | First Quarter |  | Fourth Quarter |  | Total |  |
|  |  | (In thousands) |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |
| Severance |  | $ | 11,331 |  | $ | 11,290 |  | $ | 22,621 |  |
| Other exit costs |  |  | 2,248 |  |  | — |  |  | 2,248 |  |
| Total restructuring charges |  |  | 13,579 |  |  | 11,290 |  |  | 24,869 |  |
| Asia: |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 16,205 |  |  | 13,214 |  |  | 29,419 |  |
| Long-lived asset impairment |  |  | 1,900 |  |  | — |  |  | 1,900 |  |
| Other exit costs |  |  | 3,157 |  |  | — |  |  | 3,157 |  |
| Total restructuring charges |  |  | 21,262 |  |  | 13,214 |  |  | 34,476 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 4,631 |  |  | 10,047 |  |  | 14,678 |  |
| Other exit costs |  |  | 1,288 |  |  | — |  |  | 1,288 |  |
| Total restructuring charges |  |  | 5,919 |  |  | 10,047 |  |  | 15,966 |  |
| Total |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 32,167 |  |  | 34,551 |  |  | 66,718 |  |
| Long-lived asset impairment |  |  | 1,900 |  |  | — |  |  | 1,900 |  |
| Other exit costs |  |  | 6,693 |  |  | — |  |  | 6,693 |  |
| Total restructuring charges |  | $ | 40,760 |  | $ | 34,551 |  | $ | 75,311 |  |

[0001047469-14-005069:notes:83]
The components of the restructuring charges by geographic region incurred in fiscal 2013 are as follows:

[0001047469-14-005069:notes:84]
|  |  | Third Quarter |  | Fourth Quarter |  | Total |  |
|  |  | (In thousands) |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |
| Severance |  | $ | 863 |  | $ | 13,156 |  | $ | 14,019 |  |
| Long-lived asset impairment |  |  | — |  |  | 6,302 |  |  | 6,302 |  |
| Other exit costs |  |  | 322 |  |  | 6,533 |  |  | 6,855 |  |
| Total restructuring charges |  |  | 1,185 |  |  | 25,991 |  |  | 27,176 |  |
| Asia: |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 8,572 |  |  | 18,076 |  |  | 26,648 |  |
| Long-lived asset impairment |  |  | 46,250 |  |  | 5,268 |  |  | 51,518 |  |
| Other exit costs |  |  | 28,818 |  |  | 1,443 |  |  | 30,261 |  |
| Total restructuring charges |  |  | 83,640 |  |  | 24,787 |  |  | 108,427 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 6,142 |  |  | 63,301 |  |  | 69,443 |  |
| Long-lived asset impairment |  |  | 9,851 |  |  | 1,782 |  |  | 11,633 |  |
| Other exit costs |  |  | 1,873 |  |  | 8,882 |  |  | 10,755 |  |
| Total restructuring charges |  |  | 17,866 |  |  | 73,965 |  |  | 91,831 |  |
| Total |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 15,577 |  |  | 94,533 |  |  | 110,110 |  |
| Long-lived asset impairment |  |  | 56,101 |  |  | 13,352 |  |  | 69,453 |  |
| Other exit costs |  |  | 31,013 |  |  | 16,858 |  |  | 47,871 |  |
| Total restructuring charges |  | $ | 102,691 |  | $ | 124,743 |  | $ | 227,434 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0001047469-14-005069:notes:85]
|  |  | Severance |  | Long-Lived Asset Impairment |  | Other Exit Costs |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of March 31, 2011 |  | $ | 7,596 |  | $ | — |  | $ | 21,726 |  | $ | 29,322 |  |
| Activities during the fiscal year 2012: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash payments for charges incurred in fiscal year 2010 and prior |  |  | (2,976 | ) |  | — |  |  | (13,659 | ) |  | (16,635 | ) |
| Balance as of March 31, 2012 |  |  | 4,620 |  |  | — |  |  | 8,067 |  |  | 12,687 |  |
| Provision for charges incurred in fiscal year 2013 |  |  | 110,110 |  |  | 69,453 |  |  | 47,871 |  |  | 227,434 |  |
| Cash payments for charges incurred in fiscal year 2013 |  |  | (28,586 | ) |  | — |  |  | (3,832 | ) |  | (32,418 | ) |
| Cash payments for charges incurred in fiscal year 2010 and prior |  |  | (2,455 | ) |  | — |  |  | (2,902 | ) |  | (5,357 | ) |
| Non-cash charges incurred in fiscal year 2013 |  |  | — |  |  | (69,453 | ) |  | (34,993 | ) |  | (104,446 | ) |
| Balance as of March 31, 2013 |  |  | 83,689 |  |  | — |  |  | 14,211 |  |  | 97,900 |  |
| Provision for charges incurred in fiscal year 2014 |  |  | 66,718 |  |  | 1,900 |  |  | 6,693 |  |  | 75,311 |  |
| Cash payments for charges incurred in fiscal year 2014 |  |  | (40,273 | ) |  | — |  |  | (4,296 | ) |  | (44,569 | ) |
| Cash payments for charges incurred in fiscal year 2013 |  |  | (71,470 | ) |  | — |  |  | (8,755 | ) |  | (80,225 | ) |
| Cash payments for charges incurred in fiscal year 2010 and prior |  |  | (2,171 | ) |  | — |  |  | (1,950 | ) |  | (4,121 | ) |
| Non-cash charges incurred in fiscal year 2014 |  |  | — |  |  | (1,900 | ) |  | — |  |  | (1,900 | ) |
| Balance as of March 31, 2014 |  |  | 36,493 |  |  | — |  |  | 5,903 |  |  | 42,396 |  |
| Less: Current portion (classified as other current liabilities) |  |  | 34,600 |  |  | — |  |  | 1,717 |  |  | 36,317 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) |  | $ | 1,893 |  | $ | — |  | $ | 4,186 |  | $ | 6,079 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0001047469-14-005069:notes:86]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities assumed of Google's Motorola Mobility LLC (in thousands):

[0001047469-14-005069:notes:87]
| Current assets: |  |  |  |  |
| Inventories |  | $ | 97,740 |  |
| Other current assets |  |  | 24,280 |  |
| Total current assets |  |  | 122,020 |  |
| Property and equipment |  |  | 45,198 |  |
| Goodwill |  |  | 2,844 |  |
| Other intangible assets (useful life—6 years) |  |  | 2,948 |  |
| Other assets |  |  | 7,414 |  |
| Total assets |  | $ | 180,424 |  |
| Current liabilities: |  |  |  |  |
| Other current liabilities |  | $ | 317 |  |
| Total current liabilities |  |  | 317 |  |
| Other liabilities |  |  | 1,202 |  |
| Total aggregate purchase price |  | $ | 178,905 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001047469-14-005069:notes:88]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | (In thousands) |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |
| Asia |  | $ | 13,714,187 |  | $ | 11,743,140 |  | $ | 15,408,872 |  |
| Americas |  |  | 8,189,414 |  |  | 7,193,063 |  |  | 8,390,521 |  |
| Europe |  |  | 4,205,006 |  |  | 4,633,272 |  |  | 5,543,636 |  |
|  |  | $ | 26,108,607 |  | $ | 23,569,475 |  | $ | 29,343,029 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001047469-14-005069:notes:89]
|  |  | As of March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Long-lived assets: |  |  |  |  |  |  |  |
| Asia |  | $ | 1,154,467 |  | $ | 1,144,451 |  |
| Americas |  |  | 785,753 |  |  | 659,289 |  |
| Europe |  |  | 348,436 |  |  | 370,848 |  |
|  |  | $ | 2,288,656 |  | $ | 2,174,588 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisValuationTechniquesTableTextBlock

[0001047469-14-005069:notes:90]
|  |  | As of March 31, 2013 |  |
| Remaining life |  |  | 5 years |  |
| Volatility |  |  | 58 | % |
| Dividend yield |  |  | 0 | % |
| Risk-free rate |  |  | 0.80 | % |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001047469-14-005069:notes:91]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2013 |  | 2012 |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 40,593 |  | $ | 127,258 |  |
| Cost of sales |  |  | 42,793 |  |  | 145,403 |  |
| Gross loss |  |  | (2,200 | ) |  | (18,145 | ) |
| Selling, general and administrative expenses |  |  | 1,930 |  |  | 8,932 |  |
| Intangibles amortization and impairment |  |  | 11,000 |  |  | 6,325 |  |
| Interest and other, net |  |  | 11,280 |  |  | (7 | ) |
| Loss before income taxes |  |  | (26,410 | ) |  | (33,395 | ) |
| Benefit from income taxes |  |  | (959 | ) |  | (1,390 | ) |
| Net loss of discontinued operations |  | $ | (25,451 | ) | $ | (32,005 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0001047469-14-005069:notes:92]
Condensed Consolidating Balance Sheets as of March 31, 2014

[0001047469-14-005069:notes:93]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 638,714 |  | $ | 30,500 |  | $ | 924,514 |  | $ | — |  | $ | 1,593,728 |  |
| Accounts receivable |  |  | — |  |  | 766,110 |  |  | 1,931,875 |  |  | — |  |  | 2,697,985 |  |
| Inventories |  |  | — |  |  | 1,387,510 |  |  | 2,211,498 |  |  | — |  |  | 3,599,008 |  |
| Inter company receivable |  |  | 8,867,520 |  |  | 6,968,138 |  |  | 9,149,244 |  |  | (24,984,902 | ) |  | — |  |
| Other current assets |  |  | 246 |  |  | 277,035 |  |  | 1,232,324 |  |  | — |  |  | 1,509,605 |  |
| Total current assets |  |  | 9,506,480 |  |  | 9,429,293 |  |  | 15,449,455 |  |  | (24,984,902 | ) |  | 9,400,326 |  |
| Property and equipment, net |  |  | — |  |  | 427,390 |  |  | 1,861,266 |  |  | — |  |  | 2,288,656 |  |
| Goodwill and other intangible assets, net |  |  | 775 |  |  | 39,074 |  |  | 337,369 |  |  | — |  |  | 377,218 |  |
| Other assets |  |  | 2,585,169 |  |  | 103,335 |  |  | 4,628,970 |  |  | (6,883,524 | ) |  | 433,950 |  |
| Investment in subsidiaries |  |  | 3,350,690 |  |  | 666,996 |  |  | 16,387,828 |  |  | (20,405,514 | ) |  | — |  |
| Total assets |  | $ | 15,443,114 |  | $ | 10,666,088 |  | $ | 38,664,888 |  | $ | (52,273,940 | ) | $ | 12,500,150 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 32,500 |  | $ | 60 |  | $ | 15 |  | $ | — |  | $ | 32,575 |  |
| Accounts payable |  |  | — |  |  | 1,256,204 |  |  | 3,491,575 |  |  | — |  |  | 4,747,779 |  |
| Accrued payroll |  |  | — |  |  | 83,288 |  |  | 271,601 |  |  | — |  |  | 354,889 |  |
| Inter company payable |  |  | 8,607,486 |  |  | 9,422,179 |  |  | 6,955,237 |  |  | (24,984,902 | ) |  | — |  |
| Other current liabilities |  |  | 24,868 |  |  | 626,550 |  |  | 1,870,026 |  |  | — |  |  | 2,521,444 |  |
| Total current liabilities |  |  | 8,664,854 |  |  | 11,388,281 |  |  | 12,588,454 |  |  | (24,984,902 | ) |  | 7,656,687 |  |
| Long term liabilities |  |  | 4,615,210 |  |  | 2,050,460 |  |  | 2,859,638 |  |  | (6,883,524 | ) |  | 2,641,784 |  |
| Flextronics International Ltd. shareholders' equity |  |  | 2,163,050 |  |  | (2,772,653 | ) |  | 23,178,167 |  |  | (20,405,514 | ) |  | 2,163,050 |  |
| Noncontrolling interests |  |  | — |  |  | — |  |  | 38,629 |  |  | — |  |  | 38,629 |  |
| Total shareholders' equity |  |  | 2,163,050 |  |  | (2,772,653 | ) |  | 23,216,796 |  |  | (20,405,514 | ) |  | 2,201,679 |  |
| Total liabilities and shareholders' equity |  | $ | 15,443,114 |  | $ | 10,666,088 |  | $ | 38,664,888 |  | $ | (52,273,940 | ) | $ | 12,500,150 |  |

[0001047469-14-005069:notes:94]
Condensed Consolidating Balance Sheets as of March 31, 2013

[0001047469-14-005069:notes:95]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 740,515 |  | $ | 82,900 |  | $ | 763,672 |  | $ | — |  | $ | 1,587,087 |  |
| Accounts receivable |  |  | — |  |  | 458,617 |  |  | 1,653,379 |  |  | — |  |  | 2,111,996 |  |
| Inventories |  |  | — |  |  | 1,063,627 |  |  | 1,658,873 |  |  | — |  |  | 2,722,500 |  |
| Inter company receivable |  |  | 4,440,955 |  |  | 4,726,673 |  |  | 6,490,274 |  |  | (15,657,902 | ) |  | — |  |
| Other current assets |  |  | 6,182 |  |  | 178,585 |  |  | 1,165,051 |  |  | — |  |  | 1,349,818 |  |
| Total current assets |  |  | 5,187,652 |  |  | 6,510,402 |  |  | 11,731,249 |  |  | (15,657,902 | ) |  | 7,771,401 |  |
| Property and equipment, net |  |  | — |  |  | 328,621 |  |  | 1,845,967 |  |  | — |  |  | 2,174,588 |  |
| Goodwill and other intangible assets, net |  |  | 1,075 |  |  | 40,626 |  |  | 301,851 |  |  | — |  |  | 343,552 |  |
| Other assets |  |  | 2,498,080 |  |  | 105,136 |  |  | 4,902,815 |  |  | (7,204,017 | ) |  | 302,014 |  |
| Investment in subsidiaries |  |  | 4,127,384 |  |  | 141,599 |  |  | 15,968,617 |  |  | (20,237,600 | ) |  | — |  |
| Total assets |  | $ | 11,814,191 |  | $ | 7,126,384 |  | $ | 34,750,499 |  | $ | (43,099,519 | ) | $ | 10,591,555 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 416,594 |  | $ | 60 |  | $ | — |  | $ | — |  | $ | 416,654 |  |
| Accounts payable |  |  | — |  |  | 1,077,723 |  |  | 2,627,574 |  |  | — |  |  | 3,705,297 |  |
| Accrued payroll |  |  | — |  |  | 86,073 |  |  | 265,610 |  |  | — |  |  | 351,683 |  |
| Inter company payable |  |  | 4,963,615 |  |  | 6,093,606 |  |  | 4,600,681 |  |  | (15,657,902 | ) |  | — |  |
| Other current liabilities |  |  | 32,440 |  |  | 424,599 |  |  | 1,242,112 |  |  | — |  |  | 1,699,151 |  |
| Total current liabilities |  |  | 5,412,649 |  |  | 7,682,061 |  |  | 8,735,977 |  |  | (15,657,902 | ) |  | 6,172,785 |  |
| Long term liabilities |  |  | 4,154,784 |  |  | 2,488,279 |  |  | 2,732,966 |  |  | (7,204,017 | ) |  | 2,172,012 |  |
| Shareholders' equity |  |  | 2,246,758 |  |  | (3,043,956 | ) |  | 23,281,556 |  |  | (20,237,600 | ) |  | 2,246,758 |  |
| Total liabilities and shareholders' equity |  | $ | 11,814,191 |  | $ | 7,126,384 |  | $ | 34,750,499 |  | $ | (43,099,519 | ) | $ | 10,591,555 |  |


## us-gaap:ScheduleOfQuarterlyFinancialInformationTableTextBlock

[0001047469-14-005069:notes:96]
|  |  | Fiscal Year Ended March 31, 2014 |  | Fiscal Year Ended March 31, 2013 |  |
|  |  | First |  | Second |  | Third |  | Fourth |  | First |  | Second |  | Third |  | Fourth |  |
|  |  | (In thousands, except per share amounts) |  |
| Net sales(1) |  | $ | 5,791,125 |  | $ | 6,410,106 |  | $ | 7,183,442 |  | $ | 6,723,934 |  | $ | 5,975,995 |  | $ | 6,174,841 |  | $ | 6,123,321 |  | $ | 5,295,318 |  |
| Gross profit(1) |  |  | 311,035 |  |  | 368,423 |  |  | 398,619 |  |  | 362,144 |  |  | 357,357 |  |  | 366,772 |  |  | 246,462 |  |  | 195,657 |  |
| Income (loss) from continuing operations, net of taxes |  |  | 59,257 |  |  | 118,205 |  |  | 145,157 |  |  | 42,975 |  |  | 136,769 |  |  | 160,453 |  |  | 54,596 |  |  | (49,316 | ) |
| Loss from discontinued operations, net of taxes |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (8,297 | ) |  | (9,906 | ) |  | (7,248 | ) |  | — |  |
| Net income (loss) |  |  | 59,257 |  |  | 118,205 |  |  | 145,157 |  |  | 42,975 |  |  | 128,472 |  |  | 150,547 |  |  | 47,348 |  |  | (49,316 | ) |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.09 |  | $ | 0.19 |  | $ | 0.24 |  | $ | 0.07 |  | $ | 0.20 |  | $ | 0.24 |  | $ | 0.08 |  | $ | (0.08 | ) |
| Diluted |  | $ | 0.09 |  | $ | 0.19 |  | $ | 0.23 |  | $ | 0.07 |  | $ | 0.20 |  | $ | 0.24 |  | $ | 0.08 |  | $ | (0.08 | ) |
| Loss from discontinued operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (0.01 | ) | $ | (0.01 | ) | $ | (0.01 | ) | $ | — |  |
| Diluted |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (0.01 | ) | $ | (0.01 | ) | $ | (0.01 | ) | $ | — |  |
| Net income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.09 |  | $ | 0.19 |  | $ | 0.24 |  | $ | 0.07 |  | $ | 0.19 |  | $ | 0.23 |  | $ | 0.07 |  | $ | (0.08 | ) |
| Diluted |  | $ | 0.09 |  | $ | 0.19 |  | $ | 0.23 |  | $ | 0.07 |  | $ | 0.19 |  | $ | 0.22 |  | $ | 0.07 |  | $ | (0.08 | ) |

[0001047469-14-005069:notes:97]
As discussed in note 20 to the consolidated financial statements, "Discontinued Operations", during fiscal 2013 the Company finalized the sale of two of its non-core businesses, and is reporting the operating results of these non-core businesses as discontinued operations. Accordingly net sales and gross profit data above have been adjusted to exclude net revenue and gross profit (loss) pertaining to these non-core businesses.


## us-gaap:ScheduleOfCondensedIncomeStatementTableTextBlock

[0001047469-14-005069:notes:98]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2014

[0001047469-14-005069:notes:99]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 16,224,739 |  | $ | 22,879,360 |  | $ | (12,995,492 | ) | $ | 26,108,607 |  |
| Cost of sales |  |  | — |  |  | 14,846,866 |  |  | 22,758,364 |  |  | (12,995,492 | ) |  | 24,609,738 |  |
| Restructuring charges |  |  | — |  |  | 1,293 |  |  | 57,355 |  |  | — |  |  | 58,648 |  |
| Gross profit |  |  | — |  |  | 1,376,580 |  |  | 63,641 |  |  | — |  |  | 1,440,221 |  |
| Selling, general and administrative expenses |  |  | — |  |  | 198,999 |  |  | 675,797 |  |  | — |  |  | 874,796 |  |
| Intangible amortization |  |  | 300 |  |  | 4,124 |  |  | 24,468 |  |  | — |  |  | 28,892 |  |
| Restructuring charges |  |  | 800 |  |  | 2,401 |  |  | 13,462 |  |  | — |  |  | 16,663 |  |
| Interest and other, net |  |  | (502,028 | ) |  | 860,718 |  |  | (239,274 | ) |  | — |  |  | 119,416 |  |
| Income (loss) from continuing operations before income taxes |  |  | 500,928 |  |  | 310,338 |  |  | (410,812 | ) |  | — |  |  | 400,454 |  |
| Provision for income taxes |  |  | 52 |  |  | 16,762 |  |  | 18,046 |  |  | — |  |  | 34,860 |  |
| Equity in earnings in subsidiaries |  |  | (135,282 | ) |  | (210,354 | ) |  | 388,737 |  |  | (43,101 | ) |  | — |  |
| Net income (loss) |  | $ | 365,594 |  | $ | 83,222 |  | $ | (40,121 | ) | $ | (43,101 | ) | $ | 365,594 |  |

[0001047469-14-005069:notes:100]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2013

[0001047469-14-005069:notes:101]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 14,630,979 |  | $ | 17,768,884 |  | $ | (8,830,388 | ) | $ | 23,569,475 |  |
| Cost of sales |  |  | — |  |  | 13,162,397 |  |  | 17,855,384 |  |  | (8,830,388 | ) |  | 22,187,393 |  |
| Restructuring charges |  |  | — |  |  | 20,366 |  |  | 195,468 |  |  | — |  |  | 215,834 |  |
| Gross profit (loss) |  |  | — |  |  | 1,448,216 |  |  | (281,968 | ) |  | — |  |  | 1,166,248 |  |
| Selling, general and administrative expenses |  |  | — |  |  | 199,934 |  |  | 605,301 |  |  | — |  |  | 805,235 |  |
| Intangible amortization |  |  | 300 |  |  | 7,840 |  |  | 21,389 |  |  | — |  |  | 29,529 |  |
| Restructuring charges |  |  | — |  |  | 1,556 |  |  | 10,044 |  |  | — |  |  | 11,600 |  |
| Interest and other, net |  |  | (880,051 | ) |  | 699,459 |  |  | 171,661 |  |  | — |  |  | (8,931 | ) |
| Income (loss) from continuing operations before income taxes |  |  | 879,751 |  |  | 539,427 |  |  | (1,090,363 | ) |  | — |  |  | 328,815 |  |
| Provision for income taxes |  |  | — |  |  | 1,708 |  |  | 24,605 |  |  | — |  |  | 26,313 |  |
| Equity in earnings in subsidiaries |  |  | (602,700 | ) |  | (330,600 | ) |  | 585,839 |  |  | 347,461 |  |  | — |  |
| Income (loss) from continuing operations |  |  | 277,051 |  |  | 207,119 |  |  | (529,129 | ) |  | 347,461 |  |  | 302,502 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  | — |  |  | (25,451 | ) |  | — |  |  | (25,451 | ) |
| Net income (loss) |  | $ | 277,051 |  | $ | 207,119 |  | $ | (554,580 | ) | $ | 347,461 |  | $ | 277,051 |  |

[0001047469-14-005069:notes:102]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2012

[0001047469-14-005069:notes:103]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 18,852,902 |  | $ | 22,012,300 |  | $ | (11,522,173 | ) | $ | 29,343,029 |  |
| Cost of sales |  |  | — |  |  | 17,395,532 |  |  | 21,951,720 |  |  | (11,522,173 | ) |  | 27,825,079 |  |
| Gross profit |  |  | — |  |  | 1,457,370 |  |  | 60,580 |  |  | — |  |  | 1,517,950 |  |
| Selling, general and administrative expenses |  |  | — |  |  | 203,673 |  |  | 673,891 |  |  | — |  |  | 877,564 |  |
| Intangible amortization |  |  | 2,550 |  |  | 11,559 |  |  | 35,463 |  |  | — |  |  | 49,572 |  |
| Interest and other, net |  |  | (442,563 | ) |  | 1,079,398 |  |  | (620,751 | ) |  | — |  |  | 16,084 |  |
| Income from continuing operations before income taxes |  |  | 440,013 |  |  | 162,740 |  |  | (28,023 | ) |  | — |  |  | 574,730 |  |
| Provision for income taxes |  |  | — |  |  | 1,633 |  |  | 52,327 |  |  | — |  |  | 53,960 |  |
| Equity in earnings in subsidiaries |  |  | 48,752 |  |  | 96,713 |  |  | 360,073 |  |  | (505,538 | ) |  | — |  |
| Income from continuing operations |  |  | 488,765 |  |  | 257,820 |  |  | 279,723 |  |  | (505,538 | ) |  | 520,770 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  | — |  |  | (32,005 | ) |  | — |  |  | (32,005 | ) |
| Net income (loss) |  | $ | 488,765 |  | $ | 257,820 |  | $ | 247,718 |  | $ | (505,538 | ) | $ | 488,765 |  |


## flex:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0001047469-14-005069:notes:104]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2014

[0001047469-14-005069:notes:105]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 365,594 |  | $ | 83,222 |  | $ | (40,121 | ) | $ | (43,101 | ) | $ | 365,594 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  |  | (34,683 | ) |  | (23,634 | ) |  | (89,635 | ) |  | 113,269 |  |  | (34,683 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  |  | (13,992 | ) |  | (6,229 | ) |  | (13,992 | ) |  | 20,221 |  |  | (13,992 | ) |
| Comprehensive income (loss) |  | $ | 316,919 |  | $ | 53,359 |  | $ | (143,748 | ) | $ | 90,389 |  | $ | 316,919 |  |

[0001047469-14-005069:notes:106]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2013

[0001047469-14-005069:notes:107]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 277,051 |  | $ | 207,119 |  | $ | (554,580 | ) | $ | 347,461 |  | $ | 277,051 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  |  | (16,289 | ) |  | 6,464 |  |  | 10,377 |  |  | (16,841 | ) |  | (16,289 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  |  | (20,755 | ) |  | (21,084 | ) |  | (20,755 | ) |  | 41,839 |  |  | (20,755 | ) |
| Comprehensive income (loss) |  | $ | 240,007 |  | $ | 192,499 |  | $ | (564,958 | ) | $ | 372,459 |  | $ | 240,007 |  |

[0001047469-14-005069:notes:108]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2012

[0001047469-14-005069:notes:109]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 488,765 |  | $ | 257,820 |  | $ | 247,718 |  | $ | (505,538 | ) | $ | 488,765 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  |  | (53,616 | ) |  | 40,899 |  |  | 755 |  |  | (41,654 | ) |  | (53,616 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  |  | (7,575 | ) |  | (943 | ) |  | (7,575 | ) |  | 8,518 |  |  | (7,575 | ) |
| Comprehensive income (loss) |  | $ | 427,574 |  | $ | 297,776 |  | $ | 240,898 |  | $ | (538,674 | ) | $ | 427,574 |  |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0001047469-14-005069:notes:110]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2014

[0001047469-14-005069:notes:111]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | 459,748 |  | $ | (371,978 | ) | $ | 1,128,906 |  | $ | (216 | ) |  | 1,216,460 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  |  | — |  |  | (194,878 | ) |  | (319,540 | ) |  | (585 | ) |  | (515,003 | ) |
| Acquisition of businesses, net of cash acquired |  |  | — |  |  | (2,949 | ) |  | (235,082 | ) |  | — |  |  | (238,031 | ) |
| Proceeds from divestitures of business, net of cash held in divested business |  |  | — |  |  | — |  |  | 4,599 |  |  | — |  |  | 4,599 |  |
| Investing cash flows from (to) affiliates |  |  | 35,262 |  |  | (506,382 | ) |  | (1,744,370 | ) |  | 2,215,490 |  |  | — |  |
| Other investing activities, net |  |  | — |  |  | (5,342 | ) |  | (30,155 | ) |  | — |  |  | (35,497 | ) |
| Net cash provided by (used in) investing activities |  |  | 35,262 |  |  | (709,551 | ) |  | (2,324,548 | ) |  | 2,214,905 |  |  | (783,932 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  |  | 1,066,359 |  |  | 277 |  |  | 17 |  |  | — |  |  | 1,066,653 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations |  |  | (492,034 | ) |  | (525 | ) |  | (45,021 | ) |  | — |  |  | (537,580 | ) |
| Payments for early repurchase of long-term debt |  |  | (503,423 | ) |  | (41,417 | ) |  | — |  |  |  |  |  | (544,840 | ) |
| Payments for repurchases of ordinary shares |  |  | (475,314 | ) |  | — |  |  | — |  |  | — |  |  | (475,314 | ) |
| Proceeds from exercise of stock options |  |  | 28,140 |  |  | — |  |  | — |  |  | — |  |  | 28,140 |  |
| Financing cash flows from (to) affiliates |  |  | (277,595 | ) |  | 1,067,746 |  |  | 1,424,537 |  |  | (2,214,688 | ) |  | — |  |
| Other financing activities, net |  |  | — |  |  | — |  |  | 52,149 |  |  | — |  |  | 52,149 |  |
| Net cash provided by (used in) financing activities |  |  | (653,867 | ) |  | 1,026,081 |  |  | 1,431,682 |  |  | (2,214,688 | ) |  | (410,792 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | 57,055 |  |  | 3,048 |  |  | (75,198 | ) |  | — |  |  | (15,095 | ) |
| Net change in cash and cash equivalents |  |  | (101,801 | ) |  | (52,400 | ) |  | 160,842 |  |  | — |  |  | 6,641 |  |
| Cash and cash equivalents, beginning of year |  |  | 740,515 |  |  | 82,900 |  |  | 763,672 |  |  | — |  |  | 1,587,087 |  |
| Cash and cash equivalents, end of year |  | $ | 638,714 |  | $ | 30,500 |  | $ | 924,514 |  | $ | — |  | $ | 1,593,728 |  |

[0001047469-14-005069:notes:112]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2013

[0001047469-14-005069:notes:113]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | 836,833 |  | $ | 588,298 |  | $ | (309,276 | ) | $ | (425 | ) | $ | 1,115,430 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  |  | — |  |  | (134,819 | ) |  | (300,750 | ) |  | 241 |  |  | (435,328 | ) |
| Acquisition of businesses, net of cash acquired |  |  | — |  |  | (20,150 | ) |  | (163,947 | ) |  | — |  |  | (184,097 | ) |
| Proceeds from divestitures of business, net of cash held in divested business |  |  | — |  |  | — |  |  | 22,585 |  |  | — |  |  | 22,585 |  |
| Investing cash flows from (to) affiliates |  |  | (1,228,776 | ) |  | (134,715 | ) |  | 3,168,999 |  |  | (1,805,508 | ) |  | — |  |
| Other investing activities, net |  |  | — |  |  | 6,412 |  |  | (106,771 | ) |  | — |  |  | (100,359 | ) |
| Net cash provided by (used in) investing activities |  |  | (1,228,776 | ) |  | (283,272 | ) |  | 2,620,116 |  |  | (1,805,267 | ) |  | (697,199 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  |  | 1,250,000 |  |  | 150 |  |  | 63 |  |  | — |  |  | 1,250,213 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations |  |  | (379,399 | ) |  | (3,875 | ) |  | (8,585 | ) |  | — |  |  | (391,859 | ) |
| Payments for early repurchase of long-term debt |  |  | (756,855 | ) |  | (243,145 | ) |  | — |  |  |  |  |  | (1,000,000 | ) |
| Payments for repurchases of ordinary shares |  |  | (322,040 | ) |  | — |  |  | — |  |  | — |  |  | (322,040 | ) |
| Proceeds from exercise of stock options |  |  | 22,257 |  |  | — |  |  | — |  |  | — |  |  | 22,257 |  |
| Financing cash flows from (to) affiliates |  |  | 693,185 |  |  | (18,006 | ) |  | (2,480,871 | ) |  | 1,805,692 |  |  | — |  |
| Other financing activities, net |  |  | — |  |  | — |  |  | 101,851 |  |  | — |  |  | 101,851 |  |
| Net cash provided by (used in) financing activities |  |  | 507,148 |  |  | (264,876 | ) |  | (2,387,542 | ) |  | 1,805,692 |  |  | (339,578 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (23,942 | ) |  | (5,115 | ) |  | 19,162 |  |  | — |  |  | (9,895 | ) |
| Net change in cash and cash equivalents |  |  | 91,263 |  |  | 35,035 |  |  | (57,540 | ) |  | — |  |  | 68,758 |  |
| Cash and cash equivalents, beginning of year |  |  | 649,252 |  |  | 47,865 |  |  | 821,212 |  |  | — |  |  | 1,518,329 |  |
| Cash and cash equivalents, end of year |  | $ | 740,515 |  | $ | 82,900 |  | $ | 763,672 |  | $ | — |  | $ | 1,587,087 |  |

[0001047469-14-005069:notes:114]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2012

[0001047469-14-005069:notes:115]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | 399,896 |  | $ | (190,136 | ) | $ | 594,630 |  | $ | (122 | ) |  | 804,268 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  |  | — |  |  | (67,425 | ) |  | (320,300 | ) |  | (279 | ) |  | (388,004 | ) |
| Acquisition of businesses, net of cash acquired |  |  | — |  |  | (70,831 | ) |  | (21,426 | ) |  | — |  |  | (92,257 | ) |
| Proceeds from divestitures of operations, net |  |  | — |  |  | — |  |  | 1,398 |  |  | — |  |  | 1,398 |  |
| Investing cash flows from (to) affiliates |  |  | 376,349 |  |  | 294,368 |  |  | 1,029,085 |  |  | (1,699,802 | ) |  | — |  |
| Other investing activities |  |  | (1,500 | ) |  | 4,626 |  |  | (5,627 | ) |  | — |  |  | (2,501 | ) |
| Net cash provided by (used in) investing activities |  |  | 374,849 |  |  | 160,738 |  |  | 683,130 |  |  | (1,700,081 | ) |  | (481,364 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  |  | 2,827,875 |  |  | — |  |  | 5,829 |  |  | — |  |  | 2,833,704 |  |
| Repayments of bank borrowings and long-term debt |  |  | (2,383,596 | ) |  | (3,503 | ) |  | (2,022 | ) |  | — |  |  | (2,389,121 | ) |
| Payments for early repurchase of long-term debt |  |  | (480,000 | ) |  | — |  |  | — |  |  | — |  |  | (480,000 | ) |
| Payments for repurchases of ordinary shares |  |  | (509,800 | ) |  | — |  |  | — |  |  | — |  |  | (509,800 | ) |
| Proceeds from exercise of stock options |  |  | 23,055 |  |  | — |  |  | — |  |  | — |  |  | 23,055 |  |
| Financing cash flows from (to) affiliates |  |  | (112,398 | ) |  | 16,789 |  |  | (1,604,594 | ) |  | 1,700,203 |  |  | — |  |
| Net cash provided by (used in) financing activities |  |  | (634,864 | ) |  | 13,286 |  |  | (1,600,787 | ) |  | 1,700,203 |  |  | (522,162 | ) |
| Effect of exchange rates on cash |  |  | (55,416 | ) |  | (2,877 | ) |  | 27,409 |  |  | — |  |  | (30,884 | ) |
| Net change in cash and cash equivalents |  |  | 84,465 |  |  | (18,989 | ) |  | (295,618 | ) |  | — |  |  | (230,142 | ) |
| Cash and cash equivalents, beginning of year |  |  | 564,787 |  |  | 66,854 |  |  | 1,116,830 |  |  | — |  |  | 1,748,471 |  |
| Cash and cash equivalents, end of year |  | $ | 649,252 |  | $ | 47,865 |  | $ | 821,212 |  | $ | — |  | $ | 1,518,329 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001047469-14-005069:notes:116]
1. ORGANIZATION OF THE COMPANY

[0001047469-14-005069:notes:117]
Flextronics International Ltd. ("Flextronics" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of supply chain solutions that span from concept through consumption. The Company designs, builds, ships and services a complete packaged electronic product for original equipment manufacturers ("OEMs") in the following business groups: High Reliability Solutions ("HRS"), which is comprised of our medical, automotive, and defense and aerospace businesses; High Velocity Solutions ("HVS"), which includes our mobile devices business, including smart phones; our consumer electronics business, including game consoles and wearable electronics; and our high-volume computing business, including various supply chain solutions for notebook personal computing ("PC"), tablets, and printers; Industrial and Emerging Industries ("IEI"), which is comprised of our household appliances, semi-cap equipment, kiosks, energy and emerging industries businesses; and Integrated Network Solutions ("INS"), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses. The Company's strategy is to provide customers with a full range of cost competitive, global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. OEM customers leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001047469-14-005069:notes:118]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001047469-14-005069:notes:119]
2. SUMMARY OF ACCOUNTING POLICIES

[0001047469-14-005069:notes:120]
Use of Estimates

[0001047469-14-005069:notes:121]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; asset impairments; fair values of financial instruments including investments, notes receivable and derivative instruments; restructuring charges; contingencies; fair values of assets and liabilities obtained in business combinations and the fair values of stock options and share bonus awards granted under the Company's stock-based compensation plans. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0001047469-14-005069:notes:122]
Customer Credit Risk

[0001047469-14-005069:notes:123]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0001047469-14-005069:notes:124]
Concentration of Credit Risk

[0001047469-14-005069:notes:125]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, cash and cash equivalents, and derivative instruments.

[0001047469-14-005069:notes:126]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2014, 2013 and 2012:

[0001047469-14-005069:notes:127]
One customer accounted for approximately 13% of the Company's net sales in fiscal 2014. No customer accounted for greater than 10% of the Company's net sales in fiscal 2013. Two customers accounted for approximately 11% and 10%, respectively of the Company's net sales in fiscal 2012. The Company's ten largest customers accounted for approximately 52%, 47%, and 55% of its net sales in fiscal years 2014, 2013 and 2012, respectively. As of March 31, 2014, one customer accounted for approximately 14% of the Company's total accounts receivables. As of March 31, 2013, no single customer accounted for greater than 10% of the Company's total accounts receivable.

[0001047469-14-005069:notes:128]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, and are classified as cash equivalents on the consolidated balance sheet.

[0001047469-14-005069:notes:129]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives at note 8 to the consolidated financial statements.

[0001047469-14-005069:notes:130]
Accounting for Business and Asset Acquisitions

[0001047469-14-005069:notes:131]
The Company has actively pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0001047469-14-005069:notes:132]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0001047469-14-005069:notes:133]
Investments

[0001047469-14-005069:notes:134]
The Company's investments are included as other assets in the consolidated balance sheets. The Company has certain equity investments in, and notes receivable from, non-publicly traded companies which are included within other assets in the Company's consolidated balance sheets. Non-majority-owned investments are accounted for using the equity method when the Company has an ownership percentage equal to or greater than 20% but less than 50%, or has the ability to significantly influence the operating decisions of the issuer; otherwise the cost method is used. The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required. Fair values of these investments, when required, are estimated using unobservable inputs, primarily discounted cash flow projections.

[0001047469-14-005069:notes:135]
As of March 31, 2014 and 2013, the Company's equity investments in non-majority owned companies totaled $77.4 million and $26.8 million, respectively. The equity in the earnings or losses of the Company's equity method investments was not material to the consolidated results of operations for any period presented and is included in interest and other, net.

[0001047469-14-005069:notes:136]
The investments balance as of March 31, 2013 includes $74.4 million relating to the fair value of certain fully vested warrants to purchase common stock of a supplier. These warrants were exercised and the underlying shares were sold for total proceeds of $67.3 million resulting in a loss of $7.1 million that was recognized during fiscal 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001047469-14-005069:notes:137]
3. SHARE-BASED COMPENSATION

[0001047469-14-005069:notes:138]
Equity Compensation Plans

[0001047469-14-005069:notes:139]
During fiscal year 2014, the Company granted equity compensation awards under the 2010 Equity Incentive Plan (the "2010 Plan") and the 2013 Elementum Plan (the "Elementum Plan"). The 2010 Plan is administered by Flextronics International Ltd., while the Elementum Plan is administered by Elementum SCM (Cayman) Limited, a majority owned subsidiary of the Company.

[0001047469-14-005069:notes:140]
The 2010 Equity Incentive Plan of Flextronics International Ltd.

[0001047469-14-005069:notes:141]
As of March 31, 2014, the Company had approximately 38.1 million shares available for grants under the 2010 Plan. Options issued to employees under the 2010 Plan generally vest over four years and expire seven years from the date of grant. Options granted to non-employee directors expire five years from the date of grant.

[0001047469-14-005069:notes:142]
The exercise price of options granted to employees is determined by the Company's Board of Directors or the Compensation Committee and may not be less than the closing price of the Company's ordinary shares on the date of grant.

[0001047469-14-005069:notes:143]
The Company also grants share bonus awards under its equity compensation plan. Share bonus awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. Share bonus awards generally vest in installments over a three to five year period and unvested share bonus awards are forfeited upon termination of employment. Vesting for certain share bonus awards is contingent upon both service and market conditions.

[0001047469-14-005069:notes:144]
Share-Based Compensation Expense

[0001047469-14-005069:notes:145]
The following table summarizes the Company's share-based compensation expense:

[0001047469-14-005069:notes:146]
As required by the authoritative guidance for stock-based compensation, management made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as an analysis of actual forfeitures.

[0001047469-14-005069:notes:147]
As of March 31, 2014, the total unrecognized compensation cost related to unvested share options granted to employees under the Company's 2010 Plan was approximately $0.6 million, net of estimated forfeitures. This cost will be amortized on a straight-line basis over a weighted-average period of approximately 1.0 year and will be adjusted for estimated forfeitures. As of March 31, 2014, the total unrecognized compensation cost related to unvested share bonus awards granted to employees was approximately $77.5 million, net of estimated forfeitures. This cost will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.4 years and will be adjusted for estimated forfeitures. Approximately $15.0 million of the unrecognized compensation cost, net of forfeitures, is related to share bonus awards granted to certain key employees whereby vesting is contingent on meeting a certain market condition.

[0001047469-14-005069:notes:148]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as financing cash flows. During fiscal years 2014, 2013 and 2012, the Company did not recognize any excess tax benefits as a financing cash inflow.

[0001047469-14-005069:notes:149]
Determining Fair Value

[0001047469-14-005069:notes:150]
Options

[0001047469-14-005069:notes:151]
Valuation and Amortization Method—The Company estimates the fair value of share options granted under the 2010 Plan using the Black-Scholes valuation method and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period. The fair market value of share bonus awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0001047469-14-005069:notes:152]
Expected Term—The Company's expected term used in the Black-Scholes valuation method represents the period that the Company's share options are expected to be outstanding and is determined based on historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share options.

[0001047469-14-005069:notes:153]
Expected Volatility—The Company's expected volatility used in the Black-Scholes valuation method is derived from a combination of implied volatility related to publicly traded options to purchase Flextronics ordinary shares and historical variability in the Company's periodic share price.

[0001047469-14-005069:notes:154]
Expected Dividend—The Company has never paid dividends on its ordinary shares and currently does not intend to do so in the near term, and accordingly, the dividend yield percentage is zero for all periods.

[0001047469-14-005069:notes:155]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0001047469-14-005069:notes:156]
There were no options granted under the 2010 Plan during fiscal year 2014. The fair value of the Company's share options granted to employees for fiscal years 2013 and 2012 was estimated using the following weighted-average assumptions:

[0001047469-14-005069:notes:157]
Options granted during the 2013 and 2012 fiscal years had contractual lives of seven years.

[0001047469-14-005069:notes:158]
Share bonus awards with service and market conditions

[0001047469-14-005069:notes:159]
Valuation and Amortization Method—The Company estimates the fair value of share bonus awards granted under the 2010 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0001047469-14-005069:notes:160]
Expected volatility of Flextronics—Volatility used in Monte Carlo simulation is derived from the historical volatility of Flextronics' stock price over a period equal to the service period of the share bonus awards granted. The service period is three years for those share bonus awards granted in fiscal years 2014 and 2013, and four years for those share bonus awards granted in fiscal year 2012.

[0001047469-14-005069:notes:161]
Average peer volatility—Volatility used in Monte Carlo simulation is derived from the historical volatilities of both the S&P 500 index and components of an extended Electronics Manufacturing Services ("EMS") group, comprised of global competitors of the Company within the same industry, for the share bonus awards granted in fiscal year 2014, and historical volatilities of the S&P 500 index for the share bonus awards granted in fiscal years 2013 and 2012 based on the various service periods.

[0001047469-14-005069:notes:162]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flextronics' stock price relative to both the S&P 500 index and peers in the extended EMS group for the share bonus awards granted in fiscal 2014, and relative to the S&P 500 index for the share bonus awards granted in fiscal 2013 and 2012.

[0001047469-14-005069:notes:163]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Monte Carlo simulation on the yield of zero-coupon U.S. Treasury bills, as of the measurement date.

[0001047469-14-005069:notes:164]
The fair value of the Company's share-bonus awards, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2014, 2013 and 2012 was estimated using the following weighted-average assumptions:

[0001047469-14-005069:notes:165]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Expected volatility |  |  | 35.9 | % |  | 41.7 | % |  | 60.6 | % |
| Average peer volatility |  |  | 35.7 | % |  | 19.2 | % |  | 27.4 | % |
| Average peer correlation |  |  | 0.4 |  |  | 0.7 |  |  | 0.7 |  |
| Expected dividends |  |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate |  |  | 0.4 | % |  | 0.4 | % |  | 1.2 | % |

[0001047469-14-005069:notes:166]
Share-Based Awards Activity

[0001047469-14-005069:notes:167]
The following is a summary of option activity for the Company's 2010 Plan ("Price" reflects the weighted-average exercise price):

[0001047469-14-005069:notes:168]
The aggregate intrinsic value of options exercised (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise for options exercised in-the-money) under the Company's 2010 Plan was $24.7 million, $13.0 million and $17.1 million during fiscal years 2014, 2013 and 2012 respectively.

[0001047469-14-005069:notes:169]
Cash received from option exercises was $28.1 million, $22.3 million and $23.1 million for fiscal years 2014, 2013 and 2012, respectively.

[0001047469-14-005069:notes:170]
The following table presents the composition of options outstanding and exercisable as of March 31, 2014:

[0001047469-14-005069:notes:171]
As of March 31, 2014, the aggregate intrinsic value for options outstanding, options vested and expected to vest (which includes adjustments for expected forfeitures), and options exercisable were $53.5 million, $53.4 million and $53.0 million, respectively. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2014 for the approximately 10.1 million options that were in-the-money at March 31, 2014. As of March 31, 2014, the weighted average remaining contractual life for options exercisable was 1.49 years.

[0001047469-14-005069:notes:172]
The following table summarizes the Company's share bonus award activity ("Price" reflects the weighted-average grant-date fair value):

[0001047469-14-005069:notes:173]
Of the 21.8 million unvested share bonus awards outstanding as of the year ended March 31, 2014, approximately 5.1 million represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions, and are summarized as follows:

[0001047469-14-005069:notes:174]
|  |  |  |  |  |  |  |  | Range of shares that may be issued |  |  |
|  |  | Targeted number of awards as of March 31, 2014 (in shares) |  | Average grant date fair value (per share) |  |  |  |  |
| Year of grant |  | Market condition |  | Minimum |  | Maximum |  | Assessment dates |
| Fiscal 2014 |  |  | 2,174,000 |  | $ | 9.34 |  | Vesting ranges from zero to 200% based on measurement of Flextronics' total shareholder return against both the Standard and Poor's ("S&P") 500 Composite Index and an Extended Electronics Manufacturing Services ("EMS") Group Index. |  |  | 0 |  |  | 4,348,000 |  | May 2016 |
| Fiscal 2013 |  |  | 1,795,000 |  | $ | 7.63 |  | Vesting ranges from zero to 200% based on measurement of Flextronics' total shareholder return against the S&P 500 Composite Index. |  |  | 0 |  |  | 3,590,000 |  | May 2015 |
| Fiscal 2012 |  |  | 822,500 |  | $ | 7.78 |  | Vesting ranges from zero to 150% based on measurement of Flextronics' total shareholder return against the S&P 500 Composite Index. |  |  | 0 |  |  | 1,233,750 |  | June 2014 (50%) June 2015 (50%) |
| Fiscal 2011 |  |  | 320,000 |  | $ | 7.32 |  | Vesting ranges from zero to 150% based on measurement of Flextronics' total shareholder return against the S&P 500 Composite Index. |  |  | 0 |  |  | 480,000 |  | June 2014 |
| Totals |  |  | 5,111,500 |  |  |  |  |  |  |  |  |  |  | 9,651,750 |  |  |

[0001047469-14-005069:notes:175]
In accordance with the accounting guidance, the Company will continue to recognize share-based compensation expense for these awards with market conditions regardless of whether such awards will ultimately vest. The first half of the share-bonus awards with market conditions granted in fiscal year 2011 did not vest in June 2013 as the market condition was not met as of that date. Half of the share-bonus awards with market conditions granted during fiscal 2012 and the remainder of the awards granted during fiscal year 2011 will vest in June 2014, and the expected payout percentages are approximately 50% and 75% of the number of shares granted, respectively.

[0001047469-14-005069:notes:176]
The total intrinsic value of share bonus awards vested under the Company's 2010 Plan was $42.4 million, $9.7 million, and $17.7 million during fiscal years 2014, 2013 and 2012, respectively, based on the closing price of the Company's ordinary shares on the date vested.

[0001047469-14-005069:notes:177]
The 2013 Equity Incentive Plan of Elementum SCM (Cayman) Ltd.

[0001047469-14-005069:notes:178]
In November 2013, Elementum SCM (Cayman) Ltd.("Elementum"), a majority owned subsidiary of the Company established its own equity incentive plan (Elementum Plan). During the year ended March 31, 2014, Elementum issued 8.3 million options with an average fair value of $0.19 per option and average exercise price of $0.17 per option to its employees which vest over a period of four years and expire ten years from the grant date. Of these options 1.9 million were cancelled during the fiscal year, and 6.4 million were outstanding at an average exercise price of $0.19 per option. None of the options had been exercised as of March 31, 2014, and Elementum had approximately 6.6 million shares available for future grants under this Plan.

[0001047469-14-005069:notes:179]
The exercise price of the options granted under this Plan are determined by the Board of Directors of Elementum and is based on valuations obtained from a third party service provider for the Elementum common shares as of the date of option grants.

[0001047469-14-005069:notes:180]
Fair value of options granted under this Plan are determined as follows:

[0001047469-14-005069:notes:181]
Valuation and Amortization Method—Elementum estimates the fair value of share options granted using the Black-Scholes valuation method and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001047469-14-005069:notes:182]
Expected Term—The expected term used in the Black-Scholes valuation method is calculated using the simplified method as applicable to non-publicly-traded companies per the authoritative guidance for stock-based compensation expense.

[0001047469-14-005069:notes:183]
Expected Volatility—The expected volatility used in the Black-Scholes valuation method is derived from implied volatility related to publicly traded options to purchase ordinary shares of comparable companies.

[0001047469-14-005069:notes:184]
Expected Dividend—Elementum has never paid dividends on its ordinary shares and currently does not intend to do so in the near term, and accordingly, the dividend yield percentage is zero for all periods.

[0001047469-14-005069:notes:185]
Risk-Free Interest Rate—Elementum bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0001047469-14-005069:notes:186]
Total stock-based compensation expense for the Elementum Plan recognized during the year ended March 31, 2014 is not material to the consolidated operating results of the Company and is included in the share-based compensation expense disclosures of the Company. Total unrecognized compensation expenses relating to stock options granted to certain employees under the Elementum Plan as of March 31, 2014 is $3.1 million, and will be recognized over a weighted average period of 3.75 years.


## us-gaap:EarningsPerShareTextBlock

[0001047469-14-005069:notes:187]
4. EARNINGS PER SHARE

[0001047469-14-005069:notes:188]
Basic earnings per share for both continuing and discontinued operations exclude dilution and are computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0001047469-14-005069:notes:189]
Diluted earnings per share for both continuing and discontinued operations reflect the potential dilution from stock options and share bonus awards. The potential dilution from stock options exercisable into ordinary share equivalents and share bonus awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0001047469-14-005069:notes:190]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income from continuing and discontinued operations per share:


## us-gaap:MinorityInterestDisclosureTextBlock

[0001047469-14-005069:notes:191]
5. NON-CONTROLLING INTERESTS

[0001047469-14-005069:notes:192]
During fiscal 2014, a previously wholly-owned subsidiary of the Company received $38.6 million in exchange for issuing a non-controlling equity interest to certain third party investors for an ownership interest of less than 20% of the outstanding shares in the subsidiary. The Company continues to own a majority of the subsidiary's outstanding equity and also controls the subsidiary's board of directors. Accordingly, the consolidated financial statements include the financial position and results of operations of this subsidiary as of March 31, 2014 and for the year then ended.

[0001047469-14-005069:notes:193]
The Company has recognized the carrying value of the non-controlling interest as a component of total shareholders' equity. The operating results of the subsidiary attributable to the non-controlling interests are immaterial for all of the periods presented and are included in interest and other, net.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001047469-14-005069:notes:194]
6. SUPPLEMENTAL CASH FLOW DISCLOSURES

[0001047469-14-005069:notes:195]
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:


## us-gaap:DebtDisclosureTextBlock

[0001047469-14-005069:notes:196]
7. BANK BORROWINGS AND LONG-TERM DEBT

[0001047469-14-005069:notes:197]
Bank borrowings and long-term debt are as follows:

[0001047469-14-005069:notes:198]
The weighted average interest rates for the Company's long-term debt were 3.2% and 3.5% as of March 31, 2014 and 2013, respectively.

[0001047469-14-005069:notes:199]
Repayments of the Company's long-term debt are as follows:

[0001047469-14-005069:notes:200]
Capital lease obligations of $8.9 million and $9.1 million, consisting of short-term obligations of $4.2 million and $2.8 million and long term obligations of $4.7 million and $6.3 million are included in current and non-current liabilities on the Company's balance sheets as of March 31, 2014 and 2013, respectively.

[0001047469-14-005069:notes:201]
Term Loan Agreement due October 2014

[0001047469-14-005069:notes:202]
The Company entered into a $1.8 billion term loan facility, dated as of October 1, 2007, and subsequently amended as of December 28, 2007.

[0001047469-14-005069:notes:203]
On August 30, 2013, the Company repaid the remaining amount of $170.3 million under this loan using part of the proceeds from the Term Loan due August 2018.

[0001047469-14-005069:notes:204]
Term Loan due August 2018

[0001047469-14-005069:notes:205]
On August 30, 2013, the Company entered into a $600 million term loan agreement due August 30, 2018 and used part of the proceeds to repay the outstanding balances of the term loan due October 2014 and the Asia Term Loans in full amounting to $170.3 million and $374.5 million, respectively. The remaining $55.2 million was used to repay part of the term loan due March 2019 and upfront bank fees. This loan is repayable in quarterly installments of $3.75 million, which will commence in December 2014 through June 2018, with the remaining amount due at maturity.

[0001047469-14-005069:notes:206]
Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.00% and 2.00%, based on the Company's credit ratings or (ii) the base rate (the greatest of the agent's prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.00% and 1.00%, based on the Company's credit rating.

[0001047469-14-005069:notes:207]
This term loan is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2014, the Company was in compliance with the covenants under this term loan agreement.

[0001047469-14-005069:notes:208]
Term Loan Agreement due March 2019 and Revolving Line of Credit

[0001047469-14-005069:notes:209]
On October 19, 2011, the Company entered into a five-year $2.0 billion Credit Facility consisting of a $1.5 billion Revolving Credit Facility and a $500.0 million term loan, which was due to expire in October 2016. The Revolving Credit Facility due 2016 replaced the Company's then existing $2.0 billion revolving credit facility and the $500.0 million term loan refinanced the outstanding amount of its $500.0 million tranche under the Company's $1.7 billion term loan due October 2014 (referred to above). During fiscal year 2013, the Company increased the limit on the term loan by $50 million and borrowed the entire incremental amount.

[0001047469-14-005069:notes:210]
On March 31, 2014, the Company extended the maturity date of this revolving credit facility and term loan to March 2019, and borrowed an incremental amount of $63.4 million under the term loan thereby increasing the total amount outstanding under the term loan to $500 million. Quarterly repayments of principal under this term loan will commence on June 30, 2014 in the amount of $6.3 million up to March 31, 2016 and will increase to $9.4 million thereafter with the remainder due upon maturity. Upon extension of this revolving credit facility and term loan, borrowings bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the agent's prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating. The Company is required to pay a quarterly commitment fee ranging between 0.15% and 0.40% per annum on the daily unused amount of the $1.5 billion Revolving Credit Facility based on the Company's credit rating.

[0001047469-14-005069:notes:211]
This Credit Facility is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2014, the Company was in compliance with the covenants under this loan agreement.

[0001047469-14-005069:notes:212]
Notes due February 2020 and February 2023

[0001047469-14-005069:notes:213]
On February 20, 2013, the Company issued $500.0 million of 4.625% Notes due February 15, 2020 and $500.0 million of 5.000% Notes due February 15, 2023 (collectively the "Notes") in a private offering pursuant to Rule 144A and Regulation S under the Securities Act. In July 2013, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission. The Company received net proceeds of approximately $990.6 million from the issuance and used those proceeds, together with $9.4 million of cash on hand, to repay $1.0 billion of outstanding borrowings under its term loan due October 2014.

[0001047469-14-005069:notes:214]
Interest on the Notes is payable semi-annually, which commenced on August 15, 2013. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Term Loan Agreement and Revolving Line of Credit.

[0001047469-14-005069:notes:215]
At any time prior to maturity, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0001047469-14-005069:notes:216]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately. As of March 31, 2014, the Company was in compliance with the covenants in the indenture governing the Notes.

[0001047469-14-005069:notes:217]
Asia Term Loans

[0001047469-14-005069:notes:218]
On September 27, 2010, the Company entered into a $50.0 million term loan agreement with a bank based in Asia, which was due to mature on September 27, 2013. Borrowings under the term loan bear interest at LIBOR plus 2.30%. The Company, at its election, may convert the loan (in whole or in part) to bear interest at the higher of the Federal Funds rate plus 0.50% or the prime rate plus 1.00%. Principal payments of $500,000 are due quarterly with the balance due on the maturity date. The Company has the right to prepay any part of the loan without penalty. Borrowings under the term loan agreement are guaranteed by certain subsidiaries of the Company.

[0001047469-14-005069:notes:219]
On September 28, 2010, the Company entered into a $130.0 million term loan facility with a bank in Asia, which was due to mature on September 28, 2013. Borrowings under the facility bear interest at LIBOR plus a margin of 2.15%, and the Company paid a non-refundable fee of $1.4 million at the inception of the loan. The Company has the right to prepay any part of the loan without penalty.

[0001047469-14-005069:notes:220]
On February 17, 2011, the Company entered into a $200.0 million term loan facility with a bank in Asia, which was due to mature on February 17, 2014. Borrowings under the facility bear interest at LIBOR plus a margin of 2.28%, and the Company paid a non-refundable fee of $1.0 million at the inception of the loan.

[0001047469-14-005069:notes:221]
On August 30, 2013, the Company repaid the entire balance on the Asia Term loans using the proceeds from its Term Loan due August 2018.

[0001047469-14-005069:notes:222]
Other Credit Lines

[0001047469-14-005069:notes:223]
As of March 31, 2104, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other loans in the amount of $267.7 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2014 and 2013. These unsecured credit facilities, and lines of credit and other loans bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin, and generally have maturities that expire on various dates in future fiscal years.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001047469-14-005069:notes:224]
8. FINANCIAL INSTRUMENTS

[0001047469-14-005069:notes:225]
Foreign Currency Contracts

[0001047469-14-005069:notes:226]
The Company transacts business in various foreign countries and is therefore, exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency unit of the operating entity. The Company enters into short-term foreign currency forward and swap contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains and losses on the Company's forward and swap contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these forward and swap contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0001047469-14-005069:notes:227]
As of March 31, 2014, the aggregate notional amount of the Company's outstanding foreign currency forward and swap contracts was $4.5 billion as summarized below:

[0001047469-14-005069:notes:228]
As of March 31, 2014 and 2013, the fair value of the Company's short-term foreign currency contracts was not material and included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in non-functional currencies and are not accounted for as hedges under the accounting standards. Accordingly, changes in fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the consolidated statements of operations. As of March 31, 2014 and 2013, the Company also has included net deferred losses and gains, respectively, in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses and gains were not material, and the deferred losses as of March 31, 2014 are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations over the next twelve month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal years presented and are included as a component of interest and other, net in the consolidated statements of operations.

[0001047469-14-005069:notes:229]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2014 and 2013:

[0001047469-14-005069:notes:230]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001047469-14-005069:notes:231]
9. ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001047469-14-005069:notes:232]
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal year ended March 31, 2014 are as follows:

[0001047469-14-005069:notes:233]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the fiscal year ended March 31, 2014, was recognized as a component of cost of sales in the consolidated statement of operations, which primarily relate to the Company's foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001047469-14-005069:notes:234]
10. TRADE RECEIVABLES SECURITIZATION

[0001047469-14-005069:notes:235]
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0001047469-14-005069:notes:236]
Asset-Backed Securitization Programs

[0001047469-14-005069:notes:237]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the "Global Program") and its North American Asset-Backed Securitization Agreement (the "North American Program," collectively, the "ABS Programs") to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $500.0 million for the Global Program, of which $400.0 million is committed and $100.0 million is uncommitted, and $300.0 million for the North American Program. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001047469-14-005069:notes:238]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.5% to 1.00% of serviced receivables per annum. Servicing fees recognized during the fiscal years ended March 31, 2014, 2013 and 2012 were not material and are included in interest and other, net within the consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0001047469-14-005069:notes:239]
As of March 31, 2014 and 2013, the accounts receivable balances that were sold under the ABS Programs were removed from the consolidated balance sheets and the net cash proceeds received by the Company during fiscal years ended March 31, 2014, 2013 and 2012 were included as cash provided by operating activities in the consolidated statements of cash flows.

[0001047469-14-005069:notes:240]
As of March 31, 2014, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of $729.3 million and deferred purchase price receivables of $470.9 million. As of March 31, 2013, approximately $1.0 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $556.9 million and deferred purchase price receivables of $412.4 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of March 31, 2014 and 2013, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the consolidated statements of operations; such amounts were $7.1 million, $7.2 million and $10.9 million for the fiscal years ended March 31, 2014, 2013 and 2012, respectively.

[0001047469-14-005069:notes:241]
For the fiscal years ended March 31, 2014, 2013 and 2012, cash flows from sales of receivables under the ABS Programs consisted of approximately $4.2 billion, $3.5 billion and $4.7 billion, respectively for transfers of receivables (of which approximately $0.4 billion, $0.7 billion and $0.6 billion, respectively represented new transfers and the remainder proceeds from collections reinvested in revolving period transfers).

[0001047469-14-005069:notes:242]
The following table summarizes the activity in the deferred purchase price receivables account during the fiscal years ended March 31, 2014 and 2013:

[0001047469-14-005069:notes:243]
Trade Accounts Receivable Sale Programs

[0001047469-14-005069:notes:244]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $341.8 million and $163.6 million as of March 31, 2014 and 2013, respectively. For the years ended March 31, 2014, 2013 and 2012, total accounts receivables sold to certain third party banking institutions was approximately $3.4 billion, $1.1 billion and $2.0 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and were reflected as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0001047469-14-005069:notes:245]
11. FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES

[0001047469-14-005069:notes:246]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0001047469-14-005069:notes:247]
Level 1— Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0001047469-14-005069:notes:248]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other noncurrent assets on the consolidated balance sheets and include investments in equity securities that are valued using active market prices.

[0001047469-14-005069:notes:249]
Level 2— Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0001047469-14-005069:notes:250]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0001047469-14-005069:notes:251]
The Company's cash equivalents are comprised of bank deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0001047469-14-005069:notes:252]
The Company's deferred compensation plan assets also include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0001047469-14-005069:notes:253]
Level 3— Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0001047469-14-005069:notes:254]
The Company has accrued for contingent consideration in connection with its business acquisitions, which is measured at fair value based on certain internal models and inputs. The following table summarizes the activities related to contingent consideration:

[0001047469-14-005069:notes:255]
The Company values deferred purchase price receivables relating to its Asset-Backed Securitization Program based on a discounted cash flow analysis using unobservable inputs (i.e. level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, their fair value approximates carrying value. Significant increases in either of the significant unobservable inputs (credit spread or risk free interest rate) in isolation would result in lower fair value estimates, however the impact is insignificant. The interrelationship between these inputs is also insignificant. Refer to note 10 to the consolidated financial statements for a reconciliation of the change in the deferred purchase price receivable.

[0001047469-14-005069:notes:256]
As of March 31, 2013, the Company had warrants to purchase up to 1.35 million shares of common stock of a certain supplier at a weighted-average price of $7.33 per share. The warrants were to expire on May 18, 2018. These fully vested warrants, which were derivative instruments, were fair valued at each reporting date with gains or losses from changes in fair value recognized in the consolidated statements of operations. The Company valued these warrants based on the Black-Scholes option-valuation model using unobservable inputs classified as level 3 in the fair value hierarchy. Significant changes in any of the unobservable inputs in isolation would have resulted in a change in the fair value estimate, but in each case, the amount would have been insignificant. The interrelationship between these inputs was also insignificant. As of March 31, 2013, the Company used the following assumptions to value these warrants:

[0001047469-14-005069:notes:257]
During fiscal year 2014 these warrants were exercised and the underlying shares were sold.

[0001047469-14-005069:notes:258]
The following table summarizes the changes in the fair value of these warrants:

[0001047469-14-005069:notes:259]
|  |  | As of March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 74,437 |  | $ | — |  |
| Exercise of warrants |  |  | (67,326 | ) |  | — |  |
| Fair value adjustment |  |  | (7,111 | ) |  | 74,437 |  |
| Ending balance |  | $ | — |  | $ | 74,437 |  |

[0001047469-14-005069:notes:260]
There were no transfers between levels in the fair value hierarchy during fiscal years 2014 and 2013.

[0001047469-14-005069:notes:261]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0001047469-14-005069:notes:262]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2014 and 2013:

[0001047469-14-005069:notes:263]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001047469-14-005069:notes:264]
The Company has certain long-lived assets that are measured at fair value on a nonrecurring basis, and are as follows:

[0001047469-14-005069:notes:265]
Assets held for sale

[0001047469-14-005069:notes:266]
Assets held for sale are recorded at the lesser of the carrying value or fair value, which is based on comparable sales from prevailing market data (level 2 inputs). These assets primarily represent manufacturing facilities that have been closed as part of the Company's historical facility consolidations and that met the criteria to be classified as held for sale. During fiscal year 2014, the Company transferred $59.4 million of assets to held for sale, and expects to sell these within a period of twelve months. Disposals of assets held for sale totaled $24.5 million during fiscal year 2014, which resulted in a gain of $9.2 million, and was included as a component of cost of sales in the consolidated statement of operations. Impairment charges during fiscal year 2014 were not significant for assets that were no longer in use and held for sale. No impairment charges were recorded for assets held for sale during fiscal year 2013.

[0001047469-14-005069:notes:267]
Property and equipment

[0001047469-14-005069:notes:268]
During the fiscal year 2013, the Company recognized impairment charges relating to certain long-lived assets held and used since the carrying value of such assets exceeded the fair value, based on the sales of comparable assets, as a result of its restructuring activities as further discussed in note 14 to the consolidated financial statements.

[0001047469-14-005069:notes:269]
There were no material fair value adjustments or other transfers between levels in the fair value hierarchy for these long-lived assets during the fiscal years 2014 and 2013.

[0001047469-14-005069:notes:270]
Other financial instruments

[0001047469-14-005069:notes:271]
The following table presents the Company's liabilities not carried at fair value as at March 31, 2014 and 2013:

[0001047469-14-005069:notes:272]
The term loans and Notes due February 2020 and February 2023 are valued based on broker trading prices in active markets.

[0001047469-14-005069:notes:273]
Asia term loans—The Company's Asia Term Loans were not traded publicly; however, as the pricing, maturity and other pertinent terms of these loans closely approximate those of the Term Loans due October 2014 and March 2019, management estimates the respective trading prices would be approximately the same.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001047469-14-005069:notes:274]
12. COMMITMENTS AND CONTINGENCIES

[0001047469-14-005069:notes:275]
Commitments

[0001047469-14-005069:notes:276]
As of March 31, 2014 and 2013, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under capital leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2028 and require the following minimum lease payments:

[0001047469-14-005069:notes:277]
Total rent expense amounted to $150.1 million, $138.8 million and $160.5 million in fiscal years 2014, 2013 and 2012, respectively.

[0001047469-14-005069:notes:278]
As part of an existing manufacturing agreement with a customer, the Company is obligated to reimburse the customer for certain performance provisions as defined in the contract. Also defined in the contract are certain provisions that would allow the Company to recover these losses in future periods. The maximum commitment under this arrangement was initially $88.0 million and declines as the Company manufactures and delivers products under the arrangement, which expires in August 2016. As of March 31, 2014, per the terms of the agreement, and in conjunction with negotiations with the customer during the fourth quarter of fiscal 2014, the contractual obligation for reimbursement was determined to be probable and accordingly the Company recorded $55.0 million to other charges (income), net in the consolidated statements of operations. Reimbursement is not payable until August 2016 or upon contract termination and as a result is included in other liabilities. The Company and the customer are finalizing an amendment to this agreement that includes a waiver of the $55.0 million contractual obligation. Upon the execution of the amendment, if the contractual obligation is waived, the Company will reverse this charge with a corresponding credit to other income in the period the amendment is executed.

[0001047469-14-005069:notes:279]
The Company valued the contractual obligation as of March 31, 2014 based on the performance provisions defined in the contract (i.e. level 3 inputs in the fair value hierarchy).

[0001047469-14-005069:notes:280]
Litigation and other legal matters

[0001047469-14-005069:notes:281]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431). The complaint asserts various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products. The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys' fees and costs. The plaintiff also seeks a jury trial. Although the outcome of this matter is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of this matter, which are in excess of amounts already accrued in its consolidated balance sheets, would not be material to the financial statements as a whole.

[0001047469-14-005069:notes:282]
During the fourth quarter of fiscal 2014, one of our Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010. This assessment is currently being reviewed at an administrative level, and we plan to vigorously oppose it as well as any future assessments. We are, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While we believe there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, we are unable to reasonably estimate a range of loss, if any. We do not expect final judicial determination on these claims for several years.

[0001047469-14-005069:notes:283]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. We defend ourselves vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in its consolidated balance sheet, would not be material to the financial statements as a whole.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001047469-14-005069:notes:284]
13. INCOME TAXES

[0001047469-14-005069:notes:285]
The domestic (Singapore) and foreign components of income from continuing operations before income taxes were comprised of the following:

[0001047469-14-005069:notes:286]
The provision for income taxes from continuing operations consisted of the following:

[0001047469-14-005069:notes:287]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2014, 2013 and 2012. The reconciliation of the income tax expense from continuing operations expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0001047469-14-005069:notes:288]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company's operations. The aggregate dollar effect on the Company's income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2014, 2013 and 2012 was $15.2 million, $22.6 million and $41.8 million, respectively. For the fiscal year ended March 31, 2014, the effect on basic and diluted earnings per share was $0.02 and $0.02, and the effect on basic and diluted earnings per share during fiscal years 2013 and 2012 were $0.03 and $0.03, and $0.06 and $0.06, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in the fiscal years ending March 31, 2015 through fiscal year 2022.

[0001047469-14-005069:notes:289]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore. The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years ended March 31, 2014, 2013 and 2012 were $51.5 million, $26.7 million and $17.7 million, respectively.

[0001047469-14-005069:notes:290]
The components of deferred income taxes are as follows:

[0001047469-14-005069:notes:291]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision. Approximately $34.0 million of the valuation allowance relates to income tax benefits arising from the exercise of stock options, which if realized will be credited directly to shareholders' equity and will not be available to benefit the income tax provision in any future period.

[0001047469-14-005069:notes:292]
The Company has recorded deferred tax assets of approximately $2.7 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $46.0 million of the deferred tax assets. These tax losses and other carryforwards, on a tax return basis, will expire at various dates as follows:

[0001047469-14-005069:notes:293]
|  |  | (In thousands) |  |
| 2015 - 2020 |  | $ | 279,204 |  |
| 2021 - 2026 |  |  | 1,001,767 |  |
| 2027 and post |  |  | 714,406 |  |
| Indefinite |  |  | 691,790 |  |
|  |  | $ | 2,687,167 |  |

[0001047469-14-005069:notes:294]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management's estimates.

[0001047469-14-005069:notes:295]
The Company does not provide for income taxes on approximately $779.0 million of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. Determination of the amount of the unrecognized deferred tax liability on these undistributed earnings is not practicable.

[0001047469-14-005069:notes:296]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0001047469-14-005069:notes:297]
The Company's unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an estimated range of $18 million to $37 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0001047469-14-005069:notes:298]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2003.

[0001047469-14-005069:notes:299]
Of the $243.9 million of unrecognized tax benefits at March 31, 2014, $166.3 million will affect the annual effective tax rate if the benefits are eventually recognized. The amount that does not impact the effective tax rate relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0001047469-14-005069:notes:300]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company's tax expense. During the fiscal years ended March 31, 2014 and 2013, the Company recognized interest and penalties of approximately $8.4 million and $5.1 million, respectively. The Company had approximately $15.6 million and $11.9 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2014 and 2013, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001047469-14-005069:notes:301]
14. RESTRUCTURING CHARGES

[0001047469-14-005069:notes:302]
The Company initiated certain restructuring activities during fiscal years 2014 and 2013 intended to improve its operational efficiencies by reducing excess workforce and capacity and realign the corporate cost structure. Restructuring charges are recorded based upon employee termination dates, site closure and consolidation plans.

[0001047469-14-005069:notes:303]
Fiscal Year 2014

[0001047469-14-005069:notes:304]
During the fiscal year ended March 31, 2014, the Company recognized restructuring charges of approximately $75.3 million. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on equipment no longer in use and to be disposed of, and other exit related costs due to facility closures or rationalizations. Pre-tax restructuring charges comprised $73.4 million of cash charges predominantly related to employee severance and $1.9 million of non-cash charges related to impairment of long-lived assets. Employee severance costs were associated with the terminations of 6,758 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 5,073, 1,482 and 203 for Asia, the Americas and Europe, respectively.

[0001047469-14-005069:notes:305]
During the fiscal year ended March 31, 2014, the Company recognized approximately $66.7 million of severance costs related to employee terminations of which approximately $50.2 million was recognized in cost of sales.

[0001047469-14-005069:notes:306]
During the fiscal year ended March 31, 2014, the Company recognized approximately $1.9 million for the write-down of property and equipment, and was classified as a component of cost of sales. The property and equipment were sold as of March 31, 2014.

[0001047469-14-005069:notes:307]
During the fiscal year ended March 31, 2014, the Company recognized approximately $6.7 million of other exit costs, which primarily were comprised of $3.8 million related to personnel costs and $2.9 million of contractual obligations that resulted from facility closures. The majority of these costs were classified as a component of cost of sales.

[0001047469-14-005069:notes:308]
Fiscal Year 2013

[0001047469-14-005069:notes:309]
During the fiscal year ended March 31, 2013, the Company recognized restructuring charges of approximately $227.4 million, of which $110.1 million was associated with the terminations of 9,138 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 4,467, 2,282, and 2,389 for Asia, the Americas and Europe, respectively. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on facilities and equipment that are not recoverable through future cash flows or are no longer in use and are to be disposed of, and other exit related costs due to facility closures or rationalizations. Pre-tax restructuring charges comprised $123.0 million of cash charges predominantly related to employee severance costs and $104.4 million of non-cash charges primarily related asset impairment and other exit charges. The activities associated with these charges were completed by the first quarter of fiscal 2014.

[0001047469-14-005069:notes:310]
During the fiscal year ended March 31, 2013, the Company recognized approximately $110.1 million of severance costs related to employee terminations. Approximately $98.5 million of this was classified as a component of cost of sales for fiscal year 2013.

[0001047469-14-005069:notes:311]
During the fiscal year ended March 31, 2013, the Company recognized approximately $69.5 million for the write-down of property and equipment and other manufacturing assets. The majority of this amount was classified as a component of cost of sales.

[0001047469-14-005069:notes:312]
During the fiscal year ended March 31, 2013, the Company recognized approximately $47.9 million of other exit costs, which primarily were comprised of $22.8 million for the write-down of certain customer specific assets that were determined to be unrecoverable based on a specific product exit and resulting declining customer volumes. Additionally, for fiscal year 2013, other exit costs include $24.7 million of customer disengagement costs primarily related to inventory that resulted from a product exit as well as contractual obligations from facility closures.

[0001047469-14-005069:notes:313]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of March 31, 2014 for charges incurred in fiscal years 2014, 2013 and prior periods:


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001047469-14-005069:notes:314]
15. OTHER CHARGES (INCOME), NET

[0001047469-14-005069:notes:315]
During fiscal year 2014, the Company recognized $55.0 million of other charges for a contractual obligation to reimburse a customer for certain performance provisions as defined in the contract. Refer to note 12 to the consolidated financial statements for further discussion. Additionally, the Company exercised warrants to purchase common shares of a certain supplier and sold the underlying shares for total proceeds of $67.3 million resulting in a loss of $7.1 million. Further, the Company recognized a gain of $4.6 million on the sale of certain investments.

[0001047469-14-005069:notes:316]
During fiscal year 2013, the Company recognized a net gain of $74.4 million for the fair value adjustment of the warrants referred to above.

[0001047469-14-005069:notes:317]
During fiscal year 2012, the Company recognized a net gain of $20.0 million in connection with the sale of certain international entities.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001047469-14-005069:notes:318]
17. BUSINESS AND ASSET ACQUISITIONS

[0001047469-14-005069:notes:319]
Business Acquisitions

[0001047469-14-005069:notes:320]
The business and asset acquisitions described below were accounted for using the purchase method of accounting, and accordingly, the fair value of the net assets acquired and the results of the acquired businesses were included in the Company's consolidated financial statements from the acquisition dates forward. The Company has not finalized the allocation of the consideration for certain of its recently completed acquisitions and expects to complete these allocations within one year of the respective acquisition dates.

[0001047469-14-005069:notes:321]
Fiscal 2014 business acquisitions

[0001047469-14-005069:notes:322]
Acquisition of Google's Motorola Mobility LLC

[0001047469-14-005069:notes:323]
On April 16, 2013, the Company completed the acquisition of certain manufacturing operations from Google's Motorola Mobility LLC. The Company also entered into a manufacturing and services agreement with Motorola Mobility LLC for mobile devices in conjunction with this acquisition. This acquisition expanded the Company's relationship with Google's Motorola Mobility and the Company's capabilities in the mobile devices market. The results of operations were included in the Company's consolidated financial results beginning on the date of acquisition. Revenues were approximately 11.5% of total revenue for the fiscal year ended March 31, 2014. Income before tax of the acquired operations for the fiscal year ended March 31, 2014 was not significant to the consolidated financial results of the Company. On a pro forma basis, the estimated increase to our previously reported revenue amounts to reflect the acquisition of this business as of the first day of the prior comparative period is $3.3 billion for the year-ended March 31, 2013, and operating results for the same period was immaterial.

[0001047469-14-005069:notes:324]
The cash consideration for this acquisition amounted to $178.9 million. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001047469-14-005069:notes:325]
Acquisition of Riwisa AG

[0001047469-14-005069:notes:326]
On November 4, 2013, the Company acquired all of the outstanding shares of Riwisa AG, a company registered in Switzerland for total cash consideration of $44.0 million, net of cash acquired amounting to $9.4 million. This acquisition expanded the Company's capabilities in the medical devices market, particularly precision plastics. The Company primarily acquired inventory, property and equipment and assumed certain liabilities relating to payables and debt. The results of operations were included in the Company's consolidated financial results beginning on the date of acquisition. Proforma results of operations for this acquisition have not been presented because the effects of the acquisition were not material to the Company's consolidated financial results.

[0001047469-14-005069:notes:327]
The initial allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. Management is in the process of determining the fair value amounts for certain acquired real estate, which may also result in an offsetting adjustment to goodwill. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill. The Company recorded $22.7 million as intangible assets and $18.5 million as goodwill based on a preliminary assessment of fair value of assets acquired and liabilities assumed. Intangible assets are comprised of customer-relationships of $15.8 million amortized over a period of 10 years and developed technology and trade names of $6.9 million amortized over a period of 7 years.

[0001047469-14-005069:notes:328]
Adjustments made to the purchase price allocation in the fourth quarter of fiscal 2014 primarily related to an increase in identifiable intangible assets by approximately $2.2 million with a corresponding decrease to goodwill. This adjustment did not have a material impact on the Company's consolidated financial results of any prior period.

[0001047469-14-005069:notes:329]
Other business acquisitions

[0001047469-14-005069:notes:330]
Further, during fiscal 2014, the Company completed two other acquisitions for total cash consideration of $15.1 million. Neither of these acquisitions were significant to the Company's consolidated financial position, results of operations and cash flows. These businesses expanded the Company's capabilities primarily in manufacturing operations for precision plastics, components and molds. The Company acquired primarily property and equipment and inventory and recorded goodwill amounting to $5.0 million in connection with these acquisitions. The results of operations were included in the Company's consolidated financial results beginning on the dates of these acquisitions. Proforma results of operations for these acquisitions have not been presented because the effects of the acquisitions were immaterial to the Company's consolidated financial results. Additionally, transaction costs related to all acquisitions completed during the periods presented were immaterial to the Company's financial results.

[0001047469-14-005069:notes:331]
The Company continues to evaluate certain assets and liabilities related to business combinations completed during recent periods. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Changes to amounts recorded as assets or liabilities, as a result of such additional information, may result in a corresponding adjustment to goodwill.

[0001047469-14-005069:notes:332]
The goodwill generated from the Company's business combinations completed during the fiscal year ended March 31, 2014 is primarily related to value placed on the employee workforce, service offerings and capabilities, and expected synergies and is not deductible for income tax purposes.

[0001047469-14-005069:notes:333]
Fiscal 2013 business acquisitions

[0001047469-14-005069:notes:334]
Acquisition of Saturn Electronics and Engineering Inc.

[0001047469-14-005069:notes:335]
During fiscal year 2013, the Company completed its acquisition of all outstanding common stock of Saturn Electronics and Engineering, Inc. ("Saturn"), a supplier of electronics manufacturing services, solenoids and wiring for the automotive, appliance, consumer, energy and industrial markets. The acquisition of Saturn broadened the Company's service offering and strengthened its capabilities in the automotive and consumer electronics businesses. The results of operations were included in the Company's consolidated financial results beginning on the date of acquisition which amounted to approximately $100.9 million in revenue for the year ended March 31, 2013. Net income of the acquired business during the fiscal year ended March 31, 2013 was not significant to the consolidated operating results of the Company.

[0001047469-14-005069:notes:336]
The initial cash consideration for this acquisition amounted to $193.7 million with up to an additional $15.0 million of estimated potential contingent consideration, for a total purchase consideration of $208.7 million.

[0001047469-14-005069:notes:337]
The allocation of the purchase price to Saturn's tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. Management determined the value of acquired intangible assets with the assistance of a third-party appraisal firm. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001047469-14-005069:notes:338]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities assumed of Saturn (in thousands):

[0001047469-14-005069:notes:339]
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,191 |  |
| Accounts receivable |  |  | 44,879 |  |
| Inventories |  |  | 23,350 |  |
| Other current assets |  |  | 1,970 |  |
| Total current assets |  |  | 72,390 |  |
| Property and equipment |  |  | 40,392 |  |
| Goodwill |  |  | 102,725 |  |
| Other intangible assets |  |  | 57,200 |  |
| Other assets |  |  | 925 |  |
| Total assets |  | $ | 273,632 |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 29,616 |  |
| Other current liabilities |  |  | 1,740 |  |
| Total current liabilities |  |  | 31,356 |  |
| Other liabilities |  |  | 33,585 |  |
| Total aggregate purchase price |  | $ | 208,691 |  |

[0001047469-14-005069:notes:340]
Intangible assets of $57.2 million in connection with the Saturn acquisition is comprised of customer-relationships of $46.4 million and developed technology amounting to $10.8 million. Customer relationships are amortized over an estimated useful life of 5 years and developed technology is amortized over an estimated useful life of 7 years.

[0001047469-14-005069:notes:341]
Additionally, during fiscal year 2013, the Company completed three other acquisitions that were not individually, nor in the aggregate, significant to the Company's consolidated financial position, results of operations and cash flows. The total consideration, which was paid in cash for these acquisitions, and earn outs related to certain prior period acquisitions amounted to $72.7 million. The total amount of cash acquired from these acquisitions amounted to $80.1 million, resulting in net cash of $7.4 million acquired from these acquisitions during the fiscal year ended 2013. One of the acquired businesses expanded the Company's capabilities primarily in the medical and defense markets; another acquired business supports the hardware product manufacturing needs of an existing customer in the technology industry; and the other acquired business expanded the Company's capabilities primarily in the LED design and manufacturing market. The Company primarily acquired cash, inventory and certain other manufacturing assets, and recorded goodwill of $61.9 million in connection with these acquisitions. The aggregate results of operations for these acquisitions were included in the Company's consolidated financial results beginning on the dates of acquisition which amounted to approximately $231.3 million in revenue for the fiscal year ended March 31, 2013. Operating results of these acquisitions during fiscal year ended March 31, 2013 was not significant, individually or in the aggregate, to the consolidated operating results of the Company.

[0001047469-14-005069:notes:342]
In connection with one of the acquired businesses, the Company entered into an agreement with an existing customer and a third party banking institution to procure certain manufacturing assets to be financed by the third party banking institution acting as an agent of the customer. These assets will be used exclusively for the benefit of this customer and the terms of this agreement will reset annually. While the Company has the option to settle this obligation in cash in certain limited instances, the Company can also settle the obligation related to these assets by returning the respective assets to the customer and cannot be required to pay cash by either the customer or the third party banking institution to settle the obligation. Accordingly, these assets amounting to $267.5 million and $251.3 million and the liabilities amounting to $286.5 million and $272.8 million have been included in other current assets and other current liabilities, as of March 31, 2014 and 2013, respectively. The cash flows relating to the purchase of assets by the Company on behalf of the customer amounting to $37.3 million and $115.3 million have been included in other investing cash flows for the fiscal years ended March 31, 2014 and 2013, respectively. Net cash inflows amounting to $13.5 million and $101.9 million relating to the funding of these assets by the financial institution on behalf of the customer have been included in cash flows from other financing activities during the fiscal years ended March 31, 2014 and 2013, respectively.

[0001047469-14-005069:notes:343]
Fiscal 2012 business acquisitions

[0001047469-14-005069:notes:344]
During fiscal year 2012, the Company completed three acquisitions that were not individually, nor in the aggregate significant to the Company's financial position, results of operations and cash flows. The aggregate cash paid for these acquisitions together with cash paid for contingent consideration related to certain prior period acquisitions during the fiscal year ended March 31, 2012 totaled approximately $92.3 million, net of cash acquired. The acquired businesses expanded the Company's capabilities in the communications market. The Company primarily acquired inventory and certain other manufacturing assets and recorded goodwill of $8.6 million and customer-related intangibles of $3.9 million in connection with these acquisitions.


## us-gaap:TreasuryStockTextBlock

[0001047469-14-005069:notes:345]
18. SHARE REPURCHASE PLAN

[0001047469-14-005069:notes:346]
During fiscal year 2014, the Company repurchased approximately 59.5 million shares for an aggregate purchase value of approximately $468.8 million under two separate repurchase plans as further discussed below.

[0001047469-14-005069:notes:347]
During the second quarter of fiscal 2014, the Company repurchased the entire remaining amount under a prior share repurchase plan that was approved by the Company's Board of Directors on September 13, 2012 and the Company's shareholders at the 2012 Extraordinary General Meeting held on August 30, 2012, or approximately 35.3 million shares for an aggregate purchase value of approximately $259.3 million, and retired all of these shares.

[0001047469-14-005069:notes:348]
The Company's Board of Directors, on July 24, 2013, authorized the repurchase of up to 10% of the Company's outstanding ordinary shares which was approved by the Company's shareholders at the 2013 Extraordinary General Meeting held on July 29, 2013. Share repurchases by the Company under the share repurchase plans are subject to an aggregate limit of 10% of the Company's ordinary shares outstanding as of the date of the 2013 Extraordinary General Meeting. During fiscal year 2014, the Company repurchased approximately 24.2 million shares for an aggregate purchase value of approximately $209.5 million under this plan, including accrued expenses, and retired all of these shares. As of March 31, 2014, approximately 37.0 million shares were available to be repurchased under this plan.

[0001047469-14-005069:notes:349]
On September 30, 2013, the Singapore Companies Act was amended to increase the share repurchase limit for companies incorporated in Singapore, from 10% to 20% of their shares outstanding as of the most recent shareholder approval date, subject to the requirements under the Singapore Companies Act.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001047469-14-005069:notes:350]
19. SEGMENT REPORTING

[0001047469-14-005069:notes:351]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker, or decision making group, in deciding how to allocate resources and in assessing performance. The Company's chief operating decision maker is its Chief Executive Officer. As of March 31, 2014, the Company operates and internally manages a single operating segment, EMS.

[0001047469-14-005069:notes:352]
Geographic information is as follows:

[0001047469-14-005069:notes:353]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0001047469-14-005069:notes:354]
During fiscal years 2014, 2013 and 2012, net sales generated from Singapore, the principal country of domicile, were approximately $504.6 million, $551.7 million and $663.1 million, respectively.

[0001047469-14-005069:notes:355]
During fiscal year 2014, China, Mexico, and the United States accounted for approximately 40%, 14%, and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2014.

[0001047469-14-005069:notes:356]
During fiscal year 2013, China, Mexico, the United States and Malaysia accounted for approximately 35%, 15%, 11% and 10% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2013.

[0001047469-14-005069:notes:357]
During fiscal year 2012, China, Mexico, United States and Malaysia accounted for approximately 38%, 14%, 10% and 10% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2012.

[0001047469-14-005069:notes:358]
As of March 31, 2014 and 2013, long-lived assets held in Singapore were approximately $17.0 million and $15.9 million, respectively.

[0001047469-14-005069:notes:359]
As of March 31, 2014, China, the United States and Mexico accounted for approximately 41%, 16% and 14%, respectively, of consolidated long-lived assets. No other country accounted for more than 10% of long-lived assets as of March 31, 2014.

[0001047469-14-005069:notes:360]
As of March 31, 2013, China, Mexico, and the United States accounted for approximately 39%, 13% and 11%, respectively, of consolidated long-lived assets. No other country accounted for more than 10% of long-lived assets as of March 31, 2013.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001047469-14-005069:notes:361]
20. DISCONTINUED OPERATIONS

[0001047469-14-005069:notes:362]
During fiscal year 2013, the Company finalized the sale of two of its non-core businesses. Total proceeds received from these sales amounted to $27.2 million, net of $1.0 million of cash sold. The Company recognized an aggregate loss of $12.1 million on these sales, which is included in interest and other, net within the results from discontinued operations in fiscal 2013.

[0001047469-14-005069:notes:363]
In accordance with the accounting guidance, these non-core businesses qualify as discontinued operations, and accordingly, the Company has reported the results of operations and financial position of these businesses in discontinued operations within the consolidated statements of operations and the consolidated balance sheets for all periods presented as applicable.

[0001047469-14-005069:notes:364]
The results from discontinued operations were as follows:

[0001047469-14-005069:notes:365]
Interest and other, net for fiscal year 2013 include the loss on sale of the businesses discussed above.

[0001047469-14-005069:notes:366]
For the fiscal year ended March 31, 2014, there were no discontinued operations. As of March 31, 2014 and 2013, there were no assets or liabilities attributable to discontinued operations.


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001047469-14-005069:notes:367]
21. SUPPLEMENTAL GUARANTOR AND NON-GUARANTOR CONSOLIDATED FINANCIAL STATEMENTS

[0001047469-14-005069:notes:368]
Flextronics International Ltd. ("Parent") has two tranches of Notes of $500 million each outstanding, which mature on February 15, 2020 and February 15, 2023, respectively. These notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company's Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the notes are rated investment grade.

[0001047469-14-005069:notes:369]
In lieu of providing separate financial statements for the guarantor subsidiaries, the Company has included the accompanying condensed consolidating financial statements, which are presented using the equity method of accounting. The principal elimination entries relate to investment in subsidiaries and intercompany balances and transactions, including transactions with the Company's non-guarantor subsidiaries.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001047469-14-005069:notes:370]
22. QUARTERLY FINANCIAL DATA (UNAUDITED)

[0001047469-14-005069:notes:371]
The following table contains unaudited quarterly financial data for fiscal years 2014 and 2013. Earnings per share are computed independently for each quarter presented; therefore, the sum of the quarterly earnings per share may not equal the total earnings per share amounts for the fiscal year.

[0001047469-14-005069:notes:372]
The Company recorded restructuring charges during fiscal year 2014. The Company classified approximately $35.1 million and $23.5 million of these charges as a component of cost of sales during the first and fourth quarters of fiscal year 2014, respectively, and approximately $5.6 million and $11.1 million of these charges as a component of selling, general and administrative expenses during the first and fourth quarters of fiscal year 2014, respectively.

[0001047469-14-005069:notes:373]
The Company recorded restructuring charges during fiscal year 2013. The Company classified approximately $98.3 million and $117.5 million of these charges as a component of cost of sales during the third and fourth quarters of fiscal year 2013, respectively, and approximately $4.4 million and $7.2 million of these charges as a component of selling, general and administrative expenses during the third and fourth quarters of fiscal year 2013, respectively.

[0001047469-14-005069:notes:374]
The Company recognized a $23.0 million gain as a component of other charges (income), net in the three-month period ended September 28, 2012 for the cumulative fair value adjustment of the Company's warrants to purchase common shares of a supplier. These fully-vested warrants, which are derivative instruments, are to be fair valued at each reporting date with gains or losses from changes in fair value recognized in the statements of operations. The gain from changes in fair value recognized in the three-month period ended September 28, 2012 includes an out-of-period adjustment of $12.8 million and for the year ended March 31, 2013 includes an out-of-period adjustment of $5.7 million. Management believes the impact of the error is not material to current or prior fiscal periods.

[0001047469-14-005069:notes:375]
During the fourth quarter of fiscal 2013, the Company recognized an income tax benefit of $9.3 million that related to prior fiscal years, of which $6.1 million related to the fiscal year ended March 31, 2012 and $3.2 million related to years prior to fiscal 2012. Management believes the impact of this error is not material to any of the periods.
