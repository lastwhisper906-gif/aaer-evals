# FLEX MD&A — 0001047469-14-005069


## mdna

[0001047469-14-005069:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001047469-14-005069:mdna:2]
OVERVIEW

[0001047469-14-005069:mdna:3]
We are a globally-recognized leading provider of supply chain solutions that span from concept through consumption. We design, build,
ship and service a complete packaged electronic product for original equipment manufacturers ("OEMs") in the following business groups: High Reliability Solutions ("HRS"), which is comprised of our
medical, automotive, and defense and aerospace businesses; High Velocity Solutions ("HVS"), which includes our mobile devices business, including smart phones; our consumer electronics business,
including game consoles and wearable electronics; and our high-volume computing business, including various supply chain solutions for notebook personal computing ("PC"), tablets and printers;
Industrial and Emerging Industries ("IEI"), which is comprised of our household appliances, semi-cap equipment, kiosks, energy and emerging industries businesses; and Integrated Network Solutions
("INS"), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses.

[0001047469-14-005069:mdna:4]
Our
strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a
complete packaged product for our OEM customers. This enables our OEM customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001047469-14-005069:mdna:5]
During
the recent years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified
themselves as software providers, internet service providers or e-commerce retailers have started to enter the highly competitive and rapidly evolving hardware markets, such as mobile devices, home
entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more
complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0001047469-14-005069:mdna:6]
We
use a portfolio management approach to manage our extensive service offerings. As our OEM customers change in the way they go to market, we reorganize and rebalance our business
portfolio in order to align with our customers' needs and requirements and to optimize our operating results. With the acquisition of certain manufacturing operations from Google's Motorola
Mobility LLC during the first quarter of fiscal 2014, we have experienced an increase in the percentage of our revenues from the HVS business group, and expect the amount of revenue from our
HVS business group, relative to total revenue, to stabilize going forward. The objective of our operating model is to allow us to redeploy and

[0001047469-14-005069:mdna:7]
reposition
our assets and resources to meet specific customer needs across all of the markets we serve, and we have been able to successfully reposition our assets and capacity between various
business groups to serve our customers as required, which illustrates the overall flexibility of our model.

[0001047469-14-005069:mdna:8]
During
fiscal years 2013 and 2014, we launched multiple programs broadly across our portfolio of services, and, in some instances, we deployed certain new technologies. We expect that
these new programs will continue to increase in complexity in order to provide competitive advantages to our customers. We anticipate these programs will continue ramping with an increase in volume
production during fiscal year 2015 and beyond. Until we achieve such higher levels of revenue, we expect that our gross margin and operating margin may be negatively impacted as profitability normally
lags revenue growth due to incremental start-up costs, operational inefficiencies, under-absorbed overhead costs and lower manufacturing program volumes while in the ramp phase. We expect that our
margins for these programs will improve over time as the revenue increases due to increased volumes.

[0001047469-14-005069:mdna:9]
We
are one of the world's largest providers of global supply chain solutions, with revenues of $26.1 billion in fiscal year 2014. We have established an extensive network of
manufacturing facilities in the world's major electronics markets (Asia, the Americas and Europe) in order to serve the growing outsourcing needs of both multinational and regional OEMs. We
design, build, ship, and service electronics products for our customers through a network of facilities in approximately 30 countries across four continents. As of March 31, 2014, our total
manufacturing capacity was approximately 26.0 million square feet. In fiscal year 2014, our net sales in Asia, the Americas and Europe represented approximately 53%, 31% and 16%, respectively,
of our total net sales, based on the location of the manufacturing site. The following tables set forth net sales and net property and equipment, by country, based on the location of our manufacturing
sites and the relative percentages:

[0001047469-14-005069:mdna:10]
|  |  | Fiscal Year Ended March 31, |  |
| Net sales: |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | (In thousands) |  |
| China |  | $ | 10,521,169 |  |  | 40 | % | $ | 8,132,776 |  |  | 35 | % | $ | 11,212,310 |  |  | 38 | % |
| Mexico |  |  | 3,565,803 |  |  | 14 | % |  | 3,534,067 |  |  | 15 | % |  | 4,005,653 |  |  | 14 | % |
| U.S |  |  | 2,829,807 |  |  | 11 | % |  | 2,539,460 |  |  | 11 | % |  | 2,971,757 |  |  | 10 | % |
| Malaysia |  |  | 2,142,437 |  |  | 8 | % |  | 2,440,902 |  |  | 10 | % |  | 2,868,990 |  |  | 10 | % |
| Brazil |  |  | 1,699,209 |  |  | 6 | % |  | 1,023,790 |  |  | 4 | % |  | 1,269,203 |  |  | 4 | % |
| Other |  |  | 5,350,182 |  |  | 21 | % |  | 5,898,480 |  |  | 25 | % |  | 7,015,116 |  |  | 24 | % |
|  |  | $ | 26,108,607 |  |  |  |  | $ | 23,569,475 |  |  |  |  | $ | 29,343,029 |  |  |  |  |

[0001047469-14-005069:mdna:11]
|  |  | Fiscal Year Ended March 31, |  |
| Property and equipment, net: |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| China |  | $ | 941,850 |  |  | 41 | % | $ | 855,032 |  |  | 39 | % |
| U.S |  |  | 362,199 |  |  | 16 | % |  | 245,590 |  |  | 11 | % |
| Mexico |  |  | 326,287 |  |  | 14 | % |  | 286,026 |  |  | 13 | % |
| Malaysia |  |  | 153,194 |  |  | 7 | % |  | 152,594 |  |  | 7 | % |
| Hungary |  |  | 103,266 |  |  | 5 | % |  | 113,173 |  |  | 5 | % |
| Other |  |  | 401,860 |  |  | 17 | % |  | 522,173 |  |  | 25 | % |
|  |  | $ | 2,288,656 |  |  |  |  | $ | 2,174,588 |  |  |  |  |

[0001047469-14-005069:mdna:12]
We
believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant
scale and global presence, and industrial campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and
servicing

[0001047469-14-005069:mdna:13]
37

[0001047469-14-005069:mdna:14]
electronics
products for leading multinational and regional OEMs. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our OEM customers
the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to achieve meaningful time to market and cost savings.

[0001047469-14-005069:mdna:15]
Our
operating results are affected by a number of factors, including the following:

[0001047469-14-005069:mdna:16]
•

[0001047469-14-005069:mdna:17]
changes in the macro-economic environment and related changes in consumer demand;

[0001047469-14-005069:mdna:18]
•

[0001047469-14-005069:mdna:19]
the mix of the manufacturing services we are providing, the number and size of new manufacturing programs, the degree to
which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors;

[0001047469-14-005069:mdna:20]
•

[0001047469-14-005069:mdna:21]
the effects on our business when our customers are not successful in marketing their products, or when their products do
not gain widespread commercial acceptance;

[0001047469-14-005069:mdna:22]
•

[0001047469-14-005069:mdna:23]
our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the
performance specifications demanded by our OEM customers;

[0001047469-14-005069:mdna:24]
•

[0001047469-14-005069:mdna:25]
the effects on our business due to our customers' products having short product life cycles;

[0001047469-14-005069:mdna:26]
•

[0001047469-14-005069:mdna:27]
our customers' ability to cancel or delay orders or change production quantities;

[0001047469-14-005069:mdna:28]
•

[0001047469-14-005069:mdna:29]
our customers' decision to choose internal manufacturing instead of outsourcing for their product requirements;

[0001047469-14-005069:mdna:30]
•

[0001047469-14-005069:mdna:31]
our exposure to financially troubled customers;

[0001047469-14-005069:mdna:32]
•

[0001047469-14-005069:mdna:33]
integration of acquired businesses and facilities;

[0001047469-14-005069:mdna:34]
•

[0001047469-14-005069:mdna:35]
increased labor costs due to adverse labor conditions in the markets we operate; and

[0001047469-14-005069:mdna:36]
•

[0001047469-14-005069:mdna:37]
changes in tax legislation.

[0001047469-14-005069:mdna:38]
We
also are subject to other risks as outlined in Item 1A, "Risk Factors."

[0001047469-14-005069:mdna:39]
Net
revenues for fiscal year 2014 increased 10.8% or $2.5 billion to $26.1 billion. This increase was primarily attributable to our acquisition of certain manufacturing
operations from Google's Motorola Mobility LLC (Motorola), which was partially offset by the disengagement of our assembly activities with Blackberry during fiscal 2013, which contributed
revenue in that year of approximately $0.9 billion. Our revenue increased across all of the business groups we serve except for INS. Our fiscal year 2014 gross profit totaled
$1.4 billion, representing an increase of $274.0 million, or 23.5%, and our income from continuing operations totaled $365.6 million, representing an increase of
$63.1 million, compared to fiscal year 2013. Both gross profit and income from continuing operations increased primarily due to lower restructuring charges incurred during fiscal year 2014 as a
result of less cost reduction activities as compared to prior year. Additionally, the increase in income from continuing operations was partially offset by $55.0 million of other charges for a
contractual obligation for certain performance provisions as defined in an existing manufacturing agreement with a customer. Additionally, our income from continuing operations in fiscal year 2013
included a gain from the fair value adjustment of $74.4 million relating to warrants to purchase common shares of a supplier. These warrants were exercised and the underlying shares were sold
for total proceeds of $67.3 million resulting in a loss of $7.1 million that was recognized during fiscal 2014.

[0001047469-14-005069:mdna:40]
Cash
provided by operations increased approximately $101.0 million to $1.2 billion for fiscal year 2014 compared with $1.1 billion for fiscal year 2013 primarily due
to increased net income and to a lesser extent due to changes in operating assets and liabilities. Our average net working capital, defined as accounts receivable, including deferred purchase price
receivable from our asset-backed securitization programs plus inventory less accounts payable, as a percentage of annual sales was

[0001047469-14-005069:mdna:41]
38

[0001047469-14-005069:mdna:42]
approximately
6.8%, 7.8% and 6.2% for the years ended March 31, 2014, 2013 and 2012, respectively. The decrease in the percentage for the year ended March 31, 2014 is primarily
attributable to higher revenue from our HVS business which carries significantly higher inventory turns and customers with contractually shorter payment terms resulting in a decrease in our average
net working capital in fiscal year 2014. Our free cash flow, which we define as cash from operating activities less net purchases of property and equipment, was $701.5 million for fiscal year
2014 compared to $680.1 million for fiscal year 2013, primarily due to higher cash flows from operations partially offset by higher net capital expenditure. Refer to the Liquidity and Capital
Resources section for the free cash flows reconciliation to our most directly comparable GAAP financial measure of cash flows from operations. Cash used in financing activities amounted to
$410.8 million during fiscal year 2014 and included repurchases of approximately 60.7 million ordinary shares at an aggregate purchase value of $475.3 million. As of
March 31, 2014 and 2013, $5.5 million and $12.0 million was included in accrued expenses for approximately 0.6 million and 1.8 million ordinary shares, respectively,
that were not settled by the end of the year.

[0001047469-14-005069:mdna:43]
Additionally,
in response to a challenging macroeconomic environment, we initiated certain restructuring activities in fiscal years 2013 and 2014 intended to improve our operational
efficiencies by reducing excess workforce and capacity. The restructuring activities are intended to realign our corporate cost structure, and rationalize our global manufacturing capacity and
infrastructure which will result in a further shift of manufacturing capacity to locations with higher efficiencies. During the fiscal year ended March 31, 2014, we recognized
$75.3 million of pre-tax restructuring charges primarily comprised of $73.4 million of cash charges predominantly related to employee severance costs. During the fiscal year ended
March 31, 2013, we recognized $227.4 million of pre-tax restructuring charges comprised of $123.0 million of cash charges primarily related to employee severance costs and
$104.4 million of non-cash charges primarily related to asset impairment and other exit charges.

[0001047469-14-005069:mdna:44]
We
believe that our business transformation has strategically positioned us very well to take advantage of the long-term, future growth prospects for outsourcing of advanced
manufacturing capabilities, design and engineering services and after-market services, which remain strong.

[0001047469-14-005069:mdna:45]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001047469-14-005069:mdna:46]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America
("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at
the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results may differ from those estimates and assumptions.

[0001047469-14-005069:mdna:47]
We
believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further
discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0001047469-14-005069:mdna:48]
Revenue Recognition

[0001047469-14-005069:mdna:49]
We recognize manufacturing revenue when we ship goods or the goods are received by our customer, title and risk of ownership have
passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations
related to manufacturing services. If such requirements or obligations exist, then we recognize the related revenues at the time when such requirements are completed and the obligations are fulfilled.
Some of our customer contracts allow us to recover certain costs related to manufacturing services that are over and above the prices we charge for the related products. We determine the amount of
costs that are recoverable based on historical experiences and

[0001047469-14-005069:mdna:50]
39

[0001047469-14-005069:mdna:51]
agreements
with those customers. Also, certain customer contracts may contain certain commitments and obligations that may result in additional expenses or decrease in revenue. We accrue for these
commitments and obligations based on facts and circumstances and contractual terms. We also make provisions for estimated sales returns and other adjustments at the time revenue is recognized based
upon contractual terms and an analysis of historical returns. Provisions for sales returns and other adjustments were not material to our consolidated financial statements for any of the periods
presented.

[0001047469-14-005069:mdna:52]
We
provide a comprehensive suite of services for our customers that range from advanced product design to manufacturing and logistics to after-sales services. We recognize service
revenue when the services have been performed, and the related costs are expensed as incurred. Our net sales for services were less than 10% of our total sales for all periods presented, and
accordingly, are included in net sales in the consolidated statements of operations.

[0001047469-14-005069:mdna:53]
Customer Credit Risk

[0001047469-14-005069:mdna:54]
We have an established customer credit policy through which we manage customer credit exposures through credit evaluations, credit
limit setting, monitoring, and enforcement of credit limits for new and existing customers. We perform ongoing credit evaluations of our customers' financial condition and make provisions for doubtful
accounts based on the outcome of those credit evaluations. We evaluate the collectability of accounts receivable based on specific customer circumstances, current economic trends, historical
experience with collections and the age of past due receivables. To the extent we identify exposures as a result of credit or customer evaluations, we also review other customer related exposures,
including but not limited to inventory and related contractual obligations.

[0001047469-14-005069:mdna:55]
Restructuring Charges

[0001047469-14-005069:mdna:56]
We recognize restructuring charges related to our plans to close or consolidate excess manufacturing and administrative facilities and
to realign our corporate cost structure. In connection with these activities, we recognize restructuring charges for employee termination costs, long-lived asset impairment and other exit-related
costs.

[0001047469-14-005069:mdna:57]
The
recognition of these restructuring charges requires that we make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit
activity. To the extent our actual results differ from our estimates and assumptions, we may be required to revise the estimates of future liabilities, requiring the recognition of additional
restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each
reporting period, we evaluate the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with
developed exit plans.

[0001047469-14-005069:mdna:58]
Refer
to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0001047469-14-005069:mdna:59]
Carrying Value of Long-Lived Assets

[0001047469-14-005069:mdna:60]
We review property and equipment and acquired amortizable intangible assets for impairment whenever events or changes in circumstances
indicate that the carrying amount of the asset may not be recoverable. An impairment loss is recognized when the carrying amount of these long-lived assets exceeds their fair value. Recoverability of
property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such assets are
considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair
value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, general business environment and other
factors. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize additional impairment charges in the future.

[0001047469-14-005069:mdna:61]
40

[0001047469-14-005069:mdna:62]
Inventory Valuation

[0001047469-14-005069:mdna:63]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by
rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand, and we estimate write downs for excess and obsolete
inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our
customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers
and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regard to inventory procured to
fulfill customer demand.

[0001047469-14-005069:mdna:64]
Contingent Liabilities

[0001047469-14-005069:mdna:65]
We may be exposed to certain liabilities relating to our business operations, acquisitions of businesses and assets and other
activities. We make provisions for such liabilities when it is probable that the settlement of the liability will result in an outflow of economic resources or the impairment of an asset. We make
these assessments based on facts and circumstances that may change in the future resulting in additional expenses.

[0001047469-14-005069:mdna:66]
Income Taxes

[0001047469-14-005069:mdna:67]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and
liabilities which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it
is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future
profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be
required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.
