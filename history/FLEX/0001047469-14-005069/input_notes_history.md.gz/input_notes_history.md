# FLEX note change history — 0001104659-13-080056 → 0001104659-14-005587


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2014-01-31):
[0001104659-14-005587:note_history:1]
Litigation and other legal matters

- added (2014-01-31):
[0001104659-14-005587:note_history:2]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International, Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431).  The complaint asserts various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products.  The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys’ fees and costs.  The plaintiff also seeks a jury trial.  The Company is investigating the allegations and is unable to estimate a range of reasonably possible losses in this matter at this time.

- changed (2014-01-31):
[0001104659-14-005587:note_history:3]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business including tax assessments. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in its condensed consolidated balance sheets would not be material to the financial statements as a whole.
  (was, 2013-11-01, similarity 0.7482):
[0001104659-13-080056:note_history:3]
From time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in its condensed consolidated balance sheets, would not be material to the financial statements as a whole.

- removed (2014-01-31):
[0001104659-13-080056:note_history:4]
On October 31, 2013, the Mexican government approved significant tax reform legislation.  The Company is still assessing the impact of this reform, however, the resulting changes could have a material impact to the future income tax expense of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-01-31):
[0001104659-14-005587:note_history:5]
Flextronics International Ltd. (“Flextronics” or the “Company”) was incorporated in the Republic of Singapore in May 1990. The Company’s operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a leading global supply chain solutions provider of advanced design, manufacturing and services to original equipment manufacturers (“OEMs”) of a broad range of electronic products serving customers in the following markets: High Reliability Solutions (“HRS”), which is comprised of our medical, automotive, and defense and aerospace businesses; High Velocity Solutions (“HVS”), which includes our mobile devices business, including smart phones, and consumer electronics, including game consoles and wearable electronics, and our high-volume computing business, including various supply chain solutions for notebook personal computing (“PC”), tablets, and printers; Industrial and Emerging Industries (“IEI”), which is comprised of household appliances, semi-cap equipment, kiosks, energy and our emerging industries businesses; and Integrated Network Solutions (“INS”), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses. The Company’s strategy is to provide customers with a full range of cost competitive, global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. OEM customers leverage the Company’s supply chain solutions to meet their product requirements throughout the entire product life cycle.
  (was, 2013-11-01, similarity 0.8811):
[0001104659-13-080056:note_history:5]
Flextronics International Ltd. (“Flextronics” or the “Company”) was incorporated in the Republic of Singapore in May 1990. The Company’s operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a leading global provider of advanced design, manufacturing and services to original equipment manufacturers (“OEMs”) of a broad range of electronic products serving customers in the following markets: High Reliability Solutions (“HRS”), which is comprised of our medical, automotive, and defense and aerospace businesses; High Velocity Solutions (“HVS”), which includes our mobile devices business, including smart phones, and consumer electronics, including game consoles, high-volume computing business, including notebook personal computing (“PC”), tablets, and printers; Industrial and Emerging Industries (“IEI”), which is comprised of household appliances, semi-cap equipment, energy and our emerging industries businesses; and Integrated Network Solutions (“INS”), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses. The Company’s strategy is to provide customers with a full range of cost competitive, global supply chain services through which the Company can design, build, ship and service a complete packaged product for its OEM customers. OEM customers leverage the Company’s services to meet their product requirements throughout the entire product life cycle.

- added (2014-01-31):
[0001104659-14-005587:note_history:6]
The Company’s service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement,  inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings like rigid and flexible printed circuit boards and power adapters and chargers.

- changed (2014-01-31):
[0001104659-14-005587:note_history:7]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2013 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and nine-month periods ended December 31, 2013 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2014.
  (was, 2013-11-01, similarity 0.9928):
[0001104659-13-080056:note_history:7]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2013 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and six-month periods ended September 27, 2013 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2014.

- added (2014-01-31):
[0001104659-14-005587:note_history:8]
During the fourth quarter of fiscal 2013, the Company recorded certain purchase accounting adjustments in connection with an acquisition of a business that was consummated in the third quarter of fiscal 2013.  These purchase accounting adjustments resulted in the release of $22.3 million of valuation allowances for deferred tax assets. In accordance with the accounting guidance applicable to business combinations, the Company re-casted the operating results for the quarter ended December 31, 2012 to reflect the release of the valuation allowance for deferred tax assets.

- changed (2014-01-31):
[0001104659-14-005587:note_history:9]
The first quarter for fiscal year 2014 and fiscal year 2013 ended on June 28, 2013 and June 29, 2012, respectively. The second quarter for fiscal year 2014 and fiscal year 2013 ended on September 27, 2013 and September 28, 2012, respectively. The Company’s third fiscal quarter ends on December 31, and the fourth fiscal quarter, and year, ends on March 31 of each year.
  (was, 2013-11-01, similarity 0.7689):
[0001104659-13-080056:note_history:9]
The first quarter for fiscal year 2014 and fiscal year 2013 ended on June 28, 2013 and June 29, 2012, respectively. The second quarter for fiscal year 2014 and fiscal year 2013 ended on September 27, 2013 and September 28, 2012, respectively.

- removed (2014-01-31):
[0001104659-13-080056:note_history:10]
The Company’s service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to , manufacturing (including enclosures, metals, and plastics), system integration and assembly and test services, materials procurement,  inventory management), logistics, and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings like rigid and flexible printed circuit boards and power adapters and chargers.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-01-31):
[0001104659-14-005587:note_history:11]
|  |  | As of |  | As of |  |
|  |  | December 31, 2013 |  | March 31, 2013 |  |
|  |  | (In thousands) |  |
| Term Loan, including current portion, due October 2014 |  | $ | — |  | $ | 170,340 |  |
| Term Loan, including current portion, due in installments through October 2016 |  | 436,641 |  | 517,500 |  |
| Term Loan, including current portion, due in installments through August 2018 |  | 600,000 |  | — |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 500,000 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 500,000 |  |
| Asia Term Loans |  | — |  | 375,000 |  |
| Other |  | 19,004 |  | 4,787 |  |
|  |  | 2,055,645 |  | 2,067,627 |  |
| Current portion |  | (54,951 | ) | (416,654 | ) |
| Non-current portion |  | $ | 2,000,694 |  | $ | 1,650,973 |  |

- changed (2014-01-31):
[0001104659-14-005587:note_history:12]
The weighted average interest rates for the Company’s long-term debt were 3.2% and 3.5% as of December 31, 2013 and March 31, 2013, respectively.
  (was, 2013-11-01, similarity 0.9808):
[0001104659-13-080056:note_history:12]
The weighted average interest rates for the Company’s long-term debt were 3.3% and 3.5% as of September 27, 2013 and March 31, 2013, respectively.

- changed (2014-01-31):
[0001104659-14-005587:note_history:13]
The term loan due August 2018 is unsecured, and contains customary restrictions on the Company’s and its subsidiaries’ ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2013, the Company was in compliance with the covenants under this term loan agreement.
  (was, 2013-11-01, similarity 0.9684):
[0001104659-13-080056:note_history:13]
This term loan agreement is unsecured, and contains customary restrictions on the Company’s and its subsidiaries’ ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of September 27, 2013, the Company was in compliance with the covenants under this term loan agreement.

- changed (2014-01-31):
[0001104659-14-005587:note_history:14]
Repayments of the Company’s long term debt outstanding as of December 31, 2013 are as follows:
  (was, 2013-11-01, similarity 0.9721):
[0001104659-13-080056:note_history:14]
Repayments of the Company’s long term debt outstanding as of September 27, 2013 are as follows:

- changed (2014-01-31):
[0001104659-14-005587:note_history:15]
(1)                     Represents scheduled repayments for the remaining three-month period ending March 31, 2014.
  (was, 2013-11-01, similarity 0.9545):
[0001104659-13-080056:note_history:15]
(1)       Represents scheduled repayments for the remaining six-month period ending March 31, 2014.

- removed (2014-01-31):
[0001104659-13-080056:note_history:16]
|  |  | As of |  | As of |  |
|  |  | September 27, 2013 |  | March 31, 2013 |  |
|  |  | (In thousands) |  |
| 4.625% Notes due February 2020 |  | $ | 500,000 |  | $ | 500,000 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 500,000 |  |
| Term Loan, including current portion, due October 2014 |  | — |  | 170,340 |  |
| Term Loan, including current portion, due in installments through October 2016 |  | 452,065 |  | 517,500 |  |
| Term Loan, including current portion, due in installments through August 2018 |  | 600,000 |  | — |  |
| Asia Term Loans |  | — |  | 375,000 |  |
| Other |  | 5,068 |  | 4,787 |  |
|  |  | 2,057,133 |  | 2,067,627 |  |
| Current portion |  | (43,427 | ) | (416,654 | ) |
| Non-current portion |  | $ | 2,013,706 |  | $ | 1,650,973 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-01-31):
[0001104659-14-005587:note_history:17]
|  |  | As of December 31, 2013 |  | As of March 31, 2013 |  |  |  |
|  |  | Carrying |  | Fair |  | Carrying |  | Fair |  | Fair Value |  |
|  |  | Amount |  | Value |  | Amount |  | Value |  | Hierarchy |  |
|  |  | (In thousands) |  |  |  |
| Term Loan, including current portion, due October 2014 |  | $ | — |  | $ | — |  | $ | 170,340 |  | $ | 170,496 |  | Level 1 |  |
| Term Loan, including current portion, due in installments through October 2016 |  | 436,641 |  | 435,824 |  | 517,500 |  | 518,794 |  | Level 1 |  |
| Term Loan, including current portion, due in installments through August 2018 |  | 600,000 |  | 591,000 |  | — |  | — |  | Level 1 |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 502,350 |  | 500,000 |  | 507,190 |  | Level 1 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 472,250 |  | 500,000 |  | 500,000 |  | Level 1 |  |
| Asia Term Loans |  | — |  | — |  | 375,000 |  | 375,343 |  | Level 2 |  |
| Total |  | $ | 2,036,641 |  | $ | 2,001,424 |  | $ | 2,062,840 |  | $ | 2,071,823 |  |  |  |

- removed (2014-01-31):
[0001104659-13-080056:note_history:18]
|  |  | As of September 27, 2013 |  | As of March 31, 2013 |  |  |  |
|  |  | Carrying |  | Fair |  | Carrying |  | Fair |  | Fair Value |  |
|  |  | Amount |  | Value |  | Amount |  | Value |  | Hierarchy |  |
|  |  | (In thousands) |  |  |  |
| Term loan dated October 1, 2007 |  | $ | — |  | $ | — |  | $ | 170,340 |  | $ | 170,496 |  | Level 1 |  |
| Term loan dated October 19, 2011 |  | 452,065 |  | 449,524 |  | 517,500 |  | 518,794 |  | Level 1 |  |
| 4.625% Notes dated February 20, 2013 (due 2020) |  | 500,000 |  | 497,500 |  | 500,000 |  | 507,190 |  | Level 1 |  |
| 5.000% Notes dated February 20, 2013 (due 2023) |  | 500,000 |  | 480,000 |  | 500,000 |  | 500,000 |  | Level 1 |  |
| Term loan dated August 30, 2013 (due 2018) |  | 600,000 |  | 585,378 |  | — |  | — |  | Level 1 |  |
| Asia term loans |  | — |  | — |  | 375,000 |  | 375,343 |  | Level 2 |  |
| Total |  | $ | 2,052,065 |  | $ | 2,012,402 |  | $ | 2,062,840 |  | $ | 2,071,823 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-01-31):
[0001104659-14-005587:note_history:19]
|  |  | As of |  | As of |  |
|  |  | December 31, 2013 |  | March 31, 2013 |  |
|  |  | (In thousands) |  |
| Term Loan, including current portion, due October 2014 |  | $ | — |  | $ | 170,340 |  |
| Term Loan, including current portion, due in installments through October 2016 |  | 436,641 |  | 517,500 |  |
| Term Loan, including current portion, due in installments through August 2018 |  | 600,000 |  | — |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 500,000 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 500,000 |  |
| Asia Term Loans |  | — |  | 375,000 |  |
| Other |  | 19,004 |  | 4,787 |  |
|  |  | 2,055,645 |  | 2,067,627 |  |
| Current portion |  | (54,951 | ) | (416,654 | ) |
| Non-current portion |  | $ | 2,000,694 |  | $ | 1,650,973 |  |

- removed (2014-01-31):
[0001104659-13-080056:note_history:20]
|  |  | As of |  | As of |  |
|  |  | September 27, 2013 |  | March 31, 2013 |  |
|  |  | (In thousands) |  |
| 4.625% Notes due February 2020 |  | $ | 500,000 |  | $ | 500,000 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 500,000 |  |
| Term Loan, including current portion, due October 2014 |  | — |  | 170,340 |  |
| Term Loan, including current portion, due in installments through October 2016 |  | 452,065 |  | 517,500 |  |
| Term Loan, including current portion, due in installments through August 2018 |  | 600,000 |  | — |  |
| Asia Term Loans |  | — |  | 375,000 |  |
| Other |  | 5,068 |  | 4,787 |  |
|  |  | 2,057,133 |  | 2,067,627 |  |
| Current portion |  | (43,427 | ) | (416,654 | ) |
| Non-current portion |  | $ | 2,013,706 |  | $ | 1,650,973 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-01-31):
[0001104659-14-005587:note_history:21]
(1)                     Represents scheduled repayments for the remaining three-month period ending March 31, 2014.
  (was, 2013-11-01, similarity 0.9545):
[0001104659-13-080056:note_history:21]
(1)       Represents scheduled repayments for the remaining six-month period ending March 31, 2014.
