# FLEX MD&A — 0001104659-14-075227


## mdna

[0001104659-14-075227:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001104659-14-075227:mdna:2]
[same as prior period, unchanged from 0001104659-14-054018:mdna:2]

[0001104659-14-075227:mdna:3]
[same as prior period, unchanged from 0001104659-14-054018:mdna:3]

[0001104659-14-075227:mdna:4]
We are a globally-recognized leading provider of supply chain solutions that span from concept through consumption. We design, build, ship and service complete packaged electronic products for original equipment manufacturers (“OEMs”) in the following business groups: High Reliability Solutions (“HRS”), which is comprised of our medical, automotive, and defense and aerospace businesses; Consumer Technology Group (“CTG”), which includes our mobile devices business, including smart phones; our consumer electronics business, including game consoles and wearable electronics; and our high-volume computing business, including various supply chain solutions for notebook personal computing (“PC”), tablets, and printers; Industrial and Emerging Industries (“IEI”), which is comprised of our household appliances, semi-cap equipment, kiosks, energy and emerging industries businesses; and Integrated Network Solutions (“INS”), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses.

[0001104659-14-075227:mdna:5]
[same as prior period, unchanged from 0001104659-14-054018:mdna:5]

[0001104659-14-075227:mdna:6]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, internet service providers or e-commerce retailers have started to enter the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0001104659-14-075227:mdna:7]
We use a portfolio management approach to manage our extensive service offerings. As our OEM customers change the way they go to market, we are able to reorganize and rebalance our business portfolio in order to align with our customers’ needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customer’s supply chain solutions across all of the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0001104659-14-075227:mdna:8]
During fiscal year 2014, we launched multiple programs broadly across our portfolio of services and, in some instances, we deployed certain new technologies.  We expect that these new programs will continue to increase in complexity in order to provide competitive advantages to our customers.  We anticipate these programs will continue ramping with an increase in volume production during fiscal year 2015 and beyond.  Until we achieve such higher levels of revenue, we expect that our gross margin and operating margin may be negatively impacted as profitability normally lags revenue growth due to incremental start-up costs, operational inefficiencies, under-absorbed overhead costs and lower manufacturing program volumes while in the ramp phase.  We expect that our margins for these programs will improve over time as the revenue increases due to increased volumes and certain cost control measures.

[0001104659-14-075227:mdna:9]
We are one of the world’s largest providers of global supply chain solutions, with revenues of $13.2 billion for the six-month period ended September 26, 2014 and $26.1 billion in fiscal year 2014.  We have established an extensive network of manufacturing facilities in the world’s major electronics markets (Asia, the Americas and Europe) in order to serve the growing outsourcing needs of both multinational and regional OEMs. We design, build, ship and service electronics products for our customers through a network of facilities in approximately 30 countries across four continents.  As of September 26, 2014, our total manufacturing capacity was approximately 25.0 million square feet.  The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0001104659-14-075227:mdna:10]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |  |
| Net sales: |  | September 26, 2014 |  | September 27, 2013 |  | September 26, 2014 |  | September 27, 2013 |  |
|  |  | (In thousands) |  | (In thousands) |  |
| China |  | $ | 2,476,736 |  | 38 | % | $ | 2,513,539 |  | 39 | % | $ | 5,026,967 |  | 38 | % | $ | 4,648,581 |  | 38 | % |
| Mexico |  | 876,339 |  | 13 | % | 899,752 |  | 14 | % | 1,725,937 |  | 13 | % | 1,777,225 |  | 15 | % |
| U.S |  | 689,737 |  | 11 | % | 706,346 |  | 11 | % | 1,444,457 |  | 11 | % | 1,347,132 |  | 11 | % |
| Malaysia |  | 560,849 |  | 9 | % | 562,071 |  | 9 | % | 1,101,961 |  | 8 | % | 1,097,690 |  | 9 | % |
| Brazil |  | 545,384 |  | 8 | % | 388,956 |  | 6 | % | 1,142,031 |  | 9 | % | 719,550 |  | 6 | % |
| Other |  | 1,379,472 |  | 21 | % | 1,339,442 |  | 21 | % | 2,729,909 |  | 21 | % | 2,611,053 |  | 21 | % |
|  |  | $ | 6,528,517 |  |  |  | $ | 6,410,106 |  |  |  | $ | 13,171,262 |  |  |  | $ | 12,201,231 |  |  |  |

[0001104659-14-075227:mdna:11]
|  |  | As of |  | As of |  |
| Property and equipment, net: |  | September 26, 2014 |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| China |  | $ | 835,028 |  | 38 | % | $ | 941,850 |  | 41 | % |
| U.S |  | 360,479 |  | 16 | % | 362,199 |  | 16 | % |
| Mexico |  | 290,525 |  | 13 | % | 326,287 |  | 14 | % |
| Malaysia |  | 156,803 |  | 7 | % | 153,194 |  | 7 | % |
| Brazil |  | 98,502 |  | 4 | % | 88,867 |  | 4 | % |
| Other |  | 452,629 |  | 22 | % | 416,259 |  | 18 | % |
|  |  | $ | 2,193,966 |  |  |  | $ | 2,288,656 |  |  |  |

[0001104659-14-075227:mdna:12]
[same as prior period, unchanged from 0001104659-14-054018:mdna:13]

[0001104659-14-075227:mdna:13]
[same as prior period, unchanged from 0001104659-14-054018:mdna:14]

[0001104659-14-075227:mdna:14]
[same as prior period, unchanged from 0001104659-14-054018:mdna:15]

[0001104659-14-075227:mdna:15]
[same as prior period, unchanged from 0001104659-14-054018:mdna:16]

[0001104659-14-075227:mdna:16]
[same as prior period, unchanged from 0001104659-14-054018:mdna:17]

[0001104659-14-075227:mdna:17]
[same as prior period, unchanged from 0001104659-14-054018:mdna:18]

[0001104659-14-075227:mdna:18]
[same as prior period, unchanged from 0001104659-14-054018:mdna:19]

[0001104659-14-075227:mdna:19]
[same as prior period, unchanged from 0001104659-14-054018:mdna:20]

[0001104659-14-075227:mdna:20]
[same as prior period, unchanged from 0001104659-14-054018:mdna:21]

[0001104659-14-075227:mdna:21]
[same as prior period, unchanged from 0001104659-14-054018:mdna:22]

[0001104659-14-075227:mdna:22]
[same as prior period, unchanged from 0001104659-14-054018:mdna:23]

[0001104659-14-075227:mdna:23]
[same as prior period, unchanged from 0001104659-14-054018:mdna:24]

[0001104659-14-075227:mdna:24]
[same as prior period, unchanged from 0001104659-14-054018:mdna:25]

[0001104659-14-075227:mdna:25]
[same as prior period, unchanged from 0001104659-14-054018:mdna:26]

[0001104659-14-075227:mdna:26]
[same as prior period, unchanged from 0001104659-14-054018:mdna:27]

[0001104659-14-075227:mdna:27]
[same as prior period, unchanged from 0001104659-14-054018:mdna:28]

[0001104659-14-075227:mdna:28]
[same as prior period, unchanged from 0001104659-14-054018:mdna:29]

[0001104659-14-075227:mdna:29]
[same as prior period, unchanged from 0001104659-14-054018:mdna:30]

[0001104659-14-075227:mdna:30]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |  |
|  |  | September 26, 2014 |  | September 27, 2013 |  | September 26, 2014 |  | September 27, 2013 |  |
| Net sales |  | 100.0 | % | 100.0 | % | 100.0 | % | 100.0 | % |
| Cost of sales |  | 94.2 |  | 94.3 |  | 94.2 |  | 94.4 |  |
| Gross profit |  | 5.8 |  | 5.7 |  | 5.8 |  | 5.6 |  |
| Selling, general and administrative expenses |  | 3.1 |  | 3.4 |  | 3.1 |  | 3.6 |  |
| Intangible amortization |  | 0.1 |  | 0.1 |  | 0.1 |  | 0.1 |  |
| Interest and other, net |  | 0.2 |  | 0.2 |  | 0.2 |  | 0.2 |  |
| Other charges (income), net |  | — |  | — |  | (0.3 | ) | 0.1 |  |
| Income before income taxes |  | 2.4 |  | 2.0 |  | 2.7 |  | 1.6 |  |
| Provision for income taxes |  | 0.2 |  | 0.2 |  | 0.2 |  | 0.1 |  |
| Net income |  | 2.2 | % | 1.8 | % | 2.5 | % | 1.5 | % |

[0001104659-14-075227:mdna:31]
[same as prior period, unchanged from 0001104659-14-054018:mdna:32]

[0001104659-14-075227:mdna:32]
[same as prior period, unchanged from 0001104659-14-054018:mdna:33]

[0001104659-14-075227:mdna:33]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |  |
| Business groups: |  | September 26, 2014 |  | September 27, 2013 |  | September 26, 2014 |  | September 27, 2013 |  |
|  |  | (In thousands) |  | (In thousands) |  |
| Integrated Network Solutions |  | $ | 2,408,899 |  | 37 | % | $ | 2,587,528 |  | 40 | % | $ | 4,911,394 |  | 37 | % | $ | 5,119,673 |  | 42 | % |
| Consumer Technology Group |  | 2,141,444 |  | 33 | % | 2,097,495 |  | 33 | % | 4,301,577 |  | 33 | % | 3,643,978 |  | 30 | % |
| Industrial & Emerging Industries |  | 1,103,040 |  | 17 | % | 939,979 |  | 15 | % | 2,237,219 |  | 17 | % | 1,846,206 |  | 15 | % |
| High Reliability Solutions |  | 875,134 |  | 13 | % | 785,104 |  | 12 | % | 1,721,072 |  | 13 | % | 1,591,374 |  | 13 | % |
|  |  | $ | 6,528,517 |  |  |  | $ | 6,410,106 |  |  |  | $ | 13,171,262 |  |  |  | $ | 12,201,231 |  |  |  |

[0001104659-14-075227:mdna:34]
Net sales during the three-month and six-month periods ended September 26, 2014 totaled $6.5 billion and $13.2 billion, respectively.  Sales increased by approximately $0.1 billion, or 2%, and $1.0 billion, or 8% from $6.4 billion and $12.2 billion during the three-month and six-month periods ended September 27, 2013, respectively.  Revenue increased across all of our business groups, except for INS, which experienced a marginal decrease.

[0001104659-14-075227:mdna:35]
The increase in revenue from our IEI business group is primarily attributable to a broad increase across product categories, most notably in our energy business and in our household appliances businesses. The increased revenue from our HRS business group is primarily due to higher sales to our automotive customers as a result of an increased use of electronics throughout vehicles in areas such as in-car connectivity, LED lighting, and power management.  The increased revenue from our CTG business group is primarily as a result of our acquisition of certain manufacturing operations from Google’s Motorola Mobility LLC (Motorola) during the first quarter of fiscal 2014 and the business ramping up during the mid to latter part of fiscal 2014. These increases were offset by a

[0001104659-14-075227:mdna:36]
decrease in revenue in our INS business group amounting to $0.2 billion for both the three-month and six-month periods ended September 26, 2014 primarily attributable to broad softness in our connected home and telecom businesses.

[0001104659-14-075227:mdna:37]
For the three-month and six-month periods ended September 26, 2014, net sales increased $100.1 million to $2.1 billion and $450.4 million to $4.3 billion in the Americas, respectively, and increased $46.6 million to $1.1 billion and $115.1 million to $2.1 billion in Europe, respectively. Net sales in Asia decreased $28.3 million to $3.3 billion for the three-month period ended September 26, 2014, while increasing $404.6 million to $6.7 billion for the six-month period then ended.

[0001104659-14-075227:mdna:38]
Our ten largest customers during the three-month and six-month periods ended September 26, 2014 accounted for approximately 51% and 52% of net sales, respectively. Google (including Motorola) accounted for more than 10% of net sales during the three-month and six-month periods ended September 26, 2014. Our ten largest customers during the three-month and six-month periods ended September 27, 2013 accounted for approximately 52% and 50% of net sales, respectively. Google (including Motorola) accounted for more than 10% of net sales during the three-month period ended September 27, 2013. No single customer accounted for greater than 10% of our net sales during the six-month period ended September 27, 2013.

[0001104659-14-075227:mdna:39]
[same as prior period, unchanged from 0001104659-14-054018:mdna:38]

[0001104659-14-075227:mdna:40]
[same as prior period, unchanged from 0001104659-14-054018:mdna:39]

[0001104659-14-075227:mdna:41]
Gross profit during the three-month period ended September 26, 2014 increased $8.7 million to $377.1 million, or 5.8% of net sales from $368.4 million, or 5.7% of net sales, during the three-month period ended September 27, 2013. Gross profit during the six-month period ended September 26, 2014 increased $78.4 million to $757.9 million, or 5.8% of net sales from $679.5 million, or 5.6% of net sales, during the six-month period ended September 27, 2013.  Gross margins improved 10 basis points and 20 basis points in the three-month and six-month periods ended September 26, 2014 compared to that of the three-month and six-month periods ended September 27, 2013 primarily as a result of increased revenues and favorable product mix from our higher margin business groups such as IEI and HRS coupled with benefits of an improved cost structure following our restructuring activities completed in fiscal year 2014.

[0001104659-14-075227:mdna:42]
[same as prior period, unchanged from 0001104659-14-054018:mdna:41]

[0001104659-14-075227:mdna:43]
Selling, general and administrative expenses (“SG&A”) amounted to $204.6 million, or 3.1% of net sales, during the three-month period ended September 26, 2014, decreasing $13.9 million from $218.5 million, or 3.4% of net sales, during the three-month period ended September 27, 2013. SG&A was $413.9 million, or 3.1% of net sales, during the six-month period ended September 26, 2014, decreasing $28.3 million from $442.1 million, or 3.6% of net sales, during the six-month period ended September 27, 2013.  Our SG&A expenses decreased in the current year periods, both in dollars and as a percentage of revenue, primarily as a result of certain cost reduction and rationalization measures that we undertook in the prior fiscal year.

[0001104659-14-075227:mdna:44]
[same as prior period, unchanged from 0001104659-14-054018:mdna:43]

[0001104659-14-075227:mdna:45]
Amortization of intangible assets increased by $0.5 million during the three-month period ended September 26, 2014 to $8.2 million from $7.7 million for the three-month period ended September 27, 2013 primarily due to incremental amortization expenses on intangible assets relating to our acquisitions completed during the latter part of fiscal 2014 and during fiscal 2015, as well as the purchase of certain technology rights during fiscal 2015 as further discussed in note 2 to the condensed consolidated financial statements.

[0001104659-14-075227:mdna:46]
Amortization of intangible assets decreased by $0.7 million during the six-month period ended September 26, 2014 to $15.2 million from $15.9 million for the six-month period ended September 27, 2013 primarily due to certain high value intangible assets that were fully amortized during fiscal year 2014, resulting in lower amortization expense during the current fiscal year. The decrease was offset by incremental intangible amortization expense in connection with our recent acquisitions, as well as the purchase of certain technology rights as discussed above.

[0001104659-14-075227:mdna:47]
[same as prior period, unchanged from 0001104659-14-054018:mdna:45]

[0001104659-14-075227:mdna:48]
Interest and other, net was $12.5 million during the three-month period ended September 26, 2014 compared to $14.6 million during the three-month period ended September 27, 2013. The decrease in interest and other, net of $2.1 million was primarily due to an increase in foreign currency gains in the current period mainly associated with the strength of the Chinese renminbi (“RMB”) combined with lower interest on our debt facilities that were refinanced during the period ended September 27, 2013 and in the later part of fiscal 2014.

[0001104659-14-075227:mdna:49]
Interest and other, net was $31.1 million during the six-month period ended September 26, 2014 compared to $27.2 million during the six-month period ended September 27, 2013. The increase in interest and other, net of $3.9 million was primarily due to a decrease in foreign currency gains as a result of losses incurred during the first quarter of fiscal 2015 associated with the weakened Chinese RMB during that period, partially offset by an increase in income of $6.0 million during the six-month period ended September 27, 2013 relating to the fair value adjustment of contingent consideration in connection with certain insignificant business acquisitions, and a decrease in interest expense as a result of refinancing of certain debt facilities as described above.

[0001104659-14-075227:mdna:50]
[same as prior period, unchanged from 0001104659-14-054018:mdna:47]

[0001104659-14-075227:mdna:51]
[same as prior period, unchanged from 0001104659-14-054018:mdna:48]

[0001104659-14-075227:mdna:52]
Other income, net remained relatively consistent for the three-month periods ended September 26, 2014 and September 27, 2013, respectively.

[0001104659-14-075227:mdna:53]
Other income, net was $46.6 million during the six-month period ended September 26, 2014 principally as a result of the reversal of a contractual obligation with a certain customer recognized during the fourth quarter of fiscal 2014 in the amount of $55.0 million.  We executed an amendment to the customer contract during the first quarter of fiscal year 2015 which relieved us of this contractual commitment.  This was partially offset by an $11.0 million loss in connection with the disposition of a manufacturing facility in Western Europe.

[0001104659-14-075227:mdna:54]
During the six-month period ended September 27, 2013, we recognized a loss of $7.1 million relating to the exercise of a warrant to purchase shares of a certain supplier and sale of the underlying shares for total proceeds of $67.3 million.

[0001104659-14-075227:mdna:55]
[same as prior period, unchanged from 0001104659-14-054018:mdna:52]

[0001104659-14-075227:mdna:56]
[same as prior period, unchanged from 0001104659-14-054018:mdna:53]

[0001104659-14-075227:mdna:57]
[same as prior period, unchanged from 0001104659-14-054018:mdna:54]

[0001104659-14-075227:mdna:58]
The consolidated effective tax rate was 10.0% and 9.1% for the three and six-month periods ended September 26, 2014, respectively, and 8.1% and 5.7% for the three and six-month periods ended September 27, 2013, respectively.  The consolidated effective tax rate varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions, operating loss carryforwards, income tax credits, previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. We generate most of our revenues and profits from operations outside of Singapore. The effective tax rate for the six-month period ended September 26, 2014 is higher than the effective tax rate for the six-month period ended September 27, 2013 primarily as a result of changes in various valuation allowance positions and a shift in jurisdictional mix of income to higher tax jurisdictions, partially offset by a net decrease in the liabilities for uncertain tax positions.

[0001104659-14-075227:mdna:59]
[same as prior period, unchanged from 0001104659-14-054018:mdna:56]

[0001104659-14-075227:mdna:60]
As of September 26, 2014, we had cash and cash equivalents of approximately $1.5 billion and bank and other borrowings of approximately $2.1 billion. We also have a $1.5 billion revolving credit facility that expires in March 2019, under which there were no borrowings outstanding as of the end of the quarter.  As of September 26, 2014, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0001104659-14-075227:mdna:61]
Cash provided by operating activities was $306.2 million during the six-month period ended September 26, 2014. This resulted primarily from $312.8 million of net income for the period plus $260.3 million of non-cash charges such as depreciation, amortization, and other impairment charges, offset by $266.9 million from changes in our operating assets and liabilities, which was mainly related

[0001104659-14-075227:mdna:62]
to reductions in customer deposits that were received in prior periods to support increased working capital requirements in those periods.

[0001104659-14-075227:mdna:63]
[same as prior period, unchanged from 0001104659-14-054018:mdna:59]

[0001104659-14-075227:mdna:64]
|  |  | Three-Month Periods Ended |  |
|  |  | September 26, 2014 |  | June 27, 2014 |  | March 31, 2014 |  | December 31, 2013 |  | September 27, 2013 |  |
| Days in trade accounts receivable |  | 44 days |  | 45 days |  | 42 days |  | 38 days |  | 42 days |  |
| Days in inventory |  | 53 days |  | 52 days |  | 54 days |  | 53 days |  | 53 days |  |
| Days in accounts payable |  | 70 days |  | 69 days |  | 70 days |  | 68 days |  | 71 days |  |
| Cash conversion cycle |  | 27 days |  | 28 days |  | 26 days |  | 23 days |  | 24 days |  |

[0001104659-14-075227:mdna:65]
Days in trade accounts receivable was calculated as average accounts receivable for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended September 26, 2014, days in trade accounts receivable increased by 2 days compared to the three-month period ended September 27, 2013 largely due to timing of invoicing customers during the current period.  Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $426.1 million, $463.1 million, $470.9 million, $528.8 million and $558.3 million for the quarters ended September 26, 2014, June 27, 2014, March 31, 2014, December 31, 2013 and September 27, 2013, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 9 to the condensed consolidated financial statements.

[0001104659-14-075227:mdna:66]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day.  Days in inventory remained consistent at 53 days for both the three-month periods ended September 26, 2014 and September 27, 2013.

[0001104659-14-075227:mdna:67]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable decreased by 1 day during the three-month period ended September 26, 2014, compared to the three-month period ended September 27, 2013 primarily due to timing of payments.

[0001104659-14-075227:mdna:68]
Our cash conversion cycle was calculated as the sum of days of inventory and days of accounts receivables outstanding less days payable outstanding.  During the three-month period ended September 26, 2014, our cash conversion cycle increased by 3 days compared to the three-month period ended September 27, 2013, due to the factors for each of the components in the calculation discussed above.

[0001104659-14-075227:mdna:69]
Cash used by investing activities amounted to $205.3 million during the six-month period ended September 26, 2014.  This resulted primarily from $138.4 million in net capital expenditures for property and equipment to support certain programs and the payment of $32.6 million primarily for the acquisition of two businesses completed during the six-month period ended September 26, 2014.  Other investing activities also includes $15.7 million paid for the purchase of certain technology rights as further discussed in note 2 to the condensed consolidated financial statements.

[0001104659-14-075227:mdna:70]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the six-month period ended September 26, 2014 was $167.9 million compared to $42.8 million for the six-month period ended September 27, 2013. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities.  Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0001104659-14-075227:mdna:71]
|  |  | Six-Month Periods Ended |  |
|  |  | September 26, 2014 |  | September 27, 2013 |  |
|  |  | (In thousands) |  |
| Net cash provided by operating activities |  | $ | 306,245 |  | $ | 353,758 |  |
| Purchases of property and equipment |  | (167,204 | ) | (321,449 | ) |
| Proceeds from the disposition of property and equipment |  | 28,809 |  | 10,468 |  |
| Free cash flow |  | $ | 167,850 |  | $ | 42,777 |  |

[0001104659-14-075227:mdna:72]
Cash used in financing activities was $189.8 million during the six-month period ended September 26, 2014, which was primarily the result of cash paid for the repurchase of our ordinary shares in the amount of $206.8 million partially offset by proceeds from the issuance of our shares for option exercises amounting to $11.4 million and net proceeds from bank borrowings and long-term debt of $2.2 million.

[0001104659-14-075227:mdna:73]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of September 26, 2014 and March 31, 2014, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore.  Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $779.0 million as of March 31, 2014). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0001104659-14-075227:mdna:74]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, the levels of shipments and changes in the volumes of customer orders, and our targeted business and asset acquisitions.

[0001104659-14-075227:mdna:75]
[same as prior period, unchanged from 0001104659-14-054018:mdna:74]

[0001104659-14-075227:mdna:76]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0001104659-14-075227:mdna:77]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 28, 2014.  During the six-month period ended September 26, 2014, we paid $206.8 million to repurchase shares (under the current and prior repurchase plans) at an average price of $10.20 per share.  As of September 26, 2014, shares in the aggregate amount of $456.7 million were available to be repurchased under the current plan.

[0001104659-14-075227:mdna:78]
[same as prior period, unchanged from 0001104659-14-054018:mdna:77]

[0001104659-14-075227:mdna:79]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report

[0001104659-14-075227:mdna:80]
30

[0001104659-14-075227:mdna:81]
on our Form 10-K for the fiscal year ended March 31, 2014.  There have been no material changes in our contractual obligations and commitments since March 31, 2014, except for the reversal of a contractual obligation during the first quarter of fiscal 2015 with a certain customer that was recognized during the fourth quarter of fiscal 2014 in the amount of $55.0 million discussed in note 6 to the condensed consolidated financial statements.

[0001104659-14-075227:mdna:82]
[same as prior period, unchanged from 0001104659-14-054018:mdna:79]

[0001104659-14-075227:mdna:83]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of September 26, 2014 and March 31, 2014, the fair values of our deferred purchase price receivable were approximately $426.1 million and $470.9 million, respectively. As of September 26, 2014 and March 31, 2014, the outstanding balances on receivables sold for cash were $1.2 billion and $1.1 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information see note 9 of our notes to the condensed consolidated financial statements.
