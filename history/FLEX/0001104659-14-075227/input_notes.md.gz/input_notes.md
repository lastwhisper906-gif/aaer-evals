# FLEX notes — 0001104659-14-075227


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-14-075227:notes:1]
[same as prior period, unchanged from 0001104659-14-054018:notes:1]

[0001104659-14-075227:notes:2]
[same as prior period, unchanged from 0001104659-14-054018:notes:2]

[0001104659-14-075227:notes:3]
Flextronics International Ltd. (“Flextronics” or the “Company”) was incorporated in the Republic of Singapore in May 1990. The Company’s operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of supply chain solutions that span from concept through consumption. The Company designs, builds, ships and services a complete packaged electronic product for original equipment manufacturers (“OEMs”) in the following business groups: High Reliability Solutions (“HRS”), which is comprised of our medical, automotive, and defense and aerospace businesses; Consumer Technology Group (“CTG”), which includes our mobile devices business, including smart phones; our consumer electronics business, including game consoles and wearable electronics; and our high-volume computing business, including various supply chain solutions for notebook personal computing (“PC”), tablets, and printers; Industrial and Emerging Industries (“IEI”), which is comprised of our household appliances, semi-cap equipment, kiosks, energy and emerging industries businesses; and Integrated Network Solutions (“INS”), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses. The Company’s strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service complete packaged products for its OEM customers. This enables our OEM customers to leverage the Company’s supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001104659-14-075227:notes:4]
[same as prior period, unchanged from 0001104659-14-054018:notes:4]

[0001104659-14-075227:notes:5]
[same as prior period, unchanged from 0001104659-14-054018:notes:5]

[0001104659-14-075227:notes:6]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2014 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and six-month periods ended September 26, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015.

[0001104659-14-075227:notes:7]
The first quarters for fiscal year 2015 and fiscal year 2014 ended on June 27, 2014, which is comprised of 88 days in the period, and June 28, 2013, which is comprised of 89 days in period, respectively. The second quarter for fiscal year 2015 and fiscal year 2014 ended on September 26, 2014 and September 27, 2013, which are comprised of 91 days in both periods, respectively.

[0001104659-14-075227:notes:8]
[same as prior period, unchanged from 0001104659-14-054018:notes:8]

[0001104659-14-075227:notes:9]
[same as prior period, unchanged from 0001104659-14-054018:notes:9]

[0001104659-14-075227:notes:10]
In April 2014, the Financial Accounting Standards Board (“FASB”) issued guidance which requires an entity to report a disposal of a component of an entity in discontinued operations if the disposal represents a strategic shift that has a major effect on an entity’s operations and financial results when the component of an entity meets certain criteria to be classified as held for sale, or when the component of an entity is disposed of by a sale or disposed of other than by a sale. Further, additional disclosures about discontinued operations should include the following for the periods in which the results of operations of the discontinued operations are presented in the statement of operations: the major classes of line items constituting pretax profit or loss of discontinued operations; total operating and investing cash flows of discontinued operations; depreciation, amortization, capital expenditures, and significant operating and investing noncash items of discontinued operations; pretax profit or loss attributable to the parent if a discontinued operation includes a non-controlling interest; a reconciliation of major classes of assets, liabilities of the discontinued operation classified as held for sale; and a reconciliation of major classes of line items constituting the pretax profit or loss of the discontinued operation. The Company early adopted this accounting standard update in the first quarter of fiscal year 2015.  During the first quarter of fiscal 2015, the Company disposed of a manufacturing facility in Western Europe which did not meet the criteria of discontinued operations under this accounting standard, as further discussed in note 6 to the condensed consolidated financial statements.

[0001104659-14-075227:notes:11]
[same as prior period, unchanged from 0001104659-14-054018:notes:11]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-14-075227:notes:12]
[same as prior period, unchanged from 0001104659-14-054018:notes:12]

[0001104659-14-075227:notes:13]
[same as prior period, unchanged from 0001104659-14-054018:notes:13]

[0001104659-14-075227:notes:14]
[same as prior period, unchanged from 0001104659-14-054018:notes:14]

[0001104659-14-075227:notes:15]
|  |  | As of |  | As of |  |
|  |  | September 26, 2014 |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Raw materials |  | $ | 2,422,415 |  | $ | 2,349,278 |  |
| Work-in-progress |  | 578,211 |  | 608,284 |  |
| Finished goods |  | 626,014 |  | 641,446 |  |
|  |  | $ | 3,626,640 |  | $ | 3,599,008 |  |

[0001104659-14-075227:notes:16]
[same as prior period, unchanged from 0001104659-14-054018:notes:16]

[0001104659-14-075227:notes:17]
The following table summarizes the activity in the Company’s goodwill account during the six-month period ended September 26, 2014:

[0001104659-14-075227:notes:18]
|  |  | Amount |  |
|  |  | (In thousands) |  |
| Balance, beginning of the year |  | $ | 292,758 |  |
| Additions (1) |  | 21,707 |  |
| Purchase accounting adjustments (2) |  | 8,651 |  |
| Foreign currency translation adjustments |  | (2,059 | ) |
| Balance, end of the period |  | $ | 321,057 |  |

[0001104659-14-075227:notes:19]
(1)          The goodwill generated from the Company’s business combinations completed during the six-month period ended September 26, 2014 is primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired businesses and expected synergies. The goodwill is not deductible for income tax purposes. See note 12 to the condensed consolidated financial statements for additional information.

[0001104659-14-075227:notes:20]
(2)          Fair value adjustment made to certain assets acquired in connection with the Company’s acquisition of Riwisa AG.

[0001104659-14-075227:notes:21]
[same as prior period, unchanged from 0001104659-14-054018:notes:20]

[0001104659-14-075227:notes:22]
|  |  | As of September 26, 2014 |  | As of March 31, 2014 |  |
|  |  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |
|  |  | Carrying |  | Accumulated |  | Carrying |  | Carrying |  | Accumulated |  | Carrying |  |
|  |  | Amount |  | Amortization |  | Amount |  | Amount |  | Amortization |  | Amount |  |
|  |  | (In thousands) |  |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles |  | $ | 211,852 |  | $ | (152,259 | ) | $ | 59,593 |  | $ | 204,369 |  | $ | (140,713 | ) | $ | 63,656 |  |
| Licenses and other intangibles |  | 47,789 |  | (15,202 | ) | 32,587 |  | 32,564 |  | (11,760 | ) | 20,804 |  |
| Total |  | $ | 259,641 |  | $ | (167,461 | ) | $ | 92,180 |  | $ | 236,933 |  | $ | (152,473 | ) | $ | 84,460 |  |

[0001104659-14-075227:notes:23]
The gross carrying amounts of intangible assets are removed when the recorded amounts have been fully amortized.  During the six-month period ended September 26, 2014, the value of customer-related intangible assets increased by $8.5 million in connection with the Company’s acquisitions, and licenses and other intangibles increased by $15.7 million primarily as a result of the purchase of certain technology rights.  The estimated future annual amortization expense for intangible assets is as follows:

[0001104659-14-075227:notes:24]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2015 (1) |  | $ | 15,741 |  |
| 2016 |  | 27,133 |  |
| 2017 |  | 18,786 |  |
| 2018 |  | 12,825 |  |
| 2019 |  | 8,498 |  |
| Thereafter |  | 9,197 |  |
| Total amortization expense |  | $ | 92,180 |  |

[0001104659-14-075227:notes:25]
(1)           Represents estimated amortization for the remaining six-month period ending March 31, 2015.

[0001104659-14-075227:notes:26]
[same as prior period, unchanged from 0001104659-14-054018:notes:25]

[0001104659-14-075227:notes:27]
Other current assets include certain assets purchased on behalf of a customer and financed by a third party banking institution of $267.5 million as of both September 26, 2014 and March 31, 2014, respectively, with a corresponding liability recorded to other current liabilities of $289.6 million and $286.5 million as of September 26, 2014 and March 31, 2014, respectively.

[0001104659-14-075227:notes:28]
Other current liabilities also includes customer working capital advances of $213.2 million and $754.7 million as of September 26, 2014 and March 31, 2014, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-14-075227:notes:29]
[same as prior period, unchanged from 0001104659-14-054018:notes:28]

[0001104659-14-075227:notes:30]
The following table summarizes the Company’s share-based compensation expense:

[0001104659-14-075227:notes:31]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |  |
|  |  | September 26, 2014 |  | September 27, 2013 |  | September 26, 2014 |  | September 27, 2013 |  |
|  |  | (In thousands) |  |
| Cost of sales |  | $ | 1,868 |  | $ | 1,866 |  | $ | 3,478 |  | $ | 3,218 |  |
| Selling, general and administrative expenses |  | 9,051 |  | 6,851 |  | 19,122 |  | 14,088 |  |
| Total stock-based compensation expense |  | $ | 10,919 |  | $ | 8,717 |  | $ | 22,600 |  | $ | 17,306 |  |

[0001104659-14-075227:notes:32]
Total unrecognized compensation expense related to share options is $0.3 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of one year. As of September 26, 2014, the number of options outstanding and exercisable was 18.3 million and 18.2 million, respectively, both at a weighted-average exercise price of $8.06 per share.

[0001104659-14-075227:notes:33]
During the six-month period ended September 26, 2014, the Company granted 6.0 million unvested share bonus awards at an average grant date price of $11.75 per share, under its 2010 Equity Incentive Plan.  Of this amount, approximately 0.9 million represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions.  The number of shares that ultimately will vest range from zero up to a maximum of 1.8 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met.  The average grant-date fair value of these awards was estimated to be $15.81 per share and was calculated using a Monte Carlo simulation.

[0001104659-14-075227:notes:34]
As of September 26, 2014, approximately 19.3 million unvested share bonus awards were outstanding, of which vesting for a targeted amount of 5.0 million is contingent primarily on meeting certain market conditions.  The number of shares that will ultimately be issued can range from zero to 9.7 million based on the achievement levels of the respective conditions.  During the six-month period ended September 26, 2014, 0.3 million shares vested in connection with the remaining number of share bonus awards with market conditions granted in fiscal 2011, and 0.4 million shares vested in connection with half of the share bonus awards with market conditions granted in fiscal 2012.

[0001104659-14-075227:notes:35]
As of September 26, 2014, total unrecognized compensation expense related to unvested share bonus awards is $107.7 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of 2.8 years. Approximately $20.8 million of the total unrecognized compensation cost, net of estimated forfeitures, is related to awards whereby vesting is contingent on meeting certain market conditions.


## us-gaap:EarningsPerShareTextBlock

[0001104659-14-075227:notes:36]
[same as prior period, unchanged from 0001104659-14-054018:notes:36]

[0001104659-14-075227:notes:37]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share:

[0001104659-14-075227:notes:38]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |  |
|  |  | September 26, 2014 |  | September 27, 2013 |  | September 26, 2014 |  | September 27, 2013 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings per share: |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 138,903 |  | $ | 118,205 |  | $ | 312,790 |  | $ | 177,462 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  | 585,760 |  | 610,775 |  | 586,497 |  | 618,447 |  |
| Basic earnings per share |  | $ | 0.24 |  | $ | 0.19 |  | $ | 0.53 |  | $ | 0.29 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 138,903 |  | $ | 118,205 |  | $ | 312,790 |  | $ | 177,462 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  | 585,760 |  | 610,775 |  | 586,497 |  | 618,447 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) |  | 10,111 |  | 12,845 |  | 12,089 |  | 13,313 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding |  | 595,871 |  | 623,620 |  | 598,586 |  | 631,760 |  |
| Diluted earnings per share |  | $ | 0.23 |  | $ | 0.19 |  | $ | 0.52 |  | $ | 0.28 |  |

[0001104659-14-075227:notes:39]
(1)     Options to purchase ordinary shares of 7.0 million and 18.1 million during the three-month periods ended September 26, 2014 and September 27, 2013, respectively, and share bonus awards of 0.8 million and 1.0 million during the three-month periods ended September 26, 2014 and September 27, 2013, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary share equivalents.

[0001104659-14-075227:notes:40]
(2)     Options to purchase ordinary shares of 12.1 million and 18.7 million during the six-month periods ended September 26, 2014 and September 27, 2013, respectively, and share bonus awards of 0.4 million and 2.4 million during the six-month periods ended September 26, 2014 and September 27, 2013, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary share equivalents.


## flex:InterestAndOtherNetTextBlock

[0001104659-14-075227:notes:41]
[same as prior period, unchanged from 0001104659-14-054018:notes:40]

[0001104659-14-075227:notes:42]
During the three-month and six-month periods ended September 26, 2014, the Company recognized interest expense of $19.0 million and $37.5 million, respectively, on its debt obligations outstanding during the period.  During the three-month and six-month periods ended September 27, 2013, the Company recognized interest expense of $20.3 million and $40.5 million, respectively.

[0001104659-14-075227:notes:43]
The weighted average interest rates for the Company’s long-term debt were 3.2% and 3.3% for the six-month periods ended September 26, 2014 and September 27, 2013, respectively.

[0001104659-14-075227:notes:44]
During the three-month and six-month periods ended September 26, 2014, the Company recognized interest income of $4.8 million and $10.1 million, respectively.  During the three-month and six-month periods ended September 27, 2013, the Company recognized interest income of $4.0 million and $7.3 million, respectively.

[0001104659-14-075227:notes:45]
During the three-month and six-month periods ended September 26, 2014, the Company recognized gains on foreign exchange transactions of $6.8 million and $5.4 million, respectively.  During the three-month and six-month periods ended September 27, 2013, the Company recognized gains on foreign exchange transactions of $3.4 million and $8.0 million, respectively.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001104659-14-075227:notes:46]
[same as prior period, unchanged from 0001104659-14-054018:notes:127]

[0001104659-14-075227:notes:47]
During the six-month period ended September 26, 2014, an amendment to a customer contract to reimburse a customer for certain performance provisions was executed which included the removal of a $55.0 million contractual obligation recognized during fiscal year 2014. Accordingly, the Company reversed this charge with a corresponding credit to other charges (income), net in the condensed consolidated statement of operations.

[0001104659-14-075227:notes:48]
Further, during the six-month period ended September 26, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe.  The Company received $11.5 million in cash for the sale of $27.2 million in net assets of the facility.  The loss also includes $4.6 million of estimated transaction costs, partially offset by a gain of $9.3 million for the release of cumulative foreign currency translation gains triggered by the disposition.

[0001104659-14-075227:notes:49]
During the six-month period ended September 27, 2013, the Company recognized a loss of $7.1 million relating to the exercise of a warrant to purchase shares of a certain supplier and sale of the underlying shares for total proceeds of $67.3 million.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-14-075227:notes:50]
[same as prior period, unchanged from 0001104659-14-054018:notes:44]

[0001104659-14-075227:notes:51]
[same as prior period, unchanged from 0001104659-14-054018:notes:45]

[0001104659-14-075227:notes:52]
The Company enters into forward contracts and foreign currency swap contracts to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions.  The Company hedges committed exposures and does not engage in speculative transactions.  As of September 26, 2014, the aggregate notional amount of the Company’s outstanding foreign currency forward and swap contracts was $5.2 billion as summarized below:

[0001104659-14-075227:notes:53]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |  |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |  |
|  |  | (In thousands) |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |
| CNY |  | 2,725,000 |  | — |  | $ | 444,057 |  | $ | — |  |
| EUR |  | 15,273 |  | 13,728 |  | 19,518 |  | 18,148 |  |
| HUF |  | 16,348,000 |  | — |  | 67,389 |  | — |  |
| MXN |  | 1,889,800 |  | — |  | 142,206 |  | — |  |
| MYR |  | 320,000 |  | — |  | 98,720 |  | — |  |
| Other |  | N/A |  | N/A |  | 131,629 |  | — |  |
|  |  |  |  |  |  | 903,519 |  | 18,148 |  |
| Other Forward/Swap Contracts |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  | 326,000 |  | — |  | 136,356 |  |
| CAD |  | 137,524 |  | 134,540 |  | 125,173 |  | 122,175 |  |
| CNY |  | 4,955,264 |  | 3,077,814 |  | 803,676 |  | 500,000 |  |
| EUR |  | 530,989 |  | 698,030 |  | 680,254 |  | 897,235 |  |
| GBP |  | 31,850 |  | 57,585 |  | 52,081 |  | 94,205 |  |
| HUF |  | 17,297,300 |  | 20,225,600 |  | 71,303 |  | 83,374 |  |
| JPY |  | 6,914,690 |  | 1,354,020 |  | 63,471 |  | 12,599 |  |
| MXN |  | 1,157,840 |  | 589,470 |  | 87,126 |  | 44,357 |  |
| MYR |  | 239,320 |  | 37,342 |  | 73,830 |  | 11,520 |  |
| SEK |  | 488,358 |  | 717,285 |  | 68,157 |  | 100,930 |  |
| Other |  | N/A |  | N/A |  | 166,590 |  | 120,356 |  |
|  |  |  |  |  |  | 2,191,661 |  | 2,123,107 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 3,095,180 |  | $ | 2,141,255 |  |

[0001104659-14-075227:notes:54]
As of September 26, 2014, the fair value of the Company’s short-term foreign currency contracts was not material and is included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards.  Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of September 26, 2014 and March 31, 2014, the Company also has included net deferred losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to the effective portion of changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses were not material as of September 26, 2014, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0001104659-14-075227:notes:55]
[same as prior period, unchanged from 0001104659-14-054018:notes:49]

[0001104659-14-075227:notes:56]
|  |  | Fair Values of Derivative Instruments |  |
|  |  | Asset Derivatives |  | Liability Derivatives |  |
|  |  |  |  | Fair Value |  |  |  | Fair Value |  |
|  |  | Balance Sheet Location |  | September 26, 2014 |  | March 31, 2014 |  | Balance Sheet Location |  | September 26, 2014 |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 6,135 |  | $ | 3,464 |  | Other current liabilities |  | $ | 8,016 |  | $ | 10,457 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 19,816 |  | $ | 4,722 |  | Other current liabilities |  | $ | 10,896 |  | $ | 6,949 |  |

[0001104659-14-075227:notes:57]
[same as prior period, unchanged from 0001104659-14-054018:notes:51]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001104659-14-075227:notes:58]
[same as prior period, unchanged from 0001104659-14-054018:notes:75]

[0001104659-14-075227:notes:59]
[same as prior period, unchanged from 0001104659-14-054018:notes:76]

[0001104659-14-075227:notes:60]
|  |  | Three-Month Periods Ended |  |
|  |  | September 26, 2014 |  | September 27, 2013 |  |
|  |  | Unrealized gain (loss) on derivative instruments and other |  | Foreign currency translation adjustments |  | Total |  | Unrealized gain (loss) on derivative instruments and other |  | Foreign currency translation adjustments |  | Total |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | (22,124 | ) | $ | (97,452 | ) | $ | (119,576 | ) | $ | (28,991 | ) | $ | (76,133 | ) | $ | (105,124 | ) |
| Other comprehensive gain (loss) before reclassifications |  | (2,965 | ) | (3,099 | ) | (6,064 | ) | 5,937 |  | (11,988 | ) | (6,051 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss |  | 532 |  | (2,584 | ) | (2,052 | ) | 3,616 |  | — |  | 3,616 |  |
| Net current-period other comprehensive gain (loss) |  | (2,433 | ) | (5,683 | ) | (8,116 | ) | 9,553 |  | (11,988 | ) | (2,435 | ) |
| Ending balance |  | $ | (24,557 | ) | $ | (103,135 | ) | $ | (127,692 | ) | $ | (19,438 | ) | $ | (88,121 | ) | $ | (107,559 | ) |

[0001104659-14-075227:notes:61]
|  |  | Six-Month Periods Ended |  |
|  |  | September 26, 2014 |  | September 27, 2013 |  |
|  |  | Unrealized gain (loss) on derivative instruments and other |  | Foreign currency translation adjustments |  | Total |  | Unrealized gain (loss) on derivative instruments and other |  | Foreign currency translation adjustments |  | Total |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | (32,849 | ) | $ | (93,307 | ) | $ | (126,156 | ) | $ | (18,857 | ) | $ | (58,624 | ) | $ | (77,481 | ) |
| Other comprehensive gain (loss) before reclassifications |  | (1,965 | ) | 2,008 |  | 43 |  | (308 | ) | (29,497 | ) | (29,805 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss |  | 10,257 |  | (11,836 | ) | (1,579 | ) | (273 | ) | — |  | (273 | ) |
| Net current-period other comprehensive gain (loss) |  | 8,292 |  | (9,828 | ) | (1,536 | ) | (581 | ) | (29,497 | ) | (30,078 | ) |
| Ending balance |  | $ | (24,557 | ) | $ | (103,135 | ) | $ | (127,692 | ) | $ | (19,438 | ) | $ | (88,121 | ) | $ | (107,559 | ) |

[0001104659-14-075227:notes:62]
Net losses reclassified from accumulated other comprehensive loss during the six-month period ended September 26, 2014 relating to derivative instruments and other includes $5.8 million attributable to the Company’s cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations.

[0001104659-14-075227:notes:63]
During the six-month period ended September 26, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe.  This loss includes the settlement of unrealized losses of $4.2 million on an insignificant defined benefit plan associated with the disposed facility offset by the release of cumulative foreign currency translation gains of $9.3 million, both of which have been reclassified from accumulated other comprehensive loss during the period.  The loss on sale is included in other charges (income), net in the condensed consolidated statement of operations.

[0001104659-14-075227:notes:64]
Additionally, net gains reclassified from accumulated other comprehensive loss during the six-month period ended September 26, 2014 includes $2.6 million in connection with cumulative translation gains related to the liquidation of a foreign entity, which is included in other charges (income), net in the condensed consolidated statement of operations.

[0001104659-14-075227:notes:65]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month and six-month periods ended September 27, 2013, was recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001104659-14-075227:notes:66]
[same as prior period, unchanged from 0001104659-14-054018:notes:79]

[0001104659-14-075227:notes:67]
[same as prior period, unchanged from 0001104659-14-054018:notes:80]

[0001104659-14-075227:notes:68]
[same as prior period, unchanged from 0001104659-14-054018:notes:81]

[0001104659-14-075227:notes:69]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables.  Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $500.0 million for the Global Program and $225.0 million for the North American Program. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001104659-14-075227:notes:70]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum.  Servicing fees recognized during the three-month and six-month periods ended September 26, 2014 and September 27, 2013 were not material and are included in interest and other, net within the condensed consolidated statements of operations.  As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0001104659-14-075227:notes:71]
As of September 26, 2014, approximately $1.1 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of $673.6 million and deferred purchase price receivables of approximately $426.1 million.  As of March 31, 2014, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $729.3 million and deferred purchase price receivables of approximately $470.9 million.  The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction.  The deferred purchase price receivables are included in other current assets as of September 26, 2014 and March 31, 2014, and were carried at the expected recovery amount of the related receivables.  The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0001104659-14-075227:notes:72]
As of September 26, 2014 and March 31, 2014, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0001104659-14-075227:notes:73]
For the six-month periods ended September 26, 2014 and September 27, 2013, cash flows from sales of receivables under the ABS Programs consisted of approximately $2.1 billion and $1.9 billion for transfers of receivables, respectively (of which approximately $76.5 million and $182.7 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0001104659-14-075227:notes:74]
[same as prior period, unchanged from 0001104659-14-054018:notes:87]

[0001104659-14-075227:notes:75]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |  |
|  |  | September 26, 2014 |  | September 27, 2013 |  | September 26, 2014 |  | September 27, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 463,124 |  | $ | 420,887 |  | $ | 470,908 |  | $ | 412,357 |  |
| Transfers of receivables |  | 720,921 |  | 983,623 |  | 1,499,781 |  | 1,866,540 |  |
| Collections |  | (757,988 | ) | (846,199 | ) | (1,544,632 | ) | (1,720,586 | ) |
| Ending balance |  | $ | 426,057 |  | $ | 558,311 |  | $ | 426,057 |  | $ | 558,311 |  |

[0001104659-14-075227:notes:76]
[same as prior period, unchanged from 0001104659-14-054018:notes:88]

[0001104659-14-075227:notes:77]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $571.5 million and $341.8 million as of September 26, 2014 and March 31, 2014, respectively. For the six-month periods ended September 26, 2014 and September 27, 2013, total accounts receivable sold to certain third party banking institutions was approximately $2.3 billion and $1.2 billion, respectively.  The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-14-075227:notes:78]
[same as prior period, unchanged from 0001104659-14-054018:notes:90]

[0001104659-14-075227:notes:79]
[same as prior period, unchanged from 0001104659-14-054018:notes:91]

[0001104659-14-075227:notes:80]
[same as prior period, unchanged from 0001104659-14-054018:notes:92]

[0001104659-14-075227:notes:81]
[same as prior period, unchanged from 0001104659-14-054018:notes:93]

[0001104659-14-075227:notes:82]
[same as prior period, unchanged from 0001104659-14-054018:notes:94]

[0001104659-14-075227:notes:83]
[same as prior period, unchanged from 0001104659-14-054018:notes:95]

[0001104659-14-075227:notes:84]
[same as prior period, unchanged from 0001104659-14-054018:notes:96]

[0001104659-14-075227:notes:85]
[same as prior period, unchanged from 0001104659-14-054018:notes:97]

[0001104659-14-075227:notes:86]
[same as prior period, unchanged from 0001104659-14-054018:notes:98]

[0001104659-14-075227:notes:87]
The Company has accrued for certain contingent consideration in connection with its business acquisitions, which is measured at fair value based on internal cash flow models and other inputs. The following table summarizes the activities related to contingent consideration:

[0001104659-14-075227:notes:88]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |  |
|  |  | September 26, 2014 |  | September 27, 2013 |  | September 26, 2014 |  | September 27, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 11,300 |  | $ | 19,000 |  | $ | 11,300 |  | $ | 25,000 |  |
| Additions to accrual |  | 4,500 |  | — |  | 4,500 |  | — |  |
| Fair value adjustments |  | — |  | (3,000 | ) | — |  | (9,000 | ) |
| Ending balance |  | $ | 15,800 |  | $ | 16,000 |  | $ | 15,800 |  | $ | 16,000 |  |

[0001104659-14-075227:notes:89]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor.  Due to its high credit quality and short term maturity the fair value approximates carrying value.  Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not meaningful.  The interrelationship between these inputs is also insignificant.  Refer to note 9 to the condensed consolidated financial statements for a reconciliation of the change in the deferred purchase price receivable during the three-month and six-month periods ended September 26, 2014 and September 27, 2013.

[0001104659-14-075227:notes:90]
There were no transfers between levels in the fair value hierarchy during the three-month and six-month periods ended September 26, 2014 and September 27, 2013.

[0001104659-14-075227:notes:91]
[same as prior period, unchanged from 0001104659-14-054018:notes:102]

[0001104659-14-075227:notes:92]
[same as prior period, unchanged from 0001104659-14-054018:notes:103]

[0001104659-14-075227:notes:93]
|  |  | Fair Value Measurements as of September 26, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) |  | $ | — |  | $ | 528,169 |  | $ | — |  | $ | 528,169 |  |
| Deferred purchase price receivable (Note 9) |  | — |  | — |  | 426,057 |  | 426,057 |  |
| Foreign exchange forward contracts (Note 7) |  | — |  | 25,951 |  | — |  | 25,951 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities |  | 9,216 |  | 37,245 |  | — |  | 46,461 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 7) |  | $ | — |  | $ | (18,912 | ) | $ | — |  | $ | (18,912 | ) |
| Contingent consideration in connection with business acquisitions |  | — |  | — |  | (15,800 | ) | (15,800 | ) |

[0001104659-14-075227:notes:94]
|  |  | Fair Value Measurements as of March 31, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) |  | $ | — |  | $ | 552,928 |  | $ | — |  | $ | 552,928 |  |
| Deferred purchase price receivable (Note 9) |  | — |  | — |  | 470,908 |  | 470,908 |  |
| Foreign exchange forward contracts (Note 7) |  | — |  | 8,186 |  | — |  | 8,186 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities |  | 9,456 |  | 36,751 |  | — |  | 46,207 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 7) |  | $ | — |  | $ | (17,406 | ) | $ | — |  | $ | (17,406 | ) |
| Contingent consideration in connection with business acquisitions |  | — |  | — |  | (11,300 | ) | (11,300 | ) |

[0001104659-14-075227:notes:95]
[same as prior period, unchanged from 0001104659-14-054018:notes:104]

[0001104659-14-075227:notes:96]
Assets held for sale are recorded at the lesser of the carrying value or fair value, which is based on comparable sales from prevailing market data (level 2 inputs).  As of September 26, 2014 and March 31, 2014, the fair value of assets that were no longer in use and held for sale totaled approximately $3.6 million and $43.5 million, respectively. These assets primarily represent manufacturing facilities that have been closed as part of the Company’s historical facility consolidations and that met the criteria to be classified as held for sale. During the six-month period ended September 26, 2014, the Company sold $39.9 million of assets held for sale.

[0001104659-14-075227:notes:97]
There were no transfers between levels in the fair value hierarchy for assets held-for-sale during the three-month and six-month periods ended September 26, 2014 and September 27, 2013.

[0001104659-14-075227:notes:98]
[same as prior period, unchanged from 0001104659-14-054018:notes:107]

[0001104659-14-075227:notes:99]
[same as prior period, unchanged from 0001104659-14-054018:notes:108]

[0001104659-14-075227:notes:100]
|  |  | As of September 26, 2014 |  | As of March 31, 2014 |  |  |  |
|  |  | Carrying |  | Fair |  | Carrying |  | Fair |  | Fair Value |  |
|  |  | Amount |  | Value |  | Amount |  | Value |  | Hierarchy |  |
|  |  | (In thousands) |  |
| Term Loan, including current portion, due in installments through August 2018 |  | $ | 600,000 |  | $ | 585,750 |  | $ | 600,000 |  | $ | 591,750 |  | Level 1 |  |
| Term Loan, including current portion, due in installments through March 2019 |  | 493,750 |  | 484,803 |  | 500,000 |  | 497,190 |  | Level 1 |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 502,510 |  | 500,000 |  | 504,688 |  | Level 1 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 505,000 |  | 500,000 |  | 517,650 |  | Level 1 |  |
| Total |  | $ | 2,093,750 |  | $ | 2,078,063 |  | $ | 2,100,000 |  | $ | 2,111,278 |  |  |  |

[0001104659-14-075227:notes:101]
[same as prior period, unchanged from 0001104659-14-054018:notes:109]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001104659-14-075227:notes:102]
[same as prior period, unchanged from 0001104659-14-054018:notes:110]

[0001104659-14-075227:notes:103]
[same as prior period, unchanged from 0001104659-14-054018:notes:111]

[0001104659-14-075227:notes:104]
During the six-month period ended September 27, 2013, the Company recognized restructuring charges of approximately $40.8 million, of which $35.1 million were recorded as a component of cost of sales and $5.6 million were recorded as a component of selling, general and administrative expenses.  Of the total restructuring charges, $32.2 million was associated with the terminations of 5,106 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 3,947 in Asia, 1,105 in the Americas and 54 in Europe. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on equipment no longer in use and to be disposed of, and other exit related costs due to facility closures or rationalizations.  Of the total restructuring charges, $1.9 million were non-cash charges related to the impairment of long-lived assets, and were classified as a component of cost of sales.

[0001104659-14-075227:notes:105]
The components of the restructuring charges by geographic region incurred during the six-month period ended September 27, 2013 were as follows:

[0001104659-14-075227:notes:106]
|  |  | Americas |  | Asia |  | Europe |  | Total |  |
|  |  | (In thousands) |  |
| Severance |  | $ | 11,331 |  | $ | 16,205 |  | $ | 4,631 |  | $ | 32,167 |  |
| Long-lived asset impairment |  | — |  | 1,900 |  | — |  | 1,900 |  |
| Other exit costs |  | 2,248 |  | 3,157 |  | 1,288 |  | 6,693 |  |
| Total restructuring charges |  | $ | 13,579 |  | $ | 21,262 |  | $ | 5,919 |  | $ | 40,760 |  |

[0001104659-14-075227:notes:107]
[same as prior period, unchanged from 0001104659-14-054018:notes:114]

[0001104659-14-075227:notes:108]
During the six-month period ended September 27, 2013, the Company recognized approximately $6.7 million of other exit costs, which was primarily comprised of $3.8 million related to personnel costs and $2.9 million of contractual obligations that resulted from facility closures. The majority of these costs were classified as a component of cost of sales.

[0001104659-14-075227:notes:109]
During the six-month period ended September 26, 2014, the Company paid approximately $25.0 million for restructuring charges.  Total restructuring charges accrued as of September 26, 2014 were approximately $17.4 million, of which the majority was classified as a short-term obligation.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001104659-14-075227:notes:110]
13.  COMMITMENTS AND CONTINGENCIES

[0001104659-14-075227:notes:111]
Litigation and other legal matters

[0001104659-14-075227:notes:112]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International, Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431).  The complaint asserts various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products.  The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys’ fees and costs.  The plaintiff also seeks a jury trial.  On June 25, 2014, we filed motions for Demurrer and to Strike asking the court to dismiss the claims against us.  The court has scheduled a hearing on the motions for December 19, 2014.  Although the outcome of this matter is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of this matter, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements.

[0001104659-14-075227:notes:113]
During the six-month period ended September 26, 2014, one of our non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties.  The Company believes there is no legal basis for the assessment and expects that any losses are remote.  The Company plans to vigorously defend itself through the administrative and judicial processes.

[0001104659-14-075227:notes:114]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0001104659-14-075227:notes:115]
14.  SHARE REPURCHASES

[0001104659-14-075227:notes:116]
During the three-month and six-month periods ended September 26, 2014 the Company repurchased 9.3 million shares at an aggregate purchase price of $101.3 million and 19.8 million shares at an aggregate purchase price of $203.4 million, respectively, and retired all of these shares.

[0001104659-14-075227:notes:117]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Extraordinary General Meeting held on August 28, 2014. As of September 26, 2014, shares in the aggregate amount of $456.7 million were available to be repurchased under the current plan.


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001104659-14-075227:notes:118]
15.  SUPPLEMENTAL GUARANTOR AND NON-GUARANTOR CONDENSED CONSOLIDATING FINANCIAL STATEMENTS

[0001104659-14-075227:notes:119]
Flextronics International Ltd. (“Parent”) has two tranches of Notes of $500 million each outstanding, which mature on February 15, 2020 and February 15, 2023, respectively. These Notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company’s 100% owned subsidiaries (the “guarantor subsidiaries”). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade.

[0001104659-14-075227:notes:120]
[same as prior period, unchanged from 0001104659-14-054018:notes:126]

[0001104659-14-075227:notes:121]
Condensed Consolidating Balance Sheets as of September 26, 2014

[0001104659-14-075227:notes:122]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 470,139 |  | $ | 321,665 |  | $ | 722,548 |  | $ | — |  | $ | 1,514,352 |  |
| Accounts receivable |  | — |  | 1,189,969 |  | 1,336,911 |  | — |  | 2,526,880 |  |
| Inventories |  | — |  | 1,653,596 |  | 1,973,044 |  | — |  | 3,626,640 |  |
| Inter company receivable |  | 10,094,013 |  | 8,128,810 |  | 10,142,505 |  | (28,365,328 | ) | — |  |
| Other current assets |  | 6,577 |  | 202,559 |  | 1,002,052 |  | — |  | 1,211,188 |  |
| Total current assets |  | 10,570,729 |  | 11,496,599 |  | 15,177,060 |  | (28,365,328 | ) | 8,879,060 |  |
| Property and equipment, net |  | — |  | 504,883 |  | 1,689,083 |  | — |  | 2,193,966 |  |
| Goodwill and other intangible assets, net |  | 625 |  | 47,428 |  | 365,184 |  | — |  | 413,237 |  |
| Other assets |  | 2,495,053 |  | 108,349 |  | 2,196,815 |  | (4,366,607 | ) | 433,610 |  |
| Investment in subsidiaries |  | 930,357 |  | 1,372,617 |  | 16,077,482 |  | (18,380,456 | ) | — |  |
| Total assets |  | $ | 13,996,764 |  | $ | 13,529,876 |  | $ | 35,505,624 |  | $ | (51,112,391 | ) | $ | 11,919,873 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 40,000 |  | $ | 35 |  | $ | 5,544 |  | $ | — |  | $ | 45,579 |  |
| Accounts payable |  | — |  | 1,657,866 |  | 3,035,660 |  | — |  | 4,693,526 |  |
| Accrued payroll |  | — |  | 117,170 |  | 264,096 |  | — |  | 381,266 |  |
| Inter company payable |  | 9,532,897 |  | 11,370,249 |  | 7,462,182 |  | (28,365,328 | ) | — |  |
| Other current liabilities |  | 26,609 |  | 825,056 |  | 1,084,239 |  | — |  | 1,935,904 |  |
| Total current liabilities |  | 9,599,506 |  | 13,970,376 |  | 11,851,721 |  | (28,365,328 | ) | 7,056,275 |  |
| Long term liabilities |  | 2,092,704 |  | 2,091,422 |  | 2,703,225 |  | (4,366,607 | ) | 2,520,744 |  |
| Flextronics International Ltd. shareholders’ equity |  | 2,304,554 |  | (2,531,922 | ) | 20,912,378 |  | (18,380,456 | ) | 2,304,554 |  |
| Noncontrolling interests |  | — |  | — |  | 38,300 |  | — |  | 38,300 |  |
| Total shareholders’ equity |  | 2,304,554 |  | (2,531,922 | ) | 20,950,678 |  | (18,380,456 | ) | 2,342,854 |  |
| Total liabilities and shareholders’ equity |  | $ | 13,996,764 |  | $ | 13,529,876 |  | $ | 35,505,624 |  | $ | (51,112,391 | ) | $ | 11,919,873 |  |

[0001104659-14-075227:notes:123]
Condensed Consolidating Balance Sheets as of March 31, 2014

[0001104659-14-075227:notes:124]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 638,714 |  | $ | 210,462 |  | $ | 744,552 |  | $ | — |  | $ | 1,593,728 |  |
| Accounts receivable |  | — |  | 1,203,600 |  | 1,494,385 |  | — |  | 2,697,985 |  |
| Inventories |  | — |  | 1,701,872 |  | 1,897,136 |  | — |  | 3,599,008 |  |
| Inter company receivable |  | 8,867,520 |  | 6,963,002 |  | 9,528,158 |  | (25,358,680 | ) | — |  |
| Other current assets |  | 246 |  | 383,590 |  | 1,125,769 |  | — |  | 1,509,605 |  |
| Total current assets |  | 9,506,480 |  | 10,462,526 |  | 14,790,000 |  | (25,358,680 | ) | 9,400,326 |  |
| Property and equipment, net |  | — |  | 490,166 |  | 1,798,490 |  | — |  | 2,288,656 |  |
| Goodwill and other intangible assets, net |  | 775 |  | 46,916 |  | 329,527 |  | — |  | 377,218 |  |
| Other assets |  | 2,585,169 |  | 120,739 |  | 4,692,156 |  | (6,964,114 | ) | 433,950 |  |
| Investment in subsidiaries |  | 3,350,690 |  | 822,528 |  | 15,965,981 |  | (20,139,199 | ) | — |  |
| Total assets |  | $ | 15,443,114 |  | $ | 11,942,875 |  | $ | 37,576,154 |  | $ | (52,461,993 | ) | $ | 12,500,150 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 32,500 |  | $ | 60 |  | $ | 15 |  | $ | — |  | $ | 32,575 |  |
| Accounts payable |  | — |  | 1,614,384 |  | 3,133,395 |  | — |  | 4,747,779 |  |
| Accrued payroll |  | — |  | 106,046 |  | 248,843 |  | — |  | 354,889 |  |
| Inter company payable |  | 8,607,486 |  | 10,126,691 |  | 6,624,503 |  | (25,358,680 | ) | — |  |
| Other current liabilities |  | 24,868 |  | 756,767 |  | 1,739,809 |  | — |  | 2,521,444 |  |
| Total current liabilities |  | 8,664,854 |  | 12,603,948 |  | 11,746,565 |  | (25,358,680 | ) | 7,656,687 |  |
| Long term liabilities |  | 4,615,210 |  | 2,140,985 |  | 2,849,703 |  | (6,964,114 | ) | 2,641,784 |  |
| Flextronics International Ltd. shareholders’ equity |  | 2,163,050 |  | (2,802,058 | ) | 22,941,257 |  | (20,139,199 | ) | 2,163,050 |  |
| Noncontrolling interest |  | — |  | — |  | 38,629 |  | — |  | 38,629 |  |
| Total shareholders’ equity |  | 2,163,050 |  | (2,802,058 | ) | 22,979,886 |  | (20,139,199 | ) | 2,201,679 |  |
| Total liabilities and shareholders’ equity |  | $ | 15,443,114 |  | $ | 11,942,875 |  | $ | 37,576,154 |  | $ | (52,461,993 | ) | $ | 12,500,150 |  |

[0001104659-14-075227:notes:125]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended September 26, 2014

[0001104659-14-075227:notes:126]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 4,456,995 |  | $ | 5,219,767 |  | $ | (3,148,245 | ) | $ | 6,528,517 |  |
| Cost of sales |  | — |  | 4,139,945 |  | 5,159,736 |  | (3,148,245 | ) | 6,151,436 |  |
| Gross profit |  | — |  | 317,050 |  | 60,031 |  | — |  | 377,081 |  |
| Selling, general and administrative expenses |  | — |  | 57,525 |  | 147,065 |  | — |  | 204,590 |  |
| Intangible amortization |  | 75 |  | 605 |  | 7,552 |  | — |  | 8,232 |  |
| Interest and other, net |  | (68,309 | ) | 277,193 |  | (198,962 | ) | — |  | 9,922 |  |
| Income (loss) from continuing operations before income taxes |  | 68,234 |  | (18,273 | ) | 104,376 |  | — |  | 154,337 |  |
| Provision for income taxes |  | — |  | 8,142 |  | 7,292 |  | — |  | 15,434 |  |
| Equity in earnings in subsidiaries |  | 70,669 |  | (49,086 | ) | 50,147 |  | (71,730 | ) | — |  |
| Net income (loss) |  | $ | 138,903 |  | $ | (75,501 | ) | $ | 147,231 |  | $ | (71,730 | ) | $ | 138,903 |  |

[0001104659-14-075227:notes:127]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended September 27, 2013

[0001104659-14-075227:notes:128]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 4,325,352 |  | $ | 5,239,450 |  | $ | (3,154,696 | ) | $ | 6,410,106 |  |
| Cost of sales |  | — |  | 3,965,291 |  | 5,231,088 |  | (3,154,696 | ) | 6,041,683 |  |
| Gross profit |  | — |  | 360,061 |  | 8,362 |  | — |  | 368,423 |  |
| Selling, general and administrative expenses |  | — |  | 57,999 |  | 160,501 |  | — |  | 218,500 |  |
| Intangible amortization |  | 75 |  | 955 |  | 6,688 |  | — |  | 7,718 |  |
| Interest and other, net |  | (163,869 | ) | 284,155 |  | (106,685 | ) | — |  | 13,601 |  |
| Income (loss) from continuing operations before income taxes |  | 163,794 |  | 16,952 |  | (52,142 | ) | — |  | 128,604 |  |
| Provision for income taxes |  | — |  | 2,188 |  | 8,211 |  | — |  | 10,399 |  |
| Equity in earnings in subsidiaries |  | (45,589 | ) | (85,198 | ) | 41,901 |  | 88,886 |  | — |  |
| Net income (loss) |  | $ | 118,205 |  | $ | (70,434 | ) | $ | (18,452 | ) | $ | 88,886 |  | $ | 118,205 |  |

[0001104659-14-075227:notes:129]
Condensed Consolidating Statements of Operations for the Six-Month Period Ended September 26, 2014

[0001104659-14-075227:notes:130]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 8,968,224 |  | $ | 10,025,449 |  | $ | (5,822,411 | ) | $ | 13,171,262 |  |
| Cost of sales |  | — |  | 8,298,137 |  | 9,937,670 |  | (5,822,411 | ) | 12,413,396 |  |
| Gross profit |  | — |  | 670,087 |  | 87,779 |  | — |  | 757,866 |  |
| Selling, general and administrative expenses |  | — |  | 112,019 |  | 301,848 |  | — |  | 413,867 |  |
| Intangible amortization |  | 150 |  | 1,229 |  | 13,804 |  | — |  | 15,183 |  |
| Interest and other, net |  | (51,777 | ) | 536,944 |  | (500,617 | ) | — |  | (15,450 | ) |
| Income from continuing operations before income taxes |  | 51,627 |  | 19,895 |  | 272,744 |  | — |  | 344,266 |  |
| Provision for income taxes |  | — |  | 14,790 |  | 16,686 |  | — |  | 31,476 |  |
| Equity in earnings in subsidiaries |  | 261,163 |  | 12,774 |  | 86,579 |  | (360,516 | ) | — |  |
| Net income (loss) |  | $ | 312,790 |  | $ | 17,879 |  | $ | 342,637 |  | $ | (360,516 | ) | $ | 312,790 |  |

[0001104659-14-075227:notes:131]
Condensed Consolidating Statements of Operations for the Six-Month Period Ended September 27, 2013

[0001104659-14-075227:notes:132]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 8,066,344 |  | $ | 9,582,043 |  | $ | (5,447,156 | ) | $ | 12,201,231 |  |
| Cost of sales |  | — |  | 7,360,905 |  | 9,608,024 |  | (5,447,156 | ) | 11,521,773 |  |
| Gross profit (loss) |  | — |  | 705,439 |  | (25,981 | ) | — |  | 679,458 |  |
| Selling, general and administrative expenses |  | 800 |  | 118,448 |  | 322,871 |  | — |  | 442,119 |  |
| Intangible amortization |  | 150 |  | 2,036 |  | 13,734 |  | — |  | 15,920 |  |
| Interest and other, net |  | (213,203 | ) | 550,750 |  | (304,262 | ) | — |  | 33,285 |  |
| Income (loss) from continuing operations before income taxes |  | 212,253 |  | 34,205 |  | (58,324 | ) | — |  | 188,134 |  |
| Provision for income taxes |  | 10 |  | 6,582 |  | 4,080 |  | — |  | 10,672 |  |
| Equity in earnings in subsidiaries |  | (34,781 | ) | (95,847 | ) | 34,748 |  | 95,880 |  | — |  |
| Net income (loss) |  | $ | 177,462 |  | $ | (68,224 | ) | $ | (27,656 | ) | $ | 95,880 |  | $ | 177,462 |  |

[0001104659-14-075227:notes:133]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended September 26, 2014

[0001104659-14-075227:notes:134]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non- Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 138,903 |  | $ | (75,501 | ) | $ | 147,231 |  | $ | (71,730 | ) | $ | 138,903 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (5,683 | ) | 75,966 |  | 65,611 |  | (141,577 | ) | (5,683 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | (2,433 | ) | (2,058 | ) | (2,433 | ) | 4,491 |  | (2,433 | ) |
| Comprehensive income (loss) |  | $ | 130,787 |  | $ | (1,593 | ) | $ | 210,409 |  | $ | (208,816 | ) | $ | 130,787 |  |

[0001104659-14-075227:notes:135]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended September 27, 2013

[0001104659-14-075227:notes:136]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non- Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 118,205 |  | $ | (70,434 | ) | $ | (18,452 | ) | $ | 88,886 |  | $ | 118,205 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (11,988 | ) | (38,084 | ) | (39,132 | ) | 77,216 |  | (11,988 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | 9,553 |  | 4,668 |  | 9,553 |  | (14,221 | ) | 9,553 |  |
| Comprehensive income (loss) |  | $ | 115,770 |  | $ | (103,850 | ) | $ | (48,031 | ) | $ | 151,881 |  | $ | 115,770 |  |

[0001104659-14-075227:notes:137]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Six-Month Period Ended September 26, 2014

[0001104659-14-075227:notes:138]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non- Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 312,790 |  | $ | 17,879 |  | $ | 342,637 |  | $ | (360,516 | ) | $ | 312,790 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (9,828 | ) | 91,618 |  | 71,337 |  | (162,955 | ) | (9,828 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | 8,292 |  | (228 | ) | 8,292 |  | (8,064 | ) | 8,292 |  |
| Comprehensive income (loss) |  | $ | 311,254 |  | $ | 109,269 |  | $ | 422,266 |  | $ | (531,535 | ) | $ | 311,254 |  |

[0001104659-14-075227:notes:139]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Six-Month Period Ended September 27, 2013

[0001104659-14-075227:notes:140]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non- Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 177,462 |  | $ | (68,224 | ) | $ | (27,656 | ) | $ | 95,880 |  | $ | 177,462 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (29,497 | ) | (64,165 | ) | (66,413 | ) | 130,578 |  | (29,497 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | (581 | ) | 3,424 |  | (582 | ) | (2,842 | ) | (581 | ) |
| Comprehensive income (loss) |  | $ | 147,384 |  | $ | (128,965 | ) | $ | (94,651 | ) | $ | 223,616 |  | $ | 147,384 |  |

[0001104659-14-075227:notes:141]
Condensed Consolidating Statements of Cash Flows for the Six-Month Period Ended September 26, 2014

[0001104659-14-075227:notes:142]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by operating activities |  | $ | 24,949 |  | $ | 217,745 |  | $ | 63,551 |  | $ | — |  | 306,245 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  | — |  | (73,455 | ) | (64,929 | ) | (11 | ) | (138,395 | ) |
| Acquisition of businesses, net of cash acquired |  | — |  | — |  | (32,589 | ) | — |  | (32,589 | ) |
| Proceeds from divesture of business, net of cash held in divested business |  | — |  | — |  | (5,493 | ) | — |  | (5,493 | ) |
| Investing cash flows from (to) affiliates |  | (833,951 | ) | (1,064,718 | ) | 351,146 |  | 1,547,523 |  | — |  |
| Other investing activities, net |  | — |  | (6,134 | ) | (22,721 | ) | — |  | (28,855 | ) |
| Net cash provided by (used in) investing activities |  | (833,951 | ) | (1,144,307 | ) | 225,414 |  | 1,547,512 |  | (205,332 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | — |  | — |  | 11,387 |  | — |  | 11,387 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations |  | (6,250 | ) | (888 | ) | (2,047 | ) | — |  | (9,185 | ) |
| Payments for repurchases of ordinary shares |  | (206,771 | ) | — |  | — |  | — |  | (206,771 | ) |
| Net proceeds from issuance of ordinary shares |  | 11,412 |  | — |  | — |  | — |  | 11,412 |  |
| Financing cash flows from (to) affiliates |  | 925,410 |  | 1,039,792 |  | (417,690 | ) | (1,547,512 | ) | — |  |
| Other financing activities, net |  | — |  | — |  | 3,382 |  | — |  | 3,382 |  |
| Net cash provided by (used in) financing activities |  | 723,801 |  | 1,038,904 |  | (404,968 | ) | (1,547,512 | ) | (189,775 | ) |
| Effect of exchange rates on cash and cash equivalents |  | (83,374 | ) | (1,139 | ) | 93,999 |  | — |  | 9,486 |  |
| Net increase (decrease) in cash and cash equivalents |  | (168,575 | ) | 111,203 |  | (22,004 | ) | — |  | (79,376 | ) |
| Cash and cash equivalents, beginning of period |  | 638,714 |  | 210,462 |  | 744,552 |  | — |  | 1,593,728 |  |
| Cash and cash equivalents, end of period |  | $ | 470,139 |  | $ | 321,665 |  | $ | 722,548 |  | $ | — |  | $ | 1,514,352 |  |

[0001104659-14-075227:notes:143]
Condensed Consolidating Statements of Cash Flows for the Six-Month Period Ended September 27, 2013

[0001104659-14-075227:notes:144]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | 199,101 |  | $ | (729,765 | ) | $ | 884,283 |  | $ | 139 |  | $ | 353,758 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  | — |  | (175,791 | ) | (135,190 | ) | — |  | (310,981 | ) |
| Acquisition of businesses, net of cash acquired |  | — |  | (61,587 | ) | (125,956 | ) | — |  | (187,543 | ) |
| Proceeds from divestiture of business, net of cash held in divested business |  | — |  | — |  | 1,000 |  | — |  | 1,000 |  |
| Investing cash flows from (to) affiliates |  | (345,190 | ) | 110,985 |  | (2,108,241 | ) | 2,342,446 |  | — |  |
| Other investing activities, net |  | — |  | 1,165 |  | 6,271 |  | — |  | 7,436 |  |
| Net cash provided by (used in) investing activities |  | (345,190 | ) | (125,228 | ) | (2,362,116 | ) | 2,342,446 |  | (490,088 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 933,000 |  | 278 |  | 169 |  | — |  | 933,447 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations |  | (403,821 | ) | (979 | ) | (1 | ) | — |  | (404,801 | ) |
| Payments for early retirement of long-term debt |  | (503,422 | ) | (41,418 | ) | — |  | — |  | (544,840 | ) |
| Payments for repurchases of ordinary shares |  | (324,594 | ) | — |  | — |  | — |  | (324,594 | ) |
| Net proceeds from issuance of ordinary shares |  | 19,637 |  | — |  | — |  | — |  | 19,637 |  |
| Financing cash flows from (to) affiliates |  | (90,262 | ) | 823,930 |  | 1,608,917 |  | (2,342,585 | ) | — |  |
| Other financing activities, net |  | — |  | — |  | 14,743 |  | — |  | 14,743 |  |
| Net cash provided by (used in) financing activities |  | (369,462 | ) | 781,811 |  | 1,623,828 |  | (2,342,585 | ) | (306,408 | ) |
| Effect of exchange rates on cash and cash equivalents |  | 38,541 |  | 1,502 |  | (57,326 | ) | — |  | (17,283 | ) |
| Net decrease (increase) in cash and cash equivalents |  | (477,010 | ) | (71,680 | ) | 88,669 |  | — |  | (460,021 | ) |
| Cash and cash equivalents, beginning of period |  | 740,515 |  | 226,372 |  | 620,200 |  | — |  | 1,587,087 |  |
| Cash and cash equivalents, end of period |  | $ | 263,505 |  | $ | 154,692 |  | $ | 708,869 |  | $ | — |  | $ | 1,127,066 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-14-075227:notes:145]
12. BUSINESS AND ASSETS ACQUISITIONS

[0001104659-14-075227:notes:146]
During the three-month period ended September 26, 2014, the Company completed two acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company.  Both of the acquired businesses expanded the Company’s capabilities in the medical devices market, particularly precision plastics.  The total consideration was paid in cash and amounted to $31.4 million net of $5.6 million of cash held by the acquirees.  The Company recorded goodwill of $21.7 million in connection with these acquisitions.  The results of operations were included in the Company’s consolidated financial results beginning on the date of these acquisitions. Pro-forma results of operations for these acquisitions have not been presented because the effects of the acquisitions were immaterial to the Company’s consolidated financial results for all periods presented.

[0001104659-14-075227:notes:147]
The Company is in the process of evaluating the fair value of the assets and liabilities related to business combinations completed during the recent periods. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisition.  Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the respective measurement periods.
