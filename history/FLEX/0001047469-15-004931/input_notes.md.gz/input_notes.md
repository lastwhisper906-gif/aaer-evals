# FLEX notes — 0001047469-15-004931


## flex:BasisOfPresentationAndPrinciplesOfConsolidationPolicyTextBlock

[0001047469-15-004931:notes:1]
Basis of Presentation and Principles of Consolidation

[0001047469-15-004931:notes:2]
The Company's third fiscal quarter ends on December 31, and the fourth fiscal quarter and year ends on March 31 of each year. The first fiscal quarter ended on June 27, 2014 and June 28, 2013, respectively, and the second fiscal quarter ended on September 26, 2014 and September 27, 2013, respectively. Amounts included in the consolidated financial statements are expressed in U.S. dollars unless otherwise designated.

[0001047469-15-004931:notes:3]
The accompanying consolidated financial statements include the accounts of Flextronics and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates all majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a non-controlling interest for the ownership of the non-controlling owners. As of March 31, 2015, the non-controlling interest has been included on the consolidated balance sheets as a component of total shareholders' equity. The associated non-controlling owners' interest in the income or losses of these companies has not been material to the Company's results of operations for any of the periods presented, and has been classified as a component of interest and other, net, in the consolidated statements of operations.

[0001047469-15-004931:notes:4]
During fiscal year 2013, the Company finalized the sale of two of its non-core businesses. In accordance with the accounting guidance, these non-core businesses represent separate asset groups and the divestitures qualify as discontinued operations, and accordingly, the Company has reported the results of operations and financial position of these businesses in discontinued operations within the consolidated statements of operations and consolidated balance sheets for all periods presented as applicable.


## flex:InterestAndOtherNetTextBlock

[0001047469-15-004931:notes:5]
16. INTEREST AND OTHER, NET

[0001047469-15-004931:notes:6]
For the fiscal years ended March 31, 2015, 2014 and 2013, the Company recognized interest income of $18.7 million, $17.6 million and $20.0 million.

[0001047469-15-004931:notes:7]
For the fiscal years ended March 31, 2015, 2014 and 2013, the Company recognized interest expense of $76.4 million, $79.9 million and $68.9 million, respectively, on its debt obligations outstanding during the period.

[0001047469-15-004931:notes:8]
For the fiscal years ended March 31, 2015, 2014 and 2013, the Company recognized gains on foreign exchange transactions of $19.7 million, $11.8 million and $19.9 million, respectively.


## flex:ScheduleOfShareBonusAwardsWithMarketConditionsTableTextBlock

[0001047469-15-004931:notes:9]
|  |  | Targetednumber ofawards as ofMarch 31, 2015(in shares) |  |  |  |  |  | Range of sharesthat may be issued |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment dates |
| Year of grant |  | Market condition |  | Minimum |  | Maximum |
| Fiscal 2015 |  |  | 962,083 |  | $ | 14.77 |  | Vesting ranges from zero to 200% based on measurement of Flextronics' total shareholder return against both the Standard and Poor's ("S&P") 500 Composite Index and an Extended Electronics Manufacturing Services ("EMS") Group Index. |  |  | — |  |  | 1,924,166 |  | May 2017 |
| Fiscal 2014 |  |  | 1,932,000 |  | $ | 9.36 |  | Vesting ranges from zero to 200% based on measurement of Flextronics' total shareholder return against both the Standard and Poor's ("S&P") 500 Composite Index and an Extended Electronics Manufacturing Services ("EMS") Group Index. |  |  | — |  |  | 3,864,000 |  | May 2016 |
| Fiscal 2013 |  |  | 1,591,000 |  | $ | 7.60 |  | Vesting ranges from zero to 200% based on measurement of Flextronics' total shareholder return against the S&P 500 Composite Index. |  |  | — |  |  | 3,182,000 |  | May 2015 |
| Fiscal 2012 |  |  | 380,000 |  | $ | 7.83 |  | Vesting ranges from zero to 150% based on measurement of Flextronics' total shareholder return against the S&P 500 Composite Index. |  |  | — |  |  | 570,000 |  | June 2015 (50%) |
| Totals |  |  | 4,865,083 |  |  |  |  |  |  |  |  |  |  | 9,540,166 |  |  |


## flex:ScheduleOfTaxLossesAndOtherCarryforwardsTableTextBlock

[0001047469-15-004931:notes:10]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
|  |  | (In thousands) |  |
| 2016 - 2021 |  | $ | 344,790 |  |
| 2022 - 2027 |  |  | 939,453 |  |
| 2028 and post |  |  | 660,072 |  |
| Indefinite |  |  | 482,527 |  |
|  |  | $ | 2,426,842 |  |


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0001047469-15-004931:notes:11]
|  |  | As of March 31, |  |
|  |  | 2015 |  | 2014 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 470,908 |  | $ | 412,357 |  |
| Transfers of receivables |  |  | 3,599,768 |  |  | 3,778,420 |  |
| Collections |  |  | (3,470,004 | ) |  | (3,719,869 | ) |
| Ending balance |  | $ | 600,672 |  | $ | 470,908 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001047469-15-004931:notes:12]
21. SUPPLEMENTAL GUARANTOR AND NON-GUARANTOR CONSOLIDATED FINANCIAL STATEMENTS

[0001047469-15-004931:notes:13]
Flextronics International Ltd. ("Parent") has two tranches of Notes of $500 million each outstanding, which mature on February 15, 2020 and February 15, 2023, respectively. These notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company's Credit Facility and the Company's Term Loan due 2018; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the notes are rated investment grade.

[0001047469-15-004931:notes:14]
In lieu of providing separate financial statements for the guarantor subsidiaries, the Company has included the accompanying condensed consolidating financial statements, which are presented using the equity method of accounting. The principal elimination entries relate to investment in subsidiaries and intercompany balances and transactions, including transactions with the Company's non-guarantor subsidiaries.

[0001047469-15-004931:notes:15]
Condensed Consolidating Balance Sheets as of March 31, 2015

[0001047469-15-004931:notes:16]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 608,971 |  | $ | 168,272 |  | $ | 851,165 |  | $ | — |  | $ | 1,628,408 |  |
| Accounts receivable |  |  | — |  |  | 1,193,491 |  |  | 1,144,024 |  |  | — |  |  | 2,337,515 |  |
| Inventories |  |  | — |  |  | 1,729,593 |  |  | 1,759,159 |  |  | — |  |  | 3,488,752 |  |
| Inter company receivable |  |  | 6,417,410 |  |  | 4,774,526 |  |  | 10,218,788 |  |  | (21,410,724 | ) |  | — |  |
| Other current assets |  |  | 8,143 |  |  | 200,476 |  |  | 1,077,606 |  |  | — |  |  | 1,286,225 |  |
| Total current assets |  |  | 7,034,524 |  |  | 8,066,358 |  |  | 15,050,742 |  |  | (21,410,724 | ) |  | 8,740,900 |  |
| Property and equipment, net |  |  | — |  |  | 471,052 |  |  | 1,621,115 |  |  | — |  |  | 2,092,167 |  |
| Goodwill and other intangible assets, net |  |  | 475 |  |  | 60,782 |  |  | 353,918 |  |  | — |  |  | 415,175 |  |
| Other assets |  |  | 2,223,402 |  |  | 155,172 |  |  | 2,131,523 |  |  | (4,092,715 | ) |  | 417,382 |  |
| Investment in subsidiaries |  |  | 1,799,956 |  |  | 1,666,759 |  |  | 16,652,951 |  |  | (20,119,666 | ) |  | — |  |
| Total assets |  | $ | 11,058,357 |  | $ | 10,420,123 |  | $ | 35,810,249 |  | $ | (45,623,105 | ) | $ | 11,665,624 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 40,000 |  | $ | 917 |  | $ | 5,245 |  | $ | — |  | $ | 46,162 |  |
| Accounts payable |  |  | — |  |  | 1,772,695 |  |  | 2,788,499 |  |  | — |  |  | 4,561,194 |  |
| Accrued payroll |  |  | — |  |  | 112,692 |  |  | 227,047 |  |  | — |  |  | 339,739 |  |
| Inter company payable |  |  | 6,559,569 |  |  | 7,309,944 |  |  | 7,541,211 |  |  | (21,410,724 | ) |  | — |  |
| Other current liabilities |  |  | 30,553 |  |  | 772,015 |  |  | 1,006,560 |  |  | — |  |  | 1,809,128 |  |
| Total current liabilities |  |  | 6,630,122 |  |  | 9,968,263 |  |  | 11,568,562 |  |  | (21,410,724 | ) |  | 6,756,223 |  |
| Long term liabilities |  |  | 2,067,421 |  |  | 2,102,483 |  |  | 2,435,962 |  |  | (4,092,715 | ) |  | 2,513,151 |  |
| Flextronics International Ltd. shareholders' equity |  |  | 2,360,814 |  |  | (1,650,623 | ) |  | 21,770,289 |  |  | (20,119,666 | ) |  | 2,360,814 |  |
| Noncontrolling interests |  |  | — |  |  | — |  |  | 35,436 |  |  | — |  |  | 35,436 |  |
| Total shareholders' equity |  |  | 2,360,814 |  |  | (1,650,623 | ) |  | 21,805,725 |  |  | (20,119,666 | ) |  | 2,396,250 |  |
| Total liabilities and shareholders' equity |  | $ | 11,058,357 |  | $ | 10,420,123 |  | $ | 35,810,249 |  | $ | (45,623,105 | ) | $ | 11,665,624 |  |

[0001047469-15-004931:notes:17]
Condensed Consolidating Balance Sheets as of March 31, 2014

[0001047469-15-004931:notes:18]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 638,714 |  | $ | 210,462 |  | $ | 744,552 |  | $ | — |  | $ | 1,593,728 |  |
| Accounts receivable |  |  | — |  |  | 1,229,242 |  |  | 1,468,743 |  |  | — |  |  | 2,697,985 |  |
| Inventories |  |  | — |  |  | 1,705,872 |  |  | 1,893,136 |  |  | — |  |  | 3,599,008 |  |
| Inter company receivable |  |  | 8,867,520 |  |  | 6,963,002 |  |  | 9,528,158 |  |  | (25,358,680 | ) |  | — |  |
| Other current assets |  |  | 246 |  |  | 383,590 |  |  | 1,125,769 |  |  | — |  |  | 1,509,605 |  |
| Total current assets |  |  | 9,506,480 |  |  | 10,492,168 |  |  | 14,760,358 |  |  | (25,358,680 | ) |  | 9,400,326 |  |
| Property and equipment, net |  |  | — |  |  | 490,166 |  |  | 1,798,490 |  |  | — |  |  | 2,288,656 |  |
| Goodwill and other intangible assets, net |  |  | 775 |  |  | 46,917 |  |  | 329,526 |  |  | — |  |  | 377,218 |  |
| Other assets |  |  | 2,585,169 |  |  | 120,738 |  |  | 4,692,157 |  |  | (6,964,114 | ) |  | 433,950 |  |
| Investment in subsidiaries |  |  | 3,350,690 |  |  | 758,612 |  |  | 15,995,623 |  |  | (20,104,925 | ) |  | — |  |
| Total assets |  | $ | 15,443,114 |  | $ | 11,908,601 |  | $ | 37,576,154 |  | $ | (52,427,719 | ) | $ | 12,500,150 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 32,500 |  | $ | 60 |  | $ | 15 |  | $ | — |  | $ | 32,575 |  |
| Accounts payable |  |  | — |  |  | 1,614,383 |  |  | 3,133,396 |  |  | — |  |  | 4,747,779 |  |
| Accrued payroll |  |  | — |  |  | 106,046 |  |  | 248,843 |  |  | — |  |  | 354,889 |  |
| Inter company payable |  |  | 8,607,486 |  |  | 10,126,691 |  |  | 6,624,503 |  |  | (25,358,680 | ) |  | — |  |
| Other current liabilities |  |  | 24,868 |  |  | 756,767 |  |  | 1,739,809 |  |  | — |  |  | 2,521,444 |  |
| Total current liabilities |  |  | 8,664,854 |  |  | 12,603,947 |  |  | 11,746,566 |  |  | (25,358,680 | ) |  | 7,656,687 |  |
| Long term liabilities |  |  | 4,615,210 |  |  | 2,140,985 |  |  | 2,849,703 |  |  | (6,964,114 | ) |  | 2,641,784 |  |
| Flextronics International Ltd. shareholders' equity |  |  | 2,163,050 |  |  | (2,836,331 | ) |  | 22,941,256 |  |  | (20,104,925 | ) |  | 2,163,050 |  |
| Noncontrolling interests |  |  | — |  |  | — |  |  | 38,629 |  |  | — |  |  | 38,629 |  |
| Total shareholders' equity |  |  | 2,163,050 |  |  | (2,836,331 | ) |  | 22,979,885 |  |  | (20,104,925 | ) |  | 2,201,679 |  |
| Total liabilities and shareholders' equity |  | $ | 15,443,114 |  | $ | 11,908,601 |  | $ | 37,576,154 |  | $ | (52,427,719 | ) | $ | 12,500,150 |  |

[0001047469-15-004931:notes:19]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2015

[0001047469-15-004931:notes:20]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 17,620,300 |  | $ | 19,669,882 |  | $ | (11,142,266 | ) | $ | 26,147,916 |  |
| Cost of sales |  |  | — |  |  | 16,133,224 |  |  | 19,611,618 |  |  | (11,142,266 | ) |  | 24,602,576 |  |
| Gross profit |  |  | — |  |  | 1,487,076 |  |  | 58,264 |  |  | — |  |  | 1,545,340 |  |
| Selling, general and administrative expenses |  |  | — |  |  | 233,767 |  |  | 610,706 |  |  | — |  |  | 844,473 |  |
| Intangible amortization |  |  | 300 |  |  | 2,891 |  |  | 28,844 |  |  | — |  |  | 32,035 |  |
| Interest and other, net |  |  | 10,086 |  |  | 850,886 |  |  | (862,795 | ) |  | — |  |  | (1,823 | ) |
| Income (loss) before income taxes |  |  | (10,386 | ) |  | 399,532 |  |  | 281,509 |  |  | — |  |  | 670,655 |  |
| Provision for income taxes |  |  | — |  |  | 14,143 |  |  | 55,711 |  |  | — |  |  | 69,854 |  |
| Equity in earnings in subsidiaries |  |  | 611,187 |  |  | (142,451 | ) |  | 467,940 |  |  | (936,676 | ) |  | — |  |
| Net income |  | $ | 600,801 |  | $ | 242,938 |  | $ | 693,738 |  | $ | (936,676 | ) | $ | 600,801 |  |

[0001047469-15-004931:notes:21]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2014

[0001047469-15-004931:notes:22]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 17,648,879 |  | $ | 21,600,240 |  | $ | (13,140,512 | ) | $ | 26,108,607 |  |
| Cost of sales |  |  | — |  |  | 16,225,232 |  |  | 21,525,018 |  |  | (13,140,512 | ) |  | 24,609,738 |  |
| Restructuring charges |  |  | — |  |  | 9,609 |  |  | 49,039 |  |  | — |  |  | 58,648 |  |
| Gross profit |  |  | — |  |  | 1,414,038 |  |  | 26,183 |  |  | — |  |  | 1,440,221 |  |
| Selling, general and administrative expenses |  |  | — |  |  | 230,041 |  |  | 644,755 |  |  | — |  |  | 874,796 |  |
| Intangible amortization |  |  | 300 |  |  | 4,124 |  |  | 24,468 |  |  | — |  |  | 28,892 |  |
| Restructuring charges |  |  | 800 |  |  | (271 | ) |  | 16,134 |  |  | — |  |  | 16,663 |  |
| Interest and other, net |  |  | (502,028 | ) |  | 864,095 |  |  | (242,651 | ) |  | — |  |  | 119,416 |  |
| Income (loss) before income taxes |  |  | 500,928 |  |  | 316,049 |  |  | (416,523 | ) |  | — |  |  | 400,454 |  |
| Provision for income taxes |  |  | 52 |  |  | 42,944 |  |  | (8,136 | ) |  | — |  |  | 34,860 |  |
| Equity in earnings in subsidiaries |  |  | (135,282 | ) |  | (255,941 | ) |  | 369,429 |  |  | 21,794 |  |  | — |  |
| Net income (loss) |  | $ | 365,594 |  | $ | 17,164 |  | $ | (38,958 | ) | $ | 21,794 |  | $ | 365,594 |  |

[0001047469-15-004931:notes:23]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2013

[0001047469-15-004931:notes:24]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 15,379,151 |  | $ | 17,033,974 |  | $ | (8,843,650 | ) | $ | 23,569,475 |  |
| Cost of sales |  |  | — |  |  | 13,886,798 |  |  | 17,144,245 |  |  | (8,843,650 | ) |  | 22,187,393 |  |
| Restructuring charges |  |  | — |  |  | 26,295 |  |  | 189,539 |  |  | — |  |  | 215,834 |  |
| Gross profit |  |  | — |  |  | 1,466,058 |  |  | (299,810 | ) |  | — |  |  | 1,166,248 |  |
| Selling, general and administrative expenses |  |  | — |  |  | 195,560 |  |  | 609,675 |  |  | — |  |  | 805,235 |  |
| Intangible amortization |  |  | 300 |  |  | 7,840 |  |  | 21,389 |  |  | — |  |  | 29,529 |  |
| Restructuring charges |  |  | — |  |  | 1,646 |  |  | 9,954 |  |  | — |  |  | 11,600 |  |
| Interest and other, net |  |  | (880,051 | ) |  | 702,305 |  |  | 168,815 |  |  | — |  |  | (8,931 | ) |
| Income (loss) from continuing operations before income taxes |  |  | 879,751 |  |  | 558,707 |  |  | (1,109,643 | ) |  | — |  |  | 328,815 |  |
| Provision for income taxes |  |  | — |  |  | 15,396 |  |  | 10,917 |  |  | — |  |  | 26,313 |  |
| Equity in earnings in subsidiaries |  |  | (602,700 | ) |  | (391,748 | ) |  | 591,825 |  |  | 402,623 |  |  | — |  |
| Income from continuing operations |  |  | 277,051 |  |  | 151,563 |  |  | (528,735 | ) |  | 402,623 |  |  | 302,502 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  | — |  |  | (25,451 | ) |  | — |  |  | (25,451 | ) |
| Net income (loss) |  | $ | 277,051 |  | $ | 151,563 |  | $ | (554,186 | ) | $ | 402,623 |  | $ | 277,051 |  |

[0001047469-15-004931:notes:25]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2015

[0001047469-15-004931:notes:26]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income |  | $ | 600,801 |  | $ | 242,938 |  | $ | 693,738 |  | $ | (936,676 | ) | $ | 600,801 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  |  | (18,932 | ) |  | 256,652 |  |  | 221,418 |  |  | (478,070 | ) |  | (18,932 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax |  |  | (35,417 | ) |  | (33,769 | ) |  | (35,417 | ) |  | 69,186 |  |  | (35,417 | ) |
| Comprehensive income |  | $ | 546,452 |  | $ | 465,821 |  | $ | 879,739 |  | $ | (1,345,560 | ) | $ | 546,452 |  |

[0001047469-15-004931:notes:27]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2014

[0001047469-15-004931:notes:28]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 365,594 |  | $ | 17,164 |  | $ | (38,958 | ) | $ | 21,794 |  | $ | 365,594 |  |
| Other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  |  | (34,683 | ) |  | (89,282 | ) |  | (89,635 | ) |  | 178,917 |  |  | (34,683 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax |  |  | (13,992 | ) |  | (5,221 | ) |  | (13,993 | ) |  | 19,214 |  |  | (13,992 | ) |
| Comprehensive income (loss) |  | $ | 316,919 |  | $ | (77,339 | ) | $ | (142,586 | ) | $ | 219,925 |  | $ | 316,919 |  |

[0001047469-15-004931:notes:29]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2013

[0001047469-15-004931:notes:30]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 277,051 |  | $ | 151,563 |  | $ | (554,186 | ) | $ | 402,623 |  | $ | 277,051 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  |  | (16,289 | ) |  | 5,207 |  |  | 10,377 |  |  | (15,584 | ) |  | (16,289 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax |  |  | (20,755 | ) |  | (15,910 | ) |  | (20,755 | ) |  | 36,665 |  |  | (20,755 | ) |
| Comprehensive income (loss) |  | $ | 240,007 |  | $ | 140,860 |  | $ | (564,564 | ) | $ | 423,704 |  | $ | 240,007 |  |

[0001047469-15-004931:notes:31]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2015

[0001047469-15-004931:notes:32]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | (73,356 | ) | $ | 448,685 |  | $ | 418,705 |  | $ | — |  | $ | 794,034 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  |  | — |  |  | (85,876 | ) |  | (153,833 | ) |  | (15 | ) |  | (239,724 | ) |
| Acquisition of businesses, net of cash acquired |  |  | — |  |  | (20,589 | ) |  | (40,772 | ) |  | — |  |  | (61,361 | ) |
| Proceeds from divestitures of business, net of cash held in divested business |  |  | — |  |  | — |  |  | (5,493 | ) |  | — |  |  | (5,493 | ) |
| Investing cash flows from (to) affiliates |  |  | (1,703,983 | ) |  | (2,284,175 | ) |  | 1,178,606 |  |  | 2,809,552 |  |  | — |  |
| Other investing activities, net |  |  | (1,500 | ) |  | (13,821 | ) |  | 79,683 |  |  | — |  |  | 64,362 |  |
| Net cash provided by (used in) investing activities |  |  | (1,705,483 | ) |  | (2,404,461 | ) |  | 1,058,191 |  |  | 2,809,537 |  |  | (242,216 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  |  | 303,000 |  |  | 4,737 |  |  | 11,805 |  |  | — |  |  | 319,542 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations |  |  | (335,500 | ) |  | (3,127 | ) |  | (5,529 | ) |  | — |  |  | (344,156 | ) |
| Payments for repurchases of ordinary shares |  |  | (415,945 | ) |  | — |  |  | — |  |  | — |  |  | (415,945 | ) |
| Proceeds from exercise of stock options |  |  | 23,497 |  |  | — |  |  | 11 |  |  | — |  |  | 23,508 |  |
| Financing cash flows from (to) affiliates |  |  | 2,420,952 |  |  | 1,914,619 |  |  | (1,526,034 | ) |  | (2,809,537 | ) |  | — |  |
| Other financing activities, net |  |  | — |  |  | — |  |  | (98,966 | ) |  | — |  |  | (98,966 | ) |
| Net cash provided by (used in) financing activities |  |  | 1,996,004 |  |  | 1,916,229 |  |  | (1,618,713 | ) |  | (2,809,537 | ) |  | (516,017 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (246,908 | ) |  | (2,643 | ) |  | 248,430 |  |  | — |  |  | (1,121 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (29,743 | ) |  | (42,190 | ) |  | 106,613 |  |  | — |  |  | 34,680 |  |
| Cash and cash equivalents, beginning of period |  |  | 638,714 |  |  | 210,462 |  |  | 744,552 |  |  | — |  |  | 1,593,728 |  |
| Cash and cash equivalents, end of period |  | $ | 608,971 |  | $ | 168,272 |  | $ | 851,165 |  | $ | — |  | $ | 1,628,408 |  |

[0001047469-15-004931:notes:33]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2014

[0001047469-15-004931:notes:34]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | 459,748 |  | $ | (543,426 | ) | $ | 1,299,587 |  | $ | 551 |  |  | 1,216,460 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  |  | — |  |  | (222,197 | ) |  | (292,221 | ) |  | (585 | ) |  | (515,003 | ) |
| Acquisition of businesses, net of cash acquired |  |  | — |  |  | (61,587 | ) |  | (176,444 | ) |  | — |  |  | (238,031 | ) |
| Proceeds from divestitures of business, net of cash held in divested business |  |  | — |  |  | — |  |  | 4,599 |  |  | — |  |  | 4,599 |  |
| Investing cash flows from (to) affiliates |  |  | 35,262 |  |  | (510,168 | ) |  | (1,790,609 | ) |  | 2,265,515 |  |  | — |  |
| Other investing activities, net |  |  | — |  |  | (5,342 | ) |  | (30,155 | ) |  | — |  |  | (35,497 | ) |
| Net cash provided by (used in) investing activities |  |  | 35,262 |  |  | (799,294 | ) |  | (2,284,830 | ) |  | 2,264,930 |  |  | (783,932 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  |  | 1,066,359 |  |  | 277 |  |  | 17 |  |  | — |  |  | 1,066,653 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations |  |  | (492,034 | ) |  | (525 | ) |  | (45,021 | ) |  | — |  |  | (537,580 | ) |
| Payments for early repurchase of long-term debt |  |  | (503,423 | ) |  | (41,417 | ) |  | — |  |  | — |  |  | (544,840 | ) |
| Payments for repurchases of ordinary shares |  |  | (475,314 | ) |  | — |  |  | — |  |  | — |  |  | (475,314 | ) |
| Proceeds from exercise of stock options |  |  | 28,140 |  |  | — |  |  | — |  |  | — |  |  | 28,140 |  |
| Financing cash flows from (to) affiliates |  |  | (277,594 | ) |  | 1,365,834 |  |  | 1,177,241 |  |  | (2,265,481 | ) |  | — |  |
| Other financing activities, net |  |  | — |  |  | — |  |  | 52,149 |  |  | — |  |  | 52,149 |  |
| Net cash provided by (used in) financing activities |  |  | (653,866 | ) |  | 1,324,169 |  |  | 1,184,386 |  |  | (2,265,481 | ) |  | (410,792 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | 57,055 |  |  | 2,641 |  |  | (74,791 | ) |  | — |  |  | (15,095 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (101,801 | ) |  | (15,910 | ) |  | 124,352 |  |  | — |  |  | 6,641 |  |
| Cash and cash equivalents, beginning of period |  |  | 740,515 |  |  | 226,372 |  |  | 620,200 |  |  | — |  |  | 1,587,087 |  |
| Cash and cash equivalents, end of period |  | $ | 638,714 |  | $ | 210,462 |  | $ | 744,552 |  | $ | — |  | $ | 1,593,728 |  |

[0001047469-15-004931:notes:35]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2013

[0001047469-15-004931:notes:36]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | 836,830 |  | $ | 695,596 |  | $ | (416,280 | ) | $ | (716 | ) |  | 1,115,430 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  |  | — |  |  | (137,921 | ) |  | (297,937 | ) |  | 530 |  |  | (435,328 | ) |
| Acquisition of businesses, net of cash acquired |  |  | — |  |  | (20,150 | ) |  | (163,947 | ) |  | — |  |  | (184,097 | ) |
| Proceeds from divestitures of business, net of cash held in divested business |  |  | — |  |  | — |  |  | 22,585 |  |  | — |  |  | 22,585 |  |
| Investing cash flows from (to) affiliates |  |  | (1,228,773 | ) |  | 965,298 |  |  | 1,166,809 |  |  | (903,334 | ) |  | — |  |
| Other investing activities, net |  |  | — |  |  | 6,412 |  |  | (106,771 | ) |  | — |  |  | (100,359 | ) |
| Net cash provided by (used in) investing activities |  |  | (1,228,773 | ) |  | 813,639 |  |  | 620,739 |  |  | (902,804 | ) |  | (697,199 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  |  | 1,250,000 |  |  | 150 |  |  | 63 |  |  | — |  |  | 1,250,213 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations |  |  | (379,399 | ) |  | (3,875 | ) |  | (8,585 | ) |  |  |  |  | (391,859 | ) |
| Payments for early repurchase of long-term debt |  |  | (756,855 | ) |  | (243,145 | ) |  | — |  |  |  |  |  | (1,000,000 | ) |
| Payments for repurchases of ordinary shares |  |  | (322,040 | ) |  | — |  |  | — |  |  | — |  |  | (322,040 | ) |
| Proceeds from exercise of stock options |  |  | 22,257 |  |  | — |  |  | — |  |  | — |  |  | 22,257 |  |
| Financing cash flows from (to) affiliates |  |  | 693,185 |  |  | (1,213,350 | ) |  | (383,355 | ) |  | 903,520 |  |  | — |  |
| Other financing activities, net |  |  | — |  |  | — |  |  | 101,851 |  |  | — |  |  | 101,851 |  |
| Net cash provided by (used in) financing activities |  |  | 507,148 |  |  | (1,460,220 | ) |  | (290,026 | ) |  | 903,520 |  |  | (339,578 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (23,942 | ) |  | (1,801 | ) |  | 15,848 |  |  | — |  |  | (9,895 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 91,263 |  |  | 47,214 |  |  | (69,719 | ) |  | — |  |  | 68,758 |  |
| Cash and cash equivalents, beginning of period |  |  | 649,252 |  |  | 179,158 |  |  | 689,919 |  |  | — |  |  | 1,518,329 |  |
| Cash and cash equivalents, end of period |  | $ | 740,515 |  | $ | 226,372 |  | $ | 620,200 |  | $ | — |  | $ | 1,587,087 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001047469-15-004931:notes:37]
2. SUMMARY OF ACCOUNTING POLICIES

[0001047469-15-004931:notes:38]
Use of Estimates

[0001047469-15-004931:notes:39]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; asset impairments; fair values of financial instruments including investments, notes receivable and derivative instruments; restructuring charges; contingencies; fair values of assets and liabilities obtained in business combinations and the fair values of stock options and share bonus awards granted under the Company's stock-based compensation plans. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0001047469-15-004931:notes:40]
Translation of Foreign Currencies

[0001047469-15-004931:notes:41]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive loss, a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for any of the periods presented, and have been classified as a component of interest and other, net in the consolidated statements of operations.

[0001047469-15-004931:notes:42]
Revenue Recognition

[0001047469-15-004931:notes:43]
The Company recognizes manufacturing revenue when it ships goods or the goods are received by its customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then the Company recognizes the related revenues at the time when such requirements are completed and the obligations are fulfilled. Some of the Company's customer contracts allow the recovery of certain costs related to manufacturing services that are over and above the prices charged for the related products. The Company determines the amount of costs that are recoverable based on historical experiences and agreements with those customers. Also, certain customer contracts may contain certain commitments and obligations that may result in additional expenses or decrease in revenue. The Company accrues for these commitments and obligations based on facts and circumstances and contractual terms. The Company also makes provisions for estimated sales returns and other adjustments at the time revenue is recognized based upon contractual terms and an analysis of historical returns. Provisions for sales returns and other adjustments were not material to the consolidated financial statements for any of the periods presented.

[0001047469-15-004931:notes:44]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The Company recognizes service revenue when the services have been performed, and the related costs are expensed as incurred. Sales for services were less than 10% of the Company's total sales for all periods presented, and accordingly, are included in net sales in the consolidated statements of operations.

[0001047469-15-004931:notes:45]
Customer Credit Risk

[0001047469-15-004931:notes:46]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0001047469-15-004931:notes:47]
Concentration of Credit Risk

[0001047469-15-004931:notes:48]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, cash and cash equivalents, and derivative instruments.

[0001047469-15-004931:notes:49]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2015, 2014 and 2013:

[0001047469-15-004931:notes:50]
|  |  | Balance atBeginningof Year |  | Charged toCosts andExpenses |  | Deductions/Write-Offs |  | Balance atEnd ofYear |  |
|  |  | (In thousands) |  |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Year ended March 31, 2013(1) |  | $ | 38,905 |  | $ | 6,643 |  | $ | (34,671 | ) | $ | 10,877 |  |
| Year ended March 31, 2014 |  | $ | 10,877 |  | $ | 2,029 |  | $ | (7,377 | ) | $ | 5,529 |  |
| Year ended March 31, 2015 |  | $ | 5,529 |  | $ | 650 |  | $ | (1,645 | ) | $ | 4,534 |  |

[0001047469-15-004931:notes:51]
| (1) | Fiscal year 2013 includes a $28.0 million write off related to a fiscal year 2012 charge for a distressed customer and $5.8 million which was previously reserved and the underlying accounts receivable balance was reclassified to non-current assets in fiscal year 2013 and was carried net of its specific reserve. |

[0001047469-15-004931:notes:52]
One customer (including net sales from its current and former parent companies, through the dates of their respective ownership during the current fiscal year), which is within the Company's CTG business group, accounted for approximately 17% and 13% of the Company's net sales and approximately 15% and 14% of the Company's total accounts receivable balances in fiscal years 2015 and 2014, respectively. No customer accounted for greater than 10% of the Company's net sales in fiscal year 2013. The Company's ten largest customers accounted for approximately 50%, 52% and 47%, of its net sales in fiscal years 2015, 2014 and 2013, respectively.

[0001047469-15-004931:notes:53]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0001047469-15-004931:notes:54]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 8.

[0001047469-15-004931:notes:55]
Cash and Cash Equivalents

[0001047469-15-004931:notes:56]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0001047469-15-004931:notes:57]
Cash and cash equivalents consisted of the following:

[0001047469-15-004931:notes:58]
|  |  | As of March 31, |  |
|  |  | 2015 |  | 2014 |  |
|  |  | (In thousands) |  |
| Cash and bank balances |  | $ | 953,549 |  | $ | 1,040,800 |  |
| Money market funds and time deposits |  |  | 674,859 |  |  | 552,928 |  |
|  |  | $ | 1,628,408 |  | $ | 1,593,728 |  |

[0001047469-15-004931:notes:59]
Inventories

[0001047469-15-004931:notes:60]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or market value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of lower of cost or market write-downs, were as follows:

[0001047469-15-004931:notes:61]
|  |  | As of March 31, |  |
|  |  | 2015 |  | 2014 |  |
|  |  | (In thousands) |  |
| Raw materials |  | $ | 2,330,428 |  | $ | 2,349,278 |  |
| Work-in-progress |  |  | 557,786 |  |  | 608,284 |  |
| Finished goods |  |  | 600,538 |  |  | 641,446 |  |
|  |  | $ | 3,488,752 |  | $ | 3,599,008 |  |

[0001047469-15-004931:notes:62]
Property and Equipment, Net

[0001047469-15-004931:notes:63]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are amortized over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment was comprised of the following:

[0001047469-15-004931:notes:64]
|  |  |  |  | As of March 31, |  |
|  |  | DepreciableLife(In Years) |  |
|  |  | 2015 |  | 2014 |  |
|  |  |  |  | (In thousands) |  |
| Machinery and equipment |  | 3 - 10 |  | $ | 2,928,903 |  | $ | 2,929,449 |  |
| Buildings |  | 30 |  |  | 1,067,837 |  |  | 1,069,376 |  |
| Leasehold improvements |  | up to 30 |  |  | 459,926 |  |  | 470,960 |  |
| Furniture, fixtures, computer equipment and software |  | 3 - 7 |  |  | 440,878 |  |  | 427,038 |  |
| Land |  | — |  |  | 123,633 |  |  | 127,567 |  |
| Construction-in-progress |  | — |  |  | 140,786 |  |  | 88,687 |  |
|  |  |  |  |  | 5,161,963 |  |  | 5,113,077 |  |
| Accumulated depreciation and amortization |  |  |  |  | (3,069,796 | ) |  | (2,824,421 | ) |
| Property and equipment, net |  |  |  | $ | 2,092,167 |  | $ | 2,288,656 |  |

[0001047469-15-004931:notes:65]
Total depreciation expense associated with property and equipment amounted to approximately $496.8 million, $424.8 million and $412.3 million in fiscal years 2015, 2014 and 2013, respectively.

[0001047469-15-004931:notes:66]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is measured by comparing its carrying amount to the projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0001047469-15-004931:notes:67]
Deferred Income Taxes

[0001047469-15-004931:notes:68]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0001047469-15-004931:notes:69]
Accounting for Business and Asset Acquisitions

[0001047469-15-004931:notes:70]
The Company has actively pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0001047469-15-004931:notes:71]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0001047469-15-004931:notes:72]
Goodwill and Other Intangible Assets

[0001047469-15-004931:notes:73]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. If the recorded value of the assets, including goodwill, and liabilities ("net book value") of each reporting unit exceeds its fair value, an impairment loss may be required to be recognized. Further, to the extent the net book value of the Company as a whole is greater than its fair value in the aggregate, all, or a significant portion of its goodwill may be considered impaired.

[0001047469-15-004931:notes:74]
As discussed in note 19, the Company concluded that as of the fourth quarter of fiscal year 2015 it has four reportable operating segments: HRS, CTG, IEI and INS and concluded these same four segments also represented its reporting units. The Company performed its goodwill impairment assessment on January 1, 2015 and determined that no impairment existed as of the date of the impairment test because the fair value of each reporting unit exceeded its carrying value. The Company changed the date of its annual goodwill impairment test from January 31 in order to better align with its reporting calendar. This change is within twelve months from the previous assessment date as well as within the same fiscal quarter and did not have a material impact on the consolidated financial statements.

[0001047469-15-004931:notes:75]
The following table summarizes the activity in the Company's goodwill at the one reporting unit level through December 31, 2014, and at the four reporting unit level from January 1, 2015 through March 31, 2015 (in thousands):

[0001047469-15-004931:notes:76]
|  |  | HRS |  | CTG |  | IEI |  | INS |  | Total |  |
| Balance, as of March 31, 2013 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 262,005 |  |
| Additions(1) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 26,270 |  |
| Purchase accounting adjustments(2) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4,034 |  |
| Foreign currency translation adjustments |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 449 |  |
| Balance, as of March 31, 2014 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 292,758 |  |
| Additions(1) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 36,467 |  |
| Purchase accounting adjustments(2) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8,651 |  |
| Foreign currency translation adjustments |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (3,393 | ) |
| Balance, as of December 31, 2014(3) |  |  | 93,990 |  |  | 68,234 |  |  | 64,221 |  |  | 108,038 |  |  | 334,483 |  |
| Purchase accounting adjustments(2) |  |  | (656 | ) |  | — |  |  | — |  |  | — |  |  | (656 | ) |
| Foreign currency translation adjustments |  |  | (196 | ) |  | — |  |  | — |  |  | — |  |  | (196 | ) |
| Balance, as of March 31, 2015 |  | $ | 93,138 |  | $ | 68,234 |  | $ | 64,221 |  | $ | 108,038 |  | $ | 333,631 |  |

[0001047469-15-004931:notes:77]
| (1) | The goodwill generated from the Company's business combinations completed during the fiscal years 2015 and 2014 are primarily related to value placed on the employee workforce, service offerings and capabilities and expected synergies. The goodwill is not deductible for income tax purposes. Refer to the discussion of the Company's business acquisitions in note 17. |
| (2) | Includes adjustments based on management's estimates resulting from their review and finalization of the valuation of assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition. These adjustments were not individually, nor in the aggregate, significant to the Company. |
| (3) | Goodwill is allocated to each of the reporting units based on the relative fair values assessed in conjunction with the goodwill impairment testing conducted as of January 1, 2015. |

[0001047469-15-004931:notes:78]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2015 and concluded that such amounts continued to be recoverable.

[0001047469-15-004931:notes:79]
Intangible assets are comprised of customer-related intangible assets, that include contractual agreements and customer relationships; and licenses and other intangible assets, that are primarily comprised of licenses and also includes patents and trademarks, and developed technologies. Generally customer-related intangible assets are amortized on an accelerated method based on expected cash flows, primarily over a period of up to eight years. Licenses and other intangible assets are generally amortized on a straight line basis over a period of up to seven years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability. The components of acquired intangible assets are as follows:

[0001047469-15-004931:notes:80]
|  |  | As of March 31, 2015 |  | As of March 31, 2014 |  |
|  |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  |
|  |  | (In thousands) |  |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles |  | $ | 133,853 |  | $ | (80,506 | ) | $ | 53,347 |  | $ | 204,369 |  | $ | (140,713 | ) | $ | 63,656 |  |
| Licenses and other intangibles |  |  | 39,985 |  |  | (11,788 | ) |  | 28,197 |  |  | 32,564 |  |  | (11,760 | ) |  | 20,804 |  |
| Total |  | $ | 173,838 |  | $ | (92,294 | ) | $ | 81,544 |  | $ | 236,933 |  | $ | (152,473 | ) | $ | 84,460 |  |

[0001047469-15-004931:notes:81]
The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2015, the gross carrying amounts of such intangible assets fully amortized totaled $94.9 million. During the year ended March 31, 2015, the Company's customer-related intangible assets increased by $16.1 million in connection with the Company's acquisitions, and licenses and other intangible assets increased by $15.7 million primarily as a result of the purchase of certain technology rights. Total intangible asset amortization expense recognized in continuing operations during fiscal years 2015, 2014 and 2013 was $32.0 million, $28.9 million and $29.5 million, respectively. As of March 31, 2015, the weighted-average remaining useful lives of the Company's intangible assets were approximately 4.6 years and 4.2 years for customer-related intangibles, and licenses and other intangible assets, respectively. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0001047469-15-004931:notes:82]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2016 |  | $ | 27,449 |  |
| 2017 |  |  | 19,701 |  |
| 2018 |  |  | 14,000 |  |
| 2019 |  |  | 9,760 |  |
| 2020 |  |  | 5,224 |  |
| Thereafter |  |  | 5,410 |  |
| Total amortization expense |  | $ | 81,544 |  |

[0001047469-15-004931:notes:83]
Derivative Instruments and Hedging Activities

[0001047469-15-004931:notes:84]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in the spot currency rates and the change in the present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency LIBOR rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Additional information is included in note 8.

[0001047469-15-004931:notes:85]
Other Current Assets

[0001047469-15-004931:notes:86]
Other current assets includes approximately $600.7 million and $470.9 million as of March 31, 2015 and 2014, respectively for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0001047469-15-004931:notes:87]
Other current assets as of March 31, 2015 and 2014 included certain assets purchased on behalf of a customer and financed by a third party banking institution of $169.2 million and $267.5 million, respectively, as further described in note 17.

[0001047469-15-004931:notes:88]
Investments

[0001047469-15-004931:notes:89]
The Company has certain equity investments in, and notes receivable from, non-publicly traded companies which are included within other assets. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer; otherwise the cost method is used. Non-majority-owned investments in corporations are accounted for using the equity method when the Company has an ownership percentage equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required. Fair values of these investments, when required, are estimated using unobservable inputs, primarily discounted cash flow projections.

[0001047469-15-004931:notes:90]
As of March 31, 2015 and 2014, the Company's equity investments in non-majority owned companies totaled $87.0 million and $77.4 million, respectively. The equity in the earnings or losses of the Company's equity method investments was not material to the consolidated results of operations for any period presented and is included in interest and other, net.

[0001047469-15-004931:notes:91]
Other Current Liabilities

[0001047469-15-004931:notes:92]
Other current liabilities include customer working capital advances of $189.6 million and $754.7 million, customer-related accruals of $454.8 million and $327.5 million, and deferred revenue of $272.6 million and $296.3 million as of March 31, 2015 and 2014, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Other current liabilities as of March 31, 2015 and 2014 also included the outstanding balances due to the third party banking institution related to the financed equipment discussed above, that amounted to $197.7 million and $286.5 million, respectively, as further described in note 17.

[0001047469-15-004931:notes:93]
Restructuring Charges

[0001047469-15-004931:notes:94]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing and administrative facilities. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0001047469-15-004931:notes:95]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed exit plans. See note 14 for additional information regarding restructuring charges.

[0001047469-15-004931:notes:96]
Recent Accounting Pronouncements

[0001047469-15-004931:notes:97]
In April 2015, the Financial Accounting Standards Board ("FASB") issued new guidance which changes the presentation of debt issuance costs in financial statements. Under the new guidance, an entity presents such costs in the balance sheet as a direct deduction from the related debt liability rather than as an asset. Amortization of the costs is reported as interest expense. This guidance is effective for the Company beginning in the first quarter of fiscal year 2017 and early adoption is permitted in an interim period with any adjustments reflected as of the beginning of the fiscal year that includes that interim period. The guidance is not expected to have a significant impact to the Company's consolidated financial statements.

[0001047469-15-004931:notes:98]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. In April 2015, the FASB proposed to defer the effective date of the standard by a year and if such proposal is adopted, this guidance is effective for the Company beginning in the first quarter of fiscal year 2019. The Company is in the process of assessing the impact on its consolidated financial statements.

[0001047469-15-004931:notes:99]
In April 2014, the Financial Accounting Standards Board issued guidance which requires an entity to report a disposal of a component of an entity in discontinued operations if the disposal represents a strategic shift that has a major effect on an entity's operations and financial results when the component of an entity meets certain criteria to be classified as held for sale, or when the component of an entity is otherwise disposed. The Company early adopted this accounting standard update in the first quarter of fiscal year 2015. During fiscal year 2015, the Company recognized a loss of $11.0 million recorded in other income and expense, for the disposal of a manufacturing facility in Western Europe which did not meet the criteria of discontinued operations under this accounting standard.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001047469-15-004931:notes:100]
17. BUSINESS AND ASSET ACQUISITIONS

[0001047469-15-004931:notes:101]
Business Acquisitions

[0001047469-15-004931:notes:102]
The business and asset acquisitions described below were accounted for using the purchase method of accounting, and accordingly, the fair value of the net assets acquired and the results of the acquired businesses were included in the Company's consolidated financial statements from the acquisition dates forward. The Company has not finalized the allocation of the consideration for certain of its recently completed acquisitions and generally expects to complete these allocations within one year of the respective acquisition dates.

[0001047469-15-004931:notes:103]
Fiscal year 2015 business acquisitions

[0001047469-15-004931:notes:104]
During the fiscal year 2015, the Company completed four acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. All of the acquired businesses expanded the Company's capabilities in the medical devices market, particularly precision plastics, within the HRS business group. The Company paid $52.7 million net of $5.9 million of cash held by the acquired businesses, and recorded an accrual of $4.5 million for contingent consideration relating to one of the acquisitions. The Company primarily acquired $29.4 million of current assets, $9.0 million of property and equipment, recorded goodwill of $35.8 million and intangibles of $16.1 million, and assumed certain liabilities relating to payables and debt in connection with these acquisitions. The results of operations were included in the Company's consolidated financial results beginning on the date of these acquisitions. Pro-forma results of operations for these acquisitions have not been presented because the effects of the acquisitions were immaterial to the Company's consolidated financial results for all periods presented. The Company also paid $7.5 million as a deposit to acquire another business expected to close in fiscal year 2016, which is included in other assets.

[0001047469-15-004931:notes:105]
Fiscal year 2014 business acquisitions

[0001047469-15-004931:notes:106]
Acquisition of Motorola Mobility LLC from Google

[0001047469-15-004931:notes:107]
On April 16, 2013, the Company completed the acquisition of certain manufacturing operations from Google's Motorola Mobility LLC. The Company also entered into a manufacturing and services agreement with Motorola Mobility for mobile devices in conjunction with this acquisition. This acquisition expanded the Company's relationship with Google's Motorola Mobility and the Company's capabilities in the mobile devices market, within the CTG business group. The results of operations were included in the Company's consolidated financial results beginning on the date of acquisition. Revenues were approximately 11.5% of total revenue for the fiscal year ended March 31, 2014. Income before tax of the acquired operations for the fiscal year ended March 31, 2014 was not significant to the consolidated financial results of the Company. On a pro forma basis, the estimated increase to our previously reported revenue amounts to reflect the acquisition of this business as of the first day of the prior comparative period is $3.3 billion for the year-ended March 31, 2013, and operating results for the same period was immaterial.

[0001047469-15-004931:notes:108]
The cash consideration for this acquisition amounted to $178.9 million. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001047469-15-004931:notes:109]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities assumed of Google's Motorola Mobility LLC (in thousands):

[0001047469-15-004931:notes:110]
| Current assets: |  |  |  |  |
| Inventories |  | $ | 97,740 |  |
| Other current assets |  |  | 24,280 |  |
| Total current assets |  |  | 122,020 |  |
| Property and equipment |  |  | 45,198 |  |
| Goodwill |  |  | 2,844 |  |
| Other intangible assets (useful life—6 years) |  |  | 2,948 |  |
| Other assets |  |  | 7,414 |  |
| Total assets |  | $ | 180,424 |  |
| Current liabilities: |  |  |  |  |
| Other current liabilities |  | $ | 317 |  |
| Total current liabilities |  |  | 317 |  |
| Other liabilities |  |  | 1,202 |  |
| Total aggregate purchase price |  | $ | 178,905 |  |

[0001047469-15-004931:notes:111]
Acquisition of Riwisa AG

[0001047469-15-004931:notes:112]
On November 4, 2013, the Company acquired all of the outstanding shares of Riwisa AG, a company registered in Switzerland for total cash consideration of $44.0 million, net of cash acquired amounting to $9.4 million. This acquisition expanded the Company's capabilities in the medical devices market, particularly precision plastics within the HRS business group. The Company primarily acquired inventory, property and equipment and assumed certain liabilities relating to payables and debt. The results of operations were included in the Company's consolidated financial results beginning on the date of acquisition. Proforma results of operations for this acquisition have not been presented because the effects of the acquisition were not material to the Company's consolidated financial results.

[0001047469-15-004931:notes:113]
The initial allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill. During fiscal year 2014 the Company recorded $22.7 million as intangible assets and $18.5 million as goodwill based on a preliminary assessment of fair value of assets acquired and liabilities assumed. During fiscal year 2015, the Company further adjusted the purchase allocation for the acquisition resulting in a $2.6 million increase in the total cash consideration from $44.0 million to $46.6 million, and an $8.7 million fair value adjustment for assets acquired, increasing total goodwill to $27.2 million. Intangible assets are comprised of customer-relationships of $15.8 million amortized over a period of 10 years and developed technology and trade names of $6.9 million amortized over a period of 7 years.

[0001047469-15-004931:notes:114]
Other business acquisitions

[0001047469-15-004931:notes:115]
Further, during fiscal year 2014, the Company completed two other acquisitions for total cash consideration of $15.1 million. Neither of these acquisitions were significant to the Company's consolidated financial position, results of operations and cash flows. These businesses expanded the Company's capabilities primarily in manufacturing operations for precision plastics, components and molds. The Company acquired primarily property and equipment and inventory and recorded goodwill amounting to $5.0 million in connection with these acquisitions. The results of operations were included in the Company's consolidated financial results beginning on the dates of these acquisitions. Proforma results of operations for these acquisitions have not been presented because the effects of the acquisitions were immaterial to the Company's consolidated financial results. Additionally, transaction costs related to all acquisitions completed during the periods presented were immaterial to the Company's financial results.

[0001047469-15-004931:notes:116]
The Company continues to evaluate certain assets and liabilities related to business combinations completed during recent periods. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Changes to amounts recorded as assets or liabilities, as a result of such additional information, may result in a corresponding adjustment to goodwill.

[0001047469-15-004931:notes:117]
The goodwill generated from the Company's business combinations completed during the fiscal year ended March 31, 2014 is primarily related to value placed on the employee workforce, service offerings and capabilities, and expected synergies and is not deductible for income tax purposes.

[0001047469-15-004931:notes:118]
Fiscal year 2013 business acquisitions

[0001047469-15-004931:notes:119]
Acquisition of Saturn Electronics and Engineering Inc.

[0001047469-15-004931:notes:120]
During the fiscal year 2013, the Company completed its acquisition of all outstanding common stock of Saturn Electronics and Engineering, Inc. ("Saturn"), a supplier of electronics manufacturing services, solenoids and wiring for the automotive, appliance, consumer, energy and industrial markets. The acquisition of Saturn broadened the Company's service offering and strengthened its capabilities in the automotive and consumer electronics businesses within the HRS business group. The results of operations were included in the Company's consolidated financial results beginning on the date of acquisition which amounted to approximately $100.9 million in revenue for the year ended March 31, 2013. Net income of the acquired business during the fiscal year ended March 31, 2013 was not significant to the consolidated operating results of the Company.

[0001047469-15-004931:notes:121]
The initial cash consideration for this acquisition amounted to $193.7 million with up to an additional $15.0 million of estimated potential contingent consideration, for a total purchase consideration of $208.7 million. During fiscal year 2015, the Company paid $11.3 million to settle all remaining contingent consideration.

[0001047469-15-004931:notes:122]
The allocation of the purchase price to Saturn's tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. Management determined the value of acquired intangible assets with the assistance of a third-party appraisal firm. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001047469-15-004931:notes:123]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities assumed of Saturn (in thousands):

[0001047469-15-004931:notes:124]
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,191 |  |
| Accounts receivable |  |  | 44,879 |  |
| Inventories |  |  | 23,350 |  |
| Other current assets |  |  | 1,970 |  |
| Total current assets |  |  | 72,390 |  |
| Property and equipment |  |  | 40,392 |  |
| Goodwill |  |  | 102,725 |  |
| Other intangible assets |  |  | 57,200 |  |
| Other assets |  |  | 925 |  |
| Total assets |  | $ | 273,632 |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 29,616 |  |
| Other current liabilities |  |  | 1,740 |  |
| Total current liabilities |  |  | 31,356 |  |
| Other liabilities |  |  | 33,585 |  |
| Total aggregate purchase price |  | $ | 208,691 |  |

[0001047469-15-004931:notes:125]
The intangible assets of $57.2 million is comprised of customer-relationships of $46.4 million and developed technology amounting to $10.8 million. Customer relationships are amortized over an estimated useful life of 5 years and developed technology is amortized over an estimated useful life of 7 years.

[0001047469-15-004931:notes:126]
Additionally, during the fiscal year 2013, the Company completed three other acquisitions that were not individually, nor in the aggregate, significant to the Company's consolidated financial position, results of operations and cash flows. The total consideration, which was paid in cash for these acquisitions, and earn outs related to certain prior period acquisitions amounted to $72.7 million. The total amount of cash acquired from these acquisitions amounted to $80.1 million, resulting in net cash of $7.4 million acquired from these acquisitions during the fiscal year ended 2013. One of the acquired businesses expanded the Company's capabilities primarily in the medical and defense markets; another acquired business supports the hardware product manufacturing needs of an existing customer in the technology industry; and the other acquired business expanded the Company's capabilities primarily in the LED design and manufacturing market. The Company primarily acquired cash, inventory and certain other manufacturing assets, and recorded goodwill of $61.9 million in connection with these acquisitions. The aggregate results of operations for these acquisitions were included in the Company's consolidated financial results beginning on the dates of acquisition which amounted to approximately $231.3 million in revenue for the fiscal year ended March 31, 2013. Operating results of these acquisitions during the fiscal year ended March 31, 2013 was not significant, individually or in the aggregate, to the consolidated operating results of the Company.

[0001047469-15-004931:notes:127]
In connection with one of the acquired businesses, the Company entered into an agreement with an existing customer and a third party banking institution to procure certain manufacturing equipment that was financed by the third party banking institution, acting as an agent of the customer. The manufacturing equipment was used exclusively for the benefit of this customer. The Company has the ability to settle the obligation related to these financed assets by returning the equipment to the customer and cannot be required to pay cash by either the customer or the third party banking institution. During fiscal year 2015, the Company ceased manufacturing of the product related to the financed equipment. As a result, pursuant an agreement with the customer, the Company as an agent on behalf of the customer is in the process of dispositioning the equipment via sales to third parties and forwarding the proceeds to the third party banking institution reducing the outstanding obligation. Accordingly, the value of the equipment financed by the third party banking institution decreased to $169.2 million from $267.5 million as of March 31, 2015 and 2014, respectively, and has been included in other current assets. The outstanding balance due to the third party banking institution related to the financed equipment correspondingly decreased to $197.7 million from $286.5 million as of March 31, 2015 and 2014, respectively, and has been included in other current liabilities. The cash inflows from the sale of the manufacturing equipment originally purchased on behalf of the customer and financed by the third party banking institution amounting to $79.7 million have been included in other investing cash flows for the fiscal year ended March 31, 2015. The cash outflows relating to the purchase of the manufacturing equipment by the Company on behalf of the customer amounting to $37.3 million and $115.3 million have also been included in other investing cash flows for the fiscal years ended March 31, 2014 and 2013, respectively. The cash outflows to repay the third party banking institution on behalf of the customer upon cessation of manufacturing operations amounting to $88.8 million have been included in cash flows from other financing activities during the fiscal year ended March 31, 2015. Net cash inflows amounting to $13.5 million and $101.9 million relating to the funding of these assets by the financial institution on behalf of the customer have been included in cash flows from other financing activities during the fiscal years ended March 31, 2014 and 2013, respectively.

[0001047469-15-004931:notes:128]
Acquisition of Mirror Controls International

[0001047469-15-004931:notes:129]
On April 29, 2015, the Company announced that it has entered into a definitive agreement to acquire Mirror Controls International (MCi) from private equity firm Egeria in an all cash transaction valuing its share capital at approximately $500.0 million. The transaction is expected to close in the second quarter of fiscal year 2016 and will be included as part of our HRS business group. A preliminary purchase price allocation is not yet available for this acquisition.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001047469-15-004931:notes:130]
6. SUPPLEMENTAL CASH FLOW DISCLOSURES

[0001047469-15-004931:notes:131]
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0001047469-15-004931:notes:132]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Net cash paid for: |  |  |  |  |  |  |  |  |  |  |
| Interest |  | $ | 87,179 |  | $ | 86,406 |  | $ | 66,071 |  |
| Income taxes |  | $ | 70,621 |  | $ | 87,561 |  | $ | 52,306 |  |
| Non-cash investing activity: |  |  |  |  |  |  |  |  |  |  |
| Unpaid purchases of property and equipment |  | $ | 115,757 |  | $ | 42,902 |  | $ | 89,718 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001047469-15-004931:notes:133]
12. COMMITMENTS AND CONTINGENCIES

[0001047469-15-004931:notes:134]
Commitments

[0001047469-15-004931:notes:135]
As of March 31, 2015 and 2014, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under capital leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2028 and require the following minimum lease payments:

[0001047469-15-004931:notes:136]
| Fiscal Year Ending March 31, |  | Operating Lease |  |
|  |  | (In thousands) |  |
| 2016 |  | $ | 115,695 |  |
| 2017 |  |  | 91,272 |  |
| 2018 |  |  | 80,555 |  |
| 2019 |  |  | 65,780 |  |
| 2020 |  |  | 57,366 |  |
| Thereafter |  |  | 163,393 |  |
| Total minimum lease payments |  | $ | 574,061 |  |

[0001047469-15-004931:notes:137]
Total rent expense amounted to $133.1 million, $150.1 million and $138.8 million in fiscal years 2015, 2014 and 2013, respectively.

[0001047469-15-004931:notes:138]
Litigation and other legal matters

[0001047469-15-004931:notes:139]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431). The complaint asserts various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products. The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys' fees and costs. The plaintiff also seeks a jury trial. On June 25, 2014, the Company filed motions for demurrer and to strike asking the court to dismiss the claims against itself. The court held a hearing on March 18, 2015 on the Company's motion for demurrer and to strike Xilinx's complaint. On March 26, 2015, the court granted the Company's motion, rejecting most of Xilinx's complaint, but allowing Xilinx the opportunity to file an amended complaint by April 25, 2015. Xilinx filed its amended complaint on April 27, 2015, and the Company's response is due May 29, 2015. Discovery is ongoing. Although the outcome of this matter is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of this matter, which are in excess of amounts already accrued in the Company's consolidated balance sheets, would not be material to the financial statements.

[0001047469-15-004931:notes:140]
During the fourth quarter of fiscal 2014, one of our Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010. This assessment is in the second stage of the review process at the administrative level, and we plan to continue to vigorously oppose it as well as any future assessments. We are, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While we believe there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, we are unable to reasonably estimate a range of loss, if any. We do not expect final judicial determination on these claims for several years.

[0001047469-15-004931:notes:141]
During fiscal year 2015, one of our non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties. The Company believes there is no legal basis for the assessment and expects that any losses are remote. The Company plans to vigorously defend itself through the administrative and judicial processes.

[0001047469-15-004931:notes:142]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company's consolidated balance sheet, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001047469-15-004931:notes:143]
9. ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001047469-15-004931:notes:144]
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2015 and 2014 are as follows:

[0001047469-15-004931:notes:145]
|  |  | Fiscal Year Ended March 31, 2015 |  |
|  |  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | (32,849 | ) | $ | (93,307 | ) | $ | (126,156 | ) |
| Other comprehensive loss before reclassifications |  |  | (76,470 | ) |  | (9,318 | ) |  | (85,788 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss |  |  | 41,053 |  |  | (9,614 | ) |  | 31,439 |  |
| Net current-period other comprehensive loss |  |  | (35,417 | ) |  | (18,932 | ) |  | (54,349 | ) |
| Ending balance |  | $ | (68,266 | ) | $ | (112,239 | ) | $ | (180,505 | ) |

[0001047469-15-004931:notes:146]
|  |  | Fiscal Year Ended March 31, 2014 |  |
|  |  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | (18,857 | ) | $ | (58,624 | ) | $ | (77,481 | ) |
| Other comprehensive loss before reclassifications |  |  | (15,851 | ) |  | (34,683 | ) |  | (50,534 | ) |
| Net losses reclassified from accumulated other comprehensive loss |  |  | 1,859 |  |  | — |  |  | 1,859 |  |
| Net current-period other comprehensive loss |  |  | (13,992 | ) |  | (34,683 | ) |  | (48,675 | ) |
| Ending balance |  | $ | (32,849 | ) | $ | (93,307 | ) | $ | (126,156 | ) |

[0001047469-15-004931:notes:147]
Net losses reclassified from accumulated other comprehensive loss during the fiscal year 2015 relating to derivative instruments and other includes $36.2 million attributable to the Company's cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations.

[0001047469-15-004931:notes:148]
During fiscal year 2015, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. This loss includes the settlement of unrealized losses of $4.2 million on an insignificant defined benefit plan associated with the disposed facility offset by the release of cumulative foreign currency translation gains of $9.3 million, both of which have been reclassified from accumulated other comprehensive loss during the period. The loss on sale is included in other charges (income), net in the condensed consolidated statement of operations.


## us-gaap:DebtDisclosureTextBlock

[0001047469-15-004931:notes:149]
7. BANK BORROWINGS AND LONG-TERM DEBT

[0001047469-15-004931:notes:150]
Bank borrowings and long-term debt are as follows:

[0001047469-15-004931:notes:151]
|  |  | As of March 31, |  |
|  |  | 2015 |  | 2014 |  |
|  |  | (In thousands) |  |
| Term Loan, including current portion, due in installments through August 2018 |  | $ | 592,500 |  | $ | 600,000 |  |
| Term Loan, including current portion, due in installments through March 2019 |  |  | 475,000 |  |  | 500,000 |  |
| 4.625% Notes due February 2020 |  |  | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 |  |  | 500,000 |  |  | 500,000 |  |
| Other |  |  | 16,233 |  |  | 2,595 |  |
|  |  |  | 2,083,733 |  |  | 2,102,595 |  |
| Current portion |  |  | (46,162 | ) |  | (32,575 | ) |
| Non-current portion |  | $ | 2,037,571 |  | $ | 2,070,020 |  |

[0001047469-15-004931:notes:152]
The weighted average interest rates for the Company's long-term debt was 3.2% as of both March 31, 2015 and 2014.

[0001047469-15-004931:notes:153]
Repayments of the Company's long-term debt are as follows:

[0001047469-15-004931:notes:154]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2016 |  | $ | 46,162 |  |
| 2017 |  |  | 52,500 |  |
| 2018 |  |  | 52,500 |  |
| 2019 |  |  | 922,500 |  |
| 2020 |  |  | 500,000 |  |
| Thereafter |  |  | 510,071 |  |
| Total |  | $ | 2,083,733 |  |

[0001047469-15-004931:notes:155]
Capital lease obligations of $5.3 million and $8.9 million, consisting of short-term obligations of $2.8 million and $4.2 million and long term obligations of $2.5 million and $4.7 million are included in current and non-current liabilities on the Company's balance sheets as of March 31, 2015 and 2014, respectively.

[0001047469-15-004931:notes:156]
Term Loan due August 2018

[0001047469-15-004931:notes:157]
On August 30, 2013, the Company entered into a $600 million term loan agreement due August 30, 2018 and used these proceeds to repay certain term loans in full that were outstanding at that time in the amount of $544.8 million. The remaining $55.2 million was used to repay part of the term loan due March 2019 and upfront bank fees. This loan is repayable in quarterly installments of $3.75 million, which commenced in December 2014 and continue through August 2018, with the remaining amount due at maturity.

[0001047469-15-004931:notes:158]
Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.00% and 2.00%, based on the Company's credit ratings or (ii) the base rate (the greatest of the U.S. prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.00% and 1.00%, based on the Company's credit rating.

[0001047469-15-004931:notes:159]
This term loan is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2015, the Company was in compliance with the covenants under this term loan agreement.

[0001047469-15-004931:notes:160]
Term Loan Agreement due March 2019 and Revolving Line of Credit

[0001047469-15-004931:notes:161]
The Company's $2.0 billion credit facility ("Credit Facility") consists of a $1.5 billion revolving credit facility and a $500.0 million term loan, which is due to expire in March 2019.

[0001047469-15-004931:notes:162]
On March 31, 2014, the Company borrowed an incremental amount of $63.4 million under the term loan thereby increasing the total amount outstanding under the term loan to $500 million in conjunction with the extension of the maturity date to March 2019. Quarterly repayments of principal under this term loan commenced on June 30, 2014 in the amount of $6.3 million up to March 31, 2016 and will increase to $9.4 million thereafter with the remainder due upon maturity. Borrowings under this facility bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the agent's prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating. The Company is required to pay a quarterly commitment fee ranging between 0.15% and 0.40% per annum on the daily unused amount of the $1.5 billion Revolving Credit Facility based on the Company's credit rating.

[0001047469-15-004931:notes:163]
This Credit Facility is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2015, the Company was in compliance with the covenants under this loan agreement.

[0001047469-15-004931:notes:164]
Notes due February 2020 and February 2023

[0001047469-15-004931:notes:165]
On February 20, 2013, the Company issued $500.0 million of 4.625% Notes due February 15, 2020 and $500.0 million of 5.000% Notes due February 15, 2023 (collectively the "Notes") in a private offering pursuant to Rule 144A and Regulation S under the Securities Act. In July 2013, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission. The Company received net proceeds of approximately $990.6 million from the issuance and used those proceeds, together with $9.4 million of cash on hand, to repay $1.0 billion of outstanding borrowings under its previous term loan that was due October 2014.

[0001047469-15-004931:notes:166]
Interest on the Notes is payable semi-annually, which commenced on August 15, 2013. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Credit Facility or the Company’s Term Loan due 2018.

[0001047469-15-004931:notes:167]
At any time prior to maturity, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0001047469-15-004931:notes:168]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately. As of March 31, 2015, the Company was in compliance with the covenants in the indenture governing the Notes.

[0001047469-15-004931:notes:169]
Other Credit Lines

[0001047469-15-004931:notes:170]
As of March 31, 2015, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other loans in the amount of $184.6 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2015 and 2014. These unsecured credit facilities, and lines of credit and other loans bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin, and generally have maturities that expire on various dates in future fiscal years.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001047469-15-004931:notes:171]
8. FINANCIAL INSTRUMENTS

[0001047469-15-004931:notes:172]
Foreign Currency Contracts

[0001047469-15-004931:notes:173]
The Company transacts business in various foreign countries and is therefore, exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency unit of the operating entity. The Company enters into short-term foreign currency forward and swap contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains and losses on the Company's forward and swap contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these forward and swap contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0001047469-15-004931:notes:174]
As of March 31, 2015, the aggregate notional amount of the Company's outstanding foreign currency forward and swap contracts was $3.6 billion as summarized below:

[0001047469-15-004931:notes:175]
|  |  | Foreign CurrencyAmount |  | Notional ContractValue in USD |  |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |  |
|  |  | (In thousands) |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CNY |  |  | 2,038,000 |  |  | — |  | $ | 327,916 |  | $ | — |  |
| HUF |  |  | 16,064,000 |  |  | — |  |  | 58,340 |  |  | — |  |
| ILS |  |  | 110,200 |  |  | — |  |  | 27,786 |  |  | — |  |
| MXN |  |  | 1,706,500 |  |  | 275,000 |  |  | 112,366 |  |  | 18,108 |  |
| MYR |  |  | 285,000 |  |  | 33,000 |  |  | 77,341 |  |  | 8,955 |  |
| SGD |  |  | 27,700 |  |  | — |  |  | 20,234 |  |  | — |  |
| RON |  |  | 88,300 |  |  | — |  |  | 21,768 |  |  | — |  |
| Other |  |  | N/A |  |  | N/A |  |  | 47,774 |  |  | 7,837 |  |
|  |  |  |  |  |  |  |  |  | 693,525 |  |  | 34,900 |  |
| Other Forward/Swap Contracts |  |  |  |  |  |  |  |  |  |  |  |  |  |
| BRL |  |  | — |  |  | 534,000 |  |  | — |  |  | 165,330 |  |
| CAD |  |  | 168,467 |  |  | 165,795 |  |  | 134,286 |  |  | 131,992 |  |
| CNY |  |  | 760,113 |  |  | — |  |  | 120,710 |  |  | — |  |
| EUR |  |  | 553,629 |  |  | 758,846 |  |  | 606,019 |  |  | 831,531 |  |
| GBP |  |  | 32,794 |  |  | 61,161 |  |  | 48,840 |  |  | 91,283 |  |
| MXN |  |  | 1,306,400 |  |  | 793,212 |  |  | 86,021 |  |  | 52,228 |  |
| MYR |  |  | 237,837 |  |  | 39,200 |  |  | 64,542 |  |  | 10,638 |  |
| SEK |  |  | 411,292 |  |  | 707,248 |  |  | 48,065 |  |  | 83,294 |  |
| Other |  |  | N/A |  |  | N/A |  |  | 219,114 |  |  | 178,321 |  |
|  |  |  |  |  |  |  |  |  | 1,327,597 |  |  | 1,544,617 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  |  | $ | 2,021,122 |  | $ | 1,579,517 |  |

[0001047469-15-004931:notes:176]
As of March 31, 2015 and 2014, the fair value of the Company's short-term foreign currency contracts was not material and included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in non-functional currencies and are not accounted for as hedges under the accounting standards. Accordingly, changes in fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the consolidated statements of operations. As of March 31, 2015 and 2014, the Company also has included net deferred losses, in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses totaled $17.3 million as of March 31, 2015, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations over the next twelve month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal years presented and are included as a component of interest and other, net in the consolidated statements of operations.

[0001047469-15-004931:notes:177]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2015 and 2014:

[0001047469-15-004931:notes:178]
|  |  | Fair Values of Derivative Instruments |  |
|  |  | Asset Derivatives |  | Liability Derivatives |  |
|  |  |  |  | Fair Value |  |  |  | Fair Value |  |
|  |  | Balance SheetLocation |  | March 31,2015 |  | March 31,2014 |  | Balance SheetLocation |  | March 31,2015 |  | March 31,2014 |  |
|  |  | (In thousands) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 2,896 |  | $ | 3,464 |  | Other current liabilities |  | $ | 19,729 |  | $ | 10,457 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 22,933 |  | $ | 4,722 |  | Other current liabilities |  | $ | 11,328 |  | $ | 6,949 |  |

[0001047469-15-004931:notes:179]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001047469-15-004931:notes:180]
3. SHARE-BASED COMPENSATION

[0001047469-15-004931:notes:181]
Equity Compensation Plans

[0001047469-15-004931:notes:182]
During fiscal year 2015, the Company granted equity compensation awards under the 2010 Equity Incentive Plan (the "2010 Plan") and the 2013 Elementum Plan (the "Elementum Plan"). The 2010 Plan is administered by Flextronics International Ltd., while the Elementum Plan is administered by Elementum SCM (Cayman) Limited ("Elementum"), a majority owned subsidiary of the Company.

[0001047469-15-004931:notes:183]
The 2010 Equity Incentive Plan of Flextronics International Ltd.

[0001047469-15-004931:notes:184]
As of March 31, 2015, the Company had approximately 34.6 million shares available for grant under the 2010 Plan. Options issued to employees under the 2010 Plan generally vest over four years and expire seven years from the date of grant. Options granted to non-employee directors expire five years from the date of grant.

[0001047469-15-004931:notes:185]
The exercise price of options granted to employees is determined by the Company's Board of Directors or the Compensation Committee and may not be less than the closing price of the Company's ordinary shares on the date of grant.

[0001047469-15-004931:notes:186]
The Company also grants share bonus awards under its equity compensation plan. Share bonus awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. Share bonus awards generally vest in installments over a three to five year period and unvested share bonus awards are forfeited upon termination of employment. Vesting for certain share bonus awards is contingent upon both service and market conditions.

[0001047469-15-004931:notes:187]
Share-Based Compensation Expense

[0001047469-15-004931:notes:188]
The following table summarizes the Company's share-based compensation expense:

[0001047469-15-004931:notes:189]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Cost of sales |  | $ | 7,503 |  | $ | 6,540 |  | $ | 5,163 |  |
| Selling, general and administrative expenses |  |  | 42,767 |  |  | 33,899 |  |  | 29,366 |  |
| Total share-based compensation expense |  | $ | 50,270 |  | $ | 40,439 |  | $ | 34,529 |  |

[0001047469-15-004931:notes:190]
As required by the authoritative guidance for stock-based compensation, management made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as an analysis of actual forfeitures.

[0001047469-15-004931:notes:191]
As of March 31, 2015, the total unrecognized compensation cost related to unvested share options granted to employees under the Company's 2010 Plan was approximately $0.1 million, net of estimated forfeitures. This cost will be amortized on a straight-line basis over a weighted-average period of approximately 2.0 years and will be adjusted for estimated forfeitures. As of March 31, 2015, the total unrecognized compensation cost related to unvested share bonus awards granted to employees was approximately $90.2 million, net of estimated forfeitures. This cost will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.5 years and will be adjusted for estimated forfeitures. Approximately $15.4 million of the unrecognized compensation cost, net of forfeitures, is related to share bonus awards granted to certain key employees whereby vesting is contingent on meeting a certain market condition.

[0001047469-15-004931:notes:192]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as financing cash flows. During fiscal years 2015, 2014 and 2013, the Company did not recognize any excess tax benefits as a financing cash inflow.

[0001047469-15-004931:notes:193]
Determining Fair Value

[0001047469-15-004931:notes:194]
Options

[0001047469-15-004931:notes:195]
Valuation and Amortization Method—The Company estimates the fair value of share options granted under the 2010 Plan using the Black-Scholes valuation method and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period. The fair market value of share bonus awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0001047469-15-004931:notes:196]
Expected Term—The Company's expected term used in the Black-Scholes valuation method represents the period that the Company's share options are expected to be outstanding and is determined based on historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share options.

[0001047469-15-004931:notes:197]
Expected Volatility—The Company's expected volatility used in the Black-Scholes valuation method is derived from a combination of implied volatility related to publicly traded options to purchase Flextronics ordinary shares and historical variability in the Company's periodic share price.

[0001047469-15-004931:notes:198]
Expected Dividend—The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0001047469-15-004931:notes:199]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0001047469-15-004931:notes:200]
There were no options granted under the 2010 Plan during fiscal year 2014. The fair value of the Company's share options granted to employees for fiscal years 2015 and 2013 was estimated using the following weighted-average assumptions:

[0001047469-15-004931:notes:201]
|  |  | Fiscal Year EndedMarch 31, |
|  |  | 2015 |  | 2013 |
| Expected term |  | 6.3 years |  | 4.1 years |
| Expected volatility |  | 46.9% |  | 46.9% |
| Expected dividends |  | 0.0% |  | 0.0% |
| Risk-free interest rate |  | 2.3% |  | 0.9% |
| Weighted-average fair value |  | $4.85 |  | $2.48 |

[0001047469-15-004931:notes:202]
Options granted during the 2015 and 2013 fiscal years had contractual lives of seven years.

[0001047469-15-004931:notes:203]
Share bonus awards with service and market conditions

[0001047469-15-004931:notes:204]
Valuation and Amortization Method—The Company estimates the fair value of share bonus awards granted under the 2010 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0001047469-15-004931:notes:205]
Expected volatility of Flextronics—Volatility used in Monte Carlo simulation is derived from the historical volatility of Flextronics' stock price over a period equal to the service period of the share bonus awards granted. The service period is three years for those share bonus awards granted in fiscal years 2015, 2014 and 2013.

[0001047469-15-004931:notes:206]
Average peer volatility—Volatility used in Monte Carlo simulation is derived from the historical volatilities of both the S&P 500 index and components of an extended Electronics Manufacturing Services ("EMS") group, comprised of global competitors of the Company within the same industry, for the share bonus awards granted in fiscal years 2015 and 2014, and historical volatilities of the S&P 500 index for the share bonus awards granted in fiscal year 2013 based on the various service periods.

[0001047469-15-004931:notes:207]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flextronics' stock price relative to both the S&P 500 index and peers in the extended EMS group for the share bonus awards granted in fiscal years 2015 and 2014, and relative to the S&P 500 index for the share bonus awards granted in fiscal year 2013.

[0001047469-15-004931:notes:208]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Monte Carlo simulation on the yield of zero-coupon U.S. Treasury bills, as of the measurement date.

[0001047469-15-004931:notes:209]
The fair value of the Company's share-bonus awards, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2015, 2014 and 2013 was estimated using the following weighted-average assumptions:

[0001047469-15-004931:notes:210]
|  |  | Fiscal Year EndedMarch 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
| Expected volatility |  |  | 29.4 | % |  | 35.9 | % |  | 41.7 | % |
| Average peer volatility |  |  | 25.9 | % |  | 35.7 | % |  | 19.2 | % |
| Average peer correlation |  |  | 0.6 |  |  | 0.4 |  |  | 0.7 |  |
| Expected dividends |  |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate |  |  | 0.9 | % |  | 0.4 | % |  | 0.4 | % |

[0001047469-15-004931:notes:211]
Share-Based Awards Activity

[0001047469-15-004931:notes:212]
The following is a summary of option activity for the Company's 2010 Plan ("Price" reflects the weighted-average exercise price):

[0001047469-15-004931:notes:213]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | Options |  | Price |  | Options |  | Price |  | Options |  | Price |  |
| Outstanding, beginning of fiscal year |  |  | 23,612,872 |  | $ | 8.57 |  |  | 34,405,564 |  | $ | 8.29 |  |  | 43,933,660 |  | $ | 7.78 |  |
| Granted |  |  | 15,000 |  |  | 11.11 |  |  | — |  |  | — |  |  | 19,000 |  |  | 6.57 |  |
| Exercised |  |  | (3,600,900 | ) |  | 6.53 |  |  | (6,572,383 | ) |  | 4.28 |  |  | (5,398,331 | ) |  | 4.12 |  |
| Forfeited |  |  | (4,034,078 | ) |  | 13.17 |  |  | (4,220,309 | ) |  | 12.93 |  |  | (4,148,765 | ) |  | 8.32 |  |
| Outstanding, end of fiscal year |  |  | 15,992,894 |  | $ | 7.81 |  |  | 23,612,872 |  | $ | 8.57 |  |  | 34,405,564 |  | $ | 8.29 |  |
| Options exercisable, end of fiscal year |  |  | 15,959,173 |  | $ | 7.81 |  |  | 23,373,101 |  | $ | 8.58 |  |  | 33,662,480 |  | $ | 8.31 |  |

[0001047469-15-004931:notes:214]
The aggregate intrinsic value of options exercised (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise for options exercised in-the-money) under the Company's 2010 Plan was $16.3 million, $24.7 million and $13.0 million during fiscal years 2015, 2014 and 2013 respectively.

[0001047469-15-004931:notes:215]
Cash received from option exercises was $23.5 million, $28.1 million and $22.3 million for fiscal years 2015, 2014 and 2013, respectively.

[0001047469-15-004931:notes:216]
The following table presents the composition of options outstanding and exercisable as of March 31, 2015:

[0001047469-15-004931:notes:217]
|  |  | Options Outstanding |  | Options Exercisable |  |
| Range of Exercise Prices |  | Number ofSharesOutstanding |  | WeightedAverageRemainingContractualLife(In Years) |  | WeightedAverageExercisePrice |  | Number ofSharesExercisable |  | WeightedAverageExercisePrice |  |
| $1.94 - $2.26 |  |  | 4,665,815 |  |  | 0.79 |  | $ | 2.12 |  |  | 4,665,815 |  | $ | 2.12 |  |
| $3.39 - $5.75 |  |  | 2,236,960 |  |  | 1.36 |  |  | 5.56 |  |  | 2,233,938 |  |  | 5.56 |  |
| $5.87 - $7.07 |  |  | 79,118 |  |  | 2.03 |  |  | 6.42 |  |  | 68,217 |  |  | 6.43 |  |
| $7.08 - $10.59 |  |  | 4,357,646 |  |  | 0.42 |  |  | 10.34 |  |  | 4,349,848 |  |  | 10.35 |  |
| $10.67 - $11.41 |  |  | 831,555 |  |  | 1.19 |  |  | 11.22 |  |  | 819,555 |  |  | 11.22 |  |
| $11.53 - $13.98 |  |  | 3,786,800 |  |  | 0.22 |  |  | 12.45 |  |  | 3,786,800 |  |  | 12.45 |  |
| $14.34 - $23.02 |  |  | 35,000 |  |  | 1.42 |  |  | 15.95 |  |  | 35,000 |  |  | 15.95 |  |
| $1.94 - $23.02 |  |  | 15,992,894 |  |  | 0.66 |  | $ | 7.81 |  |  | 15,959,173 |  | $ | 7.81 |  |
| Options vested and expected to vest |  |  | 15,989,753 |  |  | 0.66 |  | $ | 7.81 |  |  |  |  |  |  |  |

[0001047469-15-004931:notes:218]
As of March 31, 2015, the aggregate intrinsic value for options outstanding, options vested and expected to vest (which includes adjustments for expected forfeitures), and options exercisable were $78.1 million, $78.1 million and $77.9 million, respectively. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2015 for the approximately 15.7 million options that were in-the-money at March 31, 2015. As of March 31, 2015, the weighted average remaining contractual life for options exercisable was 0.65 years.

[0001047469-15-004931:notes:219]
The following table summarizes the Company's share bonus award activity ("Price" reflects the weighted-average grant-date fair value):

[0001047469-15-004931:notes:220]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |  |
| Unvested share bonus awards outstanding, beginning of fiscal year |  |  | 21,848,120 |  | $ | 7.32 |  |  | 21,807,069 |  | $ | 6.80 |  |  | 15,965,268 |  | $ | 6.91 |  |
| Granted |  |  | 6,963,125 |  |  | 11.75 |  |  | 8,978,941 |  |  | 8.07 |  |  | 9,582,867 |  |  | 6.74 |  |
| Vested |  |  | (7,246,056 | ) |  | 6.97 |  |  | (5,481,153 | ) |  | 6.66 |  |  | (1,506,234 | ) |  | 7.51 |  |
| Forfeited |  |  | (2,571,937 | ) |  | 7.70 |  |  | (3,456,737 | ) |  | 7.07 |  |  | (2,234,832 | ) |  | 6.86 |  |
| Unvested share bonus awards outstanding, end of fiscal year |  |  | 18,993,252 |  | $ | 9.01 |  |  | 21,848,120 |  | $ | 7.32 |  |  | 21,807,069 |  | $ | 6.80 |  |

[0001047469-15-004931:notes:221]
Of the 19.0 million unvested share bonus awards outstanding as of the fiscal year ended 2015, approximately 4.9 million represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0001047469-15-004931:notes:222]
In accordance with the accounting guidance, the Company will continue to recognize share-based compensation expense for these awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2015, 0.3 million shares vested in connection with the remaining number of share bonus awards with market conditions granted in fiscal year 2011, and 0.4 million shares vested in connection with half of the share bonus awards with market conditions granted in fiscal year 2012.

[0001047469-15-004931:notes:223]
The total intrinsic value of share bonus awards vested under the Company's 2010 Plan was $79.0 million, $42.4 million and $9.7 million during fiscal years 2015, 2014 and 2013, respectively, based on the closing price of the Company's ordinary shares on the date vested.

[0001047469-15-004931:notes:224]
The 2013 Equity Incentive Plan of Elementum SCM (Cayman) Ltd.

[0001047469-15-004931:notes:225]
As of March 31, 2015 Elementum had approximately 5.0 million shares available for future grants under the 2013 Elementum Plan. Options issued to employees under this Plan vest over a period of four years and expire ten years from the grant date. As of March 31, 2015 there were 16.0 million of options outstanding at a weighted average exercise price of $0.27 per option. Total unrecognized compensation expenses relating to stock options granted to certain employees under the Elementum Plan as of March 31, 2015 is $2.1 million, and will be recognized over a weighted average period of 3.29 years.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001047469-15-004931:notes:226]
20. DISCONTINUED OPERATIONS

[0001047469-15-004931:notes:227]
During fiscal year 2013, the Company finalized the sale of two of its non-core businesses. Total proceeds received from these sales amounted to $27.2 million, net of $1.0 million of cash sold. The Company recognized an aggregate loss of $12.1 million on these sales, which is included in interest and other, net within the results from discontinued operations in fiscal year 2013.

[0001047469-15-004931:notes:228]
In accordance with the accounting guidance applicable at the time, these non-core businesses qualify as discontinued operations, and accordingly, the Company has reported the results of operations and financial position of these businesses in discontinued operations within the consolidated statements of operations and the consolidated balance sheets for all periods presented as applicable.

[0001047469-15-004931:notes:229]
The results from discontinued operations were as follows:

[0001047469-15-004931:notes:230]
|  |  | Fiscal Year Ended2013 |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 40,593 |  |
| Cost of sales |  |  | 42,793 |  |
| Gross loss |  |  | (2,200 | ) |
| Selling, general and administrative expenses |  |  | 1,930 |  |
| Intangibles amortization and impairment |  |  | 11,000 |  |
| Interest and other, net |  |  | 11,280 |  |
| Loss before income taxes |  |  | (26,410 | ) |
| Benefit from income taxes |  |  | (959 | ) |
| Net loss of discontinued operations |  | $ | (25,451 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001047469-15-004931:notes:231]
4. EARNINGS PER SHARE

[0001047469-15-004931:notes:232]
Basic earnings per share for both continuing and discontinued operations exclude dilution and are computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0001047469-15-004931:notes:233]
Diluted earnings per share for both continuing and discontinued operations reflect the potential dilution from stock options and share bonus awards. The potential dilution from stock options exercisable into ordinary share equivalents and share bonus awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0001047469-15-004931:notes:234]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income from continuing and discontinued operations per share:

[0001047469-15-004931:notes:235]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | (In thousands, exceptper share amounts) |  |
| Basic earnings from continuing and discontinued operations per share: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 600,801 |  | $ | 365,594 |  | $ | 302,502 |  |
| Loss from discontinued operations |  | $ | — |  | $ | — |  | $ | (25,451 | ) |
| Net income |  | $ | 600,801 |  | $ | 365,594 |  | $ | 277,051 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  |  | 579,981 |  |  | 610,497 |  |  | 662,874 |  |
| Basic earnings from continuing operations per share |  | $ | 1.04 |  | $ | 0.60 |  | $ | 0.46 |  |
| Basic loss from discontinued operations per share |  | $ | — |  | $ | — |  | $ | (0.04 | ) |
| Basic earnings per share |  | $ | 1.04 |  | $ | 0.60 |  | $ | 0.42 |  |
| Diluted earnings from continuing and discontinued operations per share: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 600,801 |  | $ | 365,594 |  | $ | 302,502 |  |
| Loss from discontinued operations |  | $ | — |  | $ | — |  | $ | (25,451 | ) |
| Net income |  | $ | 600,801 |  | $ | 365,594 |  | $ | 277,051 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  |  | 579,981 |  |  | 610,497 |  |  | 662,874 |  |
| Weighted-average ordinary share equivalents from stock options and awards(1) |  |  | 11,575 |  |  | 12,982 |  |  | 12,159 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding |  |  | 591,556 |  |  | 623,479 |  |  | 675,033 |  |
| Diluted earnings from continuing operations per share |  | $ | 1.02 |  | $ | 0.59 |  | $ | 0.45 |  |
| Diluted loss from discontinued operations per share |  | $ | — |  | $ | — |  | $ | (0.04 | ) |
| Diluted earnings per share |  | $ | 1.02 |  | $ | 0.59 |  | $ | 0.41 |  |

[0001047469-15-004931:notes:236]
| (1) | Options to purchase ordinary shares of 6.2 million, 17.1 million and 20.6 million during fiscal years 2015, 2014 and 2013, respectively, and share bonus awards of less than 0.1 million and 0.3 million during fiscal years 2015 and 2013, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. There were no anti-dilutive share bonus awards in fiscal year 2014. |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0001047469-15-004931:notes:237]
|  |  | Fair Value Measurements as of March 31,2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets held for sale |  | $ | — |  | $ | 43,504 |  | $ | — |  | $ | 43,504 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001047469-15-004931:notes:238]
11. FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES

[0001047469-15-004931:notes:239]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0001047469-15-004931:notes:240]
Level 1—Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0001047469-15-004931:notes:241]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other noncurrent assets on the consolidated balance sheets and include investments in equity securities that are valued using active market prices.

[0001047469-15-004931:notes:242]
Level 2—Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model- derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0001047469-15-004931:notes:243]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0001047469-15-004931:notes:244]
The Company's cash equivalents are comprised of bank deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0001047469-15-004931:notes:245]
The Company's deferred compensation plan assets also include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0001047469-15-004931:notes:246]
Level 3—Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0001047469-15-004931:notes:247]
The Company accrues for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and inputs. During fiscal year 2015, the Company paid $11.3 million of contingent consideration related to the acquisition of Saturn Electronics and Engineering Inc. The following table summarizes the activities related to contingent consideration:

[0001047469-15-004931:notes:248]
|  |  | As of March 31, |  |
|  |  | 2015 |  | 2014 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 11,300 |  | $ | 25,000 |  |
| Additions to accrual |  |  | 4,500 |  |  | — |  |
| Payments |  |  | (11,300 | ) |  | — |  |
| Fair value adjustments |  |  | — |  |  | (13,700 | ) |
| Ending balance |  | $ | 4,500 |  | $ | 11,300 |  |

[0001047469-15-004931:notes:249]
The Company values deferred purchase price receivables relating to its Asset-Backed Securitization Program based on a discounted cash flow analysis using unobservable inputs (i.e. level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, their fair value approximates carrying value. Significant increases in either of the significant unobservable inputs (credit spread or risk free interest rate) in isolation would result in lower fair value estimates, however the impact is insignificant. The interrelationship between these inputs is also insignificant. Refer to note 10 for a reconciliation of the change in the deferred purchase price receivable.

[0001047469-15-004931:notes:250]
There were no transfers between levels in the fair value hierarchy during fiscal years 2015 and 2014.

[0001047469-15-004931:notes:251]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0001047469-15-004931:notes:252]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2015 and 2014:

[0001047469-15-004931:notes:253]
|  |  | Fair Value Measurements as of March 31, 2015 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) |  | $ | — |  | $ | 674,859 |  | $ | — |  | $ | 674,859 |  |
| Deferred purchase price receivable (Note 10) |  |  | — |  |  | — |  |  | 600,672 |  |  | 600,672 |  |
| Foreign exchange forward contracts (Note 8) |  |  | — |  |  | 25,829 |  |  | — |  |  | 25,829 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities |  |  | 9,068 |  |  | 37,041 |  |  | — |  |  | 46,109 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) |  | $ | — |  | $ | (31,057 | ) | $ | — |  | $ | (31,057 | ) |
| Contingent consideration in connection with acquistions |  |  | — |  |  | — |  |  | (4,500 | ) |  | (4,500 | ) |

[0001047469-15-004931:notes:254]
|  |  | Fair Value Measurements as of March 31, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) |  | $ | — |  | $ | 552,928 |  | $ | — |  | $ | 552,928 |  |
| Deferred purchase price receivable (Note 10) |  |  | — |  |  | — |  |  | 470,908 |  |  | 470,908 |  |
| Foreign exchange forward contracts (Note 8) |  |  | — |  |  | 8,186 |  |  | — |  |  | 8,186 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities |  |  | 9,456 |  |  | 36,751 |  |  | — |  |  | 46,207 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) |  | $ | — |  | $ | (17,406 | ) | $ | — |  | $ | (17,406 | ) |
| Contingent consideration in connection with acquistions |  |  | — |  |  | — |  |  | (11,300 | ) |  | (11,300 | ) |

[0001047469-15-004931:notes:255]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001047469-15-004931:notes:256]
The Company has certain long-lived assets that are measured at fair value on a nonrecurring basis, and are as follows:

[0001047469-15-004931:notes:257]
Assets held for sale

[0001047469-15-004931:notes:258]
Assets held for sale are recorded at the lesser of the carrying value or fair value, which is based on comparable sales from prevailing market data (level 2 inputs). These assets primarily represent manufacturing facilities that have been closed as part of the Company's historical facility consolidations and that met the criteria to be classified as held for sale. During fiscal year 2014, the Company transferred $59.4 million assets to assets held for sale, and expected to sell these within a period of twelve months. Disposals of assets held for sale totaled $41.5 million and $24.5 million during fiscal year 2015 and 2014, respectively, which resulted in a gain of $12.1 million and $9.2 million, respectively, and was included as a component of cost of sales in the consolidated statement of operations. No impairment charges were recorded for assets held for sale during fiscal year 2015. Impairment charges during fiscal year 2014 were not significant for assets that were no longer in use and held for sale. Assets held for sale as of the 2015 fiscal year end were not significant.

[0001047469-15-004931:notes:259]
There were no material fair value adjustments or other transfers between levels in the fair value hierarchy for these long-lived assets during the fiscal years 2015 and 2014.

[0001047469-15-004931:notes:260]
Other financial instruments

[0001047469-15-004931:notes:261]
The following table presents the Company's liabilities not carried at fair value as at March 31, 2015 and 2014:

[0001047469-15-004931:notes:262]
|  |  | As of March 31, 2015 |  | As of March 31, 2014 |  |  |
|  |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  |  | (In thousands) |  | (In thousands) |  |  |
| Term Loan, including current portion, due in installments through August 2018 |  | $ | 592,500 |  | $ | 582,131 |  | $ | 600,000 |  | $ | 591,750 |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 |  |  | 475,000 |  |  | 465,500 |  |  | 500,000 |  |  | 497,190 |  | Level 1 |
| 4.625% Notes due February 2020 |  |  | 500,000 |  |  | 523,750 |  |  | 500,000 |  |  | 504,688 |  | Level 1 |
| 5.000% Notes due February 2023 |  |  | 500,000 |  |  | 543,150 |  |  | 500,000 |  |  | 517,650 |  | Level 1 |
| Total |  | $ | 2,067,500 |  | $ | 2,114,531 |  | $ | 2,100,000 |  | $ | 2,111,278 |  |  |

[0001047469-15-004931:notes:263]
All of the above debts are valued based on broker trading prices in active markets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001047469-15-004931:notes:264]
13. INCOME TAXES

[0001047469-15-004931:notes:265]
The domestic (Singapore) and foreign components of income from continuing operations before income taxes were comprised of the following:

[0001047469-15-004931:notes:266]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Domestic |  | $ | 67,482 |  | $ | 314,639 |  | $ | 170,071 |  |
| Foreign |  |  | 603,173 |  |  | 85,815 |  |  | 158,744 |  |
| Total |  | $ | 670,655 |  | $ | 400,454 |  | $ | 328,815 |  |

[0001047469-15-004931:notes:267]
The provision for income taxes from continuing operations consisted of the following:

[0001047469-15-004931:notes:268]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Current: |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 87 |  | $ | (681 | ) | $ | 680 |  |
| Foreign |  |  | 129,863 |  |  | 73,992 |  |  | 60,466 |  |
|  |  |  | 129,950 |  |  | 73,311 |  |  | 61,146 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |
| Domestic |  |  | (4,734 | ) |  | 9 |  |  | (1,187 | ) |
| Foreign |  |  | (55,362 | ) |  | (38,460 | ) |  | (33,646 | ) |
|  |  |  | (60,096 | ) |  | (38,451 | ) |  | (34,833 | ) |
| Provision for income taxes |  | $ | 69,854 |  | $ | 34,860 |  | $ | 26,313 |  |

[0001047469-15-004931:notes:269]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2015, 2014 and 2013. The reconciliation of the income tax expense from continuing operations expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0001047469-15-004931:notes:270]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Income taxes based on domestic statutory rates |  | $ | 114,011 |  | $ | 68,077 |  | $ | 55,899 |  |
| Effect of tax rate differential |  |  | (80,842 | ) |  | (68,654 | ) |  | (120,785 | ) |
| Intangible amortization |  |  | 5,143 |  |  | 4,750 |  |  | 4,881 |  |
| Change in liability for uncertain tax positions |  |  | 29,729 |  |  | (2,178 | ) |  | 15,268 |  |
| Change in valuation allowance |  |  | 2,495 |  |  | 26,838 |  |  | 68,596 |  |
| Other |  |  | (682 | ) |  | 6,027 |  |  | 2,454 |  |
| Provision for income taxes |  | $ | 69,854 |  | $ | 34,860 |  | $ | 26,313 |  |

[0001047469-15-004931:notes:271]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company's operations. The aggregate dollar effect on the Company's income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2015, 2014 and 2013 was $9.8 million, $15.2 million and $22.6 million, respectively. The effect on basic earnings per share was $0.02 for both fiscal years ended March 31, 2015 and 2014, and $0.03 for the fiscal year ended March 31, 2013. The effect on diluted earnings per share was $0.02 for both fiscal years ended March 31, 2015 and 2014, and $0.03 for the fiscal year ended March 31, 2013. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in the fiscal years ending March 31, 2016 through fiscal year 2022.

[0001047469-15-004931:notes:272]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore. The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years 2014 and 2013 were $51.5 million and $26.7 million, respectively. Due to the lack of sufficient foreign source income, tax effect for the fiscal year 2015 was zero.

[0001047469-15-004931:notes:273]
The components of deferred income taxes are as follows:

[0001047469-15-004931:notes:274]
|  |  | As of March 31, |  |
|  |  | 2015 |  | 2014 |  |
|  |  | (In thousands) |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |
| Fixed assets |  | $ | (73,327 | ) | $ | (76,524 | ) |
| Others |  |  | (44,603 | ) |  | (54,900 | ) |
| Total deferred tax liabilities |  |  | (117,930 | ) |  | (131,424 | ) |
| Deferred tax assets: |  |  |  |  |  |  |  |
| Fixed assets |  |  | 80,370 |  |  | 80,801 |  |
| Intangible assets |  |  | 28,954 |  |  | 62,951 |  |
| Deferred compensation |  |  | 13,618 |  |  | 10,263 |  |
| Inventory valuation |  |  | 11,864 |  |  | 9,255 |  |
| Provision for doubtful accounts |  |  | 3,149 |  |  | 3,558 |  |
| Net operating loss and other carryforwards |  |  | 2,394,456 |  |  | 2,613,095 |  |
| Others |  |  | 264,781 |  |  | 201,906 |  |
|  |  |  | 2,797,192 |  |  | 2,981,829 |  |
| Valuation allowances |  |  | (2,521,763 | ) |  | (2,749,040 | ) |
| Net deferred tax assets, net of valuation allowance |  |  | 275,429 |  |  | 232,789 |  |
| Net deferred tax asset |  | $ | 157,499 |  | $ | 101,365 |  |
| The net deferred tax asset is classified as follows: |  |  |  |  |  |  |  |
| Current asset (classified as other current assets) |  | $ | 63,910 |  | $ | 13,522 |  |
| Long-term asset (classified as other assets) |  |  | 211,519 |  |  | 219,267 |  |
| Long-term liability (classified as other liabilities) |  |  | (117,930 | ) |  | (131,424 | ) |
| Total |  | $ | 157,499 |  | $ | 101,365 |  |

[0001047469-15-004931:notes:275]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision. Approximately $34.0 million of the valuation allowance relates to income tax benefits arising from the exercise of stock options, which if realized will be credited directly to shareholders' equity and will not be available to benefit the income tax provision in any future period.

[0001047469-15-004931:notes:276]
The Company has recorded deferred tax assets of approximately $2.4 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $45.4 million of the deferred tax assets. These tax losses and other carryforwards, on a tax return basis, will expire at various dates as follows:

[0001047469-15-004931:notes:277]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management's estimates.

[0001047469-15-004931:notes:278]
The Company does not provide for income taxes on approximately $800.0 million of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. Determination of the amount of the unrecognized deferred tax liability on these undistributed earnings is not practicable. During the fiscal year 2015, we changed our intent with regard to the indefinite reinvestment of foreign earnings from certain of our Chinese subsidiaries which are scheduled to be de-registered or liquidated in the near future. As a result, we provided for applicable foreign withholding taxes on $145.9 million of undistributed foreign earnings for 2015 and prior years, and recorded a deferred tax liability of approximately $12.6 million.

[0001047469-15-004931:notes:279]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0001047469-15-004931:notes:280]
|  |  | Fiscal Year EndedMarch 31, |  |
|  |  | 2015 |  | 2014 |  |
|  |  | (In thousands) |  |
| Balance, beginning of fiscal year |  | $ | 243,864 |  | $ | 230,018 |  |
| Additions based on tax position related to the current year |  |  | 27,048 |  |  | 16,823 |  |
| Additions for tax positions of prior years |  |  | 24,354 |  |  | 36,689 |  |
| Reductions for tax positions of prior years |  |  | (16,388 | ) |  | (19,755 | ) |
| Reductions related to lapse of applicable statute of limitations |  |  | (11,891 | ) |  | (10,261 | ) |
| Settlements |  |  | (24,049 | ) |  | (8,964 | ) |
| Impact from foreign exchange rates fluctuation |  |  | (20,565 | ) |  | (686 | ) |
| Balance, end of fiscal year |  | $ | 222,373 |  | $ | 243,864 |  |

[0001047469-15-004931:notes:281]
The Company's unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an estimated range of $25 million to $52 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0001047469-15-004931:notes:282]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2005.

[0001047469-15-004931:notes:283]
Of the $222.4 million of unrecognized tax benefits at March 31, 2015, $186.8 million will affect the annual effective tax rate if the benefits are eventually recognized. The amount that does not impact the effective tax rate relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0001047469-15-004931:notes:284]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company's tax expense. During the fiscal years ended March 31, 2015, 2014 and 2013, the Company recognized interest and penalties of approximately $2.5 million and $8.4 million and $5.1 million, respectively. The Company had approximately $17.0 million, $15.6 million and $11.9 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2015, 2014 and 2013, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001047469-15-004931:notes:285]
5. NON-CONTROLLING INTERESTS

[0001047469-15-004931:notes:286]
During fiscal year 2014, a previously wholly-owned subsidiary of the Company received $38.6 million in exchange for issuing a non-controlling equity interest to certain third party investors for an ownership interest of less than 20% of the outstanding shares in the subsidiary. The Company continues to own a majority of the subsidiary's outstanding equity and also controls the subsidiary's board of directors. Accordingly, the consolidated financial statements include the financial position and results of operations of this subsidiary as of March 31, 2015 and for the year then ended.

[0001047469-15-004931:notes:287]
The Company has recognized the carrying value of the non-controlling interest as a component of total shareholders' equity. The operating results of the subsidiary attributable to the non-controlling interests are immaterial for all of the periods presented and are included in interest and other, net.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001047469-15-004931:notes:288]
1. ORGANIZATION OF THE COMPANY

[0001047469-15-004931:notes:289]
Flextronics International Ltd. ("Flextronics" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following business groups: High Reliability Solutions ("HRS"), which is comprised of our medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and our defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group ("CTG"), which includes our mobile devices business, including smart phones; our consumer electronics business, including connected living, wearable electronics, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for notebook personal computing, tablets, and printers; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, test and measurement, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions ("INS"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables our OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001047469-15-004931:notes:290]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001047469-15-004931:notes:291]
15. OTHER CHARGES (INCOME), NET

[0001047469-15-004931:notes:292]
During fiscal year 2015, an amendment to a customer contract to reimburse a customer for certain performance provisions was executed which included the removal of a $55.0 million contractual obligation recognized during fiscal year 2014. Accordingly, the Company reversed this charge with a corresponding credit to other charges (income), net in the consolidated statement of operations. Additionally, during fiscal year 2015, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. The Company received $11.5 million in cash for the sale of $27.2 million in net assets of the facility. The loss also includes $4.6 million of estimated transaction costs, partially offset by a gain of $9.3 million for the release of cumulative foreign currency translation gains triggered by the disposition.

[0001047469-15-004931:notes:293]
During fiscal year 2014, the Company recognized $55.0 million of other charges for the contractual obligation to reimburse a customer for certain performance provisions as described above. Additionally, the Company exercised warrants to purchase common shares of a certain supplier and sold the underlying shares for total proceeds of $67.3 million resulting in a loss of $7.1 million. Further, the Company recognized a gain of $4.6 million on the sale of certain investments.

[0001047469-15-004931:notes:294]
During fiscal year 2013, the Company recognized a net gain of $74.4 million for the fair value adjustment of the warrants referred to above.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001047469-15-004931:notes:295]
22. QUARTERLY FINANCIAL DATA (UNAUDITED)

[0001047469-15-004931:notes:296]
The following table contains unaudited quarterly financial data for fiscal years 2015 and 2014.

[0001047469-15-004931:notes:297]
|  |  | Fiscal Year Ended March 31, 2015 |  | Fiscal Year Ended March 31, 2014 |  |
|  |  | First |  | Second |  | Third |  | Fourth |  | First |  | Second |  | Third |  | Fourth |  |
|  |  | (In thousands, except per share amounts) |  |
| Net sales |  | $ | 6,642,745 |  | $ | 6,528,517 |  | $ | 7,025,054 |  | $ | 5,951,600 |  | $ | 5,791,125 |  | $ | 6,410,106 |  | $ | 7,183,442 |  | $ | 6,723,934 |  |
| Gross profit |  |  | 380,785 |  |  | 377,081 |  |  | 408,657 |  |  | 378,817 |  |  | 311,035 |  |  | 368,423 |  |  | 398,619 |  |  | 362,144 |  |
| Net income |  |  | 173,887 |  |  | 138,903 |  |  | 152,899 |  |  | 135,112 |  |  | 59,257 |  |  | 118,205 |  |  | 145,157 |  |  | 42,975 |  |
| Earnings per share(1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.30 |  | $ | 0.24 |  | $ | 0.26 |  | $ | 0.24 |  | $ | 0.09 |  | $ | 0.19 |  | $ | 0.24 |  | $ | 0.07 |  |
| Diluted |  | $ | 0.29 |  | $ | 0.23 |  | $ | 0.26 |  | $ | 0.23 |  | $ | 0.09 |  | $ | 0.19 |  | $ | 0.23 |  | $ | 0.07 |  |

[0001047469-15-004931:notes:298]
| (1) | Earnings per share are computed independently for each quarter presented; therefore, the sum of the quarterly earnings per share may not equal the total earnings per share amounts for the fiscal year. |

[0001047469-15-004931:notes:299]
The Company recorded restructuring charges during fiscal year 2014. The Company classified approximately $35.1 million and $23.5 million of these charges as a component of cost of sales during the first and fourth quarters of fiscal year 2014, respectively, and approximately $5.6 million and $11.1 million of these charges as a component of selling, general and administrative expenses during the first and fourth quarters of fiscal year 2014, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001047469-15-004931:notes:300]
14. RESTRUCTURING CHARGES

[0001047469-15-004931:notes:301]
The Company initiated certain restructuring activities during fiscal years 2014 and 2013 intended to improve its operational efficiencies by reducing excess workforce and capacity and realign the corporate cost structure. There were no material restructuring activities during fiscal year 2015. Restructuring charges are recorded based upon employee termination dates, site closure and consolidation plans generally in conjunction with an overall corporate initiative to drive cost reduction and realign the Company's global footprint.

[0001047469-15-004931:notes:302]
Fiscal Year 2014

[0001047469-15-004931:notes:303]
During the fiscal year ended March 31, 2014, the Company recognized restructuring charges of approximately $75.3 million. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on equipment no longer in use and to be disposed of, and other exit related costs due to facility closures or rationalizations. Pre-tax restructuring charges comprised $73.4 million of cash charges predominantly related to employee severance and $1.9 million of non-cash charges related to impairment of long-lived assets. Employee severance costs were associated with the terminations of 6,758 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 5,073, 1,482 and 203 for Asia, the Americas and Europe, respectively.

[0001047469-15-004931:notes:304]
The components of the restructuring charges by geographic region incurred in fiscal year 2014 are as follows:

[0001047469-15-004931:notes:305]
|  |  | FirstQuarter |  | FourthQuarter |  | Total |  |
|  |  | (In thousands) |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |
| Severance |  | $ | 11,331 |  | $ | 11,290 |  | $ | 22,621 |  |
| Other exit costs |  |  | 2,248 |  |  | — |  |  | 2,248 |  |
| Total restructuring charges |  |  | 13,579 |  |  | 11,290 |  |  | 24,869 |  |
| Asia: |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 16,205 |  |  | 13,214 |  |  | 29,419 |  |
| Long-lived asset impairment |  |  | 1,900 |  |  | — |  |  | 1,900 |  |
| Other exit costs |  |  | 3,157 |  |  | — |  |  | 3,157 |  |
| Total restructuring charges |  |  | 21,262 |  |  | 13,214 |  |  | 34,476 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 4,631 |  |  | 10,047 |  |  | 14,678 |  |
| Other exit costs |  |  | 1,288 |  |  | — |  |  | 1,288 |  |
| Total restructuring charges |  |  | 5,919 |  |  | 10,047 |  |  | 15,966 |  |
| Total |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 32,167 |  |  | 34,551 |  |  | 66,718 |  |
| Long-lived asset impairment |  |  | 1,900 |  |  | — |  |  | 1,900 |  |
| Other exit costs |  |  | 6,693 |  |  | — |  |  | 6,693 |  |
| Total restructuring charges |  | $ | 40,760 |  | $ | 34,551 |  | $ | 75,311 |  |

[0001047469-15-004931:notes:306]
During the fiscal year ended March 31, 2014, the Company recognized approximately $66.7 million of severance costs related to employee terminations of which approximately $50.2 million was recognized in cost of sales.

[0001047469-15-004931:notes:307]
During the fiscal year ended March 31, 2014, the Company recognized approximately $1.9 million for the write-down of property and equipment, and was classified as a component of cost of sales. The property and equipment were sold as of March 31, 2014.

[0001047469-15-004931:notes:308]
During the fiscal year ended March 31, 2014, the Company recognized approximately $6.7 million of other exit costs, which primarily were comprised of $3.8 million related to personnel costs and $2.9 million of contractual obligations that resulted from facility closures. The majority of these costs were classified as a component of cost of sales.

[0001047469-15-004931:notes:309]
Fiscal Year 2013

[0001047469-15-004931:notes:310]
During the fiscal year ended March 31, 2013, the Company recognized restructuring charges of approximately $227.4 million, of which $110.1 million was associated with the terminations of 9,138 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 4,467, 2,282, and 2,389 for Asia, the Americas and Europe, respectively. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on facilities and equipment that are not recoverable through future cash flows or are no longer in use and are to be disposed of, and other exit related costs due to facility closures or rationalizations. Pre-tax restructuring charges comprised $123.0 million of cash charges predominantly related to employee severance costs and $104.4 million of non-cash charges primarily related to asset impairment and other exit charges. The activities associated with these charges were completed by the first quarter of fiscal year 2014.

[0001047469-15-004931:notes:311]
The components of the restructuring charges by geographic region incurred in fiscal year 2013 are as follows:

[0001047469-15-004931:notes:312]
|  |  | ThirdQuarter |  | FourthQuarter |  | Total |  |
|  |  | (In thousands) |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |
| Severance |  | $ | 863 |  | $ | 13,156 |  | $ | 14,019 |  |
| Long-lived asset impairment |  |  | — |  |  | 6,302 |  |  | 6,302 |  |
| Other exit costs |  |  | 322 |  |  | 6,533 |  |  | 6,855 |  |
| Total restructuring charges |  |  | 1,185 |  |  | 25,991 |  |  | 27,176 |  |
| Asia: |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 8,572 |  |  | 18,076 |  |  | 26,648 |  |
| Long-lived asset impairment |  |  | 46,250 |  |  | 5,268 |  |  | 51,518 |  |
| Other exit costs |  |  | 28,818 |  |  | 1,443 |  |  | 30,261 |  |
| Total restructuring charges |  |  | 83,640 |  |  | 24,787 |  |  | 108,427 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 6,142 |  |  | 63,301 |  |  | 69,443 |  |
| Long-lived asset impairment |  |  | 9,851 |  |  | 1,782 |  |  | 11,633 |  |
| Other exit costs |  |  | 1,873 |  |  | 8,882 |  |  | 10,755 |  |
| Total restructuring charges |  |  | 17,866 |  |  | 73,965 |  |  | 91,831 |  |
| Total |  |  |  |  |  |  |  |  |  |  |
| Severance |  |  | 15,577 |  |  | 94,533 |  |  | 110,110 |  |
| Long-lived asset impairment |  |  | 56,101 |  |  | 13,352 |  |  | 69,453 |  |
| Other exit costs |  |  | 31,013 |  |  | 16,858 |  |  | 47,871 |  |
| Total restructuring charges |  | $ | 102,691 |  | $ | 124,743 |  | $ | 227,434 |  |

[0001047469-15-004931:notes:313]
During the fiscal year ended March 31, 2013, the Company recognized approximately $110.1 million of severance costs related to employee terminations. Approximately $98.5 million of this was classified as a component of cost of sales for fiscal year 2013.

[0001047469-15-004931:notes:314]
During the fiscal year ended March 31, 2013, the Company recognized approximately $69.5 million for the write-down of property and equipment and other manufacturing assets. The majority of this amount was classified as a component of cost of sales.

[0001047469-15-004931:notes:315]
During the fiscal year ended March 31, 2013, the Company recognized approximately $47.9 million of other exit costs, which primarily were comprised of $22.8 million for the write-down of certain customer specific assets that were determined to be unrecoverable based on a specific product exit and resulting declining customer volumes. Additionally, for fiscal year 2013, other exit costs include $24.7 million of customer disengagement costs primarily related to inventory that resulted from a product exit as well as contractual obligations from facility closures.

[0001047469-15-004931:notes:316]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of March 31, 2015 for charges incurred in fiscal years 2015, 2014, 2013 and prior periods:

[0001047469-15-004931:notes:317]
|  |  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of March 31, 2012 |  | $ | 4,620 |  | $ | — |  | $ | 8,067 |  | $ | 12,687 |  |
| Provision for charges incurred in fiscal year 2013 |  |  | 110,110 |  |  | 69,453 |  |  | 47,871 |  |  | 227,434 |  |
| Cash payments for charges incurred in fiscal year 2013 |  |  | (28,586 | ) |  | — |  |  | (3,832 | ) |  | (32,418 | ) |
| Cash payments for charges incurred in fiscal year 2010 and prior |  |  | (2,455 | ) |  | — |  |  | (2,902 | ) |  | (5,357 | ) |
| Non-cash charges incurred in fiscal year 2013 |  |  | — |  |  | (69,453 | ) |  | (34,993 | ) |  | (104,446 | ) |
| Balance as of March 31, 2013 |  |  | 83,689 |  |  | — |  |  | 14,211 |  |  | 97,900 |  |
| Provision for charges incurred in fiscal year 2014 |  |  | 66,718 |  |  | 1,900 |  |  | 6,693 |  |  | 75,311 |  |
| Cash payments for charges incurred in fiscal year 2014 |  |  | (40,273 | ) |  | — |  |  | (4,296 | ) |  | (44,569 | ) |
| Cash payments for charges incurred in fiscal year 2013 |  |  | (71,470 | ) |  | — |  |  | (8,755 | ) |  | (80,225 | ) |
| Cash payments for charges incurred in fiscal year 2010 and prior |  |  | (2,171 | ) |  | — |  |  | (1,950 | ) |  | (4,121 | ) |
| Non-cash charges incurred in fiscal year 2014 |  |  | — |  |  | (1,900 | ) |  | — |  |  | (1,900 | ) |
| Balance as of March 31, 2014 |  |  | 36,493 |  |  | — |  |  | 5,903 |  |  | 42,396 |  |
| Cash payments for charges incurred in fiscal year 2014 |  |  | (18,558 | ) |  | — |  |  | (2,212 | ) |  | (20,770 | ) |
| Cash payments for charges incurred in fiscal year 2013 |  |  | (4,560 | ) |  | — |  |  | (1,685 | ) |  | (6,245 | ) |
| Cash payments for charges incurred in fiscal year 2010 and prior |  |  | (12 | ) |  | — |  |  | (312 | ) |  | (324 | ) |
| Balance as of March 31, 2015 |  |  | 13,363 |  |  | — |  |  | 1,694 |  |  | 15,057 |  |
| Less: Current portion (classified as other current liabilities) |  |  | 3,078 |  |  | — |  |  | 390 |  |  | 3,468 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) |  | $ | 10,285 |  | $ | — |  | $ | 1,304 |  | $ | 11,589 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001047469-15-004931:notes:318]
|  |  | As of March 31, |  |  |  |
|  |  | 2015 |  |  |  | 2014 |  |  |  |
|  |  | (In thousands) |  |  |  |
| Property and equipment, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia |  | $ | 997,806 |  |  | 48 | % | $ | 1,154,467 |  |  | 50 | % |
| Americas |  |  | 782,839 |  |  | 37 | % |  | 785,753 |  |  | 34 | % |
| Europe |  |  | 311,522 |  |  | 15 | % |  | 348,436 |  |  | 16 | % |
|  |  | $ | 2,092,167 |  |  |  |  | $ | 2,288,656 |  |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001047469-15-004931:notes:319]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia |  | $ | 12,953,004 |  |  | 50 | % | $ | 13,714,187 |  |  | 53 | % | $ | 11,743,140 |  |  | 50 | % |
| Americas |  |  | 8,897,868 |  |  | 34 | % |  | 8,189,414 |  |  | 31 | % |  | 7,193,063 |  |  | 30 | % |
| Europe |  |  | 4,297,044 |  |  | 16 | % |  | 4,205,006 |  |  | 16 | % |  | 4,633,272 |  |  | 20 | % |
|  |  | $ | 26,147,916 |  |  |  |  | $ | 26,108,607 |  |  |  |  | $ | 23,569,475 |  |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001047469-15-004931:notes:320]
|  |  | Fiscal Year Ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |
| Integrated Network Solutions |  | $ | 9,191,211 |  | $ | 9,688,023 |  | $ | 9,935,302 |  |
| Consumer Technology Group |  |  | 8,940,043 |  |  | 9,357,635 |  |  | 7,036,903 |  |
| Industrial & Emerging Industries |  |  | 4,459,351 |  |  | 3,787,838 |  |  | 3,762,508 |  |
| High Reliability Solutions |  |  | 3,557,311 |  |  | 3,275,111 |  |  | 2,834,762 |  |
|  |  | $ | 26,147,916 |  | $ | 26,108,607 |  | $ | 23,569,475 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |  |  |  |
| Integrated Network Solutions |  | $ | 257,323 |  | $ | 259,329 |  | $ | 270,270 |  |
| Consumer Technology Group |  |  | 218,251 |  |  | 125,171 |  |  | 41,339 |  |
| Industrial & Emerging Industries |  |  | 131,956 |  |  | 127,085 |  |  | 157,881 |  |
| High Reliability Solutions |  |  | 227,595 |  |  | 221,402 |  |  | 168,166 |  |
| Corporate and Other |  |  | (83,988 | ) |  | (68,475 | ) |  | (26,280 | ) |
| Total segment income |  |  | 751,137 |  |  | 664,512 |  |  | 611,376 |  |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization |  |  | 32,035 |  |  | 28,892 |  |  | 29,529 |  |
| Stock-based compensation |  |  | 50,270 |  |  | 40,439 |  |  | 34,529 |  |
| Restructuring charges |  |  | — |  |  | 75,311 |  |  | 227,434 |  |
| Other charges (income), net |  |  | (53,233 | ) |  | 57,512 |  |  | (65,190 | ) |
| Interest and other, net |  |  | 51,410 |  |  | 61,904 |  |  | 56,259 |  |
| Income from continuing operations before income taxes |  | $ | 670,655 |  | $ | 400,454 |  | $ | 328,815 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001047469-15-004931:notes:321]
19. SEGMENT REPORTING

[0001047469-15-004931:notes:322]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the Chief Operating Decision Maker ("CODM"), or a decision making group, in deciding how to allocate resources and in assessing performance. Resource allocation decisions and the Company's performance are assessed by its Chief Executive Officer ("CEO"), with support from his direct staff who oversee certain operations of the business, collectively identified as the CODM or the decision making group.

[0001047469-15-004931:notes:323]
During the fourth quarter of fiscal year 2015, the Company reassessed its conclusion around what constitutes the CODM for the Company. It was concluded that the CODM group is collectively the CEO, as supported by his direct staff who oversee the operations of the Company's four business groups. Based on this reassessment, the Company concluded it has four reportable operating segments which are aligned to its four business groups: HRS, CTG, IEI, and INS. These segments represent components of the Company for which separate financial information is available that is utilized on a regular basis by the CODM. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 to the financial statements for a description of the various product categories manufactured under each of these segments.

[0001047469-15-004931:notes:324]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges, other charges (income), net and interest and other, net.

[0001047469-15-004931:notes:325]
A portion of amortization and depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses. As property and equipment is not allocated to the segment, amortization and depreciation is not separately reviewed by the CODM group.

[0001047469-15-004931:notes:326]
Selected financial information by segment is as follows:

[0001047469-15-004931:notes:327]
Asset information on a segment basis is not disclosed as this information is not separately identified and is not internally reported to the Company's CODM.

[0001047469-15-004931:notes:328]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0001047469-15-004931:notes:329]
Geographic information is as follows:

[0001047469-15-004931:notes:330]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0001047469-15-004931:notes:331]
During fiscal years 2015, 2014 and 2013, net sales generated from Singapore, the principal country of domicile, were approximately $553.4 million, $504.6 million and $551.7 million, respectively.

[0001047469-15-004931:notes:332]
During fiscal year 2015, China, Mexico, and the United States accounted for approximately 37%, 13%, and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2015.

[0001047469-15-004931:notes:333]
During fiscal year 2014, China, Mexico, and the United States accounted for approximately 40%, 14%, and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2014.

[0001047469-15-004931:notes:334]
During fiscal year 2013, China, Mexico, the United States and Malaysia accounted for approximately 35%, 15%, 11% and 10% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2013.

[0001047469-15-004931:notes:335]
As of March 31, 2015 and 2014, property and equipment, net held in Singapore were approximately $19.3 million and $17.0 million, respectively.

[0001047469-15-004931:notes:336]
As of March 31, 2015, China, Mexico and the United States accounted for approximately 37%, 17% and 15%, respectively, of property and equipment, net. No other country accounted for more than 10% of property and equipment, net as of March 31, 2015.

[0001047469-15-004931:notes:337]
As of March 31, 2014, China, the United States and Mexico accounted for approximately 41%, 16% and 14%, respectively, of consolidated property and equipment, net. No other country accounted for more than 10% of property and equipment, net as of March 31, 2014.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001047469-15-004931:notes:338]
10. TRADE RECEIVABLES SECURITIZATION

[0001047469-15-004931:notes:339]
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0001047469-15-004931:notes:340]
Asset-Backed Securitization Programs

[0001047469-15-004931:notes:341]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the "Global Program") and its North American Asset-Backed Securitization Agreement (the "North American Program," collectively, the "ABS Programs") to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $550.0 million for the Global Program and $225.0 million for the North American Program. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001047469-15-004931:notes:342]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the fiscal years ended March 31, 2015, 2014 and 2013 were not material and are included in interest and other, net within the consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0001047469-15-004931:notes:343]
As of March 31, 2015 and 2014, the accounts receivable balances that were sold under the ABS Programs were removed from the consolidated balance sheets and the net cash proceeds received by the Company during fiscal years ended March 31, 2015, 2014 and 2013 were included as cash provided by operating activities in the consolidated statements of cash flows.

[0001047469-15-004931:notes:344]
As of March 31, 2015, approximately $1.3 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of $740.7 million and deferred purchase price receivables of $600.7 million. As of March 31, 2014, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $729.3 million and deferred purchase price receivables of $470.9 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of March 31, 2015 and 2014, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the consolidated statements of operations; such amounts were $7.1 million for both fiscal years ended March 31, 2015 and 2014, and $7.2 million for the fiscal year ended March 31, 2013.

[0001047469-15-004931:notes:345]
For the fiscal years ended March 31, 2015, 2014 and 2013, cash flows from sales of receivables under the ABS Programs consisted of approximately $4.3 billion, $4.2 billion and $3.5 billion, respectively for transfers of receivables (of which approximately $0.3 billion, $0.4 billion and $0.7 billion, respectively represented new transfers and the remainder proceeds from collections reinvested in revolving period transfers).

[0001047469-15-004931:notes:346]
The following table summarizes the activity in the deferred purchase price receivables account during the fiscal years ended March 31, 2015 and 2014:

[0001047469-15-004931:notes:347]
Trade Accounts Receivable Sale Programs

[0001047469-15-004931:notes:348]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $485.6 million and $341.8 million as of March 31, 2015 and 2014, respectively. For the years ended March 31, 2015, 2014 and 2013, total accounts receivables sold to certain third party banking institutions was approximately $4.2 billion, $3.4 billion and $1.1 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and were reflected as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0001047469-15-004931:notes:349]
18. SHARE REPURCHASE PLAN

[0001047469-15-004931:notes:350]
During fiscal year 2015, the Company repurchased approximately 39.0 million shares for an aggregate purchase value of approximately $421.7 million under two separate repurchase plans as further discussed below.

[0001047469-15-004931:notes:351]
During the second quarter of fiscal year 2015, the Company repurchased the entire remaining amount under a prior share repurchase plan that was approved by the Company's Board of Directors on July 24, 2013 and the Company's shareholders at the 2013 Extraordinary General Meeting held on July 29, 2013, or approximately 15.9 million shares for an aggregate purchase value of approximately $160.1 million, and retired all of these shares.

[0001047469-15-004931:notes:352]
Under the Company's current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company's shareholders at the date of the most recent Extraordinary General Meeting held on August 28, 2014. During fiscal year 2015, the Company repurchased approximately 23.0 million shares for an aggregate purchase value of approximately $261.6 million under this plan, including amounts accrued but not paid, and retired all of these shares. As of March 31, 2015, shares in the aggregate amount of $238.4 million were available to be repurchased under the current Board authorization.
