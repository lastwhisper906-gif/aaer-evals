# FLEX MD&A — 0001047469-15-004931


## mdna

[0001047469-15-004931:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001047469-15-004931:mdna:2]
OVERVIEW

[0001047469-15-004931:mdna:3]
We are a globally-recognized leading provider of innovative design, manufacturing, and supply chain services and solutions that span  from sketch to
scale; from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer electronics and
industrial products for original equipment manufacturers ("OEMs"), through our activities in the following business groups: High Reliability Solutions ("HRS"), which is comprised of our medical
business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics,; and our
defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group ("CTG"), which includes our mobile devices business, including smart phones; our
consumer

[0001047469-15-004931:mdna:4]
37

[0001047469-15-004931:mdna:5]
electronics
business, including connected living, wearable electronics, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for
notebook personal computing, tablets and printers; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, test and measurement,
household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions ("INS"), which includes radio access base stations, remote
radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting and switching products for the data and video network; server and storage platforms for both enterprise and
cloud based deployments; next generation storage and security appliance products and rack level solutions, converged infrastructure and software defined product solutions. As of March 31, 2015
the above described business groups comprise our reportable segments. Please refer to note 19 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary
Data."

[0001047469-15-004931:mdna:6]
Our
strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a
complete packaged product for our OEM customers. This enables our OEM customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001047469-15-004931:mdna:7]
Over
the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified
themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home
entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more
complex, the supply chain solutions required by such companies have become more
customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0001047469-15-004931:mdna:8]
We
use a portfolio approach to manage our extensive service offerings. As our OEM customers change the way they go to market, we are able to reorganize and rebalance our business
portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and
reposition our assets and resources as necessary to meet specific customer's supply chain solutions needs across all of the markets we serve and earn a return on our invested capital above the
weighted average cost of that capital.

[0001047469-15-004931:mdna:9]
During
the past few years we have made significant efforts to evolve our long-term portfolio towards a higher mix of businesses which possess longer product life cycles and higher
margins such as reflected in our IEI and HRS businesses. During the last two fiscal years we launched several programs broadly across our portfolio of services and in some instances we deployed
certain new technologies. Some of these programs have started to yield better results, as demonstrated by our margin improvement over a comparable base of sales during fiscal year 2015. We continue to
invest in innovation and we have expanded our design and engineering relationships through our product innovation centers.

[0001047469-15-004931:mdna:10]
We
believe that our business transformation has strategically positioned us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing
capabilities, design and engineering services and after-market services, which remain strong.

[0001047469-15-004931:mdna:11]
We
are one of the world's largest providers of global supply chain solutions, with revenues of $26.1 billion in fiscal year 2015. We have established an extensive network of
manufacturing facilities in the world's major consumer electronics and industrial markets (Asia, the Americas, and Europe) in order to serve the growing outsourcing needs of both multinational and
regional OEMs. We design, build, ship, and service consumer electronics and industrial products for our customers through a

[0001047469-15-004931:mdna:12]
network
of over 100 facilities in approximately 30 countries across four continents. As of March 31, 2015, our total manufacturing capacity was approximately 24.4 million square feet. In
fiscal year 2015, our net sales in Asia, the Americas and Europe represented approximately 50%, 34% and 16%, respectively, of our total net sales, based on the location of the manufacturing site. The
following tables set forth net sales and net property and equipment, by country, based on the location of our manufacturing sites and the relative percentages:

[0001047469-15-004931:mdna:13]
|  |  | Fiscal Year Ended March 31, |  |
| Net sales: |  | 2015 |  | 2014 |  | 2013 |  |
|  |  | (In thousands) |  |
| China |  | $ | 9,550,837 |  |  | 37 | % | $ | 10,521,169 |  |  | 40 | % | $ | 8,132,776 |  |  | 35 | % |
| Mexico |  |  | 3,512,767 |  |  | 13 | % |  | 3,565,803 |  |  | 14 | % |  | 3,534,067 |  |  | 15 | % |
| U.S |  |  | 2,876,359 |  |  | 11 | % |  | 2,829,807 |  |  | 11 | % |  | 2,539,460 |  |  | 11 | % |
| Brazil |  |  | 2,474,291 |  |  | 9 | % |  | 1,699,209 |  |  | 6 | % |  | 1,023,790 |  |  | 4 | % |
| Malaysia |  |  | 2,300,579 |  |  | 9 | % |  | 2,142,437 |  |  | 8 | % |  | 2,440,902 |  |  | 10 | % |
| Other |  |  | 5,433,083 |  |  | 21 | % |  | 5,350,182 |  |  | 21 | % |  | 5,898,480 |  |  | 25 | % |
|  |  | $ | 26,147,916 |  |  |  |  | $ | 26,108,607 |  |  |  |  | $ | 23,569,475 |  |  |  |  |

[0001047469-15-004931:mdna:14]
|  |  | Fiscal Year Ended March 31, |  |
| Property and equipment, net: |  | 2015 |  | 2014 |  |
|  |  | (In thousands) |  |
| China |  | $ | 776,914 |  |  | 37 | % | $ | 941,850 |  |  | 41 | % |
| Mexico |  |  | 364,435 |  |  | 17 | % |  | 326,287 |  |  | 14 | % |
| U.S |  |  | 314,613 |  |  | 15 | % |  | 362,199 |  |  | 16 | % |
| Malaysia |  |  | 165,779 |  |  | 8 | % |  | 153,194 |  |  | 7 | % |
| Brazil |  |  | 103,496 |  |  | 5 | % |  | 88,867 |  |  | 4 | % |
| Other |  |  | 366,930 |  |  | 18 | % |  | 416,259 |  |  | 18 | % |
|  |  | $ | 2,092,167 |  |  |  |  | $ | 2,288,656 |  |  |  |  |

[0001047469-15-004931:mdna:15]
We
believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant
scale and global presence, and industrial campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and
servicing consumer electronics and industrial products for leading multinational and regional OEMs. Specifically, we have launched multiple product innovation centers ("PIC") focused
exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time
to market and cost savings.

[0001047469-15-004931:mdna:16]
Our
operating results are affected by a number of factors, including the following:

[0001047469-15-004931:mdna:17]
•

[0001047469-15-004931:mdna:18]
changes in the macro-economic environment and related changes in consumer demand;

[0001047469-15-004931:mdna:19]
•

[0001047469-15-004931:mdna:20]
the mix of the manufacturing services we are providing, the number and size of new manufacturing programs, the degree to which we
utilize our manufacturing capacity, seasonal demand, shortages of components and other factors;

[0001047469-15-004931:mdna:21]
•

[0001047469-15-004931:mdna:22]
the effects on our business when our customers are not successful in marketing their products, or when their products do not gain
widespread commercial acceptance;

[0001047469-15-004931:mdna:23]
•

[0001047469-15-004931:mdna:24]
our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance
specifications demanded by our OEM customers;

[0001047469-15-004931:mdna:25]
•

[0001047469-15-004931:mdna:26]
the effects on our business due to our customers' products having short product life cycles;

[0001047469-15-004931:mdna:27]
•

[0001047469-15-004931:mdna:28]
our customers' ability to cancel or delay orders or change production quantities;

[0001047469-15-004931:mdna:29]
•

[0001047469-15-004931:mdna:30]
our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements;

[0001047469-15-004931:mdna:31]
•

[0001047469-15-004931:mdna:32]
our exposure to financially troubled customers;

[0001047469-15-004931:mdna:33]
•

[0001047469-15-004931:mdna:34]
integration of acquired businesses and facilities;

[0001047469-15-004931:mdna:35]
•

[0001047469-15-004931:mdna:36]
increased labor costs due to adverse labor conditions in the markets we operate; and

[0001047469-15-004931:mdna:37]
•

[0001047469-15-004931:mdna:38]
changes in tax legislation.

[0001047469-15-004931:mdna:39]
We
also are subject to other risks as outlined in Item 1A, "Risk Factors."

[0001047469-15-004931:mdna:40]
Net
sales for fiscal year 2015 remained relatively stable from the prior year, increasing by 0.2% or $39.3 million to $26.1 billion. Revenue increased for our IEI and HRS
business groups, offset by decreases for our INS and CTG business groups. Our fiscal year 2015 gross profit totaled $1.5 billion, representing an increase of $105.1 million, or 7.3%, and
our income from continuing operations totaled $600.8 million, representing an increase of $235.2 million, or 64.3%, compared to fiscal year 2014. Both gross profit and income from
continuing operations increased primarily as a result of an improved cost structure and operating efficiencies following our restructuring activities completed in the fiscal years 2014 and 2013
coupled with an increase in sales from our IEI and HRS business groups which contribute higher margins. Our income before taxes further benefited by the reversal of a customer contractual obligation
in fiscal year 2015 in the amount of $55.0 million, which was accrued in fiscal year
2014, upon execution of an amendment to the customer contract in early fiscal year 2015, which relieved us of this contractual obligation, as discussed in note 15 to the consolidated financial
statements in Item 8, "Financial Statements and Supplementary Data".

[0001047469-15-004931:mdna:41]
Cash
provided by operations decreased approximately $422.4 million to $0.8 billion for the fiscal year 2015 compared with $1.2 billion for the fiscal year 2014
primarily due to unfavorable changes in operating assets and liabilities. Our average net working capital, defined as accounts receivable, including deferred purchase price receivable from our
asset-backed securitization programs plus inventory less accounts payable, as a percentage of annualized sales increased by 0.3% to 7.8%. Our free cash flow, which we define as cash from operating
activities less net purchases of property and equipment, was $554.3 million for fiscal year 2015 compared to $701.5 million for fiscal year 2014, primarily due to the lower cash flows
from operations offset by lower net expenditures during fiscal year 2015. Refer to the Liquidity and Capital Resources section for the free cash flows reconciliation to our most directly comparable
GAAP financial measure of cash flows from operations. Cash used in financing activities amounted to $516.0 million during fiscal year 2015 and included repurchases of approximately
38.7 million ordinary shares at an aggregate purchase value of $415.9 million.

[0001047469-15-004931:mdna:42]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001047469-15-004931:mdna:43]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America
("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at
the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results may differ from those estimates and assumptions.

[0001047469-15-004931:mdna:44]
We
believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further
discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0001047469-15-004931:mdna:45]
40

[0001047469-15-004931:mdna:46]
Revenue Recognition

[0001047469-15-004931:mdna:47]
We recognize manufacturing revenue when we ship goods or the goods are received by our customer, title and risk of ownership have
passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations
related to manufacturing services. If such requirements or obligations exist, then we recognize the related revenues at the time when such requirements are completed and the obligations are fulfilled.
Some of our customer contracts allow us to recover certain costs related to manufacturing services that are over and above the prices we charge for the related products. We determine the amount of
costs that are recoverable based on historical experiences and agreements with those customers. Also, certain customer contracts may contain certain commitments and obligations that may result in
additional expenses or decrease in revenue. We accrue for these commitments and obligations based on facts and circumstances and contractual terms. We also make provisions for estimated sales returns
and other adjustments at the time revenue is recognized based upon contractual terms and an analysis of historical returns. Provisions for sales returns and other adjustments were not material to our
consolidated financial statements for any of the periods presented.

[0001047469-15-004931:mdna:48]
We
provide a comprehensive suite of services for our customers that range from advanced product design to manufacturing and logistics to after-sales services. We recognize service
revenue when the services have been performed, and the related costs are expensed as incurred. Our net sales for services were less than 10% of our total sales for all periods presented, and
accordingly, are included in net sales in the consolidated statements of operations.

[0001047469-15-004931:mdna:49]
Customer Credit Risk

[0001047469-15-004931:mdna:50]
We have an established customer credit policy through which we manage customer credit exposures through credit evaluations, credit
limit setting, monitoring, and enforcement of credit limits for new and existing customers. We perform ongoing credit evaluations of our customers' financial condition and make provisions for doubtful
accounts based on the outcome of those credit evaluations. We evaluate the collectability of accounts receivable based on specific customer circumstances, current economic trends, historical
experience with collections and the age of past due receivables. To the extent we identify exposures as a result of credit or customer evaluations, we also review other customer related exposures,
including but not limited to inventory and related contractual obligations.

[0001047469-15-004931:mdna:51]
Restructuring Charges

[0001047469-15-004931:mdna:52]
We recognize restructuring charges related to our plans to close or consolidate excess manufacturing and administrative facilities and
to realign our corporate cost structure. In connection with these activities, we recognize restructuring charges for employee termination costs, long-lived asset impairment and other exit-related
costs.

[0001047469-15-004931:mdna:53]
The
recognition of these restructuring charges requires that we make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit
activity. To the extent our actual results differ from our estimates and assumptions, we may be required to revise the estimates of future liabilities, requiring the recognition of additional
restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each
reporting period, we evaluate the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with
developed exit plans.

[0001047469-15-004931:mdna:54]
Refer
to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0001047469-15-004931:mdna:55]
41

[0001047469-15-004931:mdna:56]
Carrying Value of Long-Lived Assets

[0001047469-15-004931:mdna:57]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or
changes in circumstances indicate that the carrying amount of the asset may not be recoverable. An impairment loss is recognized when the carrying amount of these long-lived assets exceeds their fair
value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to
generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable
intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, general
business environment and other factors. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize additional impairment charges in the
future.

[0001047469-15-004931:mdna:58]
Goodwill
is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability
of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among
other factors, market multiples for comparable companies as well as a discounted cash flow analysis. During the fourth quarter of fiscal year 2015, the Company identified four reportable operating
segments: HRS, CTG, IEI and INS and concluded these same four segments also represented its reporting units. The Company performed its goodwill impairment assessment on January 1, 2015 and
determined that no impairment existed as of the date of the impairment test because the fair value of each reporting unit exceeded its carrying value.

[0001047469-15-004931:mdna:59]
Inventory Valuation

[0001047469-15-004931:mdna:60]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by
rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted
demand, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production
requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition,
unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability
to fulfill their contractual obligations with regard to inventory procured to fulfill customer demand.

[0001047469-15-004931:mdna:61]
Contingent Liabilities

[0001047469-15-004931:mdna:62]
We may be exposed to certain liabilities relating to our business operations, acquisitions of businesses and assets and other
activities. We make provisions for such liabilities when it is probable that the settlement of the liability will result in an outflow of economic resources or the impairment of an asset. We make
these assessments based on facts and circumstances that may change in the future resulting in additional expenses.

[0001047469-15-004931:mdna:63]
Income Taxes

[0001047469-15-004931:mdna:64]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and
liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it
is more likely than not that we will be able to generate sufficient future

[0001047469-15-004931:mdna:65]
taxable
income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or
international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax
assets previously recognized, resulting in additional or lesser income tax expense.
