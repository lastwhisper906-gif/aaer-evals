# FLEX notes — 0000866374-23-000007


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-23-000007:notes:1]
[same as prior period, unchanged from 0000866374-22-000074:notes:1]

[0000866374-23-000007:notes:2]
[same as prior period, unchanged from 0000866374-22-000074:notes:2]

[0000866374-23-000007:notes:3]
[same as prior period, unchanged from 0000866374-22-000074:notes:3]

[0000866374-23-000007:notes:4]
[same as prior period, unchanged from 0000866374-22-000074:notes:4]

[0000866374-23-000007:notes:5]
[same as prior period, unchanged from 0000866374-22-000074:notes:5]

[0000866374-23-000007:notes:6]
[same as prior period, unchanged from 0000866374-22-000074:notes:6]

[0000866374-23-000007:notes:7]
[same as prior period, unchanged from 0000866374-22-000074:notes:7]

[0000866374-23-000007:notes:8]
[same as prior period, unchanged from 0000866374-22-000074:notes:8]

[0000866374-23-000007:notes:9]
[same as prior period, unchanged from 0000866374-22-000074:notes:9]

[0000866374-23-000007:notes:10]
[same as prior period, unchanged from 0000866374-22-000074:notes:10]

[0000866374-23-000007:notes:11]
[same as prior period, unchanged from 0000866374-22-000074:notes:11]

[0000866374-23-000007:notes:12]
[same as prior period, unchanged from 0000866374-22-000074:notes:12]

[0000866374-23-000007:notes:13]
[same as prior period, unchanged from 0000866374-22-000074:notes:13]

[0000866374-23-000007:notes:14]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2022 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

[0000866374-23-000007:notes:15]
The Company's third quarters for fiscal years 2023 and 2022 ended on December 31 of each year, which are comprised of 92 and 91 days, respectively. The Company's first three quarters for fiscal years 2023 and 2022 both are comprised of 275 days.

[0000866374-23-000007:notes:16]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. In all cases other than the redeemable noncontrolling interest in Nextracker, the associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of Interest and other, net, in the condensed consolidated statements of operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company

[0000866374-23-000007:notes:17]
is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the condensed consolidated statements of operations.

[0000866374-23-000007:notes:18]
[same as prior period, unchanged from 0000866374-22-000074:notes:18]

[0000866374-23-000007:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic and geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the COVID-19 pandemic and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-23-000007:notes:20]
Recently Adopted Accounting Pronouncements

[0000866374-23-000007:notes:21]
In December 2022, the FASB issued ASU 2022-06 "Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848", which defers the sunset date of ASC 848 from December 31, 2022 to December 31, 2024. ASC 848 provides relief for companies preparing for the discontinuation of interest rates, such as LIBOR. Entities that apply ASC 848 can continue to do so until December 31, 2024. The Company adopted the guidance during the third quarter of fiscal year 2023 with an immaterial impact on its consolidated financial statements.

[0000866374-23-000007:notes:22]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company adopted the guidance during the first quarter of fiscal year 2023 with an immaterial impact on its condensed consolidated financial statements.

[0000866374-23-000007:notes:23]
Recently Issued Accounting Pronouncement

[0000866374-23-000007:notes:24]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the first quarter of fiscal year 2024.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-23-000007:notes:25]
[same as prior period, unchanged from 0000866374-22-000074:notes:24]

[0000866374-23-000007:notes:26]
[same as prior period, unchanged from 0000866374-22-000074:notes:25]

[0000866374-23-000007:notes:27]
|  | As of December 31, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| Raw materials | $ | 6,365 |  |  | $ | 5,290 |  |
| Work-in-progress | 689 |  |  | 602 |  |
| Finished goods | 784 |  |  | 688 |  |
|  | $ | 7,838 |  |  | $ | 6,580 |  |

[0000866374-23-000007:notes:28]
[same as prior period, unchanged from 0000866374-22-000074:notes:27]

[0000866374-23-000007:notes:29]
During the nine-month period ended December 31, 2022, there was no material activity in the Company's goodwill account for each of its reportable segments.

[0000866374-23-000007:notes:30]
[same as prior period, unchanged from 0000866374-22-000074:notes:29]

[0000866374-23-000007:notes:31]
|  | As of December 31, 2022 |  | As of March 31, 2022 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 369 |  |  | $ | (189) |  |  | $ | 180 |  |  | $ | 385 |  |  | $ | (157) |  |  | $ | 228 |  |
| Licenses and other intangibles | 294 |  |  | (142) |  |  | 152 |  |  | 319 |  |  | (136) |  |  | 183 |  |
| Total | $ | 663 |  |  | $ | (331) |  |  | $ | 332 |  |  | $ | 704 |  |  | $ | (293) |  |  | $ | 411 |  |

[0000866374-23-000007:notes:32]
[same as prior period, unchanged from 0000866374-22-000074:notes:31]

[0000866374-23-000007:notes:33]
[same as prior period, unchanged from 0000866374-22-000074:notes:32]

[0000866374-23-000007:notes:34]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 21 |  |
| 2024 |  | 69 |  |
| 2025 |  | 62 |  |
| 2026 |  | 42 |  |
| 2027 |  | 35 |  |
| Thereafter |  | 103 |  |
| Total amortization expense |  | $ | 332 |  |

[0000866374-23-000007:notes:35]
[same as prior period, unchanged from 0000866374-22-000074:notes:34]

[0000866374-23-000007:notes:36]
(1)Represents estimated amortization for the remaining fiscal three-month period ending March 31, 2023.

[0000866374-23-000007:notes:37]
[same as prior period, unchanged from 0000866374-22-000074:notes:36]

[0000866374-23-000007:notes:38]
Customer working capital advances were $2.2 billion and $1.4 billion, as of December 31, 2022 and March 31, 2022, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-23-000007:notes:39]
[same as prior period, unchanged from 0000866374-22-000074:notes:38]

[0000866374-23-000007:notes:40]
Other current liabilities include customer-related accruals of $275 million and $227 million as of December 31, 2022 and March 31, 2022, respectively.

[0000866374-23-000007:notes:41]
[same as prior period, unchanged from 0000866374-22-000074:notes:40]

[0000866374-23-000007:notes:42]
As a result of the sale by a subsidiary of the Company of redeemable preferred units (“Series A Preferred Units”), representing a 16.67% interest in the Company's subsidiary, Nextracker LLC ("Nextracker"), to TPG Rise Flash, L.P. ("TPG Rise") on February 1, 2022, the Company recognized approximately $7 million and $19 million of a payable-in-kind dividend due to TPG Rise during the three and nine-month periods ended December 31, 2022, respectively, based on a dividend rate of 5% per annum.

[0000866374-23-000007:notes:43]
At TPG Rise’s election, the Company is required to purchase all of the outstanding Series A Preferred Units at their liquidation preference, which shall include all contributed but unreturned capital plus accrued but unpaid dividends, at the earlier of certain change in control events and February 1, 2028. Additionally, if Nextracker has not completed a qualified initial public offering (a "Qualified Public Offering") prior to February 1, 2027, then TPG Rise may cause the Company to purchase all of the outstanding Series A Preferred Units at their fair market value. The Company has determined that a Qualified Public Offering is likely and that the change in control is not probable as of December 31, 2022 and, as such, it is not probable that the noncontrolling interest will become redeemable.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-23-000007:notes:44]
[same as prior period, unchanged from 0000866374-22-000074:notes:43]

[0000866374-23-000007:notes:45]
[same as prior period, unchanged from 0000866374-22-000074:notes:44]

[0000866374-23-000007:notes:46]
[same as prior period, unchanged from 0000866374-22-000074:notes:45]

[0000866374-23-000007:notes:47]
[same as prior period, unchanged from 0000866374-22-000074:notes:46]

[0000866374-23-000007:notes:48]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement

[0000866374-23-000007:notes:49]
mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the condensed consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-23-000007:notes:50]
[same as prior period, unchanged from 0000866374-22-000074:notes:48]

[0000866374-23-000007:notes:51]
[same as prior period, unchanged from 0000866374-22-000074:notes:49]

[0000866374-23-000007:notes:52]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-23-000007:notes:53]
[same as prior period, unchanged from 0000866374-22-000074:notes:52]

[0000866374-23-000007:notes:54]
[same as prior period, unchanged from 0000866374-22-000074:notes:53]

[0000866374-23-000007:notes:55]
[same as prior period, unchanged from 0000866374-22-000074:notes:54]

[0000866374-23-000007:notes:56]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $813 million and $704 million as of December 31, 2022 and March 31, 2022, respectively, of which $745 million and $615 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-23-000007:notes:57]
[same as prior period, unchanged from 0000866374-22-000074:notes:56]

[0000866374-23-000007:notes:58]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2022 and December 31, 2021, respectively. Historical information for the first three quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.

[0000866374-23-000007:notes:59]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,812 |  |  | $ | 3,389 |  |  | $ | 11,378 |  |  | $ | 9,887 |  |
| Over time | 217 |  |  | 192 |  |  | 646 |  |  | 563 |  |
| Total | 4,029 |  |  | 3,581 |  |  | 12,024 |  |  | 10,450 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,038 |  |  | 2,528 |  |  | 8,938 |  |  | 7,243 |  |
| Over time | 187 |  |  | 183 |  |  | 555 |  |  | 515 |  |
| Total | 3,225 |  |  | 2,711 |  |  | 9,493 |  |  | 7,758 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 8 |  |  | 42 |  |  | 41 |  |  | 63 |  |
| Over time | 508 |  |  | 296 |  |  | 1,343 |  |  | 955 |  |
| Total | 516 |  |  | 338 |  |  | 1,384 |  |  | 1,018 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,844 |  |  | 5,948 |  |  | 20,325 |  |  | 17,157 |  |
| Over time | 912 |  |  | 671 |  |  | 2,544 |  |  | 2,033 |  |
| Total | $ | 7,756 |  |  | $ | 6,619 |  |  | $ | 22,869 |  |  | $ | 19,190 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-23-000007:notes:60]
[same as prior period, unchanged from 0000866374-22-000074:notes:59]

[0000866374-23-000007:notes:61]
[same as prior period, unchanged from 0000866374-22-000074:notes:60]

[0000866374-23-000007:notes:62]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
|  | (In millions) |
| Cost of sales | $ | 7 |  |  | $ | 6 |  |  | $ | 21 |  |  | $ | 17 |  |
| Selling, general and administrative expenses | 20 |  |  | 19 |  |  | 59 |  |  | 52 |  |
| Total share-based compensation expense | $ | 27 |  |  | $ | 25 |  |  | $ | 80 |  |  | $ | 69 |  |

[0000866374-23-000007:notes:63]
Total number of options outstanding and exercisable were immaterial as of December 31, 2022. All options have been fully expensed as of December 31, 2022.

[0000866374-23-000007:notes:64]
During the nine-month period ended December 31, 2022, the Company granted 7.0 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 4.7 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, and with an average grant date price of $16.51 per award. In addition, approximately 0.5 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $16.68 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of approximately 1.0 million based on a measurement of the Company's adjusted earnings per share growth over certain specified periods, and will cliff vest after a period of three years, to the extent such performance conditions have been met. Further, approximately 0.5 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $23.45 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 1.0 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions

[0000866374-23-000007:notes:65]
have been met. Finally, the remaining balance of approximately 1.2 million represents the number of shares issued upon vesting of RSU awards above target levels based on the achievement of certain market conditions.

[0000866374-23-000007:notes:66]
As of December 31, 2022, approximately 14.6 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 2.1 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of 0.9 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to 4.2 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to 1.8 million based on the achievement levels. During the nine-month period ended December 31, 2022, 2.4 million shares vested in connection with the awards with market conditions granted in fiscal year 2020.

[0000866374-23-000007:notes:67]
As of December 31, 2022, total unrecognized compensation expense related to unvested RSU awards under all plans, not including the 2022 Nextracker plan below, was approximately $158 million, and will be recognized over a weighted-average remaining vesting period of 2.0 years.

[0000866374-23-000007:notes:68]
During the first three quarters of fiscal year 2023, Nextracker granted 11.8 million equity-based compensation awards, which included approximately 5.9 million unit options, 4.5 million RSU awards and 1.4 million performance-based restricted share unit awards (“PSU”) to its employees under the First Amended and Restated 2022 Nextracker LLC Equity Incentive Plan (the “2022 Nextracker Plan”). Vesting for the awards granted under the 2022 Nextracker Plan is contingent upon continued employee service and certain performance conditions, including a liquidity event such as the occurrence of an initial public offering or the sale of Nextracker.

[0000866374-23-000007:notes:69]
Total unrecognized compensation expense related to unvested awards under the 2022 Nextracker Plan was approximately $55 million, which is expected to be recognized over a weighted-average period of approximately 3 years. No expense was recognized for equity-based compensation awards granted under the 2022 Nextracker Plan for the nine-month period ended December 31, 2022 as there was no occurrence of a liquidity event. Nextracker will record cumulative stock-based compensation expense related to these awards in the period when its liquidity event is completed for the portion of the awards for which the relevant service condition has been satisfied with the remaining expense recognized over the remaining service period.


## us-gaap:EarningsPerShareTextBlock

[0000866374-23-000007:notes:70]
[same as prior period, unchanged from 0000866374-22-000074:notes:68]

[0000866374-23-000007:notes:71]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
|  | (In millions, except per share amounts) |
| Basic earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 237 |  |  | $ | 227 |  |  | $ | 670 |  |  | $ | 769 |  |
| Net income attributable to redeemable noncontrolling interest | 7 |  |  | — |  |  | 19 |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 230 |  |  | $ | 227 |  |  | $ | 651 |  |  | $ | 769 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 452 |  |  | 469 |  |  | 455 |  |  | 481 |  |
| Basic earnings per share | $ | 0.51 |  |  | $ | 0.48 |  |  | $ | 1.43 |  |  | $ | 1.60 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 237 |  |  | $ | 227 |  |  | $ | 670 |  |  | $ | 769 |  |
| Net income attributable to redeemable noncontrolling interest | 7 |  |  | — |  |  | 19 |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 230 |  |  | $ | 227 |  |  | $ | 651 |  |  | $ | 769 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 452 |  |  | 469 |  |  | 455 |  |  | 481 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 7 |  |  | 5 |  |  | 7 |  |  | 6 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 459 |  |  | 474 |  |  | 462 |  |  | 487 |  |
| Diluted earnings per share | $ | 0.50 |  |  | $ | 0.48 |  |  | $ | 1.41 |  |  | $ | 1.58 |  |

[0000866374-23-000007:notes:72]
(1)An immaterial amount of RSU awards for the three and nine-month periods ended December 31, 2022 and December 31, 2021, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-23-000007:notes:73]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2022 and March 31, 2022 are as follows:

[0000866374-23-000007:notes:74]
|  | As of December 31, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | — |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.436% | 250 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 599 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 687 |  |  | 690 |  |
| 6.000% Notes due January 2028 | 396 |  |  | — |  |
| 4.875% Notes due June 2029 | 658 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 687 |  |  | 690 |  |
| Euro Term Loans | 265 |  |  | 389 |  |
| Delayed Draw Term Loan | 150 |  |  | — |  |
| 3.600% HUF Bonds due December 2031 | 264 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (19) |  |  | (18) |  |
|  | 4,016 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (494) |  |  | (949) |  |
| Non-current portion | $ | 3,522 |  |  | $ | 3,248 |  |

[0000866374-23-000007:notes:75]
The weighted-average interest rate for the Company's long-term debt was 4.5% and 4.0% as of December 31, 2022 and March 31, 2022, respectively.

[0000866374-23-000007:notes:76]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2022 are as follows:

[0000866374-23-000007:notes:77]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 26 |  |
| 2024 |  | 468 |  |
| 2025 |  | 250 |  |
| 2026 |  | 1,286 |  |
| 2027 |  | — |  |
| Thereafter |  | 2,005 |  |
| Total |  | $ | 4,035 |  |

[0000866374-23-000007:notes:78]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2023.

[0000866374-23-000007:notes:79]
Notes due January 2028

[0000866374-23-000007:notes:80]
In December 2022, the Company issued $400 million of 6.000% Notes due 2028 (the “Notes”). The Company received proceeds of approximately $396 million, net of discount, from the issuance which were used, together with cash on hand, for general corporate purposes, which includes redeeming its 2023 notes on December 20, 2022 and for working capital requirements. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet of approximately $4 million of costs in conjunction with the issuance of the Notes.

[0000866374-23-000007:notes:81]
Interest on the Notes is payable on January 15 and July 15 of each year, beginning on July 15, 2023. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.

[0000866374-23-000007:notes:82]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant

[0000866374-23-000007:notes:83]
limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries.

[0000866374-23-000007:notes:84]
In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare the entire principle of Notes, together with all accrued and unpaid interest, if any, to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of December 31, 2022, the Company was in compliance with the covenants in the indenture governing the Notes.

[0000866374-23-000007:notes:85]
Euro Term Loan due December 2023

[0000866374-23-000007:notes:86]
In December 2022, the Company borrowed €250 million (approximately $265 million as of December 31, 2022), under a 1-year term-loan agreement. The proceeds of the term loan were used to repay outstanding debt of a €250 million Euro term loan due on December 9, 2022. Borrowings under this term loan bear interest at Euro Interbank Offered Rate (EURIBOR) rate plus 0.7% per annum, which is payable in full on the last day of each 3-month interest period. The term loan is repayable upon maturity, and the borrowings have been included as bank borrowings and current portion of long-term debt under the condensed consolidated balance sheet.

[0000866374-23-000007:notes:87]
The 2027 Credit Facility

[0000866374-23-000007:notes:88]
In July 2022, the Company entered into a new $2.5 billion credit agreement which matures in July 2027 (the "2027 Credit Facility") and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2027 Credit Facility replaced the previous $2.0 billion revolving credit facility, which was due to mature in January 2026.

[0000866374-23-000007:notes:89]
Borrowings under the 2027 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of  (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the Term Secured Overnight Financing Rate (Term SOFR) rate plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.750% per annum, based on the Company’s credit ratings or (ii) Term SOFR (or (x) the “Alternative Currency Term Rate”, which is defined as, depending on the applicable currency at issue, either the Euro Interbank Offered Rate, Tokyo Interbank Offer Rate, or such other term rate per annum as designated with respect to such alternative currency or (y) the “Alternative Currency Daily Rate”, which is defined as, in the case of Sterling, the rate per annum equal to Sterling Overnight Index Average, and for any other alternative currency, such other term rate per annum as designated with respect to such alternative currency) plus the applicable margin for Term SOFR rate (or the Alternative Currency Term Rate) loans ranging between 1.125% and 1.750% per annum, based on the Company’s credit ratings, plus an adjustment for Term SOFR loans of 0.10% per annum and an adjustment for Sterling Overnight Index Average loans of 0.0326% per annum. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the last business day of March, June, September and December of each calendar year and the maturity date, (ii) in the case of borrowings at the Term SOFR rate (or the Alternative Currency Term Rate), on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month and the maturity date and (iii) in the case of borrowings at the Alternative Currency Daily Rate, on the last day of each calendar month and the maturity date. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2027 Credit Facility ranging from 0.125% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.125% to 1.750% per annum (based on the Company’s credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

[0000866374-23-000007:notes:90]
Under the 2027 Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

[0000866374-23-000007:notes:91]
Delayed Draw Term Loan

[0000866374-23-000007:notes:92]
In September 2022, the Company entered into a $450 million delayed draw term loan agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. All borrowings under the delayed draw term loan will become due on the date that is 364 days after the initial borrowing. Interest is based on either (a) a Term SOFR-based formula plus a margin of 100.0 basis points to 162.5 basis points, depending on the Company’s credit ratings, or (b) a Base Rate formula plus a margin of 0.0 basis point to 62.5 basis

[0000866374-23-000007:notes:93]
points, depending on the Company's credit ratings. On November 30, 2022, the Company borrowed $450 million under the delayed draw term loan. Of this amount, $300 million was repaid in December 2022. As of December 31, 2022, the Company had $150 million in borrowings outstanding under the delayed draw term loan agreement, which amount is due on November 29, 2023.

[0000866374-23-000007:notes:94]
The Euro term loan, the 2027 Credit Facility, and delayed draw term loan are unsecured, and contain customary restrictions on the ability of the Company and its subsidiaries to (i) incur liens, (ii) dispose of assets and (iii) make certain acquisitions of other entities. The Euro term loan also contains a restriction on the ability of the Company and its subsidiaries to change its line of business. The 2027 Credit Facility and delayed draw term loan also contain a restriction on the ability of the Company and its subsidiaries to engage in transaction with affiliates. These covenants are subject to a number of significant exceptions and limitations. The Euro term loan, the 2027 Credit Facility, and delayed draw term loan agreement also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio. As of December 31, 2022, the Company was in compliance with the covenants under the Euro term loan, the 2027 Credit Facility, and delayed draw term loan agreement.


## flex:InterestAndOtherNetTextBlock

[0000866374-23-000007:notes:95]
INTEREST AND OTHER, NET 
Interest and other, net for the three and nine-month periods ended December 31, 2022 and December 31, 2021 are primarily composed of the following:

[0000866374-23-000007:notes:96]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 49 |  |  | $ | 38 |  |  | $ | 136 |  |  | $ | 113 |  |
| AR sales program related expenses | 13 |  |  | 1 |  |  | 26 |  |  | 3 |  |
| Equity in (earnings) loss on investments | (3) |  |  | (30) |  |  | 3 |  |  | (52) |  |
| Brazil tax credit (1) | — |  |  | (1) |  |  | — |  |  | (150) |  |

[0000866374-23-000007:notes:97]
(1)During the nine-month period ended December 31, 2021, the Company recognized a $150 million gain related to a certain tax credit upon approval of a "Credit Habilitation" request by the relevant Brazil tax authorities.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-23-000007:notes:98]
[same as prior period, unchanged from 0000866374-22-000074:notes:88]

[0000866374-23-000007:notes:99]
[same as prior period, unchanged from 0000866374-22-000074:notes:89]

[0000866374-23-000007:notes:100]
As of December 31, 2022, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $11.5 billion as summarized below:

[0000866374-23-000007:notes:101]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| CNY |  | 1,759 |  |  | — |  |  | $ | 252 |  |  | $ | — |  |
| EUR |  | 279 |  |  | 38 |  |  | 281 |  |  | 41 |  |
| HUF |  | 141,230 |  |  | — |  |  | 421 |  |  | — |  |
| ILS |  | 376 |  |  | — |  |  | 106 |  |  | — |  |
| JPY |  | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN |  | 7,826 |  |  | — |  |  | 403 |  |  | — |  |
| MYR |  | 510 |  |  | 101 |  |  | 115 |  |  | 23 |  |
| Other |  | N/A |  | N/A |  | 138 |  |  | 5 |  |
|  |  |  |  |  |  | 2,016 |  |  | 69 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 1,060 |  |  | — |  |  | 201 |  |
| CAD |  | 122 |  |  | 72 |  |  | 90 |  |  | 53 |  |
| CNY |  | 3,917 |  |  | — |  |  | 562 |  |  | — |  |
| EUR |  | 2,364 |  |  | 2,527 |  |  | 2,509 |  |  | 2,673 |  |
| GBP |  | 247 |  |  | 287 |  |  | 297 |  |  | 346 |  |
| HUF |  | 90,357 |  |  | 77,398 |  |  | 238 |  |  | 204 |  |
| ILS |  | 645 |  |  | 286 |  |  | 182 |  |  | 81 |  |
| INR |  | 18,673 |  |  | 406 |  |  | 225 |  |  | 5 |  |
| MXN |  | 9,654 |  |  | 7,424 |  |  | 497 |  |  | 382 |  |
| MYR |  | 1,653 |  |  | 786 |  |  | 374 |  |  | 178 |  |
| PLN |  | 274 |  |  | 214 |  |  | 62 |  |  | 48 |  |
| Other |  | N/A |  | N/A |  | 142 |  |  | 100 |  |
|  |  |  |  |  |  | 5,178 |  |  | 4,271 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 7,194 |  |  | $ | 4,340 |  |

[0000866374-23-000007:notes:102]
As of December 31, 2022, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of December 31, 2022 and March 31, 2022, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. The deferred loss was $23 million as of December 31, 2022, and is expected to be recognized as a component of cost of sales and net sales in the condensed consolidated statements of operations over the next twelve-month period, except for the USD JPY cross currency swap, the USD HUF cross currency swaps and the USD EUR cross currency swap, which are further discussed below.

[0000866374-23-000007:notes:103]
The Company entered into a USD JPY cross currency swap in April 2019 to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in current and long-term other liabilities as of December 31, 2022. The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in current and long-term other liabilities as of December 31, 2022. Additionally, the Company entered into a USD EUR cross currency swap in November 2022 to hedge the foreign currency risk on the EUR term loan due December 2023, and the fair value of the cross currency swap was included in current assets as of December 31, 2022. The changes in fair value of the cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated

[0000866374-23-000007:notes:104]
other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY and EUR loan principal and HUF bond principal, which also impact the same line.

[0000866374-23-000007:notes:105]
[same as prior period, unchanged from 0000866374-22-000074:notes:94]

[0000866374-23-000007:notes:106]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31,2022 |  | March 31,2022 |  | Balance SheetLocation |  | December 31,2022 |  | March 31,2022 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 40 |  |  | $ | 22 |  |  | Other current liabilities |  | $ | 28 |  |  | $ | 35 |  |
| Foreign currency contracts | Other assets |  | $ | — |  |  | $ | — |  |  | Other liabilities |  | $ | 112 |  |  | $ | 61 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 37 |  |  | $ | 21 |  |  | Other current liabilities |  | $ | 41 |  |  | $ | 26 |  |

[0000866374-23-000007:notes:107]
[same as prior period, unchanged from 0000866374-22-000074:notes:96]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-23-000007:notes:108]
[same as prior period, unchanged from 0000866374-22-000074:notes:97]

[0000866374-23-000007:notes:109]
|  | Three-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (73) |  |  | $ | (279) |  |  | $ | (352) |  |  | $ | (49) |  |  | $ | (88) |  |  | $ | (137) |  |
| Other comprehensive gains (loss) before reclassifications | 77 |  |  | 80 |  |  | 157 |  |  | (27) |  |  | (14) |  |  | (41) |  |
| Net (gains) loss reclassified from accumulated other comprehensive loss | (49) |  |  | — |  |  | (49) |  |  | 14 |  |  | 6 |  |  | 20 |  |
| Net current-period other comprehensive gains (loss) | 28 |  |  | 80 |  |  | 108 |  |  | (13) |  |  | (8) |  |  | (21) |  |
| Ending balance | $ | (45) |  |  | $ | (199) |  |  | $ | (244) |  |  | $ | (62) |  |  | $ | (96) |  |  | $ | (158) |  |

[0000866374-23-000007:notes:110]
|  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |  | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |
| Other comprehensive loss before reclassifications | (72) |  |  | (83) |  |  | (155) |  |  | (20) |  |  | (24) |  |  | (44) |  |
| Net gains reclassified from accumulated other comprehensive loss | 93 |  |  | — |  |  | 93 |  |  | — |  |  | 5 |  |  | 5 |  |
| Net current-period other comprehensive gains (loss) | 21 |  |  | (83) |  |  | (62) |  |  | (20) |  |  | (19) |  |  | (39) |  |
| Ending balance | $ | (45) |  |  | $ | (199) |  |  | $ | (244) |  |  | $ | (62) |  |  | $ | (96) |  |  | $ | (158) |  |

[0000866374-23-000007:notes:111]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and nine-month periods ended December 31, 2022 were reclassified out of accumulated other comprehensive loss to interest and other, net and cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in accumulated other comprehensive loss for the three-month periods ended December 31, 2022 and 2021 were $9 million and $1 million tax benefits, respectively. The tax impacts on the changes in accumulated other comprehensive loss for the nine-month periods ended December 31, 2022 and 2021 were immaterial and $1 million tax benefits, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-23-000007:notes:112]
[same as prior period, unchanged from 0000866374-22-000074:notes:101]

[0000866374-23-000007:notes:113]
[same as prior period, unchanged from 0000866374-22-000074:notes:102]

[0000866374-23-000007:notes:114]
[same as prior period, unchanged from 0000866374-22-000074:notes:103]

[0000866374-23-000007:notes:115]
During the nine-month periods ended December 31, 2022 and December 31, 2021, no accounts receivable were sold under the ABS Programs.

[0000866374-23-000007:notes:116]
Trade Accounts Receivable Sale Programs
The Company also sells accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.8 billion and $0.6 billion as of December 31, 2022 and March 31, 2022, respectively. For the nine-month periods ended December 31, 2022 and December 31, 2021, total accounts receivable sold to certain third-party banking institutions was approximately $2.6 billion and $1.0 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-23-000007:notes:117]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market 
in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-23-000007:notes:118]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of December 31, 2022 and March 31, 2022.

[0000866374-23-000007:notes:119]
[same as prior period, unchanged from 0000866374-22-000074:notes:108]

[0000866374-23-000007:notes:120]
[same as prior period, unchanged from 0000866374-22-000074:notes:109]

[0000866374-23-000007:notes:121]
The Company’s cash equivalents include bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-23-000007:notes:122]
[same as prior period, unchanged from 0000866374-22-000074:notes:111]

[0000866374-23-000007:notes:123]
[same as prior period, unchanged from 0000866374-22-000074:notes:112]

[0000866374-23-000007:notes:124]
There were no transfers between levels in the fair value hierarchy during the nine-month periods ended December 31, 2022 and December 31, 2021.

[0000866374-23-000007:notes:125]
[same as prior period, unchanged from 0000866374-22-000074:notes:115]

[0000866374-23-000007:notes:126]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of December 31, 2022 and March 31, 2022:

[0000866374-23-000007:notes:127]
|  | Fair Value Measurements as of December 31, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,392 |  |  | $ | — |  |  | $ | 1,392 |  |
| Foreign currency contracts (Note 8) | — |  |  | 77 |  |  | — |  |  | 77 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (181) |  |  | $ | — |  |  | $ | (181) |  |
|  | Fair Value Measurements as of March 31, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 2,285 |  |  | $ | — |  |  | $ | 2,285 |  |
| Foreign currency contracts (Note 8) | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (122) |  |  | $ | — |  |  | $ | (122) |  |

[0000866374-23-000007:notes:128]
[same as prior period, unchanged from 0000866374-22-000074:notes:118]

[0000866374-23-000007:notes:129]
[same as prior period, unchanged from 0000866374-22-000074:notes:119]

[0000866374-23-000007:notes:130]
|  | As of December 31, 2022 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | — |  |  | $ | — |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.436% | 250 |  |  | 250 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 599 |  |  | 590 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 687 |  |  | 650 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 396 |  |  | 397 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 658 |  |  | 621 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 687 |  |  | 644 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | 265 |  |  | 265 |  |  | 389 |  |  | 389 |  |  | Level 2 |
| Delayed Draw Term Loan | 150 |  |  | 150 |  |  | — |  |  | — |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 264 |  |  | 190 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | 79 |  |  | 79 |  |  | 84 |  |  | 84 |  |  | Level 2 |

[0000866374-23-000007:notes:131]
The Notes due June 2025, February 2026, January 2028, June 2029 and May 2030 are valued based on broker trading prices in active markets. HUF Bonds are valued based on the broker trading prices in an inactive market.

[0000866374-23-000007:notes:132]
The Term Loan due April 2024, Euro Term Loans, Delayed Draw Term Loan, and India Facilities bear interest at floating interest rates, and therefore, as of December 31, 2022, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-23-000007:notes:133]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-23-000007:notes:134]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-23-000007:notes:135]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-23-000007:notes:136]
From time to time, the Company enters into intellectual property licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

[0000866374-23-000007:notes:137]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 374 million Brazilian reals (approximately USD $71 million based on the exchange rate as of December 31, 2022). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $12 million). The Company successfully defeated another three of the assessments in September 2022 (totaling approximately 229 million Brazilian reals or USD $43 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 34 million Brazilian reals (approximately USD $6 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-23-000007:notes:138]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-23-000007:notes:139]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2019.

[0000866374-23-000007:notes:140]
The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-23-000007:notes:141]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-23-000007:notes:142]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-23-000007:notes:143]
SHARE REPURCHASES 
During the three and nine-month periods ended December 31, 2022, the Company repurchased 2.1 million and 17.8 million shares at an aggregate purchase price of $40 million and $293 million, respectively, and retired all of these shares.

[0000866374-23-000007:notes:144]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 25, 2022. As of December 31, 2022, shares in the aggregate amount of $937 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-23-000007:notes:145]
[same as prior period, unchanged from 0000866374-22-000074:notes:135]

[0000866374-23-000007:notes:146]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, legal and other, and interest and other, net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-23-000007:notes:147]
Selected financial information by segment is in the table below. Historical information for the first three quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below and in Item 2, "Management's Discussion and Analysis of Financial Condition and Results of Operations."

[0000866374-23-000007:notes:148]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 4,029 |  |  | $ | 3,581 |  |  | $ | 12,024 |  |  | $ | 10,450 |  |
| Flex Reliability Solutions | 3,225 |  |  | 2,711 |  |  | 9,493 |  |  | 7,758 |  |
| Nextracker | 516 |  |  | 338 |  |  | 1,384 |  |  | 1,018 |  |
| Intersegment eliminations | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
|  | $ | 7,756 |  |  | $ | 6,619 |  |  | $ | 22,869 |  |  | $ | 19,190 |  |
| Segment income and reconciliation of income before income taxes: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 181 |  |  | $ | 163 |  |  | $ | 523 |  |  | $ | 453 |  |
| Flex Reliability Solutions | 143 |  |  | 136 |  |  | 465 |  |  | 407 |  |
| Nextracker | 60 |  |  | 18 |  |  | 133 |  |  | 68 |  |
| Corporate and Other | (12) |  |  | (19) |  |  | (43) |  |  | (54) |  |
| Total segment income | 372 |  |  | 298 |  |  | 1,078 |  |  | 874 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 19 |  |  | 15 |  |  | 62 |  |  | 45 |  |
| Stock-based compensation | 27 |  |  | 25 |  |  | 80 |  |  | 69 |  |
| Restructuring charges | 5 |  |  | 2 |  |  | 5 |  |  | 10 |  |
| Legal and other (1) | — |  |  | 5 |  |  | 13 |  |  | 5 |  |
| Interest and other, net | 59 |  |  | 8 |  |  | 152 |  |  | (103) |  |
| Income before income taxes | $ | 262 |  |  | $ | 243 |  |  | $ | 766 |  |  | $ | 848 |  |

[0000866374-23-000007:notes:149]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset impairments (recoveries). During the third quarter of fiscal year 2022, the Company incurred $5 million in acquisition-related costs related to the acquisition of Anord Mardix. During the first half of fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-23-000007:notes:150]
[same as prior period, unchanged from 0000866374-22-000074:notes:140]

[0000866374-23-000007:notes:151]
[same as prior period, unchanged from 0000866374-22-000074:notes:141]


## us-gaap:SubsequentEventsTextBlock

[0000866374-23-000007:notes:152]
SUBSEQUENT EVENTS On January 13, 2023, the Company announced that its subsidiary, Nextracker Inc. ("Nextracker"), publicly filed a registration statement on Form S-1 with the U.S. Securities and Exchange Commission ("SEC") relating to a proposed initial public offering of shares of Nextracker's Class A common stock. The initial public offering and its timing are subject to market and other conditions and the SEC’s review process, and there can be no assurance that we will proceed with such offering or any alternative transaction.
