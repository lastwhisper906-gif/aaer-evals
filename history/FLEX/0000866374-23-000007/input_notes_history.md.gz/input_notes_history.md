# FLEX note change history — 0000866374-22-000074 → 0000866374-23-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0000866374-23-000007:note_history:1]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 374 million Brazilian reals (approximately USD $71 million based on the exchange rate as of December 31, 2022). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $12 million). The Company successfully defeated another three of the assessments in September 2022 (totaling approximately 229 million Brazilian reals or USD $43 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 34 million Brazilian reals (approximately USD $6 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.
  (was, 2022-10-31, similarity 0.9887):
[0000866374-22-000074:note_history:1]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 374 million Brazilian reals (approximately USD $70 million based on the exchange rate as of September 30, 2022). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $11 million). The Company successfully defeated another three of the assessments in September 2022 (totaling approximately 229 million Brazilian reals or USD $43 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 34 million Brazilian reals (approximately USD $6 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0000866374-23-000007:note_history:2]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2022 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.
  (was, 2022-10-31, similarity 0.9939):
[0000866374-22-000074:note_history:2]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2022 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

- added (2023-01-27):
[0000866374-23-000007:note_history:3]
The Company's third quarters for fiscal years 2023 and 2022 ended on December 31 of each year, which are comprised of 92 and 91 days, respectively. The Company's first three quarters for fiscal years 2023 and 2022 both are comprised of 275 days.

- changed (2023-01-27):
[0000866374-23-000007:note_history:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. In all cases other than the redeemable noncontrolling interest in Nextracker, the associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of Interest and other, net, in the condensed consolidated statements of operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company
  (was, 2022-10-31, similarity 0.9321):
[0000866374-22-000074:note_history:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. In all cases other than the redeemable noncontrolling interest in Nextracker, the associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of Interest and other, net, in the condensed consolidated statements of

- changed (2023-01-27):
[0000866374-23-000007:note_history:5]
is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the condensed consolidated statements of operations.
  (was, 2022-10-31, similarity 0.7205):
[0000866374-22-000074:note_history:5]
operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the condensed consolidated statements of operations.

- changed (2023-01-27):
[0000866374-23-000007:note_history:6]
Recently Adopted Accounting Pronouncements
  (was, 2022-10-31, similarity 0.988):
[0000866374-22-000074:note_history:6]
Recently Adopted Accounting Pronouncement

- added (2023-01-27):
[0000866374-23-000007:note_history:7]
In December 2022, the FASB issued ASU 2022-06 "Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848", which defers the sunset date of ASC 848 from December 31, 2022 to December 31, 2024. ASC 848 provides relief for companies preparing for the discontinuation of interest rates, such as LIBOR. Entities that apply ASC 848 can continue to do so until December 31, 2024. The Company adopted the guidance during the third quarter of fiscal year 2023 with an immaterial impact on its consolidated financial statements.

- changed (2023-01-27):
[0000866374-23-000007:note_history:8]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the first quarter of fiscal year 2024.
  (was, 2022-10-31, similarity 0.9483):
[0000866374-22-000074:note_history:8]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2024.

- removed (2023-01-27):
[0000866374-22-000074:note_history:9]
The first quarters for fiscal years 2023 and 2022 ended on July 1, 2022, which is comprised of 92 days in the period, and July 2, 2021, which is comprised of 93 days in the period, respectively. The second quarters for fiscal years 2023 and 2022 ended on September 30, 2022 and October 1, 2021, respectively, which are comprised of 91 days in both periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0000866374-23-000007:note_history:10]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2022 and March 31, 2022 are as follows:
  (was, 2022-10-31, similarity 0.9148):
[0000866374-22-000074:note_history:10]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 30, 2022 are as follows:

- added (2023-01-27):
[0000866374-23-000007:note_history:11]
|  | As of December 31, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | — |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.436% | 250 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 599 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 687 |  |  | 690 |  |
| 6.000% Notes due January 2028 | 396 |  |  | — |  |
| 4.875% Notes due June 2029 | 658 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 687 |  |  | 690 |  |
| Euro Term Loans | 265 |  |  | 389 |  |
| Delayed Draw Term Loan | 150 |  |  | — |  |
| 3.600% HUF Bonds due December 2031 | 264 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (19) |  |  | (18) |  |
|  | 4,016 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (494) |  |  | (949) |  |
| Non-current portion | $ | 3,522 |  |  | $ | 3,248 |  |

- changed (2023-01-27):
[0000866374-23-000007:note_history:12]
The weighted-average interest rate for the Company's long-term debt was 4.5% and 4.0% as of December 31, 2022 and March 31, 2022, respectively.
  (was, 2022-10-31, similarity 0.9805):
[0000866374-22-000074:note_history:12]
The weighted-average interest rate for the Company's long-term debt was 4.2% and 4.0% as of September 30, 2022 and March 31, 2022, respectively.

- changed (2023-01-27):
[0000866374-23-000007:note_history:13]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2022 are as follows:
  (was, 2022-10-31, similarity 0.9767):
[0000866374-22-000074:note_history:13]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 30, 2022 are as follows:

- changed (2023-01-27):
[0000866374-23-000007:note_history:14]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2023.
  (was, 2022-10-31, similarity 0.9574):
[0000866374-22-000074:note_history:14]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2023.

- added (2023-01-27):
[0000866374-23-000007:note_history:15]
Notes due January 2028

- added (2023-01-27):
[0000866374-23-000007:note_history:16]
In December 2022, the Company issued $400 million of 6.000% Notes due 2028 (the “Notes”). The Company received proceeds of approximately $396 million, net of discount, from the issuance which were used, together with cash on hand, for general corporate purposes, which includes redeeming its 2023 notes on December 20, 2022 and for working capital requirements. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet of approximately $4 million of costs in conjunction with the issuance of the Notes.

- added (2023-01-27):
[0000866374-23-000007:note_history:17]
Interest on the Notes is payable on January 15 and July 15 of each year, beginning on July 15, 2023. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.

- added (2023-01-27):
[0000866374-23-000007:note_history:18]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant

- added (2023-01-27):
[0000866374-23-000007:note_history:19]
limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries.

- added (2023-01-27):
[0000866374-23-000007:note_history:20]
In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare the entire principle of Notes, together with all accrued and unpaid interest, if any, to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of December 31, 2022, the Company was in compliance with the covenants in the indenture governing the Notes.

- added (2023-01-27):
[0000866374-23-000007:note_history:21]
Euro Term Loan due December 2023

- added (2023-01-27):
[0000866374-23-000007:note_history:22]
In December 2022, the Company borrowed €250 million (approximately $265 million as of December 31, 2022), under a 1-year term-loan agreement. The proceeds of the term loan were used to repay outstanding debt of a €250 million Euro term loan due on December 9, 2022. Borrowings under this term loan bear interest at Euro Interbank Offered Rate (EURIBOR) rate plus 0.7% per annum, which is payable in full on the last day of each 3-month interest period. The term loan is repayable upon maturity, and the borrowings have been included as bank borrowings and current portion of long-term debt under the condensed consolidated balance sheet.

- changed (2023-01-27):
[0000866374-23-000007:note_history:23]
Borrowings under the 2027 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of  (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the Term Secured Overnight Financing Rate (Term SOFR) rate plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.750% per annum, based on the Company’s credit ratings or (ii) Term SOFR (or (x) the “Alternative Currency Term Rate”, which is defined as, depending on the applicable currency at issue, either the Euro Interbank Offered Rate, Tokyo Interbank Offer Rate, or such other term rate per annum as designated with respect to such alternative currency or (y) the “Alternative Currency Daily Rate”, which is defined as, in the case of Sterling, the rate per annum equal to Sterling Overnight Index Average, and for any other alternative currency, such other term rate per annum as designated with respect to such alternative currency) plus the applicable margin for Term SOFR rate (or the Alternative Currency Term Rate) loans ranging between 1.125% and 1.750% per annum, based on the Company’s credit ratings, plus an adjustment for Term SOFR loans of 0.10% per annum and an adjustment for Sterling Overnight Index Average loans of 0.0326% per annum. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the last business day of March, June, September and December of each calendar year and the maturity date, (ii) in the case of borrowings at the Term SOFR rate (or the Alternative Currency Term Rate), on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month and the maturity date and (iii) in the case of borrowings at the Alternative Currency Daily Rate, on the last day of each calendar month and the maturity date. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2027 Credit Facility ranging from 0.125% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.125% to 1.750% per annum (based on the Company’s credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.
  (was, 2022-10-31, similarity 0.7381):
[0000866374-22-000074:note_history:23]
Borrowings under the 2027 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the Term Secured Overnight Financing Rate (Term SOFR) rate plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.750% per annum, based on the Company’s credit ratings or (ii) Term SOFR (or (x) the “Alternative Currency Term Rate”, which is defined as, depending on the applicable currency at issue, either the Euro Interbank Offered Rate, Tokyo Interbank Offer Rate, or such other term rate per annum as designated with respect to such alternative currency or (y) the “Alternative Currency Daily Rate”, which is defined as, in the case of Sterling, the rate per annum equal to Sterling Overnight Index Average, and for any other alternative currency, such other term rate per annum as designated with respect to such alternative currency) plus the applicable margin for Term SOFR rate (or the Alternative Currency Term Rate) loans ranging between 1.125% and 1.750% per annum, based on the Company’s credit ratings, plus an adjustment for Term SOFR loans of 0.10% per annum and an adjustment for Sterling Overnight Index Average loans of 0.0326% per annum. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the

- changed (2023-01-27):
[0000866374-23-000007:note_history:24]
In September 2022, the Company entered into a $450 million delayed draw term loan agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. All borrowings under the delayed draw term loan will become due on the date that is 364 days after the initial borrowing. Interest is based on either (a) a Term SOFR-based formula plus a margin of 100.0 basis points to 162.5 basis points, depending on the Company’s credit ratings, or (b) a Base Rate formula plus a margin of 0.0 basis point to 62.5 basis
  (was, 2022-10-31, similarity 0.9005):
[0000866374-22-000074:note_history:24]
In September 2022, the Company entered into a $450 million delayed draw term loan credit agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. The delayed draw term loan is available to be drawn through November 30, 2022. All borrowings under the delayed draw term loan will become due on the date that is 364 days after the initial borrowing. Interest is based on either (a) a Term SOFR-based formula plus a margin of 100.0 basis points to 162.5 basis points, depending on the Company’s credit ratings, or (b) a Base Rate formula plus a margin of 0.0 basis point to 62.5 basis points, depending on the Company's credit ratings.

- added (2023-01-27):
[0000866374-23-000007:note_history:25]
points, depending on the Company's credit ratings. On November 30, 2022, the Company borrowed $450 million under the delayed draw term loan. Of this amount, $300 million was repaid in December 2022. As of December 31, 2022, the Company had $150 million in borrowings outstanding under the delayed draw term loan agreement, which amount is due on November 29, 2023.

- added (2023-01-27):
[0000866374-23-000007:note_history:26]
The Euro term loan, the 2027 Credit Facility, and delayed draw term loan are unsecured, and contain customary restrictions on the ability of the Company and its subsidiaries to (i) incur liens, (ii) dispose of assets and (iii) make certain acquisitions of other entities. The Euro term loan also contains a restriction on the ability of the Company and its subsidiaries to change its line of business. The 2027 Credit Facility and delayed draw term loan also contain a restriction on the ability of the Company and its subsidiaries to engage in transaction with affiliates. These covenants are subject to a number of significant exceptions and limitations. The Euro term loan, the 2027 Credit Facility, and delayed draw term loan agreement also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio. As of December 31, 2022, the Company was in compliance with the covenants under the Euro term loan, the 2027 Credit Facility, and delayed draw term loan agreement.

- removed (2023-01-27):
[0000866374-22-000074:note_history:27]
|  | As of September 30, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.446% | 232 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 688 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 688 |  |  | 690 |  |
| Euro Term Loans | 337 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 232 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (16) |  |  | (18) |  |
|  | 3,997 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (916) |  |  | (949) |  |
| Non-current portion | $ | 3,081 |  |  | $ | 3,248 |  |

- removed (2023-01-27):
[0000866374-22-000074:note_history:28]
last business day of March, June, September and December of each calendar year and the maturity date, (ii) in the case of borrowings at the Term SOFR rate (or the Alternative Currency Term Rate), on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month and the maturity date and (iii) in the case of borrowings at the Alternative Currency Daily Rate, on the last day of each calendar month and the maturity date. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2027 Credit Facility ranging from 0.125% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.125% to 1.750% per annum (based on the Company’s credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

- removed (2023-01-27):
[0000866374-22-000074:note_history:29]
The 2027 Credit Facility and delayed draw term loan are unsecured, and contain customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain acquisitions of other entities, (iii) incur liens, (iv) dispose of assets, and (v) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2027 Credit Facility and delayed draw term loan agreement also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio. As of September 30, 2022, the Company had no borrowings outstanding and was in compliance with the covenants under the 2027 Credit Facility and delayed draw term loan agreement.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0000866374-23-000007:note_history:30]
|  | As of December 31, 2022 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | — |  |  | $ | — |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.436% | 250 |  |  | 250 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 599 |  |  | 590 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 687 |  |  | 650 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 396 |  |  | 397 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 658 |  |  | 621 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 687 |  |  | 644 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | 265 |  |  | 265 |  |  | 389 |  |  | 389 |  |  | Level 2 |
| Delayed Draw Term Loan | 150 |  |  | 150 |  |  | — |  |  | — |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 264 |  |  | 190 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | 79 |  |  | 79 |  |  | 84 |  |  | 84 |  |  | Level 2 |
  (was, 2022-10-31, similarity 0.7592):
[0000866374-22-000074:note_history:30]
|  | As of September 30, 2022 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 501 |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.446% | 232 |  |  | 232 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 588 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 688 |  |  | 643 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 659 |  |  | 602 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 688 |  |  | 630 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | 337 |  |  | 337 |  |  | 389 |  |  | 389 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 232 |  |  | 232 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | 79 |  |  | 79 |  |  | 84 |  |  | 84 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0000866374-23-000007:note_history:31]
Bank borrowings and long-term debt as of December 31, 2022 and March 31, 2022 are as follows:
  (was, 2022-10-31, similarity 0.8758):
[0000866374-22-000074:note_history:31]
Bank borrowings and long-term debt as of September 30, 2022 are as follows:

- added (2023-01-27):
[0000866374-23-000007:note_history:32]
|  | As of December 31, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | — |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.436% | 250 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 599 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 687 |  |  | 690 |  |
| 6.000% Notes due January 2028 | 396 |  |  | — |  |
| 4.875% Notes due June 2029 | 658 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 687 |  |  | 690 |  |
| Euro Term Loans | 265 |  |  | 389 |  |
| Delayed Draw Term Loan | 150 |  |  | — |  |
| 3.600% HUF Bonds due December 2031 | 264 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (19) |  |  | (18) |  |
|  | 4,016 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (494) |  |  | (949) |  |
| Non-current portion | $ | 3,522 |  |  | $ | 3,248 |  |

- removed (2023-01-27):
[0000866374-22-000074:note_history:33]
|  | As of September 30, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.446% | 232 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 688 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 688 |  |  | 690 |  |
| Euro Term Loans | 337 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 232 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (16) |  |  | (18) |  |
|  | 3,997 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (916) |  |  | (949) |  |
| Non-current portion | $ | 3,081 |  |  | $ | 3,248 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0000866374-23-000007:note_history:34]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2022 are as follows:
  (was, 2022-10-31, similarity 0.9767):
[0000866374-22-000074:note_history:34]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 30, 2022 are as follows:

- changed (2023-01-27):
[0000866374-23-000007:note_history:35]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2023.
  (was, 2022-10-31, similarity 0.9574):
[0000866374-22-000074:note_history:35]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2023.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0000866374-23-000007:note_history:36]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2022 and December 31, 2021, respectively. Historical information for the first three quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.
  (was, 2022-10-31, similarity 0.9147):
[0000866374-22-000074:note_history:36]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 30, 2022 and October 1, 2021, respectively. Historical information for the first and second quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.

- changed (2023-01-27):
[0000866374-23-000007:note_history:37]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,812 |  |  | $ | 3,389 |  |  | $ | 11,378 |  |  | $ | 9,887 |  |
| Over time | 217 |  |  | 192 |  |  | 646 |  |  | 563 |  |
| Total | 4,029 |  |  | 3,581 |  |  | 12,024 |  |  | 10,450 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,038 |  |  | 2,528 |  |  | 8,938 |  |  | 7,243 |  |
| Over time | 187 |  |  | 183 |  |  | 555 |  |  | 515 |  |
| Total | 3,225 |  |  | 2,711 |  |  | 9,493 |  |  | 7,758 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 8 |  |  | 42 |  |  | 41 |  |  | 63 |  |
| Over time | 508 |  |  | 296 |  |  | 1,343 |  |  | 955 |  |
| Total | 516 |  |  | 338 |  |  | 1,384 |  |  | 1,018 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,844 |  |  | 5,948 |  |  | 20,325 |  |  | 17,157 |  |
| Over time | 912 |  |  | 671 |  |  | 2,544 |  |  | 2,033 |  |
| Total | $ | 7,756 |  |  | $ | 6,619 |  |  | $ | 22,869 |  |  | $ | 19,190 |  |
  (was, 2022-10-31, similarity 0.9552):
[0000866374-22-000074:note_history:37]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,787 |  |  | $ | 3,250 |  |  | $ | 7,566 |  |  | $ | 6,498 |  |
| Over time | 217 |  |  | 187 |  |  | 429 |  |  | 371 |  |
| Total | 4,004 |  |  | 3,437 |  |  | 7,995 |  |  | 6,869 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,110 |  |  | 2,308 |  |  | 5,900 |  |  | 4,715 |  |
| Over time | 189 |  |  | 157 |  |  | 368 |  |  | 332 |  |
| Total | 3,299 |  |  | 2,465 |  |  | 6,268 |  |  | 5,047 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 10 |  |  | 12 |  |  | 33 |  |  | 21 |  |
| Over time | 463 |  |  | 327 |  |  | 835 |  |  | 659 |  |
| Total | 473 |  |  | 339 |  |  | 868 |  |  | 680 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,897 |  |  | 5,558 |  |  | 13,481 |  |  | 11,209 |  |
| Over time | 869 |  |  | 671 |  |  | 1,632 |  |  | 1,362 |  |
| Total | $ | 7,766 |  |  | $ | 6,229 |  |  | $ | 15,113 |  |  | $ | 12,571 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-01-27):
[0000866374-23-000007:note_history:38]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement
  (was, 2022-10-31, similarity 0.8895):
[0000866374-22-000074:note_history:38]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the condensed consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

- added (2023-01-27):
[0000866374-23-000007:note_history:39]
mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the condensed consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

- changed (2023-01-27):
[0000866374-23-000007:note_history:40]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).
  (was, 2022-10-31, similarity 0.8605):
[0000866374-22-000074:note_history:40]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily

- changed (2023-01-27):
[0000866374-23-000007:note_history:41]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $813 million and $704 million as of December 31, 2022 and March 31, 2022, respectively, of which $745 million and $615 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.
  (was, 2022-10-31, similarity 0.9912):
[0000866374-22-000074:note_history:41]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $792 million and $704 million as of September 30, 2022 and March 31, 2022, respectively, of which $731 million and $615 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2023-01-27):
[0000866374-23-000007:note_history:42]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2022 and December 31, 2021, respectively. Historical information for the first three quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.
  (was, 2022-10-31, similarity 0.9147):
[0000866374-22-000074:note_history:42]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 30, 2022 and October 1, 2021, respectively. Historical information for the first and second quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.

- changed (2023-01-27):
[0000866374-23-000007:note_history:43]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,812 |  |  | $ | 3,389 |  |  | $ | 11,378 |  |  | $ | 9,887 |  |
| Over time | 217 |  |  | 192 |  |  | 646 |  |  | 563 |  |
| Total | 4,029 |  |  | 3,581 |  |  | 12,024 |  |  | 10,450 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,038 |  |  | 2,528 |  |  | 8,938 |  |  | 7,243 |  |
| Over time | 187 |  |  | 183 |  |  | 555 |  |  | 515 |  |
| Total | 3,225 |  |  | 2,711 |  |  | 9,493 |  |  | 7,758 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 8 |  |  | 42 |  |  | 41 |  |  | 63 |  |
| Over time | 508 |  |  | 296 |  |  | 1,343 |  |  | 955 |  |
| Total | 516 |  |  | 338 |  |  | 1,384 |  |  | 1,018 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,844 |  |  | 5,948 |  |  | 20,325 |  |  | 17,157 |  |
| Over time | 912 |  |  | 671 |  |  | 2,544 |  |  | 2,033 |  |
| Total | $ | 7,756 |  |  | $ | 6,619 |  |  | $ | 22,869 |  |  | $ | 19,190 |  |
  (was, 2022-10-31, similarity 0.9552):
[0000866374-22-000074:note_history:43]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,787 |  |  | $ | 3,250 |  |  | $ | 7,566 |  |  | $ | 6,498 |  |
| Over time | 217 |  |  | 187 |  |  | 429 |  |  | 371 |  |
| Total | 4,004 |  |  | 3,437 |  |  | 7,995 |  |  | 6,869 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,110 |  |  | 2,308 |  |  | 5,900 |  |  | 4,715 |  |
| Over time | 189 |  |  | 157 |  |  | 368 |  |  | 332 |  |
| Total | 3,299 |  |  | 2,465 |  |  | 6,268 |  |  | 5,047 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 10 |  |  | 12 |  |  | 33 |  |  | 21 |  |
| Over time | 463 |  |  | 327 |  |  | 835 |  |  | 659 |  |
| Total | 473 |  |  | 339 |  |  | 868 |  |  | 680 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,897 |  |  | 5,558 |  |  | 13,481 |  |  | 11,209 |  |
| Over time | 869 |  |  | 671 |  |  | 1,632 |  |  | 1,362 |  |
| Total | $ | 7,766 |  |  | $ | 6,229 |  |  | $ | 15,113 |  |  | $ | 12,571 |  |

- removed (2023-01-27):
[0000866374-22-000074:note_history:44]
available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-01-27):
[0000866374-23-000007:note_history:45]
SUBSEQUENT EVENTS On January 13, 2023, the Company announced that its subsidiary, Nextracker Inc. ("Nextracker"), publicly filed a registration statement on Form S-1 with the U.S. Securities and Exchange Commission ("SEC") relating to a proposed initial public offering of shares of Nextracker's Class A common stock. The initial public offering and its timing are subject to market and other conditions and the SEC’s review process, and there can be no assurance that we will proceed with such offering or any alternative transaction.
