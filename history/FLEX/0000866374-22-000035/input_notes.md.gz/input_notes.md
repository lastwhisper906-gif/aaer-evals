# FLEX notes — 0000866374-22-000035


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000866374-22-000035:notes:1]
Proxy Statement to be delivered to shareholders in connection with the Registrant's 2022 Annual General Meeting of Shareholders


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-22-000035:notes:2]
ORGANIZATION OF THE COMPANY
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers advanced manufacturing solutions and operates one of the most trusted global supply chains, supporting the entire product lifecycle with fulfillment, after-market, and circular economy solutions for diverse industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. Beginning in the fourth quarter of fiscal year 2022, as a result of the sale of certain Series A preferred units in Nextracker LLC ("Nextracker LLC" or "Nextracker") to a third party (see note 7) and the Company's continuing evaluation to separate the Nextracker business and consistent with how the Company's chief operating decision maker ("CODM") allocates resources, assesses performance and makes strategic and operational decisions, Flex now reports Nextracker as a separate operating and reportable segment. Nextracker was previously included in the Industrial reporting unit within the Flex Reliability Solutions segment. Flex's three operating and reportable segments are:

[0000866374-22-000035:notes:3]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-22-000035:notes:4]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-22-000035:notes:5]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

[0000866374-22-000035:notes:6]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-22-000035:notes:7]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-22-000035:notes:8]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies;

[0000866374-22-000035:notes:9]
◦Health Solutions, including medical devices, medical equipment, and drug delivery; and

[0000866374-22-000035:notes:10]
◦Industrial, including capital equipment, industrial devices, and renewables and grid edge.

[0000866374-22-000035:notes:11]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

[0000866374-22-000035:notes:12]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers). The Company also provide intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-22-000035:notes:13]
SUMMARY OF ACCOUNTING POLICIES
Basis of Presentation and Principles of Consolidation

[0000866374-22-000035:notes:14]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of other charges (income), net, in the consolidated statements of operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the consolidated statements of operations. Refer to note 7 Redeemable Noncontrolling Interest for additional information.

[0000866374-22-000035:notes:15]
Certain prior period presentations and disclosures were reclassified to ensure comparability with the current period presentation. In fiscal year 2022, the Company elected to include operating income as a subtotal in the consolidated statements of operations. In addition, deferred revenue and customer working capital advances, previously included within other current liabilities, have been separately presented as deferred revenue and customer working capital advances in the current liabilities section of the consolidated balance sheets. Further, certain unbilled receivables previously presented as part of accounts receivable, net of allowance for doubtful accounts are now being presented as contract assets on the consolidated balance sheets as billing is to occur subsequent to revenue recognition and is conditional upon other than the passage of time. The Company reclassified $146.8 million of unbilled receivables from accounts receivable, net of allowance for doubtful accounts to contract assets for the period ended March 31, 2021 in order to align with the current year presentation. The Company also recast fiscal year 2021 and 2020 consolidated statements of cash flows reflecting similar reclassifications between changes in contract assets and accounts receivable, net of allowance for doubtful accounts to align with the current year presentation. The reclassifications had no effect on the previously reported results of operations or cash flows from operating activities.

[0000866374-22-000035:notes:16]
Use of Estimates

[0000866374-22-000035:notes:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic and geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the COVID-19 pandemic and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-22-000035:notes:18]
Translation of Foreign Currencies

[0000866374-22-000035:notes:19]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive income (loss), a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not

[0000866374-22-000035:notes:20]
material to the Company's consolidated results of operations for all periods presented, and have been classified as a component of other charges (income), net in the consolidated statements of operations.

[0000866374-22-000035:notes:21]
Revenue Recognition

[0000866374-22-000035:notes:22]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company recognizes estimates of this variable consideration that are not expected to result in a significant revenue reversal in the future, primarily based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 4 "Revenue" for further details.

[0000866374-22-000035:notes:23]
Concentration of Credit Risk

[0000866374-22-000035:notes:24]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, derivative instruments, and cash and cash equivalents.

[0000866374-22-000035:notes:25]
Customer Credit Risk

[0000866374-22-000035:notes:26]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-22-000035:notes:27]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2022, 2021 and 2020:

[0000866374-22-000035:notes:28]
|  | Balance atBeginningof Year |  | Charged toCosts andExpenses (1) |  | Deductions/Write-Offs |  | Balance atEnd ofYear |
|  | (In millions) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2020 | $ | 91 |  |  | $ | 24 |  |  | $ | (19) |  |  | $ | 96 |  |
| Year ended March 31, 2021 | 96 |  |  | 5 |  |  | (40) |  |  | 61 |  |
| Year ended March 31, 2022 | 61 |  |  | (3) |  |  | (2) |  |  | 56 |  |

[0000866374-22-000035:notes:29]
(1)Charges incurred and recoveries during fiscal years 2022, 2021 and 2020 are primarily for costs and expenses or bad debt recoveries related to various distressed customers.

[0000866374-22-000035:notes:30]
No customer accounted for greater than 10% of the Company's net sales in fiscal years 2022, 2021 and 2020. No customer accounted for greater than 10% of the Company's total balance of accounts receivable, net as of fiscal year ended

[0000866374-22-000035:notes:31]
March 31, 2022. One customer within the Company's FAS segment accounted for approximately 11% of the Company's total balance of accounts receivable, net as of fiscal year ended March 31, 2021. A different customer within the Company's FAS segment accounted for approximately 10% of the Company's total balances of accounts receivable, net as of fiscal year ended March 31, 2020.

[0000866374-22-000035:notes:32]
The Company's ten largest customers accounted for approximately 34%, 36% and 39%, of its net sales in fiscal years 2022, 2021 and 2020, respectively.

[0000866374-22-000035:notes:33]
Derivative Instruments

[0000866374-22-000035:notes:34]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 10.

[0000866374-22-000035:notes:35]
Cash and Cash Equivalents

[0000866374-22-000035:notes:36]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-22-000035:notes:37]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-22-000035:notes:38]
Cash and cash equivalents consisted of the following:

[0000866374-22-000035:notes:39]
|  | As of March 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Cash and bank balances | $ | 679 |  |  | $ | 1,130 |  |
| Money market funds and time deposits | 2,285 |  |  | 1,507 |  |
|  | $ | 2,964 |  |  | $ | 2,637 |  |

[0000866374-22-000035:notes:40]
Inventories

[0000866374-22-000035:notes:41]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or net realizable value write-downs, were as follows:

[0000866374-22-000035:notes:42]
|  | As of March 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Raw materials | $ | 5,290 |  |  | $ | 2,831 |  |
| Work-in-progress | 602 |  |  | 459 |  |
| Finished goods | 688 |  |  | 605 |  |
|  | $ | 6,580 |  |  | $ | 3,895 |  |

[0000866374-22-000035:notes:43]
Property and Equipment, Net

[0000866374-22-000035:notes:44]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are depreciated over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment is comprised of the following:

[0000866374-22-000035:notes:45]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2022 |  | 2021 |
|  |  |  | (In millions) |
| Machinery and equipment | 2 - 10 |  | $ | 3,540 |  |  | $ | 3,381 |  |
| Buildings | 30 |  | 1,123 |  |  | 1,103 |  |
| Leasehold improvements | Shorter of lease term or useful life of the improvement |  | 564 |  |  | 500 |  |
| Furniture, fixtures, computer equipment and software | 3 - 7 |  | 503 |  |  | 491 |  |
| Land | — |  | 113 |  |  | 113 |  |
| Construction-in-progress | — |  | 261 |  |  | 255 |  |
|  |  |  | 6,104 |  |  | 5,843 |  |
| Accumulated depreciation and amortization |  |  | (3,979) |  |  | (3,746) |  |
| Property and equipment, net |  |  | $ | 2,125 |  |  | $ | 2,097 |  |

[0000866374-22-000035:notes:46]
Total depreciation expense associated with property and equipment was approximately $408.9 million, $422.3 million and $422.4 million in fiscal years 2022, 2021 and 2020, respectively.

[0000866374-22-000035:notes:47]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-22-000035:notes:48]
Deferred Income Taxes

[0000866374-22-000035:notes:49]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-22-000035:notes:50]
Accounting for Business and Asset Acquisitions

[0000866374-22-000035:notes:51]
The Company has strategically pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0000866374-22-000035:notes:52]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-22-000035:notes:53]
Goodwill

[0000866374-22-000035:notes:54]
In accordance with accounting guidance on goodwill, the Company evaluates goodwill for impairment at the reporting unit level annually, and in certain circumstances such as a change in reporting units or whenever there are indications that goodwill might be impaired. The Company performed its annual goodwill impairment assessment on January 1, 2022 and as a result of the quantitative assessment of its goodwill, the Company determined that no impairment existed as of the date of the impairment test because the fair value of each one of its reporting units exceeded its respective carrying value. As described in note 1 and note 7, during the fourth quarter of fiscal year 2022, as a result of the sale of certain Series A preferred units in Nextracker to a third party and the Company's continuing evaluation to separate the Nextracker business and consistent with how the Company's CODM allocates resources, assesses performance and makes strategic and operational decisions, Flex now reports its financial performance based on three operating and reportable segments. With these changes, the Company also revised its reporting units, separating Nextracker from the Industrial reporting unit. Accordingly, the Company reallocated total Industrial goodwill between Nextracker and the updated Industrial reporting unit (excluding the Nextracker business) based on each reporting unit’s relative fair value as of February 1, 2022.

[0000866374-22-000035:notes:55]
Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require management to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider the Company's budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of the Company's goodwill.

[0000866374-22-000035:notes:56]
If the recorded value of the assets, including goodwill, and liabilities ("net book value") of any reporting unit exceeds its fair value, an impairment loss may be required to be recognized.

[0000866374-22-000035:notes:57]
The Company completed its acquisition of Anord Mardix in December 2021. The acquisition generated $272 million of goodwill in the Industrial reporting unit and primarily related to value placed on the acquired employee workforce, service offerings and capabilities of the acquired business. The goodwill is not deductible for income tax purposes. Refer to note 19 for more information.

[0000866374-22-000035:notes:58]
The following table summarizes the activity in the Company's goodwill during fiscal years 2022 and 2021:

[0000866374-22-000035:notes:59]
|  |  | FAS |  | FRS |  | Nextracker |  | Total |
|  |  | (In millions) |
| Balance at March 31, 2020 |  | $ | 370 |  |  | $ | 695 |  |  | $ | — |  |  | $ | 1,065 |  |
| Divestitures |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Foreign currency translation adjustments |  | 1 |  |  | 25 |  |  | — |  |  | 26 |  |
| Balance at March 31, 2021 |  | $ | 371 |  |  | $ | 719 |  |  | $ | — |  |  | $ | 1,090 |  |
| Reporting unit reallocation |  | — |  |  | (204) |  |  | 204 |  |  | — |  |
| Acquisitions |  | — |  |  | 272 |  |  | — |  |  | 272 |  |
| Foreign currency translation adjustments |  | — |  |  | (20) |  |  | — |  |  | (20) |  |
| Balance at March 31, 2022 |  | $ | 371 |  |  | $ | 767 |  |  | $ | 204 |  |  | $ | 1,342 |  |

[0000866374-22-000035:notes:60]
Other Intangible Assets

[0000866374-22-000035:notes:61]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The

[0000866374-22-000035:notes:62]
Company reviewed the carrying value of its intangible assets as of March 31, 2022 and concluded that such amounts continued to be recoverable.

[0000866374-22-000035:notes:63]
Intangible assets are comprised of customer-related intangible assets that include contractual agreements and customer relationships, and licenses and other intangible assets that are primarily comprised of licenses, patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight-line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability.

[0000866374-22-000035:notes:64]
During fiscal year 2022, the total value of intangible assets increased by $273.0 million as a result of the Company's initial estimated value of intangible assets from the Anord Mardix acquisition. This acquisition contributed an additional $147.0 million in customer-related intangible assets, and $126.0 million in licenses and other intangibles assets such as trade names and technology. Refer to note 19 for additional information.

[0000866374-22-000035:notes:65]
The components of acquired intangible assets are as follows:

[0000866374-22-000035:notes:66]
|  | As of March 31, 2022 |  | As of March 31, 2021 |
|  | Weighted-Average Remaining Useful life (in Years) |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  |  |  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | 6.8 |  | $ | 385 |  |  | $ | (157) |  |  | $ | 228 |  |  | $ | 276 |  |  | $ | (154) |  |  | $ | 122 |  |
| Licenses and other intangibles | 6.8 |  | 319 |  |  | (136) |  |  | 183 |  |  | 250 |  |  | (159) |  |  | 91 |  |
| Total |  |  | $ | 704 |  |  | $ | (293) |  |  | $ | 411 |  |  | $ | 526 |  |  | $ | (313) |  |  | $ | 213 |  |

[0000866374-22-000035:notes:67]
Total intangible asset amortization expense recognized in operations during fiscal years 2022, 2021 and 2020 was $67.9 million, $61.8 million and $64.1 million, respectively. The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2022, the gross carrying amounts of fully amortized intangible assets totaled $81.4 million. The Company also recorded $7.1 million of foreign currency translation adjustments during fiscal year 2022, as the U.S. Dollar fluctuated against foreign currencies for certain intangibles. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-22-000035:notes:68]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2023 | $ | 87 |  |
| 2024 | 72 |  |
| 2025 | 65 |  |
| 2026 | 44 |  |
| 2027 | 37 |  |
| Thereafter | 106 |  |
| Total amortization expense | $ | 411 |  |

[0000866374-22-000035:notes:69]
The Company owns or licenses various United States and foreign patents relating to a variety of technologies. For certain of the Company's proprietary processes, inventions, and works of authorship, the Company relies on trade secret or copyright protection. The Company also maintains trademark rights (including registrations) for the Company's corporate name and several other trademarks and service marks that the Company uses in the Company's business in the United States and other countries throughout the world. The Company has implemented appropriate policies and procedures (including both technological means and training programs for the Company's employees) to identify and protect the Company's intellectual property, as well as that of the Company's customers and suppliers. As of March 31, 2022 and 2021, the carrying value of the Company's intellectual property was not material.

[0000866374-22-000035:notes:70]
Derivative Instruments and Hedging Activities

[0000866374-22-000035:notes:71]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Cash receipts and cash payments related to derivative instruments are recorded in the same category as the cash flows from the items being hedged on the consolidated statements of cash flows. Additional information is included in note 10.

[0000866374-22-000035:notes:72]
Investments

[0000866374-22-000035:notes:73]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other assets. These privately held companies range from startups to more mature companies with established revenue streams and business models. As of March 31, 2022, and March 31, 2021, the Company's investments in non-consolidated companies totaled $131.3 million and $102.8 million, respectively.

[0000866374-22-000035:notes:74]
During fiscal year 2022, the Company recognized $61.0 million of equity in earnings, associated with its equity method investments, in other charges (income), net on the consolidated statement of operations. Additional information is included in note 17.

[0000866374-22-000035:notes:75]
During fiscal year 2021, the Company recognized $83.5 million of equity in earnings, associated with its equity method investments in other charges (income), net on the consolidated statement of operations. Also during fiscal year 2021, in connection with the Company’s ongoing assessment of recoverability of its investment portfolio, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized a $36.5 million total impairment in other charges (income), net on the consolidated statement of operations primarily related to the Company's investment in Bright Machines.

[0000866374-22-000035:notes:76]
Non-consolidated investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage generally equal to or greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. Cost method is used for investments where the Company does not have the ability to significantly influence the operating decisions of the investee, or if the Company’s investment is in securities other than common stock or in-substance common stock.

[0000866374-22-000035:notes:77]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy, and require management to make various judgmental assumptions primarily about comparable company multiples and discounted cash flow projections. Some of the inherent estimates and assumptions used in determining the fair value of the investments are outside the control of management. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the investments, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of investments.

[0000866374-22-000035:notes:78]
For investments accounted for under the cost method that do not have readily determinable fair values, the Company measures them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-22-000035:notes:79]
Customer Working Capital Advances

[0000866374-22-000035:notes:80]
Customer working capital advances were $1.4 billion and $471.5 million, as of March 31, 2022 and 2021, respectively. Customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.

[0000866374-22-000035:notes:81]
Other Current Liabilities

[0000866374-22-000035:notes:82]
Other current liabilities include customer-related accruals of $227.4 million and $242.0 million as of March 31, 2022 and 2021, respectively.

[0000866374-22-000035:notes:83]
Leases

[0000866374-22-000035:notes:84]
The Company is a lessee with several non-cancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. The Company determines if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the Company has the right to control the use of the identified asset. Beginning with the adoption of ASC 842 on April 1, 2019, the Company elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether then-existing or expired contracts contain a lease, (2) lease classification for then-existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. The Company recognizes a right-of-use (“ROU”) asset and a lease liability at the lease commencement date for the Company's operating leases. For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at the lease commencement date. The Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and non-lease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for the Company's leases, the Company uses the Company's estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company's estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company's leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-22-000035:notes:85]
The adoption of ASC 842 had a material impact to the Company’s consolidated balance sheet, but did not materially impact the consolidated statement of operations or consolidated statement of cash flows. The most significant changes to the consolidated balance sheet relate to the recognition of ROU assets and lease liabilities for operating leases. The Company’s accounting for finance leases remains substantially unchanged and the balances are not material for any periods presented.

[0000866374-22-000035:notes:86]
As of March 31, 2022 and 2021, current operating lease liabilities were $132.4 million and $127.6 million, respectively, which are included in other current liabilities on the consolidated balance sheets.

[0000866374-22-000035:notes:87]
Restructuring Charges

[0000866374-22-000035:notes:88]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and rationalize administrative functions. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-22-000035:notes:89]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed restructuring plans. See note 16 for additional information regarding restructuring charges.

[0000866374-22-000035:notes:90]
Recently Adopted Accounting Pronouncements

[0000866374-22-000035:notes:91]
In August 2020, the FASB issued ASU 2020-06 "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging - Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity", which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments and contracts on an entity’s own equity. The guidance is effective  for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company early adopted the guidance during the fourth quarter of fiscal year 2022 using the modified retrospective approach with an immaterial impact to its consolidated financial statements.

[0000866374-22-000035:notes:92]
In October 2021, the FASB issued ASU 2021-08 "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities From Contracts With Customers", which requires an acquirer to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with FASB Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers. The guidance is effective prospectively for the Company beginning in the first quarter of fiscal year 2024 with early adoption permitted. The Company early adopted the guidance during the third quarter of fiscal year 2022 with an immaterial impact to its consolidated financial statements.

[0000866374-22-000035:notes:93]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.

[0000866374-22-000035:notes:94]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.

[0000866374-22-000035:notes:95]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.

[0000866374-22-000035:notes:96]
Recently Issued Accounting Pronouncements

[0000866374-22-000035:notes:97]
In November 2021, the FASB issued ASU 2021-10 "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance," which aims to provide increased transparency by requiring business entities to disclose information about certain types of government assistance they receive in the notes to the annual financial statements. The guidance is effective for the Company beginning in fiscal year 2023 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in fiscal year 2023.

[0000866374-22-000035:notes:98]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2023.


## us-gaap:DerivativesPolicyTextBlock

[0000866374-22-000035:notes:99]
Derivative InstrumentsThe amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions.Derivative Instruments and Hedging ActivitiesAll derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-22-000035:notes:100]
LEASESThe Company has several commitments under operating leases for warehouses, buildings, and equipment. The Company also has a minimal number of finance leases with an immaterial impact on its consolidated financial statements. Leases have lease terms ranging from 1 year to 18 years.
The components of lease cost recognized under ASC 842 were as follow (in millions):

[0000866374-22-000035:notes:101]
| Lease cost | Fiscal Year Ended |
|  | March 31, 2022 |  | March 31, 2021 |
| Operating lease cost | $ | 156 |  |  | $ | 152 |  |

[0000866374-22-000035:notes:102]
Amounts reported in the consolidated balance sheet as of the periods ended March 31, 2022 and 2021 were (in millions, except weighted average lease term and discount rate):

[0000866374-22-000035:notes:103]
|  | As of March 31, 2022 |  | As of March 31, 2021 |
| Operating Leases: |  |  |  |
| Operating lease right of use assets | $ | 637 |  | $ | 642 |
| Operating lease liabilities | 683 |  | 690 |
| Weighted-average remaining lease term (In years) |  |  |  |
| Operating leases | 7.1 |  | 7.5 |
| Weighted-average discount rate |  |  |  |
| Operating leases | 3.6 | % |  | 3.9 | % |

[0000866374-22-000035:notes:104]
Other information related to leases was as follow (in millions):

[0000866374-22-000035:notes:105]
|  | Fiscal Year Ended |
|  | March 31, 2022 |  | March 31, 2021 |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 158 |  |  | $ | 152 |  |
| Right‑of‑use assets obtained in exchange for lease liabilities |  |  |  |
| Operating Lease | $ | 78 |  |  | $ | 159 |  |

[0000866374-22-000035:notes:106]
Future lease payments under non-cancellable leases as of March 31, 2022 are as follows (in millions):

[0000866374-22-000035:notes:107]
| Fiscal Year Ended March 31, | Operating Leases |
| 2023 | $ | 151 |  |
| 2024 | 128 |  |
| 2025 | 107 |  |
| 2026 | 84 |  |
| 2027 | 72 |  |
| Thereafter | 229 |  |
| Total undiscounted lease payments | 771 |  |
| Less: imputed interest | 88 |  |
| Total lease liabilities | $ | 683 |  |

[0000866374-22-000035:notes:108]
Total rent expense amounted to $180.3 million, $179.8 million, and $186.9 million in fiscal years 2022, 2021 and 2020, respectively.


## us-gaap:LeaseCostTableTextBlock

[0000866374-22-000035:notes:109]
The components of lease cost recognized under ASC 842 were as follow (in millions):


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-22-000035:notes:110]
REVENUE
Revenue Recognition

[0000866374-22-000035:notes:111]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract

[0000866374-22-000035:notes:112]
with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-22-000035:notes:113]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract are transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-22-000035:notes:114]
Customer Contracts and Related Obligations

[0000866374-22-000035:notes:115]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-22-000035:notes:116]
Performance Obligations

[0000866374-22-000035:notes:117]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

[0000866374-22-000035:notes:118]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-22-000035:notes:119]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-22-000035:notes:120]
Contract Balances

[0000866374-22-000035:notes:121]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to receivables when rights to payment become unconditional.

[0000866374-22-000035:notes:122]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $704.3 million and $435.4 million as of March 31, 2022 and 2021, respectively, of which $615.5 million and $376.5 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-22-000035:notes:123]
Disaggregation of Revenue

[0000866374-22-000035:notes:124]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time for the fiscal years ended March 31, 2022, 2021 and 2020:

[0000866374-22-000035:notes:125]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |
| Point in time | $ | 13,288 |  |  | $ | 12,058 |  |  | $ | 11,581 |  |
| Over time | 739 |  |  | 1,435 |  |  | 2,472 |  |
| Total | 14,027 |  |  | 13,493 |  |  | 14,053 |  |
| FRS |  |  |  |  |  |
| Point in time | 9,904 |  |  | 7,667 |  |  | 6,518 |  |
| Over time | 699 |  |  | 1,828 |  |  | 2,535 |  |
| Total | 10,603 |  |  | 9,495 |  |  | 9,053 |  |
| Nextracker |  |  |  |  |  |
| Point in time | 128 |  |  | 66 |  |  | 419 |  |
| Over time | 1,330 |  |  | 1,129 |  |  | 752 |  |
| Total | 1,458 |  |  | 1,195 |  |  | 1,171 |  |
| Intersegment eliminations |  |  |  |  |  |
| Point in time | (47) |  |  | (59) |  |  | (67) |  |
| Over time | — |  |  | — |  |  | — |  |
| Total | (47) |  |  | (59) |  |  | (67) |  |
| Flex |  |  |  |  |  |
| Point in time | 23,273 |  |  | 19,732 |  |  | 18,451 |  |
| Over time | 2,768 |  |  | 4,392 |  |  | 5,759 |  |
| Total | $ | 26,041 |  |  | $ | 24,124 |  |  | $ | 24,210 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-22-000035:notes:126]
SHARE-BASED COMPENSATION
Equity Compensation Plans

[0000866374-22-000035:notes:127]
The Company's primary plan used for granting equity compensation awards is the Company's 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-22-000035:notes:128]
Share-Based Compensation Expense

[0000866374-22-000035:notes:129]
The following table summarizes the Company's share-based compensation expense for all equity incentive plans:

[0000866374-22-000035:notes:130]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Cost of sales | $ | 24 |  |  | $ | 20 |  |  | $ | 15 |  |
| Selling, general and administrative expenses | 67 |  |  | 59 |  |  | 56 |  |
| Total share-based compensation expense | $ | 91 |  |  | $ | 79 |  |  | $ | 71 |  |

[0000866374-22-000035:notes:131]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as operating cash flows. During fiscal years 2022, 2021 and 2020, the Company did not recognize any excess tax benefits as an operating cash inflow.

[0000866374-22-000035:notes:132]
As of March 31, 2022, the Company had approximately 19.4 million shares available for grant under the 2017 Plan. The Company no longer issues options to employees under all plans. The number of outstanding and exercisable options are immaterial and the compensation cost related to options granted to employees under all plans has been fully recognized as of March 31, 2022.

[0000866374-22-000035:notes:133]
The Company also grants restricted share unit ("RSU") awards under its 2017 Plan. RSU awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. RSU awards generally vest in installments over a two to four-year period and unvested RSU awards are generally forfeited upon termination of employment.

[0000866374-22-000035:notes:134]
Vesting for certain RSU awards is contingent upon both service and market conditions or both service and performance conditions.

[0000866374-22-000035:notes:135]
As of March 31, 2022, the total unrecognized compensation cost related to unvested RSU awards under all plans was approximately $148.4 million. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.0 years. Approximately $16.0 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain market conditions. Approximately $5.5 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain performance conditions.

[0000866374-22-000035:notes:136]
Determining Fair Value - RSU awards

[0000866374-22-000035:notes:137]
Valuation and Amortization Method—The fair market value of RSU awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-22-000035:notes:138]
Determining Fair Value - RSU awards with service and market conditions

[0000866374-22-000035:notes:139]
Valuation and Amortization Method—The Company estimates the fair value of RSU awards granted under the 2017 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-22-000035:notes:140]
Expected volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the RSU awards granted. The service period is three years for those RSU awards granted in fiscal years 2022, 2021, and 2020.

[0000866374-22-000035:notes:141]
Average peer volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of Flex's peer companies for the RSU awards granted in fiscal years 2022, and volatility used in a Monte Carlo simulation is derived from the historical volatility of the Standard and Poor's ("S&P") 500 index for the RSU awards granted in fiscal years 2021 and 2020.

[0000866374-22-000035:notes:142]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to Flex's peer companies for the RSU awards granted in fiscal years 2022, and correlation coefficients were used to model the movement of Flex's stock price relative to the S&P 500 index for the RSU awards granted in fiscal years 2021 and 2020.

[0000866374-22-000035:notes:143]
Expected Dividend —The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-22-000035:notes:144]
Risk-Free Interest Rate assumptions—The Company bases the risk-free interest rate used in the Monte Carlo simulation on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the RSU awards.

[0000866374-22-000035:notes:145]
The fair value of the Company's RSU awards under the 2017 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2022, 2021, and 2020 was estimated using the following weighted-average assumptions:

[0000866374-22-000035:notes:146]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Expected volatility | 54.6 | % |  | 52.8 | % |  | 38.8 | % |
| Average peer volatility | 39.8 | % |  | 35.9 | % |  | 24.9 | % |
| Average peer correlation | 0.4 |  |  | 0.7 |  |  | 0.5 |  |
| Expected dividends | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 0.3 | % |  | 0.3 | % |  | 1.8 | % |

[0000866374-22-000035:notes:147]
Share-Based Awards Activity

[0000866374-22-000035:notes:148]
Option activity for all plans is immaterial for all periods presented.

[0000866374-22-000035:notes:149]
Cash received from option exercises under all plans, which was reflected within other financing activities in the consolidated statement of cash flows, was immaterial for fiscal years 2022, 2021, and 2020.

[0000866374-22-000035:notes:150]
The following table summarizes the Company's RSU award activity under all plans ("Price" reflects the weighted-average grant-date fair value):

[0000866374-22-000035:notes:151]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested RSU awards outstanding, beginning of fiscal year | 17,308,625 |  |  | $ | 11.14 |  |  | 16,050,640 |  |  | $ | 11.87 |  |  | 14,903,886 |  |  | $ | 13.76 |  |
| Granted | 7,276,643 |  |  | 18.48 |  |  | 10,982,109 |  |  | 11.04 |  |  | 8,259,272 |  |  | 9.81 |  |
| Vested | (5,933,605) |  |  | 10.87 |  |  | (5,520,005) |  |  | 11.64 |  |  | (4,222,524) |  |  | 13.33 |  |
| Forfeited | (1,632,104) |  |  | 12.42 |  |  | (4,204,119) |  |  | 11.92 |  |  | (2,889,994) |  |  | 12.89 |  |
| Unvested RSU awards outstanding, end of fiscal year | 17,019,559 |  |  | $ | 14.13 |  |  | 17,308,625 |  |  | $ | 11.14 |  |  | 16,050,640 |  |  | $ | 11.87 |  |

[0000866374-22-000035:notes:152]
Of the 7.3 million unvested RSU awards granted in fiscal year 2022, approximately 6.4 million are plain-vanilla unvested RSU awards with no performance or market conditions with an average grant date price of $18.02 per share. Further, approximately 0.4 million of these unvested RSU awards granted in fiscal year 2022 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions, with an average grant date fair value estimated to be $25.86 per award calculated using a Monte Carlo simulation. Vesting information for these shares is further detailed in the table below.

[0000866374-22-000035:notes:153]
Of the 17.0 million unvested RSU awards outstanding under all plans as of the fiscal year ended March 31, 2022, approximately 2.9 million unvested RSU awards represent the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-22-000035:notes:154]
|  |  | Targetednumber ofawards as ofMarch 31, 2022(in shares) |  |  |  |  |  | Range of sharesthat may be issued (1) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment dates |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2022 |  | 409,526 |  |  | $ | 25.86 |  |  |  |  | — |  |  | 819,052 |  |  | June 2024 |
| Fiscal 2021 |  | 1,243,848 |  |  | 15.03 |  |  |  |  | — |  |  | 2,487,696 |  |  | June 2023 |
| Fiscal 2020 |  | 1,200,639 |  |  | 11.92 |  |  |  |  | — |  |  | 2,401,278 |  |  | June 2022 |
| Totals |  | 2,854,013 |  |  |  |  |  |  |  |  | 5,708,026 |  |  |  |

[0000866374-22-000035:notes:155]
(1)    Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against Flex's peer companies for RSU awards granted in fiscal year 2022 and based on measurement of Flex's total shareholder return against the Standard and Poor's ("S&P") 500 Composite Index for RSU awards granted in fiscal years 2021 and 2020.

[0000866374-22-000035:notes:156]
The Company will continue to recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2022, no shares vested in connection with the RSU awards with market conditions granted in fiscal year 2019.

[0000866374-22-000035:notes:157]
Approximately 0.4 million of these unvested RSU awards granted in fiscal year 2022 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, with an average grant date price of $18.24 per share. Vesting information for these shares is further detailed in the table below.

[0000866374-22-000035:notes:158]
Of the 17.0 million unvested RSU awards outstanding under all plans as of the fiscal year ended March 31, 2022, approximately 0.4 million unvested RSU awards represent the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain performance conditions summarized as follows:

[0000866374-22-000035:notes:159]
|  |  | Targetednumber ofawards as ofMarch 31, 2022(in shares) |  |  |  |  |  | Range of sharesthat may be issued (1) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment date |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2022 |  | 409,524 |  |  | $ | 18.24 |  |  |  |  | — |  |  | 819,048 |  |  | Mar 2024 |

[0000866374-22-000035:notes:160]
(1)    Vesting ranges from zero to 200% based on performance of Flex's average earnings per share growth.

[0000866374-22-000035:notes:161]
The total intrinsic value of RSU awards vested under all the Company's plans was $108.1 million, $68.6 million and $41.7 million during fiscal years 2022, 2021 and 2020, respectively, based on the closing price of the Company's ordinary shares on the date vested.
In April 2022, Nextracker granted 11.2 million equity-based compensation awards to its employees under the 2022 Nextracker LLC Equity Incentive Plan (the “2022 Nextracker Plan”). Vesting for the awards granted under the 2022 Nextracker Plan is contingent upon continued employee service and certain performance conditions, including a liquidity event such as the occurrence of an initial public offering or the sale of Nextracker.


## us-gaap:EarningsPerShareTextBlock

[0000866374-22-000035:notes:162]
EARNINGS PER SHARE
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-22-000035:notes:163]
Diluted earnings per share reflects the potential dilution from stock options and RSU awards. The potential dilution from stock options exercisable into ordinary share equivalents and restricted share unit awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-22-000035:notes:164]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income per share:

[0000866374-22-000035:notes:165]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions, except per share amounts) |
| Basic earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |
| Net income | $ | 940 |  |  | $ | 613 |  |  | $ | 88 |  |
| Net income attributable to redeemable noncontrolling interest | 4 |  |  | — |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 936 |  |  | $ | 613 |  |  | $ | 88 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 476 |  |  | 499 |  |  | 509 |  |
| Basic earnings per share | $ | 1.97 |  |  | $ | 1.23 |  |  | $ | 0.17 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |
| Net income | $ | 940 |  |  | $ | 613 |  |  | $ | 88 |  |
| Net income attributable to redeemable noncontrolling interest | 4 |  |  | — |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 936 |  |  | $ | 613 |  |  | $ | 88 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 476 |  |  | 499 |  |  | 509 |  |
| Weighted-average ordinary share equivalents from stock options and RSU awards (1) | 7 |  |  | 7 |  |  | 3 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 483 |  |  | 506 |  |  | 512 |  |
| Diluted earnings per share | $ | 1.94 |  |  | $ | 1.21 |  |  | $ | 0.17 |  |

[0000866374-22-000035:notes:166]
_________________________________________________________________________
(1)An immaterial amount of options to purchase ordinary shares and RSU awards during fiscal years 2022, 2021, and 2020, respectively were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000866374-22-000035:notes:167]
REDEEMABLE NONCONTROLLING INTEREST
On February 1, 2022, the Company sold redeemable preferred units (“Series A Preferred Units”), representing a 16.67% interest in its subsidiary Nextracker LLC ("Nextracker"), to TPG Rise Flash, L.P. ("TPG Rise") and received proceeds of $487.5 million, net of $12.5 million in transaction costs. Because the Series A Preferred Units are redeemable upon the occurrence of conditions not solely within the control of the Company, the Company classified the redeemable noncontrolling interest as temporary equity on its consolidated balance sheets.

[0000866374-22-000035:notes:168]
The Series A Preferred Units have a dividend rate of 5% per annum, payable semi-annually, up to 100% of which may be paid by the issuance of additional Series A Preferred Units  ("payable-in-kind") during the first two years following the closing of the sale to TPG Rise, and 50% of which may be payable-in-kind thereafter. The Series A Preferred Units will vote together with the common units of Nextracker as a single class in all matters that are subject to a vote by common unitholders. The Series A Preferred Units provide TPG Rise the right to designate two members of the Board of Nextracker; if, however, TPG Rise owns Series A Preferred Units or common units with a fully diluted ownership percentage of less than 10% but more than 5%, the number of Board members that TPG Rise will be entitled to designate will be reduced to one. So long as at least 51% of the Series A Preferred Units remain outstanding, the consent of the holders of the Series A Preferred Units must be obtained prior to taking certain actions regarding Nextracker.

[0000866374-22-000035:notes:169]
The Series A Preferred Units will be automatically converted into common units of Nextracker upon a qualified initial public offering (a “Qualified Public Offering”) and TPG Rise may elect to convert the Series A Preferred Units into common units at any time after March 31, 2023. Subject to certain exceptions, for any mandatory or optional conversion, the conversion ratio for each Series A Preferred Unit will be based on a deemed value of Nextracker equal to the lesser of $3.00 billion and the implied equity valuation of Nextracker determined by the underwriters engaged in connection with a Qualified Public Offering. If a Qualified Public Offering occurs by March 31, 2023 with an implied equity valuation greater than $3.75 billion, then the conversion ratio will be adjusted upwards based on a deemed value of Nextracker equal to $3.20 billion. If a Qualified Public Offering occurs after March 31, 2023 with an implied equity valuation between $2.70 billion and $3.00 billion, then the conversion ratio will be based on a deemed value of Nextracker equal to $3.00 billion. If a Qualified Public Offering occurs

[0000866374-22-000035:notes:170]
after March 31, 2023 with an implied equity valuation of less than $2.70 billion, then the conversion ratio will be based on a deemed value equal to the implied equity valuation of Nextracker in the Qualified Public Offering divided by 90%. If TPG Rise elects to convert the Series A Preferred Units prior to an initial public offering, the conversion ratio shall be based on a deemed value of Nextracker equal to $3.00 billion.

[0000866374-22-000035:notes:171]
At TPG Rise’s election, the Company is required to repurchase all of the outstanding Series A Preferred Units at their liquidation preference, which shall include all contributed but unreturned capital plus accrued but unpaid dividends, at the earlier of certain change in control events and February 2, 2028. Additionally, if Nextracker has not completed a Qualified Public Offering prior to February 2, 2027, then TPG Rise may cause the Company to repurchase all of the outstanding Series A Preferred Units at their fair market value.

[0000866374-22-000035:notes:172]
In connection with any voluntary or involuntary liquidation, dissolution, or winding up of Nextracker, each outstanding Series A Preferred Unit will be entitled to receive cash equal to the liquidation preference prior to distributions made to any other units.

[0000866374-22-000035:notes:173]
The Company has determined that a Qualified Public Offering is likely and that the change in control is not probable as of March 31, 2022 and as such, it is not probable that the noncontrolling interest will become redeemable as of March 31, 2022.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-22-000035:notes:174]
SUPPLEMENTAL CASH FLOW DISCLOSURESThe following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-22-000035:notes:175]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 169 |  |  | $ | 147 |  |  | $ | 172 |  |
| Income taxes | 122 |  |  | 105 |  |  | 99 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 126 |  |  | $ | 102 |  |  | $ | 104 |  |
| Finance lease for Bright Machines assets | — |  |  | 4 |  |  | 23 |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-22-000035:notes:176]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt are as follows:

[0000866374-22-000035:notes:177]
|  | As of March 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.43% | 273 |  |  | 305 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 690 |  |  | 694 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 661 |  |
| 4.875% Notes due May 2030 | 690 |  |  | 694 |  |
| Euro Term Loans | 389 |  |  | 168 |  |
| 3.600% HUF Bonds due December 2031 | 301 |  |  | — |  |
| India Facilities | 84 |  |  | 133 |  |
| Other | 31 |  |  | 51 |  |
| Debt issuance costs | (18) |  |  | (21) |  |
|  | 4,197 |  |  | 3,783 |  |
| Current portion, net of debt issuance costs | (949) |  |  | (268) |  |
| Non-current portion | $ | 3,248 |  |  | $ | 3,515 |  |

[0000866374-22-000035:notes:178]
The weighted-average interest rates for the Company's long-term debt were 4.0% and 4.3% as of March 31, 2022 and 2021, respectively.

[0000866374-22-000035:notes:179]
Scheduled repayments of the Company's bank borrowings and long-term debt are as follows:

[0000866374-22-000035:notes:180]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2023 | $ | 950 |  |
| 2024 | 53 |  |
| 2025 | 273 |  |
| 2026 | 1,288 |  |
| 2027 | — |  |
| Thereafter | 1,651 |  |
| Total | $ | 4,215 |  |

[0000866374-22-000035:notes:181]
HUF Bonds due December 2031

[0000866374-22-000035:notes:182]
In December 2021, the Company issued HUF 100 billion (approximately $301.4 million as of March 31, 2022) in aggregate principal amount of bonds under the National Bank of Hungary’s Bond Funding for Growth Scheme. The bonds mature in December 2031 and amortize in an amount equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity. The outstanding principal amount of the bonds bear interest at 3.60% per annum. Interest is due and payable annually in arrears. The proceeds of the bonds were used for general corporate purposes.

[0000866374-22-000035:notes:183]
The bonds are unsecured and unsubordinated obligations of the Company and rank equally with all of the Company’s other existing and future unsecured and unsubordinated obligations. The bonds contain a customary negative pledge covenant restricting the ability of the Company to incur liens to secure indebtedness without ratably and equally securing the bonds. This covenant is subject to a number of exceptions and limitations. The bonds also provide for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company. Except in limited circumstances resulting from adverse changes in applicable tax laws, the bonds are not voluntarily redeemable. The bonds are listed for

[0000866374-22-000035:notes:184]
trading on the XBond multilateral trading facility operated by the Budapest Stock Exchange. As of March 31, 2022, the Company was in compliance with the covenants under the HUF bond agreement.

[0000866374-22-000035:notes:185]
The 2026 Credit Facility

[0000866374-22-000035:notes:186]
In January 2021, the Company entered into a new $2.0 billion credit agreement which matures in January 2026 (the "2026 Credit Facility") and consists of a $2.0 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2026 Credit Facility replaced the previous $1.75 billion revolving credit facility, which was due to mature in June 2022 (the "2022 Credit Facility"). The Company determined that effectively increasing the borrowing capacity of the former revolving arrangement qualified as a debt modification and consequently all unamortized debt issuance costs related to the 2022 Credit Facility remain capitalized and are being amortized over the term of the 2026 Credit Facility.

[0000866374-22-000035:notes:187]
Borrowings under the 2026 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.250% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.250% and 1.875% per annum, based on the Company’s credit ratings. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the last business day of March, June, September and December of each calendar year and (ii) in the case of borrowings at the LIBOR rate, on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2026 Credit Facility ranging from 0.15% to 0.30% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.250% to 1.875% per annum (based on the Company’s credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

[0000866374-22-000035:notes:188]
Under the 2026 Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

[0000866374-22-000035:notes:189]
The 2026 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain acquisitions of other entities, (iii) incur liens, (iv) dispose of assets and (v) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2026 Credit Facility also requires that the Company maintains a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization) and a minimum interest coverage ratio. As of March 31, 2022, the Company was in compliance with the covenants under the 2026 Credit Facility agreement.

[0000866374-22-000035:notes:190]
Notes

[0000866374-22-000035:notes:191]
Notes due February 2023

[0000866374-22-000035:notes:192]
In February 2013, the Company issued $500 million of 5.000% notes due February 15, 2023 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act. In July 2013, the Company exchanged these notes for new notes (the “2023 Notes”) with substantially similar terms and completed the registration of the 2023 Notes with the Securities and Exchange Commission.

[0000866374-22-000035:notes:193]
Notes due June 2025

[0000866374-22-000035:notes:194]
In June 2015, the Company issued $600 million of 4.750% notes due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at 99.213% of face value, and an effective yield of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which was used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes (the “2025 Notes”) with substantially similar terms and completed the registration of the 2025 Notes with the Securities and Exchange Commission.

[0000866374-22-000035:notes:195]
Notes due February 2026 and May 2030

[0000866374-22-000035:notes:196]
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026 (the "Existing 2026 Notes"), at 99.617% of face value and $325 million aggregate principal amount of 4.875% Notes due May 2030 (the "Existing 2030 Notes" and, together with the Existing 2026 Notes, the "Existing Notes"), at 99.562% of face value. In August 2020, as a further issuance of the Existing Notes, the Company issued under the same terms (other than the initial interest accrual date and first interest payment date for the additional 2026 Notes, and the initial offering price and the issue date for the additional 2026 and 2030 Notes), an additional $250 million of 3.750% Notes due February 2026 (together with the Existing 2026 Notes, the "2026 Notes"), at 109.294% of face value, and $325 million of 4.875% Notes due May 2030 (together with the Existing 2030 Notes, the "2030 Notes"), at 114.863% of face value. Immediately after the issuance of the additional notes issued in August 2020, the Company has $675 million aggregate principal amount of 3.750% 2026 Notes outstanding and $650 million aggregate principal amount of 4.875% 2030 Notes outstanding. The Company received in aggregate, proceeds of approximately $1.4 billion, net of discounts and after premiums, from the issuances, which were used for working capital and other general corporate purposes.

[0000866374-22-000035:notes:197]
Notes due June 2029

[0000866374-22-000035:notes:198]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “Existing 2029 Notes”), at 99.607% of face value. In November 2019, as a further issuance of the Existing 2029 Notes, the Company issued under the same terms, an additional $200 million of 4.875% Notes due June 15, 2029 (together with the "Existing 2029 Notes", the "2029 Notes"), at 107.289% of face value. Immediately after the issuance of the notes issued in November 2019, the Company has $650 million aggregate principal amount of 4.875% 2029 Notes outstanding. The Company received in aggregate, proceeds of approximately $662.8 million, net of discount and premium, from the issuances which were used, together with available cash, to refinance certain other outstanding debt.

[0000866374-22-000035:notes:199]
Interest on the 2023 Notes, 2025 Notes, 2026 Notes, 2029 Notes, 2030 Notes (collectively the “Notes”) is payable semi-annually. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company’s other existing and future senior and unsecured debt obligations.

[0000866374-22-000035:notes:200]
At any time up to three months prior to the maturity date of the respective Notes, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the indentures of the respective Notes), the Company must offer to repurchase the respective Notes at a repurchase price equal to 101% of the principal amount of these Notes, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0000866374-22-000035:notes:201]
The indentures governing the Notes contain covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indentures. The indentures also provide for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other events of default under the indentures occur or are continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes.  As of March 31, 2022, the Company was in compliance with the covenants in the indentures governing the Notes.

[0000866374-22-000035:notes:202]
Term Loan due April 2024

[0000866374-22-000035:notes:203]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month TIBOR plus 0.43%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, was used to fund general operations and refinance certain other outstanding debts.

[0000866374-22-000035:notes:204]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintains a

[0000866374-22-000035:notes:205]
maximum ratio of total indebtedness to EBITDA, and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2022, the Company was in compliance with the covenants under this term loan agreement.

[0000866374-22-000035:notes:206]
Other Borrowings

[0000866374-22-000035:notes:207]
In December 2021, the Company borrowed €350 million (approximately $388.6 million as of March 31, 2022), under a 1-year term-loan agreement. Of this amount, €250 million is due December 9, 2022 and €100 million is due December 30, 2022. The proceeds of the term loan was used to refinance certain other outstanding debt and for other general corporate purposes. Borrowings under this term loan bear interest at (0.18)% per annum, which is payable in full at maturity. The term loan is repayable upon maturity, and the borrowings have been included as bank borrowings and current portion of long-term debt under the consolidated balance sheet.

[0000866374-22-000035:notes:208]
In July 2018, a subsidiary of the Company entered into a $200 million term loan facility (the "India Facility"), under which there was $84.1 million in borrowings outstanding as of March 31, 2022. The India Facility was used to fund capital expenditures to support the Company's expansion plans for India. The availability period during which drawdowns can be made was from the date of the agreement to and including January 2020. The maximum maturity of each drawdown will be 5 years from the funded Capex shipment date. As a result, the longest maturity date of any drawdown under the India Facility is June 2023. Borrowings under this term loan bear interest at LIBOR plus a margin of 0.90% to 1.15% depending on loan duration.

[0000866374-22-000035:notes:209]
In January 2017, the Company borrowed €100 million, under a 5-year, term-loan agreement due January 2, 2022. Borrowings under this term loan bear interest at EURIBOR minus 0.1% plus the applicable margin ranging between 0.40% and 1.35%, based on the Company's credit ratings. During the fourth quarter of fiscal year 2021, the Company repaid the loan and immediately borrowed the same amount at a fixed interest rate of (0.16)%, while maintaining the January 2, 2022 maturity date. As of March 31, 2022, the borrowings under this term-loan have been paid in full.

[0000866374-22-000035:notes:210]
These term loans are unsecured. As of March 31, 2022, the Company was in compliance with the covenants under these term loan agreements.

[0000866374-22-000035:notes:211]
As of March 31, 2022, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities in the amount of $325 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2022 and 2021. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-22-000035:notes:212]
FINANCIAL INSTRUMENTS
Foreign Currency Contracts

[0000866374-22-000035:notes:213]
The Company transacts business in various foreign countries and is therefore exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency of the operating entity. The Company enters into short-term and long-term foreign currency derivative contracts, including forward, swap, and option contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable, accounts payable, debt, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-22-000035:notes:214]
As of March 31, 2022, the aggregate notional amount of the Company's outstanding foreign currency derivative contracts was $11.6 billion as summarized below:

[0000866374-22-000035:notes:215]
|  | Foreign CurrencyAmount |  | Notional ContractValue in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| CNY | 3,177 |  |  | — |  |  | $ | 499 |  |  | $ | — |  |
| HUF | 140,860 |  |  | — |  |  | 435 |  |  | — |  |
| JPY | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN | 7,075 |  |  | — |  |  | 354 |  |  |  |
| MYR | 483 |  |  | 86 |  |  | 114 |  |  | 20 |  |
| Other | N/A |  | N/A |  | 261 |  |  | 114 |  |
|  |  |  |  |  | 1,963 |  |  | 134 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |
| BRL | 17 |  |  | 900 |  |  | 3 |  |  | 190 |  |
| CAD | 113 |  |  | 66 |  |  | 90 |  |  | 53 |  |
| CNY | 6,283 |  |  | 2,224 |  |  | 982 |  |  | 348 |  |
| EUR | 2,477 |  |  | 2,320 |  |  | 2,758 |  |  | 2,575 |  |
| GBP | 136 |  |  | 148 |  |  | 178 |  |  | 194 |  |
| HUF | 66,804 |  |  | 56,541 |  |  | 201 |  |  | 170 |  |
| ILS | 386 |  |  | 23 |  |  | 121 |  |  | 7 |  |
| INR | 12,744 |  |  | 534 |  |  | 167 |  |  | 7 |  |
| MXN | 8,187 |  |  | 6,128 |  |  | 409 |  |  | 307 |  |
| MYR | 1,002 |  |  | 351 |  |  | 238 |  |  | 83 |  |
| PLN | 243 |  |  | 199 |  |  | 58 |  |  | 47 |  |
| SEK | 515 |  |  | 579 |  |  | 53 |  |  | 62 |  |
| SGD | 97 |  |  | 50 |  |  | 71 |  |  | 37 |  |
| Other | N/A |  | N/A |  | 69 |  |  | 49 |  |
|  |  |  |  |  | 5,398 |  |  | 4,129 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 7,361 |  |  | $ | 4,263 |  |

[0000866374-22-000035:notes:216]
As of March 31, 2022 and 2021, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the consolidated statements of operations. The Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred losses were $40.9 million as of March 31, 2022, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, and the USD HUF cross currency swaps, which are further discussed below.

[0000866374-22-000035:notes:217]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other liabilities and other assets as of March 31, 2022, and March 31, 2021, respectively. Additionally, the Company entered into USD HUF cross currency swaps to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other liabilities as of March 31, 2022. The changes in fair value of the USD JPY cross currency swap and the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out

[0000866374-22-000035:notes:218]
of accumulated other comprehensive loss to other charges (income), net to offset the remeasurements of the underlying JPY loan principal and HUF bond principal, which also impact the same line.

[0000866374-22-000035:notes:219]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2022 and 2021:

[0000866374-22-000035:notes:220]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31,2022 |  | March 31,2021 |  | Balance SheetLocation |  | March 31,2022 |  | March 31,2021 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 22 |  |  | $ | 23 |  |  | Other current liabilities |  | $ | 35 |  |  | $ | 16 |  |
| Foreign currency contracts | Other assets |  | — |  |  | 5 |  |  | Other liabilities |  | 61 |  |  | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 21 |  |  | $ | 31 |  |  | Other current liabilities |  | $ | 26 |  |  | $ | 32 |  |

[0000866374-22-000035:notes:221]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-22-000035:notes:222]
ACCUMULATED OTHER COMPREHENSIVE LOSS
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2022, 2021 and 2020 are as follows:

[0000866374-22-000035:notes:223]
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance on March 31, 2019 | $ | (42) |  |  | $ | (109) |  |  | $ | (151) |  |
| Other comprehensive loss before reclassifications | (43) |  |  | (22) |  |  | (65) |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 3 |  |  | (2) |  |  | 1 |  |
| Net current-period other comprehensive loss | (40) |  |  | (24) |  |  | (64) |  |
| Ending balance on March 31, 2020 | $ | (82) |  |  | $ | (133) |  |  | $ | (215) |  |
| Other comprehensive gain before reclassifications | 48 |  |  | 56 |  |  | 104 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (8) |  |  | — |  |  | (8) |  |
| Net current-period other comprehensive gain | 40 |  |  | 56 |  |  | 96 |  |
| Ending balance on March 31, 2021 | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |
| Other comprehensive loss before reclassifications | (49) |  |  | (44) |  |  | (93) |  |
| Net losses reclassified from accumulated other comprehensive loss | 25 |  |  | 5 |  |  | 30 |  |
| Net current-period other comprehensive loss | (24) |  |  | (39) |  |  | (63) |  |
| Ending balance on March 31, 2022 | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |

[0000866374-22-000035:notes:224]
Net (gains) losses reclassified from accumulated other comprehensive loss was $30 million loss during fiscal year 2022, and were immaterial during fiscal years 2021 and 2020.The tax impact to other comprehensive loss was immaterial for all periods presented.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-22-000035:notes:225]
TRADE RECEIVABLES SECURITIZATION
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-22-000035:notes:226]
Asset-Backed Securitization Programs

[0000866374-22-000035:notes:227]
The Company has historically sold designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the "Global Program") and its North American Asset-Backed Securitization Agreement (the "North American Program," and together with the Global Program, the "ABS Programs") to affiliated special purpose entities, each of which in turn sells a fraction of the receivables to unaffiliated financial institutions, based on the Company's requirements. Under these programs, the entire purchase price of sold receivables are paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The fair value of the guarantee obligation was zero as of March 31, 2022 and March 31, 2021, respectively. The accounts receivable balances sold under the ABS Programs were removed from the consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the consolidated statements of cash flows.

[0000866374-22-000035:notes:228]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are legally isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which have the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are uncommitted and amount to $500 million for the Global Program and $250 million for the North American Program.

[0000866374-22-000035:notes:229]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized were zero during fiscal year ended March 31, 2022 and were not material during fiscal years ended March 31, 2021 and 2020 and are included in interest, net within the consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-22-000035:notes:230]
As of March 31, 2022 and March 31, 2021, no accounts receivable had been sold under the ABS programs.

[0000866374-22-000035:notes:231]
For the fiscal year ended March 31, 2021, cash flows from sales of receivables to the special purpose entities under the ABS Programs consisted of approximately $8.7 billion, for transfers of receivables. Further, cash flows from sales of receivables from the special purpose entities to unaffiliated financial institutions, during fiscal year 2021, consisted of approximately $0.6 billion for transfers of receivables. For the fiscal year ended March 31, 2020, cash flows from sales of receivables under the ABS Programs consisted of approximately $7.6 billion, for transfers of receivables, and approximately $2.6 billion for collections on deferred purchase price receivables (effective November 2019, upon amending the previous ABS programs, the Company no longer holds a deferred purchase price receivables balance). The Company's cash flows from transfers of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-22-000035:notes:232]
Trade Accounts Receivable Sale Programs

[0000866374-22-000035:notes:233]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.6 billion and $0.2 billion as of March 31, 2022 and 2021, respectively. For the fiscal years ended March 31, 2022, 2021 and 2020, total accounts receivable sold to certain third party banking institutions was approximately $1.6 billion, $0.8 billion and $1.6 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and the cash received was included as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-22-000035:notes:234]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-22-000035:notes:235]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of March 31, 2022.

[0000866374-22-000035:notes:236]
Level 2 - Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-22-000035:notes:237]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-22-000035:notes:238]
The Company's cash equivalents are comprised of bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-22-000035:notes:239]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy. There were no investments classified as level 1 in the fair value hierarchy as of March 31, 2022.

[0000866374-22-000035:notes:240]
Level 3 - Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-22-000035:notes:241]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of March 31, 2022 and 2021.

[0000866374-22-000035:notes:242]
There were no transfers between levels in the fair value hierarchy during fiscal years 2022 and 2021.

[0000866374-22-000035:notes:243]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-22-000035:notes:244]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2022 and 2021:

[0000866374-22-000035:notes:245]
|  | Fair Value Measurements as of March 31, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 2,285 |  |  | $ | — |  |  | $ | 2,285 |  |
| Foreign currency contracts (Note 10) | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (122) |  |  | $ | — |  |  | $ | (122) |  |

[0000866374-22-000035:notes:246]
|  | Fair Value Measurements as of March 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 1,507 |  |  | $ | — |  |  | $ | 1,507 |  |
| Foreign currency contracts (Note 10) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |

[0000866374-22-000035:notes:247]
Other financial instruments

[0000866374-22-000035:notes:248]
The following table presents the Company's major debts not carried at fair value as of March 31, 2022 and 2021:

[0000866374-22-000035:notes:249]
|  | As of March 31, 2022 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In millions) |  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 511 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.43% | 273 |  |  | 273 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 615 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 690 |  |  | 690 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 659 |  |  | 687 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 690 |  |  | 713 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 389 |  |  | 389 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 301 |  |  | 301 |  |  | — |  |  | — |  |  | Level 2 |
| India Facilities | 84 |  |  | 84 |  |  | 133 |  |  | 133 |  |  | Level 2 |

[0000866374-22-000035:notes:250]
The Notes due February 2023, June 2025, February 2026, June 2029 and May 2030 are valued based on broker trading prices in active markets.
The Company values its Term Loan due April 2024, India Facilities, Euro Term Loans and HUF Bonds, based on the current market rate, and as of March 31, 2022, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-22-000035:notes:251]
COMMITMENTS AND CONTINGENCIES
Commitments

[0000866374-22-000035:notes:252]
As of March 31, 2022 and 2021, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under finance leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2038. Refer to note 3 for additional details on the minimum lease payments.

[0000866374-22-000035:notes:253]
Litigation and other legal matters

[0000866374-22-000035:notes:254]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-22-000035:notes:255]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-22-000035:notes:256]
From time to time, the Company enters into intellectual property licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

[0000866374-22-000035:notes:257]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff, National Elevator Industry Pension Fund, and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice

[0000866374-22-000035:notes:258]
of appeal to the Ninth Circuit Court of Appeals. On December 21, 2021, the Court of Appeals affirmed the dismissal with prejudice of the case. The Court of Appeals’ decision took effect on January 12, 2022. The time for plaintiffs to seek review by the U.S. Supreme Court lapsed on March 21, 2022. This matter is now fully resolved.

[0000866374-22-000035:notes:259]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. The parties reached a cash settlement, that is fully provided for as of March 31, 2022, whereby the SunEdison Litigation Trust released all potential claims against the Company.

[0000866374-22-000035:notes:260]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 373.7 million Brazilian reals (approximately USD $78.7 million based on the exchange rate as of March 31, 2022). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 60.6 million Brazilian reals or USD $12.8 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 33.9 million Brazilian reals (approximately USD $7.1 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

[0000866374-22-000035:notes:261]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter.  On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-22-000035:notes:262]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $163.9 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-22-000035:notes:263]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-22-000035:notes:264]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated

[0000866374-22-000035:notes:265]
on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for "Credit Habilitation" with the tax authorities in June 2021 to request additional PIS/COFINS credit in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of the Company's credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remained uncertainty regarding the Company’s ability to recognize these credits. The Company considered the recognition of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and did not record a gain for such credits in the three-month period ended July 2, 2021 as it had not resolved all contingencies to conclude a realized or realizable amount. In September 2021, the Credit Habilitation request was approved by the tax authorities and the Company recognized a gain of 809.6 million Brazilian reals (approximately USD $149.3 million based on the exchange rate as of October 1, 2021) included in other charges (income), net in the consolidated statements of operations for the twelve-month period ended March 31, 2022. The total gain recorded included credits from February 2003 to September 2021, net of additional taxes, as the Credit Habilitation received covering the period from February 2003 to December 2019 resolved any uncertainty regarding the Company's ability to claim such credits. This gain is non-cash and can only be used to offset certain current and future tax obligations. As of March 31, 2022, credits totaling 378.7 million Brazilian reals (approximately USD $79.8 million based on the exchange rate as of March 31, 2022) are included in other current assets.

[0000866374-22-000035:notes:266]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-22-000035:notes:267]
INCOME TAXES
The domestic (Singapore) and foreign components of income before income taxes were comprised of the following:

[0000866374-22-000035:notes:268]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Domestic | $ | 352 |  |  | $ | 242 |  |  | $ | (2) |  |
| Foreign | 693 |  |  | 472 |  |  | 161 |  |
| Total | $ | 1,045 |  |  | $ | 714 |  |  | $ | 159 |  |

[0000866374-22-000035:notes:269]
The provision for income taxes consisted of the following:

[0000866374-22-000035:notes:270]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Current: |  |  |  |  |  |
| Domestic | $ | 3 |  |  | $ | 1 |  |  | $ | 2 |  |
| Foreign | 146 |  |  | 105 |  |  | 62 |  |
|  | 149 |  |  | 106 |  |  | 64 |  |
| Deferred: |  |  |  |  |  |
| Domestic | — |  |  | 1 |  |  | — |  |
| Foreign | (44) |  |  | (6) |  |  | 7 |  |
|  | (44) |  |  | (5) |  |  | 7 |  |
| Provision for income taxes | $ | 105 |  |  | $ | 101 |  |  | $ | 71 |  |

[0000866374-22-000035:notes:271]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2022, 2021 and 2020. The reconciliation of the income tax expense expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0000866374-22-000035:notes:272]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Income taxes based on domestic statutory rates | $ | 178 |  |  | $ | 121 |  |  | $ | 27 |  |
| Effect of jurisdictional tax rate differential | (114) |  |  | (82) |  |  | (81) |  |
| Change in unrecognized tax benefit | 12 |  |  | 11 |  |  | (1) |  |
| Change in valuation allowance | 12 |  |  | 35 |  |  | 93 |  |
| Foreign exchange movement on prior year taxes recoverable | (9) |  |  | 5 |  |  | 13 |  |
| Tax impacts related to sale of Nextracker Series A Preferred Units | 13 |  |  | — |  |  | — |  |
| APB23 tax liability | 1 |  |  | 1 |  |  | 9 |  |
| Other | 12 |  |  | 10 |  |  | 11 |  |
| Provision for income taxes | $ | 105 |  |  | $ | 101 |  |  | $ | 71 |  |

[0000866374-22-000035:notes:273]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2022, 2021 and 2020 was $22.5 million, $21.2 million and $15.6 million, respectively. For the fiscal year ended March 31, 2022, the effect on basic and diluted earnings per share was $0.05 and $0.05, respectively, and the effects on basic and diluted earnings per share during fiscal years 2021 and 2020 were $0.04 and $0.04, and $0.03 and $0.03, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in various years through the end of fiscal year 2028.

[0000866374-22-000035:notes:274]
The Company provides a valuation allowance against deferred tax assets that in the Company's estimation are not more likely than not to be realized. During fiscal year 2022, 2021 and 2020, the Company released valuation allowances totaling $26.3 million, $24.5 million and $1.1 million, respectively. For fiscal year 2022, $7.7 million valuation allowance release was mainly related to certain operations in Canada and Hungary, as these amounts were deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those operations. The remaining $18.6 million valuation allowance release relates to deferred tax assets in the United States deemed realizable due to purchase accounting related to the Anord Mardix acquisition. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances. Lastly, these valuation allowance reductions and eliminations were offset by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions. For fiscal years ended March 31, 2022, 2021 and 2020, the offsetting amounts totaled $38.7 million, $60.0 million and $90.2 million, respectively.

[0000866374-22-000035:notes:275]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years ended March 31, 2022, 2021 and 2020 were $104.5 million, $57.3 million and $27.9 million, respectively.

[0000866374-22-000035:notes:276]
The components of deferred income taxes are as follows:

[0000866374-22-000035:notes:277]
|  | As of March 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (49) |  |  | $ | (69) |  |
| Intangible assets | (89) |  |  | (45) |  |
| Others | (14) |  |  | (13) |  |
| Total deferred tax liabilities | (152) |  |  | (127) |  |
| Deferred tax assets: |  |  |  |
| Fixed assets | 72 |  |  | 66 |  |
| Intangible assets | 6 |  |  | 8 |  |
| Deferred compensation | 22 |  |  | 20 |  |
| Inventory valuation | 26 |  |  | 28 |  |
| Provision for doubtful accounts | 5 |  |  | 5 |  |
| Net operating loss and other carryforwards | 1,542 |  |  | 1,641 |  |
| Others | 201 |  |  | 190 |  |
| Total deferred tax assets | 1,874 |  |  | 1,958 |  |
| Valuation allowances | (1,631) |  |  | (1,726) |  |
| Total deferred tax assets, net of valuation allowances | 243 |  |  | 232 |  |
| Net deferred tax asset | $ | 91 |  |  | $ | 105 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Long-term asset | $ | 177 |  |  | $ | 165 |  |
| Long-term liability | (86) |  |  | (60) |  |
| Total | $ | 91 |  |  | $ | 105 |  |

[0000866374-22-000035:notes:278]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-22-000035:notes:279]
The Company has recorded deferred tax assets of approximately $1.7 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $84.2 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-22-000035:notes:280]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
| Fiscal year | (In millions) |
| 2023 - 2028 | $ | 555 |  |
| 2029 - 2034 | 274 |  |
| 2035 and post | 120 |  |
| Indefinite | 706 |  |
|  | $ | 1,655 |  |

[0000866374-22-000035:notes:281]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-22-000035:notes:282]
The Company does not provide for income taxes on approximately $1.6 billion of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. The estimated amount of the unrecognized deferred tax liability on these undistributed earnings is approximately $147.5 million. As a result, as of March 31, 2022, the Company has provided for earnings in foreign subsidiaries that are not considered to be indefinitely reinvested and therefore subject to withholding taxes on $10.0 million of undistributed foreign earnings, recording a deferred tax liability of approximately $0.5 million thereon.

[0000866374-22-000035:notes:283]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-22-000035:notes:284]
|  | Fiscal Year EndedMarch 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Balance, beginning of fiscal year | $ | 266 |  |  | $ | 246 |  |
| Additions based on tax position related to the current year | 27 |  |  | 16 |  |
| Additions for tax positions of prior years | 15 |  |  | 14 |  |
| Reductions for tax positions of prior years | (7) |  |  | (8) |  |
| Reductions related to lapse of applicable statute of limitations | (16) |  |  | (16) |  |
| Impact from foreign exchange rates fluctuation | (3) |  |  | 14 |  |
| Balance, end of fiscal year | $ | 282 |  |  | $ | 266 |  |

[0000866374-22-000035:notes:285]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an additional approximate $93.2 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-22-000035:notes:286]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2008.

[0000866374-22-000035:notes:287]
Of the $282.2 million of unrecognized tax benefits at March 31, 2022, $189.8 million will affect the annual effective tax rate (ETR) if the benefits are eventually recognized. The amount that doesn’t impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-22-000035:notes:288]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company’s tax expense. During the fiscal years ended March 31, 2022, 2021 and 2020, the Company recognized interest and penalties of approximately $2.1 million, $2.1 million and ($0.9) million, respectively. The Company had approximately $16.4 million, $14.4 million and $12.3 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2022, 2021 and 2020, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-22-000035:notes:289]
RESTRUCTURING CHARGES
Fiscal Year 2022

[0000866374-22-000035:notes:290]
The Company continues to identify certain structural changes to restructure the business throughout fiscal year 2022. During fiscal year 2022, the Company recognized approximately $15 million of restructuring charges, most of which related to employee severance. Restructuring charges are not included in segment income, as disclosed further in note 21.

[0000866374-22-000035:notes:291]
Fiscal Year 2021

[0000866374-22-000035:notes:292]
In order to support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic would be slower than anticipated, the Company identified certain structural changes to restructure the business. These restructuring actions eliminated non-core activities primarily within the Company’s corporate function, aligned the Company’s cost structure with its reorganizing and optimizing of its operations model along its reporting segments, and further sharpened its focus to winning business in end markets where it has competitive advantages and deep domain expertise. During fiscal year 2021, the Company recognized approximately $101.3 million of restructuring charges, most of which related to employee severance.

[0000866374-22-000035:notes:293]
Fiscal Year 2020

[0000866374-22-000035:notes:294]
During the first half of fiscal year 2020 in connection with the geopolitical developments and uncertainties at the time, primarily impacting one customer in China, the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and streamline its cost structure. During fiscal year 2020, the Company recognized $216.4 million of restructuring charges. The Company incurred cash charges of approximately $159.3 million, that were predominantly for employee severance, in addition to non-cash charges of $57.1 million, respectively, primarily related to asset impairments.

[0000866374-22-000035:notes:295]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2019 | $ | 23 |  |  | $ | — |  |  | $ | 9 |  |  | $ | 32 |  |
| Provision for charges incurred in fiscal year 2020 | 123 |  |  | 46 |  |  | 47 |  |  | 216 |  |
| Cash payments for charges incurred in fiscal year 2019 and prior | (15) |  |  | — |  |  | (3) |  |  | (18) |  |
| Cash payments for charges incurred in fiscal year 2020 | (112) |  |  | — |  |  | (35) |  |  | (147) |  |
| Non-cash charges incurred in fiscal year 2020 | — |  |  | (46) |  |  | (14) |  |  | (60) |  |
| Balance as of March 31, 2020 | 19 |  |  | — |  |  | 4 |  |  | 23 |  |
| Provision for charges incurred in fiscal year 2021 | 89 |  |  | 8 |  |  | 4 |  |  | 101 |  |
| Cash payments for charges incurred in fiscal year 2020 and prior | (14) |  |  | — |  |  | — |  |  | (14) |  |
| Cash payments for charges incurred in fiscal year 2021 | (49) |  |  | — |  |  | (1) |  |  | (50) |  |
| Non-cash charges incurred in fiscal year 2021 | — |  |  | (8) |  |  | 1 |  |  | (7) |  |
| Balance as of March 31, 2021 | 45 |  |  | — |  |  | 8 |  |  | 53 |  |
| Provision for charges incurred in fiscal year 2022 | 11 |  |  | 1 |  |  | 3 |  |  | 15 |  |
| Cash payments for charges incurred in fiscal year 2021 and prior | (15) |  |  | — |  |  | — |  |  | (15) |  |
| Cash payments for charges incurred in fiscal year 2022 | (6) |  |  | — |  |  | — |  |  | (6) |  |
| Non-cash charges incurred in fiscal year 2022 | — |  |  | (1) |  |  | (3) |  |  | (4) |  |
| Balance as of March 31, 2022 | 35 |  |  | — |  |  | 8 |  |  | 43 |  |
| Less: Current portion (classified as other current liabilities) | 34 |  |  | — |  |  | 8 |  |  | 42 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-22-000035:notes:296]
OTHER CHARGES (INCOME), NET
Other charges (income), net for the fiscal years ended March 31, 2022, 2021 and 2020 are primarily comprised of the following:

[0000866374-22-000035:notes:297]
|  | Fiscal Year Ended March 31 |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Gain on foreign exchange transactions | $ | (32) |  |  | $ | (21) |  |  | $ | (10) |  |
| Equity in earnings (1) | (61) |  |  | (83) |  |  | (5) |  |
| Impairments and (gain) loss on sale of investments (2) | 2 |  |  | 37 |  |  | 98 |  |
| Brazil tax credit (3) | (150) |  |  | — |  |  | — |  |

[0000866374-22-000035:notes:298]
(1)Represents gains on strategic investments in privately held companies accounted under equity method. During fiscal years 2022 and 2021, the Company recognized $61 million and $83 million of equity in earnings, respectively, driven by the value increase in certain investment funds primarily resulting from discrete market events such as initial public offerings of certain companies included in the funds. Out of the total gain on investments recorded in fiscal years 2022 and 2021, the Company realized approximately $17 million and $48 million of cash proceeds as it sold certain shares received as a distribution from one of its funds' investments.

[0000866374-22-000035:notes:299]
(2)During fiscal years 2022, 2021 and 2020, and in connection with the Company’s ongoing assessment of recoverability of its investment portfolio, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized $3.0 million, $36.5 million and $97.7 million of total impairment charges, respectively (See note 2 for additional information).

[0000866374-22-000035:notes:300]
(3)The Company recognized a $150.0 million gain related to a certain tax credit upon approval of a "Credit Habilitation" request by the relevant Brazil tax authorities for fiscal year 2022. Refer to note 14 for further information.


## flex:InterestAndOtherNetTextBlock

[0000866374-22-000035:notes:301]
INTEREST, NET
Interest, net for the fiscal years ended March 31, 2022, 2021 and 2020 are primarily comprised of the following:

[0000866374-22-000035:notes:302]
|  | Fiscal Year Ended March 31 |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Interest expenses on debt obligations (1) | $ | 153 |  |  | $ | 150 |  |  | $ | 146 |  |
| Interest income | (14) |  |  | (14) |  |  | (19) |  |
| ABS and AR sales programs related expenses | 5 |  |  | 11 |  |  | 43 |  |

[0000866374-22-000035:notes:303]
(1)    Interest expense on debt obligations for fiscal year 2020 includes debt extinguishment costs of $7.2 million, related to the full repayments of the Notes due February 2020 and the Term Loan due November 2021. Debt extinguishment costs incurred during fiscal years 2022 and 2021 were immaterial.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-22-000035:notes:304]
BUSINESS AND ASSET ACQUISITIONS & DIVESTITURES
Fiscal 2022 Business acquisition

[0000866374-22-000035:notes:305]
On December 1, 2021, the Company completed the business acquisition of Anord Mardix, a global leader in critical power solutions for an initial purchase consideration of $522.5 million, net of $25.1 million cash acquired, with an additional $16.5 million deferred purchase price paid out in the fourth quarter of fiscal year 2022, for a total purchase consideration of $539 million. The acquisition adds to the Company's portfolio of Power products and expands its offering in the data center market. For reporting purposes, Anord Mardix is included in the Industrial reporting unit within the FRS segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill. The results of operations of the acquisition were included in the Company’s consolidated financial results beginning on the date of acquisition, and the total amount of net income and revenue were not material to the Company's consolidated financial results for fiscal year 2022.

[0000866374-22-000035:notes:306]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities of Anord Mardix (in millions):

[0000866374-22-000035:notes:307]
| Current assets | $ | 142 |  |
| Property and equipment | 13 |  |
| Operating lease right-of-use assets | 36 |  |
| Intangible assets | 273 |  |
| Goodwill | 272 |  |
| Total assets | $ | 736 |  |
| Current liabilities | $ | 104 |  |
| Operating lease liabilities and other liabilities, non-current | 37 |  |
| Deferred tax liabilities, non-current | 56 |  |
| Total aggregate purchase price, net of cash acquired | $ | 539 |  |

[0000866374-22-000035:notes:308]
The intangible assets of $273.0 million are comprised of customer related intangible assets of $147.0 million and licenses and other intangible assets such as trade names and developed technology of $126.0 million. Customer related assets are

[0000866374-22-000035:notes:309]
amortized over a weighted-average estimated useful life of 8.7 years while licensed and other intangibles are amortized over a weighted-average estimated useful life of 8.9 years.

[0000866374-22-000035:notes:310]
Pro-forma results of operations have not been presented because the effects were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-22-000035:notes:311]
The Company is in the process of evaluating the fair value of the assets and liabilities related to this acquisition. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisition. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the respective measurement period.

[0000866374-22-000035:notes:312]
Fiscal 2020 Business acquisition and divestitures

[0000866374-22-000035:notes:313]
During fiscal year 2020, the Company completed an acquisition that was not significant to the consolidated financial position, result of operations and cash flows of the Company.

[0000866374-22-000035:notes:314]
Further, during fiscal year 2020, the Company disposed of two immaterial non-strategic businesses. The net gain on dispositions was not material to the Company’s consolidated financial results, and was included in other charges, net in the consolidated statements of operations for fiscal year 2020.

[0000866374-22-000035:notes:315]
Pro-forma results of operations for the acquisition and divestitures have not been presented because the effects were not individually, nor in the aggregate, material to the Company's consolidated financial results for all periods presented.


## us-gaap:TreasuryStockTextBlock

[0000866374-22-000035:notes:316]
SHARE REPURCHASE PLAN
During fiscal year 2022, the Company repurchased approximately 38.2 million shares for an aggregate purchase price of approximately $685.6 million and retired all of these shares.

[0000866374-22-000035:notes:317]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 4, 2021. As of March 31, 2022, shares in the aggregate amount of $495.6 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-22-000035:notes:318]
SEGMENT REPORTING
The Company's Chief Executive Officer is our CODM who evaluates how we allocate resources, assesses performance and make strategic and operational decisions. Based on such evaluation, the Company determined as of and for the period ended March 31, 2022, that Flex has three operating and reportable segments. See note 1 and note 7 for further details on the segment change that took place in the fourth quarter of fiscal year 2022.

[0000866374-22-000035:notes:319]
The FAS segment is optimized for speed to market based on a highly flexible supply and manufacturing system. FAS is comprised of the following end markets that represent reporting units:

[0000866374-22-000035:notes:320]
•Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-22-000035:notes:321]
•Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

[0000866374-22-000035:notes:322]
•Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-22-000035:notes:323]
The FRS segment is optimized for longer product lifecycles requiring complex ramps with specialized production models and critical environments. FRS is comprised of the following end markets that represent reporting units:

[0000866374-22-000035:notes:324]
•Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies;

[0000866374-22-000035:notes:325]
•Health Solutions, including medical devices, medical equipment, and drug delivery; and

[0000866374-22-000035:notes:326]
•Industrial, including capital equipment, industrial devices, and renewables and grid edge.

[0000866374-22-000035:notes:327]
The Nextracker segment provides solar tracker technologies that optimize and increase energy production while reducing costs for significant plant return on investment.

[0000866374-22-000035:notes:328]
The determination of the separate operating and reporting segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-22-000035:notes:329]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairments (recoveries), restructuring charges, legal and other. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-22-000035:notes:330]
Selected financial information by segment is in the table below. Fiscal year 2021 and 2020 historical information has been recast to reflect the new operating and reportable segments, in the table below and in Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations."

[0000866374-22-000035:notes:331]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |
| Flex Agility Solutions | $ | 14,027 |  |  | $ | 13,493 |  |  | $ | 14,053 |  |
| Flex Reliability Solutions | 10,603 |  |  | 9,495 |  |  | 9,053 |  |
| Nextracker | 1,458 |  |  | 1,195 |  |  | 1,171 |  |
| Intersegment eliminations | (47) |  |  | (59) |  |  | (67) |  |
|  | $ | 26,041 |  |  | $ | 24,124 |  |  | $ | 24,210 |  |
| Segment income and reconciliation of operating income: |  |  |  |  |  |
| Flex Agility Solutions | $ | 605 |  |  | $ | 449 |  |  | $ | 369 |  |
| Flex Reliability Solutions | 546 |  |  | 484 |  |  | 474 |  |
| Nextracker | 90 |  |  | 178 |  |  | 168 |  |
| Corporate and Other | (72) |  |  | (80) |  |  | (113) |  |
| Total segment income | 1,169 |  |  | 1,031 |  |  | 898 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 68 |  |  | 62 |  |  | 64 |  |
| Stock-based compensation | 91 |  |  | 79 |  |  | 71 |  |
| Customer related asset impairments (recoveries) (1) | — |  |  | (7) |  |  | 106 |  |
| Restructuring charges (Note 16) | 15 |  |  | 101 |  |  | 216 |  |
| Legal and other (2) | 23 |  |  | 1 |  |  | 26 |  |
| Operating income | $ | 972 |  |  | $ | 795 |  |  | $ | 415 |  |

[0000866374-22-000035:notes:332]
(1)Customer related asset impairments (recoveries) for fiscal years 2022 and 2021 were not material.

[0000866374-22-000035:notes:333]
Customer related asset impairments for fiscal year 2020 primarily relate to non-cash impairments of certain property and equipment for customers from whom we have disengaged or were in the process of disengaging, additional provision for doubtful accounts receivable, charges for other asset impairments, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand.

[0000866374-22-000035:notes:334]
(2)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During the fourth quarter of fiscal year 2022, the Company accrued for certain loss contingencies where losses are considered probable and estimable offset by a gain upon successful settlement of certain supplier claims.

[0000866374-22-000035:notes:335]
Legal and other during fiscal year 2021 primarily consists of costs accrued for certain loss contingencies where losses are considered probable and estimable, offset by a gain on the sale of real estate in the fourth quarter of fiscal year 2021 exited as a result of the disengagement of a certain customer in fiscal year 2020.

[0000866374-22-000035:notes:336]
Legal and other during fiscal year 2020 primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India, offset by certain gains resulting from the recognition of prior year expenses paid to a government now considered probable of recovery and reasonably estimable due to a favorable tax ruling.

[0000866374-22-000035:notes:337]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-22-000035:notes:338]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled in the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segment nor reported by segment to the Company's CODM.

[0000866374-22-000035:notes:339]
Property and equipment on a segment basis is not disclosed as it is not separately identified and is not internally reported by segment to the Company's CODM as described above. During fiscal years 2022, 2021 and 2020, depreciation expense included in the segments' measure of operating performance above is as follows.

[0000866374-22-000035:notes:340]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Depreciation expense: |  |  |  |  |  |
| Flex Agility Solutions | $ | 184 |  |  | $ | 185 |  |  | $ | 218 |  |
| Flex Reliability Solutions | 204 |  |  | 210 |  |  | 170 |  |
| Nextracker | 3 |  |  | 2 |  |  | 3 |  |
| Corporate and Other | 18 |  |  | 25 |  |  | 31 |  |
| Total depreciation expense | $ | 409 |  |  | $ | 422 |  |  | $ | 422 |  |

[0000866374-22-000035:notes:341]
Geographic information of net sales is as follows:

[0000866374-22-000035:notes:342]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 10,839 |  |  | 42 | % |  | $ | 9,672 |  |  | 40 | % |  | $ | 10,066 |  |  | 42 | % |
| Asia | 9,601 |  |  | 37 | % |  | 9,326 |  |  | 39 | % |  | 9,362 |  |  | 39 | % |
| Europe | 5,601 |  |  | 21 | % |  | 5,126 |  |  | 21 | % |  | 4,782 |  |  | 19 | % |
|  | $ | 26,041 |  |  |  |  | $ | 24,124 |  |  |  |  | $ | 24,210 |  |  |  |

[0000866374-22-000035:notes:343]
Revenues are attributable to the country in which the product is manufactured, or service is provided.

[0000866374-22-000035:notes:344]
During fiscal years 2022, 2021 and 2020, net sales generated from Singapore, the country of domicile, were approximately $518.9 million, $507.0 million and $574.6 million, respectively.

[0000866374-22-000035:notes:345]
The following table summarizes the countries that accounted for more than 10% of net sales in fiscal years 2022, 2021, and 2020:

[0000866374-22-000035:notes:346]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In millions) |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 6,146 |  |  | 24 | % |  | $ | 6,147 |  |  | 25 | % |  | $ | 5,665 |  |  | 23 | % |
| Mexico | 5,059 |  |  | 19 | % |  | 4,413 |  |  | 18 | % |  | 4,449 |  |  | 18 | % |
| U.S. | 3,690 |  |  | 14 | % |  | 3,648 |  |  | 15 | % |  | 3,719 |  |  | 15 | % |

[0000866374-22-000035:notes:347]
No other country accounted for more than 10% of net sales for the fiscal periods presented in the table above.

[0000866374-22-000035:notes:348]
Geographic information of property and equipment, net is as follows:

[0000866374-22-000035:notes:349]
|  | As of March 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Americas | $ | 1,075 |  |  | 51 | % |  | $ | 1,015 |  |  | 48 | % |
| Asia | 561 |  |  | 26 | % |  | 627 |  |  | 30 | % |
| Europe | 489 |  |  | 23 | % |  | 455 |  |  | 22 | % |
|  | $ | 2,125 |  |  |  |  | $ | 2,097 |  |  |  |

[0000866374-22-000035:notes:350]
As of March 31, 2022 and 2021, property and equipment, net held in Singapore were approximately $5.0 million and $5.9 million, respectively.

[0000866374-22-000035:notes:351]
The following table summarizes the countries that accounted for more than 10% of property and equipment, net in fiscal year 2022 and 2021:

[0000866374-22-000035:notes:352]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 626 |  |  | 29 | % |  | $ | 553 |  |  | 26 | % |
| U.S. | 354 |  |  | 17 | % |  | 361 |  |  | 17 | % |
| China | 299 |  |  | 14 | % |  | 331 |  |  | 16 | % |

[0000866374-22-000035:notes:353]
No other country accounted for more than 10% of property and equipment, net for the fiscal periods presented in the table above.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-22-000035:notes:354]
Legal and other during fiscal year 2020 primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India, offset by certain gains resulting from the recognition of prior year expenses paid to a government now considered probable of recovery and reasonably estimable due to a favorable tax ruling. 
During fiscal years 2022, 2021 and 2020, depreciation expense included in the segments' measure of operating performance above is as follows.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000866374-22-000035:notes:355]
QUARTERLY FINANCIAL DATA (UNAUDITED)The fourth fiscal quarter and year end on March 31 of each year, which is comprised of 90 days for fiscal years 2022 and 2021, respectively. The following table contains the unaudited fourth quarter financial data for fiscal years 2022 and 2021.

[0000866374-22-000035:notes:356]
|  |  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | March 31, 2022 |  |  |  |  |  |  |  | March 31, 2021 |
|  |  |  |  |  |  |  | (In millions, except per share amounts) |
| Net sales |  |  |  |  |  |  | $ | 6,851 |  |  |  |  |  |  |  |  | $ | 6,266 |  |
| Gross profit |  |  |  |  |  |  | 505 |  |  |  |  |  |  |  |  | 509 |  |
| Operating income |  |  |  |  |  |  | 228 |  |  |  |  |  |  |  |  | 282 |  |
| Net income |  |  |  |  |  |  | 172 |  |  |  |  |  |  |  |  | 240 |  |
| Net income attributable to Flex Ltd. |  |  |  |  |  |  | 168 |  |  |  |  |  |  |  |  | 240 |  |
| Earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  |  | $ | 0.36 |  |  |  |  |  |  |  |  | $ | 0.48 |  |
| Diluted |  |  |  |  |  |  | $ | 0.36 |  |  |  |  |  |  |  |  | $ | 0.47 |  |
