# FLEX MD&A — 0000866374-22-000035


## mdna

[0000866374-22-000035:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-22-000035:mdna:2]
OVERVIEW

[0000866374-22-000035:mdna:3]
We are the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we deliver advanced manufacturing solutions and operate one of the most trusted global supply chains, supporting the entire product lifecycle with fulfillment, after-market, and circular economy solutions for diverse industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. Beginning in the fourth quarter of fiscal year 2022, as a result of the sale of certain Series A preferred units in Nextracker LLC ("Nextracker LLC" or "Nextracker") to a third party and our continuing evaluation to separate the Nextracker business and consistent with how our chief operating decision maker allocates resources, assesses performance and makes strategic and operational decisions, we report Nextracker as a separate operating and reportable segment. Nextracker was previously included in the Industrial reporting unit within the Flex Reliability Solutions segment. Our three operating and reportable segments are:

[0000866374-22-000035:mdna:4]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-22-000035:mdna:5]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-22-000035:mdna:6]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

[0000866374-22-000035:mdna:7]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-22-000035:mdna:8]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-22-000035:mdna:9]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies;

[0000866374-22-000035:mdna:10]
◦Health Solutions, including medical devices, medical equipment, and drug delivery; and

[0000866374-22-000035:mdna:11]
◦Industrial, including capital equipment, industrial devices, and renewables and grid edge.

[0000866374-22-000035:mdna:12]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

[0000866374-22-000035:mdna:13]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product lifecycle.

[0000866374-22-000035:mdna:14]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0000866374-22-000035:mdna:15]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-22-000035:mdna:16]
During fiscal year 2021, in order to further support our strategy and build a sustainable organization, and after considering that the economic recovery from the COVID-19 global pandemic will be slower than anticipated, we identified and engaged in certain structural changes. See additional discussion regarding these restructuring actions below under "Results of Operations - Restructuring charges".

[0000866374-22-000035:mdna:17]
We believe that our continued business transformation is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-22-000035:mdna:18]
Update on the Impact of COVID-19 on our Business

[0000866374-22-000035:mdna:19]
With the second wave of the global pandemic including follow-on variants of COVID-19, there have been renewed disease control measures being taken to limit the spread including movement bans and shelter-in-place orders. Although not materially impacting our results for the fourth quarter of fiscal year 2022, most recently, with the lockdowns in China, we have also been experiencing temporary plant closures and/or restrictions at certain of our manufacturing facilities in China. We continue to closely monitor the situation in all the locations where we operate. Our priority remains the welfare of our employees. In addition, our end markets continue to be impacted by the global supply chain disruptions. Component shortages and logistical constraints are pervasive across the entire value chain. COVID-19 related restrictions also contributed to a declining workforce, including at ports and warehouses, as well as creating driver shortages around the world. We expect persistent waves of COVID-19 to remain a headwind into the near future. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future as we are continuing to see increasing supply constraints and costs. We continue to carefully monitor potential supply chain disruptions due to ongoing tightness in the overall component environment. Refer to “Risk Factors - The ongoing COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material.”

[0000866374-22-000035:mdna:20]
We are continuously evaluating our capital structure in response to the current environment and expect that our current financial condition, including our liquidity sources are adequate to fund future commitments. See additional discussion in the Liquidity and Capital Resources section below.

[0000866374-22-000035:mdna:21]
Russian Invasion of Ukraine

[0000866374-22-000035:mdna:22]
We are monitoring and responding to the escalating conflict in Ukraine and the associated sanctions and other restrictions. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine. The full impact of the conflict on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflict and its impact on regional and global economic conditions. We will continue to monitor the conflict and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-22-000035:mdna:23]
Other Developments

[0000866374-22-000035:mdna:24]
On April 28, 2021, we announced that we confidentially submitted a draft registration statement on Form S-1 with the SEC relating to the proposed initial public offering of Nextracker's Class A common stock. The initial public offering and its timing are subject to market and other conditions and the SEC’s review process, and there can be no assurance that we will proceed with such offering or any alternative transaction. Refer to "Risk Factors - We are pursuing alternatives for our Nextracker business, including a full or partial separation of the business, through an initial public offering of Nextracker or otherwise, which may not be consummated as or when planned or at all, and may not achieve the intended benefits."

[0000866374-22-000035:mdna:25]
On February 1, 2022, we sold Series A Preferred Units representing a 16.7% interest in Nextracker to TPG Rise Flash, L.P., a Delaware limited partnership, which is managed or advised by TPG Rise Climate, TPG, Inc.’s dedicated renewables and climate investing fund (“TPG Rise”), for an aggregate purchase price of $500 million. The sale of the 16.7% interest in Nextracker reflects an implied value for Nextracker as of the date of the sale of $3.0 billion. See note 7 to the consolidated financial statements in Item 8, “Financial Statements and Supplementary Data” for further information.

[0000866374-22-000035:mdna:26]
This Annual Report on Form 10-K does not constitute an offer to sell or a solicitation of an offer to buy securities, and shall not constitute an offer, solicitation or sale in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of that jurisdiction.

[0000866374-22-000035:mdna:27]
Business Overview

[0000866374-22-000035:mdna:28]
We are one of the world's largest providers of global supply chain solutions, with revenues of $26.0 billion in the fiscal year ended March 31, 2022. We have established an extensive network of manufacturing facilities in the world's major

[0000866374-22-000035:mdna:29]
consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. We also provide intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. As of March 31, 2022, our total manufacturing capacity was approximately 27 million square feet. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment, by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-22-000035:mdna:30]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  |  |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 10,839 |  |  | 42 | % |  | $ | 9,672 |  |  | 40 | % |  |  |  |  |
| Asia | 9,601 |  |  | 37 | % |  | 9,326 |  |  | 39 | % |  |  |  |  |
| Europe | 5,601 |  |  | 21 | % |  | 5,126 |  |  | 21 | % |  |  |  |  |
|  | $ | 26,041 |  |  |  |  | $ | 24,124 |  |  |  |  |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 6,146 |  |  | 24 | % |  | $ | 6,147 |  |  | 25 | % |  |  |  |  |
| Mexico | 5,059 |  |  | 19 | % |  | 4,413 |  |  | 18 | % |  |  |  |  |
| U.S. | 3,690 |  |  | 14 | % |  | 3,648 |  |  | 15 | % |  |  |  |  |
| Brazil | 2,022 |  |  | 8 | % |  | 1,554 |  |  | 6 | % |  |  |  |  |
| Malaysia | 1,866 |  |  | 7 | % |  | 1,563 |  |  | 6 | % |  |  |  |  |
| Hungary | 1,230 |  |  | 5 | % |  | 1,313 |  |  | 5 | % |  |  |  |  |
| Other | 6,028 |  |  | 23 | % |  | 5,486 |  |  | 25 | % |  |  |  |  |
|  | $ | 26,041 |  |  |  |  | $ | 24,124 |  |  |  |  |  |  |  |

[0000866374-22-000035:mdna:31]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 626 |  |  | 29 | % |  | $ | 553 |  |  | 26 | % |
| U.S. | 354 |  |  | 17 | % |  | 361 |  |  | 17 | % |
| China | 299 |  |  | 14 | % |  | 331 |  |  | 16 | % |
| India | 129 |  |  | 6 | % |  | 166 |  |  | 8 | % |
| Hungary | 118 |  |  | 6 | % |  | 105 |  |  | 5 | % |
| Malaysia | 110 |  |  | 5 | % |  | 106 |  |  | 5 | % |
| Other | 489 |  |  | 23 | % |  | 475 |  |  | 23 | % |
|  | $ | 2,125 |  |  |  |  | $ | 2,097 |  |  |  |

[0000866374-22-000035:mdna:32]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we offer our customers the ability to simplify their global product development, manufacturing process, and after-sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-22-000035:mdna:33]
Our operating results are affected by a number of factors, including the following:

[0000866374-22-000035:mdna:34]
•the impacts on our business due to component shortages, disruptions in transportation or other supply chain related constraints including as a result of the COVID-19 global pandemic;

[0000866374-22-000035:mdna:35]
36

[0000866374-22-000035:mdna:36]
•the effects of the COVID-19 global pandemic on our business and results of operations;

[0000866374-22-000035:mdna:37]
•changes in the macro-economic environment and related changes in consumer demand;

[0000866374-22-000035:mdna:38]
•the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, and other factors;

[0000866374-22-000035:mdna:39]
•the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance;

[0000866374-22-000035:mdna:40]
•our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers;

[0000866374-22-000035:mdna:41]
•the effects that current credit and market conditions (including as a result of the COVID-19 global pandemic and the ongoing conflict between Russia and Ukraine) could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-22-000035:mdna:42]
•the effects on our business due to certain customers' products having short product lifecycles;

[0000866374-22-000035:mdna:43]
•our customers' ability to cancel or delay orders or change production quantities;

[0000866374-22-000035:mdna:44]
•our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements;

[0000866374-22-000035:mdna:45]
•integration of acquired businesses and facilities;

[0000866374-22-000035:mdna:46]
•increased labor costs due to adverse labor conditions in the markets we operate;

[0000866374-22-000035:mdna:47]
•changes in tax legislation; and

[0000866374-22-000035:mdna:48]
•changes in trade regulations and treaties.

[0000866374-22-000035:mdna:49]
We also are subject to other risks as outlined in Item 1A, "Risk Factors".

[0000866374-22-000035:mdna:50]
Net sales for fiscal year 2022 increased approximately 8%, or $1.9 billion, to $26.0 billion from the prior year. The increase in sales was notable in all three segments. Net sales for our FAS segment increased $0.5 billion, or 4.0%, from the prior year, driven by an increase in our Lifestyle business, and to a lesser extent, an increase in our CEC business. These increases were driven by a lesser impact from COVID-19 production pressure during the current year versus the prior year, coupled with new ramps, customer expansions and continued recoveries in consumer spending, offset to some extent by the scarcity of components and raw material and logistics constraints noted above. The increases noted in FAS during fiscal year 2022 were partially offset by a decrease in our Consumer Devices business primarily due to component shortages and planned contract completions. Net sales for our FRS segment increased $1.1 billion, or 12%, from the prior year, primarily driven by an increase in sales from our Industrial business, as a result of customer ramps and strong demand in EV charging and renewables, semicap, and robotics, coupled with incremental revenue from the Anord Mardix acquisition. In addition, net sales for our Automotive business increased due to new programs during fiscal year 2022 for our next generation mobility portfolio and recovery from the depressed sales from factory shutdowns in the first quarter of fiscal year 2021. The increase in our Automotive business was partially constrained by component shortages and OEM plant shutdowns during fiscal year 2022. Net sales for our Nextracker segment increased $0.3 billion, or 22.0%, from the prior year, primarily driven by additional tracker projects, most notably outside the United States. Our fiscal year 2022 gross profit totaled $1.9 billion, representing an increase of $0.2 billion, or 15%, from the prior year. The increase was primarily driven by overall stronger cost discipline focused on driving further productivity improvements, coupled with continued improvement in the mix of our business, lower restructuring charges in the current fiscal year, benefits from prior restructuring activities and a lower direct and incremental impact from COVID-19, coupled with the stronger demand in multiple end markets compared to the prior year period. Our net income totaled $0.9 billion, representing an increase of $0.3 billion, or 53%, compared to fiscal year 2021, due to the factors explained above along with an approximately $150 million non-cash gain recorded in fiscal year 2022 related to certain tax credits in Brazil (See note 14 to the consolidated financial statements for further information).

[0000866374-22-000035:mdna:51]
37

[0000866374-22-000035:mdna:52]
Cash provided by operations increased by approximately $0.9 billion to a cash inflow of $1.0 billion for fiscal year 2022 compared with a cash inflow of $0.1 billion for fiscal year 2021 primarily driven by the $0.3 billion increase in net income and $0.6 billion increase in cash provided by operating assets and liabilities. Our net working capital ("NWC") is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, plus inventories and contract assets, less accounts payable. Our net working capital as a percentage of annualized sales for fiscal year 2022 increased to 15.4% from 11.5% in the prior year as a direct result of elevated inventory levels due to component shortages and logistics constraints.

[0000866374-22-000035:mdna:53]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. We also excluded the impact to cash flows related to certain vendor programs that is required for U.S. GAAP presentation as well as cash outflows related to repayment of the outstanding balance of our asset-backed securitization ("ABS") programs in fiscal year 2021 as we utilized proceeds from debt issuance to replace funding from the ABS programs for working capital purposes. Our adjusted free cash flow was $0.6 billion and $0.7 billion for fiscal years 2022 and 2021, respectively. Refer to the Liquidity and Capital Resources section for the adjusted free cash flows reconciliation to the most directly comparable GAAP financial measure of cash flows from operations. Cash used in investing activities increased by approximately $0.7 billion to a cash outflow of $1.0 billion for fiscal year 2022, compared with a cash outflow of $0.2 billion for fiscal year 2021, primarily due to $0.5 billion of cash paid for the acquisition of Anord Mardix in December 2021, net of cash acquired. Cash provided by financing activities decreased by approximately $0.5 billion to a cash inflow of $0.3 billion during fiscal year 2022, compared with a cash inflow of $0.7 billion in the prior year, primarily driven by $0.5 billion of additional cash paid for the repurchase of our ordinary shares in the current fiscal year.

[0000866374-22-000035:mdna:54]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000866374-22-000035:mdna:55]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to the COVID-19 pandemic and the ongoing conflict between Russia and Ukraine, there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the COVID-19 pandemic and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from those estimates and assumptions.

[0000866374-22-000035:mdna:56]
We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-22-000035:mdna:57]
Revenue Recognition

[0000866374-22-000035:mdna:58]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assess whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when we have transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-22-000035:mdna:59]
Customer Contracts and Related Obligations

[0000866374-22-000035:mdna:60]
Certain of our customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as

[0000866374-22-000035:mdna:61]
on-time delivery, and other periodic pricing resets that may be refundable to customers. We estimate the variable consideration related to these price adjustments as part of the total transaction price and recognize revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. We constrain the amount of revenues recognized for these contractual provisions based on our best estimate of the amount which will not result in a significant reversal of revenue in a future period. We determine the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-22-000035:mdna:62]
Customer Credit Risk

[0000866374-22-000035:mdna:63]
We have an established customer credit policy through which we manage customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. We perform ongoing credit evaluations of our customers' financial condition and make provisions for doubtful accounts based on the outcome of those credit evaluations. We evaluate the collectability of accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent we identify exposures as a result of customer credit issues, we also review other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-22-000035:mdna:64]
Restructuring Charges

[0000866374-22-000035:mdna:65]
We recognize restructuring charges related to our plans to close or consolidate excess manufacturing facilities and rationalize administrative functions and to realign our corporate cost structure. In connection with these activities, we recognize restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-22-000035:mdna:66]
The recognition of these restructuring charges requires that we make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned restructuring activity. To the extent our actual results differ from our estimates and assumptions, we may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, we evaluate the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed exit plans.

[0000866374-22-000035:mdna:67]
Refer to note 16 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-22-000035:mdna:68]
Inventory Valuation

[0000866374-22-000035:mdna:69]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regards to inventory procured to fulfill customer demand.

[0000866374-22-000035:mdna:70]
Valuation of Private Company Investments

[0000866374-22-000035:mdna:71]
We assess our investments for impairment whenever events or changes in circumstances indicate that the assets may be impaired. The factors we consider in our evaluation of potential impairment of our investments, include, but are not limited to a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. The carrying value of certain of our investments are individually material, and thus there is the potential for material charges in future periods if we determine that those investments are impaired. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our investments.

[0000866374-22-000035:mdna:72]
Carrying Value of Long-Lived Assets

[0000866374-22-000035:mdna:73]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. An impairment loss is recognized when the carrying amount of the asset group exceeds its fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such asset groups are determined to be impaired, the impairment loss

[0000866374-22-000035:mdna:74]
39

[0000866374-22-000035:mdna:75]
recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, the general business environment and other factors including future developments of the COVID-19 pandemic and the ongoing conflict between Russia and Ukraine, which remain highly uncertain and unpredictable. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize material impairment charges in the future.

[0000866374-22-000035:mdna:76]
Goodwill

[0000866374-22-000035:mdna:77]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require us to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider our budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While we believe we have made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If our actual results are not consistent with our estimates and assumptions used to calculate fair value, it could result in material impairments of our goodwill. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail on our goodwill.

[0000866374-22-000035:mdna:78]
Contingent Liabilities

[0000866374-22-000035:mdna:79]
We may be exposed to certain liabilities relating to our business operations, acquisitions of businesses and assets and other activities. We make provisions for such liabilities when it is probable that the settlement of the liability will result in an outflow of economic resources or the impairment of an asset. We make these assessments based on facts and circumstances that may change in the future resulting in additional expenses.

[0000866374-22-000035:mdna:80]
Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our contingent liabilities.

[0000866374-22-000035:mdna:81]
Redeemable Noncontrolling Interest

[0000866374-22-000035:mdna:82]
Interest held by a third party in a consolidated majority-owned subsidiary is presented as noncontrolling interest, which represents the noncontrolling equity holder’s interest in the underlying net assets of our consolidated majority-owned subsidiary. Noncontrolling interest, where we may be required to repurchase the noncontrolling interest under a contractual redemption requirement, is reported in the consolidated balance sheets between liabilities and equity, as redeemable noncontrolling interest (“RNCI”). The carrying value of the RNCI should not be accreted or adjusted to redemption value unless it becomes probable that the Series A Units will become redeemable. Refer to note 7 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our RNCI.

[0000866374-22-000035:mdna:83]
Income Taxes

[0000866374-22-000035:mdna:84]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-22-000035:mdna:85]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-22-000035:mdna:86]
40

[0000866374-22-000035:mdna:87]
RESULTS OF OPERATIONS

[0000866374-22-000035:mdna:88]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data." As further discussed in note 1 and note 21 to the consolidated financial statement in Item 8, we revised our reportable segments in the fourth quarter of fiscal year 2022 to reflect Nextracker as a separate reportable segment in addition to FRS and FAS. There was no change to our consolidated financial statements. Additionally, as further discussed in note 2 to the consolidated financial statement in Item 8, the prior year amounts related to interest expense (income), net are now presented separately under interest, net, and the remaining balances under interest and other, net have been reclassified to other charges (income), net within the consolidated statements of operations. We also elected to include operating income as a subtotal in the consolidated statements of operations. For comparability purposes, the prior periods have been recast to conform to the current presentation. The reclassifications had no effect on the previously reported results of operations.

[0000866374-22-000035:mdna:89]
For a discussion of our results of operations for the fiscal year ended March 31, 2021 compared to the fiscal year ended March 31, 2020, refer to Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0000866374-22-000035:mdna:90]
The data below, and discussion that follows, represents our results from operations.

[0000866374-22-000035:mdna:91]
|  | Fiscal Year EndedMarch 31, |
|  | 2022 |  | 2021 |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |
| Cost of sales | 92.5 |  |  | 92.6 |  |  |  |
| Restructuring charges | 0.1 |  |  | 0.4 |  |  |  |
| Gross profit | 7.4 |  |  | 7.0 |  |  |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.4 |  |  |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  |  |
| Restructuring charges | — |  |  | 0.1 |  |  |  |
| Operating income | 3.7 |  |  | 3.2 |  |  |  |
| Interest, net | 0.6 |  |  | 0.6 |  |  |  |
| Other charges (income), net | (0.9) |  |  | (0.3) |  |  |  |
| Income before income taxes | 4.0 |  |  | 2.9 |  |  |  |
| Provision for income taxes | 0.4 |  |  | 0.4 |  |  |  |
| Net income | 3.6 | % |  | 2.5 | % |  |  |
| Net income attributable to redeemable noncontrolling interest | — |  |  | — |  |  |  |
| Net income attributable to Flex Ltd. | 3.6 | % |  | 2.5 | % |  |  |

[0000866374-22-000035:mdna:92]
Net sales

[0000866374-22-000035:mdna:93]
The following table sets forth our net sales by segment, and their relative percentages:

[0000866374-22-000035:mdna:94]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  |  |
| Net sales: | (In millions) |
| Flex Agility Solutions | $ | 14,027 |  |  | 54 | % |  | $ | 13,493 |  |  | 56 | % |  |  |  |  |
| Flex Reliability Solutions | 10,603 |  |  | 41 | % |  | 9,495 |  |  | 39 | % |  |  |  |  |
| Nextracker | 1,458 |  |  | 6 | % |  | 1,195 |  |  | 5 | % |  |  |  |  |
| Intersegment eliminations | (47) |  |  | — | % |  | (59) |  |  | — | % |  |  |  |  |
|  | $ | 26,041 |  |  |  |  | $ | 24,124 |  |  |  |  |  |  |  |

[0000866374-22-000035:mdna:95]
Net sales for the fiscal year ended 2022 totaled $26.0 billion, representing an increase of $1.9 billion, or approximately 8%, from $24.1 billion for the fiscal year ended 2021. Net sales for our FAS segment increased $0.5 billion, or 4%, from the

[0000866374-22-000035:mdna:96]
41

[0000866374-22-000035:mdna:97]
prior year, mainly due to an increase in net sales of 14% in our Lifestyle business and 3% in our CEC business resulting from a lesser impact from COVID-19 production pressure during the current year versus the prior year, coupled with new ramps, customer expansions and continued recoveries in consumer spending, offset to some extent by the scarcity of components and raw material and logistics constraints. These increases in FAS were offset by a 7% decrease in net sales in our Consumer Devices business due to certain planned contract completions in fiscal year 2022 reflecting our active program management. Net sales in our FRS segment increased $1.1 billion, or 12%, driven primarily by an increase of 17% in net sales from prior year in our Industrial business as a result of customer ramps and strong demand in EV charging and renewables, semicap, and robotics, coupled with incremental revenues from our Anord Mardix acquisition. In addition, net sales for our Automotive business increased 15% from the prior year due to new programs during fiscal year 2022 for our next generation mobility portfolio and recovery from the depressed sales from factory shutdowns in the first quarter of fiscal year 2021. The increase in our Automotive business was partially constrained by component shortages and OEM plant shutdowns during fiscal year 2022. Net sales for our Nextracker segment increased $0.3 billion, or 22%, from the prior year driven by additional tracker projects, most notably outside the United States.

[0000866374-22-000035:mdna:98]
Net sales increased across all regions with a $1.2 billion increase to $10.8 billion in the Americas, a $0.5 billion increase to $5.6 billion in Europe, and a $0.3 billion increase to $9.6 billion in Asia.

[0000866374-22-000035:mdna:99]
Our ten largest customers during fiscal years 2022 and 2021 accounted for approximately 34% and 36% of net sales, respectively. We have made substantial efforts to diversify our portfolio which allows us to operate at scale in many different industries, and, as a result, no customer accounted for greater than 10% of net sales in fiscal year 2022 and 2021.

[0000866374-22-000035:mdna:100]
Cost of sales

[0000866374-22-000035:mdna:101]
Cost of sales is affected by a number of factors, including the number and size of new manufacturing programs, product mix, labor cost fluctuations by region, component costs and availability and capacity utilization.

[0000866374-22-000035:mdna:102]
Cost of sales during fiscal year 2022 totaled $24.1 billion, representing an increase of approximately $1.7 billion, or 8% from $22.3 billion during fiscal year 2021. The increase in cost of sales is most notable in our FRS segment. Cost of sales in FRS for fiscal year 2022 increased $1.0 billion or approximately 12% from fiscal year 2021, which is in line with the 12% increase in revenue, primarily as a result of higher revenue in our Industrial and Automotive businesses. Cost of sales in FAS increased $0.4 billion, or approximately 3%, from fiscal year 2021, which is relatively consistent the 4% increase in revenue, primarily as a result of higher revenue in our Lifestyle and CEC businesses, and partially offset by improved efficiencies. Cost of sales in our Nextracker segment increased $0.4 billion or approximately 37% from fiscal year 2021, primarily due to the increase in steel and freight costs due to container shortages and other logistics challenges resulting from the COVID-19 pandemic, coupled with the increase in sales noted above.

[0000866374-22-000035:mdna:103]
Gross profit

[0000866374-22-000035:mdna:104]
Gross profit is affected by a fluctuation in costs of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-22-000035:mdna:105]
Gross profit during fiscal year 2022 increased $0.2 billion to $1.9 billion, or 7.4% of net sales, from $1.7 billion, or 7.0% of net sales, during fiscal year 2021, an improvement of 40 basis points. The increase in gross profit and gross margin during fiscal year 2022 primarily resulted from the overall stronger cost discipline focused on driving further productivity improvements, coupled with continued improvement in the mix of our business, lower restructuring charges incurred compared to prior year, benefits from prior restructuring activities and a lower direct and incremental impact from COVID-19, coupled with stronger demand in our Automotive, Industrial, CEC and Lifestyle businesses compared to the prior year period.

[0000866374-22-000035:mdna:106]
Segment income

[0000866374-22-000035:mdna:107]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairments (recoveries), restructuring charges, legal and other. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-22-000035:mdna:108]
42

[0000866374-22-000035:mdna:109]
The following table sets forth segment income and margins:

[0000866374-22-000035:mdna:110]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  |  |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 605 |  |  | 4.3 | % |  | $ | 449 |  |  | 3.3 | % |  |  |  |  |
| Flex Reliability Solutions | 546 |  |  | 5.1 | % |  | 484 |  |  | 5.1 | % |  |  |  |  |
| Nextracker | 90 |  |  | 6.2 | % |  | 178 |  |  | 14.9 | % |  |  |  |  |

[0000866374-22-000035:mdna:111]
FAS segment margin increased 100 basis points, to 4.3% for fiscal year 2022, from 3.3% for fiscal year 2021. The margin increase during the period was driven by disciplined cost management and improved efficiencies as noted above, partially offset by elevated costs due to component shortages and logistics constraints across all of our end markets.

[0000866374-22-000035:mdna:112]
FRS segment margin for both fiscal years 2022 and 2021 was consistent at 5.1%. FRS segment margin increased for fiscal year 2022 in our Automotive business compared to the prior year despite component shortages and OEM plant shutdowns during the current year and to a lesser extent, increased in our Industrial business due to strong demand and customer ramps. Increases in Automotive and Industrial were offset by a drop in Health Solutions due to high growth from critical care products in the fiscal year ended 2021.

[0000866374-22-000035:mdna:113]
Nextracker segment margin decreased 870 basis points, to 6.2% for fiscal year 2022, from 14.9% for fiscal year 2021 driven primarily by increased freight and logistics costs.

[0000866374-22-000035:mdna:114]
Restructuring charges

[0000866374-22-000035:mdna:115]
We continued to identify certain structural changes to restructure the business throughout fiscal year 2022. During fiscal year 2022, we recognized approximately $15 million of restructuring charges, most of which related to employee severance. During fiscal year 2021, we recognized approximately $0.1 billion of restructuring charges, most of which related to employee severance as part of an overall effort to align our cost structure with the reorganizing and optimizing of our operations model along the reporting segments, and further sharpen our focus to winning business in end markets where we have competitive advantages and deep domain expertise

[0000866374-22-000035:mdna:116]
Refer to note 16 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-22-000035:mdna:117]
Selling, general and administrative expenses

[0000866374-22-000035:mdna:118]
Selling, general and administrative expenses ("SG&A") totaled $0.9 billion, or 3.4% of net sales, during fiscal year 2022, compared to $0.8 billion, or 3.4% of net sales, during fiscal year 2021, increasing by $75 million or 9%, which reflects our enhanced cost control efforts to support higher revenue growth while keeping our SG&A expenses relatively flat.

[0000866374-22-000035:mdna:119]
Intangible amortization

[0000866374-22-000035:mdna:120]
Amortization of intangible assets in fiscal years 2022 and 2021 were $68 million and $62 million, respectively, representing an increase of $6 million, from fiscal year 2021 as a result of four months of amortization expense related to new intangible assets from the Anord Mardix acquisition in December 2021 offset by certain intangible assets being fully amortized during fiscal year 2022.

[0000866374-22-000035:mdna:121]
Interest, net

[0000866374-22-000035:mdna:122]
Interest, net remained relatively flat at $152 million and $148 million during fiscal years 2022 and 2021, respectively.

[0000866374-22-000035:mdna:123]
Other charges (income), net

[0000866374-22-000035:mdna:124]
During fiscal year 2022, we recorded $225 million of other income, net, primarily driven by a $150 million gain related to a certain tax credit recorded upon approval of a "Credit Habilitation" request by the relevant Brazil tax authorities. This is a non-cash gain which will be used to offset certain current and future tax obligations. Other income, net also includes $61 million of equity in earnings, driven by the value increase in certain investment funds resulting from discrete market events including initial public offerings of certain companies included in the funds, coupled with a $32 million gain on foreign exchange transactions.

[0000866374-22-000035:mdna:125]
43

[0000866374-22-000035:mdna:126]
During fiscal year 2021, we recorded $67 million of other income, net, primarily as a result of recognizing $83 million of equity in earnings, driven by the value increase in certain investment funds resulting from discrete market events including initial public offerings of certain companies included in the funds. Out of the $83 million equity in earnings recorded in fiscal year 2021, we collected $48 million of cash proceeds as we sold certain shares received as a distribution from one of our fund's investments. Partially offsetting the income was an impairment charge of $37 million related to certain non-core investments that were determined to be other than temporarily impaired.

[0000866374-22-000035:mdna:127]
Refer to note 17 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our other charges (income), net.

[0000866374-22-000035:mdna:128]
Income taxes

[0000866374-22-000035:mdna:129]
We work to ensure that we accrue and pay the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which we operate. Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were 10.0% and 14.1% for the fiscal years 2022 and 2021, respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0000866374-22-000035:mdna:130]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  |  |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  |  |
| Effect of jurisdictional tax rate differential | (10.9) |  |  | (11.6) |  |  |  |
| Change in unrecognized tax benefit | 1.1 |  |  | 1.5 |  |  |  |
| Change in valuation allowance | 1.1 |  |  | 4.9 |  |  |  |
| Foreign exchange movement on prior year taxes recoverable | (0.9) |  |  | 0.7 |  |  |  |
| Tax impacts related to sale of Nextracker Series A Preferred Units | 1.2 |  |  | — |  |  |  |
| APB 23 tax liability | 0.1 |  |  | 0.1 |  |  |  |
| Other | 1.3 |  |  | 1.5 |  |  |  |
| Provision for income taxes | 10.0 | % |  | 14.1 | % |  |  |

[0000866374-22-000035:mdna:131]
The variation in our effective tax rate each year is primarily a result of recognition of earnings in foreign jurisdictions which are taxed at rates lower than the Singapore statutory rate including the effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia, Costa Rica, Netherlands and Israel of $23 million and $21 million in fiscal years 2022 and 2021, respectively. Additionally, our effective tax rate is impacted by changes in our liabilities for uncertain tax positions of $12 million, and $11 million and changes in our valuation allowances on deferred tax assets of $12 million and $35 million in fiscal years 2022 and 2021, respectively. We generate most of our revenues and profits from operations outside of Singapore.

[0000866374-22-000035:mdna:132]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our effective tax rate, tax position, operating results, financial position and cash flows.

[0000866374-22-000035:mdna:133]
We provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized. During fiscal year 2022, we released valuation allowances totaling $26 million, $8 million of which related primarily to certain operations in Canada and Hungary, as these amounts were deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those operations. The remaining approximately $19 million valuation allowance release related to deferred tax assets in the United States deemed realizable due to purchase accounting related to the Anord Mardix acquisition. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances. Lastly, these valuation allowance reductions and eliminations were offset by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions.

[0000866374-22-000035:mdna:134]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-22-000035:mdna:135]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of March 31, 2022, we had cash and cash equivalents of approximately $3.0 billion and bank and other borrowings of approximately $4.2 billion. We have a $2.0 billion revolving credit facility, that is due to mature in January 2026 (the "2026 Credit Facility"), under which we had no borrowings outstanding as of March 31, 2022. We also issued HUF 100 billion of 3.6% bonds due December 2031 (approximately $301.4 million, as of March 31, 2022) and borrowed €350 million under a one-year term loan (approximately $388.6 million as of March 31, 2022) at an interest rate of (0.18)% per annum. The proceeds of the new debt were used to refinance certain other outstanding debt in fiscal year 2022 and for other general corporate purposes. As of March 31, 2022, we were in compliance with the covenants under all of our credit facilities and indentures. Refer to note 9 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details on the 2026 Credit Facility and the new notes.

[0000866374-22-000035:mdna:136]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2022, approximately 34% of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2022). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-22-000035:mdna:137]
The following is a discussion of our cash flows for the fiscal years ended March 31, 2022 and March 31, 2021. For a discussion of our cash flows for the fiscal years ended March 31, 2021 and March 31, 2020, please refer to Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0000866374-22-000035:mdna:138]
Fiscal Year 2022

[0000866374-22-000035:mdna:139]
Cash provided by operating activities was $1.0 billion during fiscal year 2022. The total cash provided by operating activities resulted primarily from $0.9 billion of net income for the period plus $0.6 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, provision for doubtful accounts, deferred income taxes and stock-based compensation. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were offset by a net change in our operating assets and liabilities of $0.5 billion primarily driven by changes in NWC as discussed below, partially offset by an increase in cash from other current liabilities of $1.1 billion primarily attributed to customer advances received.

[0000866374-22-000035:mdna:140]
We believe NWC, and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. NWC is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, plus inventories and contract assets, less accounts payable. NWC increased by $1.3 billion to $4.2 billion as of March 31, 2022, from $2.9 billion as of March 31, 2021. This increase is primarily driven by a $2.7 billion increase in inventories due to component shortages, clear-to build constraints and logistic challenges which increased buffer stock and inventory pricing, coupled with a $0.2 billion increase in contract assets, and partially offset with a $1.0 billion increase in accounts payable due to increased inventory purchases and a $0.6 billion decrease in accounts receivable, net partially due to more accounts receivable factored as of March 31, 2022. Our net working capital as a percentage of annualized net sales as of March 31, 2022 increased to 15.4% as compared to 11.5% of annualized net sales as of March 31, 2021 due to these factors. We continue to experience component shortages in the supply chain and logistical constraints, and although we are actively managing these impacts, we expect continued working capital pressure in the near future. We expect it will take time to adequately drive down our inventory levels. We are proactively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative to reset our load planning in an effort to reduce inventory levels. In addition, we are pursuing alternative resources using inclusive hybrid solutions to minimize transit times and implementing operational efficiencies. Component shortages and significantly increased logistic costs are expected to persist into the near future as we are continuing to experience increasing supply constraints and costs. We are working diligently with our partners to secure needed parts and fulfill demand. In addition, to the extent possible, we have collaborated with our customers for working capital advances to offset the required investment in inventory. Advances from customers were $1.4 billion as of March 31, 2022, an increase of $0.9 billion from $0.5 billion as of March 31, 2021.

[0000866374-22-000035:mdna:141]
Cash used in investing activities totaled $1.0 billion during fiscal year 2022. This was primarily driven by $0.5 billion of cash paid for the acquisition of Anord Mardix in December 2021, net of cash acquired, and approximately $0.4 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Lifestyle, Automotive, and Industrial businesses.

[0000866374-22-000035:mdna:142]
Cash provided by financing activities was $0.3 billion during fiscal year 2022. This was primarily driven by $0.7 billion of proceeds received in aggregate, after premiums, following the issuance of the HUF 100 billion Bonds due December 2031 and the €350 million term loan due December 2022, and $0.5 billion of proceeds received from the sale of Nextracker redeemable preferred units, partially offset by $0.7 billion of cash paid for the repurchase of our ordinary shares and $0.2 billion of cash paid for the repayment of the Euro term loan due January 2022. Refer to note 9 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details.

[0000866374-22-000035:mdna:143]
Fiscal Year 2021

[0000866374-22-000035:mdna:144]
Cash provided by operating activities was $0.1 billion during fiscal year 2021. The total cash provided by operating activities resulted primarily from $0.6 billion of net income for the period plus $0.6 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, provision for doubtful accounts, deferred income taxes and stock-based compensation. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were offset by a net change in our operating assets and liabilities of $1.1 billion, primarily driven by cash outflows related to accounts receivables resulting from the reduction of our outstanding balances of accounts receivable sold through our ABS and accounts receivable factoring programs.

[0000866374-22-000035:mdna:145]
Cash used in investing activities totaled $0.2 billion during fiscal year 2021. This was primarily driven by approximately $0.4 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Health Solutions and Industrial businesses net of approximately $0.1 billion of proceeds from the sale of fixed assets including proceeds from the sale of an exited facility in the fourth quarter of fiscal year 2021 as a result of the disengagement of a certain customer in fiscal year 2020. Further offsetting the capital expenditures was $48 million of proceeds from the sale of certain shares received as distribution from one of our funds' investments.

[0000866374-22-000035:mdna:146]
Cash provided by financing activities was $0.7 billion during fiscal year 2021. This was primarily driven by $1.4 billion of proceeds received in aggregate, net of discounts and after premiums, following the issuance of the 2026 Notes and the 2030 Notes, partially offset by $0.4 billion of cash paid for the repayment of the term loan due June 2022. Also offsetting cash provided by financing activities was $0.2 billion of cash paid for the repurchase of our ordinary shares.

[0000866374-22-000035:mdna:147]
Adjusted Free Cash Flow

[0000866374-22-000035:mdna:148]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investors. During fiscal year 2021, we proactively and strategically reduced the outstanding balance of our ABS programs. Proceeds from our debt issuance replaced the funding from the ABS programs for working capital purposes. As this decrease in cash flow reflected the change of our capital strategy, we added this back for our adjusted free cash flow calculation and also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation for fiscal year 2021. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” (Adjusted Free Cash Flow subsection) of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2021 for further discussion. Our adjusted free cash flow was $0.6 billion and $0.7 billion for fiscal years 2022 and 2021, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-22-000035:mdna:149]
|  | Fiscal Year Ended March 31, |
|  | 2022 |  | 2021 |  |  |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,024 |  |  | $ | 144 |  |  |  |
| Reduction in ABS levels and other | — |  |  | 799 |  |  |  |
| Purchases of property and equipment | (443) |  |  | (351) |  |  |  |
| Proceeds from the disposition of property and equipment | 11 |  |  | 85 |  |  |  |
| Adjusted free cash flow (1) | $ | 593 |  |  | $ | 677 |  |  |  |

[0000866374-22-000035:mdna:150]
(1)Figures in the table may not foot exactly due to rounding.

[0000866374-22-000035:mdna:151]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months.

[0000866374-22-000035:mdna:152]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volume of customer orders.

[0000866374-22-000035:mdna:153]
We maintain global paying service agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. During fiscal years ended March 31, 2022 and 2021, the cumulative payments due to suppliers participating in the programs amounted to approximately $1.3 billion and $1.0 billion, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-22-000035:mdna:154]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to a commercial paper program, and a revolving sale and repurchase of subordinated notes established under the securitization facility, under which there were no borrowings outstanding as of March 31, 2022.

[0000866374-22-000035:mdna:155]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of debt securities, bank debt and lease financings. We also have the ability to sell a designated pool of trade receivables under ABS programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed.

[0000866374-22-000035:mdna:156]
During fiscal year 2022, no accounts receivable had been sold under our ABS programs and we received approximately $1.6 billion from other sales of receivables under our factoring program. During fiscal years 2021, we received approximately $0.6 billion from transfers of receivables under our ABS programs, and $0.8 billion from other sales of receivables. As of March 31, 2022 and 2021, the outstanding balance on receivables sold for cash was $0.6 billion and $0.2 billion, respectively, under our accounts receivable factoring programs, which were removed from accounts receivable balances in our consolidated balance sheets.

[0000866374-22-000035:mdna:157]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In January 2021, we entered into a $2.0 billion credit agreement which matures in January 2026 and consists of a $2.0 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit.

[0000866374-22-000035:mdna:158]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-22-000035:mdna:159]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 4, 2021. During fiscal year 2022, we paid $686 million to repurchase shares under the current and prior repurchase plans at an average price of $17.97 per share. As of March 31, 2022, shares in the aggregate amount of $496 million were available to be repurchased under the current plan.

[0000866374-22-000035:mdna:160]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-22-000035:mdna:161]
Bank borrowings and long-term debt are as follows:

[0000866374-22-000035:mdna:162]
|  | As of March 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.43% | 273 |  |  | 305 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 690 |  |  | 694 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 661 |  |
| 4.875% Notes due May 2030 | 690 |  |  | 694 |  |
| Euro Term Loans | 389 |  |  | 168 |  |
| 3.600% HUF Bonds due December 2031 | 301 |  |  | — |  |
| India Facilities | 84 |  |  | 133 |  |
| Other | 31 |  |  | 51 |  |
| Debt issuance costs | (18) |  |  | (21) |  |
|  | 4,197 |  |  | 3,783 |  |
| Current portion, net of debt issuance costs | (949) |  |  | (268) |  |
| Non-current portion | $ | 3,248 |  |  | $ | 3,515 |  |

[0000866374-22-000035:mdna:163]
Refer to the discussion in note 9 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details of our debt obligations.

[0000866374-22-000035:mdna:164]
In addition. we have leased certain of our property and equipment under finance lease commitments, and certain of our facilities and equipment under operating lease commitments. Future payments due under our debt including finance leases and related interest obligations and operating leases are as follows (amounts may not sum due to rounding):

[0000866374-22-000035:mdna:165]
|  | Total |  | Less Than1 Year |  | 1 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In millions) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings, long-term debt and finance lease obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and long-term debt | $ | 4,215 |  |  | $ | 950 |  |  | $ | 326 |  |  | $ | 1,288 |  |  | $ | 1,651 |  |
| Finance leases | 4 |  |  | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Interest on long-term debt obligations | 744 |  |  | 153 |  |  | 264 |  |  | 154 |  |  | 173 |  |
| Operating leases, net of subleases | 765 |  |  | 148 |  |  | 232 |  |  | 156 |  |  | 229 |  |
| Restructuring costs | 43 |  |  | 42 |  |  | 1 |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 5,771 |  |  | $ | 1,295 |  |  | $ | 825 |  |  | $ | 1,598 |  |  | $ | 2,053 |  |

[0000866374-22-000035:mdna:166]
We have excluded $282 million of liabilities for unrecognized tax benefits from the contractual obligations table as we cannot make a reasonably reliable estimate of the periodic settlements with the respective taxing authorities. See note 15, "Income Taxes" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-22-000035:mdna:167]
We also have outstanding firm purchase orders with certain suppliers for the purchase of inventory, which are not included in the table above. The majority of the purchase obligations are generally short-term in nature. As of March 31, 2022, our purchase obligations over one year were approximately $0.9 billion. We generally do not enter into non-cancelable purchase orders for materials until we receive a corresponding purchase commitment from our customer. Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-22-000035:mdna:168]
On February 1, 2022, we sold Series A Preferred Units, representing a 16.67% interest in Nextracker, to TPG Rise and received proceeds of $487.5 million, net of $12.5 million in transaction costs. Because the Series A Preferred Units are redeemable upon the occurrence of conditions not solely within the control of Flex, we classified the redeemable noncontrolling interest as temporary equity on our consolidated balance sheets.

[0000866374-22-000035:mdna:169]
At TPG Rise’s election, we are required to repurchase all of the outstanding Series A Preferred Units at their liquidation preference, which shall include all contributed but unreturned capital plus accrued but unpaid dividends, at the earlier of certain change in control events and February 2, 2028. Additionally, if Nextracker has not completed a qualified initial public offering prior to February 2, 2027, then TPG Rise may cause us to repurchase all of the outstanding Series A Preferred Units at their fair market value. We do not believe that it is probable as of March 31, 2022, that the noncontrolling interest will become redeemable given the anticipated Qualified Public Offering of Nextracker. See note 7, "Redeemable Noncontrolling Interest" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-22-000035:mdna:170]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-22-000035:mdna:171]
Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for recent accounting pronouncements.

[0000866374-22-000035:mdna:172]
49
