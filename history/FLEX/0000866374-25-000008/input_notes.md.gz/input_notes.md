# FLEX notes — 0000866374-25-000008


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-25-000008:notes:1]
[same as prior period, unchanged from 0000866374-24-000053:notes:1]

[0000866374-25-000008:notes:2]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle and healthcare. As of December 31, 2024, Flex's two operating and reportable segments were as follows:

[0000866374-25-000008:notes:3]
[same as prior period, unchanged from 0000866374-24-000053:notes:3]

[0000866374-25-000008:notes:4]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-25-000008:notes:5]
[same as prior period, unchanged from 0000866374-24-000053:notes:5]

[0000866374-25-000008:notes:6]
[same as prior period, unchanged from 0000866374-24-000053:notes:6]

[0000866374-25-000008:notes:7]
[same as prior period, unchanged from 0000866374-24-000053:notes:7]

[0000866374-25-000008:notes:8]
[same as prior period, unchanged from 0000866374-24-000053:notes:8]

[0000866374-25-000008:notes:9]
[same as prior period, unchanged from 0000866374-24-000053:notes:9]

[0000866374-25-000008:notes:10]
[same as prior period, unchanged from 0000866374-24-000053:notes:10]

[0000866374-25-000008:notes:11]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards, power adapters and chargers).

[0000866374-25-000008:notes:12]
[same as prior period, unchanged from 0000866374-24-000053:notes:12]

[0000866374-25-000008:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2024 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025.

[0000866374-25-000008:notes:14]
The third quarters for fiscal years 2025 and 2024 ended on December 31 of each year and are comprised of 95 and 93 days, respectively. The Company's first three quarters for fiscal years 2025 and 2024 are both comprised of 275 days.

[0000866374-25-000008:notes:15]
[same as prior period, unchanged from 0000866374-24-000053:notes:15]

[0000866374-25-000008:notes:16]
On January 2, 2024, Flex completed its spin-off (the "Spin-off") of its remaining interest in Nextracker Inc. ("Nextracker"). After the Spin-off, Flex no longer consolidates the financial results of Nextracker within its financial results of continuing operations. For all the periods prior to the Spin-off, the financial results of Nextracker are presented as net earnings from discontinued operations in the condensed consolidated statements of operations and unless otherwise indicated Flex's disclosures are presented on a continuing operations basis. The historical statements of comprehensive income and cash flows

[0000866374-25-000008:notes:17]
and the balances related to shareholders' equity have not been revised to reflect the Spin-off. See note 6 "Discontinued Operations" for additional information.

[0000866374-25-000008:notes:18]
[same as prior period, unchanged from 0000866374-24-000053:notes:18]

[0000866374-25-000008:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-25-000008:notes:20]
Recently Issued Accounting Pronouncements

[0000866374-25-000008:notes:21]
In November 2024, the FASB issued ASU 2024-03 "Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses", which requires public entities to disclose specified information about certain costs and expenses. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2028 and will be applied retrospectively to all prior periods presented on its consolidated financial statements. We are currently evaluating the guidance to determine the impact on the Company's disclosures.

[0000866374-25-000008:notes:22]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

[0000866374-25-000008:notes:23]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company has assessed the impact of ASU 2023-07 on its consolidated financial statements and intends to adopt the guidance retrospectively with the updated segment disclosures in the fourth quarter of fiscal year 2025.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-25-000008:notes:24]
[same as prior period, unchanged from 0000866374-24-000053:notes:26]

[0000866374-25-000008:notes:25]
[same as prior period, unchanged from 0000866374-24-000053:notes:27]

[0000866374-25-000008:notes:26]
|  | As of December 31, 2024 |  | As of March 31, 2024 |
|  | (In millions) |
| Raw materials | $ | 4,332 |  |  | $ | 5,045 |  |
| Work-in-progress | 465 |  |  | 623 |  |
| Finished goods | 473 |  |  | 537 |  |
|  | $ | 5,270 |  |  | $ | 6,205 |  |

[0000866374-25-000008:notes:27]
[same as prior period, unchanged from 0000866374-24-000053:notes:29]

[0000866374-25-000008:notes:28]
The Company completed the acquisitions of Crown Technical Systems (“Crown”) and JETCOOL Technologies Inc. (“JetCool”) in the Industrial and CEC reporting units, respectively. Crown’s goodwill is deductible for tax purposes, while JetCool’s is non-deductible. Refer to Note 13 for further details.

[0000866374-25-000008:notes:29]
The following table summarizes the activity in the Company's goodwill during the nine-month period ended December 31, 2024:

[0000866374-25-000008:notes:30]
|  | FAS |  | FRS |  | Total |
|  | (In millions) |
| Balance at March 31, 2024 | $ | 371 |  |  | $ | 764 |  |  | $ | 1,135 |  |
| Acquisitions (1) | 38 |  |  | 170 |  |  | 208 |  |
| Foreign currency translation adjustments | (1) |  |  | (10) |  |  | (11) |  |
| Balance at December 31, 2024 | $ | 408 |  |  | $ | 924 |  |  | $ | 1,332 |  |

[0000866374-25-000008:notes:31]
(1) Represents goodwill of $170 million from the Crown acquisition, $30 million from the JetCool acquisition and $8 million from an acquisition completed in the first quarter of fiscal year 2025.

[0000866374-25-000008:notes:32]
[same as prior period, unchanged from 0000866374-24-000053:notes:31]

[0000866374-25-000008:notes:33]
|  | As of December 31, 2024 |  | As of March 31, 2024 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 405 |  |  | $ | (173) |  |  | $ | 232 |  |  | $ | 316 |  |  | $ | (186) |  |  | $ | 130 |  |
| Licenses and other intangibles | 313 |  |  | (202) |  |  | 111 |  |  | 298 |  |  | (183) |  |  | 115 |  |
| Total | $ | 718 |  |  | $ | (375) |  |  | $ | 343 |  |  | $ | 614 |  |  | $ | (369) |  |  | $ | 245 |  |

[0000866374-25-000008:notes:34]
The gross carrying amounts of intangible assets are removed when fully amortized. During the nine-month period ended December 31, 2024, the total value of intangible assets increased by $147 million as a result of the Company's estimated value of intangible assets from the acquisitions. Refer to Note 13 for further details.

[0000866374-25-000008:notes:35]
[same as prior period, unchanged from 0000866374-24-000053:notes:34]

[0000866374-25-000008:notes:36]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | 24 |  |
| 2026 |  | 72 |  |
| 2027 |  | 61 |  |
| 2028 |  | 45 |  |
| 2029 |  | 42 |  |
| Thereafter |  | 99 |  |
| Total amortization expense |  | $ | 343 |  |

[0000866374-25-000008:notes:37]
[same as prior period, unchanged from 0000866374-24-000053:notes:36]

[0000866374-25-000008:notes:38]
(1)Represents estimated amortization for the remaining fiscal three-month period ending March 31, 2025.

[0000866374-25-000008:notes:39]
[same as prior period, unchanged from 0000866374-24-000053:notes:38]

[0000866374-25-000008:notes:40]
Customer working capital advances were $1.6 billion and $2.2 billion as of December 31, 2024 and March 31, 2024, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-25-000008:notes:41]
[same as prior period, unchanged from 0000866374-24-000053:notes:40]

[0000866374-25-000008:notes:42]
Other non-current assets include deferred tax assets of $662 million and $644 million as of December 31, 2024 and March 31, 2024, respectively.

[0000866374-25-000008:notes:43]
[same as prior period, unchanged from 0000866374-24-000053:notes:42]

[0000866374-25-000008:notes:44]
Other current liabilities include customer-related accruals of $226 million and $277 million as of December 31, 2024 and March 31, 2024, respectively.

[0000866374-25-000008:notes:45]
Supplier Finance Programs

[0000866374-25-000008:notes:46]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due dates. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. We have no economic interest in a supplier’s decision to participate in the supplier finance programs.

[0000866374-25-000008:notes:47]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of December 31, 2024 and March 31, 2024 were $127 million and $123 million, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-25-000008:notes:48]
[same as prior period, unchanged from 0000866374-24-000053:notes:44]

[0000866374-25-000008:notes:49]
[same as prior period, unchanged from 0000866374-24-000053:notes:45]

[0000866374-25-000008:notes:50]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $355 million and $490 million as of December 31, 2024 and March 31, 2024, respectively, of which $314 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-25-000008:notes:51]
[same as prior period, unchanged from 0000866374-24-000053:notes:47]

[0000866374-25-000008:notes:52]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2024 and December 31, 2023, respectively.

[0000866374-25-000008:notes:53]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,849 |  |  | $ | 3,151 |  |  | $ | 8,646 |  |  | $ | 9,867 |  |
| Over time | 750 |  |  | 314 |  |  | 1,924 |  |  | 817 |  |
| Total | 3,599 |  |  | 3,465 |  |  | 10,570 |  |  | 10,684 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,960 |  |  | 2,793 |  |  | 6,830 |  |  | 9,070 |  |
| Over time | 997 |  |  | 163 |  |  | 2,015 |  |  | 492 |  |
| Total | 2,957 |  |  | 2,956 |  |  | 8,845 |  |  | 9,562 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,809 |  |  | 5,944 |  |  | 15,476 |  |  | 18,937 |  |
| Over time | 1,747 |  |  | 477 |  |  | 3,939 |  |  | 1,309 |  |
| Total | $ | 6,556 |  |  | $ | 6,421 |  |  | $ | 19,415 |  |  | $ | 20,246 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-25-000008:notes:54]
[same as prior period, unchanged from 0000866374-24-000053:notes:50]

[0000866374-25-000008:notes:55]
[same as prior period, unchanged from 0000866374-24-000053:notes:51]

[0000866374-25-000008:notes:56]
[same as prior period, unchanged from 0000866374-24-000053:notes:52]

[0000866374-25-000008:notes:57]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
|  | (In millions) |
| Cost of sales | $ | 9 |  |  | $ | 7 |  |  | $ | 25 |  |  | $ | 21 |  |
| Selling, general and administrative expenses | 24 |  |  | 19 |  |  | 68 |  |  | 65 |  |
| Total share-based compensation expense | $ | 33 |  |  | $ | 26 |  |  | $ | 93 |  |  | $ | 86 |  |

[0000866374-25-000008:notes:58]
[same as prior period, unchanged from 0000866374-24-000053:notes:54]

[0000866374-25-000008:notes:59]
During the nine-month period ended December 31, 2024, the Company granted approximately 4.6 million restricted share unit ("RSU") awards. Of this amount, approximately 2.9 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, and with an average grant date price of $31.88 per award. In addition, approximately 0.7 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $31.04 per award. These performance-based RSUs include awards tied to the Company's adjusted earnings per share growth and awards tied to operating profit goals. The number of shares that will ultimately vest will range from zero up to a maximum of approximately 1.2 million based on the level of achievement of these performance conditions. The awards will cliff vest after a period of one to three years, depending on the specific performance metrics, to the extent such performance conditions have been met. Further, approximately 0.3 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $42.36 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 0.6 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met. Finally, the remaining balance of approximately 0.7 million represents the number of shares issued upon the vesting of RSU awards above target levels based on the achievement of certain market and performance conditions for awards granted in fiscal year 2022. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-25-000008:notes:60]
As of December 31, 2024, approximately 12.3 million unvested RSU awards under the 2017 Plan were outstanding, of which vesting for a targeted amount of approximately 1.2 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of approximately 1.6 million shares is contingent on meeting certain performance

[0000866374-25-000008:notes:61]
conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to approximately 2.4 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to approximately 3.0 million based on the achievement levels. During the nine-month period ended December 31, 2024, approximately 1.6 million shares vested in connection with the awards with market and performance conditions granted in fiscal year 2022.

[0000866374-25-000008:notes:62]
As of December 31, 2024, total unrecognized compensation expense related to unvested RSU awards under the 2017 Plan was approximately $189 million, and will be recognized over a weighted-average remaining vesting period of 2.0 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-25-000008:notes:63]
[same as prior period, unchanged from 0000866374-24-000053:notes:59]

[0000866374-25-000008:notes:64]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
|  | (In millions, except per share amounts) |
| Numerator: |  |  |  |  |  |  |  |
| Net income from continuing operations | $ | 263 |  |  | $ | 129 |  |  | $ | 616 |  |  | $ | 477 |  |
| Net income from discontinued operations, net of tax | — |  |  | 104 |  |  | — |  |  | 373 |  |
| Less: Net income attributable to noncontrolling interest | — |  |  | 36 |  |  | — |  |  | 239 |  |
| Net income from discontinued operations attributable to Flex Ltd. | — |  |  | 68 |  |  | — |  |  | 134 |  |
| Total net income attributable to Flex Ltd. | $ | 263 |  |  | $ | 197 |  |  | $ | 616 |  |  | $ | 611 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding - basic | 387 |  |  | 431 |  |  | 394 |  |  | 440 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 7 |  |  | 5 |  |  | 7 |  |  | 6 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding - diluted | 394 |  |  | 436 |  |  | 401 |  |  | 446 |  |
| Earnings per share - basic |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.68 |  |  | $ | 0.30 |  |  | $ | 1.56 |  |  | $ | 1.08 |  |
| Discontinued operations, net of tax | — |  |  | 0.16 |  |  | — |  |  | 0.31 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.68 |  |  | $ | 0.46 |  |  | $ | 1.56 |  |  | $ | 1.39 |  |
| Earnings per share - diluted |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.67 |  |  | $ | 0.30 |  |  | $ | 1.54 |  |  | $ | 1.07 |  |
| Discontinued operations, net of tax | — |  |  | 0.15 |  |  | — |  |  | 0.30 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.67 |  |  | $ | 0.45 |  |  | $ | 1.54 |  |  | $ | 1.37 |  |

[0000866374-25-000008:notes:65]
(1)An immaterial amount of RSU awards for both the three and nine-month periods ended December 31, 2024 and December 31, 2023, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000866374-25-000008:notes:66]
[same as prior period, unchanged from 0000866374-24-000053:notes:62]

[0000866374-25-000008:notes:67]
The key components of net income from discontinued operations for the three and nine-month periods ended December 31, 2023 were as follows:

[0000866374-25-000008:notes:68]
|  |  | Three-month period ended |  | Nine-month period ended |
|  |  | December 31, 2023 |  | December 31, 2023 |
|  |  | (In millions) |
| Net sales (1) |  | $ | 682 |  |  | $ | 1,664 |  |
| Cost of sales (1) |  | 473 |  |  | 1,198 |  |
| Gross Profit |  | 209 |  |  | 466 |  |
| Selling, general and administrative expenses |  | 59 |  |  | 145 |  |
| Operating income |  | 150 |  |  | 321 |  |
| Interest and other, net |  | (5) |  |  | (1) |  |
| Income before income taxes |  | 155 |  |  | 322 |  |
| Provision for/ (Benefit from) income taxes |  | 51 |  |  | (51) |  |
| Net income from discontinued operations |  | 104 |  |  | 373 |  |
| Net income from discontinued operations attributable to noncontrolling interest (2) |  | 36 |  |  | 239 |  |
| Net income from discontinued operations attributable to Flex Ltd. |  | $ | 68 |  |  | $ | 134 |  |

[0000866374-25-000008:notes:69]
(1)    Both net sales and cost of sales from discontinued operations includes the effect of intercompany transactions that were eliminated from Flex's condensed consolidated statements of operations of approximately $29 million and $99 million for the three and nine-month periods ended December 31, 2023, respectively.

[0000866374-25-000008:notes:70]
(2)    Net income from discontinued operations attributable to noncontrolling interest represented a share of pre-tax income of $76 million and $145 million and of income tax expense of $40 million and $46 million for the three and nine-month periods ended December 31, 2023. As such, pre-tax income attributable to Flex Ltd. from discontinued operations was $79 million and $177 million for the same periods. In addition, during the nine-month period ended December 31, 2023, a $140 million deferred tax asset was recorded, with an offsetting entry to income tax benefit fully attributable to noncontrolling interest in connection with Nextracker's follow-on public offering.

[0000866374-25-000008:notes:71]
Details of cash flows from discontinued operations for the nine-month period ended December 31, 2023 were as follows:

[0000866374-25-000008:notes:72]
|  |  |  |  | Nine-month period ended |
|  |  |  |  | December 31, 2023 |
|  |  |  | (In millions) |
| Net cash provided by discontinued operations operating activities (1) |  |  |  | $ | 317 |  |
| Net cash used in discontinued operations investing activities |  |  |  | (4) |  |

[0000866374-25-000008:notes:73]
(1)    Cash flows from discontinued operations operating activities includes an inflow from intercompany transactions that were eliminated from Flex's consolidated operations of $54 million for the nine-month period ended December 31, 2023.


## us-gaap:DebtDisclosureTextBlock

[0000866374-25-000008:notes:74]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2024 and March 31, 2024 are as follows:

[0000866374-25-000008:notes:75]
|  | Maturity Date |  | As of December 31, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 679 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 677 |  |  | 681 |  |
| 5.250% Notes (1) (2) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 254 |  |  | 274 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (16) |  |  | (15) |  |
|  |  |  | 3,679 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (532) |  |  | — |  |
| Non-current portion |  |  | $ | 3,147 |  |  | $ | 3,261 |  |

[0000866374-25-000008:notes:76]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

[0000866374-25-000008:notes:77]
(2)In August 2024, the Company issued $500 million of 5.250% Notes due 2032. The Company received proceeds of approximately $496 million, net of discount and certain issuance costs.

[0000866374-25-000008:notes:78]
(3)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

[0000866374-25-000008:notes:79]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.5% as of December 31, 2024 and March 31, 2024, respectively.

[0000866374-25-000008:notes:80]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2024 are as follows:

[0000866374-25-000008:notes:81]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | — |  |
| 2026 |  | 1,211 |  |
| 2027 |  | — |  |
| 2028 |  | 398 |  |
| 2029 |  | 25 |  |
| Thereafter |  | 2,061 |  |
| Total |  | $ | 3,695 |  |

[0000866374-25-000008:notes:82]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2025.


## flex:InterestAndOtherNetTextBlock

[0000866374-25-000008:notes:83]
INTEREST EXPENSE AND INTEREST INCOME
Interest expense and interest income for the three and nine-month periods ended December 31, 2024 and December 31, 2023 are composed of the following:

[0000866374-25-000008:notes:84]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 50 |  |  | $ | 39 |  |  | $ | 139 |  |  | $ | 121 |  |
| AR sale program related expenses | 7 |  |  | 11 |  |  | 27 |  |  | 34 |  |
| Interest income | (16) |  |  | (13) |  |  | (48) |  |  | (44) |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-25-000008:notes:85]
[same as prior period, unchanged from 0000866374-24-000053:notes:84]

[0000866374-25-000008:notes:86]
[same as prior period, unchanged from 0000866374-24-000053:notes:85]

[0000866374-25-000008:notes:87]
As of December 31, 2024, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $8.1 billion as summarized below:

[0000866374-25-000008:notes:88]
|  |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  | p |
| HUF |  | $ | 403 |  |  | $ | — |  |
| MXN |  | 377 |  |  | — |  |
| Other |  | 573 |  |  | 5 |  |
|  |  | 1,353 |  |  | 5 |  |
| Other Foreign Currency Contracts |  |  |  |  |
| CNY |  | 1,080 |  |  | 875 |  |
| EUR |  | 775 |  |  | 646 |  |
| BRL |  | — |  |  | 316 |  |
| MXN |  | 431 |  |  | 350 |  |
| MYR |  | 309 |  |  | 159 |  |
| Other |  | 922 |  |  | 882 |  |
|  |  | 3,517 |  |  | 3,228 |  |
| Total Notional Contract Value in USD |  | $ | 4,870 |  |  | $ | 3,233 |  |

[0000866374-25-000008:notes:89]
As of December 31, 2024, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the condensed consolidated statements of operations. As of December 31, 2024 and March 31, 2024, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. The deferred loss was $21 million as of December 31, 2024, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations over the next twelve-month period, except for the USD HUF cross currency swaps.

[0000866374-25-000008:notes:90]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031. The fair value of the cross currency swaps was included in other current assets and other non-current liabilities as of December 31, 2024, and March 31, 2024. The changes in fair value of the USD HUF cross currency swaps are recognized in other comprehensive income (loss) and accumulated in accumulated other comprehensive loss. Corresponding amounts are subsequently reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-25-000008:notes:91]
[same as prior period, unchanged from 0000866374-24-000053:notes:91]

[0000866374-25-000008:notes:92]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31,2024 |  | March 31,2024 |  | Balance SheetLocation |  | December 31,2024 |  | March 31,2024 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 9 |  |  | $ | 45 |  |  | Other current liabilities |  | $ | (45) |  |  | $ | (9) |  |
| Foreign currency contracts | Other non-current assets |  | $ | — |  |  | $ | — |  |  | Other liabilities |  | $ | (53) |  |  | $ | (33) |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 25 |  |  | $ | 14 |  |  | Other current liabilities |  | $ | (14) |  |  | $ | (10) |  |

[0000866374-25-000008:notes:93]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with certain counterparties. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-25-000008:notes:94]
[same as prior period, unchanged from 0000866374-24-000053:notes:94]

[0000866374-25-000008:notes:95]
|  | Three-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (13) |  |  | $ | (160) |  |  | $ | (173) |  |  | $ | (13) |  |  | $ | (227) |  |  | $ | (240) |  |
| Other comprehensive gain (loss) before reclassifications | (65) |  |  | (85) |  |  | (150) |  |  | 63 |  |  | 58 |  |  | 121 |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | 44 |  |  | — |  |  | 44 |  |  | (24) |  |  | 1 |  |  | (23) |  |
| Net current-period other comprehensive gain (loss) | (21) |  |  | (85) |  |  | (106) |  |  | 39 |  |  | 59 |  |  | 98 |  |
| Ending balance | $ | (34) |  |  | $ | (245) |  |  | $ | (279) |  |  | $ | 26 |  |  | $ | (168) |  |  | $ | (142) |  |

[0000866374-25-000008:notes:96]
|  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | 4 |  |  | $ | (199) |  |  | $ | (195) |  |  | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |
| Other comprehensive gain (loss) before reclassifications | (87) |  |  | (46) |  |  | (133) |  |  | 126 |  |  | 11 |  |  | 137 |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | 49 |  |  | — |  |  | 49 |  |  | (86) |  |  | 1 |  |  | (85) |  |
| Net current-period other comprehensive gain (loss) | (38) |  |  | (46) |  |  | (84) |  |  | 40 |  |  | 12 |  |  | 52 |  |
| Ending balance | $ | (34) |  |  | $ | (245) |  |  | $ | (279) |  |  | $ | 26 |  |  | $ | (168) |  |  | $ | (142) |  |

[0000866374-25-000008:notes:97]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and nine-month periods ended December 31, 2024 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in accumulated other comprehensive loss for the three-month periods ended December 31, 2024 and December 31, 2023 were $5 million and $7 million, respectively. The tax impacts on the changes in accumulated other comprehensive loss for the nine-month periods ended December 31, 2024 and December 31, 2023 were $16 million and $2 million, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-25-000008:notes:98]
TRADE RECEIVABLES SALES PROGRAMSThe Company sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.7 billion and $0.8 billion as of December 31, 2024 and March 31, 2024, respectively. For the nine-month periods ended December 31, 2024 and December 31, 2023, total accounts receivable sold to certain third-party banking institutions was approximately $3.0 billion and $2.6 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-25-000008:notes:99]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES 
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-25-000008:notes:100]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of December 31, 2024 and March 31, 2024.

[0000866374-25-000008:notes:101]
[same as prior period, unchanged from 0000866374-24-000053:notes:102]

[0000866374-25-000008:notes:102]
[same as prior period, unchanged from 0000866374-24-000053:notes:103]

[0000866374-25-000008:notes:103]
[same as prior period, unchanged from 0000866374-24-000053:notes:104]

[0000866374-25-000008:notes:104]
[same as prior period, unchanged from 0000866374-24-000053:notes:105]

[0000866374-25-000008:notes:105]
[same as prior period, unchanged from 0000866374-24-000053:notes:106]

[0000866374-25-000008:notes:106]
The Company has accrued for contingent consideration related to its acquisition of JetCool, classified as a level 3 measurement in the fair value hierarchy due to significant unobservable inputs. Fair value is determined using internal cash flow models that incorporate unobservable inputs, including the probability of achieving performance milestones. As of December 31, 2024 and March 31, 2024, the balances of contingent consideration were $5 million and zero, respectively.

[0000866374-25-000008:notes:107]
The significant inputs include the Company's probability assessments of expected future revenue during the earn-out periods, associated volatility, and a discount rate reflecting uncertainties in the obligation consistent with the terms of the purchase agreement. Significant decreases in expected revenue, or increases in the discount rate or volatility, would reduce fair value estimates. The interrelationship between these inputs is not considered significant.

[0000866374-25-000008:notes:108]
During the three-month periods ended December 31, 2024, and December 31, 2023, there were no other additions to the accrual, payments, fair value adjustments, or unrealized gains or losses included in earnings.

[0000866374-25-000008:notes:109]
There were no transfers between levels in the fair value hierarchy during the nine-month periods ended December 31, 2024 and December 31, 2023.

[0000866374-25-000008:notes:110]
[same as prior period, unchanged from 0000866374-24-000053:notes:108]

[0000866374-25-000008:notes:111]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of December 31, 2024 and March 31, 2024:

[0000866374-25-000008:notes:112]
|  | Fair Value Measurements as of December 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,329 |  |  | $ | — |  |  | $ | 1,329 |  |
| Foreign currency contracts (Note 9) | — |  |  | 34 |  |  | — |  |  | 34 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (112) |  |  | $ | — |  |  | $ | (112) |  |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (5) |  |  | (5) |  |
|  | Fair Value Measurements as of March 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 759 |  |  | $ | — |  |  | $ | 759 |  |
| Foreign currency contracts (Note 9) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (52) |  |  | $ | — |  |  | $ | (52) |  |

[0000866374-25-000008:notes:113]
[same as prior period, unchanged from 0000866374-24-000053:notes:111]

[0000866374-25-000008:notes:114]
[same as prior period, unchanged from 0000866374-24-000053:notes:112]

[0000866374-25-000008:notes:115]
|  | As of December 31, 2024 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | 532 |  |  | $ | 532 |  |  | $ | 584 |  |  | $ | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 679 |  |  | 670 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 406 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 656 |  |  | 644 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 677 |  |  | 662 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 494 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 254 |  |  | 203 |  |  | 274 |  |  | 219 |  |  | Level 2 |

[0000866374-25-000008:notes:116]
[same as prior period, unchanged from 0000866374-24-000053:notes:114]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-25-000008:notes:117]
BUSINESS ACQUISITIONS AND DIVESTITURE
The Company completed two acquisitions in the third quarter of fiscal year 2025, accounted for as business combinations. The results of the acquired businesses are included in the Company’s condensed consolidated financial statements from their respective acquisition dates. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill. Pro-forma results of operations have not been presented because the effects were not material to the Company’s condensed consolidated financial results for all periods presented. The Company is in the process of evaluating the fair value of the assets and liabilities related to these acquisitions. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisitions. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the respective measurement periods.

[0000866374-25-000008:notes:118]
Acquisition of Crown

[0000866374-25-000008:notes:119]
On November 19, 2024, the Company completed the business acquisition of 100% ownership of Crown, a U.S. leader in critical power solutions for a total estimated purchase consideration of $317 million, including cash of $313 million and a $4 million estimate of customary closing adjustments. The acquisition adds complementary capabilities to our existing portfolio in the United States, primarily strengthening our industrial power solutions. Crown is included in the Industrial reporting unit

[0000866374-25-000008:notes:120]
within the FRS segment. The following represents the Company's initial allocation of the total purchase price to the acquired assets and liabilities of Crown (in millions):

[0000866374-25-000008:notes:121]
| Current Assets: |  |
| Cash | $ | 5 |  |
| Accounts receivable | 23 |  |
| Inventory | 10 |  |
| Other current assets | 2 |  |
| Total current assets | 40 |  |
| Property and equipment | 1 |  |
| Operating lease right-of-use assets | 7 |  |
| Intangible assets | 127 |  |
| Goodwill | 170 |  |
| Total assets | $ | 345 |  |
| Current liabilities: |  |
| Accounts payable | $ | 4 |  |
| Accrued liabilities & other current liabilities | 18 |  |
| Total current liabilities | 22 |  |
| Operating lease liabilities, non-current | 6 |  |
| Total aggregate purchase price | $ | 317 |  |

[0000866374-25-000008:notes:122]
The intangible assets of $127 million is comprised of customer related intangible assets of $83 million and licenses and other intangible assets such as trade names and patented technology of $44 million. Customer related assets will be amortized over a weighted-average estimated useful life of 12.6 years while licensed and other intangibles will be amortized over a weighted-average estimated useful life of 10.0 years.

[0000866374-25-000008:notes:123]
Acquisition of JetCool

[0000866374-25-000008:notes:124]
On November 14, 2024, the Company acquired 100% ownership of JetCool, a provider of liquid cooling solutions tailored for the data center market, for approximately $42 million in cash, a deemed settled pre-existing loan from Flex of approximately $5 million, and $5 million of contingent consideration for a total estimated purchase price of $52 million. Assets acquired totaled $59 million (including approximately $21 million in intangibles and $30 million in goodwill), with $7 million in liabilities assumed in addition to an approximately $5 million estimated liability for contingent consideration. The intangible asset relates to developed technology and will be amortized over a weighted-average estimated useful life of 6.5 years. JetCool is included in the Communications, Enterprise and Cloud reporting unit within the FAS segment.

[0000866374-25-000008:notes:125]
Divestiture

[0000866374-25-000008:notes:126]
As of December 31, 2024, the Company has classified the assets and liabilities of one of its European sites as held for sale, following the execution of an agreement to sell the site during the third quarter of fiscal year 2025. The held for sale balances are reported in other current assets, other non-current assets, other current liabilities and other non-current liabilities on the condensed consolidated balance sheet. A loss of $5 million was recorded in other charges (income), net upon classification as held for sale, in order to reflect the carrying value of the disposed group at the level of expected proceeds. The held for sale balances and expected proceeds are not material to Flex. The transaction is anticipated to close within twelve months.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-25-000008:notes:127]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-25-000008:notes:128]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a

[0000866374-25-000008:notes:129]
material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-25-000008:notes:130]
The Company is currently involved in a commercial dispute related to a construction matter with related production objectives. Management assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment recognized $50 million in Selling, general and administrative expenses in the fourth quarter of the fiscal year ended March 31, 2024 as an accrual. The ultimate resolution of this dispute is uncertain, and the actual outcome may differ from the estimates made by management. Changes in circumstances or additional information may impact the Company’s assessment of its loss and could result in adjustments to the $50 million accrual, however, management currently believes that the resolution of this dispute will not have a material effect on the Company’s financial position, results of operations or cash flows. The Company will continue to monitor developments related to this matter and will adjust its accrual and disclosures accordingly in future reporting periods as additional information becomes available.

[0000866374-25-000008:notes:131]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. Two remain, where the Company was unsuccessful at the administrative level and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 37 million Brazilian reals (approximately USD $6 million). The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 60 million Brazilian reals (approximately USD $10 million). The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-25-000008:notes:132]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $285 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. In the quarter ended December 31, 2024, approximately $118 million of the approximate $285 million assessment was abated by the Tax Authority, leaving approximately $167 million remaining. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-25-000008:notes:133]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material effect on the Company’s financial position, results of operations or cash flows.

[0000866374-25-000008:notes:134]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-25-000008:notes:135]
SHARE REPURCHASES 
During the three and nine-month periods ended December 31, 2024, the Company repurchased 5.5 million and 30.5 million shares at an aggregate purchase price of $201 million and $958 million, respectively, and retired all of these shares.

[0000866374-25-000008:notes:136]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.7 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 8, 2024. As of December 31, 2024, shares in the aggregate amount of $1.3 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-25-000008:notes:137]
[same as prior period, unchanged from 0000866374-24-000053:notes:125]

[0000866374-25-000008:notes:138]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, customer related asset impairment (recoveries), legal

[0000866374-25-000008:notes:139]
and other, interest expense, and other charges (income), net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-25-000008:notes:140]
[same as prior period, unchanged from 0000866374-24-000053:notes:128]

[0000866374-25-000008:notes:141]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,599 |  |  | $ | 3,465 |  |  | $ | 10,570 |  |  | $ | 10,684 |  |
| Flex Reliability Solutions | 2,957 |  |  | 2,956 |  |  | 8,845 |  |  | 9,562 |  |
|  | $ | 6,556 |  |  | $ | 6,421 |  |  | $ | 19,415 |  |  | $ | 20,246 |  |
| Segment income and reconciliation of income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 227 |  |  | $ | 175 |  |  | $ | 624 |  |  | $ | 488 |  |
| Flex Reliability Solutions | 198 |  |  | 159 |  |  | 504 |  |  | 495 |  |
| Corporate and Other | (26) |  |  | (20) |  |  | (65) |  |  | (49) |  |
| Total segment income | 399 |  |  | 314 |  |  | 1,063 |  |  | 934 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 17 |  |  | 17 |  |  | 49 |  |  | 54 |  |
| Stock-based compensation | 33 |  |  | 26 |  |  | 93 |  |  | 86 |  |
| Restructuring charges | 12 |  |  | 73 |  |  | 54 |  |  | 97 |  |
| Legal and other (1) | 5 |  |  | — |  |  | 5 |  |  | 3 |  |
| Customer related asset impairment (recoveries) (2) | (2) |  |  | — |  |  | (2) |  |  | — |  |
| Interest expense | 57 |  |  | 50 |  |  | 166 |  |  | 155 |  |
| Interest income | 16 |  |  | 13 |  |  | 48 |  |  | 44 |  |
| Other charges (income), net | 5 |  |  | 9 |  |  | 2 |  |  | 34 |  |
| Income from continuing operations before income taxes | $ | 288 |  |  | $ | 152 |  |  | $ | 744 |  |  | $ | 549 |  |

[0000866374-25-000008:notes:142]
(1)Legal and other consists of costs not directly related to core business results and including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and asset impairment. During the first three quarters of fiscal year 2025 and 2024, the Company accrued for a $5 million asset impairment and $3 million in loss contingencies where losses were considered probable and estimable, respectively.

[0000866374-25-000008:notes:143]
(2)Customer related asset impairments (recoveries) may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. During the three and nine-month periods ended December 31, 2024, the Company recognized approximately $2 million of customer related asset recoveries.

[0000866374-25-000008:notes:144]
[same as prior period, unchanged from 0000866374-24-000053:notes:131]

[0000866374-25-000008:notes:145]
[same as prior period, unchanged from 0000866374-24-000053:notes:132]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-25-000008:notes:146]
RESTRUCTURING CHARGES
During the three and nine-month periods ended December 31, 2024, the Company recognized approximately $12 million and $55 million of restructuring charges, respectively, most of which related to employee severance.

[0000866374-25-000008:notes:147]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of December 31, 2024 for charges incurred during the nine-month period ended December 31, 2024:

[0000866374-25-000008:notes:148]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2024 | $ | 77 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 80 |  |
| Provision for net charges incurred during the nine-month period ended December 31, 2024 | 54 |  |  | 1 |  |  | — |  |  | 55 |  |
| Cash payments during the nine-month period ended December 31, 2024 | (50) |  |  | — |  |  | — |  |  | (50) |  |
| Non-cash reductions during the nine-month period ended December 31, 2024 (1) | (28) |  |  | (1) |  |  | (3) |  |  | (32) |  |
| Balance as of December 31, 2024 | 53 |  |  | — |  |  | — |  |  | 53 |  |
| Less: Current portion (classified as other current liabilities) | 53 |  |  | — |  |  | — |  |  | 53 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000866374-25-000008:notes:149]
(1) The non-cash adjustments predominantly relate to the transfer of liabilities to held for sale. Refer to Note 13 for further details.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000866374-25-000008:notes:150]
On November 6, 2024, Michael P. Hartung, President and Chief Commercial Officer, adopted a trading plan that provides for the sale of up to 64,807 ordinary shares of the Company. The plan will terminate on August 29, 2025, subject to early termination for certain specified events set forth in the plan.

[0000866374-25-000008:notes:151]
On December 5, 2024, Scott Offer, Executive Vice President and General Counsel, adopted a trading plan that provides for the sale of up to 96,852 ordinary shares of the Company. The plan will terminate on June 23, 2025, subject to early termination for certain specified events set forth in the plan.

[0000866374-25-000008:notes:152]
On December 6, 2024, Revathi Advaithi, Chief Executive Officer and a director, adopted a trading plan that provides for the sale of up to 264,000 ordinary shares of the Company. The plan will terminate on December 8, 2025, subject to early termination for certain specified events set forth in the plan.

[0000866374-25-000008:notes:153]
On December 9, 2024, Hooi Tan, President, Global Operations and Components, adopted a trading plan that provides for the sale of up to 50,000 ordinary shares of the Company. The plan will terminate on December 5, 2025, subject to early termination for certain specified events set forth in the plan.
