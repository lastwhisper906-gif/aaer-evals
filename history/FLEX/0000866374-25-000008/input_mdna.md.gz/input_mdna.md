# FLEX MD&A — 0000866374-25-000008


## mdna

[0000866374-25-000008:mdna:1]
[same as prior period, unchanged from 0000866374-24-000053:mdna:1]

[0000866374-25-000008:mdna:2]
[same as prior period, unchanged from 0000866374-24-000053:mdna:2]

[0000866374-25-000008:mdna:3]
[same as prior period, unchanged from 0000866374-24-000053:mdna:3]

[0000866374-25-000008:mdna:4]
We are the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we support our customers' entire product lifecycle with a broad array of services in every major region. Our full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. We partner with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle and healthcare. As of December 31, 2024, our two operating and reportable segments were as follows:

[0000866374-25-000008:mdna:5]
[same as prior period, unchanged from 0000866374-24-000053:mdna:5]

[0000866374-25-000008:mdna:6]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-25-000008:mdna:7]
[same as prior period, unchanged from 0000866374-24-000053:mdna:7]

[0000866374-25-000008:mdna:8]
[same as prior period, unchanged from 0000866374-24-000053:mdna:8]

[0000866374-25-000008:mdna:9]
[same as prior period, unchanged from 0000866374-24-000053:mdna:9]

[0000866374-25-000008:mdna:10]
[same as prior period, unchanged from 0000866374-24-000053:mdna:10]

[0000866374-25-000008:mdna:11]
[same as prior period, unchanged from 0000866374-24-000053:mdna:11]

[0000866374-25-000008:mdna:12]
[same as prior period, unchanged from 0000866374-24-000053:mdna:12]

[0000866374-25-000008:mdna:13]
[same as prior period, unchanged from 0000866374-24-000053:mdna:13]

[0000866374-25-000008:mdna:14]
[same as prior period, unchanged from 0000866374-24-000053:mdna:14]

[0000866374-25-000008:mdna:15]
[same as prior period, unchanged from 0000866374-24-000053:mdna:15]

[0000866374-25-000008:mdna:16]
27

[0000866374-25-000008:mdna:17]
[same as prior period, unchanged from 0000866374-24-000053:mdna:17]

[0000866374-25-000008:mdna:18]
[same as prior period, unchanged from 0000866374-24-000053:mdna:18]

[0000866374-25-000008:mdna:19]
[same as prior period, unchanged from 0000866374-24-000053:mdna:19]

[0000866374-25-000008:mdna:20]
Component shortages experienced in the recent past have largely subsided, however, logistical constraints exist which have increased freight costs. We continue to monitor potential supply chain disruptions, including as a result of emerging and evolving geopolitical conflicts and tensions. Refer to “Risk Factors - Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, have in the past affected, and may in the future affect, our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory.” and “- Global economic conditions, including inflationary pressures, currency volatility, slower growth or recession, higher interest rates, geopolitical uncertainty (including arising from the ongoing conflict between Russia and Ukraine and the Israel-Hamas war) and instability in financial markets may adversely affect our business, results of operations, financial condition, and access to capital markets.” as disclosed in Part I, “Item 1A. Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0000866374-25-000008:mdna:21]
[same as prior period, unchanged from 0000866374-24-000053:mdna:21]

[0000866374-25-000008:mdna:22]
We continue to monitor and respond to the conflict in Ukraine and the associated sanctions and other restrictions. We also are monitoring and responding to the ongoing conflicts in the Middle East, including the Israel-Hamas war. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine and Israel. The full impact of the conflicts on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflicts and their impact on regional and global economic conditions. We will continue to monitor the conflicts and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-25-000008:mdna:23]
[same as prior period, unchanged from 0000866374-24-000053:mdna:23]

[0000866374-25-000008:mdna:24]
We are one of the world's largest providers of global supply chain solutions, with revenues of $19.4 billion for the nine-month period ended December 31, 2024 and $26.4 billion in the fiscal year ended March 31, 2024. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of approximately 100 facilities in approximately 30 countries across four continents. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites:

[0000866374-25-000008:mdna:25]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 3,195 |  |  | 49 | % |  | $ | 3,080 |  |  | 48 | % |  | $ | 9,360 |  |  | 48 | % |  | $ | 9,254 |  |  | 46 | % |
| Asia | 1,998 |  |  | 30 | % |  | 2,006 |  |  | 31 | % |  | 5,925 |  |  | 31 | % |  | 6,705 |  |  | 33 | % |
| Europe | 1,363 |  |  | 21 | % |  | 1,335 |  |  | 21 | % |  | 4,130 |  |  | 21 | % |  | 4,287 |  |  | 21 | % |
|  | $ | 6,556 |  |  |  |  | $ | 6,421 |  |  |  |  | $ | 19,415 |  |  |  |  | $ | 20,246 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 1,721 |  |  | 26 | % |  | $ | 1,727 |  |  | 27 | % |  | $ | 5,042 |  |  | 26 | % |  | $ | 5,306 |  |  | 26 | % |
| China | 1,101 |  |  | 17 | % |  | 1,181 |  |  | 18 | % |  | 3,278 |  |  | 17 | % |  | 3,975 |  |  | 20 | % |
| U.S. | 1,071 |  |  | 16 | % |  | 922 |  |  | 14 | % |  | 3,053 |  |  | 16 | % |  | 2,745 |  |  | 14 | % |
| Malaysia | 630 |  |  | 10 | % |  | 500 |  |  | 8 | % |  | 1,829 |  |  | 9 | % |  | 1,601 |  |  | 8 | % |
| Brazil | 386 |  |  | 6 | % |  | 409 |  |  | 6 | % |  | 1,198 |  |  | 6 | % |  | 1,146 |  |  | 6 | % |
| Hungary | 313 |  |  | 5 | % |  | 317 |  |  | 5 | % |  | 984 |  |  | 5 | % |  | 1,031 |  |  | 5 | % |
| Other | 1,334 |  |  | 20 | % |  | 1,365 |  |  | 22 | % |  | 4,031 |  |  | 21 | % |  | 4,442 |  |  | 21 | % |
|  | $ | 6,556 |  |  |  |  | $ | 6,421 |  |  |  |  | $ | 19,415 |  |  |  |  | $ | 20,246 |  |  |  |

[0000866374-25-000008:mdna:26]
|  | As of |  | As of |
| Property and equipment, net: | December 31, 2024 |  | March 31, 2024 |
|  | (In millions) |
| Mexico | $ | 815 |  |  | 36 | % |  | $ | 793 |  |  | 35 | % |
| U.S. | 318 |  |  | 14 | % |  | 334 |  |  | 15 | % |
| China | 293 |  |  | 13 | % |  | 307 |  |  | 14 | % |
| Malaysia | 149 |  |  | 7 | % |  | 142 |  |  | 6 | % |
| Hungary | 133 |  |  | 6 | % |  | 124 |  |  | 5 | % |
| Brazil | 85 |  |  | 4 | % |  | 88 |  |  | 4 | % |
| Other | 448 |  |  | 20 | % |  | 481 |  |  | 21 | % |
|  | $ | 2,241 |  |  |  |  | $ | 2,269 |  |  |  |

[0000866374-25-000008:mdna:27]
[same as prior period, unchanged from 0000866374-24-000053:mdna:27]

[0000866374-25-000008:mdna:28]
[same as prior period, unchanged from 0000866374-24-000053:mdna:28]

[0000866374-25-000008:mdna:29]
[same as prior period, unchanged from 0000866374-24-000053:mdna:29]

[0000866374-25-000008:mdna:30]
29

[0000866374-25-000008:mdna:31]
[same as prior period, unchanged from 0000866374-24-000053:mdna:31]

[0000866374-25-000008:mdna:32]
•changes in trade regulations and treaties, trade policies and tariffs, the potential impacts of which, including increased cost of goods sold, decreased margins, increased pricing for customers, and reduced demand, we may be unable to mitigate depending on their scope and duration;

[0000866374-25-000008:mdna:33]
•the impacts on our business due to supply chain issues, including transportation disruptions, increased freight costs, and other constraints;

[0000866374-25-000008:mdna:34]
[same as prior period, unchanged from 0000866374-24-000053:mdna:32]

[0000866374-25-000008:mdna:35]
[same as prior period, unchanged from 0000866374-24-000053:mdna:33]

[0000866374-25-000008:mdna:36]
[same as prior period, unchanged from 0000866374-24-000053:mdna:34]

[0000866374-25-000008:mdna:37]
[same as prior period, unchanged from 0000866374-24-000053:mdna:35]

[0000866374-25-000008:mdna:38]
[same as prior period, unchanged from 0000866374-24-000053:mdna:37]

[0000866374-25-000008:mdna:39]
[same as prior period, unchanged from 0000866374-24-000053:mdna:38]

[0000866374-25-000008:mdna:40]
•changes in tax legislation; and

[0000866374-25-000008:mdna:41]
[same as prior period, unchanged from 0000866374-24-000053:mdna:41]

[0000866374-25-000008:mdna:42]
[same as prior period, unchanged from 0000866374-24-000053:mdna:42]

[0000866374-25-000008:mdna:43]
[same as prior period, unchanged from 0000866374-24-000053:mdna:43]

[0000866374-25-000008:mdna:44]
[same as prior period, unchanged from 0000866374-24-000053:mdna:44]

[0000866374-25-000008:mdna:45]
[same as prior period, unchanged from 0000866374-24-000053:mdna:45]

[0000866374-25-000008:mdna:46]
[same as prior period, unchanged from 0000866374-24-000053:mdna:53]

[0000866374-25-000008:mdna:47]
[same as prior period, unchanged from 0000866374-24-000053:mdna:46]

[0000866374-25-000008:mdna:48]
[same as prior period, unchanged from 0000866374-24-000053:mdna:47]

[0000866374-25-000008:mdna:49]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 90.8 |  |  | 92.3 |  |  | 91.6 |  |  | 92.5 |  |
| Restructuring charges | 0.1 |  |  | 1.0 |  |  | 0.2 |  |  | 0.4 |  |
| Gross profit | 9.1 |  |  | 6.7 |  |  | 8.2 |  |  | 7.1 |  |
| Selling, general and administrative expenses | 3.7 |  |  | 3.2 |  |  | 3.5 |  |  | 3.3 |  |
| Restructuring charges | — |  |  | 0.2 |  |  | — |  |  | 0.1 |  |
| Intangible amortization | 0.3 |  |  | 0.2 |  |  | 0.2 |  |  | 0.3 |  |
| Operating income | 5.1 |  |  | 3.1 |  |  | 4.5 |  |  | 3.4 |  |
| Interest expense | 0.9 |  |  | 0.8 |  |  | 0.9 |  |  | 0.8 |  |
| Interest income | 0.2 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Other charges (income), net | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from continuing operations before income taxes | 4.4 |  |  | 2.4 |  |  | 3.8 |  |  | 2.7 |  |
| Provision for (benefit from) income taxes | 0.4 |  |  | 0.4 |  |  | 0.6 |  |  | 0.3 |  |
| Net income from continuing operations | 4.0 |  |  | 2.0 |  |  | 3.2 |  |  | 2.4 |  |
| Net income from discontinued operations, net of tax | — |  |  | 1.6 |  |  | — |  |  | 1.8 |  |
| Net income | 4.0 |  |  | 3.6 |  |  | 3.2 |  |  | 4.2 |  |
| Net income attributable to noncontrolling interest | — |  |  | 0.5 |  |  | — |  |  | 1.2 |  |
| Net income attributable to Flex Ltd. | 4.0 | % |  | 3.1 | % |  | 3.2 | % |  | 3.0 | % |

[0000866374-25-000008:mdna:50]
[same as prior period, unchanged from 0000866374-24-000053:mdna:49]

[0000866374-25-000008:mdna:51]
[same as prior period, unchanged from 0000866374-24-000053:mdna:50]

[0000866374-25-000008:mdna:52]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,599 |  |  | 55 | % |  | $ | 3,465 |  |  | 54 | % |  | $ | 10,570 |  |  | 54 | % |  | $ | 10,684 |  |  | 53 | % |
| Flex Reliability Solutions | 2,957 |  |  | 45 | % |  | 2,956 |  |  | 46 | % |  | 8,845 |  |  | 46 | % |  | 9,562 |  |  | 47 | % |
|  | $ | 6,556 |  |  |  |  | $ | 6,421 |  |  |  |  | $ | 19,415 |  |  |  |  | $ | 20,246 |  |  |  |

[0000866374-25-000008:mdna:53]
Net sales during the three-month period ended December 31, 2024 totaled $6.6 billion, representing an increase of approximately $0.1 billion, or 2% from $6.4 billion during the three-month period ended December 31, 2023. Net sales for our FAS segment increased approximately $0.1 billion or 4% from the three-month period ended December 31, 2023, primarily driven by a mid single-digit percentage increase in our CEC business as a result of higher demand in cloud and a high teen percentage increase in our Consumer Devices business, partially offset by a low single-digit decrease in our Lifestyle business due to softer demand. Net sales for our FRS segment remained relatively flat from the three-month period ended December 31, 2023. This was primarily driven by a mid single-digit percentage decrease in our Automotive business due to lower customer demand, which was offset by low single-digit percentage increases in both our Health Solutions and Industrial businesses, driven by continued strength in medical devices and data center power. Net sales decreased $8 million to $2.0 billion in Asia, increased $28 million to $1.4 billion in Europe, and increased $0.1 billion to $3.2 billion in the Americas.

[0000866374-25-000008:mdna:54]
[same as prior period, unchanged from 0000866374-24-000053:mdna:64]

[0000866374-25-000008:mdna:55]
Net sales during the nine-month period ended December 31, 2024 totaled $19.4 billion, representing a decrease of approximately $0.8 billion, or 4% from $20.2 billion during the nine-month period ended December 31, 2023. Net sales for our FAS segment decreased approximately $0.1 billion, or 1% from the nine-month period ended December 31, 2023, primarily driven by a low single-digit percentage decrease in our CEC business from softer demand in our non-cloud businesses and a mid single-digit percentage decrease in our Lifestyle business due to softer demand, partially offset by an increase in our Consumer Devices business due to higher demand. Net sales for our FRS segment decreased approximately $0.7 billion, or 7% from the nine-month period ended December 31, 2023, primarily driven by a low double digit percentage decrease in our Industrial business, along with low single-digit percentage decreases in both our Automotive and Health Solutions businesses, due to lower customer demand. The factors described above that decreased FAS and FRS revenues were partially offset by the impact of certain customer arrangements transitioning from point in time to over time revenue recognition. This transition also contributed to an increase in contract assets as of December 31, 2024. The impact of certain customers arrangements transitioning to over time revenue increased net sales by less than 2% for the nine-month period ended December 31, 2024. Net sales decreased $0.8 billion to $5.9 billion in Asia, decreased $0.1 billion to $4.1 billion in Europe, and increased $0.1 billion to $9.4 billion in the Americas.

[0000866374-25-000008:mdna:56]
Our ten largest customers during the three and nine-month periods ended December 31, 2024 accounted for approximately 45% and 44% of net sales, respectively. Our ten largest customers during the three and nine-month periods ended December 31, 2023 accounted for approximately 39% and 37% of net sales, respectively. No customer accounted for more than 10% of net sales during the three or nine-month periods ended December 31, 2024 or December 31, 2023.

[0000866374-25-000008:mdna:57]
[same as prior period, unchanged from 0000866374-24-000053:mdna:57]

[0000866374-25-000008:mdna:58]
[same as prior period, unchanged from 0000866374-24-000053:mdna:58]

[0000866374-25-000008:mdna:59]
Cost of sales during the three-month period ended December 31, 2024 totaled $6.0 billion, representing an increase of approximately $25 million, or 0.4% from $5.9 billion during the three-month period ended December 31, 2023. The higher cost of sales for the three-month period ended December 31, 2024 was primarily driven by a $0.1 billion or 2% increase in consolidated sales, partially offset by cost efficiencies and favorable mix. Cost of sales in our FAS segment for the three-month period ended December 31, 2024 increased approximately $70 million, or 2% from the three-month period ended December 31, 2023, due to higher revenues in our CEC and Consumer Devices businesses net of favorable mix and FAS cost efficiencies. Cost of sales in our FRS segment for the three-month period ended December 31, 2024 decreased approximately $44 million, or 2% from the three-month period ended December 31, 2023, on relatively flat revenue due to favorable mix and cost efficiencies.

[0000866374-25-000008:mdna:60]
Cost of sales during the nine-month period ended December 31, 2024 totaled $17.8 billion, representing a decrease of approximately $1.0 billion, or 5% from $18.7 billion during the nine-month period ended December 31, 2023. The lower cost of sales for the nine-month period ended December 31, 2024 was primarily driven by decreased consolidated sales of $0.8 billion or 4% and favorable mix and cost efficiencies. Cost of sales in our FAS segment for the nine-month period ended December 31, 2024 decreased approximately $0.3 billion, or 3% from the nine-month period ended December 31, 2023, which is consistent with a 1% decrease in FAS revenue during the same period combined with favorable mix and cost efficiencies. Cost of sales in our FRS segment for the nine-month period ended December 31, 2024 decreased approximately $0.7 billion, or 8% from the nine-month period ended December 31, 2023, which is consistent with a 7% decrease in FRS revenue during the same period.

[0000866374-25-000008:mdna:61]
[same as prior period, unchanged from 0000866374-24-000053:mdna:61]

[0000866374-25-000008:mdna:62]
[same as prior period, unchanged from 0000866374-24-000053:mdna:62]

[0000866374-25-000008:mdna:63]
Gross profit during the three-month period ended December 31, 2024 increased $0.2 billion to $0.6 billion, or 9.1% of net sales, from $0.4 billion, or 6.7% of net sales, during the three-month period ended December 31, 2023. Gross margin improved 240 basis points during the three-month period ended December 31, 2024 primarily due to favorable mix and continued operational execution.

[0000866374-25-000008:mdna:64]
Gross profit during the nine-month period ended December 31, 2024 increased $0.2 billion to $1.6 billion, or 8.2% of net sales, from $1.4 billion, or 7.1% of net sales, during the nine-month period ended December 31, 2023. Gross margin improved 110 basis points during the same period due to the same factors noted above in the three-month period discussion.

[0000866374-25-000008:mdna:65]
[same as prior period, unchanged from 0000866374-24-000053:mdna:66]

[0000866374-25-000008:mdna:66]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, customer related asset impairment (recoveries), legal and other, interest expense, and other charges (income), net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-25-000008:mdna:67]
[same as prior period, unchanged from 0000866374-24-000053:mdna:68]

[0000866374-25-000008:mdna:68]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 227 |  |  | 6.3 | % |  | $ | 175 |  |  | 5.1 | % |  | $ | 624 |  |  | 5.9 | % |  | $ | 488 |  |  | 4.6 | % |
| Flex Reliability Solutions | 198 |  |  | 6.7 | % |  | 159 |  |  | 5.4 | % |  | 504 |  |  | 5.7 | % |  | 495 |  |  | 5.2 | % |

[0000866374-25-000008:mdna:69]
FAS segment margin increased approximately 120 basis points to 6.3% for the three-month period ended December 31, 2024, and 130 basis points to 5.9% for the nine-month period ended December 31, 2024, compared to 5.1% and 4.6%, respectively, in the prior-year periods, primarily driven by continued mix improvement and strong cost execution.

[0000866374-25-000008:mdna:70]
FRS segment margin increased approximately 130 basis points to 6.7% for the three-month period ended December 31, 2024, and 50 basis points to 5.7% for the nine-month period ended December 31, 2024, compared to 5.4% and 5.2%, respectively, in the prior-year periods, primarily driven by favorable mix and strong cost execution.

[0000866374-25-000008:mdna:71]
[same as prior period, unchanged from 0000866374-24-000053:mdna:72]

[0000866374-25-000008:mdna:72]
We committed to targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. During the three and nine-month periods ended December 31, 2024, we recognized approximately $12 million and $55 million of restructuring charges, respectively, primarily related to employee severance.

[0000866374-25-000008:mdna:73]
[same as prior period, unchanged from 0000866374-24-000053:mdna:74]

[0000866374-25-000008:mdna:74]
Selling, general and administrative expenses (“SG&A”) was approximately $0.2 billion, or 3.7% of net sales, during the three-month period ended December 31, 2024, increasing $36 million from approximately $0.2 billion or 3.2% of net sales, during the three-month period ended December 31, 2023. SG&A was $0.7 billion, or 3.5% of net sales, during the nine-month period ended December 31, 2024, increasing $9 million from $0.7 billion or 3.3% of net sales, during the nine-month period ended December 31, 2023. The increase in SG&A is largely attributed to variable costs associated with improved financial performance.

[0000866374-25-000008:mdna:75]
[same as prior period, unchanged from 0000866374-24-000053:mdna:76]

[0000866374-25-000008:mdna:76]
Amortization of intangible assets remained relatively flat at $17 million for the three-month period ended December 31, 2024, compared to the same period in 2023. For the nine-month period ended December 31, 2024, amortization decreased to $49 million from $54 million for the same period in 2023, primarily due to certain intangibles now being fully amortized.

[0000866374-25-000008:mdna:77]
[same as prior period, unchanged from 0000866374-24-000053:mdna:78]

[0000866374-25-000008:mdna:78]
Interest expense increased to $57 million for the three-month period ended December 31, 2024, from $50 million in the prior year, driven by a new debt issuance in the second quarter of fiscal year 2025. For the nine-month period ended December 31, 2024, interest expense increased to $166 million from $155 million for the same period in 2023, primarily due to higher short-term borrowings and the new debt issuance, partially offset by savings from debt repurchases and repayments.

[0000866374-25-000008:mdna:79]
[same as prior period, unchanged from 0000866374-24-000053:mdna:80]

[0000866374-25-000008:mdna:80]
Interest income for the three-month period ended December 31, 2024, increased to $16 million compared to $13 million for the same period in 2023. For the nine-month period ended December 31, 2024, interest income increased to $48 million compared to $44 million in the prior year. These results remain consistent with the equivalent prior year periods, reflecting higher average cash balances.

[0000866374-25-000008:mdna:81]
33

[0000866374-25-000008:mdna:82]
[same as prior period, unchanged from 0000866374-24-000053:mdna:82]

[0000866374-25-000008:mdna:83]
Other charges (income), net was $5 million during the three-month period ended December 31, 2024 compared to an expense of $9 million during the three-month period ended December 31, 2023, primarily due to favorable foreign exchange partially offset by losses on classification of a business held for sale.

[0000866374-25-000008:mdna:84]
Other charges (income), net was $2 million during the nine-month period ended December 31, 2024 compared to an expense of $34 million during the nine-month period ended December 31, 2023, primarily driven by lower foreign exchange transaction losses and a gain from a Nextracker tax receivable agreement payment, partially offset by losses upon the classification of a business held for sale and on certain non-core equity method investments in the current period.

[0000866374-25-000008:mdna:85]
[same as prior period, unchanged from 0000866374-24-000053:mdna:85]

[0000866374-25-000008:mdna:86]
[same as prior period, unchanged from 0000866374-24-000053:mdna:86]

[0000866374-25-000008:mdna:87]
The consolidated effective tax rate was 9% and 17% for the three and nine-month periods ended December 31, 2024, and 15% and 13% for the three and nine-month periods ended December 31, 2023, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effects of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, the Netherlands and Israel. The effective tax rate for the three-month period ended December 31, 2024 was significantly lower than the effective tax rate for the three-month period ended December 31, 2023, primarily due to the recognition of approximately $26 million of interest recoverable on prior periods taxes paid by one of our Brazilian subsidiaries. The right to receive the interest became unconditional during the period. The effective tax rate for the nine-month period ended December 31, 2024 was higher than the effective tax rate for the nine-month period ended December 31, 2023 primarily due to the tax accrual required for our U.S. tax group after the U.S. tax group valuation allowance release in the fiscal year ended March 31, 2024 and the recognition of a withholding tax accrual on the undistributed earnings of our Chinese subsidiaries due to the decision in the fiscal year ended March 31, 2024 to not indefinitely reinvest our China earnings in China.

[0000866374-25-000008:mdna:88]
The OECD Pillar Two Global Anti-Base Erosion (“GloBE”) model rules, issued under the OECD Inclusive Framework on Base Erosion and Profit Shifting, introduce a global minimum tax of 15% applicable to multinational enterprise groups with consolidated financial statement revenue in excess of €750 million. Numerous foreign jurisdictions have already enacted tax legislation based on the GloBE rules, with some effective as early as January 1, 2024. As of December 31, 2024, we recognized a nominal income tax expense for Pillar Two GloBE minimum tax. The Company is continuously monitoring the evolving application of this legislation and assessing its potential impact on our future tax liability.

[0000866374-25-000008:mdna:89]
[same as prior period, unchanged from 0000866374-24-000053:mdna:89]

[0000866374-25-000008:mdna:90]
[same as prior period, unchanged from 0000866374-24-000053:mdna:90]

[0000866374-25-000008:mdna:91]
Net income from continuing operations was $263 million during the three-month period ended December 31, 2024, compared to $129 million during the three-month period ended December 31, 2023; net income from continuing operations was $616 million during the nine-month period ended December 31, 2024 compared to $477 million during the nine-month period ended December 31, 2023, driven by the factors discussed above.

[0000866374-25-000008:mdna:92]
[same as prior period, unchanged from 0000866374-24-000053:mdna:92]

[0000866374-25-000008:mdna:93]
Net income from discontinued operations was zero during the three-month period ended December 31, 2024, compared to $104 million during the three-month period ended December 31, 2023; net income from discontinued operations was zero during the nine-month period ended December 31, 2024 compared to $373 million during the nine-month period ended December 31, 2023, as Nextracker was spun off during the fourth quarter of fiscal year 2024.

[0000866374-25-000008:mdna:94]
[same as prior period, unchanged from 0000866374-24-000053:mdna:94]

[0000866374-25-000008:mdna:95]
Net income attributable to noncontrolling interest was zero during the three-month period ended December 31, 2024, compared to $36 million during the three-month period ended December 31, 2023; net income attribute to noncontrolling

[0000866374-25-000008:mdna:96]
interest was zero during the nine-month period ended December 31, 2024 compared to $239 million during the nine-month period ended December 31, 2023, as Nextracker was spun off during the fourth quarter of fiscal year 2024.

[0000866374-25-000008:mdna:97]
[same as prior period, unchanged from 0000866374-24-000053:mdna:96]

[0000866374-25-000008:mdna:98]
We continuously evaluate our ability to meet our obligations over the next 12 months and beyond and proactively reset our capital structure to improve maturities and liquidity. We expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of December 31, 2024, we had cash and cash equivalents of approximately $2.3 billion and bank and other borrowings of approximately $3.7 billion. We have a $2.5 billion revolving credit facility that is due to mature in July 2027, under which we had no borrowings outstanding as of December 31, 2024. We also issued $500 million of 5.250% Notes due January 2032 (the "2032 Senior Notes") in the second quarter of fiscal year 2025. As of December 31, 2024, we were in compliance with the covenants under all of our credit facilities and indentures; we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-25-000008:mdna:99]
During the nine-month period ended December 31, 2024, we repurchased approximately $53 million of our 4.750% Notes due June 2025 under our 10b5-1 bond buyback program, resulting in an immaterial gain on our condensed consolidated statement of operations.

[0000866374-25-000008:mdna:100]
Cash provided by operating activities was $1.1 billion during the nine-month period ended December 31, 2024, primarily driven by $0.6 billion of net income for the period plus $0.5 billion of non-cash charges such as depreciation, amortization, and stock-based compensation.

[0000866374-25-000008:mdna:101]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital decreased approximately $0.8 billion to $3.7 billion as of December 31, 2024, from $4.5 billion as of March 31, 2024. The decrease was primarily the result of the effect of a $0.5 billion increase in current liabilities as a result of growth in short-term debt of $0.5 billion and accounts payable of $0.6 billion offset in part by reductions in working capital advances. In addition, current assets decreased by $0.2 billion as a result of decreases in inventory offset in part by growth in contract assets and accounts receivable.

[0000866374-25-000008:mdna:102]
Net cash used in investing activities was $0.6 billion during the nine-month period ended December 31, 2024. This was primarily driven by $0.3 billion of cash paid for the acquisitions of Crown Technical Systems and JETCOOL Technologies Inc. in November 2024, net of cash acquired, and $0.3 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of primarily our Automotive, CEC, and Industrial businesses.

[0000866374-25-000008:mdna:103]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investors. Our adjusted free cash flow for the nine-month periods ended December 31, 2024 and December 31, 2023 was an inflow of $0.8 billion and $0.2 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-25-000008:mdna:104]
|  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,072 |  |  | $ | 647 |  |
| Purchases of property and equipment | (326) |  |  | (449) |  |
| Proceeds from the disposition of property and equipment | 11 |  |  | 21 |  |
| Adjusted free cash flow | $ | 757 |  |  | $ | 219 |  |

[0000866374-25-000008:mdna:105]
Cash used by financing activities was $0.5 billion during the nine-month period ended December 31, 2024, which was primarily driven by $1.0 billion of cash paid for the repurchase of our ordinary shares offset by $0.5 billion of proceeds from the issuance of the 2032 Senior Notes.

[0000866374-25-000008:mdna:106]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our

[0000866374-25-000008:mdna:107]
35

[0000866374-25-000008:mdna:108]
existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months and beyond. As of December 31, 2024 and March 31, 2024, approximately 78% and 55%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $0.7 billion as of March 31, 2024). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-25-000008:mdna:109]
[same as prior period, unchanged from 0000866374-24-000053:mdna:108]

[0000866374-25-000008:mdna:110]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of December 31, 2024.

[0000866374-25-000008:mdna:111]
[same as prior period, unchanged from 0000866374-24-000053:mdna:110]

[0000866374-25-000008:mdna:112]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-25-000008:mdna:113]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1.7 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 8, 2024. During the nine-month period ended December 31, 2024, we paid $958 million to repurchase shares under the current and prior repurchase plans at an average price of $31.36 per share. As of December 31, 2024, shares in the aggregate amount of $1.3 billion were available to be repurchased under the current plan.

[0000866374-25-000008:mdna:114]
[same as prior period, unchanged from 0000866374-24-000053:mdna:113]

[0000866374-25-000008:mdna:115]
[same as prior period, unchanged from 0000866374-24-000053:mdna:114]

[0000866374-25-000008:mdna:116]
In August 2024, we issued the 2032 Senior Notes, and other than such issuance, there were no material changes in our contractual obligations and commitments as of December 31, 2024.
