# FLEX MD&A — 0000866374-21-000019


## mdna

[0000866374-21-000019:mdna:1]
[same as prior period, unchanged from 0000866374-20-000030:mdna:1]

[0000866374-21-000019:mdna:2]
[same as prior period, unchanged from 0000866374-20-000030:mdna:2]

[0000866374-21-000019:mdna:3]
[same as prior period, unchanged from 0000866374-20-000030:mdna:3]

[0000866374-21-000019:mdna:4]
[same as prior period, unchanged from 0000866374-20-000030:mdna:4]

[0000866374-21-000019:mdna:5]
[same as prior period, unchanged from 0000866374-20-000030:mdna:5]

[0000866374-21-000019:mdna:6]
[same as prior period, unchanged from 0000866374-20-000030:mdna:6]

[0000866374-21-000019:mdna:7]
[same as prior period, unchanged from 0000866374-20-000030:mdna:7]

[0000866374-21-000019:mdna:8]
[same as prior period, unchanged from 0000866374-20-000030:mdna:8]

[0000866374-21-000019:mdna:9]
[same as prior period, unchanged from 0000866374-20-000030:mdna:9]

[0000866374-21-000019:mdna:10]
[same as prior period, unchanged from 0000866374-20-000030:mdna:10]

[0000866374-21-000019:mdna:11]
[same as prior period, unchanged from 0000866374-20-000030:mdna:11]

[0000866374-21-000019:mdna:12]
[same as prior period, unchanged from 0000866374-20-000030:mdna:12]

[0000866374-21-000019:mdna:13]
[same as prior period, unchanged from 0000866374-20-000030:mdna:13]

[0000866374-21-000019:mdna:14]
[same as prior period, unchanged from 0000866374-20-000030:mdna:14]

[0000866374-21-000019:mdna:15]
[same as prior period, unchanged from 0000866374-20-000030:mdna:15]

[0000866374-21-000019:mdna:16]
[same as prior period, unchanged from 0000866374-20-000030:mdna:16]

[0000866374-21-000019:mdna:17]
During the first half of fiscal year 2020 in connection with geopolitical developments and uncertainties at the time, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During fiscal year 2021, in order to further support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, the Company has identified and is engaging in certain structural changes.

[0000866374-21-000019:mdna:18]
[same as prior period, unchanged from 0000866374-20-000030:mdna:18]

[0000866374-21-000019:mdna:19]
[same as prior period, unchanged from 0000866374-20-000030:mdna:19]

[0000866374-21-000019:mdna:20]
As anticipated, our results were negatively impacted by COVID-19 disruptions to our factories, workforce, and suppliers most notably in our first quarter as the impact from the pandemic extended throughout the entire quarter. Total COVID-19 related costs incurred over the nine-month period ended December 31, 2020 were over $140 million and were primarily comprised of enhanced health and safety protocols, incremental labor incentives, incremental supply chain costs and forced

[0000866374-21-000019:mdna:21]
under-absorption of idle and underutilized labor and overhead costs. As we expected, these incremental costs persisted in our third quarter, but declined significantly from the June and September quarters as demand improved. Although not impacting our results for the third quarter of fiscal year 2021, most recently, with the second wave of the pandemic, we have also been experiencing plant closures and/or restrictions at certain manufacturing facilities in Brazil and Malaysia.

[0000866374-21-000019:mdna:22]
While both the FAS and FRS segments experienced sequential growth, COVID-19 related demand and production pressures remain in certain end markets that we serve. Net sales increased $0.3 billion during the three-month period ended December 31, 2020 versus the prior year period as a result of increases in demand across both of our segments. On the other hand, net sales declined $0.9 billion during the nine-month period ended December 31, 2020 versus the prior year period, primarily due to declines noted in our Consumer Devices business included in the FAS segment. Included in the FRS segment, our Health Solutions business performed well during the nine-month period ended December 31, 2020 driven by the increased demand for critical care products and diagnostics and patient monitoring programs. Our factories were productive for the entire second and third quarters resulting in sales recovering specifically for the automotive businesses that were shut down during the majority of the first quarter. In the three-month period ended December 31, 2020, we have started to see certain component constraints related to Automotive and we continue to carefully monitor potential supply chain disruptions due to ongoing tightness in the overall component environment. In addition, while we anticipate revenue will continue to improve across our end markets, we believe that our businesses tied to consumer spending, such as Lifestyle and Consumer Devices, will continue to be impacted if there is a prolonged demand slowdown. Refer to “Risk Factors - The COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material,” as disclosed in Part I, “Item 1A. Risk Factors” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0000866374-21-000019:mdna:23]
As part of our continuous response to the outbreak, we initiated salary cuts, furloughs and other programs to cut costs during the first half of fiscal year 2021. This also included aggressively reducing discretionary corporate spend. Employees that have been operating on a work-from-home basis are continuing to do so. While there still remains an elevated degree of uncertainty, we have removed specific austerity measures involving employee compensation. Further, to continue to support our strategy and build a sustainable organization, and after considering that the economic recovery will be slower than anticipated, we have identified and are continuing to engage in certain structural changes. See additional discussion regarding these restructuring actions below under "Results of Operations - Restructuring charges".

[0000866374-21-000019:mdna:24]
[same as prior period, unchanged from 0000866374-20-000030:mdna:24]

[0000866374-21-000019:mdna:25]
Other Developments

[0000866374-21-000019:mdna:26]
We are actively pursuing alternatives for our NEXTracker business. We are considering options that may include, among others, a full or partial separation of the business through an initial public offering, sale, spin-off, or other transaction.

[0000866374-21-000019:mdna:27]
[same as prior period, unchanged from 0000866374-20-000030:mdna:25]

[0000866374-21-000019:mdna:28]
We are one of the world's largest providers of global supply chain solutions, with revenues of $17.9 billion for the nine-month period ended December 31, 2020 and $24.2 billion in fiscal year 2020. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-21-000019:mdna:29]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 2,562 |  |  | 38 | % |  | $ | 2,630 |  |  | 41 | % |  | $ | 7,119 |  |  | 40 | % |  | $ | 7,661 |  |  | 41 | % |
| Asia | 2,695 |  |  | 40 | % |  | 2,563 |  |  | 40 | % |  | 6,985 |  |  | 39 | % |  | 7,510 |  |  | 40 | % |
| Europe | 1,463 |  |  | 22 | % |  | 1,268 |  |  | 19 | % |  | 3,754 |  |  | 21 | % |  | 3,554 |  |  | 19 | % |
|  | $ | 6,720 |  |  |  |  | $ | 6,461 |  |  |  |  | $ | 17,858 |  |  |  |  | $ | 18,725 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 1,721 |  |  | 26 | % |  | $ | 1,638 |  |  | 25 | % |  | $ | 4,631 |  |  | 26 | % |  | $ | 4,535 |  |  | 24 | % |
| Mexico | 1,177 |  |  | 18 | % |  | 1,171 |  |  | 18 | % |  | 3,237 |  |  | 18 | % |  | 3,408 |  |  | 18 | % |
| U.S. | 964 |  |  | 14 | % |  | 966 |  |  | 15 | % |  | 2,728 |  |  | 15 | % |  | 2,677 |  |  | 14 | % |
| Malaysia | 459 |  |  | 7 | % |  | 398 |  |  | 6 | % |  | 1,191 |  |  | 7 | % |  | 1,233 |  |  | 7 | % |
| Brazil | 405 |  |  | 6 | % |  | 480 |  |  | 7 | % |  | 1,116 |  |  | 6 | % |  | 1,524 |  |  | 8 | % |
| Hungary | 385 |  |  | 6 | % |  | 352 |  |  | 5 | % |  | 942 |  |  | 5 | % |  | 994 |  |  | 5 | % |
| India | 316 |  |  | 5 | % |  | 298 |  |  | 5 | % |  | 599 |  |  | 3 | % |  | 1,091 |  |  | 6 | % |
| Other | 1,293 |  |  | 18 | % |  | 1,158 |  |  | 19 | % |  | 3,414 |  |  | 20 | % |  | 3,263 |  |  | 18 | % |
|  | $ | 6,720 |  |  |  |  | $ | 6,461 |  |  |  |  | $ | 17,858 |  |  |  |  | $ | 18,725 |  |  |  |

[0000866374-21-000019:mdna:30]
|  | As of |  | As of |
| Property and equipment, net: | December 31, 2020 |  | March 31, 2020 |
|  | (In millions) |
| Mexico | $ | 540 |  |  | 26 | % |  | $ | 555 |  |  | 25 | % |
| U.S. | 364 |  |  | 17 | % |  | 378 |  |  | 17 | % |
| China | 337 |  |  | 16 | % |  | 396 |  |  | 18 | % |
| India | 174 |  |  | 8 | % |  | 207 |  |  | 9 | % |
| Hungary | 104 |  |  | 5 | % |  | 100 |  |  | 5 | % |
| Malaysia | 102 |  |  | 5 | % |  | 111 |  |  | 4 | % |
| Other | 476 |  |  | 23 | % |  | 469 |  |  | 22 | % |
|  | $ | 2,097 |  |  |  |  | $ | 2,216 |  |  |  |

[0000866374-21-000019:mdna:31]
[same as prior period, unchanged from 0000866374-20-000030:mdna:30]

[0000866374-21-000019:mdna:32]
[same as prior period, unchanged from 0000866374-20-000030:mdna:31]

[0000866374-21-000019:mdna:33]
[same as prior period, unchanged from 0000866374-20-000030:mdna:32]

[0000866374-21-000019:mdna:34]
[same as prior period, unchanged from 0000866374-20-000030:mdna:33]

[0000866374-21-000019:mdna:35]
[same as prior period, unchanged from 0000866374-20-000030:mdna:34]

[0000866374-21-000019:mdna:36]
[same as prior period, unchanged from 0000866374-20-000030:mdna:52]

[0000866374-21-000019:mdna:37]
[same as prior period, unchanged from 0000866374-20-000030:mdna:35]

[0000866374-21-000019:mdna:38]
[same as prior period, unchanged from 0000866374-20-000030:mdna:36]

[0000866374-21-000019:mdna:39]
[same as prior period, unchanged from 0000866374-20-000030:mdna:37]

[0000866374-21-000019:mdna:40]
[same as prior period, unchanged from 0000866374-20-000030:mdna:38]

[0000866374-21-000019:mdna:41]
[same as prior period, unchanged from 0000866374-20-000030:mdna:39]

[0000866374-21-000019:mdna:42]
[same as prior period, unchanged from 0000866374-20-000030:mdna:40]

[0000866374-21-000019:mdna:43]
[same as prior period, unchanged from 0000866374-20-000030:mdna:41]

[0000866374-21-000019:mdna:44]
[same as prior period, unchanged from 0000866374-20-000030:mdna:42]

[0000866374-21-000019:mdna:45]
[same as prior period, unchanged from 0000866374-20-000030:mdna:43]

[0000866374-21-000019:mdna:46]
[same as prior period, unchanged from 0000866374-20-000030:mdna:44]

[0000866374-21-000019:mdna:47]
[same as prior period, unchanged from 0000866374-20-000030:mdna:45]

[0000866374-21-000019:mdna:48]
[same as prior period, unchanged from 0000866374-20-000030:mdna:46]

[0000866374-21-000019:mdna:49]
[same as prior period, unchanged from 0000866374-20-000030:mdna:47]

[0000866374-21-000019:mdna:50]
[same as prior period, unchanged from 0000866374-20-000030:mdna:48]

[0000866374-21-000019:mdna:51]
[same as prior period, unchanged from 0000866374-20-000030:mdna:49]

[0000866374-21-000019:mdna:52]
[same as prior period, unchanged from 0000866374-20-000030:mdna:50]

[0000866374-21-000019:mdna:53]
[same as prior period, unchanged from 0000866374-20-000030:mdna:51]

[0000866374-21-000019:mdna:54]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 92.4 |  |  | 93.1 |  |  | 93.1 |  |  | 93.9 |  |
| Restructuring charges | 0.4 |  |  | 0.2 |  |  | 0.4 |  |  | 0.9 |  |
| Gross profit | 7.2 |  |  | 6.7 |  |  | 6.5 |  |  | 5.2 |  |
| Selling, general and administrative expenses | 3.3 |  |  | 3.4 |  |  | 3.4 |  |  | 3.4 |  |
| Intangible amortization | 0.2 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.0 |  |  | 0.0 |  |  | 0.1 |  |  | 0.1 |  |
| Interest and other, net | 0.1 |  |  | 0.8 |  |  | 0.3 |  |  | 0.8 |  |
| Income before income taxes | 3.6 |  |  | 2.3 |  |  | 2.4 |  |  | 0.6 |  |
| Provision for income taxes | 0.4 |  |  | 0.5 |  |  | 0.5 |  |  | 0.4 |  |
| Net income | 3.2 | % |  | 1.8 | % |  | 1.9 | % |  | 0.2 | % |

[0000866374-21-000019:mdna:55]
[same as prior period, unchanged from 0000866374-20-000030:mdna:54]

[0000866374-21-000019:mdna:56]
[same as prior period, unchanged from 0000866374-20-000030:mdna:55]

[0000866374-21-000019:mdna:57]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,834 |  |  | 57 | % |  | $ | 3,631 |  |  | 56 | % |  | $ | 10,063 |  |  | 56 | % |  | $ | 11,122 |  |  | 59 | % |
| Flex Reliability Solutions | 2,886 |  |  | 43 | % |  | 2,830 |  |  | 44 | % |  | 7,795 |  |  | 44 | % |  | 7,603 |  |  | 41 | % |
|  | $ | 6,720 |  |  |  |  | $ | 6,461 |  |  |  |  | $ | 17,858 |  |  |  |  | $ | 18,725 |  |  |  |

[0000866374-21-000019:mdna:58]
Net sales during the three-month period ended December 31, 2020 totaled $6.7 billion, representing an increase of approximately $0.3 billion, or 4% from $6.5 billion during the three-month period ended December 31, 2019. Net sales for our FAS segment increased $203 million, or 5.6%, driven by increases across all of its end markets, led by an approximately 10% increase in sales by our Lifestyle business due to extended strength in high-end audio, floor care, and appliance end markets, and an approximately 9% increase in sales by our Consumer Devices business as a result of spikes in consumer spending and demand. Net sales for our FRS segment increased $56 million, or 2.0%, primarily due to an increase of over 20% in sales by our Health Solution business as a result of continued demand for critical care products and diagnostics and patient monitoring programs. In addition, Automotive revenue increased over 5% as we continue to recover from the shutdowns earlier in the year. Offsetting these increases was an over 5% drop in sales in our Industrial business where strong growth in core industrial was offset by expected declines in power solutions due to reductions in demand from a specific customer. Net sales increased $194 million to $1.5 billion in Europe, $132 million to $2.7 billion in Asia, partially offset by a $68 million decline down to $2.6 billion in the Americas.

[0000866374-21-000019:mdna:59]
Net sales during the nine-month period ended December 31, 2020 totaled $17.9 billion, representing a decrease of approximately $0.9 billion, or 5% from $18.7 billion during the nine-month period ended December 31, 2019. The decrease in net sales was most notable in our FAS segment, down $1.1 billion, or 9.5%, from the prior year, mainly due to a drop of over 30% in our Consumer Devices business resulting from lower demand due to the impact of COVID-19, and our continued strategic shift away from high volatility, short cycle businesses that we initiated in the prior year. Offsetting a portion of the overall decline in revenue was an increase in revenues from the FRS segment of $192 million, or 2.4%, driven primarily by an increase of over 20% in sales from our Health Solutions business, as noted above, and an increase of 3% in our Industrial business led by strong demand. These increases in our FRS segment were offset by a drop of approximately 15% in our Automotive business due to the factory shutdowns in the first quarter of fiscal year 2021 despite the recovery noted in the second and third quarters of fiscal year 2021. Net sales decreased $525 million to $7.0 billion in Asia, $542 million to $7.1 billion in the Americas, partially offset by a modest increase of $200 million to $3.8 billion in Europe.

[0000866374-21-000019:mdna:60]
Our ten largest customers, during the three and nine-month periods ended December 31, 2020, accounted for approximately 36% and 37% of net sales, respectively. Our ten largest customers, during the three and nine-month periods ended December 31, 2019, accounted for approximately 40% and 39% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and nine-month periods ended December 31, 2020 or December 31, 2019.

[0000866374-21-000019:mdna:61]
34

[0000866374-21-000019:mdna:62]
[same as prior period, unchanged from 0000866374-20-000030:mdna:60]

[0000866374-21-000019:mdna:63]
[same as prior period, unchanged from 0000866374-20-000030:mdna:61]

[0000866374-21-000019:mdna:64]
Cost of sales during the three-month period ended December 31, 2020 totaled $6.2 billion, representing an increase of approximately $0.2 billion, or 3% from $6.0 billion during the three-month period ended December 31, 2019. The increase in cost of sales for the three-month period is more notable in our FAS segment. Cost of sales in FAS for the three-month period ended December 31, 2020 increased 4%, or $149 million from the three-month period ended December 31, 2019, which is in line with the overall 5.6% increase in FAS revenue during the same period primarily as a result of demand upsides in our Lifestyle and Consumer Devices businesses coupled with better absorption of fixed costs. In addition, cost of sales in FRS for the three-month period ended December 31, 2020 increased 2%, or $55 million from the three-month period ended December 31, 2019, which is in line with the overall 2% increase in FRS revenue during the same period, as our Health Solutions and Automotive businesses continued to ramp as discussed above.

[0000866374-21-000019:mdna:65]
Cost of sales during the nine-month period ended December 31, 2020 totaled $16.6 billion, representing a decrease of approximately $1.0 billion, or 5% from $17.6 billion during the nine-month period ended December 31, 2019. The decrease in cost of sales for the nine-month period is more notable in our FAS segment. Cost of sales in FAS for the nine-month period ended December 31, 2020 decreased $1.0 billion or 10% from the nine-month period ended December 31, 2019, which is in line with the 10% decrease in revenue, primarily as a result of COVID-19 impacting our Consumer Devices business in the earlier part of fiscal year 2021, coupled with our targeted disengagement of high volatility, short cycle businesses initiated in the prior year. Offsetting the decrease in cost of sales in FAS is an increase of $208 million, or 3%, related to the FRS segment during the nine-month period ended December 31, 2020. These fluctuations are consistent with the associated change in net sales noted above. Cost of sales was also higher in the prior year due to $95 million of customer assets impairment charges for customers that were experiencing financial difficulties as well as the write-down of inventory not recoverable due to significant reductions in future customer demand as we reduced our exposure to certain higher volatility businesses.

[0000866374-21-000019:mdna:66]
[same as prior period, unchanged from 0000866374-20-000030:mdna:64]

[0000866374-21-000019:mdna:67]
[same as prior period, unchanged from 0000866374-20-000030:mdna:65]

[0000866374-21-000019:mdna:68]
Gross profit during the three-month period ended December 31, 2020 increased $49 million to $479 million, or 7.2% of net sales, from $430 million, or 6.7% of net sales, during the three-month period ended December 31, 2019. Gross margin improved 50 basis points during the same period. The increase in gross profit and gross margin resulted primarily from an improvement of the FAS segment gross profit and gross margin driven by strong demand in Consumer Devices and Lifestyle end markets and, as noted above, enhanced productivity and efficiencies driven by disciplined cost reduction initiatives. This more than offset the flat gross profit and slight drop in gross margin for our FRS segment related to certain product transitions to next generation within Automotive coupled with continued investments with new product ramps in our Health Solutions business.

[0000866374-21-000019:mdna:69]
Gross profit during the nine-month period ended December 31, 2020 increased $205 million to $1.2 billion, or 6.5% of net sales, from $1.0 billion, or 5.2% of net sales, during the nine-month period ended December 31, 2019, an improvement of 130 basis points. The increase in gross profit and gross margin during the nine-month period ended December 31, 2020 primarily resulted from lower restructuring costs, $63 million in the nine-month period ended December 31, 2020, versus $175 million in the nine-month period ended December 31, 2019, a decline of $112 million which is primarily due to charges taken in fiscal year 2020 due to geopolitical challenges and uncertainties which impacted certain of our customers. Gross profit also increased due to the $95 million of customer assets impairment charges recorded in the prior year for customers that were experiencing financial difficulties coupled with the write-down of inventory not recoverable due to the significant reductions in future customer demand as we reduced our exposure to certain higher volatility businesses. These increases were partially offset by the decline in revenue and gross profit in our Consumer Devices and Automotive end markets reflecting COVID-19 demand and production pressures during the first half of fiscal year 2021.

[0000866374-21-000019:mdna:70]
[same as prior period, unchanged from 0000866374-20-000030:mdna:68]

[0000866374-21-000019:mdna:71]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment charges, restructuring charges, legal and other, and interest and other, net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-21-000019:mdna:72]
[same as prior period, unchanged from 0000866374-20-000030:mdna:70]

[0000866374-21-000019:mdna:73]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 153 |  |  | 4.0 | % |  | $ | 98 |  |  | 2.7 | % |  | $ | 313 |  |  | 3.1 | % |  | $ | 301 |  |  | 2.7 | % |
| Flex Reliability Solutions | 178 |  |  | 6.2 | % |  | 186 |  |  | 6.6 | % |  | 472 |  |  | 6.1 | % |  | 475 |  |  | 6.2 | % |

[0000866374-21-000019:mdna:74]
FAS segment margin increased 130 basis points, to 4.0% for the three-month period ended December 31, 2020, from 2.7% for the three-month period ended December 31, 2019. The margin increase was driven by an increase in demand from high-end audio, floor care and appliance customers included in our Lifestyle end markets as well as incremental margin enhancement from our Consumer Devices end markets driven by product ramps coupled with better fixed costs absorption. The FAS segment margin increased 40 basis points, to 3.1% for the nine-month period ended December 31, 2020, from 2.7% for the nine-month period ended December 31, 2019. The increase in FAS segment margin during the nine-month period is due to similar drivers as noted in the discussion above for the three-month period partially offset by the elevated under absorption and supply chain constraints noted in the earlier part of fiscal year 2021.

[0000866374-21-000019:mdna:75]
FRS segment margin decreased 40 basis points, to 6.2% for the three-month period ended December 31, 2020, from 6.6% for the three-month period ended December 31, 2019. The margin deterioration was driven by certain product transitions to next generation noted in our Automotive business coupled with investments in new product ramps in our Health Solutions business. FRS segment margin decreased 10 basis points, to 6.1% for the nine-month period ended December 31, 2020, from 6.2% for the nine-month period ended December 31, 2019. The decrease in FRS segment margin during the nine-month period is primarily the results of plant shutdowns during most of our first quarter of fiscal year 2021, which affected the entire automotive ecosystem across all regions, coupled with under-absorption and efficiency impacts.

[0000866374-21-000019:mdna:76]
36

[0000866374-21-000019:mdna:77]
[same as prior period, unchanged from 0000866374-20-000030:mdna:75]

[0000866374-21-000019:mdna:78]
[same as prior period, unchanged from 0000866374-20-000030:mdna:76]

[0000866374-21-000019:mdna:79]
[same as prior period, unchanged from 0000866374-20-000030:mdna:77]

[0000866374-21-000019:mdna:80]
[same as prior period, unchanged from 0000866374-20-000030:mdna:78]

[0000866374-21-000019:mdna:81]
[same as prior period, unchanged from 0000866374-20-000030:mdna:79]

[0000866374-21-000019:mdna:82]
[same as prior period, unchanged from 0000866374-20-000030:mdna:80]

[0000866374-21-000019:mdna:83]
In order to support our strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, we have identified and are engaging in certain structural changes. These restructuring actions will eliminate non-core activities primarily within our corporate function, align our cost structure with our reorganizing and optimizing of our operations model along our two reporting segments, and further sharpen our focus to winning business in end markets where we have competitive advantages and deep domain expertise. During the three and nine-month periods ended December 31, 2020, we recognized approximately $30 million and $75 million, respectively, of restructuring charges, primarily cash charges related to employee severance.

[0000866374-21-000019:mdna:84]
During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During the three and nine-month periods ended December 31, 2019, we recognized $15 million and $199 million of restructuring charges. We incurred cash charges of approximately $15 million and $143 million, respectively, that were predominantly for employee severance, and non-cash charges of an immaterial amount and $56 million, respectively, primarily related to asset impairments.

[0000866374-21-000019:mdna:85]
[same as prior period, unchanged from 0000866374-20-000030:mdna:83]

[0000866374-21-000019:mdna:86]
Selling, general and administrative expenses (“SG&A”) was $222 million, or 3.3% of net sales, during the three-month period ended December 31, 2020, increasing $4 million from $218 million, or 3.4% of net sales, during the three-month period ended December 31, 2019, which reflects our enhanced cost control efforts to support a higher revenue growth while keeping our SG&A expenses relatively flat. SG&A was $606 million, or 3.4% of net sales, during the nine-month period ended

[0000866374-21-000019:mdna:87]
[same as prior period, unchanged from 0000866374-20-000030:mdna:97]

[0000866374-21-000019:mdna:88]
December 31, 2020, decreasing $27 million from $633 million, or 3.4% of net sales, during the nine-month period ended December 31, 2019. The decrease reflects strong cost discipline practiced across the enterprise as well as the benefits from our distinct actions taken to temporarily reduce compensation costs across our employee base and aggressively reducing our discretionary spend levels during the first half of fiscal year 2021. In addition, it reflects a refined cost structure benefiting from prior restructuring initiatives.

[0000866374-21-000019:mdna:89]
[same as prior period, unchanged from 0000866374-20-000030:mdna:86]

[0000866374-21-000019:mdna:90]
Amortization of intangible assets remains consistent at $16 million during the three-month periods ended December 31, 2020 and December 31, 2019.  During the nine-month period ended December 31, 2020, amortization of intangible assets marginally declined to $47 million, from $49 million for the nine-month period ended December 31, 2019, primarily due to certain intangibles now being fully amortized.

[0000866374-21-000019:mdna:91]
[same as prior period, unchanged from 0000866374-20-000030:mdna:88]

[0000866374-21-000019:mdna:92]
Interest and other, net was $7 million of charges during the three-month period ended December 31, 2020 compared to $50 million of charges during the three-month period ended December 31, 2019, primarily driven by $48 million of gains from higher equity in earnings recognized in fiscal year 2021 for certain of our non-core equity method investments.

[0000866374-21-000019:mdna:93]
Interest and other, net was $58 million of charges during the nine-month period ended December 31, 2020 compared to $153 million of charges during the nine-month period ended December 31, 2019. Consistent with the factors above, the decrease in expense is primarily driven by $68 million of gains from higher equity in earnings recognized for certain of our non-core equity method investments in fiscal year 2021, in addition to $26 million of lower expenses from our asset-backed securitization programs as we reduced outstanding balances for these programs.

[0000866374-21-000019:mdna:94]
[same as prior period, unchanged from 0000866374-20-000030:mdna:91]

[0000866374-21-000019:mdna:95]
[same as prior period, unchanged from 0000866374-20-000030:mdna:92]

[0000866374-21-000019:mdna:96]
The consolidated effective tax rate was 11% and 18% for the three-month and nine-month periods ended December 31, 2020 and 23% and 65% for the three-month and nine-month periods ended December 31, 2019, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, India, the Netherlands and Israel. The effective tax rate for the three-month and nine-month periods ended December 31, 2020 is lower than the effective tax rate for the three-month and nine-month periods ended December 31, 2019, primarily due to the changing jurisdictional mix of income, and the Company's recognition of significant amounts of restructuring charges, impairment of non-core investments, and customer related asset impairments with minimal associated tax benefits for the three-month and  nine-month periods ended December 31, 2019.

[0000866374-21-000019:mdna:97]
[same as prior period, unchanged from 0000866374-20-000030:mdna:94]

[0000866374-21-000019:mdna:98]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of December 31, 2020, we had cash and cash equivalents of approximately $2.6 billion and bank and other borrowings of approximately $3.8 billion. We had a $1.75 billion revolving credit facility, under which there were no borrowings outstanding as of the end of the quarter. We also issued $675 million of 3.750% Notes due February 2026 and $650 million of 4.875% Notes due May 2030 and repaid $433 million for the term loan due June 2022.  Refer to note 6 to the condensed consolidated financial statement for details. As of December 31, 2020, we were in compliance with the covenants under all of our credit facilities and indentures. In January 2021, we entered into a new $2.0 billion credit agreement (the "New Credit Facility") which matures in January 2026 and consists of a $2.0 billion revolving credit facility with a sub-limit of $360 million available for swing line loans and a sub-limit of $175 million available for the issuance of letters of credit. The New Credit Facility replaced the previous $1.75 billion credit facility noted above. Under the New Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

[0000866374-21-000019:mdna:99]
[same as prior period, unchanged from 0000866374-20-000030:mdna:104]

[0000866374-21-000019:mdna:100]
Cash used in operating activities was $17 million during the nine-month period ended December 31, 2020, primarily driven by cash outflows related to accounts receivables resulting from the reduction of our outstanding balances of accounts receivable sold through our ABS and accounts receivable factoring programs. These were offset by $373 million of net income for the period plus $517 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation.

[0000866374-21-000019:mdna:101]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts,  plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. Net working capital increased $1.3 billion to $2.7 billion as of December 31, 2020, from $1.4 billion as of March 31, 2020. This increase is primarily driven by a $1.6 billion increase in net receivables as we reduced our outstanding balances on our ABS and accounts receivable factoring programs as discussed above, partially offset by a $0.2 billion decrease in contract assets and $0.1 billion decrease in inventories. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended December 31, 2020, increased to 10.1% from 6.3% of annualized net sales for the quarter ended March 31, 2020 as a direct result of reducing the outstanding balance of accounts receivable sold through our ABS and accounts receivable factoring programs. The Company expects to operate in this range going forward. Though we have mitigated most of the initial supplier constraints and component shortages that we had encountered in the first quarter of fiscal year 2021, we continue to operate in an unusual and dynamic environment with respect to virus-related production limitations and fluctuating demand. We expect it will take additional time to adequately drive down our inventory levels to align with the current demand environment. We are actively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative resetting our load planning. Component shortages are also expected to persist in the near future as we are seeing increasing supply constraints. We are working diligently with our partners to secure needed parts and fulfill demand.

[0000866374-21-000019:mdna:102]
Cash used in investing activities was $226 million during the nine-month period ended December 31, 2020. This was primarily driven by $236 million of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Health Solutions and Industrial businesses.

[0000866374-21-000019:mdna:103]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, plus cash collections of deferred purchase price receivables (for fiscal year 2020), less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency (refer to Part II, Item 8, note 11 of our Annual Report on Form 10-K for the fiscal year ended March 31, 2020, for discussion of the amendment of the ABS Programs). We also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation. During the nine-month period ended December 31, 2020, we proactively and strategically reduced the outstanding balance of our ABS programs. Proceeds from our debt issuance replaced the funding from the ABS programs for working capital purposes. We reduced the balance on this short-term financing product by $796 million as of December 31, 2020, from $798 million as of March 31, 2020, which has the accounting effect of reducing our cash flow from operations. As this decrease in cash flow reflects the change of our capital strategy, we have added this back for our adjusted free cash flow calculation. Our adjusted free cash flows for the nine-month period ended December 31, 2020 was an inflow of $542 million compared to an inflow of $538 million for the nine-month period ended December 31, 2019. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-21-000019:mdna:104]
|  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |
|  | (In millions) |
| Net cash used in operating activities | $ | (17) |  |  | $ | (1,699) |  |
| Reduction in ABS levels | 796 |  |  | — |  |
| Cash collection of deferred purchase price and other | (1) |  |  | 2,511 |  |
| Purchases of property and equipment | (261) |  |  | (376) |  |
| Proceeds from the disposition of property and equipment | 25 |  |  | 102 |  |
| Adjusted free cash flow | $ | 542 |  |  | $ | 538 |  |

[0000866374-21-000019:mdna:105]
Cash provided by financing activities was $893 million during the nine-month period ended December 31, 2020, which was primarily driven by $1.4 billion of proceeds received in aggregate, net of discounts and after premiums, following the issuance of the 2026 Notes and the 2030 Notes, partially offset by $433 million cash paid for the repayment of the term loan due June

[0000866374-21-000019:mdna:106]
[same as prior period, unchanged from 0000866374-20-000030:mdna:116]

[0000866374-21-000019:mdna:107]
2022, and to a lesser extent by $38 million of cash paid for the repurchase of our ordinary shares. For further information, see note 6 to the condensed consolidated financial statements.

[0000866374-21-000019:mdna:108]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of December 31, 2020, and March 31, 2020, approximately half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.4 billion as of March 31, 2020). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-21-000019:mdna:109]
[same as prior period, unchanged from 0000866374-20-000030:mdna:106]

[0000866374-21-000019:mdna:110]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs amounted to approximately $0.3 billion and $0.7 billion for the three and nine-month periods ended December 31, 2020, respectively, and approximately $0.2 billion and $0.6 billion for the three and nine-month periods ended December 31, 2019, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-21-000019:mdna:111]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to commercial paper program, and revolving sale and repurchase of subordinated note established under the securitization facility, under which there were no borrowings outstanding as of December 31, 2020.

[0000866374-21-000019:mdna:112]
[same as prior period, unchanged from 0000866374-20-000030:mdna:109]

[0000866374-21-000019:mdna:113]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-21-000019:mdna:114]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 7, 2020. During the nine-month period ended December 31, 2020, we paid $38 million to repurchase shares under the current repurchase plans at an average price of $15.73 per share. As of December 31, 2020, shares in the aggregate amount of $462 million were available to be repurchased under the current plan.

[0000866374-21-000019:mdna:115]
40

[0000866374-21-000019:mdna:116]
[same as prior period, unchanged from 0000866374-20-000030:mdna:112]

[0000866374-21-000019:mdna:117]
[same as prior period, unchanged from 0000866374-20-000030:mdna:113]

[0000866374-21-000019:mdna:118]
During fiscal year 2021, we issued $675 million of 3.750% Notes due February 2026 and $650 million of 4.875% Notes due May 2030 and repaid $433 million for the term loan due June 2022. Further, in January 2021, we entered into a new $2.0 billion credit facility which matures in January 2026, replacing our previous $1.75 billion credit facility.

[0000866374-21-000019:mdna:119]
[same as prior period, unchanged from 0000866374-20-000030:mdna:115]

[0000866374-21-000019:mdna:120]
[same as prior period, unchanged from 0000866374-20-000030:mdna:117]

[0000866374-21-000019:mdna:121]
As of December 31, 2020, and March 31, 2020, the outstanding balance on receivables sold for cash was $0.1 billion and $1.2 billion, respectively, under our asset-backed securitization programs and accounts receivable factoring program, which were removed from accounts receivable balances in our condensed consolidated balance sheets. For further information, see note 10 to the condensed consolidated financial statements.
