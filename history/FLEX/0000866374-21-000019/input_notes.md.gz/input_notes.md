# FLEX notes — 0000866374-21-000019


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-21-000019:notes:1]
[same as prior period, unchanged from 0000866374-20-000030:notes:1]

[0000866374-21-000019:notes:2]
[same as prior period, unchanged from 0000866374-20-000030:notes:2]

[0000866374-21-000019:notes:3]
[same as prior period, unchanged from 0000866374-20-000030:notes:3]

[0000866374-21-000019:notes:4]
[same as prior period, unchanged from 0000866374-20-000030:notes:4]

[0000866374-21-000019:notes:5]
[same as prior period, unchanged from 0000866374-20-000030:notes:5]

[0000866374-21-000019:notes:6]
[same as prior period, unchanged from 0000866374-20-000030:notes:6]

[0000866374-21-000019:notes:7]
[same as prior period, unchanged from 0000866374-20-000030:notes:7]

[0000866374-21-000019:notes:8]
[same as prior period, unchanged from 0000866374-20-000030:notes:8]

[0000866374-21-000019:notes:9]
[same as prior period, unchanged from 0000866374-20-000030:notes:9]

[0000866374-21-000019:notes:10]
[same as prior period, unchanged from 0000866374-20-000030:notes:10]

[0000866374-21-000019:notes:11]
[same as prior period, unchanged from 0000866374-20-000030:notes:11]

[0000866374-21-000019:notes:12]
[same as prior period, unchanged from 0000866374-20-000030:notes:12]

[0000866374-21-000019:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2020 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021. Beginning in the second quarter of fiscal year 2021, the Company began reporting all dollar amounts in millions. In certain circumstances, this change in rounding resulted in line items being removed within prior year disclosures. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

[0000866374-21-000019:notes:14]
The first quarters for fiscal years 2021 and 2020 ended on June 26, 2020, which is comprised of 87 days in the period, and June 28, 2019, which is comprised of 89 days in the period, respectively. The second quarters for fiscal years 2021 and 2020 ended on September 25, 2020 and September 27, 2019, which are comprised of 91 days in both periods. The Company's third quarters for fiscal years 2021 and 2020 ended on December 31 of each year, which are comprised of 97 days and 95 days, respectively.

[0000866374-21-000019:notes:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership

[0000866374-21-000019:notes:16]
of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

[0000866374-21-000019:notes:17]
[same as prior period, unchanged from 0000866374-20-000030:notes:17]

[0000866374-21-000019:notes:18]
[same as prior period, unchanged from 0000866374-20-000030:notes:18]

[0000866374-21-000019:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, including highly liquid investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-21-000019:notes:20]
Recently Adopted Accounting Pronouncement

[0000866374-21-000019:notes:21]
In March 2020, the FASB issued ASU 2020-04 "Facilitation of the Effects of Reference Rate Reform on Financial Reporting", which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

[0000866374-21-000019:notes:22]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04,  ASU 2019-05, ASU 2019-10, and ASU 2019-11, which replace the existing incurred loss impairment model with an expected credit loss model and require a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

[0000866374-21-000019:notes:23]
Recently Issued Accounting Pronouncements

[0000866374-21-000019:notes:24]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

[0000866374-21-000019:notes:25]
In October 2020, the FASB issued ASU 2020-09 "Debt (Topic 470): Amendments to SEC Paragraphs Pursuant to SEC Release No. 33-10762." which amends and supersedes SEC paragraphs in the Accounting Standards Codification to reflect the issuance of SEC Release No. 33-10762 related to financial disclosure requirements for subsidiary issuers and guarantors of registered debt securities and affiliates whose securities are pledged as collateral for registered securities. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the fourth quarter of fiscal year 2021.

[0000866374-21-000019:notes:26]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force," which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

[0000866374-21-000019:notes:27]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-21-000019:notes:28]
[same as prior period, unchanged from 0000866374-20-000030:notes:26]

[0000866374-21-000019:notes:29]
[same as prior period, unchanged from 0000866374-20-000030:notes:27]

[0000866374-21-000019:notes:30]
|  | As of December 31, 2020 |  | As of March 31, 2020 |
|  | (In millions) |
| Raw materials | $ | 2,625 |  |  | $ | 2,836 |  |
| Work-in-progress | 472 |  |  | 373 |  |
| Finished goods | 602 |  |  | 576 |  |
|  | $ | 3,699 |  |  | $ | 3,785 |  |

[0000866374-21-000019:notes:31]
[same as prior period, unchanged from 0000866374-20-000030:notes:29]

[0000866374-21-000019:notes:32]
[same as prior period, unchanged from 0000866374-20-000030:notes:30]

[0000866374-21-000019:notes:33]
Based on the latest assessment of its goodwill as of April 1, 2020, the Company determined that no impairment existed as of the date of the impairment test, because the fair value of each one of its reporting units exceeds its respective carrying value. In addition, goodwill was reallocated among each of the Company's six reporting units based on each reporting unit’s relative fair value as of April 1, 2020. The Company considered whether an interim impairment test should be performed as of December 31, 2020 and concluded that there were no events or changes in circumstances that indicated the carrying amount of goodwill may not be recoverable. It will perform its next annual impairment test with a valuation date of January 1, 2021 to be completed in the period ending March 31, 2021. The following table summarizes the goodwill allocation as of April 1, 2020 and the activity during the nine-month period ended December 31, 2020:

[0000866374-21-000019:notes:34]
|  | FAS |  | FRS |  |  |
|  | Communications, Enterprise and Cloud |  | Lifestyle |  | Consumer Devices |  | Automotive |  | Health Solutions |  | Industrial |  | Total |
|  | (In millions) |
| Balance at April 1, 2020 | $ | 188 |  |  | $ | 131 |  |  | $ | 51 |  |  | $ | 174 |  |  | $ | 192 |  |  | $ | 329 |  |  | $ | 1,065 |  |
| Foreign currency translation adjustments | 1 |  |  | — |  |  | — |  |  | 39 |  |  | 4 |  |  | — |  |  | 44 |  |
| Balance at December 31, 2020 | $ | 189 |  |  | $ | 131 |  |  | $ | 51 |  |  | $ | 213 |  |  | $ | 196 |  |  | $ | 329 |  |  | $ | 1,109 |  |

[0000866374-21-000019:notes:35]
[same as prior period, unchanged from 0000866374-20-000030:notes:33]

[0000866374-21-000019:notes:36]
|  | As of December 31, 2020 |  | As of March 31, 2020 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 280 |  |  | $ | (149) |  |  | $ | 131 |  |  | $ | 275 |  |  | $ | (128) |  |  | $ | 147 |  |
| Licenses and other intangibles | 258 |  |  | (156) |  |  | 102 |  |  | 245 |  |  | (130) |  |  | 115 |  |
| Total | $ | 538 |  |  | $ | (305) |  |  | $ | 233 |  |  | $ | 520 |  |  | $ | (258) |  |  | $ | 262 |  |

[0000866374-21-000019:notes:37]
[same as prior period, unchanged from 0000866374-20-000030:notes:35]

[0000866374-21-000019:notes:38]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2021 (1) |  | $ | 16 |  |
| 2022 |  | 55 |  |
| 2023 |  | 47 |  |
| 2024 |  | 45 |  |
| 2025 |  | 40 |  |
| Thereafter |  | 30 |  |
| Total amortization expense |  | $ | 233 |  |

[0000866374-21-000019:notes:39]
[same as prior period, unchanged from 0000866374-20-000030:notes:37]

[0000866374-21-000019:notes:40]
(1)Represents estimated amortization for the remaining fiscal three-month period ending March 31, 2021.

[0000866374-21-000019:notes:41]
Other Current Liabilities
Other current liabilities include customer working capital advances of $371.3 million and $264.2 million, customer-related accruals of $242.7 million and $195.1 million, and current operating lease liabilities of $125.2 million and $114.1 million as of December 31, 2020 and March 31, 2020, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-21-000019:notes:42]
[same as prior period, unchanged from 0000866374-20-000030:notes:40]

[0000866374-21-000019:notes:43]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers

[0000866374-21-000019:notes:44]
that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-21-000019:notes:45]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-21-000019:notes:46]
[same as prior period, unchanged from 0000866374-20-000030:notes:44]

[0000866374-21-000019:notes:47]
[same as prior period, unchanged from 0000866374-20-000030:notes:45]

[0000866374-21-000019:notes:48]
[same as prior period, unchanged from 0000866374-20-000030:notes:46]

[0000866374-21-000019:notes:49]
[same as prior period, unchanged from 0000866374-20-000030:notes:47]

[0000866374-21-000019:notes:50]
[same as prior period, unchanged from 0000866374-20-000030:notes:48]

[0000866374-21-000019:notes:51]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on

[0000866374-21-000019:notes:52]
the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-21-000019:notes:53]
[same as prior period, unchanged from 0000866374-20-000030:notes:50]

[0000866374-21-000019:notes:54]
[same as prior period, unchanged from 0000866374-20-000030:notes:51]

[0000866374-21-000019:notes:55]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $483.4 million and $361.5 million as of December 31, 2020 and March 31, 2020, respectively.

[0000866374-21-000019:notes:56]
[same as prior period, unchanged from 0000866374-20-000030:notes:53]

[0000866374-21-000019:notes:57]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2020 and December 31, 2019, respectively.

[0000866374-21-000019:notes:58]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,544 |  |  | $ | 3,104 |  |  | $ | 8,813 |  |  | $ | 9,060 |  |
| Over time | 290 |  |  | 527 |  |  | 1,250 |  |  | 2,062 |  |
| Total | 3,834 |  |  | 3,631 |  |  | 10,063 |  |  | 11,122 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,189 |  |  | 2,050 |  |  | 5,292 |  |  | 5,101 |  |
| Over time | 697 |  |  | 780 |  |  | 2,503 |  |  | 2,502 |  |
| Total | 2,886 |  |  | 2,830 |  |  | 7,795 |  |  | 7,603 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,733 |  |  | 5,154 |  |  | 14,105 |  |  | 14,161 |  |
| Over time | 987 |  |  | 1,307 |  |  | 3,753 |  |  | 4,564 |  |
| Total | $ | 6,720 |  |  | $ | 6,461 |  |  | $ | 17,858 |  |  | $ | 18,725 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-21-000019:notes:59]
[same as prior period, unchanged from 0000866374-20-000030:notes:56]

[0000866374-21-000019:notes:60]
[same as prior period, unchanged from 0000866374-20-000030:notes:57]

[0000866374-21-000019:notes:61]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
|  | (In millions) |
| Cost of sales | $ | 6 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 11 |  |
| Selling, general and administrative expenses | 19 |  |  | 15 |  |  | 46 |  |  | 42 |  |
| Total share-based compensation expense | $ | 25 |  |  | $ | 19 |  |  | $ | 62 |  |  | $ | 53 |  |

[0000866374-21-000019:notes:62]
Total unrecognized compensation expense related to share options under all plans as well as the number of options outstanding and exercisable were immaterial as of December 31, 2020.

[0000866374-21-000019:notes:63]
During the nine-month period ended December 31, 2020, the Company granted 11.0 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 9.4 million are plain-vanilla unvested RSU awards that vest over a period of two to four years, with no performance or market conditions, and with an average grant date price of $10.34 per award. Further, approximately 1.6 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $15.03 per award and was calculated using a Monte Carlo simulation. The number of

[0000866374-21-000019:notes:64]
shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 3.2 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-21-000019:notes:65]
As of December 31, 2020, approximately 20.4 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 3.7 million awards is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 7.4 million based on the achievement levels of the respective conditions. During the nine-month period ended December 31, 2020, no shares vested in connection with the awards with market conditions granted in fiscal year 2018.

[0000866374-21-000019:notes:66]
As of December 31, 2020, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $153.6 million, and will be recognized over a weighted-average remaining vesting period of 2.1 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-21-000019:notes:67]
EARNINGS PER SHARE 
The following table reflects basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share attributable to the shareholders of Flex:

[0000866374-21-000019:notes:68]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
|  | (In millions, except per share amounts) |
| Basic earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 208 |  |  | $ | 111 |  |  | $ | 373 |  |  | $ | 39 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 500 |  |  | 507 |  |  | 500 |  |  | 511 |  |
| Basic earnings per share | $ | 0.42 |  |  | $ | 0.22 |  |  | $ | 0.75 |  |  | $ | 0.08 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 208 |  |  | $ | 111 |  |  | $ | 373 |  |  | $ | 39 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 500 |  |  | 507 |  |  | 500 |  |  | 511 |  |
| Weighted-average ordinary share equivalents from stock options and RSU awards (1) (2) | 8 |  |  | 3 |  |  | 5 |  |  | 4 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 508 |  |  | 510 |  |  | 505 |  |  | 515 |  |
| Diluted earnings per share | $ | 0.41 |  |  | $ | 0.22 |  |  | $ | 0.74 |  |  | $ | 0.08 |  |

[0000866374-21-000019:notes:69]
(1)An immaterial number of options to purchase ordinary shares were excluded from the computation of diluted earnings per share during the three and nine-month periods ended December 31, 2020 and December 31, 2019, respectively, due to their anti-dilutive impact on the weighted-average ordinary share equivalents.

[0000866374-21-000019:notes:70]
(2)An immaterial number of RSU awards and 2.9 million RSU awards for the three and nine-month periods ended December 31, 2020, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. RSU awards of 3.7 million and 4.0 million for the three and nine-month periods ended December 31, 2019, respectively, were excluded from the computation of diluted earnings per share.


## us-gaap:DebtDisclosureTextBlock

[0000866374-21-000019:notes:71]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2020 are as follows:

[0000866374-21-000019:notes:72]
|  | As of December 31, 2020 |  | As of March 31, 2020 |
|  | (In millions) |
| Term Loan, including current portion, due in installments through June 2022 | $ | — |  |  | $ | 433 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 324 |  |  | 310 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 597 |  |
| 3.750% Notes due February 2026 | 695 |  |  | — |  |
| 4.875% Notes due June 2029 | 661 |  |  | 662 |  |
| 4.875% Notes due May 2030 | 696 |  |  | — |  |
| India Facilities | 136 |  |  | 138 |  |
| Other | 225 |  |  | 211 |  |
| Debt issuance costs | (23) |  |  | (13) |  |
|  | 3,812 |  |  | 2,838 |  |
| Current portion, net of debt issuance costs | (72) |  |  | (149) |  |
| Non-current portion | $ | 3,740 |  |  | $ | 2,689 |  |

[0000866374-21-000019:notes:73]
The weighted-average interest rate for the Company's long-term debt was 4.0% as of December 31, 2020 and March 31, 2020, respectively.

[0000866374-21-000019:notes:74]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2020 are as follows:

[0000866374-21-000019:notes:75]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2021 (1) |  | $ | 56 |  |
| 2022 |  | 222 |  |
| 2023 |  | 531 |  |
| 2024 |  | 53 |  |
| 2025 |  | 324 |  |
| Thereafter |  | 2,649 |  |
| Total |  | $ | 3,835 |  |

[0000866374-21-000019:notes:76]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2021.

[0000866374-21-000019:notes:77]
Notes due February 2026 and May 2030

[0000866374-21-000019:notes:78]
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026 (the "Existing 2026 Notes"), at 99.617% of face value and $325 million aggregate principal amount of 4.875% Notes due May 2030 (the "Existing 2030 Notes" and, together with the Existing 2026 Notes, the "Existing Notes"), at 99.562% of face value. In August 2020, as a further issuance of the Existing Notes, the Company issued under the same terms (other than the initial interest accrual date and first interest payment date for the additional 2026 Notes, and the initial offering price and the issue date for the additional 2026 and 2030 Notes), an additional $250 million of 3.750% Notes due February 2026 (together with the Existing 2026 Notes, the "2026 Notes"), at 109.294% of face value, and $325 million of 4.875% Notes due May 2030 (together with the Existing 2030 Notes, the "2030 Notes"), at 114.863% of face value. Immediately after the issuance of the additional notes issued in August 2020, the Company has $675 million aggregate principal amount of 3.750% Notes due 2026 outstanding and $650 million aggregate principal amount of 4.875% Notes due 2030 outstanding. The Company received in aggregate, proceeds of approximately $1.4 billion, net of discounts and after premiums, from the issuances, which have been used for working capital and other general corporate purposes, in addition to repaying the term loan due June 2022. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet approximately $12.8 million of costs in conjunction with the issuance of the Notes.

[0000866374-21-000019:notes:79]
Interest on the 2026 Notes and the 2030 Notes is payable semi-annually, commencing on August 1, 2020 and November 12, 2020, respectively, except that interest on the additional 2026 Notes is payable commencing February 1, 2021. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2026 Notes or 2030 Notes may declare all of such series of Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of such series of Notes. As of December 31, 2020, the Company was in compliance with the covenants in the indenture governing the Notes.


## flex:InterestAndOtherNetTextBlock

[0000866374-21-000019:notes:80]
INTEREST AND OTHER, NET 
Interest and other, net for the three and nine-month periods ended December 31, 2020 and December 31, 2019 are primarily composed of the following:

[0000866374-21-000019:notes:81]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
|  | (In millions) |
| Interest expenses on debt obligations (1) | $ | 40 |  |  | $ | 35 |  |  | $ | 111 |  |  | $ | 114 |  |
| ABS and AR sales programs related expenses | 2 |  |  | 11 |  |  | 9 |  |  | 35 |  |
| Interest income | (4) |  |  | (5) |  |  | (10) |  |  | (15) |  |
| Gain on foreign exchange transactions | (3) |  |  | (3) |  |  | (8) |  |  | (7) |  |
| Equity in (earnings) losses (2) | (49) |  |  | (1) |  |  | (64) |  |  | 5 |  |
| Investment impairment (3) | 20 |  |  | 16 |  |  | 21 |  |  | 23 |  |

[0000866374-21-000019:notes:82]
(1)Interest expense on debt obligations for the three and nine-month periods ended December 31, 2019 include debt extinguishment costs of $0.8 million and $7.2 million, respectively, related to the full repayments of the Notes due February 2020 and the Term Loan due November 2021. There were immaterial debt extinguishment costs incurred during fiscal year 2021 from the repayment of the term loan due June 2022.

[0000866374-21-000019:notes:83]
(2)Represents (gains) losses on strategic investments in privately held companies accounted under equity method. During the three and nine-month periods ended December 31, 2020, the Company recognized equity in earnings of $49.0 million and $63.6 million, respectively, driven by unrealized gains of $44.0 million and $55.2 million, respectively, from the value increase in certain investment funds.

[0000866374-21-000019:notes:84]
(3)During the three-month periods ended December 31, 2020, and December 31, 2019, the Company incurred impairment charges of  $20.1 million and $15.8 million, respectively, related to a certain investment as a result of the Company’s ongoing assessment of its investment portfolio strategy and conclusion that the carrying amount of its investment was other than temporarily impaired.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-21-000019:notes:85]
[same as prior period, unchanged from 0000866374-20-000030:notes:80]

[0000866374-21-000019:notes:86]
[same as prior period, unchanged from 0000866374-20-000030:notes:81]

[0000866374-21-000019:notes:87]
As of December 31, 2020, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $9.5 billion as summarized below:

[0000866374-21-000019:notes:88]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| CNY |  | 2,751 |  |  | — |  |  | $ | 421 |  |  | $ | — |  |
| HUF |  | 33,062 |  |  | — |  |  | 111 |  |  | — |  |
| JPY |  | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN |  | 5,133 |  |  | — |  |  | 258 |  |  | — |  |
| MYR |  | 389 |  |  | 44 |  |  | 96 |  |  | 11 |  |
| Other |  | N/A |  | N/A |  | 219 |  |  | 67 |  |
|  |  |  |  |  |  | 1,405 |  |  | 78 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 646 |  |  | — |  |  | 125 |  |
| CAD |  | 128 |  |  | 112 |  |  | 100 |  |  | 87 |  |
| CNY |  | 3,178 |  |  | 391 |  |  | 482 |  |  | 60 |  |
| EUR |  | 2,025 |  |  | 2,113 |  |  | 2,473 |  |  | 2,580 |  |
| GBP |  | 55 |  |  | 78 |  |  | 74 |  |  | 105 |  |
| HUF |  | 63,519 |  |  | 63,796 |  |  | 213 |  |  | 214 |  |
| ILS |  | 571 |  |  | 150 |  |  | 177 |  |  | 47 |  |
| MXN |  | 6,882 |  |  | 5,519 |  |  | 346 |  |  | 277 |  |
| MYR |  | 671 |  |  | 291 |  |  | 165 |  |  | 72 |  |
| SEK |  | 393 |  |  | 455 |  |  | 47 |  |  | 55 |  |
| Other |  | N/A |  | N/A |  | 219 |  |  | 143 |  |
|  |  |  |  |  |  | 4,296 |  |  | 3,765 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 5,701 |  |  | $ | 3,843 |  |

[0000866374-21-000019:notes:89]
As of December 31, 2020, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of December 31, 2020 and March 31, 2020, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were $39.0 million as of December 31, 2020, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-21-000019:notes:90]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of December 31, 2020. The changes in fair value of the USD JPY cross currency swap are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also impacts the same line.

[0000866374-21-000019:notes:91]
[same as prior period, unchanged from 0000866374-20-000030:notes:86]

[0000866374-21-000019:notes:92]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31,2020 |  | March 31,2020 |  | Balance SheetLocation |  | December 31,2020 |  | March 31,2020 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 53 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 8 |  |  | $ | 47 |  |
| Foreign currency contracts | Other assets |  | $ | 23 |  |  | $ | 14 |  |  | Other liabilities |  | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 32 |  |  | $ | 83 |  |  | Other current liabilities |  | $ | 31 |  |  | $ | 103 |  |

[0000866374-21-000019:notes:93]
[same as prior period, unchanged from 0000866374-20-000030:notes:88]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-21-000019:notes:94]
[same as prior period, unchanged from 0000866374-20-000030:notes:89]

[0000866374-21-000019:notes:95]
|  | Three-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (45) |  |  | $ | (88) |  |  | $ | (133) |  |  | $ | (59) |  |  | $ | (131) |  |  | $ | (190) |  |
| Other comprehensive gain before reclassifications | 43 |  |  | 42 |  |  | 85 |  |  | 1 |  |  | 11 |  |  | 12 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (14) |  |  | — |  |  | (14) |  |  | 13 |  |  | (1) |  |  | 12 |  |
| Net current-period other comprehensive gain | 29 |  |  | 42 |  |  | 71 |  |  | 14 |  |  | 10 |  |  | 24 |  |
| Ending balance | $ | (16) |  |  | $ | (46) |  |  | $ | (62) |  |  | $ | (45) |  |  | $ | (121) |  |  | $ | (166) |  |

[0000866374-21-000019:notes:96]
|  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (82) |  |  | $ | (133) |  |  | $ | (215) |  |  | $ | (42) |  |  | $ | (110) |  |  | $ | (152) |  |
| Other comprehensive gain (loss) before reclassifications | 73 |  |  | 87 |  |  | 160 |  |  | (8) |  |  | (10) |  |  | (18) |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (7) |  |  | — |  |  | (7) |  |  | 5 |  |  | (1) |  |  | 4 |  |
| Net current-period other comprehensive gain (loss) | 66 |  |  | 87 |  |  | 153 |  |  | (3) |  |  | (11) |  |  | (14) |  |
| Ending balance | $ | (16) |  |  | $ | (46) |  |  | $ | (62) |  |  | $ | (45) |  |  | $ | (121) |  |  | $ | (166) |  |

[0000866374-21-000019:notes:97]
Substantially all unrealized losses and gains relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and nine-month periods ended December 31, 2020, respectively, were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-21-000019:notes:98]
[same as prior period, unchanged from 0000866374-20-000030:notes:93]

[0000866374-21-000019:notes:99]
[same as prior period, unchanged from 0000866374-20-000030:notes:94]

[0000866374-21-000019:notes:100]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” and together with the Global Program, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells a fraction of the receivables to unaffiliated financial institutions, based on the Company's requirements. Under these programs, the entire purchase price of sold receivables are paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The fair value of the guarantee obligation was immaterial as of December 31, 2020 and March 31, 2020, respectively. The accounts receivable balances sold under the ABS Programs were removed from the condensed consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-21-000019:notes:101]
[same as prior period, unchanged from 0000866374-20-000030:notes:96]

[0000866374-21-000019:notes:102]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three and nine-month periods ended December 31, 2020 and December 31, 2019 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-21-000019:notes:103]
As of March 31, 2020, approximately $0.8 billion, of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds for the same amount. As of December 31, 2020 an immaterial amount of accounts receivables had been sold under the ABS programs.

[0000866374-21-000019:notes:104]
For the nine-month period ended December 31, 2020, collections from sales of receivables to the special purpose entities under the ABS Programs consisted of approximately $6.6 billion for transfers of receivables. Further, cash flows from sales of

[0000866374-21-000019:notes:105]
receivables from the special purpose entities to unaffiliated financial institutions, during the same period, consisted of approximately $0.6 billion for transfer of receivables. For the nine-month period ended December 31, 2019 cash flows from sales of receivables under the previous ABS Programs consisted of approximately $3.7 billion, for transfers of receivables and approximately $2.2 billion for collections on deferred purchase price receivables (effective November 2019, the Company no longer holds a deferred purchase price receivables balance). The Company's cash flows from transfers of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-21-000019:notes:106]
Trade Accounts Receivable Sale Programs
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.1 billion and $0.4 billion as of December 31, 2020 and March 31, 2020, respectively. For the nine-month periods ended December 31, 2020 and December 31, 2019, total accounts receivable sold to certain third-party banking institutions was approximately $0.6 billion and $1.2 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received were included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-21-000019:notes:107]
[same as prior period, unchanged from 0000866374-20-000030:notes:102]

[0000866374-21-000019:notes:108]
[same as prior period, unchanged from 0000866374-20-000030:notes:103]

[0000866374-21-000019:notes:109]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager. The Company’s deferred compensation plan assets are included in other noncurrent assets on the condensed consolidated balance sheets and include investments in equity securities that are valued using active market prices. There were no investments  classified as level 1 in the fair value hierarchy as of December 31, 2020 and March 31, 2020.

[0000866374-21-000019:notes:110]
[same as prior period, unchanged from 0000866374-20-000030:notes:105]

[0000866374-21-000019:notes:111]
[same as prior period, unchanged from 0000866374-20-000030:notes:106]

[0000866374-21-000019:notes:112]
[same as prior period, unchanged from 0000866374-20-000030:notes:107]

[0000866374-21-000019:notes:113]
[same as prior period, unchanged from 0000866374-20-000030:notes:108]

[0000866374-21-000019:notes:114]
[same as prior period, unchanged from 0000866374-20-000030:notes:109]

[0000866374-21-000019:notes:115]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of December 31, 2020 and March 31, 2020.

[0000866374-21-000019:notes:116]
There were no transfers between levels in the fair value hierarchy during the nine-month periods ended December 31, 2020 and December 31, 2019.

[0000866374-21-000019:notes:117]
[same as prior period, unchanged from 0000866374-20-000030:notes:112]

[0000866374-21-000019:notes:118]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of December 31, 2020 and March 31, 2020:

[0000866374-21-000019:notes:119]
|  | Fair Value Measurements as of December 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,755 |  |  | $ | — |  |  | $ | 1,755 |  |
| Foreign currency contracts (Note 8) | — |  |  | 108 |  |  | — |  |  | 108 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 50 |  |  | — |  |  | 50 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (39) |  |  | $ | — |  |  | $ | (39) |  |
|  | Fair Value Measurements as of March 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 404 |  |  | $ | — |  |  | $ | 404 |  |
| Foreign currency contracts (Note 8) | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (149) |  |  | $ | — |  |  | $ | (149) |  |

[0000866374-21-000019:notes:120]
[same as prior period, unchanged from 0000866374-20-000030:notes:115]

[0000866374-21-000019:notes:121]
[same as prior period, unchanged from 0000866374-20-000030:notes:116]

[0000866374-21-000019:notes:122]
|  | As of December 31, 2020 |  | As of March 31, 2020 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | $ | — |  |  | $ | — |  |  | $ | 433 |  |  | $ | 414 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500 |  |  | 541 |  |  | 500 |  |  | 500 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 324 |  |  | 324 |  |  | 310 |  |  | 310 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 680 |  |  | 597 |  |  | 613 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 695 |  |  | 771 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 661 |  |  | 786 |  |  | 662 |  |  | 628 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 696 |  |  | 826 |  |  | — |  |  | — |  |  | Level 1 |
| Euro Term Loans | 175 |  |  | 175 |  |  | 208 |  |  | 208 |  |  | Level 2 |
| India Facilities | 136 |  |  | 136 |  |  | 138 |  |  | 138 |  |  | Level 2 |

[0000866374-21-000019:notes:123]
[same as prior period, unchanged from 0000866374-20-000030:notes:118]

[0000866374-21-000019:notes:124]
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans due March 2021 and January 2022 based on the current market rate, and as of December 31, 2020, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-21-000019:notes:125]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-21-000019:notes:126]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-21-000019:notes:127]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-21-000019:notes:128]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor agreed to an immaterial settlement.

[0000866374-21-000019:notes:129]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. Lead plaintiff’s opening appeal brief is due April 19, 2021, and defendants’ answering brief is due May 19, 2021. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-21-000019:notes:130]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash

[0000866374-21-000019:notes:131]
transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-21-000019:notes:132]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling 373.7 million Brazilian reals (approximately USD $72.0 million based on the exchange rate as of December 31, 2020). Four of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60.5 million Brazilian reals or USD $11.7 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Sao Paolo, Brazil on March 23, 2020; the value of that assessment is 33.9 million Brazilian reals (approximately USD $6.5 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-21-000019:notes:133]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-21-000019:notes:134]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $162.5 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-21-000019:notes:135]
A different foreign Tax Authority has issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for the periods fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagrees with the Tax Authority’s assertion and is actively contesting through administrative processes and will defend through judicial processes if necessary.

[0000866374-21-000019:notes:136]
As the final resolutions of the above tax items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-21-000019:notes:137]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-21-000019:notes:138]
SHARE REPURCHASES 
During the three-month and nine-month periods ended December 31, 2020, the Company repurchased 2.4 million shares at an aggregate purchase price of $37.7 million, and retired all of these shares.

[0000866374-21-000019:notes:139]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500.0 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of Annual General Meeting held on August 7, 2020. As of December 31, 2020, shares in the aggregate amount of $462.3 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-21-000019:notes:140]
SEGMENT REPORTING
In March 2020, the Company announced a change in organizational structure as part of its strategy to further drive efficiency and productivity with two focused delivery models. The Company’s chief operating decision maker ("CODM") changed from the CEO and certain direct staff who oversee operations of the business, to the CEO herself. As a result, beginning in fiscal year 2021, the Company now reports its financial performance based on two operating and reportable segments, Flex Agility Solutions (“FAS”) and Flex Reliability Solutions (“FRS”) and analyzes operating income as the measure of segment profitability.

[0000866374-21-000019:notes:141]
[same as prior period, unchanged from 0000866374-20-000030:notes:136]

[0000866374-21-000019:notes:142]
[same as prior period, unchanged from 0000866374-20-000030:notes:137]

[0000866374-21-000019:notes:143]
[same as prior period, unchanged from 0000866374-20-000030:notes:138]

[0000866374-21-000019:notes:144]
[same as prior period, unchanged from 0000866374-20-000030:notes:139]

[0000866374-21-000019:notes:145]
[same as prior period, unchanged from 0000866374-20-000030:notes:140]

[0000866374-21-000019:notes:146]
[same as prior period, unchanged from 0000866374-20-000030:notes:141]

[0000866374-21-000019:notes:147]
[same as prior period, unchanged from 0000866374-20-000030:notes:142]

[0000866374-21-000019:notes:148]
[same as prior period, unchanged from 0000866374-20-000030:notes:143]

[0000866374-21-000019:notes:149]
[same as prior period, unchanged from 0000866374-20-000030:notes:144]

[0000866374-21-000019:notes:150]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment charges, restructuring charges, legal and other, and interest and other, net. A portion of depreciation is allocated to the respective segment, together with other general corporate research and development and administrative expenses.

[0000866374-21-000019:notes:151]
Selected financial information by segment is in the table below. Fiscal year 2020 historical information has been recast to reflect the new operating and reportable segments, in the table below and in Item 2, "Management's Discussion and Analysis of Financial Condition and Results of Operations."

[0000866374-21-000019:notes:152]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,834 |  |  | $ | 3,631 |  |  | $ | 10,063 |  |  | $ | 11,122 |  |
| Flex Reliability Solutions | 2,886 |  |  | 2,830 |  |  | 7,795 |  |  | 7,603 |  |
|  | $ | 6,720 |  |  | $ | 6,461 |  |  | $ | 17,858 |  |  | $ | 18,725 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 153 |  |  | $ | 98 |  |  | $ | 313 |  |  | $ | 301 |  |
| Flex Reliability Solutions | 178 |  |  | 186 |  |  | 472 |  |  | 475 |  |
| Corporate and Other | (20) |  |  | (28) |  |  | (64) |  |  | (85) |  |
| Total segment income | 311 |  |  | 256 |  |  | 721 |  |  | 691 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 16 |  |  | 16 |  |  | 47 |  |  | 49 |  |
| Stock-based compensation | 25 |  |  | 19 |  |  | 62 |  |  | 53 |  |
| Customer related asset impairments (recoveries) (1) | — |  |  | 4 |  |  | (3) |  |  | 95 |  |
| Restructuring charges (Note 15) | 30 |  |  | 15 |  |  | 75 |  |  | 199 |  |
| Legal and other (2) | — |  |  | 7 |  |  | 28 |  |  | 29 |  |
| Interest and other, net | 7 |  |  | 50 |  |  | 58 |  |  | 153 |  |
| Income before income taxes | $ | 233 |  |  | $ | 145 |  |  | $ | 454 |  |  | $ | 113 |  |

[0000866374-21-000019:notes:153]
(1)Customer related asset impairments for the three-month and nine-month periods ended December 31, 2020 were not material and for the three-month and nine-month periods ended December 31, 2019 primarily relate to additional provision for doubtful accounts receivable, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand.

[0000866374-21-000019:notes:154]
(2)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis. During the first quarter of fiscal year 2021, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-21-000019:notes:155]
Legal and other during the three-month and nine-month periods ended December 31, 2019 primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India.

[0000866374-21-000019:notes:156]
[same as prior period, unchanged from 0000866374-20-000030:notes:151]

[0000866374-21-000019:notes:157]
[same as prior period, unchanged from 0000866374-20-000030:notes:152]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-21-000019:notes:158]
RESTRUCTURING CHARGESIn order to support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, the Company has identified and is engaging in certain structural changes. These restructuring actions will eliminate non-core activities primarily within the Company’s corporate function, align the Company’s cost structure with its reorganizing and optimizing of its operations model along its two reporting segments, and further sharpen its focus to winning business in end markets where it has competitive advantages and deep domain expertise. 
During the three-month and nine-month periods ended December 31, 2020, the Company recognized approximately $30.0 million and $75.0 million of restructuring charges, respectively, most of which related to employee severance.

[0000866374-21-000019:notes:159]
During the first half of fiscal year 2020 in connection with geopolitical developments and uncertainties at the time, primarily impacting one customer in China, the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and streamline its cost structure. During the three-month and nine-month periods ended December 31, 2019, the Company recognized $14.6 million and $199.1 million of restructuring charges, respectively. The Company incurred cash charges of approximately $14.9 million and $142.7 million, respectively, that were predominantly for employee severance, and non-cash charges of an immaterial amount and $56.4 million, respectively, primarily related to asset impairments during the three and nine-month periods ended December 31, 2019.

[0000866374-21-000019:notes:160]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of December 31, 2020 for charges incurred during the nine-month period ended December 31, 2020:

[0000866374-21-000019:notes:161]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2020 | $ | 20 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 24 |  |
| Provision for charges incurred during the nine-month period ended December 31, 2020 | 68 |  |  | 3 |  |  | 4 |  |  | 75 |  |
| Cash payments for charges incurred in the fiscal year 2020 and prior | (13) |  |  | — |  |  | (1) |  |  | (14) |  |
| Cash payments for charges incurred during the nine-month period ended December 31, 2020 | (35) |  |  | — |  |  | (1) |  |  | (36) |  |
| Non-cash charges incurred during the nine-month period ended December 31, 2020 | — |  |  | (3) |  |  | 1 |  |  | (2) |  |
| Balance as of December 31, 2020 | 40 |  |  | — |  |  | 7 |  |  | 47 |  |
| Less: Current portion (classified as other current liabilities) | 39 |  |  | — |  |  | 7 |  |  | 46 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
