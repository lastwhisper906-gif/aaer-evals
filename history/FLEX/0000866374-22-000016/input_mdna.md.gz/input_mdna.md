# FLEX MD&A — 0000866374-22-000016


## mdna

[0000866374-22-000016:mdna:1]
[same as prior period, unchanged from 0000866374-21-000062:mdna:1]

[0000866374-22-000016:mdna:2]
[same as prior period, unchanged from 0000866374-21-000062:mdna:2]

[0000866374-22-000016:mdna:3]
[same as prior period, unchanged from 0000866374-21-000062:mdna:5]

[0000866374-22-000016:mdna:4]
[same as prior period, unchanged from 0000866374-21-000062:mdna:6]

[0000866374-22-000016:mdna:5]
[same as prior period, unchanged from 0000866374-21-000062:mdna:7]

[0000866374-22-000016:mdna:6]
[same as prior period, unchanged from 0000866374-21-000062:mdna:8]

[0000866374-22-000016:mdna:7]
[same as prior period, unchanged from 0000866374-21-000062:mdna:9]

[0000866374-22-000016:mdna:8]
[same as prior period, unchanged from 0000866374-21-000062:mdna:10]

[0000866374-22-000016:mdna:9]
[same as prior period, unchanged from 0000866374-21-000062:mdna:11]

[0000866374-22-000016:mdna:10]
[same as prior period, unchanged from 0000866374-21-000062:mdna:12]

[0000866374-22-000016:mdna:11]
[same as prior period, unchanged from 0000866374-21-000062:mdna:13]

[0000866374-22-000016:mdna:12]
[same as prior period, unchanged from 0000866374-21-000062:mdna:14]

[0000866374-22-000016:mdna:13]
[same as prior period, unchanged from 0000866374-21-000062:mdna:15]

[0000866374-22-000016:mdna:14]
[same as prior period, unchanged from 0000866374-21-000062:mdna:16]

[0000866374-22-000016:mdna:15]
[same as prior period, unchanged from 0000866374-21-000062:mdna:17]

[0000866374-22-000016:mdna:16]
[same as prior period, unchanged from 0000866374-21-000062:mdna:18]

[0000866374-22-000016:mdna:17]
[same as prior period, unchanged from 0000866374-21-000062:mdna:19]

[0000866374-22-000016:mdna:18]
With the second wave of the pandemic including follow-on variants of COVID-19, there have been renewed disease control measures being taken to limit the spread including movement bans and shelter-in-place orders. We continue to closely monitor the situation in all the locations where we operate. Our priority remains the welfare of our employees. In addition, our end markets continue to be impacted by the global supply chain disruptions. Component shortages and logistical constraints are pervasive across the entire value chain. COVID-19 related restrictions also contributed to a declining workforce, including at ports and warehouses, as well as creating driver shortages around the world. We expect persistent waves of COVID-19 to remain a headwind into the near future. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future as we are continuing to see increasing supply constraints and costs. Refer to “Risk Factors - The ongoing COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material.” as disclosed in Part II, “Item 1A. Risk Factors.”

[0000866374-22-000016:mdna:19]
[same as prior period, unchanged from 0000866374-21-000062:mdna:23]

[0000866374-22-000016:mdna:20]
[same as prior period, unchanged from 0000866374-21-000062:mdna:24]

[0000866374-22-000016:mdna:21]
[same as prior period, unchanged from 0000866374-21-000062:mdna:25]

[0000866374-22-000016:mdna:22]
On February 1, 2022, affiliates of ours entered into a purchase agreement (the “Purchase Agreement”) with TPG Rise Flash, L.P., a Delaware limited partnership, which is managed or advised by TPG Rise Climate, TPG, Inc.’s dedicated renewables and climate investing fund (“TPG Rise”), for the sale of 500,000 Series A Preferred Units (the “Preferred Units”) in Nextracker LLC for an aggregate purchase price of $500 million (the “Preferred Sale”). TPG Rise’s investment in approximately 16.7% of Nextracker LLC reflects an implied value for Nextracker LLC as of the date of the investment of $3.0 billion. See Note 16 to the condensed consolidated financial statements for further information.

[0000866374-22-000016:mdna:23]
This Quarterly Report on Form 10-Q for the third quarter ended December 31, 2021 does not constitute an offer to sell or a solicitation of an offer to buy securities, and shall not constitute an offer, solicitation or sale in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of that jurisdiction.

[0000866374-22-000016:mdna:24]
[same as prior period, unchanged from 0000866374-21-000062:mdna:30]

[0000866374-22-000016:mdna:25]
We are one of the world's largest providers of global supply chain solutions, with revenues of $19.2 billion for the nine-month period ended December 31, 2021 and $24.1 billion in fiscal year 2021. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-22-000016:mdna:26]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 2,681 |  |  | 41 | % |  | $ | 2,562 |  |  | 38 | % |  | $ | 7,865 |  |  | 41 | % |  | $ | 7,119 |  |  | 40 | % |
| Asia | 2,548 |  |  | 38 | % |  | 2,695 |  |  | 40 | % |  | 7,260 |  |  | 38 | % |  | 6,985 |  |  | 39 | % |
| Europe | 1,390 |  |  | 21 | % |  | 1,463 |  |  | 22 | % |  | 4,065 |  |  | 21 | % |  | 3,754 |  |  | 21 | % |
|  | $ | 6,619 |  |  |  |  | $ | 6,720 |  |  |  |  | $ | 19,190 |  |  |  |  | $ | 17,858 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 1,598 |  |  | 24 | % |  | $ | 1,721 |  |  | 26 | % |  | $ | 4,676 |  |  | 24 | % |  | $ | 4,631 |  |  | 26 | % |
| Mexico | 1,250 |  |  | 19 | % |  | 1,177 |  |  | 18 | % |  | 3,710 |  |  | 19 | % |  | 3,237 |  |  | 18 | % |
| U.S. | 849 |  |  | 13 | % |  | 964 |  |  | 14 | % |  | 2,571 |  |  | 13 | % |  | 2,728 |  |  | 15 | % |
| Brazil | 568 |  |  | 9 | % |  | 405 |  |  | 6 | % |  | 1,533 |  |  | 8 | % |  | 1,116 |  |  | 6 | % |
| Malaysia | 527 |  |  | 8 | % |  | 459 |  |  | 7 | % |  | 1,350 |  |  | 7 | % |  | 1,191 |  |  | 7 | % |
| Hungary | 265 |  |  | 4 | % |  | 385 |  |  | 6 | % |  | 912 |  |  | 5 | % |  | 942 |  |  | 5 | % |
| Other | 1,562 |  |  | 23 | % |  | 1,609 |  |  | 23 | % |  | 4,438 |  |  | 24 | % |  | 4,013 |  |  | 23 | % |
|  | $ | 6,619 |  |  |  |  | $ | 6,720 |  |  |  |  | $ | 19,190 |  |  |  |  | $ | 17,858 |  |  |  |

[0000866374-22-000016:mdna:27]
|  | As of |  | As of |
| Property and equipment, net: | December 31, 2021 |  | March 31, 2021 |
|  | (In millions) |
| Mexico | $ | 593 |  |  | 28 | % |  | $ | 553 |  |  | 26 | % |
| U.S. | 361 |  |  | 17 | % |  | 361 |  |  | 17 | % |
| China | 302 |  |  | 14 | % |  | 331 |  |  | 16 | % |
| India | 136 |  |  | 6 | % |  | 166 |  |  | 8 | % |
| Hungary | 114 |  |  | 5 | % |  | 105 |  |  | 5 | % |
| Malaysia | 110 |  |  | 5 | % |  | 106 |  |  | 5 | % |
| Other | 496 |  |  | 25 | % |  | 475 |  |  | 23 | % |
|  | $ | 2,112 |  |  |  |  | $ | 2,097 |  |  |  |

[0000866374-22-000016:mdna:28]
[same as prior period, unchanged from 0000866374-21-000062:mdna:34]

[0000866374-22-000016:mdna:29]
[same as prior period, unchanged from 0000866374-21-000062:mdna:35]

[0000866374-22-000016:mdna:30]
[same as prior period, unchanged from 0000866374-21-000062:mdna:36]

[0000866374-22-000016:mdna:31]
[same as prior period, unchanged from 0000866374-21-000062:mdna:37]

[0000866374-22-000016:mdna:32]
[same as prior period, unchanged from 0000866374-21-000062:mdna:38]

[0000866374-22-000016:mdna:33]
[same as prior period, unchanged from 0000866374-21-000062:mdna:39]

[0000866374-22-000016:mdna:34]
[same as prior period, unchanged from 0000866374-21-000062:mdna:40]

[0000866374-22-000016:mdna:35]
[same as prior period, unchanged from 0000866374-21-000062:mdna:41]

[0000866374-22-000016:mdna:36]
[same as prior period, unchanged from 0000866374-21-000062:mdna:42]

[0000866374-22-000016:mdna:37]
[same as prior period, unchanged from 0000866374-21-000062:mdna:43]

[0000866374-22-000016:mdna:38]
[same as prior period, unchanged from 0000866374-21-000062:mdna:44]

[0000866374-22-000016:mdna:39]
[same as prior period, unchanged from 0000866374-21-000062:mdna:45]

[0000866374-22-000016:mdna:40]
[same as prior period, unchanged from 0000866374-21-000062:mdna:46]

[0000866374-22-000016:mdna:41]
[same as prior period, unchanged from 0000866374-21-000062:mdna:47]

[0000866374-22-000016:mdna:42]
[same as prior period, unchanged from 0000866374-21-000062:mdna:48]

[0000866374-22-000016:mdna:43]
[same as prior period, unchanged from 0000866374-21-000062:mdna:49]

[0000866374-22-000016:mdna:44]
[same as prior period, unchanged from 0000866374-21-000062:mdna:50]

[0000866374-22-000016:mdna:45]
[same as prior period, unchanged from 0000866374-21-000062:mdna:51]

[0000866374-22-000016:mdna:46]
[same as prior period, unchanged from 0000866374-21-000062:mdna:52]

[0000866374-22-000016:mdna:47]
[same as prior period, unchanged from 0000866374-21-000062:mdna:53]

[0000866374-22-000016:mdna:48]
[same as prior period, unchanged from 0000866374-21-000062:mdna:54]

[0000866374-22-000016:mdna:49]
[same as prior period, unchanged from 0000866374-21-000062:mdna:55]

[0000866374-22-000016:mdna:50]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 92.6 |  |  | 92.8 |  |  | 92.6 |  |  | 93.5 |  |
| Gross profit | 7.4 |  |  | 7.2 |  |  | 7.4 |  |  | 6.5 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.3 |  |  | 3.3 |  |  | 3.5 |  |
| Intangible amortization | 0.3 |  |  | 0.2 |  |  | 0.2 |  |  | 0.3 |  |
| Operating income | 3.7 |  |  | 3.7 |  |  | 3.9 |  |  | 2.7 |  |
| Interest and other, net | 0.1 |  |  | 0.1 |  |  | (0.5) |  |  | 0.3 |  |
| Income before income taxes | 3.6 |  |  | 3.6 |  |  | 4.4 |  |  | 2.4 |  |
| Provision for income taxes | 0.2 |  |  | 0.4 |  |  | 0.4 |  |  | 0.5 |  |
| Net income | 3.4 | % |  | 3.2 | % |  | 4.0 | % |  | 1.9 | % |

[0000866374-22-000016:mdna:51]
[same as prior period, unchanged from 0000866374-21-000062:mdna:57]

[0000866374-22-000016:mdna:52]
[same as prior period, unchanged from 0000866374-21-000062:mdna:58]

[0000866374-22-000016:mdna:53]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,581 |  |  | 54 | % |  | $ | 3,834 |  |  | 57 | % |  | $ | 10,450 |  |  | 54 | % |  | $ | 10,063 |  |  | 56 | % |
| Flex Reliability Solutions | 3,038 |  |  | 46 | % |  | 2,886 |  |  | 43 | % |  | 8,740 |  |  | 46 | % |  | 7,795 |  |  | 44 | % |
|  | $ | 6,619 |  |  |  |  | $ | 6,720 |  |  |  |  | $ | 19,190 |  |  |  |  | $ | 17,858 |  |  |  |

[0000866374-22-000016:mdna:54]
Net sales during the three-month period ended December 31, 2021 totaled $6.6 billion, representing a decrease of approximately $0.1 billion, or 2% from $6.7 billion during the three-month period ended December 31, 2020. Net sales for our FAS segment decreased approximately $0.3 billion, or 7% from the three-month period ended December 31, 2020, primarily driven by a 23% year-over-year decrease in our Consumer Devices, due to a planned project completion, and a mid-single-digit decline in our CEC businesses due to impacts from COVID-19 outlined above and specifically related to scarcity of component and raw materials and logistics constraints. This was partially offset by low-single digit growth in our Lifestyle business. Net sales for our FRS segment increased approximately $0.2 billion, or 5% from the three-month period ended December 31, 2020, primarily driven by mid-teens year-over-year growth in our Industrial business led by customer ramps and strong demand in key areas including electric vehicles (EV) charging and renewables, semicap, and robotics. This growth was tempered by a mid-single digit decline in our Automotive business due to impacts from COVID-19 outlined above and specifically related to scarcity of component constraints, and a low-single digit decline in Health Solutions due to a higher comparable that benefited from strong COVID-19 related business. Net sales decreased $0.1 billion, down to $2.5 billion in Asia, and $0.1 billion down to $1.4 billion in Europe, offset by a $0.1 billion increase to $2.7 billion in the Americas.

[0000866374-22-000016:mdna:55]
Net sales during the nine-month period ended December 31, 2021 totaled $19.2 billion, representing an increase of approximately $1.3 billion, or 7% from $17.9 billion during the nine-month period ended December 31, 2020. Net sales for our FAS segment increased $0.4 billion, or 4% from the nine-month period ended December 31, 2020, primarily driven by an increase in our Lifestyle business and to a lesser extent an increase in our Consumer Devices business. These increases were driven by a lesser impact from COVID-19 production pressure during the current year versus the prior year, coupled with new ramps, customer expansions and continued recoveries in consumer spending, offset to some extent by the scarcity of components and raw material and logistics constraints noted above. The increases noted in FAS during the nine-month period ended December 31, 2021 were partially offset by a decrease in our CEC business primarily due to component shortages. Net sales for our FRS segment increased approximately $0.9 billion, or 12% from the nine-month period ended December 31, 2020, primarily due to an increase in our Industrial business, as a result of customer ramps and strong demand in EV charging and renewables, semicap, and robotics. In addition, net sales for our Automotive business increased due to depressed automotive sales from factory shutdowns in the first quarter of fiscal year 2021. The increase in our Automotive business was partially constrained by component shortages and OEM plant shutdowns during the nine-month period ended December 31, 2021. Net sales increased across all regions with a $0.7 billion increase to $7.9 billion in the Americas, a $0.3 billion increase to $7.3 billion in Asia, and a $0.3 billion increase to $4.1 billion in Europe.

[0000866374-22-000016:mdna:56]
33

[0000866374-22-000016:mdna:57]
Our ten largest customers during the three and nine-month periods ended December 31, 2021 accounted for approximately 35% of net sales. Our ten largest customers, during the three and nine-month periods ended December 31, 2020, accounted for approximately 36% and 37% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and nine-month periods ended December 31, 2021 or December 31, 2020.

[0000866374-22-000016:mdna:58]
[same as prior period, unchanged from 0000866374-21-000062:mdna:64]

[0000866374-22-000016:mdna:59]
[same as prior period, unchanged from 0000866374-21-000062:mdna:65]

[0000866374-22-000016:mdna:60]
Cost of sales during the three-month period ended December 31, 2021 totaled $6.1 billion, representing a decrease of approximately $0.1 billion, or 1% from $6.2 billion during the three-month period ended December 31, 2020. The lower cost of sales for the three-month period ended December 31, 2021 was primarily driven by decreased consolidated sales of $0.1 billion. Cost of sales in FAS for the three-month period ended December 31, 2021 decreased approximately 7%, or $0.3 billion from the three-month period ended December 31, 2020, which is aligned with the overall 7% decrease in FAS revenue during the same period primarily as a result of lower revenue in our Consumer Devices and CEC businesses. Cost of sales in FRS for the three-month period ended December 31, 2021 increased 7%, or $0.2 billion from the three-month period ended December 31, 2020, which is slightly higher than the overall 5% increase in FRS revenue during the same period primarily due to continued increases in freight and logistics costs impacting our Industrial business.

[0000866374-22-000016:mdna:61]
Cost of sales during the nine-month period ended December 31, 2021 totaled $17.8 billion, representing an increase of approximately $1.1 billion, or 6% from $16.7 billion during the nine-month period ended December 31, 2020. The increase in cost of sales for the nine-month period ended December 31, 2021 was primarily driven by the increased consolidated sales of $1.3 billion during the same period.

[0000866374-22-000016:mdna:62]
[same as prior period, unchanged from 0000866374-21-000062:mdna:68]

[0000866374-22-000016:mdna:63]
[same as prior period, unchanged from 0000866374-21-000062:mdna:69]

[0000866374-22-000016:mdna:64]
Gross profit during the three-month period ended December 31, 2021 remained relatively flat at $0.5 billion, or 7.4% of net sales, and $0.5 billion, or 7.2% of net sales, during the three-month period ended December 31, 2020. Gross margin improved 20 basis points during the same period despite certain COVID-19 disruptions, industry-wide component shortages and cost pressures on logistics in the three-month period ended December 31, 2021. The increase in gross margin during the current period resulted primarily from the overall stronger cost discipline focused on driving further productivity improvements, coupled with continued improvement in the mix of our business, benefits from prior restructuring activities and a lower direct and incremental impact from COVID-19 compared to the prior year period.

[0000866374-22-000016:mdna:65]
Gross profit during the nine-month period ended December 31, 2021 increased $0.2 billion to $1.4 billion, or 7.4% of net sales, from $1.2 billion, or 6.5% of net sales, during the nine-month period ended December 31, 2020. Gross margin improved 90 basis points during the same period due to the same factors noted above in the three-month periods discussion coupled with stronger demand in our Automotive business.

[0000866374-22-000016:mdna:66]
[same as prior period, unchanged from 0000866374-21-000062:mdna:72]

[0000866374-22-000016:mdna:67]
[same as prior period, unchanged from 0000866374-21-000062:mdna:73]

[0000866374-22-000016:mdna:68]
[same as prior period, unchanged from 0000866374-21-000062:mdna:74]

[0000866374-22-000016:mdna:69]
[same as prior period, unchanged from 0000866374-21-000062:mdna:75]

[0000866374-22-000016:mdna:70]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 163 |  |  | 4.6 | % |  | $ | 153 |  |  | 4.0 | % |  | $ | 453 |  |  | 4.3 | % |  | $ | 313 |  |  | 3.1 | % |
| Flex Reliability Solutions | 154 |  |  | 5.1 | % |  | 178 |  |  | 6.2 | % |  | 475 |  |  | 5.4 | % |  | 472 |  |  | 6.1 | % |

[0000866374-22-000016:mdna:71]
FAS segment margin increased 60 basis points, to 4.6% for the three-month period ended December 31, 2021, from 4.0% for the three-month period ended December 31, 2020 and 120 basis points, to 4.3% for the nine-month period ended December 31, 2021, from 3.1% for the nine-month period ended December 31, 2020. The margin increase was driven by disciplined cost management and improved efficiencies as noted above, partially offset by the elevated costs due to component shortages and logistics constraints across all of our end markets.

[0000866374-22-000016:mdna:72]
FRS segment margin decreased 110 basis points, to 5.1% for the three-month period ended December 31, 2021, from 6.2% for the three-month period ended December 31, 2020. The margin decrease in FRS was primarily driven by production disruptions in our Automotive business, as well as continued freight and logistics cost headwinds impacting our Industrial business during the three-month period ended December 31, 2021. FRS segment margin decreased 70 basis points, to 5.4% for the nine-month period ended December 31, 2021, from 6.1% for the nine-month period ended December 31, 2020. The decrease in FRS segment margin during the nine-month period is primarily due to the continued freight and logistics constraints impacting our Industrial business.

[0000866374-22-000016:mdna:73]
[same as prior period, unchanged from 0000866374-21-000062:mdna:81]

[0000866374-22-000016:mdna:74]
Selling, general and administrative expenses (“SG&A”) was $0.2 billion, or 3.4% of net sales, during the three-month period ended December 31, 2021, increasing $2 million from $0.2 billion, or 3.3% of net sales, during the three-month period ended December 31, 2020. SG&A was $0.6 billion, or 3.3% of net sales, during the nine-month period ended December 31, 2021, increasing $20 million from $0.6 billion, or 3.5% of net sales, during the nine-month period ended December 31, 2020, which reflects our enhanced cost control efforts to support higher revenue growth while keeping our SG&A expenses relatively flat.

[0000866374-22-000016:mdna:75]
[same as prior period, unchanged from 0000866374-21-000062:mdna:83]

[0000866374-22-000016:mdna:76]
Amortization of intangible assets marginally declined to $15 million during the three-month period ended December 31, 2021, from $16 million for the three-month period ended December 31, 2020, and declined to $45 million during the nine-month period ended December 31, 2021, from $47 million for the nine-month period ended December 31, 2020, primarily due to certain intangibles now being fully amortized offset by one month of amortization expense related to new intangible assets from the Anord Mardix acquisition in December 2021.

[0000866374-22-000016:mdna:77]
[same as prior period, unchanged from 0000866374-21-000062:mdna:85]

[0000866374-22-000016:mdna:78]
Interest and other, net remained relatively flat and was an expense of $8 million and $7 million during the three-month period ended December 31, 2021 and the three-month period ended December 31, 2020, respectively.

[0000866374-22-000016:mdna:79]
Interest and other, net was income of $103 million during the nine-month period ended December 31, 2021 compared to an expense of $58 million during the nine-month period ended December 31, 2020, primarily driven by a $150 million gain related to a certain tax credit recorded upon approval of a "Credit Habilitation" request by the relevant Brazil tax authorities. This is a non-cash gain which will be used to offset certain current and future tax obligations. Refer to note 13 to the condensed consolidated financial statements for further detail.

[0000866374-22-000016:mdna:80]
[same as prior period, unchanged from 0000866374-21-000062:mdna:88]

[0000866374-22-000016:mdna:81]
[same as prior period, unchanged from 0000866374-21-000062:mdna:89]

[0000866374-22-000016:mdna:82]
The consolidated effective tax rate was 7% and 9% for the three and nine-month periods ended December 31, 2021, and 11% and 18% for the three and nine-month periods ended December 31, 2020, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our

[0000866374-22-000016:mdna:83]
revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, the Netherlands and Israel. The effective tax rate for the three and nine-month periods ended December 31, 2021 is lower than the effective tax rate for the three-month and nine-month periods ended December 31, 2020, primarily due to a $16.8 million release of a previously established valuation allowance on deferred tax assets because of the recognition of $16.8 million in net deferred tax liability recorded in connection with the Anord Mardix acquisition.

[0000866374-22-000016:mdna:84]
[same as prior period, unchanged from 0000866374-21-000062:mdna:91]

[0000866374-22-000016:mdna:85]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of December 31, 2021, we had cash and cash equivalents of approximately $2.6 billion and bank and other borrowings of approximately $4.4 billion. We have a $2.0 billion revolving credit facility that is due to mature in January 2026 (the "2026 Credit Facility"), under which we had no borrowings outstanding as of December 31, 2021. During the three-month period ended December 31, 2021, we also issued HUF 100 billion of 3.6% bonds due December 2031 (approximately $306 million, as of December 31, 2021) and borrowed €350 million under a one-year term loan (approximately $397 million as of December 31, 2021) at an interest rate of (0.18)% per annum. The proceeds of the new debt will be used to refinance certain other outstanding debt and for other general corporate purposes. Refer to note 6 to the condensed consolidated financial statement for details. As of December 31, 2021, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-22-000016:mdna:86]
Cash provided by operating activities was $0.7 billion during the nine-month period ended December 31, 2021, primarily driven by $0.8 billion of net income for the period plus $0.4 billion of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation offset by changes in net working capital as discussed below.

[0000866374-22-000016:mdna:87]
We believe net working capital ("NWC") and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, plus inventories and contract assets, less accounts payable. Net working capital increased $1.0 billion to $3.9 billion as of December 31, 2021, from $2.9 billion as of March 31, 2021. This increase is primarily driven by a $2.0 billion increase in inventories due to component shortages, clear-to build constraints and logistics challenges driving up buffer stock and inventory pricing, partially offset by a $0.6 billion decrease in net receivables and a $0.7 billion increase in accounts payable. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended December 31, 2021, increased to 14.5% from 11.5% of annualized net sales for the quarter ended March 31, 2021 due to component shortages and logistics constraints. We continue to see component shortages in the supply chain and logistical constraints, and although we are actively managing these impacts, we expect continued working capital pressure in the near future. We expect it will take additional time to adequately drive down our inventory levels to align with the current demand environment. We are proactively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative resetting our load planning. In addition, we are pursuing alternative resources using inclusive hybrid solutions to minimize transit times and implementing operational efficiencies. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future as we are continuing to see increasing supply constraints and costs. We are working diligently with our partners to secure needed parts and fulfill demand. In addition, to the extent possible, we have collaborated with our customers for working capital advances to offset the required investment in inventory. Advances from customers as of December 31, 2021 increased $0.5 billion from $0.5 billion as of March 31, 2021.

[0000866374-22-000016:mdna:88]
Cash used in investing activities was $0.8 billion during the nine-month period ended December 31, 2021. This was primarily driven by $0.5 billion of cash paid for the acquisition of Anord Mardix in December 2021, net of cash acquired, and $0.3 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Health Solutions, Automotive, and Industrial businesses.

[0000866374-22-000016:mdna:89]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. During fiscal year 2021, we proactively and strategically reduced the outstanding balance of our ABS programs. As this decrease in cash flow reflected the change of our capital strategy, we added this back for our adjusted free cash flow calculation and also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation for fiscal year 2021. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” (Adjusted Free Cash Flow

[0000866374-22-000016:mdna:90]
subsection) of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2021 for further discussion. Our adjusted free cash flows for the nine-month period ended December 31, 2021 and December 31, 2020 was an inflow of $0.3 billion and $0.5 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-22-000016:mdna:91]
|  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |
|  | (In millions) |
| Net cash provided by (used in) operating activities | $ | 664 |  |  | $ | (17) |  |
| Reduction in ABS levels and other | — |  |  | 795 |  |
| Purchases of property and equipment | (333) |  |  | (261) |  |
| Proceeds from the disposition of property and equipment | 9 |  |  | 25 |  |
| Adjusted free cash flow | $ | 340 |  |  | $ | 542 |  |

[0000866374-22-000016:mdna:92]
Cash provided by financing activities was $0.1 billion during the nine-month period ended December 31, 2021, which was primarily driven by additional debt and bank borrowings of $0.7 billion (as discussed above and in note 6 to the condensed consolidated financial statements), offset by $0.6 billion of cash paid for the repurchase of our ordinary shares.

[0000866374-22-000016:mdna:93]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of December 31, 2021, and March 31, 2021, less than half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.5 billion as of March 31, 2021). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-22-000016:mdna:94]
[same as prior period, unchanged from 0000866374-21-000062:mdna:101]

[0000866374-22-000016:mdna:95]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs amounted to approximately $0.4 billion and $0.9 billion for the three and nine-month periods ended December 31, 2021, respectively, and $0.3 billion and $0.7 billion for the three and nine-month periods ended December 31, 2020, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-22-000016:mdna:96]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to a commercial paper program, and a revolving sale and repurchase of subordinated notes established under the securitization facility, under which there were no borrowings outstanding as of December 31, 2021.

[0000866374-22-000016:mdna:97]
[same as prior period, unchanged from 0000866374-21-000062:mdna:104]

[0000866374-22-000016:mdna:98]
[same as prior period, unchanged from 0000866374-21-000062:mdna:105]

[0000866374-22-000016:mdna:99]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-22-000016:mdna:100]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 4, 2021. During the nine-month period ended December 31, 2021, we paid $0.6 billion to repurchase shares under the current and prior repurchase plans at an average price of $18.14 per share. As of December 31, 2021, shares in the aggregate amount of $0.6 billion were available to be repurchased under the current plan.

[0000866374-22-000016:mdna:101]
[same as prior period, unchanged from 0000866374-21-000062:mdna:108]

[0000866374-22-000016:mdna:102]
[same as prior period, unchanged from 0000866374-21-000062:mdna:109]

[0000866374-22-000016:mdna:103]
During fiscal year 2022, we issued 3.6% HUF 100 billion bonds (approximately $306.3 million as of December 31, 2021) due December 2031, which was then swapped to U.S. dollars and we borrowed €350 million term loan (approximately $397 million as of December 31, 2021) due December 2022 with a (0.18)% interest rate.

[0000866374-22-000016:mdna:104]
Other than the changes discussed above, there were no material changes in our contractual obligations and commitments as of December 31, 2021.

[0000866374-22-000016:mdna:105]
[same as prior period, unchanged from 0000866374-21-000062:mdna:111]

[0000866374-22-000016:mdna:106]
As of December 31, 2021, and March 31, 2021, the outstanding balance on receivables sold for cash was $0.4 billion and $0.2 billion, respectively, under our accounts receivable factoring program, which were removed from accounts receivable balances in our condensed consolidated balance sheets. There were no outstanding balance of receivables sold under our ABS programs as of each of the periods presented. For further information, see note 10 to the condensed consolidated financial statements.
