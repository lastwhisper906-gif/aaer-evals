# FLEX note change history — 0000866374-21-000062 → 0000866374-22-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0000866374-22-000016:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or
  (was, 2021-10-29, similarity 0.864):
[0000866374-21-000062:note_history:1]
In connection with the matters described below, other than the Brazilian "Credit Habilitation" gain contingency, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- added (2022-02-04):
[0000866374-22-000016:note_history:2]
unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- changed (2022-02-04):
[0000866374-22-000016:note_history:3]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff, National Elevator Industry Pension Fund, and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. On May 19, 2021, lead plaintiff filed its opening appeal brief, on July 19, 2021, defendants filed their answering brief, and on September 8, 2021, lead plaintiff filed its reply brief. The Court of Appeals heard oral argument on December 8, 2021. On December 21, 2021, the Court of Appeals affirmed the dismissal with prejudice of the case. The Court of Appeals’ decision took effect on January 12, 2022.
  (was, 2021-10-29, similarity 0.9348):
[0000866374-21-000062:note_history:3]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff, National Elevator Industry Pension Fund, and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. On May 19, 2021, lead plaintiff filed its opening appeal brief, on July 19, 2021, defendants filed their answering brief, and on September 8, 2021, lead plaintiff filed its reply brief. The Court of Appeals has scheduled oral argument for December 8, 2021. The Company believes that the claims are without merit and intends to vigorously defend this case.

- changed (2022-02-04):
[0000866374-22-000016:note_history:4]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.
  (was, 2021-10-29, similarity 0.745):
[0000866374-21-000062:note_history:4]
shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- changed (2022-02-04):
[0000866374-22-000016:note_history:5]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 373.7 million Brazilian reals (approximately USD $65.8 million based on the exchange rate as of December 31, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 60.6 million Brazilian reals or USD $10.7 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 33.9 million Brazilian reals (approximately USD $6.0 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.
  (was, 2021-10-29, similarity 0.9963):
[0000866374-21-000062:note_history:5]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 373.7 million Brazilian reals (approximately USD $68.9 million based on the exchange rate as of October 1, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 60.6 million Brazilian reals or USD $11.2 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 33.9 million Brazilian reals (approximately USD $6.3 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

- changed (2022-02-04):
[0000866374-22-000016:note_history:6]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.
  (was, 2021-10-29, similarity 0.9009):
[0000866374-21-000062:note_history:6]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company is currently reviewing those transactions and expects to submit an update to its submission to OFAC once that review is complete. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2022-02-04):
[0000866374-22-000016:note_history:7]
A different foreign Tax Authority had issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagreed with the Tax Authority’s assertion but agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount was accrued for during the fourth quarter of fiscal year 2021 and has been fully paid during the current quarter with no additional amounts owed.
  (was, 2021-10-29, similarity 0.9):
[0000866374-21-000062:note_history:7]
A different foreign Tax Authority had issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagreed with the Tax Authority’s assertion but agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount was accrued for during the fourth quarter of fiscal year 2021 and is expected to be paid during fiscal year 2022.

- added (2022-02-04):
[0000866374-22-000016:note_history:8]
As the final resolutions of the above outstanding tax items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2022-02-04):
[0000866374-22-000016:note_history:9]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for "Credit Habilitation" with the tax authorities in June 2021 to request additional PIS/COFINS credit in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of the Company's credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remained uncertainty regarding the Company’s ability to recognize these credits. The Company considered the recognition of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and did not record a gain for such credits in the three-month period ended July 2, 2021 as it had not resolved all contingencies to conclude a realized or realizable amount. In September 2021, the Credit Habilitation request was approved by the tax authorities and the Company recognized a gain of 809.6 million Brazilian reals (approximately USD $149.3 million based on the exchange rate as of October 1, 2021) included in interest and other, net in the condensed consolidated statements of operations for the three and six-month periods ended October 1, 2021. The total gain recorded included credits from February 2003 to September 2021, net of additional taxes, as the Credit Habilitation received covering the period from February 2003 to December 2019 resolved any uncertainty regarding the Company's ability to claim such credits. This gain is non-cash and can only be used to offset certain current and future tax
  (was, 2021-10-29, similarity 0.6869):
[0000866374-21-000062:note_history:9]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for "Credit Habilitation" with the tax authorities in June 2021 to request additional PIS/COFINS credit in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of the Company's

- added (2022-02-04):
[0000866374-22-000016:note_history:10]
obligations. During the three-month period ended December 31, 2021, the Company updated its plan regarding the utilization of these credits and expects to utilize the remaining 598.8 million Brazilian reals (approximately USD $105.4 million based on the exchange rate as of December 31, 2021) of credits in the next twelve months based on the latest tax strategy. Accordingly the remaining balance is included in other current assets as of December 31, 2021.

- removed (2022-02-04):
[0000866374-21-000062:note_history:11]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously

- removed (2022-02-04):
[0000866374-21-000062:note_history:12]
As the final resolutions of the above tax items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2022-02-04):
[0000866374-21-000062:note_history:13]
credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remained uncertainty regarding the Company’s ability to recognize these credits. The Company considered the recognition of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and did not record a gain for such credits in the three-month period ended July 2, 2021 as it had not resolved all contingencies to conclude a realized or realizable amount. In September 2021, the Credit Habilitation request was approved by the tax authorities and the Company recognized a gain of 809.6 million Brazilian reals (approximately USD $149.3 million based on the exchange rate as of October 1, 2021) included in interest and other, net in the condensed consolidated statements of operations for the three and six-month periods ended October 1, 2021. The total gain recorded included credits from February 2003 to September 2021, net of additional taxes, as the Credit Habilitation received covering the period from February 2003 to December 2019 resolved any uncertainty regarding the Company's ability to claim such credits. This gain is non-cash and can only be used to offset certain current and future tax obligations. Out of the $149.3 million, $50.6 million was included in other current assets and $98.7 million was included in other assets in the condensed consolidated balance sheet as of October 1, 2021 as we expect to utilize these credits in the next two to three years.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0000866374-22-000016:note_history:14]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2021 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation. Beginning in the second quarter of fiscal year 2022, the Company elected to include operating income as a subtotal in the condensed consolidated statements of operations. In addition, deferred revenue and customer working capital advances, previously included within other current liabilities, have been separately presented as deferred revenue and customer working capital advances in the current liabilities section of the condensed consolidated balance sheets. Further, certain unbilled receivables previously presented as part of accounts receivable, net of allowance for doubtful accounts are now being presented as contract assets on the condensed consolidated balance sheets as billing is to occur subsequent to revenue recognition and is conditional upon other than the passage of time. The Company reclassified $146.8 million of unbilled receivables from account receivable, net of allowance for doubtful accounts to contract assets for the period ended March 31, 2021 in order to align with the current year presentation. These presentation changes were applied to all periods presented in the condensed consolidated statements of operations and balance sheets. The foregoing changes in presentation had no impact on the Company's results of operations or cash flows.
  (was, 2021-10-29, similarity 0.9967):
[0000866374-21-000062:note_history:14]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2021 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended October 1, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation. Beginning in the second quarter of fiscal year 2022, the Company elected to include operating income as a subtotal in the condensed consolidated statements of operations. In addition, deferred revenue and customer working capital advances, previously included within other current liabilities, have been separately presented as deferred revenue and customer working capital advances in the current liabilities section of the condensed consolidated balance sheets. Further, certain unbilled receivables previously presented as part of accounts receivable, net of allowance for doubtful accounts are now being presented as contract assets on the condensed consolidated balance sheets as billing is to occur subsequent to revenue recognition and is conditional upon other than the passage of time. The Company reclassified $146.8 million of unbilled receivables from account receivable, net of allowance for doubtful accounts to contract assets for the period ended March 31, 2021 in order to align with the current year presentation. These presentation changes were applied to all periods presented in the condensed consolidated statements of operations and balance sheets. The foregoing changes in presentation had no impact on the Company's results of operations or cash flows.

- changed (2022-02-04):
[0000866374-22-000016:note_history:15]
The first quarters for fiscal years 2022 and 2021 ended on July 2, 2021, which is comprised of 93 days in the period, and June 26, 2020, which is comprised of 87 days in the period, respectively. The second quarters for fiscal years 2022 and 2021 ended on October 1, 2021 and September 25, 2020, which are comprised of 91 days in both periods. The Company's third
  (was, 2021-10-29, similarity 0.9685):
[0000866374-21-000062:note_history:15]
The first quarters for fiscal years 2022 and 2021 ended on July 2, 2021, which is comprised of 93 days in the period, and June 26, 2020, which is comprised of 87 days in the period, respectively. The second quarters for fiscal years 2022 and 2021 ended on October 1, 2021 and September 25, 2020, which are comprised of 91 days in both periods.

- added (2022-02-04):
[0000866374-22-000016:note_history:16]
quarters for fiscal years 2022 and 2021 ended on December 31 of each year, which are comprised of 91 and 97 days, respectively.

- added (2022-02-04):
[0000866374-22-000016:note_history:17]
In October 2021, the FASB issued ASU 2021-08 "Business Combinations (Topic 805) — Accounting for Contract Assets and Contract Liabilities From Contracts With Customers", which requires an acquirer to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with FASB Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers. The guidance is effective prospectively for the Company beginning in the first quarter of fiscal year 2024 with early adoption permitted. The Company early adopted the guidance during the third quarter of fiscal year 2022 with an immaterial impact to its condensed consolidated financial statements.

- added (2022-02-04):
[0000866374-22-000016:note_history:18]
In November 2021, the FASB issued ASU 2021-10 "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance," which aims to provide increased transparency by requiring business entities to disclose information about certain types of government assistance they receive in the notes to the annual financial statements. The guidance is effective for the Company beginning in fiscal year 2023 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in fiscal year 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-02-04):
[0000866374-22-000016:note_history:19]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2021 are as follows:

- added (2022-02-04):
[0000866374-22-000016:note_history:20]
|  | As of December 31, 2021 |  | As of March 31, 2021 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 292 |  |  | 305 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 691 |  |  | 694 |  |
| 4.875% Notes due June 2029 | 660 |  |  | 661 |  |
| 4.875% Notes due May 2030 | 691 |  |  | 694 |  |
| 3.600% HUF Bonds due December 2031 | 306 |  |  | — |  |
| India Facilities | 117 |  |  | 133 |  |
| Other | 610 |  |  | 219 |  |
| Debt issuance costs | (19) |  |  | (21) |  |
|  | 4,446 |  |  | 3,783 |  |
| Current portion | (648) |  |  | (268) |  |
| Non-current portion | $ | 3,798 |  |  | $ | 3,515 |  |

- added (2022-02-04):
[0000866374-22-000016:note_history:21]
The weighted-average interest rate for the Company's long-term debt was 3.5% and 4.3% as of December 31, 2021 and March 31, 2021.

- added (2022-02-04):
[0000866374-22-000016:note_history:22]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2021 are as follows:

- added (2022-02-04):
[0000866374-22-000016:note_history:23]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2022 (1) |  | $ | 246 |  |
| 2023 |  | 928 |  |
| 2024 |  | 53 |  |
| 2025 |  | 292 |  |
| 2026 |  | 1,289 |  |
| Thereafter |  | 1,657 |  |
| Total |  | $ | 4,465 |  |

- added (2022-02-04):
[0000866374-22-000016:note_history:24]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2022.

- added (2022-02-04):
[0000866374-22-000016:note_history:25]
HUF Bonds due December 2031

- added (2022-02-04):
[0000866374-22-000016:note_history:26]
In December 2021, the Company issued HUF 100 billion (approximately $306.3 million as of December 31, 2021) in aggregate principal amount of bonds under the National Bank of Hungary’s Bond Funding for Growth Scheme. The bonds mature in December 2031 and amortize in an amount equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity. The outstanding principal amount of the bonds bear interest at 3.60% per annum. Interest is due and payable annually in arrears commencing on December 6, 2022. The proceeds of the bonds were used for general corporate purposes. As the bonds are denominated in Hungarian forint, the debt balance is remeasured to USD at the end of each reporting period. Foreign currency swap contracts have been entered into with respect to this Hungarian forint denominated liability.

- added (2022-02-04):
[0000866374-22-000016:note_history:27]
The bonds are unsecured and unsubordinated obligations of the Company and rank equally with all of the Company’s other existing and future unsecured and unsubordinated obligations.

- added (2022-02-04):
[0000866374-22-000016:note_history:28]
The bonds contain a customary negative pledge covenant restricting the ability of the Company to incur liens to secure indebtedness without ratably and equally securing the bonds. This covenant is subject to a number of exceptions and limitations. The bonds also provide for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company. Except in limited circumstances resulting from adverse changes in applicable tax laws, the bonds are not voluntarily redeemable. The Company is in the process of listing the bonds for trading on the XBond multilateral trading facility operated by the Budapest Stock Exchange.

- added (2022-02-04):
[0000866374-22-000016:note_history:29]
Other Borrowings

- added (2022-02-04):
[0000866374-22-000016:note_history:30]
Euro Term Loan due December 2022

- added (2022-02-04):
[0000866374-22-000016:note_history:31]
In December 2021, the Company borrowed €350 million (approximately $397.3 million as of December 31, 2021), under a 1-year term-loan agreement. Of this amount, €250 million is due December 9, 2022 and €100 million is due December 30, 2022. The proceeds of the term loan will be used to refinance certain other outstanding debt and for other general corporate purposes. Borrowings under this term loan bear interest at (0.18)% per annum, which is payable in full at maturity. The term loan is repayable upon maturity, and the borrowings have been included as bank borrowings and current portion of long-term debt under the condensed consolidated balance sheet.

- added (2022-02-04):
[0000866374-22-000016:note_history:32]
The term loan is unsecured. The term loan agreement contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA, and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2021, the Company was in compliance with the covenants under the term loan agreement.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0000866374-22-000016:note_history:33]
|  | As of December 31, 2021 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 521 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 292 |  |  | 292 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 651 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 691 |  |  | 738 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 660 |  |  | 747 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 691 |  |  | 785 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 560 |  |  | 560 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 306 |  |  | 306 |  |  | — |  |  | — |  |  | Level 2 |
| India Facilities | 117 |  |  | 117 |  |  | 133 |  |  | 133 |  |  | Level 2 |
  (was, 2021-10-29, similarity 0.8736):
[0000866374-21-000062:note_history:33]
|  | As of October 1, 2021 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 529 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 300 |  |  | 300 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 665 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 692 |  |  | 753 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 660 |  |  | 762 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 692 |  |  | 801 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 166 |  |  | 166 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| India Facilities | 126 |  |  | 126 |  |  | 133 |  |  | 133 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-02-04):
[0000866374-22-000016:note_history:34]
Bank borrowings and long-term debt as of December 31, 2021 are as follows:

- added (2022-02-04):
[0000866374-22-000016:note_history:35]
|  | As of December 31, 2021 |  | As of March 31, 2021 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 292 |  |  | 305 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 691 |  |  | 694 |  |
| 4.875% Notes due June 2029 | 660 |  |  | 661 |  |
| 4.875% Notes due May 2030 | 691 |  |  | 694 |  |
| 3.600% HUF Bonds due December 2031 | 306 |  |  | — |  |
| India Facilities | 117 |  |  | 133 |  |
| Other | 610 |  |  | 219 |  |
| Debt issuance costs | (19) |  |  | (21) |  |
|  | 4,446 |  |  | 3,783 |  |
| Current portion | (648) |  |  | (268) |  |
| Non-current portion | $ | 3,798 |  |  | $ | 3,515 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-02-04):
[0000866374-22-000016:note_history:36]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2021 are as follows:

- added (2022-02-04):
[0000866374-22-000016:note_history:37]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2022 (1) |  | $ | 246 |  |
| 2023 |  | 928 |  |
| 2024 |  | 53 |  |
| 2025 |  | 292 |  |
| 2026 |  | 1,289 |  |
| Thereafter |  | 1,657 |  |
| Total |  | $ | 4,465 |  |

- added (2022-02-04):
[0000866374-22-000016:note_history:38]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2022.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0000866374-22-000016:note_history:39]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2021 and December 31, 2020, respectively.
  (was, 2021-10-29, similarity 0.8931):
[0000866374-21-000062:note_history:39]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended October 1, 2021 and September 25, 2020, respectively.

- changed (2022-02-04):
[0000866374-22-000016:note_history:40]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,389 |  |  | $ | 3,544 |  |  | $ | 9,887 |  |  | $ | 8,813 |  |
| Over time | 192 |  |  | 290 |  |  | 563 |  |  | 1,250 |  |
| Total | 3,581 |  |  | 3,834 |  |  | 10,450 |  |  | 10,063 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,559 |  |  | 2,189 |  |  | 7,270 |  |  | 5,292 |  |
| Over time | 479 |  |  | 697 |  |  | 1,470 |  |  | 2,503 |  |
| Total | 3,038 |  |  | 2,886 |  |  | 8,740 |  |  | 7,795 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,948 |  |  | 5,733 |  |  | 17,157 |  |  | 14,105 |  |
| Over time | 671 |  |  | 987 |  |  | 2,033 |  |  | 3,753 |  |
| Total | $ | 6,619 |  |  | $ | 6,720 |  |  | $ | 19,190 |  |  | $ | 17,858 |  |
  (was, 2021-10-29, similarity 0.9525):
[0000866374-21-000062:note_history:40]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,250 |  |  | $ | 2,823 |  |  | $ | 6,498 |  |  | $ | 5,269 |  |
| Over time | 187 |  |  | 495 |  |  | 371 |  |  | 961 |  |
| Total | 3,437 |  |  | 3,318 |  |  | 6,869 |  |  | 6,230 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,308 |  |  | 1,779 |  |  | 4,711 |  |  | 3,103 |  |
| Over time | 484 |  |  | 888 |  |  | 991 |  |  | 1,805 |  |
| Total | 2,792 |  |  | 2,667 |  |  | 5,702 |  |  | 4,908 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,558 |  |  | 4,602 |  |  | 11,209 |  |  | 8,372 |  |
| Over time | 671 |  |  | 1,383 |  |  | 1,362 |  |  | 2,766 |  |
| Total | $ | 6,229 |  |  | $ | 5,985 |  |  | $ | 12,571 |  |  | $ | 11,138 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0000866374-22-000016:note_history:41]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.
  (was, 2021-10-29, similarity 0.8231):
[0000866374-21-000062:note_history:41]
can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

- added (2022-02-04):
[0000866374-22-000016:note_history:42]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first

- changed (2022-02-04):
[0000866374-22-000016:note_history:43]
required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.
  (was, 2021-10-29, similarity 0.7857):
[0000866374-21-000062:note_history:43]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- changed (2022-02-04):
[0000866374-22-000016:note_history:44]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.
  (was, 2021-10-29, similarity 0.6914):
[0000866374-21-000062:note_history:44]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed

- changed (2022-02-04):
[0000866374-22-000016:note_history:45]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $608.5 million and $435.4 million as of December 31, 2021 and
  (was, 2021-10-29, similarity 0.7399):
[0000866374-21-000062:note_history:45]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $545.4 million and $435.4 million as of October 1, 2021 and March 31, 2021, respectively, of which $480.1 million and $376.5 million, respectively, is included in deferred revenue and customer working capital advances.

- added (2022-02-04):
[0000866374-22-000016:note_history:46]
March 31, 2021, respectively, of which $541.2 million and $376.5 million, respectively, is included in deferred revenue and customer working capital advances.

- changed (2022-02-04):
[0000866374-22-000016:note_history:47]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2021 and December 31, 2020, respectively.
  (was, 2021-10-29, similarity 0.8931):
[0000866374-21-000062:note_history:47]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended October 1, 2021 and September 25, 2020, respectively.

- changed (2022-02-04):
[0000866374-22-000016:note_history:48]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,389 |  |  | $ | 3,544 |  |  | $ | 9,887 |  |  | $ | 8,813 |  |
| Over time | 192 |  |  | 290 |  |  | 563 |  |  | 1,250 |  |
| Total | 3,581 |  |  | 3,834 |  |  | 10,450 |  |  | 10,063 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,559 |  |  | 2,189 |  |  | 7,270 |  |  | 5,292 |  |
| Over time | 479 |  |  | 697 |  |  | 1,470 |  |  | 2,503 |  |
| Total | 3,038 |  |  | 2,886 |  |  | 8,740 |  |  | 7,795 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,948 |  |  | 5,733 |  |  | 17,157 |  |  | 14,105 |  |
| Over time | 671 |  |  | 987 |  |  | 2,033 |  |  | 3,753 |  |
| Total | $ | 6,619 |  |  | $ | 6,720 |  |  | $ | 19,190 |  |  | $ | 17,858 |  |
  (was, 2021-10-29, similarity 0.9525):
[0000866374-21-000062:note_history:48]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | October 1, 2021 |  | September 25, 2020 |  | October 1, 2021 |  | September 25, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,250 |  |  | $ | 2,823 |  |  | $ | 6,498 |  |  | $ | 5,269 |  |
| Over time | 187 |  |  | 495 |  |  | 371 |  |  | 961 |  |
| Total | 3,437 |  |  | 3,318 |  |  | 6,869 |  |  | 6,230 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,308 |  |  | 1,779 |  |  | 4,711 |  |  | 3,103 |  |
| Over time | 484 |  |  | 888 |  |  | 991 |  |  | 1,805 |  |
| Total | 2,792 |  |  | 2,667 |  |  | 5,702 |  |  | 4,908 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,558 |  |  | 4,602 |  |  | 11,209 |  |  | 8,372 |  |
| Over time | 671 |  |  | 1,383 |  |  | 1,362 |  |  | 2,766 |  |
| Total | $ | 6,229 |  |  | $ | 5,985 |  |  | $ | 12,571 |  |  | $ | 11,138 |  |

- removed (2022-02-04):
[0000866374-21-000062:note_history:49]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and

- removed (2022-02-04):
[0000866374-21-000062:note_history:50]
as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-02-04):
[0000866374-22-000016:note_history:51]
SUBSEQUENT EVENTS
Issuance and Sale of Series A Preferred Units of Nextracker

- added (2022-02-04):
[0000866374-22-000016:note_history:52]
On February 1, 2022, affiliates of the Company entered into a purchase agreement (the “Purchase Agreement”) with TPG Rise Flash, L.P., a Delaware limited partnership, which is managed or advised by TPG Rise Climate, TPG, Inc.’s dedicated renewables and climate investing fund (“TPG Rise”), for the sale of 500,000 Series A Preferred Units (the “Preferred Units”) in Nextracker LLC (“Nextracker LLC” or “Nextracker”) for an aggregate purchase price of $500 million (the “Preferred Sale”). TPG Rise’s investment in approximately 16.7% of Nextracker LLC reflects an implied value for Nextracker LLC as of the date of the investment of $3.0 billion.

- added (2022-02-04):
[0000866374-22-000016:note_history:53]
Dividends.  The Preferred Units have a dividend rate of 5% per annum, payable semi-annually, up to 100% of which (less an amount necessary to fund TPG Rise’s tax obligations) may be payable in kind during the first two years following the closing of the Preferred Sale, and 50% of which may be payable in kind thereafter.

- added (2022-02-04):
[0000866374-22-000016:note_history:54]
Conversion Ratio.  The Preferred Units will be automatically converted into common units of Nextracker LLC upon a qualified initial public offering (a “Qualified Public Offering”) and TPG Rise may elect to convert the Preferred Units into common units of Nextracker LLC at any time after March 31, 2023. Subject to certain exceptions, for any mandatory or optional conversion, the conversion ratio for each Preferred Unit will be based on a deemed value of Nextracker LLC equal to the lesser of $3.0 billion and the implied equity valuation of Nextracker LLC determined by the underwriters engaged in connection with a Qualified Public Offering. If a Qualified Public Offering occurs by March 31, 2023 with an implied equity valuation greater than $3.75 billion, then the conversion ratio will be adjusted upwards based on a deemed value of Nextracker LLC equal to $3.2 billion. If a Qualified Public Offering occurs after March 31, 2023 with an implied equity valuation between $2.7 billion and $3.0 billion, then the conversion ratio will be based on a deemed value of Nextracker LLC equal to $3.0 billion. If a Qualified Public Offering occurs after March 31, 2023 with an implied equity valuation of less than $2.7 billion, then the conversion ratio will be based on a deemed value equal to the implied equity valuation of Nextracker LLC in the Qualified Public Offering divided by 90%. If TPG Rise elects to convert the Preferred Units prior to an initial public offering, the conversion ratio shall be based on a deemed value of Nextracker LLC equal to $3.0 billion.

- added (2022-02-04):
[0000866374-22-000016:note_history:55]
Repurchase.  At TPG Rise’s election, the Company is required to repurchase all of the outstanding Preferred Units at their liquidation preference, which shall include all contributed but unreturned capital plus accrued but unpaid dividends, at the earlier of certain change in control events and February 2, 2028. Additionally, if Nextracker has not completed a Qualified Public Offering prior to February 2, 2027, then TPG Rise may cause the Company to repurchase all of the outstanding Preferred Units at their fair market value (determined by a mutually agreeable third-party appraiser).

- added (2022-02-04):
[0000866374-22-000016:note_history:56]
Voting Rights.  The Preferred Units will vote together with the common units of Nextracker as a single class in all matters that are subject to a vote by common unitholders. In connection with the Preferred Sale, TPG Rise has the right to designate two members of the Board of Nextracker LLC; if, however, TPG Rise owns Preferred Units or common units of Nextracker LLC with a fully diluted ownership percentage of less than 10% but more than 5%, the number of Board members that TPG Rise will be entitled to designate will be reduced to one. So long as at least 51% of the Preferred Units remain outstanding, the consent of the holders of the Preferred Units must be obtained prior to taking certain actions regarding Nextracker LLC, including, but not limited to, changes to the terms of the Preferred Units that adversely affect the rights of holders of the Preferred Units, certain incurrences of indebtedness by Nextracker, certain capital expenditures, acquisitions or dispositions by Nextracker, and changes to the Board and management of Nextracker.

- added (2022-02-04):
[0000866374-22-000016:note_history:57]
Conversion to Limited Liability Company.  In connection with the Preferred Sale, Nextracker Inc. (the predecessor to Nextracker LLC) was converted to a limited liability company and will remain a subsidiary of the Company until the disposition of a majority of the securities of Nextracker LLC, in an initial public offering and/or other corporate transaction. The conversion of Nextracker Inc. is intended to facilitate an initial public offering in the future through what is commonly referred to as an umbrella partnership-C Corporation or an “Up-C” structure.

- added (2022-02-04):
[0000866374-22-000016:note_history:58]
Separation and Transition Services Agreements.  At the closing of the Preferred Sale, the Company, Flextronics International USA, Inc. and Nextracker LLC entered into a separation agreement and a transition services agreement to formally separate the operations of the businesses. The Company will report the Nextracker business as a separate operating and reportable segment for the fiscal year ending March 31, 2022.

- removed (2022-02-04):
[0000866374-21-000062:note_history:59]
SUBSEQUENT EVENTSIn October 2021, the Company announced that it has entered into a definitive agreement to acquire 100% of the voting shares of Anord Mardix, a global leader in critical power solutions for $540 million in an all-cash transaction. The acquisition will add to the Company' portfolio of Power products and expand its offering in the data center market and is expected to close in the third quarter of fiscal year 2022, subject to customary closing conditions, including regulatory approval. For reporting purposes, Anord Mardix will be included in the Industrial business unit within the FRS segment.
