# FLEX notes — 0000866374-22-000016


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-22-000016:notes:1]
[same as prior period, unchanged from 0000866374-21-000062:notes:1]

[0000866374-22-000016:notes:2]
[same as prior period, unchanged from 0000866374-21-000062:notes:2]

[0000866374-22-000016:notes:3]
[same as prior period, unchanged from 0000866374-21-000062:notes:3]

[0000866374-22-000016:notes:4]
[same as prior period, unchanged from 0000866374-21-000062:notes:4]

[0000866374-22-000016:notes:5]
[same as prior period, unchanged from 0000866374-21-000062:notes:5]

[0000866374-22-000016:notes:6]
[same as prior period, unchanged from 0000866374-21-000062:notes:6]

[0000866374-22-000016:notes:7]
[same as prior period, unchanged from 0000866374-21-000062:notes:7]

[0000866374-22-000016:notes:8]
[same as prior period, unchanged from 0000866374-21-000062:notes:8]

[0000866374-22-000016:notes:9]
[same as prior period, unchanged from 0000866374-21-000062:notes:9]

[0000866374-22-000016:notes:10]
[same as prior period, unchanged from 0000866374-21-000062:notes:10]

[0000866374-22-000016:notes:11]
[same as prior period, unchanged from 0000866374-21-000062:notes:11]

[0000866374-22-000016:notes:12]
[same as prior period, unchanged from 0000866374-21-000062:notes:12]

[0000866374-22-000016:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2021 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation. Beginning in the second quarter of fiscal year 2022, the Company elected to include operating income as a subtotal in the condensed consolidated statements of operations. In addition, deferred revenue and customer working capital advances, previously included within other current liabilities, have been separately presented as deferred revenue and customer working capital advances in the current liabilities section of the condensed consolidated balance sheets. Further, certain unbilled receivables previously presented as part of accounts receivable, net of allowance for doubtful accounts are now being presented as contract assets on the condensed consolidated balance sheets as billing is to occur subsequent to revenue recognition and is conditional upon other than the passage of time. The Company reclassified $146.8 million of unbilled receivables from account receivable, net of allowance for doubtful accounts to contract assets for the period ended March 31, 2021 in order to align with the current year presentation. These presentation changes were applied to all periods presented in the condensed consolidated statements of operations and balance sheets. The foregoing changes in presentation had no impact on the Company's results of operations or cash flows.

[0000866374-22-000016:notes:14]
The first quarters for fiscal years 2022 and 2021 ended on July 2, 2021, which is comprised of 93 days in the period, and June 26, 2020, which is comprised of 87 days in the period, respectively. The second quarters for fiscal years 2022 and 2021 ended on October 1, 2021 and September 25, 2020, which are comprised of 91 days in both periods. The Company's third

[0000866374-22-000016:notes:15]
quarters for fiscal years 2022 and 2021 ended on December 31 of each year, which are comprised of 91 and 97 days, respectively.

[0000866374-22-000016:notes:16]
[same as prior period, unchanged from 0000866374-21-000062:notes:15]

[0000866374-22-000016:notes:17]
[same as prior period, unchanged from 0000866374-21-000062:notes:16]

[0000866374-22-000016:notes:18]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-22-000016:notes:19]
Recently Adopted Accounting Pronouncement

[0000866374-22-000016:notes:20]
In October 2021, the FASB issued ASU 2021-08 "Business Combinations (Topic 805) — Accounting for Contract Assets and Contract Liabilities From Contracts With Customers", which requires an acquirer to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with FASB Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers. The guidance is effective prospectively for the Company beginning in the first quarter of fiscal year 2024 with early adoption permitted. The Company early adopted the guidance during the third quarter of fiscal year 2022 with an immaterial impact to its condensed consolidated financial statements.

[0000866374-22-000016:notes:21]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

[0000866374-22-000016:notes:22]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

[0000866374-22-000016:notes:23]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

[0000866374-22-000016:notes:24]
Recently Issued Accounting Pronouncements

[0000866374-22-000016:notes:25]
In November 2021, the FASB issued ASU 2021-10 "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance," which aims to provide increased transparency by requiring business entities to disclose information about certain types of government assistance they receive in the notes to the annual financial statements. The guidance is effective for the Company beginning in fiscal year 2023 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in fiscal year 2023.

[0000866374-22-000016:notes:26]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-22-000016:notes:27]
[same as prior period, unchanged from 0000866374-21-000062:notes:24]

[0000866374-22-000016:notes:28]
[same as prior period, unchanged from 0000866374-21-000062:notes:25]

[0000866374-22-000016:notes:29]
|  | As of December 31, 2021 |  | As of March 31, 2021 |
|  | (In millions) |
| Raw materials | $ | 4,742 |  |  | $ | 2,831 |  |
| Work-in-progress | 546 |  |  | 459 |  |
| Finished goods | 670 |  |  | 605 |  |
|  | $ | 5,958 |  |  | $ | 3,895 |  |

[0000866374-22-000016:notes:30]
[same as prior period, unchanged from 0000866374-21-000062:notes:27]

[0000866374-22-000016:notes:31]
The Company completed its acquisition of Anord Mardix in December 2021. The acquisition generated $271.3 million of goodwill in the Industrial reporting unit and primarily related to value placed on the acquired employee workforce, service offerings and capabilities of the acquired business. The goodwill is not deductible for income tax purposes. Refer to Note 12 for more information.

[0000866374-22-000016:notes:32]
The following table summarizes the goodwill allocation as of April 1, 2021 and the activity during the nine-month period ended December 31, 2021:

[0000866374-22-000016:notes:33]
|  |  | FAS |  | FRS |  |  |
|  |  | Communications, Enterprise and Cloud |  | Lifestyle |  | Consumer Devices |  | Automotive |  | Health Solutions |  | Industrial |  | Total |
|  | (In millions) |
| Balance at March 31, 2021 |  | $ | 189 |  |  | $ | 131 |  |  | $ | 51 |  |  | $ | 196 |  |  | $ | 194 |  |  | $ | 329 |  |  | $ | 1,090 |  |
| Additions |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 271 |  |  | 271 |  |
| Foreign currency translation adjustments |  | — |  |  | — |  |  |  |  | (14) |  |  | — |  |  | (1) |  |  | (15) |  |
| Balance at December 31, 2021 |  | $ | 189 |  |  | $ | 131 |  |  | $ | 51 |  |  | $ | 182 |  |  | $ | 194 |  |  | $ | 599 |  |  | $ | 1,346 |  |

[0000866374-22-000016:notes:34]
[same as prior period, unchanged from 0000866374-21-000062:notes:29]

[0000866374-22-000016:notes:35]
|  | As of December 31, 2021 |  | As of March 31, 2021 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 388 |  |  | $ | (148) |  |  | $ | 240 |  |  | $ | 276 |  |  | $ | (154) |  |  | $ | 122 |  |
| Licenses and other intangibles | 318 |  |  | (130) |  |  | 188 |  |  | 250 |  |  | (159) |  |  | 91 |  |
| Total | $ | 706 |  |  | $ | (278) |  |  | $ | 428 |  |  | $ | 526 |  |  | $ | (313) |  |  | $ | 213 |  |

[0000866374-22-000016:notes:36]
The gross carrying amounts of intangible assets are removed when fully amortized. During the nine-month period ended December 31, 2021, the total value of intangible assets increased by $263.0 million as a result of the Company's initial estimated value of intangible assets from the Anord Mardix acquisition. This acquisition contributed an additional $143.0 million in customer-related intangible assets, and $120.0 million in licenses and other intangibles assets such as trade names and patented technology. The assigned values are subject to change as the Company completes the valuation. Refer to Note 12 for additional information.

[0000866374-22-000016:notes:37]
The estimated future annual amortization expense for intangible assets is as follows:

[0000866374-22-000016:notes:38]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2022 (1) |  | $ | 22 |  |
| 2023 |  | 88 |  |
| 2024 |  | 72 |  |
| 2025 |  | 64 |  |
| 2026 |  | 43 |  |
| Thereafter |  | 139 |  |
| Total amortization expense |  | $ | 428 |  |

[0000866374-22-000016:notes:39]
[same as prior period, unchanged from 0000866374-21-000062:notes:33]

[0000866374-22-000016:notes:40]
(1)Represents estimated amortization for the remaining fiscal three-month period ending March 31, 2022.

[0000866374-22-000016:notes:41]
[same as prior period, unchanged from 0000866374-21-000062:notes:35]

[0000866374-22-000016:notes:42]
Customer working capital advances was $1.0 billion and $471.5 million, as of December 31, 2021 and March 31, 2021, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-22-000016:notes:43]
[same as prior period, unchanged from 0000866374-21-000062:notes:37]

[0000866374-22-000016:notes:44]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-22-000016:notes:45]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first

[0000866374-22-000016:notes:46]
required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-22-000016:notes:47]
[same as prior period, unchanged from 0000866374-21-000062:notes:41]

[0000866374-22-000016:notes:48]
[same as prior period, unchanged from 0000866374-21-000062:notes:42]

[0000866374-22-000016:notes:49]
[same as prior period, unchanged from 0000866374-21-000062:notes:43]

[0000866374-22-000016:notes:50]
[same as prior period, unchanged from 0000866374-21-000062:notes:44]

[0000866374-22-000016:notes:51]
[same as prior period, unchanged from 0000866374-21-000062:notes:45]

[0000866374-22-000016:notes:52]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-22-000016:notes:53]
[same as prior period, unchanged from 0000866374-21-000062:notes:48]

[0000866374-22-000016:notes:54]
[same as prior period, unchanged from 0000866374-21-000062:notes:49]

[0000866374-22-000016:notes:55]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $608.5 million and $435.4 million as of December 31, 2021 and

[0000866374-22-000016:notes:56]
March 31, 2021, respectively, of which $541.2 million and $376.5 million, respectively, is included in deferred revenue and customer working capital advances.

[0000866374-22-000016:notes:57]
[same as prior period, unchanged from 0000866374-21-000062:notes:51]

[0000866374-22-000016:notes:58]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2021 and December 31, 2020, respectively.

[0000866374-22-000016:notes:59]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,389 |  |  | $ | 3,544 |  |  | $ | 9,887 |  |  | $ | 8,813 |  |
| Over time | 192 |  |  | 290 |  |  | 563 |  |  | 1,250 |  |
| Total | 3,581 |  |  | 3,834 |  |  | 10,450 |  |  | 10,063 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,559 |  |  | 2,189 |  |  | 7,270 |  |  | 5,292 |  |
| Over time | 479 |  |  | 697 |  |  | 1,470 |  |  | 2,503 |  |
| Total | 3,038 |  |  | 2,886 |  |  | 8,740 |  |  | 7,795 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,948 |  |  | 5,733 |  |  | 17,157 |  |  | 14,105 |  |
| Over time | 671 |  |  | 987 |  |  | 2,033 |  |  | 3,753 |  |
| Total | $ | 6,619 |  |  | $ | 6,720 |  |  | $ | 19,190 |  |  | $ | 17,858 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-22-000016:notes:60]
[same as prior period, unchanged from 0000866374-21-000062:notes:54]

[0000866374-22-000016:notes:61]
[same as prior period, unchanged from 0000866374-21-000062:notes:55]

[0000866374-22-000016:notes:62]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
|  | (In millions) |
| Cost of sales | $ | 6 |  |  | $ | 6 |  |  | $ | 17 |  |  | $ | 16 |  |
| Selling, general and administrative expenses | 19 |  |  | 19 |  |  | 52 |  |  | 46 |  |
| Total share-based compensation expense | $ | 25 |  |  | $ | 25 |  |  | $ | 69 |  |  | $ | 62 |  |

[0000866374-22-000016:notes:63]
Total number of options outstanding and exercisable were immaterial as of December 31, 2021. All options have been fully expensed as of December 31, 2021.

[0000866374-22-000016:notes:64]
During the nine-month period ended December 31, 2021, the Company granted 5.9 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 5.0 million are plain-vanilla unvested RSU awards that vest over a period of two to three years, with no performance or market conditions, and with an average grant date price of $18.25 per award. In addition, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $18.24 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of 0.8 million based on a measurement of the Company's adjusted earnings per share growth over a certain specified period, and will cliff vest after a period of three years, to the extent such performance conditions have been met. Further, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $25.86 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 0.8 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-22-000016:notes:65]
As of December 31, 2021, approximately 15.8 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 2.9 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of 0.4 million shares is contingent on meeting certain performance conditions. The number of shares tied to market condition that will ultimately be issued can range from zero to 5.8 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to 0.8 million based on the achievement levels. During the nine-month period ended December 31, 2021, no shares vested in connection with the awards with market conditions granted in fiscal year 2019.

[0000866374-22-000016:notes:66]
As of December 31, 2021, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $150.8 million, and will be recognized over a weighted-average remaining vesting period of 2.0 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-22-000016:notes:67]
[same as prior period, unchanged from 0000866374-21-000062:notes:62]

[0000866374-22-000016:notes:68]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
|  | (In millions, except per share amounts) |
| Basic earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 227 |  |  | $ | 208 |  |  | $ | 769 |  |  | $ | 373 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 469 |  |  | 500 |  |  | 481 |  |  | 500 |  |
| Basic earnings per share | $ | 0.48 |  |  | $ | 0.42 |  |  | $ | 1.60 |  |  | $ | 0.75 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 227 |  |  | $ | 208 |  |  | $ | 769 |  |  | $ | 373 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 469 |  |  | 500 |  |  | 481 |  |  | 500 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 5 |  |  | 8 |  |  | 6 |  |  | 5 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 474 |  |  | 508 |  |  | 487 |  |  | 505 |  |
| Diluted earnings per share | $ | 0.48 |  |  | $ | 0.41 |  |  | $ | 1.58 |  |  | $ | 0.74 |  |

[0000866374-22-000016:notes:69]
(1)Immaterial RSU awards for the three and nine-month periods ended December 31, 2021, and an immaterial number of RSU awards and 2.9 million RSU awards for the three and nine-month periods ended December 31, 2020, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-22-000016:notes:70]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2021 are as follows:

[0000866374-22-000016:notes:71]
|  | As of December 31, 2021 |  | As of March 31, 2021 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 292 |  |  | 305 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 691 |  |  | 694 |  |
| 4.875% Notes due June 2029 | 660 |  |  | 661 |  |
| 4.875% Notes due May 2030 | 691 |  |  | 694 |  |
| 3.600% HUF Bonds due December 2031 | 306 |  |  | — |  |
| India Facilities | 117 |  |  | 133 |  |
| Other | 610 |  |  | 219 |  |
| Debt issuance costs | (19) |  |  | (21) |  |
|  | 4,446 |  |  | 3,783 |  |
| Current portion | (648) |  |  | (268) |  |
| Non-current portion | $ | 3,798 |  |  | $ | 3,515 |  |

[0000866374-22-000016:notes:72]
The weighted-average interest rate for the Company's long-term debt was 3.5% and 4.3% as of December 31, 2021 and March 31, 2021.

[0000866374-22-000016:notes:73]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2021 are as follows:

[0000866374-22-000016:notes:74]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2022 (1) |  | $ | 246 |  |
| 2023 |  | 928 |  |
| 2024 |  | 53 |  |
| 2025 |  | 292 |  |
| 2026 |  | 1,289 |  |
| Thereafter |  | 1,657 |  |
| Total |  | $ | 4,465 |  |

[0000866374-22-000016:notes:75]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2022.

[0000866374-22-000016:notes:76]
HUF Bonds due December 2031

[0000866374-22-000016:notes:77]
In December 2021, the Company issued HUF 100 billion (approximately $306.3 million as of December 31, 2021) in aggregate principal amount of bonds under the National Bank of Hungary’s Bond Funding for Growth Scheme. The bonds mature in December 2031 and amortize in an amount equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity. The outstanding principal amount of the bonds bear interest at 3.60% per annum. Interest is due and payable annually in arrears commencing on December 6, 2022. The proceeds of the bonds were used for general corporate purposes. As the bonds are denominated in Hungarian forint, the debt balance is remeasured to USD at the end of each reporting period. Foreign currency swap contracts have been entered into with respect to this Hungarian forint denominated liability.

[0000866374-22-000016:notes:78]
The bonds are unsecured and unsubordinated obligations of the Company and rank equally with all of the Company’s other existing and future unsecured and unsubordinated obligations.

[0000866374-22-000016:notes:79]
The bonds contain a customary negative pledge covenant restricting the ability of the Company to incur liens to secure indebtedness without ratably and equally securing the bonds. This covenant is subject to a number of exceptions and limitations. The bonds also provide for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company. Except in limited circumstances resulting from adverse changes in applicable tax laws, the bonds are not voluntarily redeemable. The Company is in the process of listing the bonds for trading on the XBond multilateral trading facility operated by the Budapest Stock Exchange.

[0000866374-22-000016:notes:80]
Other Borrowings

[0000866374-22-000016:notes:81]
Euro Term Loan due December 2022

[0000866374-22-000016:notes:82]
In December 2021, the Company borrowed €350 million (approximately $397.3 million as of December 31, 2021), under a 1-year term-loan agreement. Of this amount, €250 million is due December 9, 2022 and €100 million is due December 30, 2022. The proceeds of the term loan will be used to refinance certain other outstanding debt and for other general corporate purposes. Borrowings under this term loan bear interest at (0.18)% per annum, which is payable in full at maturity. The term loan is repayable upon maturity, and the borrowings have been included as bank borrowings and current portion of long-term debt under the condensed consolidated balance sheet.

[0000866374-22-000016:notes:83]
The term loan is unsecured. The term loan agreement contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA, and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2021, the Company was in compliance with the covenants under the term loan agreement.


## flex:InterestAndOtherNetTextBlock

[0000866374-22-000016:notes:84]
INTEREST AND OTHER, NET 
Interest and other, net for the three and nine-month periods ended December 31, 2021 and December 31, 2020 are primarily composed of the following:

[0000866374-22-000016:notes:85]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 38 |  |  | $ | 40 |  |  | $ | 113 |  |  | $ | 111 |  |
| Interest income | (3) |  |  | (4) |  |  | (11) |  |  | (10) |  |
| Equity in earnings on investments | (30) |  |  | (49) |  |  | (52) |  |  | (64) |  |
| Brazil tax credit (1) | (1) |  |  | — |  |  | (150) |  |  | — |  |

[0000866374-22-000016:notes:86]
(1)During the nine-month period ended December 31, 2021, the Company recognized a $150 million gain related to a certain tax credit upon approval of a "Credit Habilitation" request by the relevant Brazil tax authorities. Refer to note 13 to the condensed consolidated financial statements for further information.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-22-000016:notes:87]
[same as prior period, unchanged from 0000866374-21-000062:notes:68]

[0000866374-22-000016:notes:88]
[same as prior period, unchanged from 0000866374-21-000062:notes:69]

[0000866374-22-000016:notes:89]
As of December 31, 2021, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $11.2 billion as summarized below:

[0000866374-22-000016:notes:90]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| CNY |  | 3,458 |  |  | — |  |  | $ | 543 |  |  | $ | — |  |
| HUF |  | 141,043 |  |  | — |  |  | 438 |  |  | — |  |
| JPY |  | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN |  | 6,660 |  |  | — |  |  | 324 |  |  | — |  |
| MYR |  | 461 |  |  | 226 |  |  | 110 |  |  | 54 |  |
| Other |  | N/A |  | N/A |  | 272 |  |  | 62 |  |
|  |  |  |  |  |  | 1,987 |  |  | 116 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 647 |  |  | — |  |  | 114 |  |
| CAD |  | 98 |  |  | 61 |  |  | 77 |  |  | 48 |  |
| CNY |  | 5,378 |  |  | 1,843 |  |  | 840 |  |  | 290 |  |
| EUR |  | 2,548 |  |  | 2,355 |  |  | 2,893 |  |  | 2,674 |  |
| GBP |  | 66 |  |  | 89 |  |  | 89 |  |  | 120 |  |
| HUF |  | 59,796 |  |  | 48,268 |  |  | 183 |  |  | 148 |  |
| ILS |  | 318 |  |  | 25 |  |  | 102 |  |  | 8 |  |
| MXN |  | 7,605 |  |  | 5,731 |  |  | 370 |  |  | 279 |  |
| MYR |  | 958 |  |  | 305 |  |  | 229 |  |  | 73 |  |
| SEK |  | 642 |  |  | 736 |  |  | 71 |  |  | 81 |  |
| SGD |  | 105 |  |  | 58 |  |  | 77 |  |  | 43 |  |
| Other |  | N/A |  | N/A |  | 216 |  |  | 106 |  |
|  |  |  |  |  |  | 5,147 |  |  | 3,984 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 7,134 |  |  | $ | 4,100 |  |

[0000866374-22-000016:notes:91]
As of December 31, 2021, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of December 31, 2021 and March 31, 2021, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred loss was $22.9 million as of December 31, 2021, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, and the USD HUF cross currency swaps, which are further discussed below.

[0000866374-22-000016:notes:92]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other liabilities as of December 31, 2021. Additionally, the Company entered into USD HUF cross currency swaps to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other liabilities as of December 31, 2021. The changes in fair value of both the USD JPY cross currency swap and the USD HUF cross currency swaps are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal and HUF bond principal, which also impact the same line.

[0000866374-22-000016:notes:93]
[same as prior period, unchanged from 0000866374-21-000062:notes:74]

[0000866374-22-000016:notes:94]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31,2021 |  | March 31,2021 |  | Balance SheetLocation |  | December 31,2021 |  | March 31,2021 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 19 |  |  | $ | 23 |  |  | Other current liabilities |  | $ | 19 |  |  | $ | 16 |  |
| Foreign currency contracts | Other assets |  | $ | — |  |  | $ | 5 |  |  | Other liabilities |  | $ | 37 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 19 |  |  | $ | 31 |  |  | Other current liabilities |  | $ | 11 |  |  | $ | 32 |  |

[0000866374-22-000016:notes:95]
[same as prior period, unchanged from 0000866374-21-000062:notes:76]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-22-000016:notes:96]
[same as prior period, unchanged from 0000866374-21-000062:notes:77]

[0000866374-22-000016:notes:97]
|  | Three-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (49) |  |  | $ | (88) |  |  | $ | (137) |  |  | $ | (45) |  |  | $ | (88) |  |  | $ | (133) |  |
| Other comprehensive gain (loss) before reclassifications | (27) |  |  | (14) |  |  | (41) |  |  | 43 |  |  | 42 |  |  | 85 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 14 |  |  | 6 |  |  | 20 |  |  | (14) |  |  | — |  |  | (14) |  |
| Net current-period other comprehensive gain (loss) | (13) |  |  | (8) |  |  | (21) |  |  | 29 |  |  | 42 |  |  | 71 |  |
| Ending balance | $ | (62) |  |  | $ | (96) |  |  | $ | (158) |  |  | $ | (16) |  |  | $ | (46) |  |  | $ | (62) |  |

[0000866374-22-000016:notes:98]
|  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |  | $ | (82) |  |  | $ | (133) |  |  | $ | (215) |  |
| Other comprehensive gain (loss) before reclassifications | (20) |  |  | (24) |  |  | (44) |  |  | 73 |  |  | 87 |  |  | 160 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | — |  |  | 5 |  |  | 5 |  |  | (7) |  |  | — |  |  | (7) |  |
| Net current-period other comprehensive gain (loss) | (20) |  |  | (19) |  |  | (39) |  |  | 66 |  |  | 87 |  |  | 153 |  |
| Ending balance | $ | (62) |  |  | $ | (96) |  |  | $ | (158) |  |  | $ | (16) |  |  | $ | (46) |  |  | $ | (62) |  |

[0000866374-22-000016:notes:99]
Substantially all unrealized losses and gains relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and nine-month periods ended December 31, 2021 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-22-000016:notes:100]
[same as prior period, unchanged from 0000866374-21-000062:notes:81]

[0000866374-22-000016:notes:101]
[same as prior period, unchanged from 0000866374-21-000062:notes:82]

[0000866374-22-000016:notes:102]
The Company sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” and together with the Global Program, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells a fraction of the receivables to unaffiliated financial institutions, based on the Company's requirements. Under these programs, the entire purchase price of sold receivables is paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The fair value of the guarantee obligation was zero as of December 31, 2021 and March 31, 2021, respectively. The accounts receivable balances sold under the ABS Programs were removed from the condensed consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-22-000016:notes:103]
[same as prior period, unchanged from 0000866374-21-000062:notes:84]

[0000866374-22-000016:notes:104]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the nine-month periods ended December 31, 2021 and December 31, 2020 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-22-000016:notes:105]
As of December 31, 2021 and March 31, 2021, no accounts receivable had been sold under the ABS programs.

[0000866374-22-000016:notes:106]
For the nine-month periods ended December 31, 2020, cash flows from sales of receivables from the special purpose entities to unaffiliated financial institutions, consisted of approximately $0.6 billion, for transfers of receivables. The Company's cash flows from transfers of receivables in fiscal year 2021 consisted primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented. 
Trade Accounts Receivable Sale ProgramsThe Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.4 billion and $0.2 billion as of December 31, 2021 and March 31, 2021, respectively. For the nine-month periods ended December 31, 2021 and December 31, 2020, total accounts receivable sold to certain third-party banking institutions was approximately $1.0 billion and $0.6 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-22-000016:notes:107]
[same as prior period, unchanged from 0000866374-21-000062:notes:88]

[0000866374-22-000016:notes:108]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of December 31, 2021 and March 31, 2021.

[0000866374-22-000016:notes:109]
[same as prior period, unchanged from 0000866374-21-000062:notes:90]

[0000866374-22-000016:notes:110]
[same as prior period, unchanged from 0000866374-21-000062:notes:91]

[0000866374-22-000016:notes:111]
[same as prior period, unchanged from 0000866374-21-000062:notes:92]

[0000866374-22-000016:notes:112]
[same as prior period, unchanged from 0000866374-21-000062:notes:93]

[0000866374-22-000016:notes:113]
[same as prior period, unchanged from 0000866374-21-000062:notes:94]

[0000866374-22-000016:notes:114]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of December 31, 2021 and March 31, 2021.

[0000866374-22-000016:notes:115]
There were no transfers between levels in the fair value hierarchy during the nine-month periods ended December 31, 2021 and December 31, 2020.

[0000866374-22-000016:notes:116]
[same as prior period, unchanged from 0000866374-21-000062:notes:97]

[0000866374-22-000016:notes:117]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of December 31, 2021 and March 31, 2021:

[0000866374-22-000016:notes:118]
|  | Fair Value Measurements as of December 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,620 |  |  | $ | — |  |  | $ | 1,620 |  |
| Foreign currency contracts (Note 8) | — |  |  | 38 |  |  | — |  |  | 38 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 45 |  |  | — |  |  | 45 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (67) |  |  | $ | — |  |  | $ | (67) |  |
|  | Fair Value Measurements as of March 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,507 |  |  | $ | — |  |  | $ | 1,507 |  |
| Foreign currency contracts (Note 8) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |

[0000866374-22-000016:notes:119]
[same as prior period, unchanged from 0000866374-21-000062:notes:100]

[0000866374-22-000016:notes:120]
[same as prior period, unchanged from 0000866374-21-000062:notes:101]

[0000866374-22-000016:notes:121]
|  | As of December 31, 2021 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 521 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 292 |  |  | 292 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 651 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 691 |  |  | 738 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 660 |  |  | 747 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 691 |  |  | 785 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 560 |  |  | 560 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 306 |  |  | 306 |  |  | — |  |  | — |  |  | Level 2 |
| India Facilities | 117 |  |  | 117 |  |  | 133 |  |  | 133 |  |  | Level 2 |

[0000866374-22-000016:notes:122]
[same as prior period, unchanged from 0000866374-21-000062:notes:103]

[0000866374-22-000016:notes:123]
The Company values its Term Loan due April 2024, India Facilities, Euro Term Loans, and HUF Bond based on the current market rate, and as of December 31, 2021, the carrying amounts approximate fair values.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-22-000016:notes:124]
BUSINESS ACQUISITION
Acquisition of Anord Mardix

[0000866374-22-000016:notes:125]
On December 1, 2021, the Company completed the business acquisition of Anord Mardix, a global leader in critical power solutions for an initial purchase consideration of $522.5 million, net of $25.1 million cash acquired, with an additional $16.5 million deferred purchase price to be paid out in the fourth quarter of fiscal year 2022 together with additional working capital adjustments, for a total purchase consideration of $539 million. The acquisition adds to the Company's portfolio of Power products and expands its offering in the data center market. For reporting purposes, Anord Mardix is included in the Industrial reporting unit within the FRS segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill. The results of operations of the acquisition were included in the Company’s condensed consolidated financial results beginning on the date of acquisition, and the total amount of net income and revenue were immaterial to the Company's condensed consolidated financial results for the three-month and nine-month periods ended December 31, 2021.

[0000866374-22-000016:notes:126]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities of Anord Mardix (in millions):

[0000866374-22-000016:notes:127]
| Current assets | $ | 134 |  |
| Property and equipment | 14 |  |
| Operating lease right-of-use assets | 34 |  |
| Intangible assets | 263 |  |
| Goodwill | 271 |  |
| Total assets | $ | 716 |  |
| Current liabilities | $ | 97 |  |
| Operating lease liabilities, non-current | 31 |  |
| Deferred tax liabilities | 49 |  |
| Total aggregate purchase price | $ | 539 |  |

[0000866374-22-000016:notes:128]
The intangible assets of $263.0 million is comprised of customer related intangible assets of $143.0 million and licenses and other intangible assets such as trade names and patented technology of $120.0 million. Customer related assets are amortized over a weighted-average estimated useful life of 8.5 years while licensed and other intangibles are amortized over a weighted-average estimated useful life of 8.9 years.

[0000866374-22-000016:notes:129]
Pro-forma results of operations have not been presented because the effects were not material to the Company’s condensed consolidated financial results for all periods presented.

[0000866374-22-000016:notes:130]
The Company is in the process of evaluating the fair value of the assets and liabilities related to this acquisition. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisition. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the respective measurement periods.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-22-000016:notes:131]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-22-000016:notes:132]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or

[0000866374-22-000016:notes:133]
unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-22-000016:notes:134]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-22-000016:notes:135]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

[0000866374-22-000016:notes:136]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff, National Elevator Industry Pension Fund, and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. On May 19, 2021, lead plaintiff filed its opening appeal brief, on July 19, 2021, defendants filed their answering brief, and on September 8, 2021, lead plaintiff filed its reply brief. The Court of Appeals heard oral argument on December 8, 2021. On December 21, 2021, the Court of Appeals affirmed the dismissal with prejudice of the case. The Court of Appeals’ decision took effect on January 12, 2022.

[0000866374-22-000016:notes:137]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-22-000016:notes:138]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 373.7 million Brazilian reals (approximately USD $65.8 million based on the exchange rate as of December 31, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 60.6 million Brazilian reals or USD $10.7 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 33.9 million Brazilian reals (approximately USD $6.0 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

[0000866374-22-000016:notes:139]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-22-000016:notes:140]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $163.9 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-22-000016:notes:141]
A different foreign Tax Authority had issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagreed with the Tax Authority’s assertion but agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount was accrued for during the fourth quarter of fiscal year 2021 and has been fully paid during the current quarter with no additional amounts owed.

[0000866374-22-000016:notes:142]
As the final resolutions of the above outstanding tax items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-22-000016:notes:143]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for "Credit Habilitation" with the tax authorities in June 2021 to request additional PIS/COFINS credit in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of the Company's credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remained uncertainty regarding the Company’s ability to recognize these credits. The Company considered the recognition of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and did not record a gain for such credits in the three-month period ended July 2, 2021 as it had not resolved all contingencies to conclude a realized or realizable amount. In September 2021, the Credit Habilitation request was approved by the tax authorities and the Company recognized a gain of 809.6 million Brazilian reals (approximately USD $149.3 million based on the exchange rate as of October 1, 2021) included in interest and other, net in the condensed consolidated statements of operations for the three and six-month periods ended October 1, 2021. The total gain recorded included credits from February 2003 to September 2021, net of additional taxes, as the Credit Habilitation received covering the period from February 2003 to December 2019 resolved any uncertainty regarding the Company's ability to claim such credits. This gain is non-cash and can only be used to offset certain current and future tax

[0000866374-22-000016:notes:144]
obligations. During the three-month period ended December 31, 2021, the Company updated its plan regarding the utilization of these credits and expects to utilize the remaining 598.8 million Brazilian reals (approximately USD $105.4 million based on the exchange rate as of December 31, 2021) of credits in the next twelve months based on the latest tax strategy. Accordingly the remaining balance is included in other current assets as of December 31, 2021.

[0000866374-22-000016:notes:145]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-22-000016:notes:146]
SHARE REPURCHASES 
During the three and nine-month periods ended December 31, 2021, the Company repurchased 5.0 million and 32.0 million shares at an aggregate purchase price of $90.0 million and $580.3 million, respectively, and retired all of these shares.

[0000866374-22-000016:notes:147]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of Annual General Meeting held on August 4, 2021. As of December 31, 2021, shares in the aggregate amount of $600.9 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-22-000016:notes:148]
[same as prior period, unchanged from 0000866374-21-000062:notes:122]

[0000866374-22-000016:notes:149]
[same as prior period, unchanged from 0000866374-21-000062:notes:123]

[0000866374-22-000016:notes:150]
[same as prior period, unchanged from 0000866374-21-000062:notes:124]

[0000866374-22-000016:notes:151]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,581 |  |  | $ | 3,834 |  |  | $ | 10,450 |  |  | $ | 10,063 |  |
| Flex Reliability Solutions | 3,038 |  |  | 2,886 |  |  | 8,740 |  |  | 7,795 |  |
|  | $ | 6,619 |  |  | $ | 6,720 |  |  | $ | 19,190 |  |  | $ | 17,858 |  |
| Segment income and reconciliation of operating income: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 163 |  |  | $ | 153 |  |  | $ | 453 |  |  | $ | 313 |  |
| Flex Reliability Solutions | 154 |  |  | 178 |  |  | 475 |  |  | 472 |  |
| Corporate and Other | (19) |  |  | (20) |  |  | (54) |  |  | (64) |  |
| Total segment income | 298 |  |  | 311 |  |  | 874 |  |  | 721 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 15 |  |  | 16 |  |  | 45 |  |  | 47 |  |
| Stock-based compensation | 25 |  |  | 25 |  |  | 69 |  |  | 62 |  |
| Restructuring charges | 2 |  |  | 30 |  |  | 10 |  |  | 75 |  |
| Legal and other (1) | 5 |  |  | — |  |  | 5 |  |  | 25 |  |
| Operating income | $ | 251 |  |  | $ | 240 |  |  | $ | 745 |  |  | $ | 512 |  |

[0000866374-22-000016:notes:152]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During the third quarter of fiscal year 2022, the Company incurred $4.8 million in acquisition-related costs related to the acquisition of Anord Mardix. During the first quarter of fiscal year 2021, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-22-000016:notes:153]
[same as prior period, unchanged from 0000866374-21-000062:notes:127]

[0000866374-22-000016:notes:154]
[same as prior period, unchanged from 0000866374-21-000062:notes:128]


## us-gaap:SubsequentEventsTextBlock

[0000866374-22-000016:notes:155]
SUBSEQUENT EVENTS
Issuance and Sale of Series A Preferred Units of Nextracker

[0000866374-22-000016:notes:156]
On February 1, 2022, affiliates of the Company entered into a purchase agreement (the “Purchase Agreement”) with TPG Rise Flash, L.P., a Delaware limited partnership, which is managed or advised by TPG Rise Climate, TPG, Inc.’s dedicated renewables and climate investing fund (“TPG Rise”), for the sale of 500,000 Series A Preferred Units (the “Preferred Units”) in Nextracker LLC (“Nextracker LLC” or “Nextracker”) for an aggregate purchase price of $500 million (the “Preferred Sale”). TPG Rise’s investment in approximately 16.7% of Nextracker LLC reflects an implied value for Nextracker LLC as of the date of the investment of $3.0 billion.

[0000866374-22-000016:notes:157]
Dividends.  The Preferred Units have a dividend rate of 5% per annum, payable semi-annually, up to 100% of which (less an amount necessary to fund TPG Rise’s tax obligations) may be payable in kind during the first two years following the closing of the Preferred Sale, and 50% of which may be payable in kind thereafter.

[0000866374-22-000016:notes:158]
Conversion Ratio.  The Preferred Units will be automatically converted into common units of Nextracker LLC upon a qualified initial public offering (a “Qualified Public Offering”) and TPG Rise may elect to convert the Preferred Units into common units of Nextracker LLC at any time after March 31, 2023. Subject to certain exceptions, for any mandatory or optional conversion, the conversion ratio for each Preferred Unit will be based on a deemed value of Nextracker LLC equal to the lesser of $3.0 billion and the implied equity valuation of Nextracker LLC determined by the underwriters engaged in connection with a Qualified Public Offering. If a Qualified Public Offering occurs by March 31, 2023 with an implied equity valuation greater than $3.75 billion, then the conversion ratio will be adjusted upwards based on a deemed value of Nextracker LLC equal to $3.2 billion. If a Qualified Public Offering occurs after March 31, 2023 with an implied equity valuation between $2.7 billion and $3.0 billion, then the conversion ratio will be based on a deemed value of Nextracker LLC equal to $3.0 billion. If a Qualified Public Offering occurs after March 31, 2023 with an implied equity valuation of less than $2.7 billion, then the conversion ratio will be based on a deemed value equal to the implied equity valuation of Nextracker LLC in the Qualified Public Offering divided by 90%. If TPG Rise elects to convert the Preferred Units prior to an initial public offering, the conversion ratio shall be based on a deemed value of Nextracker LLC equal to $3.0 billion.

[0000866374-22-000016:notes:159]
Repurchase.  At TPG Rise’s election, the Company is required to repurchase all of the outstanding Preferred Units at their liquidation preference, which shall include all contributed but unreturned capital plus accrued but unpaid dividends, at the earlier of certain change in control events and February 2, 2028. Additionally, if Nextracker has not completed a Qualified Public Offering prior to February 2, 2027, then TPG Rise may cause the Company to repurchase all of the outstanding Preferred Units at their fair market value (determined by a mutually agreeable third-party appraiser).

[0000866374-22-000016:notes:160]
Voting Rights.  The Preferred Units will vote together with the common units of Nextracker as a single class in all matters that are subject to a vote by common unitholders. In connection with the Preferred Sale, TPG Rise has the right to designate two members of the Board of Nextracker LLC; if, however, TPG Rise owns Preferred Units or common units of Nextracker LLC with a fully diluted ownership percentage of less than 10% but more than 5%, the number of Board members that TPG Rise will be entitled to designate will be reduced to one. So long as at least 51% of the Preferred Units remain outstanding, the consent of the holders of the Preferred Units must be obtained prior to taking certain actions regarding Nextracker LLC, including, but not limited to, changes to the terms of the Preferred Units that adversely affect the rights of holders of the Preferred Units, certain incurrences of indebtedness by Nextracker, certain capital expenditures, acquisitions or dispositions by Nextracker, and changes to the Board and management of Nextracker.

[0000866374-22-000016:notes:161]
Conversion to Limited Liability Company.  In connection with the Preferred Sale, Nextracker Inc. (the predecessor to Nextracker LLC) was converted to a limited liability company and will remain a subsidiary of the Company until the disposition of a majority of the securities of Nextracker LLC, in an initial public offering and/or other corporate transaction. The conversion of Nextracker Inc. is intended to facilitate an initial public offering in the future through what is commonly referred to as an umbrella partnership-C Corporation or an “Up-C” structure.

[0000866374-22-000016:notes:162]
Separation and Transition Services Agreements.  At the closing of the Preferred Sale, the Company, Flextronics International USA, Inc. and Nextracker LLC entered into a separation agreement and a transition services agreement to formally separate the operations of the businesses. The Company will report the Nextracker business as a separate operating and reportable segment for the fiscal year ending March 31, 2022.
