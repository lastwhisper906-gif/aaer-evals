# FLEX MD&A — 0000866374-23-000058


## mdna

[0000866374-23-000058:mdna:1]
[same as prior period, unchanged from 0000866374-23-000007:mdna:1]

[0000866374-23-000058:mdna:2]
[same as prior period, unchanged from 0000866374-23-000007:mdna:2]

[0000866374-23-000058:mdna:3]
[same as prior period, unchanged from 0000866374-23-000007:mdna:3]

[0000866374-23-000058:mdna:4]
We are the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we support the entire product lifecycle with advanced manufacturing solutions and operate one of the most trusted global supply chains. We also provide additional value to customers through a broad array of services, including design engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. We support a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of June 30, 2023, our three operating and reportable segments were as follows:

[0000866374-23-000058:mdna:5]
[same as prior period, unchanged from 0000866374-23-000007:mdna:5]

[0000866374-23-000058:mdna:6]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-23-000058:mdna:7]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio

[0000866374-23-000058:mdna:8]
[same as prior period, unchanged from 0000866374-23-000007:mdna:8]

[0000866374-23-000058:mdna:9]
[same as prior period, unchanged from 0000866374-23-000007:mdna:9]

[0000866374-23-000058:mdna:10]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies

[0000866374-23-000058:mdna:11]
◦Health Solutions, including medical devices, medical equipment and drug delivery

[0000866374-23-000058:mdna:12]
[same as prior period, unchanged from 0000866374-23-000007:mdna:12]

[0000866374-23-000058:mdna:13]
[same as prior period, unchanged from 0000866374-23-000007:mdna:13]

[0000866374-23-000058:mdna:14]
[same as prior period, unchanged from 0000866374-23-000007:mdna:14]

[0000866374-23-000058:mdna:15]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solution requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0000866374-23-000058:mdna:16]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-23-000058:mdna:17]
We believe that our continued business transformation is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-23-000058:mdna:18]
Update on Component Shortages and Logistical Constraints on our Business

[0000866374-23-000058:mdna:19]
Component shortages and logistical constraints improved as the year progressed, however, we continue to see constraints in large-node semiconductors. We continue to monitor potential supply chain disruptions. Refer to “Risk Factors - “Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, have in the past affected, and may in the future, affect our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory. We have been and continue to be adversely affected by supply chain issues, including shortages of required electronic components.” as disclosed in Part I, “Item 1A. Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0000866374-23-000058:mdna:20]
[same as prior period, unchanged from 0000866374-23-000007:mdna:22]

[0000866374-23-000058:mdna:21]
[same as prior period, unchanged from 0000866374-23-000007:mdna:23]

[0000866374-23-000058:mdna:22]
[same as prior period, unchanged from 0000866374-23-000007:mdna:24]

[0000866374-23-000058:mdna:23]
[same as prior period, unchanged from 0000866374-23-000007:mdna:25]

[0000866374-23-000058:mdna:24]
On July 3, 2023, our subsidiary Nextracker Inc. ("Nextracker") completed a follow-on offering to its initial public offering, which was completed on February 13, 2023, and issued 15,631,562 shares of Class A common stock and received net proceeds of $551 million. The entire net proceeds were used by Nextracker to acquire 14,025,000 Nextracker LLC common units from Yuma, Inc., our indirect wholly-owned subsidiary, and 1,606,562 Nextracker LLC common units from TPG Rise Flash, L.P., an affiliate of the global alternative asset management firm TPG. As a result of the repurchase of Nextracker LLC common units by Nextracker, 15,631,562 shares of Nextracker Class B common stock were cancelled. Subsequent to the follow-on offering, we owned 74,432,619 shares of Class B common stock, representing 51.5% of the total outstanding shares of Nextracker common stock and, accordingly, still controls Nextracker. We received approximately $495 million from the follow-on offering, after distribution of net proceeds to TPG and expenses.

[0000866374-23-000058:mdna:25]
[same as prior period, unchanged from 0000866374-23-000007:mdna:29]

[0000866374-23-000058:mdna:26]
We are one of the world's largest providers of global supply chain solutions, with revenues of $7.3 billion for the three-month period ended June 30, 2023 and $30.3 billion in the fiscal year ended March 31, 2023. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. We also provide intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites:

[0000866374-23-000058:mdna:27]
|  | Three-Month Periods Ended |
|  | June 30, 2023 |  | July 1, 2022 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |
| Americas | $ | 3,482 |  |  | 47 | % |  | $ | 3,315 |  |  | 45 | % |
| Asia | 2,317 |  |  | 32 | % |  | 2,517 |  |  | 34 | % |
| Europe | 1,537 |  |  | 21 | % |  | 1,515 |  |  | 21 | % |
|  | $ | 7,336 |  |  |  |  | $ | 7,347 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |
| Mexico | $ | 1,731 |  |  | 24 | % |  | $ | 1,555 |  |  | 21 | % |
| China | 1,414 |  |  | 19 | % |  | 1,584 |  |  | 22 | % |
| U.S. | 1,325 |  |  | 18 | % |  | 1,216 |  |  | 17 | % |
| Malaysia | 546 |  |  | 7 | % |  | 570 |  |  | 8 | % |
| Brazil | 402 |  |  | 5 | % |  | 527 |  |  | 7 | % |
| Hungary | 351 |  |  | 5 | % |  | 286 |  |  | 4 | % |
| Other | 1,567 |  |  | 22 | % |  | 1,609 |  |  | 21 | % |
|  | $ | 7,336 |  |  |  |  | $ | 7,347 |  |  |  |

[0000866374-23-000058:mdna:28]
|  | As of |  | As of |
| Property and equipment, net: | June 30, 2023 |  | March 31, 2023 |
|  | (In millions) |
| Mexico | $ | 788 |  |  | 33 | % |  | $ | 763 |  |  | 32 | % |
| U.S. | 361 |  |  | 15 | % |  | 365 |  |  | 16 | % |
| China | 336 |  |  | 14 | % |  | 338 |  |  | 14 | % |
| Malaysia | 152 |  |  | 6 | % |  | 152 |  |  | 6 | % |
| Hungary | 140 |  |  | 6 | % |  | 140 |  |  | 6 | % |
| India | 91 |  |  | 4 | % |  | 96 |  |  | 4 | % |
| Other | 495 |  |  | 22 | % |  | 495 |  |  | 22 | % |
|  | $ | 2,363 |  |  |  |  | $ | 2,349 |  |  |  |

[0000866374-23-000058:mdna:29]
[same as prior period, unchanged from 0000866374-23-000007:mdna:33]

[0000866374-23-000058:mdna:30]
[same as prior period, unchanged from 0000866374-23-000007:mdna:34]

[0000866374-23-000058:mdna:31]
•global economic conditions, including inflationary pressures, currency volatility, slower growth or recession, higher interest rates, and geopolitical uncertainty (including the ongoing conflict between Russia and Ukraine);

[0000866374-23-000058:mdna:32]
28

[0000866374-23-000058:mdna:33]
[same as prior period, unchanged from 0000866374-23-000007:mdna:39]

[0000866374-23-000058:mdna:34]
[same as prior period, unchanged from 0000866374-23-000007:mdna:40]

[0000866374-23-000058:mdna:35]
[same as prior period, unchanged from 0000866374-23-000007:mdna:41]

[0000866374-23-000058:mdna:36]
•the effects that current credit and market conditions (including as a result of the ongoing conflict between Russia and Ukraine) could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-23-000058:mdna:37]
•the impacts on our business due to component shortages, disruptions in transportation or other supply chain related constraints;

[0000866374-23-000058:mdna:38]
•exposure to infectious disease, epidemics and pandemics on our business operations in geographic locations impacted by the outbreak and on the business operations of our customers and suppliers;

[0000866374-23-000058:mdna:39]
[same as prior period, unchanged from 0000866374-23-000007:mdna:43]

[0000866374-23-000058:mdna:40]
[same as prior period, unchanged from 0000866374-23-000007:mdna:44]

[0000866374-23-000058:mdna:41]
[same as prior period, unchanged from 0000866374-23-000007:mdna:45]

[0000866374-23-000058:mdna:42]
[same as prior period, unchanged from 0000866374-23-000007:mdna:46]

[0000866374-23-000058:mdna:43]
[same as prior period, unchanged from 0000866374-23-000007:mdna:47]

[0000866374-23-000058:mdna:44]
[same as prior period, unchanged from 0000866374-23-000007:mdna:48]

[0000866374-23-000058:mdna:45]
[same as prior period, unchanged from 0000866374-23-000007:mdna:49]

[0000866374-23-000058:mdna:46]
We are also subject to other risks as outlined in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0000866374-23-000058:mdna:47]
CRITICAL ACCOUNTING ESTIMATES

[0000866374-23-000058:mdna:48]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to the ongoing conflict between Russia and Ukraine, there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from those estimates and assumptions.

[0000866374-23-000058:mdna:49]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2023, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0000866374-23-000058:mdna:50]
[same as prior period, unchanged from 0000866374-23-000007:mdna:54]

[0000866374-23-000058:mdna:51]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0000866374-23-000058:mdna:52]
|  | Three-Month Periods Ended |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |
| Cost of sales | 91.8 |  |  | 92.7 |  |  |  |  |
| Restructuring charges | 0.2 |  |  | — |  |  |  |  |
| Gross profit | 8.0 |  |  | 7.3 |  |  |  |  |
| Selling, general and administrative expenses | 3.7 |  |  | 3.3 |  |  |  |  |
| Restructuring charges | 0.1 |  |  | — |  |  |  |  |
| Intangible amortization | 0.2 |  |  | 0.3 |  |  |  |  |
| Operating income | 4.0 |  |  | 3.7 |  |  |  |  |
| Interest, net | 0.6 |  |  | 0.6 |  |  |  |  |
| Other charges (income), net | 0.1 |  |  | (0.1) |  |  |  |  |
| Income before income taxes | 3.3 |  |  | 3.2 |  |  |  |  |
| Provision for income taxes | 0.4 |  |  | 0.5 |  |  |  |  |
| Net income | 2.9 | % |  | 2.7 | % |  |  |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 0.4 |  |  | 0.1 |  |  |  |  |
| Net income attributable to Flex Ltd. | 2.5 | % |  | 2.6 | % |  |  |  |

[0000866374-23-000058:mdna:53]
[same as prior period, unchanged from 0000866374-23-000007:mdna:57]

[0000866374-23-000058:mdna:54]
[same as prior period, unchanged from 0000866374-23-000007:mdna:58]

[0000866374-23-000058:mdna:55]
|  | Three-Month Periods Ended |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,601 |  |  | 49 | % |  | $ | 3,991 |  |  | 54 | % |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 3,291 |  |  | 45 | % |  | 2,969 |  |  | 41 | % |  |  |  |  |  |  |  |
| Nextracker | 480 |  |  | 7 | % |  | 395 |  |  | 5 | % |  |  |  |  |  |  |  |
| Intersegment eliminations | (36) |  |  | — | % |  | (8) |  |  | — | % |  |  |  |  |  |  |  |
|  | $ | 7,336 |  |  |  |  | $ | 7,347 |  |  |  |  |  |  |  |  |  |  |

[0000866374-23-000058:mdna:56]
Net sales during the three-month period ended June 30, 2023 totaled $7.3 billion, representing a decrease of approximately $11 million, or less than 1% from $7.3 billion during the three-month period ended July 1, 2022. Net sales for our FAS segment decreased approximately $0.4 billion, or 10% from the three-month period ended July 1, 2022, primarily driven by a significant decrease in our Consumer Devices business and a mid-teens decrease in our Lifestyle business due to weakness in consumer end markets. Sales in our Communications, Enterprise and Cloud ("CEC") business were flat due to the effect of easing supply constraints and softer demand in certain markets. Net sales for our FRS segment increased approximately $0.3 billion, or 11% from the three-month period ended July 1, 2022, primarily driven by a mid-teens increase in our Automotive business, a low-teens increase in our Health Solutions business and a high single-digit increase in our Industrial business due to strong customer demand and ramps across various end markets. Net sales for our Nextracker segment increased approximately $0.1 billion, or 21% from the three-month period ended July 1, 2022, primarily driven by an increase in gigawatts delivered. Net sales decreased $0.2 billion to $2.3 billion in Asia, offset by a $0.2 billion increase to $3.5 billion in the Americas, and a $23 million increase to $1.5 billion in Europe.

[0000866374-23-000058:mdna:57]
30

[0000866374-23-000058:mdna:58]
Our ten largest customers during the three-month periods ended June 30, 2023 and July 1, 2022 accounted for approximately 34% and 35% of net sales, respectively. No customer accounted for more than 10% of net sales during the three-month periods ended June 30, 2023 or July 1, 2022.

[0000866374-23-000058:mdna:59]
[same as prior period, unchanged from 0000866374-23-000007:mdna:64]

[0000866374-23-000058:mdna:60]
[same as prior period, unchanged from 0000866374-23-000007:mdna:65]

[0000866374-23-000058:mdna:61]
Cost of sales during the three-month period ended June 30, 2023 totaled $6.7 billion, representing a decrease of approximately $0.1 billion, or 1% from $6.8 billion during the three-month period ended July 1, 2022. Lower cost of sales for the three-month period ended June 30, 2023 was primarily driven by a reduction in FAS segment sales, improvement in freight and logistics costs at Nextracker and favorable product mix within our FRS segment partially offset by an increase in FRS segment sales. Cost of sales in FAS for the three-month period ended June 30, 2023 decreased approximately $0.4 billion, or 10% from the three-month period ended July 1, 2022, which is in line with the overall 10% decrease in FAS revenue during the same period. Cost of sales in FRS for the three-month period ended June 30, 2023 increased approximately $0.3 billion, or 11% from the three-month period ended July 1, 2022, which is primarily attributed to the overall 11% increase in FRS revenue during the same period. Cost of sales in our Nextracker segment for the three-month period ended June 30, 2023 increased approximately $17 million, or 5% from the three-month period ended July 1, 2022, primarily due to the 21% increase in Nextracker revenue during the same period, offset by improved profitability resulting from a decline in freight and logistics cost increases and overall better execution on our contracts.

[0000866374-23-000058:mdna:62]
[same as prior period, unchanged from 0000866374-23-000007:mdna:68]

[0000866374-23-000058:mdna:63]
Gross profit is affected by a fluctuation in cost of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-23-000058:mdna:64]
Gross profit during the three-month period ended June 30, 2023 increased $0.1 billion to $0.6 billion, or 8% of net sales, from $0.5 billion, or 7.3% of net sales, during the three-month period ended July 1, 2022. Gross margin improved 70 basis points during the three-month period ended June 30, 2023 primarily due to favorable mix with growth in our higher-margin FRS and Nextracker segments, partially offset by unfavorable mix in our CEC business.

[0000866374-23-000058:mdna:65]
[same as prior period, unchanged from 0000866374-23-000007:mdna:73]

[0000866374-23-000058:mdna:66]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, legal and other, and interest, net and other charges (income), net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-23-000058:mdna:67]
The following table sets forth segment income and margins. Segment margins in the table below may not recalculate exactly due to rounding.

[0000866374-23-000058:mdna:68]
|  | Three-Month Periods Ended |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 146 |  |  | 4.1 | % |  | $ | 171 |  |  | 4.3 | % |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 165 |  |  | 5.0 | % |  | 147 |  |  | 5.0 | % |  |  |  |  |  |  |  |
| Nextracker | 82 |  |  | 17.2 | % |  | 30 |  |  | 7.6 | % |  |  |  |  |  |  |  |

[0000866374-23-000058:mdna:69]
FAS segment margin decreased approximately 20 basis points, to 4.1%, for the three-month period ended June 30, 2023, from 4.3% for the three-month period ended July 1, 2022. The margin decrease was attributable to unfavorable mix and ramp costs in CEC.

[0000866374-23-000058:mdna:70]
FRS segment margin remained relatively flat at 5.0% for the three-month periods ended June 30, 2023 and July 1, 2022. Improving margins in our Health Solutions business due to increased productivity offset by continued project ramps and costs related to lingering semiconductor supply chain disruptions in our Industrial and Automotive businesses.

[0000866374-23-000058:mdna:71]
Nextracker segment margin increased approximately 960 basis points, to 17.2% for the three-month period ended June 30, 2023, from 7.6% for the three-month period ended July 1, 2022. The margin increase was driven by improved pricing, freight savings, and favorable cost absorption with increased revenues.

[0000866374-23-000058:mdna:72]
[same as prior period, unchanged from 0000866374-23-000007:mdna:80]

[0000866374-23-000058:mdna:73]
During the three-month period ended June 30, 2023, we recognized approximately $23 million of restructuring charges, primarily related to employee severance.

[0000866374-23-000058:mdna:74]
[same as prior period, unchanged from 0000866374-23-000007:mdna:84]

[0000866374-23-000058:mdna:75]
Selling, general and administrative expenses (“SG&A”) was approximately $0.3 billion, or 3.7% of net sales, during the three-month period ended June 30, 2023, increasing $29 million from approximately $0.2 billion, or 3.3% of net sales, during the three-month period ended July 1, 2022. The increase was primarily due to elevated SG&A costs to support higher revenue growth in our Nextracker segment and higher labor costs.

[0000866374-23-000058:mdna:76]
[same as prior period, unchanged from 0000866374-23-000007:mdna:86]

[0000866374-23-000058:mdna:77]
Amortization of intangible assets decreased to $20 million during the three-month period ended June 30, 2023, from $22 million for the three-month period ended July 1, 2022, primarily due to certain intangibles now being fully amortized.

[0000866374-23-000058:mdna:78]
Interest, net

[0000866374-23-000058:mdna:79]
Interest, net was an expense of $41 million during the three-month period ended June 30, 2023 compared to an expense of $49 million during the three-month period ended July 1, 2022, primarily due to higher interest income, offset by higher variable interest expense compared to the prior year period.

[0000866374-23-000058:mdna:80]
Other charges (income), net

[0000866374-23-000058:mdna:81]
Other charges (income), net was an expense of $11 million during the three-month period ended June 30, 2023 compared to income of $9 million during the three-month period ended July 1, 2022, primarily due to a higher foreign exchange transaction loss recognized compared to the prior year period.

[0000866374-23-000058:mdna:82]
[same as prior period, unchanged from 0000866374-23-000007:mdna:91]

[0000866374-23-000058:mdna:83]
Certain of our subsidiaries, at various times, have been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 15, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2023 for further discussion.

[0000866374-23-000058:mdna:84]
The consolidated effective tax rate was 12% and 16% for the three-month periods ended June 30, 2023 and July 1, 2022, respectively. The effective tax rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, the Netherlands and Israel. The effective tax rate for the three-month period ended June 30, 2023 is lower than the effective tax rate for the three-month period ended July 1, 2022, due to the changing jurisdictional mix of income and the beneficial foreign exchange impacts on material tax balances for the period ended June 30, 2023.

[0000866374-23-000058:mdna:85]
On August 16, 2022, the Inflation Reduction Act of 2022 (“IRA”) was enacted into law, which includes a new corporate minimum tax, a stock repurchase excise tax, numerous green energy credits, other tax provisions, and significantly increased enforcement resources. While detailed regulations on some aspects of the act are still outstanding, we do not anticipate a material impact to our consolidated financial statements from these provisions.

[0000866374-23-000058:mdna:86]
[same as prior period, unchanged from 0000866374-23-000007:mdna:95]

[0000866374-23-000058:mdna:87]
In response to the challenging economic environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of June 30, 2023, we had cash and cash equivalents of approximately $2.7

[0000866374-23-000058:mdna:88]
32

[0000866374-23-000058:mdna:89]
billion and bank and other borrowings of approximately $3.6 billion. As of June 30, 2023, we had a $2.5 billion revolving credit facility that is due to mature in July 2027 (the "2027 Credit Facility"), and a $0.5 billion revolving credit facility that is due to mature in February 2028 (the "Nextracker Revolver"), under which we had no borrowings outstanding. As of June 30, 2023, we were in compliance with the covenants under all of our credit facilities and indentures; we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-23-000058:mdna:90]
In fiscal year 2024, we implemented a 10b5-1 bond buyback program, aiming to repurchase certain outstanding bonds issued by us. During the three-month period ended June 30, 2023, we repurchased approximately $2 million of the 4.750% Notes due 2025, resulting in an immaterial gain on our condensed consolidated statement of operations.

[0000866374-23-000058:mdna:91]
Cash provided by operating activities was $6 million during the three-month period ended June 30, 2023, primarily driven by $0.2 billion of net income for the period plus $0.2 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, and stock-based compensation, offset by certain changes in net working capital as discussed below.

[0000866374-23-000058:mdna:92]
We believe net working capital ("NWC") is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital decreased $0.3 billion to $4.9 billion as of June 30, 2023, from $5.2 billion as of March 31, 2023. This decrease is primarily driven by a $0.6 billion decrease in cash due to debt repayments, capital expenditures, and share repurchases, offset by a $0.1 billion increase in other current assets, and a $0.1 billion decrease in deferred revenue and working capital advances.

[0000866374-23-000058:mdna:93]
Cash used in investing activities was $0.2 billion during the three-month period ended June 30, 2023. This was primarily driven by $0.2 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our CEC, Automotive, and Industrial businesses.

[0000866374-23-000058:mdna:94]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investors. Our adjusted free cash flow for the three-month periods ended June 30, 2023 and July 1, 2022 was an outflow of $0.2 billion and an outflow of $0.1 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-23-000058:mdna:95]
|  | Three-Month Periods Ended |
|  | June 30, 2023 |  | July 1, 2022 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 6 |  |  | $ | 38 |  |
| Purchases of property and equipment | (167) |  |  | (107) |  |
| Proceeds from the disposition of property and equipment | 11 |  |  | 16 |  |
| Adjusted free cash flow | $ | (150) |  |  | $ | (53) |  |

[0000866374-23-000058:mdna:96]
Cash used by financing activities was $0.5 billion during the three-month period ended June 30, 2023, which was primarily driven by $0.2 billion of cash paid for the repurchase of our ordinary shares and $0.3 billion of net cash for repayments of bank borrowings and long-term debt and an associated cross-currency swap.

[0000866374-23-000058:mdna:97]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of June 30, 2023 and March 31, 2023, approximately 37% and 27%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.9 billion as of March 31, 2023). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local

[0000866374-23-000058:mdna:98]
[same as prior period, unchanged from 0000866374-23-000007:mdna:61]

[0000866374-23-000058:mdna:99]
restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-23-000058:mdna:100]
[same as prior period, unchanged from 0000866374-23-000007:mdna:106]

[0000866374-23-000058:mdna:101]
We maintain various uncommitted short-term financing facilities including but not limited to a commercial paper program, and a revolving sale and repurchase of subordinated notes established under the asset-backed securitization ("ABS") programs, under which there were no borrowings outstanding as of June 30, 2023.

[0000866374-23-000058:mdna:102]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also have the ability to sell a designated pool of trade receivables under ABS programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed.

[0000866374-23-000058:mdna:103]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-23-000058:mdna:104]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1.0 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 25, 2022. During the three-month period ended June 30, 2023, we paid $197 million to repurchase shares under the current repurchase plan at an average price of $22.71 per share. As of June 30, 2023, shares in the aggregate amount of $697 million were available to be repurchased under the current plan.

[0000866374-23-000058:mdna:105]
[same as prior period, unchanged from 0000866374-23-000007:mdna:113]

[0000866374-23-000058:mdna:106]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2023.

[0000866374-23-000058:mdna:107]
There were no material changes in our contractual obligations and commitments as of June 30, 2023.
