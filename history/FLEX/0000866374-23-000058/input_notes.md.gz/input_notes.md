# FLEX notes — 0000866374-23-000058


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-23-000058:notes:1]
[same as prior period, unchanged from 0000866374-23-000007:notes:1]

[0000866374-23-000058:notes:2]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of June 30, 2023, Flex's three operating and reportable segments were as follows:

[0000866374-23-000058:notes:3]
[same as prior period, unchanged from 0000866374-23-000007:notes:3]

[0000866374-23-000058:notes:4]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-23-000058:notes:5]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio

[0000866374-23-000058:notes:6]
[same as prior period, unchanged from 0000866374-23-000007:notes:6]

[0000866374-23-000058:notes:7]
[same as prior period, unchanged from 0000866374-23-000007:notes:7]

[0000866374-23-000058:notes:8]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies

[0000866374-23-000058:notes:9]
◦Health Solutions, including medical devices, medical equipment and drug delivery

[0000866374-23-000058:notes:10]
[same as prior period, unchanged from 0000866374-23-000007:notes:10]

[0000866374-23-000058:notes:11]
[same as prior period, unchanged from 0000866374-23-000007:notes:11]

[0000866374-23-000058:notes:12]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers). The Company also provides intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world.

[0000866374-23-000058:notes:13]
Basis of Presentation and Principles of Consolidation

[0000866374-23-000058:notes:14]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

[0000866374-23-000058:notes:15]
The first quarters for fiscal years 2024 and 2023 ended on June 30, 2023, which is comprised of 91 days in the period, and July 1, 2022, which is comprised of 92 days, respectively.

[0000866374-23-000058:notes:16]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest.  A controlling financial interest may also exist in variable interest entities (“VIEs”), through governance provisions and arrangements to provide services to VIEs.

[0000866374-23-000058:notes:17]
The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The condensed consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of June 30, 2023, we presented noncontrolling interest as permanent equity in the condensed balance sheets, reflecting the equity held by other parties. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the condensed consolidated statements of operations.

[0000866374-23-000058:notes:18]
[same as prior period, unchanged from 0000866374-23-000007:notes:18]

[0000866374-23-000058:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-23-000058:notes:20]
Recently Adopted Accounting Pronouncements

[0000866374-23-000058:notes:21]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company adopted the guidance retrospectively during the first quarter of fiscal year 2024, including a rollforward of changes in those obligations, with immaterial impacts on its condensed consolidated financial statements.

[0000866374-23-000058:notes:22]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due date. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. We have no economic interest in a supplier’s decision to participate in the supplier finance programs.

[0000866374-23-000058:notes:23]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The

[0000866374-23-000058:notes:24]
rollforward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the three-month period ended June 30, 2023 is as follows.

[0000866374-23-000058:notes:25]
|  | Three-Month Period Ended |
|  | June 30, 2023 |
|  | (In millions) |
| Confirmed obligations outstanding at the beginning of the period | $ | 275 |  |
| Invoices confirmed during the period | 272 |  |
| Confirmed invoices paid during the period | (279) |  |
| Foreign currency exchange impact | 3 |  |
| Confirmed obligations outstanding at the end of the period | $ | 271 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000866374-23-000058:notes:26]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024.The first quarters for fiscal years 2024 and 2023 ended on June 30, 2023, which is comprised of 91 days in the period, and July 1, 2022, which is comprised of 92 days, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-23-000058:notes:27]
[same as prior period, unchanged from 0000866374-23-000007:notes:25]

[0000866374-23-000058:notes:28]
[same as prior period, unchanged from 0000866374-23-000007:notes:26]

[0000866374-23-000058:notes:29]
|  | As of June 30, 2023 |  | As of March 31, 2023 |
|  | (In millions) |
| Raw materials | $ | 5,990 |  |  | $ | 6,140 |  |
| Work-in-progress | 756 |  |  | 709 |  |
| Finished goods | 780 |  |  | 681 |  |
|  | $ | 7,526 |  |  | $ | 7,530 |  |

[0000866374-23-000058:notes:30]
[same as prior period, unchanged from 0000866374-23-000007:notes:28]

[0000866374-23-000058:notes:31]
During the three-month period ended June 30, 2023, there was no material activity in the Company's goodwill account for each of its reportable segments.

[0000866374-23-000058:notes:32]
[same as prior period, unchanged from 0000866374-23-000007:notes:30]

[0000866374-23-000058:notes:33]
|  | As of June 30, 2023 |  | As of March 31, 2023 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 351 |  |  | $ | (193) |  |  | $ | 158 |  |  | $ | 373 |  |  | $ | (204) |  |  | $ | 169 |  |
| Licenses and other intangibles | 302 |  |  | (161) |  |  | 141 |  |  | 299 |  |  | (152) |  |  | 147 |  |
| Total | $ | 653 |  |  | $ | (354) |  |  | $ | 299 |  |  | $ | 672 |  |  | $ | (356) |  |  | $ | 316 |  |

[0000866374-23-000058:notes:34]
[same as prior period, unchanged from 0000866374-23-000007:notes:32]

[0000866374-23-000058:notes:35]
[same as prior period, unchanged from 0000866374-23-000007:notes:33]

[0000866374-23-000058:notes:36]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | 51 |  |
| 2025 |  | 64 |  |
| 2026 |  | 43 |  |
| 2027 |  | 36 |  |
| 2028 |  | 27 |  |
| Thereafter |  | 78 |  |
| Total amortization expense |  | $ | 299 |  |

[0000866374-23-000058:notes:37]
[same as prior period, unchanged from 0000866374-23-000007:notes:35]

[0000866374-23-000058:notes:38]
(1)Represents estimated amortization for the remaining fiscal nine-month period ending March 31, 2024.

[0000866374-23-000058:notes:39]
[same as prior period, unchanged from 0000866374-23-000007:notes:37]

[0000866374-23-000058:notes:40]
Customer working capital advances were $2.2 billion and $2.3 billion, as of June 30, 2023 and March 31, 2023, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-23-000058:notes:41]
[same as prior period, unchanged from 0000866374-23-000007:notes:39]

[0000866374-23-000058:notes:42]
Other current liabilities include customer-related accruals of $272 million and $313 million as of June 30, 2023 and March 31, 2023, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-23-000058:notes:43]
[same as prior period, unchanged from 0000866374-23-000007:notes:44]

[0000866374-23-000058:notes:44]
[same as prior period, unchanged from 0000866374-23-000007:notes:45]

[0000866374-23-000058:notes:45]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract are transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-23-000058:notes:46]
[same as prior period, unchanged from 0000866374-23-000007:notes:47]

[0000866374-23-000058:notes:47]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the condensed consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-23-000058:notes:48]
[same as prior period, unchanged from 0000866374-23-000007:notes:50]

[0000866374-23-000058:notes:49]
[same as prior period, unchanged from 0000866374-23-000007:notes:51]

[0000866374-23-000058:notes:50]
[same as prior period, unchanged from 0000866374-23-000007:notes:52]

[0000866374-23-000058:notes:51]
[same as prior period, unchanged from 0000866374-23-000007:notes:53]

[0000866374-23-000058:notes:52]
[same as prior period, unchanged from 0000866374-23-000007:notes:54]

[0000866374-23-000058:notes:53]
[same as prior period, unchanged from 0000866374-23-000007:notes:55]

[0000866374-23-000058:notes:54]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $897 million and $885 million as of June 30, 2023 and March 31, 2023, respectively, of which $802 million and $795 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-23-000058:notes:55]
[same as prior period, unchanged from 0000866374-23-000007:notes:57]

[0000866374-23-000058:notes:56]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 30, 2023 and July 1, 2022, respectively.

[0000866374-23-000058:notes:57]
|  | Three-Month Periods Ended |  |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,436 |  |  | $ | 3,779 |  |  |  |  |  |
| Over time | 165 |  |  | 212 |  |  |  |  |  |
| Total | 3,601 |  |  | 3,991 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,132 |  |  | 2,790 |  |  |  |  |  |
| Over time | 159 |  |  | 179 |  |  |  |  |  |
| Total | 3,291 |  |  | 2,969 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 23 |  |  |  |  |  |
| Over time | 474 |  |  | 372 |  |  |  |  |  |
| Total | 480 |  |  | 395 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (36) |  |  | (8) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (36) |  |  | (8) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,538 |  |  | 6,584 |  |  |  |  |  |
| Over time | 798 |  |  | 763 |  |  |  |  |  |
| Total | $ | 7,336 |  |  | $ | 7,347 |  |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-23-000058:notes:58]
SHARE-BASED COMPENSATION
Equity Compensation Plans

[0000866374-23-000058:notes:59]
Flex historically maintains stock-based compensation plans at a corporate level. The Company's primary plan used for granting equity compensation awards is the Company's 2017 Equity Incentive Plan (the "2017 Plan"). During the fiscal year 2023, Nextracker granted equity compensation awards to Nextracker employees under the 2022 Nextracker Inc. Equity Incentive Plan (the "2022 Nextracker Plan"), which is administered by Nextracker, a majority owned subsidiary of the Company.

[0000866374-23-000058:notes:60]
Share-Based Compensation Expense

[0000866374-23-000058:notes:61]
The following table summarizes the Company’s share-based compensation expense for all equity incentive plans:

[0000866374-23-000058:notes:62]
|  | Three-Month Periods Ended |  |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |  |
|  | (In millions) |
| Cost of sales | $ | 9 |  |  | $ | 7 |  |  |  |  |  |
| Selling, general and administrative expenses | 32 |  |  | 19 |  |  |  |  |  |
| Total share-based compensation expense | $ | 41 |  |  | $ | 26 |  |  |  |  |  |

[0000866374-23-000058:notes:63]
Total number of options outstanding and exercisable were immaterial as of June 30, 2023. All options have been fully expensed as of June 30, 2023.

[0000866374-23-000058:notes:64]
The 2017 Plan

[0000866374-23-000058:notes:65]
During the three-month period ended June 30, 2023, the Company granted 4.8 million restricted share unit ("RSU") awards. Of this amount, approximately 3.0 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, and with an average grant date price of $26.81 per award. In addition, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $26.72 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of approximately 0.8 million based

[0000866374-23-000058:notes:66]
on a measurement of the Company's adjusted earnings per share growth over certain specified periods, and will cliff vest after a period of three years, to the extent such performance conditions have been met. Further, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $35.64 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 0.8 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met. Finally, the remaining balance of approximately 1.2 million represents the number of shares issued upon vesting of RSU awards above target levels based on the achievement of certain market conditions for awards granted in the fiscal year 2021. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-23-000058:notes:67]
As of June 30, 2023, approximately 12.6 million unvested RSU awards under the 2017 plan were outstanding, of which vesting for a targeted amount of 1.3 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of 1.3 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to 2.6 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to 2.6 million based on the achievement levels. During the three-month period ended June 30, 2023, 2.3 million shares vested in connection with the awards with market conditions granted in fiscal year 2021.

[0000866374-23-000058:notes:68]
As of June 30, 2023, total unrecognized compensation expense related to unvested RSU awards under the 2017 Plan, was approximately $237 million, and will be recognized over a weighted-average remaining vesting period of 2.4 years.

[0000866374-23-000058:notes:69]
The 2022 Nextracker Plan

[0000866374-23-000058:notes:70]
During the three-month period ended June 30, 2023, Nextracker awarded 1.1 million equity-based compensation awards to its employees under the 2022 Nextracker Plan, which included approximately 0.5 million option awards, 0.5 million RSU ("NRSU") awards and 0.1 million performance-based restricted share unit ("NPSU") awards. Vesting for the awards granted under the 2022 Nextracker Plan is contingent upon continued employee service and certain performance conditions.

[0000866374-23-000058:notes:71]
As of June 30, 2023, approximately 5.8 million unvested options awards, NRSU awards, and NPSU awards under the 2022 Nextracker Plan were outstanding, of which vesting for a targeted amount of approximately 3.8 million shares is contingent on meeting certain performance conditions. 
Total unrecognized compensation expense related to unvested awards under the 2022 Nextracker Plan was approximately $61 million, which is expected to be recognized over a weighted-average period of approximately 2.5 years. Approximately $8 million of expense was recognized for equity-based compensation awards granted under the 2022 Nextracker Plan for the three-month period ended June 30, 2023


## us-gaap:EarningsPerShareTextBlock

[0000866374-23-000058:notes:72]
[same as prior period, unchanged from 0000866374-23-000007:notes:70]

[0000866374-23-000058:notes:73]
|  | Three-Month Periods Ended |  |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |  |
|  | (In millions, except per share amounts) |
| Basic earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 211 |  |  | $ | 195 |  |  |  |  |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 25 |  |  | 6 |  |  |  |  |  |
| Net income attributable to Flex Ltd. | $ | 186 |  |  | $ | 189 |  |  |  |  |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 447 |  |  | 458 |  |  |  |  |  |
| Basic earnings per share | $ | 0.42 |  |  | $ | 0.41 |  |  |  |  |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 211 |  |  | $ | 195 |  |  |  |  |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 25 |  |  | 6 |  |  |  |  |  |
| Net income attributable to Flex Ltd. | $ | 186 |  |  | $ | 189 |  |  |  |  |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 447 |  |  | 458 |  |  |  |  |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 8 |  |  | 10 |  |  |  |  |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 455 |  |  | 468 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.41 |  |  | $ | 0.40 |  |  |  |  |  |

[0000866374-23-000058:notes:74]
(1)An immaterial amount of RSU awards and 5.2 million RSU awards for the three-month periods ended June 30, 2023 and July 1, 2022, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-23-000058:notes:75]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 30, 2023 and March 31, 2023 are as follows:

[0000866374-23-000058:notes:76]
|  | Maturity Date |  | As of June 30, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 597 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 685 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 658 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 684 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan | November 2023 |  | 150 |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 294 |  |  | 284 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (20) |  |  | (21) |  |
|  |  |  | 3,595 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (151) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,444 |  |  | $ | 3,691 |  |

[0000866374-23-000058:notes:77]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. These notes represent the Company’s senior unsecured obligations and hold equal ranking with all other existing and future senior unsecured debt obligations.

[0000866374-23-000058:notes:78]
(2)During the first quarter of fiscal year 2024, the Company repaid the JPY Term Loan for approximately $241 million. In addition, the Company also settled the associated USD JPY cross currency swap for approximately $60 million.

[0000866374-23-000058:notes:79]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.7% as of June 30, 2023 and March 31, 2023, respectively.

[0000866374-23-000058:notes:80]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 30, 2023 are as follows:

[0000866374-23-000058:notes:81]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | 151 |  |
| 2025 |  | — |  |
| 2026 |  | 1,282 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,635 |  |
| Total |  | $ | 3,615 |  |

[0000866374-23-000058:notes:82]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2024.


## us-gaap:InterestIncomeAndInterestExpenseDisclosureTextBlock

[0000866374-23-000058:notes:83]
INTEREST, NET 
Interest and other, net for the three-month periods ended June 30, 2023 and July 1, 2022 are primarily composed of the following:

[0000866374-23-000058:notes:84]
|  | Three-Month Periods Ended |  |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |  |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 47 |  |  | $ | 43 |  |  |  |  |  |
| Interest income | (18) |  |  | (4) |  |  |  |  |  |
| AR sales program related expenses | 12 |  |  | 5 |  |  |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-23-000058:notes:85]
[same as prior period, unchanged from 0000866374-23-000007:notes:98]

[0000866374-23-000058:notes:86]
[same as prior period, unchanged from 0000866374-23-000007:notes:99]

[0000866374-23-000058:notes:87]
As of June 30, 2023, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $11.3 billion as summarized below:

[0000866374-23-000058:notes:88]
|  | Notional Contract Value in USD |
| Currency | Buy |  | Sell |
| Cash Flow Hedges |  |  |  |
| HUF | $ | 446 |  |  | $ | — |  |
| MXN | 566 |  |  | — |  |
| Other | 649 |  |  | 37 |  |
|  | 1,661 |  |  | 37 |  |
| Other Foreign Currency Contracts |  |  |  |
| CNY | 541 |  |  | 66 |  |
| EUR | 2,515 |  |  | 2,750 |  |
| GBP | 229 |  |  | 308 |  |
| HUF | 179 |  |  | 144 |  |
| MXN | 636 |  |  | 508 |  |
| MYR | 327 |  |  | 170 |  |
| Other | 655 |  |  | 575 |  |
|  | 5,082 |  |  | 4,521 |  |
| Total Notional Contract Value in USD | $ | 6,743 |  |  | $ | 4,558 |  |

[0000866374-23-000058:notes:89]
As of June 30, 2023, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the condensed consolidated statements of operations. As of June 30, 2023 and March 31, 2023, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. The deferred gain was $27 million as of June 30, 2023, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations over the next twelve-month period, except for the USD HUF cross currency swaps.

[0000866374-23-000058:notes:90]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in current and long-term other liabilities as of June 30, 2023 and March 31, 2023. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-23-000058:notes:91]
[same as prior period, unchanged from 0000866374-23-000007:notes:105]

[0000866374-23-000058:notes:92]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | June 30,2023 |  | March 31,2023 |  | Balance SheetLocation |  | June 30,2023 |  | March 31,2023 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 60 |  |  | $ | 46 |  |  | Other current liabilities |  | $ | 15 |  |  | $ | 22 |  |
| Foreign currency contracts | Other assets |  | $ | — |  |  | $ | — |  |  | Other liabilities |  | $ | 17 |  |  | $ | 88 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 39 |  |  | $ | 26 |  |  | Other current liabilities |  | $ | 47 |  |  | $ | 19 |  |

[0000866374-23-000058:notes:93]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with certain counterparties. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-23-000058:notes:94]
[same as prior period, unchanged from 0000866374-23-000007:notes:108]

[0000866374-23-000058:notes:95]
|  | Three-Month Periods Ended |
|  | June 30, 2023 |  | July 1, 2022 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |  | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |
| Other comprehensive gains (loss) before reclassifications | 101 |  |  | (9) |  |  | 92 |  |  | (79) |  |  | (68) |  |  | (147) |  |
| Net (gains) loss reclassified from accumulated other comprehensive loss | (67) |  |  | — |  |  | (67) |  |  | 78 |  |  | (3) |  |  | 75 |  |
| Net current-period other comprehensive gains (loss) | 34 |  |  | (9) |  |  | 25 |  |  | (1) |  |  | (71) |  |  | (72) |  |
| Ending balance | $ | 20 |  |  | $ | (189) |  |  | $ | (169) |  |  | $ | (67) |  |  | $ | (187) |  |  | $ | (254) |  |

[0000866374-23-000058:notes:96]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended June 30, 2023 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in accumulated other comprehensive loss for the three-month periods ended June 30, 2023 and July 1, 2022 were $2 million and $4 million tax benefits, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-23-000058:notes:97]
TRADE RECEIVABLES SECURITIZATIONThe Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program. 
Asset-Backed Securitization Programs

[0000866374-23-000058:notes:98]
The Company historically has engaged in asset-backed securitization programs (the “ABS Programs”), selling trade receivables to affiliated special purpose entities and then to unaffiliated financial institutions. Upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, the receivables are derecognized from our consolidated balance sheet as effective control of the transferred receivables is passed to the unaffiliated financial institutions, which have the right to pledge or sell the receivables. Accounts receivable sold under the ABS Programs are included as cash provided by operating activities in the consolidated statement of cash flow. During the three-month periods ended June 30, 2023 and July 1, 2022, no accounts receivable were sold under the ABS Programs.

[0000866374-23-000058:notes:99]
Trade Accounts Receivable Sale Programs
The Company also sells accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.8 billion and $0.8 billion as of June 30, 2023 and March 31, 2023, respectively. For the three-month periods ended June 30, 2023 and July 1, 2022, total accounts receivable sold to certain third-party banking institutions was approximately $0.8 billion and $0.8 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-23-000058:notes:100]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES 
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-23-000058:notes:101]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of June 30, 2023 and March 31, 2023.

[0000866374-23-000058:notes:102]
[same as prior period, unchanged from 0000866374-23-000007:notes:119]

[0000866374-23-000058:notes:103]
[same as prior period, unchanged from 0000866374-23-000007:notes:120]

[0000866374-23-000058:notes:104]
[same as prior period, unchanged from 0000866374-23-000007:notes:121]

[0000866374-23-000058:notes:105]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-23-000058:notes:106]
[same as prior period, unchanged from 0000866374-23-000007:notes:123]

[0000866374-23-000058:notes:107]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended June 30, 2023 and July 1, 2022.

[0000866374-23-000058:notes:108]
[same as prior period, unchanged from 0000866374-23-000007:notes:125]

[0000866374-23-000058:notes:109]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of June 30, 2023 and March 31, 2023:

[0000866374-23-000058:notes:110]
|  | Fair Value Measurements as of June 30, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,266 |  |  | $ | — |  |  | $ | 1,266 |  |
| Foreign currency contracts (Note 8) | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (79) |  |  | $ | — |  |  | $ | (79) |  |
|  | Fair Value Measurements as of March 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 2,324 |  |  | $ | — |  |  | $ | 2,324 |  |
| Foreign currency contracts (Note 8) | — |  |  | 72 |  |  | — |  |  | 72 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (129) |  |  | $ | — |  |  | $ | (129) |  |

[0000866374-23-000058:notes:111]
[same as prior period, unchanged from 0000866374-23-000007:notes:128]

[0000866374-23-000058:notes:112]
[same as prior period, unchanged from 0000866374-23-000007:notes:129]

[0000866374-23-000058:notes:113]
|  | As of June 30, 2023 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| JPY Term Loan due April 2024 | $ | — |  |  | $ | — |  |  | $ | 253 |  |  | $ | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597 |  |  | 585 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 685 |  |  | 654 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 404 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 658 |  |  | 630 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 684 |  |  | 663 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan due November 2023 | 150 |  |  | 150 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| Nextracker Term Loan due February 2028 | 150 |  |  | 146 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 294 |  |  | 215 |  |  | 284 |  |  | 196 |  |  | Level 2 |

[0000866374-23-000058:notes:114]
The Notes due June 2025, February 2026, January 2028, June 2029 and May 2030 are valued based on broker trading prices in active markets. HUF Bonds and Nextracker Term Loan due February 2028 are valued based on the broker trading prices in an inactive market.

[0000866374-23-000058:notes:115]
The Delayed Draw Term Loan due November 2023 bears interest at floating interest rates, and therefore, as of June 30, 2023, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-23-000058:notes:116]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-23-000058:notes:117]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-23-000058:notes:118]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $86 million based on the exchange rate as of June 30, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $13 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $54 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-23-000058:notes:119]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-23-000058:notes:120]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $221 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-23-000058:notes:121]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-23-000058:notes:122]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-23-000058:notes:123]
SHARE REPURCHASES 
During the three-month period ended June 30, 2023, the Company repurchased 8.7 million shares at an aggregate purchase price of $197 million, and retired all of these shares.

[0000866374-23-000058:notes:124]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.0 billion in accordance with the share repurchase mandate approved by the Company’s 
shareholders at the date of the most recent Annual General Meeting held on August 25, 2022. As of June 30, 2023, shares in the aggregate amount of $697 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-23-000058:notes:125]
[same as prior period, unchanged from 0000866374-23-000007:notes:145]

[0000866374-23-000058:notes:126]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, legal and other, and interest, net and other charges (income), net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-23-000058:notes:127]
Selected financial information by segment is in the table below.

[0000866374-23-000058:notes:128]
|  | Three-Month Periods Ended |  |
|  | June 30, 2023 |  | July 1, 2022 |  |
|  | (In millions) |
| Net sales: |  |  |  |  |
| Flex Agility Solutions | $ | 3,601 |  |  | $ | 3,991 |  |  |
| Flex Reliability Solutions | 3,291 |  |  | 2,969 |  |  |
| Nextracker | 480 |  |  | 395 |  |  |
| Intersegment eliminations | (36) |  |  | (8) |  |  |
|  | $ | 7,336 |  |  | $ | 7,347 |  |  |
| Segment income and reconciliation of income before income taxes: |  |  |  |  |
| Flex Agility Solutions | $ | 146 |  |  | $ | 171 |  |  |
| Flex Reliability Solutions | 165 |  |  | 147 |  |  |
| Nextracker | 82 |  |  | 30 |  |  |
| Corporate and Other | (16) |  |  | (18) |  |  |
| Total segment income | 377 |  |  | 330 |  |  |
| Reconciling items: |  |  |  |  |
| Intangible amortization | 20 |  |  | 22 |  |  |
| Stock-based compensation | 41 |  |  | 26 |  |  |
| Restructuring charges | 23 |  |  | — |  |  |
| Legal and other (1) | 2 |  |  | 10 |  |  |
| Interest, net | 41 |  |  | 49 |  |  |
| Other charges (income), net | 11 |  |  | (9) |  |  |
| Income before income taxes | $ | 239 |  |  | $ | 232 |  |  |

[0000866374-23-000058:notes:129]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During the first quarter of fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-23-000058:notes:130]
[same as prior period, unchanged from 0000866374-23-000007:notes:150]

[0000866374-23-000058:notes:131]
[same as prior period, unchanged from 0000866374-23-000007:notes:151]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-23-000058:notes:132]
RESTRUCTURING CHARGES
The Company continued to identify certain structural changes to restructure its business throughout the first quarter of fiscal year 2024. During the three-month period ended June 30, 2023, the Company recognized approximately $23 million of restructuring charges, most of which related to employee severance.

[0000866374-23-000058:notes:133]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of June 30, 2023 for charges incurred during the three-month period ended June 30, 2023:

[0000866374-23-000058:notes:134]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2023 | $ | 44 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 50 |  |
| Provision for charges incurred during the three-month period ended June 30, 2023 | 20 |  |  | 3 |  |  | — |  |  | 23 |  |
| Cash payments during the three-month period ended June 30, 2023 | (22) |  |  | — |  |  | — |  |  | (22) |  |
| Non-cash charges incurred during the three-month period ended June 30, 2023 | — |  |  | (3) |  |  |  |  | (3) |  |
| Balance as of June 30, 2023 | 42 |  |  | — |  |  | 6 |  |  | 48 |  |
| Less: Current portion (classified as other current liabilities) | 42 |  |  | — |  |  | 6 |  |  | 48 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:VariableInterestEntityDisclosureTextBlock

[0000866374-23-000058:notes:135]
VARIABLE INTEREST ENTITIES
The Company controls Nextracker Inc. ("Nextracker") through its holding of Class B common stock that does not participate in the earnings of Nextracker. As such, the shareholders of the equity at risk in Nextracker (the Class A common stock shareholders) do not have the power to direct the key activities of Nextracker and consequently Nextracker is a variable interest entity ("VIE"). The Company has the ability to control Nextracker's activities through its control of 61.2% and 61.4% of the voting rights of Nextracker as of June 30, 2023 and March 31, 2023, respectively. The Company also has the ability to receive significant benefits from the VIE (through its ability to convert its investments in Nextracker and Nextracker LLC into Class A common stock of Nextracker or cash) and as such the Company has been determined to be the primary beneficiary of the VIE. As such, the Company continues to consolidate Nextracker and the interests in Nextracker held by third parties are presented as a noncontrolling interest. Evaluation of the VIE model and identification of the primary beneficiary requires significant judgements to be made regarding which entities can control the activities of a VIE, who can receive benefits or absorb losses from the VIE and the significance of those benefits and losses to the VIE.

[0000866374-23-000058:notes:136]
As of June 30, 2023 and March 31, 2023, noncontrolling interest was $380 million and $355 million, respectively. Net income attributable to noncontrolling interest was $25 million and zero for the three-month periods ended June 30, 2023 and July 1, 2022, respectively. As a result of the Nextracker's February 13, 2023 initial public offering ("IPO"), the noncontrolling interest previously determined to be redeemable prior to the IPO did not exist as of June 30, 2023. Net income attributable to redeemable noncontrolling interest was zero and $6 million for the three-month periods ended June 30, 2023 and July 1, 2022, respectively.

[0000866374-23-000058:notes:137]
The carrying amounts and classification of the VIE's external assets and liabilities as of June 30, 2023 and March 31, 2023 are included in the condensed consolidated balance sheets as follows:

[0000866374-23-000058:notes:138]
|  | As of June 30, 2023 |  | As of March 31, 2023 |
|  | (In millions)(Unaudited) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash | $ | 355 |  |  | $ | 130 |  |
| Accounts receivable, net | 223 |  |  | 271 |  |
| Contract assets | 320 |  |  | 298 |  |
| Inventories | 137 |  |  | 138 |  |
| Other current assets | 82 |  |  | 35 |  |
| Total current assets | 1,117 |  |  | 872 |  |
| Property and equipment, net | 7 |  |  | 7 |  |
| Goodwill | 265 |  |  | 265 |  |
| Other intangible assets, net | 1 |  |  | 1 |  |
| Other assets | 267 |  |  | 275 |  |
| Total assets | $ | 1,657 |  |  | $ | 1,420 |  |
| Liabilities |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 293 |  |  | $ | 211 |  |
| Accrued expenses | 57 |  |  | 60 |  |
| Deferred revenue | 251 |  |  | 176 |  |
| Other current liabilities | 53 |  |  | 49 |  |
| Total current liabilities | 654 |  |  | 496 |  |
| Long-term debt | 147 |  |  | 147 |  |
| Other liabilities | 277 |  |  | 280 |  |
| Total liabilities | $ | 1,078 |  |  | $ | 923 |  |


## us-gaap:SubsequentEventsTextBlock

[0000866374-23-000058:notes:139]
SUBSEQUENT EVENTSOn July 3, 2023, the Company's subsidiary Nextracker completed a follow-on offering to its IPO, which was completed on February 13, 2023, and issued 15,631,562 shares of Class A common stock and received net proceeds of $551 million. The entire net proceeds were used by Nextracker to acquire 14,025,000 Nextracker LLC common units from Yuma, Inc., the Company’s indirect wholly-owned subsidiary, and 1,606,562 Nextracker LLC common units from TPG Rise Flash, L.P., an affiliate of the global alternative asset management firm TPG. As a result of the repurchase of Nextracker LLC common units by Nextracker, 15,631,562 shares of Nextracker Class B common stock were cancelled. Subsequent to the follow-on offering, Flex owned 74,432,619 shares of Class B common stock, representing 51.5% of the total outstanding shares of Nextracker common stock and, accordingly, still controls Nextracker. The Company received approximately $495 million from the follow-on offering, after distribution of net proceeds to TPG and expenses.
