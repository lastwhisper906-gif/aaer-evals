# FLEX note change history — 0000866374-23-000007 → 0000866374-23-000058


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-07-31):
[0000866374-23-000058:note_history:1]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $86 million based on the exchange rate as of June 30, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $13 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $54 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.
  (was, 2023-01-27, similarity 0.9473):
[0000866374-23-000007:note_history:1]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 374 million Brazilian reals (approximately USD $71 million based on the exchange rate as of December 31, 2022). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $12 million). The Company successfully defeated another three of the assessments in September 2022 (totaling approximately 229 million Brazilian reals or USD $43 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 34 million Brazilian reals (approximately USD $6 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

- changed (2023-07-31):
[0000866374-23-000058:note_history:2]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $221 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.
  (was, 2023-01-27, similarity 0.622):
[0000866374-23-000007:note_history:2]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2019.

- removed (2023-07-31):
[0000866374-23-000007:note_history:3]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

- removed (2023-07-31):
[0000866374-23-000007:note_history:4]
From time to time, the Company enters into intellectual property licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

- removed (2023-07-31):
[0000866374-23-000007:note_history:5]
The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-07-31):
[0000866374-23-000058:note_history:6]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of June 30, 2023, Flex's three operating and reportable segments were as follows:
  (was, 2023-01-27, similarity 0.634):
[0000866374-23-000007:note_history:6]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers advanced manufacturing solutions and operates one of the most trusted global supply chains, supporting the entire product lifecycle with fulfillment, after-market, and circular economy solutions for diverse industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. Flex's three operating and reportable segments are:

- changed (2023-07-31):
[0000866374-23-000058:note_history:7]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure
  (was, 2023-01-27, similarity 0.996):
[0000866374-23-000007:note_history:7]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure;

- changed (2023-07-31):
[0000866374-23-000058:note_history:8]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio
  (was, 2023-01-27, similarity 0.9727):
[0000866374-23-000007:note_history:8]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio; and

- changed (2023-07-31):
[0000866374-23-000058:note_history:9]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies
  (was, 2023-01-27, similarity 0.9956):
[0000866374-23-000007:note_history:9]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies;

- changed (2023-07-31):
[0000866374-23-000058:note_history:10]
◦Health Solutions, including medical devices, medical equipment and drug delivery
  (was, 2023-01-27, similarity 0.9701):
[0000866374-23-000007:note_history:10]
◦Health Solutions, including medical devices, medical equipment and drug delivery; and

- changed (2023-07-31):
[0000866374-23-000058:note_history:11]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers). The Company also provides intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world.
  (was, 2023-01-27, similarity 0.8846):
[0000866374-23-000007:note_history:11]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers).

- added (2023-07-31):
[0000866374-23-000058:note_history:12]
Basis of Presentation and Principles of Consolidation

- changed (2023-07-31):
[0000866374-23-000058:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.
  (was, 2023-01-27, similarity 0.9842):
[0000866374-23-000007:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2022 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

- added (2023-07-31):
[0000866374-23-000058:note_history:14]
The first quarters for fiscal years 2024 and 2023 ended on June 30, 2023, which is comprised of 91 days in the period, and July 1, 2022, which is comprised of 92 days, respectively.

- added (2023-07-31):
[0000866374-23-000058:note_history:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest.  A controlling financial interest may also exist in variable interest entities (“VIEs”), through governance provisions and arrangements to provide services to VIEs.

- added (2023-07-31):
[0000866374-23-000058:note_history:16]
The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The condensed consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of June 30, 2023, we presented noncontrolling interest as permanent equity in the condensed balance sheets, reflecting the equity held by other parties. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the condensed consolidated statements of operations.

- changed (2023-07-31):
[0000866374-23-000058:note_history:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2023-01-27, similarity 0.9872):
[0000866374-23-000007:note_history:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic and geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the COVID-19 pandemic and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- changed (2023-07-31):
[0000866374-23-000058:note_history:18]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company adopted the guidance retrospectively during the first quarter of fiscal year 2024, including a rollforward of changes in those obligations, with immaterial impacts on its condensed consolidated financial statements.
  (was, 2023-01-27, similarity 0.8463):
[0000866374-23-000007:note_history:18]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the first quarter of fiscal year 2024.

- added (2023-07-31):
[0000866374-23-000058:note_history:19]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due date. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. We have no economic interest in a supplier’s decision to participate in the supplier finance programs.

- added (2023-07-31):
[0000866374-23-000058:note_history:20]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The

- added (2023-07-31):
[0000866374-23-000058:note_history:21]
rollforward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the three-month period ended June 30, 2023 is as follows.

- added (2023-07-31):
[0000866374-23-000058:note_history:22]
|  | Three-Month Period Ended |
|  | June 30, 2023 |
|  | (In millions) |
| Confirmed obligations outstanding at the beginning of the period | $ | 275 |  |
| Invoices confirmed during the period | 272 |  |
| Confirmed invoices paid during the period | (279) |  |
| Foreign currency exchange impact | 3 |  |
| Confirmed obligations outstanding at the end of the period | $ | 271 |  |

- removed (2023-07-31):
[0000866374-23-000007:note_history:23]
Basis of Presentation

- removed (2023-07-31):
[0000866374-23-000007:note_history:24]
The Company's third quarters for fiscal years 2023 and 2022 ended on December 31 of each year, which are comprised of 92 and 91 days, respectively. The Company's first three quarters for fiscal years 2023 and 2022 both are comprised of 275 days.

- removed (2023-07-31):
[0000866374-23-000007:note_history:25]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. In all cases other than the redeemable noncontrolling interest in Nextracker, the associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of Interest and other, net, in the condensed consolidated statements of operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company

- removed (2023-07-31):
[0000866374-23-000007:note_history:26]
is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the condensed consolidated statements of operations.

- removed (2023-07-31):
[0000866374-23-000007:note_history:27]
In December 2022, the FASB issued ASU 2022-06 "Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848", which defers the sunset date of ASC 848 from December 31, 2022 to December 31, 2024. ASC 848 provides relief for companies preparing for the discontinuation of interest rates, such as LIBOR. Entities that apply ASC 848 can continue to do so until December 31, 2024. The Company adopted the guidance during the third quarter of fiscal year 2023 with an immaterial impact on its consolidated financial statements.

- removed (2023-07-31):
[0000866374-23-000007:note_history:28]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company adopted the guidance during the first quarter of fiscal year 2023 with an immaterial impact on its condensed consolidated financial statements.

- removed (2023-07-31):
[0000866374-23-000007:note_history:29]
Recently Issued Accounting Pronouncement


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-07-31):
[0000866374-23-000058:note_history:30]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 30, 2023 and March 31, 2023 are as follows:
  (was, 2023-01-27, similarity 0.9569):
[0000866374-23-000007:note_history:30]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2022 and March 31, 2022 are as follows:

- added (2023-07-31):
[0000866374-23-000058:note_history:31]
|  | Maturity Date |  | As of June 30, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 597 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 685 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 658 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 684 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan | November 2023 |  | 150 |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 294 |  |  | 284 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (20) |  |  | (21) |  |
|  |  |  | 3,595 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (151) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,444 |  |  | $ | 3,691 |  |

- added (2023-07-31):
[0000866374-23-000058:note_history:32]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. These notes represent the Company’s senior unsecured obligations and hold equal ranking with all other existing and future senior unsecured debt obligations.

- added (2023-07-31):
[0000866374-23-000058:note_history:33]
(2)During the first quarter of fiscal year 2024, the Company repaid the JPY Term Loan for approximately $241 million. In addition, the Company also settled the associated USD JPY cross currency swap for approximately $60 million.

- changed (2023-07-31):
[0000866374-23-000058:note_history:34]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.7% as of June 30, 2023 and March 31, 2023, respectively.
  (was, 2023-01-27, similarity 0.9603):
[0000866374-23-000007:note_history:34]
The weighted-average interest rate for the Company's long-term debt was 4.5% and 4.0% as of December 31, 2022 and March 31, 2022, respectively.

- changed (2023-07-31):
[0000866374-23-000058:note_history:35]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 30, 2023 are as follows:
  (was, 2023-01-27, similarity 0.9524):
[0000866374-23-000007:note_history:35]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2022 are as follows:

- changed (2023-07-31):
[0000866374-23-000058:note_history:36]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | 151 |  |
| 2025 |  | — |  |
| 2026 |  | 1,282 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,635 |  |
| Total |  | $ | 3,615 |  |
  (was, 2023-01-27, similarity 0.9194):
[0000866374-23-000007:note_history:36]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 26 |  |
| 2024 |  | 468 |  |
| 2025 |  | 250 |  |
| 2026 |  | 1,286 |  |
| 2027 |  | — |  |
| Thereafter |  | 2,005 |  |
| Total |  | $ | 4,035 |  |

- changed (2023-07-31):
[0000866374-23-000058:note_history:37]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2024.
  (was, 2023-01-27, similarity 0.963):
[0000866374-23-000007:note_history:37]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2023.

- removed (2023-07-31):
[0000866374-23-000007:note_history:38]
|  | As of December 31, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | — |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.436% | 250 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 599 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 687 |  |  | 690 |  |
| 6.000% Notes due January 2028 | 396 |  |  | — |  |
| 4.875% Notes due June 2029 | 658 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 687 |  |  | 690 |  |
| Euro Term Loans | 265 |  |  | 389 |  |
| Delayed Draw Term Loan | 150 |  |  | — |  |
| 3.600% HUF Bonds due December 2031 | 264 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (19) |  |  | (18) |  |
|  | 4,016 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (494) |  |  | (949) |  |
| Non-current portion | $ | 3,522 |  |  | $ | 3,248 |  |

- removed (2023-07-31):
[0000866374-23-000007:note_history:39]
Notes due January 2028

- removed (2023-07-31):
[0000866374-23-000007:note_history:40]
In December 2022, the Company issued $400 million of 6.000% Notes due 2028 (the “Notes”). The Company received proceeds of approximately $396 million, net of discount, from the issuance which were used, together with cash on hand, for general corporate purposes, which includes redeeming its 2023 notes on December 20, 2022 and for working capital requirements. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet of approximately $4 million of costs in conjunction with the issuance of the Notes.

- removed (2023-07-31):
[0000866374-23-000007:note_history:41]
Interest on the Notes is payable on January 15 and July 15 of each year, beginning on July 15, 2023. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.

- removed (2023-07-31):
[0000866374-23-000007:note_history:42]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant

- removed (2023-07-31):
[0000866374-23-000007:note_history:43]
limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries.

- removed (2023-07-31):
[0000866374-23-000007:note_history:44]
In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare the entire principle of Notes, together with all accrued and unpaid interest, if any, to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of December 31, 2022, the Company was in compliance with the covenants in the indenture governing the Notes.

- removed (2023-07-31):
[0000866374-23-000007:note_history:45]
Euro Term Loan due December 2023

- removed (2023-07-31):
[0000866374-23-000007:note_history:46]
In December 2022, the Company borrowed €250 million (approximately $265 million as of December 31, 2022), under a 1-year term-loan agreement. The proceeds of the term loan were used to repay outstanding debt of a €250 million Euro term loan due on December 9, 2022. Borrowings under this term loan bear interest at Euro Interbank Offered Rate (EURIBOR) rate plus 0.7% per annum, which is payable in full on the last day of each 3-month interest period. The term loan is repayable upon maturity, and the borrowings have been included as bank borrowings and current portion of long-term debt under the condensed consolidated balance sheet.

- removed (2023-07-31):
[0000866374-23-000007:note_history:47]
The 2027 Credit Facility

- removed (2023-07-31):
[0000866374-23-000007:note_history:48]
In July 2022, the Company entered into a new $2.5 billion credit agreement which matures in July 2027 (the "2027 Credit Facility") and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2027 Credit Facility replaced the previous $2.0 billion revolving credit facility, which was due to mature in January 2026.

- removed (2023-07-31):
[0000866374-23-000007:note_history:49]
Borrowings under the 2027 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of  (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the Term Secured Overnight Financing Rate (Term SOFR) rate plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.750% per annum, based on the Company’s credit ratings or (ii) Term SOFR (or (x) the “Alternative Currency Term Rate”, which is defined as, depending on the applicable currency at issue, either the Euro Interbank Offered Rate, Tokyo Interbank Offer Rate, or such other term rate per annum as designated with respect to such alternative currency or (y) the “Alternative Currency Daily Rate”, which is defined as, in the case of Sterling, the rate per annum equal to Sterling Overnight Index Average, and for any other alternative currency, such other term rate per annum as designated with respect to such alternative currency) plus the applicable margin for Term SOFR rate (or the Alternative Currency Term Rate) loans ranging between 1.125% and 1.750% per annum, based on the Company’s credit ratings, plus an adjustment for Term SOFR loans of 0.10% per annum and an adjustment for Sterling Overnight Index Average loans of 0.0326% per annum. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the last business day of March, June, September and December of each calendar year and the maturity date, (ii) in the case of borrowings at the Term SOFR rate (or the Alternative Currency Term Rate), on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month and the maturity date and (iii) in the case of borrowings at the Alternative Currency Daily Rate, on the last day of each calendar month and the maturity date. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2027 Credit Facility ranging from 0.125% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.125% to 1.750% per annum (based on the Company’s credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

- removed (2023-07-31):
[0000866374-23-000007:note_history:50]
Under the 2027 Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

- removed (2023-07-31):
[0000866374-23-000007:note_history:51]
Delayed Draw Term Loan

- removed (2023-07-31):
[0000866374-23-000007:note_history:52]
In September 2022, the Company entered into a $450 million delayed draw term loan agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. All borrowings under the delayed draw term loan will become due on the date that is 364 days after the initial borrowing. Interest is based on either (a) a Term SOFR-based formula plus a margin of 100.0 basis points to 162.5 basis points, depending on the Company’s credit ratings, or (b) a Base Rate formula plus a margin of 0.0 basis point to 62.5 basis

- removed (2023-07-31):
[0000866374-23-000007:note_history:53]
points, depending on the Company's credit ratings. On November 30, 2022, the Company borrowed $450 million under the delayed draw term loan. Of this amount, $300 million was repaid in December 2022. As of December 31, 2022, the Company had $150 million in borrowings outstanding under the delayed draw term loan agreement, which amount is due on November 29, 2023.

- removed (2023-07-31):
[0000866374-23-000007:note_history:54]
The Euro term loan, the 2027 Credit Facility, and delayed draw term loan are unsecured, and contain customary restrictions on the ability of the Company and its subsidiaries to (i) incur liens, (ii) dispose of assets and (iii) make certain acquisitions of other entities. The Euro term loan also contains a restriction on the ability of the Company and its subsidiaries to change its line of business. The 2027 Credit Facility and delayed draw term loan also contain a restriction on the ability of the Company and its subsidiaries to engage in transaction with affiliates. These covenants are subject to a number of significant exceptions and limitations. The Euro term loan, the 2027 Credit Facility, and delayed draw term loan agreement also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio. As of December 31, 2022, the Company was in compliance with the covenants under the Euro term loan, the 2027 Credit Facility, and delayed draw term loan agreement.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-07-31):
[0000866374-23-000058:note_history:55]
|  | As of June 30, 2023 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| JPY Term Loan due April 2024 | $ | — |  |  | $ | — |  |  | $ | 253 |  |  | $ | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597 |  |  | 585 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 685 |  |  | 654 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 404 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 658 |  |  | 630 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 684 |  |  | 663 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan due November 2023 | 150 |  |  | 150 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| Nextracker Term Loan due February 2028 | 150 |  |  | 146 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 294 |  |  | 215 |  |  | 284 |  |  | 196 |  |  | Level 2 |

- removed (2023-07-31):
[0000866374-23-000007:note_history:56]
|  | As of December 31, 2022 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | — |  |  | $ | — |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.436% | 250 |  |  | 250 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 599 |  |  | 590 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 687 |  |  | 650 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 396 |  |  | 397 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 658 |  |  | 621 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 687 |  |  | 644 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | 265 |  |  | 265 |  |  | 389 |  |  | 389 |  |  | Level 2 |
| Delayed Draw Term Loan | 150 |  |  | 150 |  |  | — |  |  | — |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 264 |  |  | 190 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | 79 |  |  | 79 |  |  | 84 |  |  | 84 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-07-31):
[0000866374-23-000058:note_history:57]
Bank borrowings and long-term debt as of June 30, 2023 and March 31, 2023 are as follows:
  (was, 2023-01-27, similarity 0.9383):
[0000866374-23-000007:note_history:57]
Bank borrowings and long-term debt as of December 31, 2022 and March 31, 2022 are as follows:

- added (2023-07-31):
[0000866374-23-000058:note_history:58]
|  | Maturity Date |  | As of June 30, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 597 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 685 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 658 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 684 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan | November 2023 |  | 150 |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 294 |  |  | 284 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (20) |  |  | (21) |  |
|  |  |  | 3,595 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (151) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,444 |  |  | $ | 3,691 |  |

- added (2023-07-31):
[0000866374-23-000058:note_history:59]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. These notes represent the Company’s senior unsecured obligations and hold equal ranking with all other existing and future senior unsecured debt obligations.

- added (2023-07-31):
[0000866374-23-000058:note_history:60]
(2)During the first quarter of fiscal year 2024, the Company repaid the JPY Term Loan for approximately $241 million. In addition, the Company also settled the associated USD JPY cross currency swap for approximately $60 million.

- removed (2023-07-31):
[0000866374-23-000007:note_history:61]
|  | As of December 31, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | — |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.436% | 250 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 599 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 687 |  |  | 690 |  |
| 6.000% Notes due January 2028 | 396 |  |  | — |  |
| 4.875% Notes due June 2029 | 658 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 687 |  |  | 690 |  |
| Euro Term Loans | 265 |  |  | 389 |  |
| Delayed Draw Term Loan | 150 |  |  | — |  |
| 3.600% HUF Bonds due December 2031 | 264 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (19) |  |  | (18) |  |
|  | 4,016 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (494) |  |  | (949) |  |
| Non-current portion | $ | 3,522 |  |  | $ | 3,248 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-07-31):
[0000866374-23-000058:note_history:62]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 30, 2023 are as follows:
  (was, 2023-01-27, similarity 0.9524):
[0000866374-23-000007:note_history:62]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2022 are as follows:

- changed (2023-07-31):
[0000866374-23-000058:note_history:63]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | 151 |  |
| 2025 |  | — |  |
| 2026 |  | 1,282 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,635 |  |
| Total |  | $ | 3,615 |  |
  (was, 2023-01-27, similarity 0.9194):
[0000866374-23-000007:note_history:63]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 26 |  |
| 2024 |  | 468 |  |
| 2025 |  | 250 |  |
| 2026 |  | 1,286 |  |
| 2027 |  | — |  |
| Thereafter |  | 2,005 |  |
| Total |  | $ | 4,035 |  |

- changed (2023-07-31):
[0000866374-23-000058:note_history:64]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2024.
  (was, 2023-01-27, similarity 0.963):
[0000866374-23-000007:note_history:64]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2023.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-07-31):
[0000866374-23-000058:note_history:65]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 30, 2023 and July 1, 2022, respectively.
  (was, 2023-01-27, similarity 0.6042):
[0000866374-23-000007:note_history:65]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2022 and December 31, 2021, respectively. Historical information for the first three quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.

- changed (2023-07-31):
[0000866374-23-000058:note_history:66]
|  | Three-Month Periods Ended |  |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,436 |  |  | $ | 3,779 |  |  |  |  |  |
| Over time | 165 |  |  | 212 |  |  |  |  |  |
| Total | 3,601 |  |  | 3,991 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,132 |  |  | 2,790 |  |  |  |  |  |
| Over time | 159 |  |  | 179 |  |  |  |  |  |
| Total | 3,291 |  |  | 2,969 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 23 |  |  |  |  |  |
| Over time | 474 |  |  | 372 |  |  |  |  |  |
| Total | 480 |  |  | 395 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (36) |  |  | (8) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (36) |  |  | (8) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,538 |  |  | 6,584 |  |  |  |  |  |
| Over time | 798 |  |  | 763 |  |  |  |  |  |
| Total | $ | 7,336 |  |  | $ | 7,347 |  |  |  |  |  |
  (was, 2023-01-27, similarity 0.8301):
[0000866374-23-000007:note_history:66]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,812 |  |  | $ | 3,389 |  |  | $ | 11,378 |  |  | $ | 9,887 |  |
| Over time | 217 |  |  | 192 |  |  | 646 |  |  | 563 |  |
| Total | 4,029 |  |  | 3,581 |  |  | 12,024 |  |  | 10,450 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,038 |  |  | 2,528 |  |  | 8,938 |  |  | 7,243 |  |
| Over time | 187 |  |  | 183 |  |  | 555 |  |  | 515 |  |
| Total | 3,225 |  |  | 2,711 |  |  | 9,493 |  |  | 7,758 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 8 |  |  | 42 |  |  | 41 |  |  | 63 |  |
| Over time | 508 |  |  | 296 |  |  | 1,343 |  |  | 955 |  |
| Total | 516 |  |  | 338 |  |  | 1,384 |  |  | 1,018 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,844 |  |  | 5,948 |  |  | 20,325 |  |  | 17,157 |  |
| Over time | 912 |  |  | 671 |  |  | 2,544 |  |  | 2,033 |  |
| Total | $ | 7,756 |  |  | $ | 6,619 |  |  | $ | 22,869 |  |  | $ | 19,190 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-07-31):
[0000866374-23-000058:note_history:67]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract are transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.
  (was, 2023-01-27, similarity 0.9983):
[0000866374-23-000007:note_history:67]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- changed (2023-07-31):
[0000866374-23-000058:note_history:68]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the condensed consolidated balance sheet and disclosed as part of customer-related accruals in note 2.
  (was, 2023-01-27, similarity 0.8895):
[0000866374-23-000007:note_history:68]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement

- changed (2023-07-31):
[0000866374-23-000058:note_history:69]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $897 million and $885 million as of June 30, 2023 and March 31, 2023, respectively, of which $802 million and $795 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.
  (was, 2023-01-27, similarity 0.9847):
[0000866374-23-000007:note_history:69]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $813 million and $704 million as of December 31, 2022 and March 31, 2022, respectively, of which $745 million and $615 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2023-07-31):
[0000866374-23-000058:note_history:70]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 30, 2023 and July 1, 2022, respectively.
  (was, 2023-01-27, similarity 0.6042):
[0000866374-23-000007:note_history:70]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2022 and December 31, 2021, respectively. Historical information for the first three quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.

- changed (2023-07-31):
[0000866374-23-000058:note_history:71]
|  | Three-Month Periods Ended |  |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,436 |  |  | $ | 3,779 |  |  |  |  |  |
| Over time | 165 |  |  | 212 |  |  |  |  |  |
| Total | 3,601 |  |  | 3,991 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,132 |  |  | 2,790 |  |  |  |  |  |
| Over time | 159 |  |  | 179 |  |  |  |  |  |
| Total | 3,291 |  |  | 2,969 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 23 |  |  |  |  |  |
| Over time | 474 |  |  | 372 |  |  |  |  |  |
| Total | 480 |  |  | 395 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (36) |  |  | (8) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (36) |  |  | (8) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,538 |  |  | 6,584 |  |  |  |  |  |
| Over time | 798 |  |  | 763 |  |  |  |  |  |
| Total | $ | 7,336 |  |  | $ | 7,347 |  |  |  |  |  |
  (was, 2023-01-27, similarity 0.8301):
[0000866374-23-000007:note_history:71]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,812 |  |  | $ | 3,389 |  |  | $ | 11,378 |  |  | $ | 9,887 |  |
| Over time | 217 |  |  | 192 |  |  | 646 |  |  | 563 |  |
| Total | 4,029 |  |  | 3,581 |  |  | 12,024 |  |  | 10,450 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,038 |  |  | 2,528 |  |  | 8,938 |  |  | 7,243 |  |
| Over time | 187 |  |  | 183 |  |  | 555 |  |  | 515 |  |
| Total | 3,225 |  |  | 2,711 |  |  | 9,493 |  |  | 7,758 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 8 |  |  | 42 |  |  | 41 |  |  | 63 |  |
| Over time | 508 |  |  | 296 |  |  | 1,343 |  |  | 955 |  |
| Total | 516 |  |  | 338 |  |  | 1,384 |  |  | 1,018 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (14) |  |  | (11) |  |  | (32) |  |  | (36) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,844 |  |  | 5,948 |  |  | 20,325 |  |  | 17,157 |  |
| Over time | 912 |  |  | 671 |  |  | 2,544 |  |  | 2,033 |  |
| Total | $ | 7,756 |  |  | $ | 6,619 |  |  | $ | 22,869 |  |  | $ | 19,190 |  |

- removed (2023-07-31):
[0000866374-23-000007:note_history:72]
mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the condensed consolidated balance sheet and disclosed as part of customer-related accruals in note 2.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-07-31):
[0000866374-23-000058:note_history:73]
SUBSEQUENT EVENTSOn July 3, 2023, the Company's subsidiary Nextracker completed a follow-on offering to its IPO, which was completed on February 13, 2023, and issued 15,631,562 shares of Class A common stock and received net proceeds of $551 million. The entire net proceeds were used by Nextracker to acquire 14,025,000 Nextracker LLC common units from Yuma, Inc., the Company’s indirect wholly-owned subsidiary, and 1,606,562 Nextracker LLC common units from TPG Rise Flash, L.P., an affiliate of the global alternative asset management firm TPG. As a result of the repurchase of Nextracker LLC common units by Nextracker, 15,631,562 shares of Nextracker Class B common stock were cancelled. Subsequent to the follow-on offering, Flex owned 74,432,619 shares of Class B common stock, representing 51.5% of the total outstanding shares of Nextracker common stock and, accordingly, still controls Nextracker. The Company received approximately $495 million from the follow-on offering, after distribution of net proceeds to TPG and expenses.

- removed (2023-07-31):
[0000866374-23-000007:note_history:74]
SUBSEQUENT EVENTS On January 13, 2023, the Company announced that its subsidiary, Nextracker Inc. ("Nextracker"), publicly filed a registration statement on Form S-1 with the U.S. Securities and Exchange Commission ("SEC") relating to a proposed initial public offering of shares of Nextracker's Class A common stock. The initial public offering and its timing are subject to market and other conditions and the SEC’s review process, and there can be no assurance that we will proceed with such offering or any alternative transaction.
