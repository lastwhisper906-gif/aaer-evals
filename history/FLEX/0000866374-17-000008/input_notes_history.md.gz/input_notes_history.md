# FLEX note change history — 0000866374-17-000002 → 0000866374-17-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2017-08-01):
[0000866374-17-000002:note_history:1]
COMMITMENTS AND CONTINGENCIES

- removed (2017-08-01):
[0000866374-17-000002:note_history:2]
Litigation and other legal matters

- removed (2017-08-01):
[0000866374-17-000002:note_history:3]
One of the Company's Brazilian subsidiaries has received several related assessments for certain sales and import taxes. The first two tax assessments were received in fiscal year 2014 and fiscal year 2016 relating to calendar year 2010 for an alleged total amount of 109 million Brazilian reals (approximately USD $34 million based on the exchange rate as of December 31, 2016). These two assessments are in various stages of the review process at the administrative level. During the third quarter of fiscal year 2017, the same Brazilian subsidiary received a third assessment related to calendar year 2011 taxes of an additional 181 million Brazilian reals (approximately USD $56 million based on the exchange rate as of December 31, 2016). The Company plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company is unable to determine the likelihood of an unfavorable outcome of these assessments against its Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for these assessments or any future assessments that are reasonably possible. The Company does not expect final judicial determination on any of these claims for several years.

- removed (2017-08-01):
[0000866374-17-000002:note_history:4]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately USD $100 million related to income and social contribution taxes, interest and penalties. During the first quarter of fiscal year 2017, the Company received a final favorable judgment in the judicial process reversing the assessment and the case is now closed. As the Company had previously determined there was no legal basis for the assessment, no adjustment was required to be recorded during fiscal year 2017.

- removed (2017-08-01):
[0000866374-17-000002:note_history:5]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-08-01):
[0000866374-17-000008:note_history:6]
Flex Ltd., ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and industrial products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

- added (2017-08-01):
[0000866374-17-000008:note_history:7]
| • | Communications & Enterprise Compute ("CEC"), which includes telecom business of radio access base stations, remote radio heads, and small cells for wireless infrastructure; networking business which includes optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions; |

- added (2017-08-01):
[0000866374-17-000008:note_history:8]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion, and mobile devices; and including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG is expanding its business relationships to include supply chain optimization for non-electronics products such as footwear and clothing; |

- added (2017-08-01):
[0000866374-17-000008:note_history:9]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy and metering, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation and kiosks, and lighting; and |

- added (2017-08-01):
[0000866374-17-000008:note_history:10]
| • | High Reliability Solutions ("HRS"), which is comprised of medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military. |

- changed (2017-08-01):
[0000866374-17-000008:note_history:11]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2017 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018.
  (was, 2017-01-27, similarity 0.9721):
[0000866374-17-000002:note_history:11]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2016 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and nine-month periods ended December 31, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017.

- added (2017-08-01):
[0000866374-17-000008:note_history:12]
The first quarters for fiscal year 2018 and fiscal year 2017 ended on June 30, 2017, which is comprised of 91 days in the period, and July 1, 2016, which is comprised of 92 days in the period, respectively.

- changed (2017-08-01):
[0000866374-17-000008:note_history:13]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has a voting percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.
  (was, 2017-01-27, similarity 0.9822):
[0000866374-17-000002:note_history:13]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has an ownership percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- added (2017-08-01):
[0000866374-17-000008:note_history:14]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.

- changed (2017-08-01):
[0000866374-17-000008:note_history:15]
In October 2016, the FASB issued new guidance intended to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early adoption permitted in the first interim period of fiscal year 2018. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.
  (was, 2017-01-27, similarity 0.7792):
[0000866374-17-000002:note_history:15]
In October 2016, the FASB issued new guidance intended to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early adoption permitted in the first interim period of fiscal year 2018. The Company intends to early adopt the new guidance starting in the first quarter of fiscal year 2018, with an expected immaterial impact on its consolidated financial statements.

- added (2017-08-01):
[0000866374-17-000008:note_history:16]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. The guidance is effective for the Company beginning in the first quarter of fiscal year 2019.

- added (2017-08-01):
[0000866374-17-000008:note_history:17]
The Company is in process of implementation activities in accordance with the planned effective date. These activities are focused on the review of significant customer contracts, identification and development of additional systems capabilities to enable the Company to make reasonable estimates of revenue as products are manufactured, and the design and implementation of relevant internal controls. The Company has determined that the new standard will change the timing of revenue recognition for a significant portion of its business. Under the new standard, revenue for a significant majority of electronics manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery). This change will also have material impacts to the Company’s balance sheet, primarily related to a reduction in finished goods and work-in-process inventories and a corresponding increase in contract assets for unbilled receivables.

- added (2017-08-01):
[0000866374-17-000008:note_history:18]
The new guidance allows for two transition methods in application - (i) retrospective to each prior reporting period presented, or (ii) prospective with the cumulative effect of adoption recognized on April 1, 2018, the first day of the Company's fiscal year 2019. The Company has not yet concluded upon its selection of the transition method.

- removed (2017-08-01):
[0000866374-17-000002:note_history:19]
Flex Ltd., formerly Flextronics International Ltd., ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from Sketch-to-Scaletm; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of its medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electronics, connectivity, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes its mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables the Company's OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

- removed (2017-08-01):
[0000866374-17-000002:note_history:20]
The first quarters for fiscal year 2017 and fiscal year 2016 ended on July 1, 2016, which is comprised of 92 days in the period, and June 26, 2015, which is comprised of 87 days in the period, respectively. The second quarters for fiscal year 2017 and fiscal year 2016 ended on September 30, 2016 and September 25, 2015, which are comprised of 91 days in both periods, respectively. The Company's third quarters end on December 31 of each year, which are comprised of 92 days and 97 days for fiscal years 2017 and 2016, respectively.

- removed (2017-08-01):
[0000866374-17-000002:note_history:21]
In March 2016, the Financial Accounting Standards Board ("FASB") issued new guidance intended to reduce the cost and complexity of the accounting for share-based payments. The new guidance simplifies various aspects of the accounting for share-based payments including income tax effects, withholding requirements and forfeitures. The Company elected to early adopt this new guidance beginning in the first quarter of fiscal year 2017. The guidance eliminates additional paid in capital ("APIC") pools and requires companies to recognize all excess tax benefits and tax deficiencies in the income statement when the awards vest or are settled. It also addresses the presentation of excess tax benefits and employee taxes paid on the statement of cash flows. Prior to adoption, the Company elected to not deduct tax benefits for stock-based compensation awards on its tax returns, and accordingly, did not have any excess tax benefits or tax deficiencies upon adoption. The Company therefore determined that adoption of the new guidance had no impact on the condensed consolidated statement of operations and the condensed consolidated statement of cash flows. Further, the new guidance eliminates the requirement to estimate forfeitures and reduce stock compensation expense during the vesting period. Instead, companies can elect to account for actual forfeitures as they occur and record any previously unrecognized compensation expense for estimated forfeitures up to the period of adoption as a retrospective adjustment to beginning retained earnings. The Company has made the election to account for actual forfeitures as they occur starting in fiscal year 2017. After assessment, it was determined that the cumulative effect adjustment required under the new guidance was immaterial and therefore the Company did not record a retrospective adjustment. The Company finally determined that the adoption of this guidance did not have a significant impact on the consolidated financial position, results of operations and cash flows of the Company.

- removed (2017-08-01):
[0000866374-17-000002:note_history:22]
In January 2017, the FASB issued new guidance that changes the definition of a business to assist entities with evaluating when a set of transferred assets and activities is a business. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early application permitted. The guidance may result in more asset acquisitions being accounted for as purchases of assets in lieu of business combinations. The Company intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2019.

- removed (2017-08-01):
[0000866374-17-000002:note_history:23]
In October 2016, the FASB issued new guidance to amend the consolidation guidance on how a reporting entity that is the single decision maker of a variable interest entity ("VIE") should treat indirect interests in the entity held through related parties that are under common control with the reporting entity when determining whether it is the primary beneficiary of that VIE. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2018.

- removed (2017-08-01):
[0000866374-17-000002:note_history:24]
In August 2016, the FASB issued new guidance intended to address specific cash flow issues with the objective of reducing the existing diversity in practice. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early application permitted. The Company is currently assessing the impact of this update and the timing of adoption.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-08-01):
[0000866374-17-000008:note_history:25]
|  | As of June 30, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 502,500 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,078 |  |  | 595,979 |  |
| Other | 182,046 |  |  | 169,671 |  |
| Debt issuance costs | (16,092 | ) |  | (16,007 | ) |
| Total | $ | 2,964,532 |  |  | $ | 2,952,143 |  |

- changed (2017-08-01):
[0000866374-17-000008:note_history:26]
The weighted-average interest rates for the Company’s long-term debt were 3.3% and 3.5% as of June 30, 2017 and March 31, 2017.
  (was, 2017-01-27, similarity 0.9231):
[0000866374-17-000002:note_history:26]
The weighted-average interest rates for the Company’s long-term debt were 3.5% as of December 31, 2016 and March 31, 2016.

- added (2017-08-01):
[0000866374-17-000008:note_history:27]
On June 30, 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature on March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and of approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualify as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the terms of the 2022 Credit Facility.

- added (2017-08-01):
[0000866374-17-000008:note_history:28]
Borrowings under the 2022 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate that would be calculated as of each day in respect of a proposed LIBOR loan with a one-month interest period, plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 1.875% per annum, based on the Company’s credit ratings.

- changed (2017-08-01):
[0000866374-17-000008:note_history:29]
The 2022 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of June 30, 2017, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.
  (was, 2017-01-27, similarity 0.6041):
[0000866374-17-000002:note_history:29]
This term loan is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term; provided that the requirement to maintain the minimum interest coverage ratio may be suspended in certain circumstances. As of December 31, 2016, the Company was in compliance with the covenants under this term loan agreement.

- added (2017-08-01):
[0000866374-17-000008:note_history:30]
The Company has three tranches of Notes, the 4.625% Notes due 2020, the 5.000% Notes due 2023 and the 4.75% Notes due 2025. These Notes are senior unsecured obligations, and prior to June 30, 2017, were guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). Upon the termination of the $2.1 billion credit facility, all guarantor subsidiaries were released from their guarantees under each indenture for each Note. As a result, the Company will no longer be providing supplemental guarantor and non-guarantor condensed consolidating financial statements.

- changed (2017-08-01):
[0000866374-17-000008:note_history:31]
Repayment of the Company’s long term debt outstanding as of June 30, 2017 is as follows:
  (was, 2017-01-27, similarity 0.9412):
[0000866374-17-000002:note_history:31]
Repayment of the Company’s long term debt outstanding as of December 31, 2016 is as follows:

- changed (2017-08-01):
[0000866374-17-000008:note_history:32]
| (1) | Represents scheduled repayment for the remaining nine-month period ending March 31, 2018. |
  (was, 2017-01-27, similarity 0.9626):
[0000866374-17-000002:note_history:32]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2017. |

- removed (2017-08-01):
[0000866374-17-000002:note_history:33]
|  | As of December 31, 2016 |  | As of March 31, 2016 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | $ | 525,000 |  |  | $ | 547,500 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 577,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 595,879 |  |  | 595,589 |  |
| Other | 62,448 |  |  | 71,317 |  |
| Debt issuance costs | (16,487 | ) |  | (17,351 | ) |
| Total | $ | 2,866,840 |  |  | $ | 2,774,555 |  |

- removed (2017-08-01):
[0000866374-17-000002:note_history:34]
On August 30, 2013, the Company entered into a $600 million term loan agreement due August 30, 2018. On November 30, 2016, the Company entered into a new arrangement to extend the maturity date of the agreement from August 30, 2018 to November 30, 2021, and borrowed an incremental amount of $130 million under this term loan, thereby increasing the total amount under the term loan to $700 million. This loan is repayable in quarterly installments of $4.1 million, which will commence October 31, 2017 and continue through September 30, 2021, with the remaining amount due at maturity.

- removed (2017-08-01):
[0000866374-17-000002:note_history:35]
Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the prime rate in effect on each day as published in The Wall Street Journal, the federal funds rate plus 0.5% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating.

- removed (2017-08-01):
[0000866374-17-000002:note_history:36]
On January 23, 2017, the Company entered into a €100 million (approximately $105.4 million as of December 31, 2016), 5-year, unsecured, term-loan agreement due January 2, 2022.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-01):
[0000866374-17-000008:note_history:37]
The following table presents the Company’s major debts not carried at fair value:
  (was, 2017-01-27, similarity 0.9548):
[0000866374-17-000002:note_history:37]
The following table presents the Company’s debt not carried at fair value:

- added (2017-08-01):
[0000866374-17-000008:note_history:38]
|  | As of June 30, 2017 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 526,370 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 699,125 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 502,500 |  |  | 503,405 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 546,820 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,078 |  |  | 639,876 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 55,977 |  |  | 55,977 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 114,093 |  |  | 114,093 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,968,648 |  |  | $ | 3,085,666 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |

- changed (2017-08-01):
[0000866374-17-000008:note_history:39]
(1)    On June 30, 2017, the Company entered into a new arrangement and extended the maturity date of the agreement from March 31, 2019 to June 30, 2022. Refer to note 6 for further details of the arrangement.
  (was, 2017-01-27, similarity 0.9167):
[0000866374-17-000002:note_history:39]
(1)    On November 30, 2016, the Company entered into a new arrangement to extend the maturity date of the agreement from August 30, 2018 to November 30, 2021. Refer to note 5 for further details of the arrangement.

- removed (2017-08-01):
[0000866374-17-000002:note_history:40]
|  | As of December 31, 2016 |  | As of March 31, 2016 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | 525,000 |  |  | 524,675 |  |  | 547,500 |  |  | 542,709 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 525,740 |  |  | 500,000 |  |  | 524,735 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 (1) | 700,000 |  |  | 696,941 |  |  | 577,500 |  |  | 573,533 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 532,810 |  |  | 500,000 |  |  | 507,500 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,879 |  |  | 639,288 |  |  | 595,589 |  |  | 604,926 |  |  | Level 1 |
| Total | $ | 2,820,879 |  |  | $ | 2,919,454 |  |  | $ | 2,720,589 |  |  | $ | 2,753,403 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-08-01):
[0000866374-17-000008:note_history:41]
|  | As of June 30, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 502,500 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,078 |  |  | 595,979 |  |
| Other | 182,046 |  |  | 169,671 |  |
| Debt issuance costs | (16,092 | ) |  | (16,007 | ) |
| Total | $ | 2,964,532 |  |  | $ | 2,952,143 |  |

- removed (2017-08-01):
[0000866374-17-000002:note_history:42]
|  | As of December 31, 2016 |  | As of March 31, 2016 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | $ | 525,000 |  |  | $ | 547,500 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 577,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 595,879 |  |  | 595,589 |  |
| Other | 62,448 |  |  | 71,317 |  |
| Debt issuance costs | (16,487 | ) |  | (17,351 | ) |
| Total | $ | 2,866,840 |  |  | $ | 2,774,555 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-01):
[0000866374-17-000008:note_history:43]
Repayment of the Company’s long term debt outstanding as of June 30, 2017 is as follows:
  (was, 2017-01-27, similarity 0.9412):
[0000866374-17-000002:note_history:43]
Repayment of the Company’s long term debt outstanding as of December 31, 2016 is as follows:

- changed (2017-08-01):
[0000866374-17-000008:note_history:44]
| (1) | Represents scheduled repayment for the remaining nine-month period ending March 31, 2018. |
  (was, 2017-01-27, similarity 0.9626):
[0000866374-17-000002:note_history:44]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2017. |
