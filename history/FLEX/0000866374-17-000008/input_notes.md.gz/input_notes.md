# FLEX notes — 0000866374-17-000008


## flex:InterestAndOtherNetTextBlock

[0000866374-17-000008:notes:1]
[same as prior period, unchanged from 0000866374-17-000002:notes:1]

[0000866374-17-000008:notes:2]
During the three-month periods ended June 30, 2017 and July 1, 2016, the Company recognized interest expense of $29.0 million and $26.9 million, respectively, on its debt obligations outstanding during the period.


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0000866374-17-000008:notes:3]
[same as prior period, unchanged from 0000866374-17-000002:notes:3]

[0000866374-17-000008:notes:4]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
|  | (In thousands) |
| Beginning balance | $ | 506,522 |  |  | $ | 501,097 |  |
| Transfers of receivables | 847,004 |  |  | 762,184 |  |
| Collections | (806,034 | ) |  | (802,947 | ) |
| Ending balance | $ | 547,492 |  |  | $ | 460,334 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-17-000008:notes:5]
[same as prior period, unchanged from 0000866374-17-000002:notes:32]

[0000866374-17-000008:notes:6]
[same as prior period, unchanged from 0000866374-17-000002:notes:33]

[0000866374-17-000008:notes:7]
In April 2017, the Company completed its acquisition of AGM, which expanded its capabilities in the automotive market, and is included within the HRS segment. The Company paid $213.7 million, net of cash acquired.

[0000866374-17-000008:notes:8]
A summary of the allocation of the total purchase consideration is presented as follows (in thousands):

[0000866374-17-000008:notes:9]
|  | Purchase Consideration |  | Net Tangible Assets Acquired |  | Purchased Intangible Assets |  | Goodwill |
| AGM | $ | 213,718 |  |  | $ | 69,091 |  |  | $ | 108,000 |  |  | $ | 36,627 |  |

[0000866374-17-000008:notes:10]
The Company is in the process of finalizing its valuation of the fair value of the assets and liabilities acquired from AGM. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisition. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the respective measurement periods.

[0000866374-17-000008:notes:11]
The results of operations of the AGM acquisition were included in the Company’s condensed consolidated financial results beginning on the date of acquisition, and the total amount of net income and revenue were immaterial to the Company's condensed consolidated financial results for the three-month period ended June 30, 2017. Pro-forma results of operations have not been presented because the effects were not material to the Company’s condensed consolidated financial results for all periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-17-000008:notes:12]
[same as prior period, unchanged from 0000866374-17-000002:notes:45]

[0000866374-17-000008:notes:13]
[same as prior period, unchanged from 0000866374-17-000002:notes:46]

[0000866374-17-000008:notes:14]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |  | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |
| Other comprehensive gain before reclassifications | 3,020 |  |  | 10,836 |  |  | 13,856 |  |  | 1,493 |  |  | 10,086 |  |  | 11,579 |  |
| Net gains reclassified from accumulated other comprehensive loss | (5,189 | ) |  | — |  |  | (5,189 | ) |  | (145 | ) |  | (225 | ) |  | (370 | ) |
| Net current-period other comprehensive gain (loss) | (2,169 | ) |  | 10,836 |  |  | 8,667 |  |  | 1,348 |  |  | 9,861 |  |  | 11,209 |  |
| Ending balance | $ | (34,595 | ) |  | $ | (84,881 | ) |  | $ | (119,476 | ) |  | $ | (40,174 | ) |  | $ | (84,532 | ) |  | $ | (124,706 | ) |

[0000866374-17-000008:notes:15]
Substantially all unrealized gains relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended June 30, 2017 are expected to be recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:ConsolidationPolicyTextBlock

[0000866374-17-000008:notes:16]
[same as prior period, unchanged from 0000866374-17-000002:notes:51]

[0000866374-17-000008:notes:17]
Flex Ltd., ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and industrial products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

[0000866374-17-000008:notes:18]
| • | Communications & Enterprise Compute ("CEC"), which includes telecom business of radio access base stations, remote radio heads, and small cells for wireless infrastructure; networking business which includes optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions; |

[0000866374-17-000008:notes:19]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion, and mobile devices; and including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG is expanding its business relationships to include supply chain optimization for non-electronics products such as footwear and clothing; |

[0000866374-17-000008:notes:20]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy and metering, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation and kiosks, and lighting; and |

[0000866374-17-000008:notes:21]
| • | High Reliability Solutions ("HRS"), which is comprised of medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military. |

[0000866374-17-000008:notes:22]
[same as prior period, unchanged from 0000866374-17-000002:notes:53]


## us-gaap:DebtDisclosureTextBlock

[0000866374-17-000008:notes:23]
BANK BORROWINGS AND LONG TERM DEBT

[0000866374-17-000008:notes:24]
Bank borrowings and long-term debt are as follows:

[0000866374-17-000008:notes:25]
|  | As of June 30, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 502,500 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,078 |  |  | 595,979 |  |
| Other | 182,046 |  |  | 169,671 |  |
| Debt issuance costs | (16,092 | ) |  | (16,007 | ) |
| Total | $ | 2,964,532 |  |  | $ | 2,952,143 |  |

[0000866374-17-000008:notes:26]
The weighted-average interest rates for the Company’s long-term debt were 3.3% and 3.5% as of June 30, 2017 and March 31, 2017.

[0000866374-17-000008:notes:27]
On June 30, 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature on March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and of approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualify as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the terms of the 2022 Credit Facility.

[0000866374-17-000008:notes:28]
Borrowings under the 2022 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate that would be calculated as of each day in respect of a proposed LIBOR loan with a one-month interest period, plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 1.875% per annum, based on the Company’s credit ratings.

[0000866374-17-000008:notes:29]
The 2022 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of June 30, 2017, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.

[0000866374-17-000008:notes:30]
The Company has three tranches of Notes, the 4.625% Notes due 2020, the 5.000% Notes due 2023 and the 4.75% Notes due 2025. These Notes are senior unsecured obligations, and prior to June 30, 2017, were guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). Upon the termination of the $2.1 billion credit facility, all guarantor subsidiaries were released from their guarantees under each indenture for each Note. As a result, the Company will no longer be providing supplemental guarantor and non-guarantor condensed consolidating financial statements.

[0000866374-17-000008:notes:31]
Repayment of the Company’s long term debt outstanding as of June 30, 2017 is as follows:

[0000866374-17-000008:notes:32]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 (1) | $ | 37,373 |  |
| 2019 | 46,670 |  |
| 2020 | 542,801 |  |
| 2021 | 111,917 |  |
| 2022 | 803,406 |  |
| Thereafter | 1,438,457 |  |
| Total | $ | 2,980,624 |  |

[0000866374-17-000008:notes:33]
_________________________________________________________

[0000866374-17-000008:notes:34]
| (1) | Represents scheduled repayment for the remaining nine-month period ending March 31, 2018. |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-17-000008:notes:35]
[same as prior period, unchanged from 0000866374-17-000002:notes:66]

[0000866374-17-000008:notes:36]
[same as prior period, unchanged from 0000866374-17-000002:notes:67]

[0000866374-17-000008:notes:37]
The Company enters into forward contracts and foreign currency swap contracts primarily to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions. The Company hedges committed exposures and does not engage in speculative transactions. As of June 30, 2017, the aggregate notional amount of the Company’s outstanding foreign currency contracts was $4.8 billion as summarized below:

[0000866374-17-000008:notes:38]
|  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |
| CNY | 1,311,000 |  |  | — |  |  | $ | 192,834 |  |  | $ | — |  |
| EUR | 26,612 |  |  | 102,211 |  |  | 30,241 |  |  | 116,798 |  |
| HUF | 18,375,520 |  |  | — |  |  | 67,488 |  |  | — |  |
| INR | 1,577,358 |  |  | — |  |  | 23,600 |  |  | — |  |
| MXN | 2,353,300 |  |  | — |  |  | 131,348 |  |  | — |  |
| MYR | 167,400 |  |  | 39,000 |  |  | 39,058 |  |  | 9,100 |  |
| RON | 103,510 |  |  | — |  |  | 25,844 |  |  | — |  |
| SGD | 29,800 |  |  | — |  |  | 21,554 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 45,783 |  |  | 5,396 |  |
|  |  |  |  |  |  |  | 577,750 |  |  | 131,294 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |
| BRL | — |  |  | 415,000 |  |  | — |  |  | 125,537 |  |
| CAD | 19,008 |  |  | 33,755 |  |  | 14,551 |  |  | 25,840 |  |
| CHF | 8,450 |  |  | 31,056 |  |  | 8,800 |  |  | 32,343 |  |
| CNY | 1,533,318 |  |  | — |  |  | 224,000 |  |  | — |  |
| DKK | 180,600 |  |  | 158,800 |  |  | 27,596 |  |  | 24,265 |  |
| EUR | 1,024,136 |  |  | 1,383,812 |  |  | 1,162,529 |  |  | 1,570,311 |  |
| GBP | 35,834 |  |  | 65,131 |  |  | 46,370 |  |  | 84,278 |  |
| HUF | 20,442,171 |  |  | 19,619,207 |  |  | 75,078 |  |  | 72,055 |  |
| INR | 3,960,000 |  |  | 142,487 |  |  | 61,348 |  |  | 2,200 |  |
| MXN | 2,241,024 |  |  | 547,954 |  |  | 125,082 |  |  | 30,584 |  |
| MYR | 354,828 |  |  | 81,400 |  |  | 82,790 |  |  | 18,993 |  |
| PLN | 137,723 |  |  | 78,591 |  |  | 36,938 |  |  | 21,078 |  |
| SEK | 157,797 |  |  | 214,117 |  |  | 18,333 |  |  | 24,978 |  |
| Other | N/A |  |  | N/A |  |  | 82,219 |  |  | 57,243 |  |
|  |  |  |  |  |  |  | 1,965,634 |  |  | 2,089,705 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  | $ | 2,543,384 |  |  | $ | 2,220,999 |  |

[0000866374-17-000008:notes:39]
As of June 30, 2017, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of June 30, 2017 and March 31, 2017, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred gains were $11.2 million as of June 30, 2017, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0000866374-17-000008:notes:40]
[same as prior period, unchanged from 0000866374-17-000002:notes:71]

[0000866374-17-000008:notes:41]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | June 30, 2017 |  | March 31, 2017 |  | Balance SheetLocation |  | June 30, 2017 |  | March 31, 2017 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 11,411 |  |  | $ | 11,936 |  |  | Other current liabilities |  | $ | 2,624 |  |  | $ | 1,814 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 10,668 |  |  | $ | 10,086 |  |  | Other current liabilities |  | $ | 8,411 |  |  | $ | 9,928 |  |

[0000866374-17-000008:notes:42]
[same as prior period, unchanged from 0000866374-17-000002:notes:73]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-17-000008:notes:43]
[same as prior period, unchanged from 0000866374-17-000002:notes:74]

[0000866374-17-000008:notes:44]
[same as prior period, unchanged from 0000866374-17-000002:notes:75]

[0000866374-17-000008:notes:45]
[same as prior period, unchanged from 0000866374-17-000002:notes:78]

[0000866374-17-000008:notes:46]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
|  | (In thousands) |
| Cost of sales | $ | 3,319 |  |  | $ | 2,433 |  |
| Selling, general and administrative expenses | 18,477 |  |  | 21,364 |  |
| Total share-based compensation expense | $ | 21,796 |  |  | $ | 23,797 |  |

[0000866374-17-000008:notes:47]
Total unrecognized compensation expense related to share options under the 2010 Plan and other immaterial plans was $7.8 million, and will be recognized over a weighted-average remaining vesting period of 1.8 years. As of June 30, 2017, the number of options outstanding and exercisable under the 2010 Plan and other immaterial plans was 1.8 million and 0.5 million, respectively, at a weighted-average exercise price of $3.66 per share and $6.00 per share, respectively.

[0000866374-17-000008:notes:48]
During the three-month period ended June 30, 2017, the Company granted 4.8 million unvested share bonus awards under the 2010 Plan. Of this amount, approximately 4.0 million unvested share bonus awards have an average grant date price of $16.39 per share and vest over four years. Further, approximately 0.6 million of these unvested shares represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions is still pending; however, the expense for the three-month period ended June 30, 2017 is immaterial as these awards were granted on the last day of the quarter. The number of shares under the 2010 Plan, contingent on market conditions that ultimately will vest will range from zero up to a maximum of 1.2 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met. No additional share options under the immaterial plans were granted by the Company during the three-month period ended June 30, 2017.

[0000866374-17-000008:notes:49]
As of June 30, 2017, approximately 16.9 million unvested share bonus awards under the 2010 Plan and other immaterial plans were outstanding, of which vesting for a targeted amount of 2.1 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 4.2 million based on the achievement levels of the respective conditions. During the three-month period ended June 30, 2017, 1.4 million shares under the 2010 Plan vested in connection with the share bonus awards with market conditions granted in fiscal year 2015.

[0000866374-17-000008:notes:50]
As of June 30, 2017, total unrecognized compensation expense related to unvested share bonus awards under the 2010 Plan and other immaterial plans was approximately $194.7 million, and will be recognized over a weighted-average remaining vesting period of 2.9 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-17-000008:notes:51]
[same as prior period, unchanged from 0000866374-17-000002:notes:92]

[0000866374-17-000008:notes:52]
The following table reflects basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share attributable to the shareholders of Flex Ltd.:

[0000866374-17-000008:notes:53]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
|  | (In thousands, except per share amounts) |
| Net income | $ | 124,710 |  |  | $ | 105,729 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 530,268 |  |  | 544,631 |  |
| Basic earnings per share | $ | 0.24 |  |  | $ | 0.19 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 124,710 |  |  | $ | 105,729 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 530,268 |  |  | 544,631 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) | 8,365 |  |  | 6,398 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 538,633 |  |  | 551,029 |  |
| Diluted earnings per share | $ | 0.23 |  |  | $ | 0.19 |  |

[0000866374-17-000008:notes:54]
[same as prior period, unchanged from 0000866374-17-000002:notes:95]

[0000866374-17-000008:notes:55]
(1)         Options to purchase ordinary shares of 0.1 million and 1.0 million during the three-month periods ended June 30, 2017 and July 1, 2016, respectively, and share bonus awards of 0.1 million and 0.8 million for the three-month periods ended June 30, 2017 and July 1, 2016, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-17-000008:notes:56]
[same as prior period, unchanged from 0000866374-17-000002:notes:98]

[0000866374-17-000008:notes:57]
[same as prior period, unchanged from 0000866374-17-000002:notes:99]

[0000866374-17-000008:notes:58]
[same as prior period, unchanged from 0000866374-17-000002:notes:100]

[0000866374-17-000008:notes:59]
[same as prior period, unchanged from 0000866374-17-000002:notes:101]

[0000866374-17-000008:notes:60]
[same as prior period, unchanged from 0000866374-17-000002:notes:102]

[0000866374-17-000008:notes:61]
[same as prior period, unchanged from 0000866374-17-000002:notes:103]

[0000866374-17-000008:notes:62]
[same as prior period, unchanged from 0000866374-17-000002:notes:104]

[0000866374-17-000008:notes:63]
[same as prior period, unchanged from 0000866374-17-000002:notes:105]

[0000866374-17-000008:notes:64]
[same as prior period, unchanged from 0000866374-17-000002:notes:106]

[0000866374-17-000008:notes:65]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs.

[0000866374-17-000008:notes:66]
The significant inputs in the fair value measurement not supported by market activity included the Company's probability assessments of expected future revenue during the earn-out period and associated volatility, appropriately discounted considering the uncertainties associated with the obligation, and calculated in accordance with the terms of the merger agreement. Significant decreases in expected revenue during the earn-out period, or significant increases in the discount rate or volatility in isolation would result in lower fair value estimates. The interrelationship between these inputs is not considered significant.

[0000866374-17-000008:notes:67]
The following table summarizes the activities related to contingent consideration payable for historic acquisitions:

[0000866374-17-000008:notes:68]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
|  | (In thousands) |
| Beginning balance | $ | 22,426 |  |  | $ | 73,423 |  |
| Additions to accrual | — |  |  | — |  |
| Payments | — |  |  | — |  |
| Fair value adjustments | (7,000 | ) |  | 1,835 |  |
| Ending balance | $ | 15,426 |  |  | $ | 75,258 |  |

[0000866374-17-000008:notes:69]
In connection with the acquisition of NEXTracker, Inc. in fiscal year 2016, the Company has an obligation to pay additional cash consideration to the former shareholders contingent upon NEXTracker, Inc.'s achievement of revenue targets during the two years after acquisition (ending on September 30, 2017). During the quarter ended June 30, 2017, the Company adjusted the estimated remaining amount to be paid based on current revenue forecasts for the quarter ending September 29, 2017 resulting in a $7.0 million credit to the condensed consolidated statement of operations.

[0000866374-17-000008:notes:70]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not material. The interrelationship between these inputs is also insignificant. Refer to note 10 for a reconciliation of the change in the deferred purchase price receivable during the three-month periods ended June 30, 2017 and July 1, 2016.

[0000866374-17-000008:notes:71]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended June 30, 2017 and July 1, 2016.

[0000866374-17-000008:notes:72]
[same as prior period, unchanged from 0000866374-17-000002:notes:114]

[0000866374-17-000008:notes:73]
[same as prior period, unchanged from 0000866374-17-000002:notes:115]

[0000866374-17-000008:notes:74]
|  | Fair Value Measurements as of June 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 576,460 |  |  | $ | — |  |  | $ | 576,460 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 547,492 |  |  | 547,492 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 22,079 |  |  | — |  |  | 22,079 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,806 |  |  | 56,041 |  |  | — |  |  | 63,847 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (11,035 | ) |  | $ | — |  |  | $ | (11,035 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (15,426 | ) |  | (15,426 | ) |
|  | Fair Value Measurements as of March 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,066,841 |  |  | $ | — |  |  | $ | 1,066,841 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 506,522 |  |  | 506,522 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 22,022 |  |  | — |  |  | 22,022 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,062 |  |  | 52,680 |  |  | — |  |  | 59,742 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (11,742 | ) |  | $ | — |  |  | $ | (11,742 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (22,426 | ) |  | (22,426 | ) |

[0000866374-17-000008:notes:75]
[same as prior period, unchanged from 0000866374-17-000002:notes:117]

[0000866374-17-000008:notes:76]
The following table presents the Company’s major debts not carried at fair value:

[0000866374-17-000008:notes:77]
|  | As of June 30, 2017 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 526,370 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 699,125 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 502,500 |  |  | 503,405 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 546,820 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,078 |  |  | 639,876 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 55,977 |  |  | 55,977 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 114,093 |  |  | 114,093 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,968,648 |  |  | $ | 3,085,666 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |

[0000866374-17-000008:notes:78]
(1)    On June 30, 2017, the Company entered into a new arrangement and extended the maturity date of the agreement from March 31, 2019 to June 30, 2022. Refer to note 6 for further details of the arrangement.

[0000866374-17-000008:notes:79]
The Company values its Euro Term Loans due September 2020 and January 2022 based on the current market rate, and as of June 30, 2017, the carrying amounts approximates fair values.

[0000866374-17-000008:notes:80]
The Term Loans due November 2021 and June 2022, and the Notes due February 2020, February 2023 and June 2025 are valued based on broker trading prices in active markets.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000866374-17-000008:notes:81]
NONCONTROLLING INTERESTS

[0000866374-17-000008:notes:82]
During the period ended June 30, 2017, a majority owned subsidiary issued additional equity interests to certain third-party investors and received $59.0 million of proceeds, which is included in other financing activities in the condensed consolidated statement of cash flows. As a result, third-party investors now hold approximately 40% ownership of the subsidiary. The Company continues to own a majority of the subsidiary's outstanding equity and controls its board of directors. Accordingly, the consolidated financial statements include the financial position and results of operations of this subsidiary as of June 30, 2017 and March 31, 2017.

[0000866374-17-000008:notes:83]
The Company has recognized the carrying value of the noncontrolling interest as a component of total shareholders' equity. The noncontrolling interest in the operating losses of the subsidiary is immaterial for all periods presented and are classified as a component of interest and other, net, in the Company's condensed consolidated statements of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000866374-17-000008:notes:84]
Recently Adopted Accounting Pronouncement

[0000866374-17-000008:notes:85]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.

[0000866374-17-000008:notes:86]
In October 2016, the FASB issued new guidance intended to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early adoption permitted in the first interim period of fiscal year 2018. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.

[0000866374-17-000008:notes:87]
Recently Issued Accounting Pronouncements

[0000866374-17-000008:notes:88]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. The guidance is effective for the Company beginning in the first quarter of fiscal year 2019.

[0000866374-17-000008:notes:89]
The Company is in process of implementation activities in accordance with the planned effective date. These activities are focused on the review of significant customer contracts, identification and development of additional systems capabilities to enable the Company to make reasonable estimates of revenue as products are manufactured, and the design and implementation of relevant internal controls. The Company has determined that the new standard will change the timing of revenue recognition for a significant portion of its business. Under the new standard, revenue for a significant majority of electronics manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery). This change will also have material impacts to the Company’s balance sheet, primarily related to a reduction in finished goods and work-in-process inventories and a corresponding increase in contract assets for unbilled receivables.

[0000866374-17-000008:notes:90]
The new guidance allows for two transition methods in application - (i) retrospective to each prior reporting period presented, or (ii) prospective with the cumulative effect of adoption recognized on April 1, 2018, the first day of the Company's fiscal year 2019. The Company has not yet concluded upon its selection of the transition method.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-17-000008:notes:91]
[same as prior period, unchanged from 0000866374-17-000002:notes:130]

[0000866374-17-000008:notes:92]
[same as prior period, unchanged from 0000866374-17-000002:notes:131]

[0000866374-17-000008:notes:93]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2017 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018.

[0000866374-17-000008:notes:94]
The first quarters for fiscal year 2018 and fiscal year 2017 ended on June 30, 2017, which is comprised of 91 days in the period, and July 1, 2016, which is comprised of 92 days in the period, respectively.

[0000866374-17-000008:notes:95]
[same as prior period, unchanged from 0000866374-17-000002:notes:134]

[0000866374-17-000008:notes:96]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has a voting percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000866374-17-000008:notes:97]
[same as prior period, unchanged from 0000866374-17-000002:notes:138]

[0000866374-17-000008:notes:98]
|  | As of June 30, 2017 |  | As of March 31, 2017 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 373,694 |  |  | $ | (117,189 | ) |  | $ | 256,505 |  |  | $ | 260,704 |  |  | $ | (105,912 | ) |  | $ | 154,792 |  |
| Licenses and other intangibles | 278,237 |  |  | (80,785 | ) |  | 197,452 |  |  | 283,897 |  |  | (76,508 | ) |  | 207,389 |  |
| Total | $ | 651,931 |  |  | $ | (197,974 | ) |  | $ | 453,957 |  |  | $ | 544,601 |  |  | $ | (182,420 | ) |  | $ | 362,181 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000866374-17-000008:notes:99]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the three-month period ended June 30, 2017:

[0000866374-17-000008:notes:100]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year | $ | 420,935 |  |  | $ | 111,223 |  |  | $ | 337,707 |  |  | $ | 115,002 |  |  | $ | 984,867 |  |
| Additions (1) | 36,627 |  |  | — |  |  | — |  |  | — |  |  | 36,627 |  |
| Divestitures (2) | — |  |  | (3,475 | ) |  | — |  |  | — |  |  | (3,475 | ) |
| Foreign currency translation adjustments (3) | 21,050 |  |  | — |  |  | — |  |  | — |  |  | 21,050 |  |
| Balance, end of the period | $ | 478,612 |  |  | $ | 107,748 |  |  | $ | 337,707 |  |  | $ | 115,002 |  |  | $ | 1,039,069 |  |

[0000866374-17-000008:notes:101]
| (1) | The goodwill generated from the Company’s acquisition of AGM Automotive ("AGM") completed during the three-month period ended June 30, 2017 is primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired business. The goodwill is not deductible for income tax purposes. See note 12 for additional information. |

[0000866374-17-000008:notes:102]
| (2) | During the three-month period ended June 30, 2017, the Company disposed of Wink Labs Inc. ("Wink"), a business within the CTG segment, and recorded an aggregate reduction of goodwill of $3.5 million accordingly, which is included as an offset to the gain on sale recorded in other charges (income), net on the condensed consolidated statement of operations. |

[0000866374-17-000008:notes:103]
| (3) | During the three-month period ended June 30, 2017, the Company recorded $21.1 million of foreign currency translation adjustments primarily related to the goodwill associated with the acquisition of Mirror Controls International ("MCi"), as the U.S. Dollar fluctuated against the Euro. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000866374-17-000008:notes:104]
The components of inventories, net of applicable lower of cost and net realizable value write-downs, were as follows:

[0000866374-17-000008:notes:105]
|  | As of June 30, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| Raw materials | $ | 2,527,603 |  |  | $ | 2,537,623 |  |
| Work-in-progress | 471,773 |  |  | 279,493 |  |
| Finished goods | 601,799 |  |  | 579,346 |  |
|  | $ | 3,601,175 |  |  | $ | 3,396,462 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-17-000008:notes:106]
[same as prior period, unchanged from 0000866374-17-000002:notes:148]

[0000866374-17-000008:notes:107]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
|  | (In thousands) |
| Net sales: |  |  |  |
| Communications & Enterprise Compute | $ | 1,973,333 |  |  | $ | 2,195,990 |  |
| Consumer Technologies Group | 1,511,969 |  |  | 1,313,782 |  |
| Industrial & Emerging Industries | 1,390,599 |  |  | 1,289,015 |  |
| High Reliability Solutions | 1,132,371 |  |  | 1,078,026 |  |
|  | $ | 6,008,272 |  |  | $ | 5,876,813 |  |
| Segment income and reconciliation of income before tax: |  |  |  |
| Communications & Enterprise Compute | $ | 48,603 |  |  | $ | 61,899 |  |
| Consumer Technologies Group | 18,004 |  |  | 24,634 |  |
| Industrial & Emerging Industries | 55,376 |  |  | 49,977 |  |
| High Reliability Solutions | 90,212 |  |  | 88,536 |  |
| Corporate and Other | (34,278 | ) |  | (34,800 | ) |
| Total segment income | 177,917 |  |  | 190,246 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 19,901 |  |  | 21,598 |  |
| Stock-based compensation | 21,796 |  |  | 23,797 |  |
| Other charges (income), net | (36,165 | ) |  | 3,529 |  |
| Interest and other, net | 26,876 |  |  | 24,399 |  |
| Income before income taxes | $ | 145,509 |  |  | $ | 116,923 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0000866374-17-000008:notes:108]
[same as prior period, unchanged from 0000866374-17-000002:notes:153]

[0000866374-17-000008:notes:109]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 (1) | $ | 59,369 |  |
| 2019 | 72,587 |  |
| 2020 | 63,414 |  |
| 2021 | 59,227 |  |
| 2022 | 50,646 |  |
| Thereafter | 148,714 |  |
| Total amortization expense | $ | 453,957 |  |

[0000866374-17-000008:notes:110]
| (1) | Represents estimated amortization for the remaining nine-month period ending March 31, 2018. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-17-000008:notes:111]
[same as prior period, unchanged from 0000866374-17-000002:notes:156]

[0000866374-17-000008:notes:112]
[same as prior period, unchanged from 0000866374-17-000002:notes:157]

[0000866374-17-000008:notes:113]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, other charges (income), net and interest and other, net.

[0000866374-17-000008:notes:114]
[same as prior period, unchanged from 0000866374-17-000002:notes:160]

[0000866374-17-000008:notes:115]
[same as prior period, unchanged from 0000866374-17-000002:notes:161]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-17-000008:notes:116]
[same as prior period, unchanged from 0000866374-17-000002:notes:162]

[0000866374-17-000008:notes:117]
[same as prior period, unchanged from 0000866374-17-000002:notes:163]

[0000866374-17-000008:notes:118]
[same as prior period, unchanged from 0000866374-17-000002:notes:164]

[0000866374-17-000008:notes:119]
The gross carrying amounts of intangible assets are removed when fully amortized. During the three-month period ended June 30, 2017, the total value of intangible assets increased primarily as a result of the Company's initial estimated value of $108.0 million for customer related intangibles acquired with the AGM acquisition in the HRS segment, which will amortize over a weighted-average estimated useful life of 10 years. The increase was partially offset by $7.5 million for the divestiture of Wink in the CTG segment. The assigned value is subject to change as the Company completes the valuation. The estimated future annual amortization expense for intangible assets is as follows:

[0000866374-17-000008:notes:120]
[same as prior period, unchanged from 0000866374-17-000002:notes:166]

[0000866374-17-000008:notes:121]
Other current assets include approximately $547.5 million and $506.5 million as of June 30, 2017 and March 31, 2017, respectively, for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0000866374-17-000008:notes:122]
[same as prior period, unchanged from 0000866374-17-000002:notes:169]

[0000866374-17-000008:notes:123]
During the three-month period ended June 30, 2017, the Company sold Wink to an unrelated third-party venture backed company in exchange for contingent consideration fair valued at $59.0 million. This estimated consideration was based on the value of the acquirer as of the most recent third-party funding of which the Company participated. The Company recognized a non-cash gain on sale of $38.7 million, which is recorded in other charges (income), net on the condensed consolidated statement of income. The contingent consideration is expected to be settled in the fourth quarter of fiscal year 2018. As of June 30, 2017 the total investment is $69.0 million and is included in other assets on the condensed consolidated balance sheet.

[0000866374-17-000008:notes:124]
[same as prior period, unchanged from 0000866374-17-000002:notes:171]

[0000866374-17-000008:notes:125]
Other current liabilities include customer working capital advances of $200.9 million and $231.3 million, customer-related accruals of $476.2 million and $501.9 million, and deferred revenue of $305.2 million and $280.7 million as of June 30, 2017 and March 31, 2017, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-17-000008:notes:126]
[same as prior period, unchanged from 0000866374-17-000002:notes:173]

[0000866374-17-000008:notes:127]
[same as prior period, unchanged from 0000866374-17-000002:notes:174]

[0000866374-17-000008:notes:128]
[same as prior period, unchanged from 0000866374-17-000002:notes:175]

[0000866374-17-000008:notes:129]
[same as prior period, unchanged from 0000866374-17-000002:notes:176]

[0000866374-17-000008:notes:130]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month periods ended June 30, 2017 and July 1, 2016 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0000866374-17-000008:notes:131]
As of June 30, 2017, approximately $1.6 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $1.0 billion and deferred purchase price receivables of approximately $547.5 million. As of March 31, 2017, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $1.0 billion and deferred purchase price receivables of approximately $506.5 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of June 30, 2017 and March 31, 2017, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-17-000008:notes:132]
As of June 30, 2017 and March 31, 2017, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-17-000008:notes:133]
For the three-month periods ended June 30, 2017 and July 1, 2016, cash flows from sales of receivables under the ABS Programs consisted of approximately $1.5 billion and $1.4 billion, for transfers of receivables, respectively (of which approximately $67.2 million and $59.5 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0000866374-17-000008:notes:134]
[same as prior period, unchanged from 0000866374-17-000002:notes:181]

[0000866374-17-000008:notes:135]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $217.4 million and $225.2 million as of June 30, 2017 and March 31, 2017, respectively. For the three-month periods ended June 30, 2017 and July 1, 2016, total accounts receivable sold to certain third party banking institutions was approximately $229.5 million and $453.0 million, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-17-000008:notes:136]
[same as prior period, unchanged from 0000866374-17-000002:notes:183]

[0000866374-17-000008:notes:137]
During the three-month period ended June 30, 2017, the Company repurchased 4.5 million shares at an aggregate purchase price of $73.9 million and retired all of these shares.

[0000866374-17-000008:notes:138]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 24, 2016. As of June 30, 2017, shares in the aggregate amount of $211.5 million were available to be repurchased under the current plan.
