# FLEX MD&A — 0000866374-17-000008


## mdna

[0000866374-17-000008:mdna:1]
[same as prior period, unchanged from 0000866374-17-000002:mdna:1]

[0000866374-17-000008:mdna:2]
Unless otherwise specifically stated, references in this report to “Flex,” “the Company,” “we,” “us,” “our” and similar terms mean Flex Ltd., and its subsidiaries.

[0000866374-17-000008:mdna:3]
22

[0000866374-17-000008:mdna:4]
[same as prior period, unchanged from 0000866374-17-000002:mdna:3]

[0000866374-17-000008:mdna:5]
We are a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer and industrial products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through our activities in the following segments:

[0000866374-17-000008:mdna:6]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads, and small cells for wireless infrastructure; our networking business which includes optical, routing, broadcasting, and switching products for the data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions; |

[0000866374-17-000008:mdna:7]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion, and mobile devices; and including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG is expanding its business relationships to include supply chain optimization for non-electronics products such as footwear and clothing; |

[0000866374-17-000008:mdna:8]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy and metering, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation and kiosks, and lighting; and |

[0000866374-17-000008:mdna:9]
| • | High Reliability Solutions ("HRS"), which is comprised of our medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; our automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies; and our defense and aerospace businesses, focused on commercial aviation, defense and military. |

[0000866374-17-000008:mdna:10]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-17-000008:mdna:11]
[same as prior period, unchanged from 0000866374-17-000002:mdna:6]

[0000866374-17-000008:mdna:12]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we are able to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customer's supply chain solutions needs across all of the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-17-000008:mdna:13]
During the past few years, we have made significant efforts to evolve our long-term portfolio towards a higher mix of businesses which possess longer product life cycles and higher segment operating margins such as reflected in our IEI and HRS businesses. Since the beginning of fiscal year 2016, we launched several programs broadly across our portfolio of services and in some instances we deployed certain new technologies. We continue to invest in innovation and we have expanded our design and engineering relationships through our product innovation centers.

[0000866374-17-000008:mdna:14]
[same as prior period, unchanged from 0000866374-17-000002:mdna:10]

[0000866374-17-000008:mdna:15]
23

[0000866374-17-000008:mdna:16]
We are one of the world's largest providers of global supply chain solutions, with revenues of $6.0 billion for the three-month period ended June 30, 2017 and $23.9 billion in fiscal year 2017. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-17-000008:mdna:17]
|  | Three-Month Periods Ended |
| Net sales: | June 30, 2017 |  | July 1, 2016 |
|  | (In thousands) |
| China | $ | 1,744,540 |  |  | 29 | % |  | $ | 1,840,853 |  |  | 31 | % |
| Mexico | 1,040,445 |  |  | 17 | % |  | 915,345 |  |  | 16 | % |
| U.S. | 694,337 |  |  | 12 | % |  | 708,410 |  |  | 12 | % |
| Brazil | 598,051 |  |  | 10 | % |  | 371,672 |  |  | 6 | % |
| Malaysia | 504,572 |  |  | 8 | % |  | 572,763 |  |  | 10 | % |
| Other | 1,426,327 |  |  | 24 | % |  | 1,467,770 |  |  | 25 | % |
|  | $ | 6,008,272 |  |  |  |  |  | $ | 5,876,813 |  |  |  |  |

[0000866374-17-000008:mdna:18]
|  | As of |  | As of |
| Property and equipment, net: | June 30, 2017 |  | March 31, 2017 |
|  | (In thousands) |
| China | $ | 692,131 |  |  | 29 | % |  | $ | 719,972 |  |  | 31 | % |
| Mexico | 556,532 |  |  | 24 | % |  | 525,582 |  |  | 23 | % |
| U.S. | 297,109 |  |  | 13 | % |  | 290,463 |  |  | 13 | % |
| Malaysia | 166,290 |  |  | 7 | % |  | 173,410 |  |  | 7 | % |
| Hungary | 138,627 |  |  | 6 | % |  | 132,527 |  |  | 6 | % |
| Other | 495,751 |  |  | 21 | % |  | 475,372 |  |  | 20 | % |
|  | $ | 2,346,440 |  |  |  |  |  | $ | 2,317,026 |  |  |  |  |

[0000866374-17-000008:mdna:19]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and industrial campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer electronics and industrial products for leading multinational and regional customers. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-17-000008:mdna:20]
[same as prior period, unchanged from 0000866374-17-000002:mdna:15]

[0000866374-17-000008:mdna:21]
[same as prior period, unchanged from 0000866374-17-000002:mdna:16]

[0000866374-17-000008:mdna:22]
[same as prior period, unchanged from 0000866374-17-000002:mdna:18]

[0000866374-17-000008:mdna:23]
[same as prior period, unchanged from 0000866374-17-000002:mdna:19]

[0000866374-17-000008:mdna:24]
| • | our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers; |

[0000866374-17-000008:mdna:25]
[same as prior period, unchanged from 0000866374-17-000002:mdna:21]

[0000866374-17-000008:mdna:26]
[same as prior period, unchanged from 0000866374-17-000002:mdna:22]

[0000866374-17-000008:mdna:27]
[same as prior period, unchanged from 0000866374-17-000002:mdna:23]

[0000866374-17-000008:mdna:28]
24

[0000866374-17-000008:mdna:29]
[same as prior period, unchanged from 0000866374-17-000002:mdna:24]

[0000866374-17-000008:mdna:30]
[same as prior period, unchanged from 0000866374-17-000002:mdna:25]

[0000866374-17-000008:mdna:31]
[same as prior period, unchanged from 0000866374-17-000002:mdna:26]

[0000866374-17-000008:mdna:32]
[same as prior period, unchanged from 0000866374-17-000002:mdna:27]

[0000866374-17-000008:mdna:33]
[same as prior period, unchanged from 0000866374-17-000002:mdna:28]

[0000866374-17-000008:mdna:34]
[same as prior period, unchanged from 0000866374-17-000002:mdna:29]

[0000866374-17-000008:mdna:35]
[same as prior period, unchanged from 0000866374-17-000002:mdna:30]

[0000866374-17-000008:mdna:36]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2017, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0000866374-17-000008:mdna:37]
[same as prior period, unchanged from 0000866374-17-000002:mdna:32]

[0000866374-17-000008:mdna:38]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our 2017 Annual Report on Form 10-K.

[0000866374-17-000008:mdna:39]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
| Net sales | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.2 |  |  | 93.1 |  |
| Gross profit | 6.8 |  |  | 6.9 |  |
| Selling, general and administrative expenses | 4.2 |  |  | 4.1 |  |
| Intangible amortization | 0.3 |  |  | 0.4 |  |
| Interest and other, net | 0.4 |  |  | 0.4 |  |
| Other charges (income), net | (0.6 | ) |  | 0.1 |  |
| Income before income taxes | 2.5 |  |  | 1.9 |  |
| Provision for income taxes | 0.3 |  |  | 0.2 |  |
| Net income | 2.2 | % |  | 1.7 | % |

[0000866374-17-000008:mdna:40]
25

[0000866374-17-000008:mdna:41]
[same as prior period, unchanged from 0000866374-17-000002:mdna:36]

[0000866374-17-000008:mdna:42]
[same as prior period, unchanged from 0000866374-17-000002:mdna:37]

[0000866374-17-000008:mdna:43]
|  | Three-Month Periods Ended |
| Segments: | June 30, 2017 |  | July 1, 2016 |
|  | (In thousands) |
| Communications & Enterprise Compute | $ | 1,973,333 |  |  | 33 | % |  | $ | 2,195,990 |  |  | 37 | % |
| Consumer Technologies Group | 1,511,969 |  |  | 25 | % |  | 1,313,782 |  |  | 22 | % |
| Industrial & Emerging Industries | 1,390,599 |  |  | 23 | % |  | 1,289,015 |  |  | 22 | % |
| High Reliability Solutions | 1,132,371 |  |  | 19 | % |  | 1,078,026 |  |  | 18 | % |
|  | $ | 6,008,272 |  |  |  |  |  | $ | 5,876,813 |  |  |  |  |

[0000866374-17-000008:mdna:44]
Net sales during the three-month period ended June 30, 2017 totaled $6.0 billion, representing an increase of approximately $0.1 billion, or 2% from $5.9 billion during the three-month period ended July 1, 2016. The overall increase in sales was driven by increases in three of our segments while sales in our CEC segment decreased. Our CTG segment increased $198 million, primarily because of stronger sales in our connected living and mobile devices businesses, offset by a decrease in gaming. Our IEI segment increased $102 million, mainly driven by our industrial, home and lifestyle business in addition to growth in our solar energy business. Our HRS segment increased $54 million from higher sales in our automotive business offsetting declines in our medical business. These increases were partially offset by a decline in our CEC segment of $223 million, largely attributable to lower sales within our telecom and legacy server & storage business, offset by increased sales of our cloud and data center business. Net sales increased $351 million to $2.4 billion in the Americas, offset by decreases of $106 million to $2.6 billion in Asia, and $114 million to $1.0 billion in Europe.

[0000866374-17-000008:mdna:45]
Our ten largest customers, during the three-month periods ended June 30, 2017 and July 1, 2016, accounted for approximately 43% of net sales, respectively. No customer accounted for more than 10% of net sales during the three-month periods ended June 30, 2017 and July 1, 2016.

[0000866374-17-000008:mdna:46]
[same as prior period, unchanged from 0000866374-17-000002:mdna:44]

[0000866374-17-000008:mdna:47]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion or consolidation of manufacturing facilities. The flexible design of our manufacturing processes allows us to build a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-17-000008:mdna:48]
Gross profit during the three-month period ended June 30, 2017 increased $1 million to $407 million, or 6.8% of net sales, from $406 million, or 6.9% of net sales, during the three-month period ended July 1, 2016. Gross margins deteriorated 10 basis points over the same period. This decline in gross margin is the result of increased investment and costs as we ramp certain strategic relationships primarily in our CTG segment. We also saw elevated levels of costs associated with material management, labor inefficiencies and capacity refinements as we transition through a production curve with a strategic customer. The foregoing was partially offset by improved mix contributions from the expansion of our IEI and HRS business groups, which are higher margin end markets.

[0000866374-17-000008:mdna:49]
[same as prior period, unchanged from 0000866374-17-000002:mdna:49]

[0000866374-17-000008:mdna:50]
An operating segment’s performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, other charges (income), net and interest and other, net. A portion of amortization and depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-17-000008:mdna:51]
[same as prior period, unchanged from 0000866374-17-000002:mdna:51]

[0000866374-17-000008:mdna:52]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
|  | (In thousands) |
| Segment income & margin: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 48,603 |  |  | 2.5 | % |  | $ | 61,899 |  |  | 2.8 | % |
| Consumer Technologies Group | 18,004 |  |  | 1.2 | % |  | 24,634 |  |  | 1.9 | % |
| Industrial & Emerging Industries | 55,376 |  |  | 4.0 | % |  | 49,977 |  |  | 3.9 | % |
| High Reliability Solutions | 90,212 |  |  | 8.0 | % |  | 88,536 |  |  | 8.2 | % |
| Corporate and Other | (34,278 | ) |  |  |  | (34,800 | ) |  |  |
| Total segment income | 177,917 |  |  | 3.0 | % |  | 190,246 |  |  | 3.2 | % |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 19,901 |  |  |  |  | 21,598 |  |  |  |
| Stock-based compensation | 21,796 |  |  |  |  | 23,797 |  |  |  |
| Other charges (income), net | (36,165 | ) |  |  |  | 3,529 |  |  |  |
| Interest and other, net | 26,876 |  |  |  |  | 24,399 |  |  |  |
| Income before income taxes | $ | 145,509 |  |  |  |  | $ | 116,923 |  |  |  |

[0000866374-17-000008:mdna:53]
CEC segment margin decreased 30 basis points, to 2.5% for the three-month period ended June 30, 2017, from 2.8% during the three-month period ended July 1, 2016 due to lower capacity utilization causing reduced overhead absorption, coupled with modest increased investments to expand its converged enterprise and cloud capabilities.

[0000866374-17-000008:mdna:54]
CTG segment margin decreased 70 basis point to 1.2% for the three-month period ended June 30, 2017, from 1.9% during the three-month period ended July 1, 2016. The decrease in margin reflected the negative impacts from the elevated levels of production ramp costs discussed earlier in Gross Profit above.

[0000866374-17-000008:mdna:55]
IEI segment margin increased 10 basis points, to 4.0% for the three-month period ended June 30, 2017, from 3.9% during the three-month period ended July 1, 2016 primarily as revenues increased resulting in improved absorption of costs as a result of ramping multiple new programs in our industrial, home and lifestyle and energy businesses.

[0000866374-17-000008:mdna:56]
HRS segment margin decreased 20 basis points, to 8.0% for the three-month period ended June 30, 2017, from 8.2% during the three-month period ended July 1, 2016 primarily as a result of an elevated level of investments during the current quarter as part of our Sketch-to-Scaletm initiatives.

[0000866374-17-000008:mdna:57]
[same as prior period, unchanged from 0000866374-17-000002:mdna:62]

[0000866374-17-000008:mdna:58]
Selling, general and administrative expenses (“SG&A”) was $251 million, or 4.2% of net sales, during the three-month period ended June 30, 2017, increasing $11 million from $240 million, or 4.1% of net sales, during the three-month period ended July 1, 2016, primarily due to incremental costs associated with our continued expansion of our design and engineering resources and innovation system to support our increased Sketch-to-Scaletm initiatives combined with incremental costs from our acquisitions.

[0000866374-17-000008:mdna:59]
[same as prior period, unchanged from 0000866374-17-000002:mdna:66]

[0000866374-17-000008:mdna:60]
Amortization of intangible assets marginally declined during the three-month period ended June 30, 2017 to $20 million from $22 million for the three-month period ended July 1, 2016, primarily due to certain intangibles now being fully amortized.

[0000866374-17-000008:mdna:61]
[same as prior period, unchanged from 0000866374-17-000002:mdna:69]

[0000866374-17-000008:mdna:62]
Interest and other, net was $27 million during the three-month period ended June 30, 2017 compared to $24 million during the three-month period ended July 1, 2016. The increase in interest and other, net of $3 million was primarily a result of higher interest expense due to higher interest rates and higher average borrowing level.

[0000866374-17-000008:mdna:63]
Other charges (income), net

[0000866374-17-000008:mdna:64]
Other charges (income), net was $36 million of income during the three-month period ended June 30, 2017 compared to $4 million of charges during the three-month period ended July 1, 2016. The increase is primarily due to a $39 million gain recognized for the disposition of Wink. See note 2 to the condensed consolidated financial statements.

[0000866374-17-000008:mdna:65]
[same as prior period, unchanged from 0000866374-17-000002:mdna:74]

[0000866374-17-000008:mdna:66]
Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 13, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2017 for further discussion.

[0000866374-17-000008:mdna:67]
[same as prior period, unchanged from 0000866374-17-000002:mdna:76]

[0000866374-17-000008:mdna:68]
The consolidated effective tax rate was 14.3% for three-month period ended June 30, 2017, and 9.6% for the three-month period ended July 1, 2016. The effective rate varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. The effective tax rate for the three-month period ended June 30, 2017 is higher than the effective tax rate for the three-month period ended July 1, 2016 primarily due to unfavorable foreign exchange impacts on liabilities for uncertain tax positions in the three-month period ended June 30, 2017 compared with favorable foreign exchange impacts and a favorable audit settlement which resulted in the release of an accrual for uncertain tax positions during the three-month period ended July 1, 2016.

[0000866374-17-000008:mdna:69]
[same as prior period, unchanged from 0000866374-17-000002:mdna:78]

[0000866374-17-000008:mdna:70]
As of June 30, 2017, we had cash and cash equivalents of approximately $1.6 billion and bank and other borrowings of approximately $3.0 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. As of June 30, 2017, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0000866374-17-000008:mdna:71]
Cash provided by operating activities was $139 million during the three-month period ended June 30, 2017. This resulted from $125 million of net income for the period plus adjustments for $143 million net non-cash charges such as depreciation, amortization, and stock-based compensation partially offset by a $39 million gain on sale of Wink, which are included in the determination of net income. The foregoing was partially offset by a $91 million net increase in our operating assets and liabilities as we ramp into second quarter production.

[0000866374-17-000008:mdna:72]
[same as prior period, unchanged from 0000866374-17-000002:mdna:81]

[0000866374-17-000008:mdna:73]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
| Days in trade accounts receivable | 42 days |  | 39 days |
| Days in inventory | 57 days |  | 59 days |
| Days in accounts payable | 76 days |  | 71 days |
| Cash conversion cycle | 23 days |  | 27 days |

[0000866374-17-000008:mdna:74]
Days in trade accounts receivable was calculated as average accounts receivable, net of allowance for doubtful accounts, for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended June 30, 2017, days in trade accounts receivable increased by 3 days compared to the three-month period ended July 1, 2016 due to an increase in accounts receivable not offset by a proportionate increase in sales. Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $547 million and $460 million for the quarters ended June 30, 2017 and July 1, 2016, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 10 to the condensed consolidated financial statements.

[0000866374-17-000008:mdna:75]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in inventory decreased by 2 days during the three-month period ended June 30, 2017, compared to the three-month period ended July 1, 2016, primarily driven by an increase of cost of sales.

[0000866374-17-000008:mdna:76]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable increased by 5 days during the three-month period ended June 30, 2017, compared to the three-month period ended July 1, 2016, primarily due to timing of purchases driving an increase in accounts payable not offset by a proportionate increase in cost of sales.

[0000866374-17-000008:mdna:77]
Our cash conversion cycle was calculated as the sum of days of inventory and days of account receivables outstanding less days payable outstanding. Our cash conversion cycle decreased by 4 days during the three-month period ended June 30, 2017, compared to the three-month period ended July 1, 2016, due to the factors for each of the components in the calculation discussed above.

[0000866374-17-000008:mdna:78]
Cash used in investing activities amounted to $352 million during the three-month period ended June 30, 2017. We paid $214 million for the acquisition of AGM, net of cash acquired, during the quarter and invested $119 million for property and equipment to expand capabilities and capacity in support of our automotive and medical businesses. In addition, other investing activities includes payments for investments, net of cash received, in non-core businesses of $18 million.

[0000866374-17-000008:mdna:79]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the three-month period ended June 30, 2017 was $19 million compared to $121 million for the three-month period ended July 1, 2016. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-17-000008:mdna:80]
|  | Three-Month Periods Ended |
|  | June 30, 2017 |  | July 1, 2016 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 138,516 |  |  | $ | 263,932 |  |
| Purchases of property and equipment | (124,851 | ) |  | (159,103 | ) |
| Proceeds from the disposition of property and equipment | 5,476 |  |  | 15,722 |  |
| Free cash flow | $ | 19,141 |  |  | $ | 120,551 |  |

[0000866374-17-000008:mdna:81]
Cash used in financing activities was $23 million during the three-month period ended June 30, 2017, which was primarily for the repurchase of our ordinary shares in the amount of $74 million, offset by $59 million received from third party investors in exchange for a noncontrolling equity interest in one of our subsidiaries.

[0000866374-17-000008:mdna:82]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit

[0000866374-17-000008:mdna:83]
29

[0000866374-17-000008:mdna:84]
facilities, will be sufficient to fund our operations through at least the next twelve months. As of June 30, 2017, more than half of our cash and cash equivalent was held by foreign subsidiaries outside of Singapore. As of March 31, 2017, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.2 billion as of March 31, 2017). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-17-000008:mdna:85]
[same as prior period, unchanged from 0000866374-17-000002:mdna:93]

[0000866374-17-000008:mdna:86]
[same as prior period, unchanged from 0000866374-17-000002:mdna:94]

[0000866374-17-000008:mdna:87]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-17-000008:mdna:88]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 24, 2016. During the three-month period ended June 30, 2017, we paid $74 million to repurchase shares under the current repurchase plan at an average price of $16.43 per share. As of June 30, 2017, shares in the aggregate amount of $212 million were available to be repurchased under the current plan.

[0000866374-17-000008:mdna:89]
[same as prior period, unchanged from 0000866374-17-000002:mdna:97]

[0000866374-17-000008:mdna:90]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2017. There have been no material changes in our contractual obligations and commitments since March 31, 2017 except for the following changes to our debt obligations.

[0000866374-17-000008:mdna:91]
On June 30, 2017 we extended the maturity date of one of our term loan agreements from March 31, 2019 to June 30, 2022. Refer to note 6 to the condensed consolidated financial statements for additional details on this term loan.

[0000866374-17-000008:mdna:92]
Future payments due under our long-term debt changed from those described in the Contractual Obligations and Commitments table contained within our Annual Report on our Form 10-K for the fiscal year ended March 31, 2017, and accordingly have been updated as follows:

[0000866374-17-000008:mdna:93]
|  | Total |  | Less Than1 Year |  | 1-3 Years |  | 4-5 Years |  | Great Than5 Years |
|  | (In thousands) |
| Long-term Debt Obligations: |  |  |  |  |  |  |  |  |  |
| Long-term debt | $ | 2,968,150 |  |  | $ | 37,730 |  |  | $ | 585,434 |  |  | $ | 905,870 |  |  | $ | 1,439,116 |  |

[0000866374-17-000008:mdna:94]
[same as prior period, unchanged from 0000866374-17-000002:mdna:102]

[0000866374-17-000008:mdna:95]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of June 30, 2017 and March 31, 2017, the fair values of our deferred purchase price receivable were approximately $547 million and $507 million, respectively. As of June 30, 2017 and March 31, 2017, the outstanding balance on receivables sold for cash was $1.2 billion under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information, see note 10 to the condensed consolidated financial statements.
