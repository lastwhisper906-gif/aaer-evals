# FLEX notes — 0000866374-20-000030


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-20-000030:notes:1]
[same as prior period, unchanged from 0000866374-20-000012:notes:1]

[0000866374-20-000030:notes:2]
[same as prior period, unchanged from 0000866374-20-000012:notes:2]

[0000866374-20-000030:notes:3]
[same as prior period, unchanged from 0000866374-20-000012:notes:3]

[0000866374-20-000030:notes:4]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure;

[0000866374-20-000030:notes:5]
[same as prior period, unchanged from 0000866374-20-000012:notes:5]

[0000866374-20-000030:notes:6]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-20-000030:notes:7]
[same as prior period, unchanged from 0000866374-20-000012:notes:7]

[0000866374-20-000030:notes:8]
[same as prior period, unchanged from 0000866374-20-000012:notes:8]

[0000866374-20-000030:notes:9]
[same as prior period, unchanged from 0000866374-20-000012:notes:9]

[0000866374-20-000030:notes:10]
[same as prior period, unchanged from 0000866374-20-000012:notes:10]

[0000866374-20-000030:notes:11]
[same as prior period, unchanged from 0000866374-20-000012:notes:11]

[0000866374-20-000030:notes:12]
[same as prior period, unchanged from 0000866374-20-000012:notes:12]

[0000866374-20-000030:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2020 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and six-month periods ended September 25, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021. Beginning in the second quarter of fiscal year 2021, the Company began reporting all dollar amounts in millions. In certain circumstances, this change in rounding resulted in line items being removed within prior year disclosures. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

[0000866374-20-000030:notes:14]
The first quarters for fiscal years 2021 and 2020 ended on June 26, 2020, which is comprised of 87 days in the period, and June 28, 2019, which is comprised of 89 days in the period, respectively. The second quarters for fiscal years 2021 and 2020 ended on September 25, 2020 and September 27, 2019, which are comprised of 91 days in both periods.

[0000866374-20-000030:notes:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not

[0000866374-20-000030:notes:16]
material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

[0000866374-20-000030:notes:17]
The changes to the Company’s organizational structure noted above had no impact on the condensed consolidated financial statements. For comparability purposes, segment reporting for prior periods have been restated to conform to the current presentation. Refer to note 14, “Segment Reporting,” for additional information on the changes in operating and reportable segments.

[0000866374-20-000030:notes:18]
[same as prior period, unchanged from 0000866374-20-000012:notes:18]

[0000866374-20-000030:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, including highly liquid investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-20-000030:notes:20]
Recently Adopted Accounting Pronouncement

[0000866374-20-000030:notes:21]
In March 2020, the FASB issued ASU 2020-04 "Facilitation of the Effects of Reference Rate Reform on Financial Reporting", which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

[0000866374-20-000030:notes:22]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04,  ASU 2019-05, ASU 2019-10, and ASU 2019-11, which replaces the existing incurred loss impairment model with an expected credit loss model and requires a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

[0000866374-20-000030:notes:23]
Recently Issued Accounting Pronouncements

[0000866374-20-000030:notes:24]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

[0000866374-20-000030:notes:25]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes", which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-20-000030:notes:26]
[same as prior period, unchanged from 0000866374-20-000012:notes:26]

[0000866374-20-000030:notes:27]
[same as prior period, unchanged from 0000866374-20-000012:notes:27]

[0000866374-20-000030:notes:28]
|  | As of September 25, 2020 |  | As of March 31, 2020 |
|  | (In millions) |
| Raw materials | $ | 2,662 |  |  | $ | 2,836 |  |
| Work-in-progress | 433 |  |  | 373 |  |
| Finished goods | 516 |  |  | 576 |  |
|  | $ | 3,611 |  |  | $ | 3,785 |  |

[0000866374-20-000030:notes:29]
[same as prior period, unchanged from 0000866374-20-000012:notes:29]

[0000866374-20-000030:notes:30]
[same as prior period, unchanged from 0000866374-20-000012:notes:30]

[0000866374-20-000030:notes:31]
Based on the latest assessment of its goodwill as of April 1, 2020, the Company determined that no impairment existed as of the date of the impairment test, because the fair value of each one of its reporting units exceeds its respective carrying value. In addition, goodwill was reallocated among each of the Company's six reporting units based on each reporting unit’s relative fair value as of April 1, 2020. The Company considered whether an interim impairment test should be performed as of September 25, 2020 and concluded that there were no events or changes in circumstances that indicated the carrying amount of goodwill may not be recoverable. It will perform its next annual impairment test on January 1, 2021. The following table summarizes the goodwill allocation as of April 1, 2020 and the activity during the six-month period ended September 25, 2020:

[0000866374-20-000030:notes:32]
|  | FAS |  | FRS |  |  |
|  | Communications, Enterprise and Cloud |  | Lifestyle |  | Consumer Devices |  | Automotive |  | Health Solutions |  | Industrial |  | Total |
|  | (In millions) |
| Balance at April 1, 2020 | $ | 188 |  |  | $ | 131 |  |  | $ | 51 |  |  | $ | 174 |  |  | $ | 192 |  |  | $ | 329 |  |  | $ | 1,065 |  |
| Foreign currency translation adjustments | — |  |  | — |  |  | — |  |  | 21 |  |  | 2 |  |  | — |  |  | 23 |  |
| Balance at September 25, 2020 | $ | 188 |  |  | $ | 131 |  |  | $ | 51 |  |  | $ | 195 |  |  | $ | 194 |  |  | $ | 329 |  |  | $ | 1,088 |  |

[0000866374-20-000030:notes:33]
[same as prior period, unchanged from 0000866374-20-000012:notes:33]

[0000866374-20-000030:notes:34]
|  | As of September 25, 2020 |  | As of March 31, 2020 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 282 |  |  | $ | (146) |  |  | $ | 136 |  |  | $ | 275 |  |  | $ | (128) |  |  | $ | 147 |  |
| Licenses and other intangibles | 255 |  |  | (150) |  |  | 105 |  |  | 245 |  |  | (130) |  |  | 115 |  |
| Total | $ | 537 |  |  | $ | (296) |  |  | $ | 241 |  |  | $ | 520 |  |  | $ | (258) |  |  | $ | 262 |  |

[0000866374-20-000030:notes:35]
[same as prior period, unchanged from 0000866374-20-000012:notes:35]

[0000866374-20-000030:notes:36]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2021 (1) |  | $ | 31 |  |
| 2022 |  | 53 |  |
| 2023 |  | 45 |  |
| 2024 |  | 44 |  |
| 2025 |  | 39 |  |
| Thereafter |  | 29 |  |
| Total amortization expense |  | $ | 241 |  |

[0000866374-20-000030:notes:37]
[same as prior period, unchanged from 0000866374-20-000012:notes:37]

[0000866374-20-000030:notes:38]
(1)Represents estimated amortization for the remaining fiscal six-month period ending March 31, 2021.

[0000866374-20-000030:notes:39]
Other Current Liabilities
Other current liabilities include customer working capital advances of $356.1 million and $264.2 million, customer-related accruals of $203.3 million and $195.1 million, and current operating lease liabilities of $119.0 million and $114.1 million as of September 25, 2020 and March 31, 2020, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-20-000030:notes:40]
[same as prior period, unchanged from 0000866374-20-000012:notes:40]

[0000866374-20-000030:notes:41]
[same as prior period, unchanged from 0000866374-20-000012:notes:41]

[0000866374-20-000030:notes:42]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of

[0000866374-20-000030:notes:43]
costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-20-000030:notes:44]
[same as prior period, unchanged from 0000866374-20-000012:notes:44]

[0000866374-20-000030:notes:45]
[same as prior period, unchanged from 0000866374-20-000012:notes:45]

[0000866374-20-000030:notes:46]
[same as prior period, unchanged from 0000866374-20-000012:notes:46]

[0000866374-20-000030:notes:47]
[same as prior period, unchanged from 0000866374-20-000012:notes:47]

[0000866374-20-000030:notes:48]
[same as prior period, unchanged from 0000866374-20-000012:notes:48]

[0000866374-20-000030:notes:49]
[same as prior period, unchanged from 0000866374-20-000012:notes:49]

[0000866374-20-000030:notes:50]
[same as prior period, unchanged from 0000866374-20-000012:notes:50]

[0000866374-20-000030:notes:51]
[same as prior period, unchanged from 0000866374-20-000012:notes:51]

[0000866374-20-000030:notes:52]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $354.9 million and $361.5 million as of September 25, 2020 and March 31, 2020, respectively.

[0000866374-20-000030:notes:53]
Disaggregation of Revenue

[0000866374-20-000030:notes:54]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended September 25, 2020 and September 27, 2019, respectively.

[0000866374-20-000030:notes:55]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,823 |  |  | $ | 2,987 |  |  | $ | 5,269 |  |  | $ | 5,956 |  |
| Over time | 495 |  |  | 596 |  |  | 961 |  |  | 1,535 |  |
| Total | 3,318 |  |  | 3,583 |  |  | 6,230 |  |  | 7,491 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,779 |  |  | 1,597 |  |  | 3,103 |  |  | 3,050 |  |
| Over time | 888 |  |  | 908 |  |  | 1,805 |  |  | 1,723 |  |
| Total | 2,667 |  |  | 2,505 |  |  | 4,908 |  |  | 4,773 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,602 |  |  | 4,584 |  |  | 8,372 |  |  | 9,006 |  |
| Over time | 1,383 |  |  | 1,504 |  |  | 2,766 |  |  | 3,258 |  |
| Total | $ | 5,985 |  |  | $ | 6,088 |  |  | $ | 11,138 |  |  | $ | 12,264 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-20-000030:notes:56]
[same as prior period, unchanged from 0000866374-20-000012:notes:54]

[0000866374-20-000030:notes:57]
[same as prior period, unchanged from 0000866374-20-000012:notes:55]

[0000866374-20-000030:notes:58]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
|  | (In millions) |
| Cost of sales | $ | 6 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 7 |  |
| Selling, general and administrative expenses | 18 |  |  | 15 |  |  | 27 |  |  | 27 |  |
| Total share-based compensation expense | $ | 24 |  |  | $ | 19 |  |  | $ | 37 |  |  | $ | 34 |  |

[0000866374-20-000030:notes:59]
Total unrecognized compensation expense related to share options under all plans as well as the number of options outstanding and exercisable were immaterial as of September 25, 2020.

[0000866374-20-000030:notes:60]
During the six-month period ended September 25, 2020, the Company granted 10.9 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 9.3 million are plain-vanilla unvested RSU awards that vest over a period of two to four years, with no performance or market conditions, and with an average grant date price of $10.31 per award. Further, approximately 1.6 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $15.03 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 3.2 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-20-000030:notes:61]
As of September 25, 2020, approximately 20.9 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 3.8 million awards is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 7.6 million based on the achievement levels of the respective conditions. During the six-month period ended September 25, 2020, no shares vested in connection with the awards with market conditions granted in fiscal year 2018.

[0000866374-20-000030:notes:62]
As of September 25, 2020, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $182.5 million, and will be recognized over a weighted-average remaining vesting period of 2.3 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-20-000030:notes:63]
EARNINGS (LOSS) PER SHARE 
The following table reflects basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share attributable to the shareholders of Flex:

[0000866374-20-000030:notes:64]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
|  | (In millions, except per share amounts) |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 113 |  |  | $ | (117) |  |  | $ | 165 |  |  | $ | (72) |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 501 |  |  | 513 |  |  | 499 |  |  | 513 |  |
| Basic earnings (loss) per share | $ | 0.23 |  |  | $ | (0.23) |  |  | $ | 0.33 |  |  | $ | (0.14) |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 113 |  |  | $ | (117) |  |  | $ | 165 |  |  | $ | (72) |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 501 |  |  | 513 |  |  | 499 |  |  | 513 |  |
| Weighted-average ordinary share equivalents from stock options and RSU awards (1) (2) (3) | 3 |  |  | — |  |  | 4 |  |  | — |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 504 |  |  | 513 |  |  | 503 |  |  | 513 |  |
| Diluted earnings (loss) per share | $ | 0.22 |  |  | $ | (0.23) |  |  | $ | 0.33 |  |  | $ | (0.14) |  |

[0000866374-20-000030:notes:65]
(1)An immaterial number of options to purchase ordinary shares were excluded from the computation of diluted earnings per share during the three and six-month periods ended September 25, 2020 and September 27, 2019, respectively, due to their anti-dilutive impact on the weighted-average ordinary share equivalents.

[0000866374-20-000030:notes:66]
(2)RSU awards of 3.5 million and 3.6 million for the three and six-month periods ended September 25, 2020, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. RSU awards of 5.9 million and 5.5 million for the three and six-month periods ended September 27, 2019, respectively, were excluded from the computation of diluted earnings per share.

[0000866374-20-000030:notes:67]
(3)As a result of the Company's net loss, ordinary shares equivalent from stock options and RSU awards of approximately 2.6 million for the three-month period ended September 27, 2019, and 3.3 million for the six-month period ended September 27, 2019, were excluded from the calculation of diluted earnings (loss) per share, due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-20-000030:notes:68]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 25, 2020 are as follows:

[0000866374-20-000030:notes:69]
|  | As of September 25, 2020 |  | As of March 31, 2020 |
|  | (In millions) |
| Term Loan, including current portion, due in installments through June 2022 | — |  |  | 433 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 318 |  |  | 310 |  |
| 4.750% Notes due June 2025 | 597 |  |  | 597 |  |
| 3.750% Notes due February 2026 | 696 |  |  | — |  |
| 4.875% Notes due June 2029 | 661 |  |  | 662 |  |
| 4.875% Notes due May 2030 | 696 |  |  | — |  |
| India Facilities | 138 |  |  | 138 |  |
| Other | 220 |  |  | 211 |  |
| Debt issuance costs | (24) |  |  | (13) |  |
|  | 3,802 |  |  | 2,838 |  |
| Current portion, net of debt issuance costs | (63) |  |  | (149) |  |
| Non-current portion | $ | 3,739 |  |  | $ | 2,689 |  |

[0000866374-20-000030:notes:70]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.0% as of September 25, 2020 and March 31, 2020, respectively.

[0000866374-20-000030:notes:71]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 25, 2020 are as follows:

[0000866374-20-000030:notes:72]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2021 (1) |  | $ | 56 |  |
| 2022 |  | 216 |  |
| 2023 |  | 531 |  |
| 2024 |  | 53 |  |
| 2025 |  | 318 |  |
| Thereafter |  | 2,652 |  |
| Total |  | $ | 3,826 |  |

[0000866374-20-000030:notes:73]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2021.

[0000866374-20-000030:notes:74]
Notes due February 2026 and May 2030

[0000866374-20-000030:notes:75]
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026 (the "Existing 2026 Notes"), at 99.617% of face value and $325 million aggregate principal amount of 4.875% Notes due May 2030 (the "Existing 2030 Notes" and, together with the Existing 2026 Notes, the "Existing Notes"), at 99.562% of face value. In August 2020, as a further issuance of the Existing Notes, the Company issued under the same terms (other than the initial interest accrual date and first interest payment date for the additional 2026 Notes, and the initial offering price and the issue date for the additional 2026 and 2030 Notes), an additional $250 million of 3.750% Notes due February 2026 (together with the "Existing 2026 Notes" above, the "2026 Notes"), at 109.294% of face value, and $325 million of 4.875% Notes due May 2030 (together with the "Existing 2030 Notes" above, the "2030 Notes"), at 114.863% of face value. Immediately after the issuance of the additional notes issued in August 2020, the Company has $675 million aggregate principal amount of 3.750% Notes due 2026 outstanding and $650 million aggregate principal amount of 4.875% Notes due 2030 outstanding. The Company received in aggregate, proceeds of approximately $1.4 billion, net of discounts and after premiums, from the issuances, which have been used for working capital and other general corporate purposes, in addition to repaying the term loan due June 2022. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet approximately $12.8 million of costs in conjunction with the issuance of the Notes.

[0000866374-20-000030:notes:76]
Interest on the 2026 Notes and the 2030 Notes is payable semi-annually, commencing on August 1, 2020 and November 12, 2020, respectively, except that interest on the additional 2026 Notes is payable commencing February 1, 2021. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2026 Notes or 2030 Notes may declare all of such series of Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of such series of Notes. As of September 25, 2020, the Company was in compliance with the covenants in the indenture governing the Notes.


## flex:InterestAndOtherNetTextBlock

[0000866374-20-000030:notes:77]
INTEREST AND OTHER, NET 
Interest and other, net for the three and six-month periods ended September 25, 2020 and September 27, 2019 are primarily composed of the following:

[0000866374-20-000030:notes:78]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
|  | (In millions) |
| Interest expenses on debt obligations (1) | $ | 38 |  |  | $ | 38 |  |  | $ | 71 |  |  | $ | 79 |  |
| ABS and AR sales programs related expenses | 3 |  |  | 12 |  |  | 7 |  |  | 25 |  |
| Interest income | (3) |  |  | (5) |  |  | (6) |  |  | (10) |  |
| Gain on foreign exchange transactions | (5) |  |  | (3) |  |  | (5) |  |  | (4) |  |

[0000866374-20-000030:notes:79]
(1)Interest expense on debt obligations for the three and six-month periods ended September 27, 2019 include debt extinguishment costs of $2.4 million and $6.5 million, respectively, related to the full repayments of the Notes due February 2020 and the Term Loan due November 2021. There were immaterial debt extinguishment costs incurred during the second quarter of fiscal year 2021 from the repayment of the term loan due June 2022.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-20-000030:notes:80]
[same as prior period, unchanged from 0000866374-20-000012:notes:78]

[0000866374-20-000030:notes:81]
[same as prior period, unchanged from 0000866374-20-000012:notes:79]

[0000866374-20-000030:notes:82]
As of September 25, 2020, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $8.9 billion as summarized below:

[0000866374-20-000030:notes:83]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| CNY |  | 1,958 |  |  | — |  |  | $ | 288 |  |  | $ | — |  |
| JPY |  | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN |  | 4,946 |  |  | — |  |  | 223 |  |  | — |  |
| Other |  | N/A |  | N/A |  | 356 |  |  | 71 |  |
|  |  |  |  |  |  | 1,167 |  |  | 71 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 792 |  |  | — |  |  | 143 |  |
| CNY |  | 4,062 |  |  | 1,316 |  |  | 591 |  |  | 193 |  |
| EUR |  | 1,834 |  |  | 1,997 |  |  | 2,144 |  |  | 2,335 |  |
| GBP |  | 69 |  |  | 89 |  |  | 88 |  |  | 114 |  |
| HUF |  | 53,376 |  |  | 52,554 |  |  | 170 |  |  | 168 |  |
| ILS |  | 354 |  |  | — |  |  | 102 |  |  | — |  |
| MXN |  | 4,550 |  |  | 2,833 |  |  | 205 |  |  | 128 |  |
| MYR |  | 1,618 |  |  | 1,290 |  |  | 390 |  |  | 311 |  |
| SEK |  | 634 |  |  | 748 |  |  | 72 |  |  | 83 |  |
| Other |  | N/A |  | N/A |  | 213 |  |  | 209 |  |
|  |  |  |  |  |  | 3,975 |  |  | 3,684 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 5,142 |  |  | $ | 3,755 |  |

[0000866374-20-000030:notes:84]
As of September 25, 2020, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of September 25, 2020 and March 31, 2020, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were $7.6 million as of September 25, 2020, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-20-000030:notes:85]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of September 25, 2020. The changes in fair value of the USD JPY cross currency swap are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also impacts the same line.

[0000866374-20-000030:notes:86]
[same as prior period, unchanged from 0000866374-20-000012:notes:84]

[0000866374-20-000030:notes:87]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 25,2020 |  | March 31,2020 |  | Balance SheetLocation |  | September 25,2020 |  | March 31,2020 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 22 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 13 |  |  | $ | 47 |  |
| Foreign currency contracts | Other assets |  | $ | 19 |  |  | $ | 14 |  |  | Other liabilities |  | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 26 |  |  | $ | 83 |  |  | Other current liabilities |  | $ | 21 |  |  | $ | 103 |  |

[0000866374-20-000030:notes:88]
[same as prior period, unchanged from 0000866374-20-000012:notes:86]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-20-000030:notes:89]
[same as prior period, unchanged from 0000866374-20-000012:notes:87]

[0000866374-20-000030:notes:90]
|  | Three-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (52) |  |  | $ | (119) |  |  | $ | (171) |  |  | $ | (47) |  |  | $ | (105) |  |  | $ | (152) |  |
| Other comprehensive gain (loss) before reclassifications | 11 |  |  | 31 |  |  | 42 |  |  | (3) |  |  | (26) |  |  | (29) |  |
| Net losses reclassified from accumulated other comprehensive loss | (4) |  |  | — |  |  | (4) |  |  | (9) |  |  | — |  |  | (9) |  |
| Net current-period other comprehensive gain (loss) | 7 |  |  | 31 |  |  | 38 |  |  | (12) |  |  | (26) |  |  | (38) |  |
| Ending balance | $ | (45) |  |  | $ | (88) |  |  | $ | (133) |  |  | $ | (59) |  |  | $ | (131) |  |  | $ | (190) |  |

[0000866374-20-000030:notes:91]
|  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (82) |  |  | $ | (133) |  |  | $ | (215) |  |  | $ | (42) |  |  | $ | (110) |  |  | $ | (152) |  |
| Other comprehensive gain (loss) before reclassifications | 30 |  |  | 45 |  |  | 75 |  |  | (9) |  |  | (21) |  |  | (30) |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 7 |  |  | — |  |  | 7 |  |  | (8) |  |  | — |  |  | (8) |  |
| Net current-period other comprehensive gain (loss) | 37 |  |  | 45 |  |  | 82 |  |  | (17) |  |  | (21) |  |  | (38) |  |
| Ending balance | $ | (45) |  |  | $ | (88) |  |  | $ | (133) |  |  | $ | (59) |  |  | $ | (131) |  |  | $ | (190) |  |

[0000866374-20-000030:notes:92]
Substantially all unrealized losses and gains relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and six-month periods ended September 25, 2020, respectively, were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-20-000030:notes:93]
[same as prior period, unchanged from 0000866374-20-000012:notes:90]

[0000866374-20-000030:notes:94]
[same as prior period, unchanged from 0000866374-20-000012:notes:91]

[0000866374-20-000030:notes:95]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” and together with the Global Program, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells the receivables to unaffiliated financial institutions. Under these programs, the entire purchase price of sold receivables are paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The fair value of the guarantee obligation was immaterial as of September 25, 2020 and March 31, 2020, respectively. The accounts receivable balances sold under the ABS Programs were removed from the condensed consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-20-000030:notes:96]
[same as prior period, unchanged from 0000866374-20-000012:notes:93]

[0000866374-20-000030:notes:97]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three and six-month periods ended September 25, 2020 and September 27, 2019 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-20-000030:notes:98]
As of September 25, 2020 and March 31, 2020, approximately $11.2 million and $0.8 billion, respectively, of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds for the same amount.

[0000866374-20-000030:notes:99]
For the six-month periods ended September 25, 2020 and September 27, 2019, cash flows from sales of receivables under the ABS Programs consisted of approximately $4.3 billion and $3.2 billion, respectively, for transfers of receivables. The six-

[0000866374-20-000030:notes:100]
month period ended September 27, 2019 also included approximately $1.8 billion for collections on deferred purchase price receivables (effective November 2019, the Company no longer holds a deferred purchase price receivables balance). The Company's cash flows from transfers of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-20-000030:notes:101]
Trade Accounts Receivable Sale Programs
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.1 billion and $0.4 billion as of September 25, 2020 and March 31, 2020, respectively. For the six-month periods ended September 25, 2020 and September 27, 2019, total accounts receivable sold to certain third-party banking institutions was approximately $0.5 billion and $0.9 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received were included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-20-000030:notes:102]
[same as prior period, unchanged from 0000866374-20-000012:notes:98]

[0000866374-20-000030:notes:103]
[same as prior period, unchanged from 0000866374-20-000012:notes:99]

[0000866374-20-000030:notes:104]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager. The Company’s deferred compensation plan assets are included in other noncurrent assets on the condensed consolidated balance sheets and include investments in equity securities that are valued using active market prices. There were no investments  classified as level 1 in the fair value hierarchy as of September 25, 2020 and March 31, 2020.

[0000866374-20-000030:notes:105]
[same as prior period, unchanged from 0000866374-20-000012:notes:102]

[0000866374-20-000030:notes:106]
[same as prior period, unchanged from 0000866374-20-000012:notes:103]

[0000866374-20-000030:notes:107]
[same as prior period, unchanged from 0000866374-20-000012:notes:104]

[0000866374-20-000030:notes:108]
[same as prior period, unchanged from 0000866374-20-000012:notes:105]

[0000866374-20-000030:notes:109]
[same as prior period, unchanged from 0000866374-20-000012:notes:106]

[0000866374-20-000030:notes:110]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of September 25, 2020 and March 31, 2020.

[0000866374-20-000030:notes:111]
There were no transfers between levels in the fair value hierarchy during the six-month periods ended September 25, 2020 and September 27, 2019.

[0000866374-20-000030:notes:112]
[same as prior period, unchanged from 0000866374-20-000012:notes:109]

[0000866374-20-000030:notes:113]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of September 25, 2020 and March 31, 2020:

[0000866374-20-000030:notes:114]
|  | Fair Value Measurements as of September 25, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 972 |  |  | $ | — |  |  | $ | 972 |  |
| Foreign currency contracts (Note 8) | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (34) |  |  | $ | — |  |  | $ | (34) |  |
|  | Fair Value Measurements as of March 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 404 |  |  | $ | — |  |  | $ | 404 |  |
| Foreign currency contracts (Note 8) | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (149) |  |  | $ | — |  |  | $ | (149) |  |

[0000866374-20-000030:notes:115]
[same as prior period, unchanged from 0000866374-20-000012:notes:112]

[0000866374-20-000030:notes:116]
[same as prior period, unchanged from 0000866374-20-000012:notes:113]

[0000866374-20-000030:notes:117]
|  | As of September 25, 2020 |  | As of March 31, 2020 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | $ | — |  |  | $ | — |  |  | $ | 433 |  |  | $ | 414 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500 |  |  | 545 |  |  | 500 |  |  | 500 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 318 |  |  | 318 |  |  | 310 |  |  | 310 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597 |  |  | 675 |  |  | 597 |  |  | 613 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 696 |  |  | 760 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 661 |  |  | 760 |  |  | 662 |  |  | 628 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 696 |  |  | 795 |  |  | — |  |  | — |  |  | Level 1 |
| Euro Term Loans | 167 |  |  | 167 |  |  | 208 |  |  | 208 |  |  | Level 2 |
| India Facilities | 138 |  |  | 138 |  |  | 138 |  |  | 138 |  |  | Level 2 |

[0000866374-20-000030:notes:118]
[same as prior period, unchanged from 0000866374-20-000012:notes:115]

[0000866374-20-000030:notes:119]
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans due March 2021 and January 2022 based on the current market rate, and as of September 25, 2020, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-20-000030:notes:120]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-20-000030:notes:121]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-20-000030:notes:122]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-20-000030:notes:123]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor agreed to an immaterial settlement.

[0000866374-20-000030:notes:124]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. The motion has been fully briefed and defendants’ motion to dismiss is set for hearing on December 3, 2020. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-20-000030:notes:125]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a

[0000866374-20-000030:notes:126]
period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-20-000030:notes:127]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling 373.7 million Brazilian reals (approximately USD $67.3 million based on the exchange rate as of September 25, 2020). Four of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60.5 million Brazilian reals or USD $10.9 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Sao Paolo, Brazil on March 23, 2020; the value of that assessment is 33.9 million Brazilian reals (approximately USD $6.1 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-20-000030:notes:128]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-20-000030:notes:129]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $145.4 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-20-000030:notes:130]
A different foreign Tax Authority has issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for the periods fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80 million. The Company disagrees with the Tax Authority’s assertion and is actively contesting through administrative processes and will defend through judicial processes if necessary.

[0000866374-20-000030:notes:131]
As the final resolutions of the above items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-20-000030:notes:132]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-20-000030:notes:133]
SHARE REPURCHASES 
During the six-month period ended September 25, 2020, the Company made no repurchases of shares.

[0000866374-20-000030:notes:134]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of Annual General Meeting held on August 7, 2020. As of September 25, 2020, shares in the aggregate amount of $500 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-20-000030:notes:135]
SEGMENT REPORTINGIn March 2020, the Company announced a change in organizational structure as part of its strategy to further drive efficiency and productivity with two focused delivery models. The Company’s chief operating decision maker ("CODM") changed from the CEO and certain direct staff who oversee operations of the business, to the CEO herself. As a result, beginning in fiscal year 2021, the Company now reports its financial performance based on two operating and reportable 
segments, Flex Agility Solutions (“FAS”) and Flex Reliability Solutions (“FRS”) and analyzes operating income as the measure of segment profitability.

[0000866374-20-000030:notes:136]
The FAS segment is optimized for speed to market at any volume based on a highly flexible supply and manufacturing system. The Company realigned the majority of the customers under the former Communications & Enterprise Compute ("CEC") and Consumer Technologies Group ("CTG") segments under the new FAS segment. Certain customers that were in the former Industrial and Emerging Industries ("IEI") segment that meet the above delivery model were also consolidated into the FAS segment. FAS is now comprised of the following end markets that represent reportable units:

[0000866374-20-000030:notes:137]
•Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure;

[0000866374-20-000030:notes:138]
[same as prior period, unchanged from 0000866374-20-000012:notes:135]

[0000866374-20-000030:notes:139]
•Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-20-000030:notes:140]
The FRS segment is optimized for longer product lifecycles requiring complex ramps at any volume with specialized production models and critical environments. The Company consolidated the majority of its customers under the former High Reliability Solutions ("HRS") and IEI segments into the new FRS segment. FRS is now comprised of the following end markets that represent reportable units:

[0000866374-20-000030:notes:141]
[same as prior period, unchanged from 0000866374-20-000012:notes:138]

[0000866374-20-000030:notes:142]
[same as prior period, unchanged from 0000866374-20-000012:notes:139]

[0000866374-20-000030:notes:143]
[same as prior period, unchanged from 0000866374-20-000012:notes:140]

[0000866374-20-000030:notes:144]
[same as prior period, unchanged from 0000866374-20-000012:notes:141]

[0000866374-20-000030:notes:145]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment charges, restructuring charges, legal and other, interest and other, net. A portion of depreciation is allocated to the respective segment, together with other general corporate research and development and administrative expenses.

[0000866374-20-000030:notes:146]
[same as prior period, unchanged from 0000866374-20-000012:notes:143]

[0000866374-20-000030:notes:147]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,318 |  |  | $ | 3,583 |  |  | $ | 6,230 |  |  | $ | 7,491 |  |
| Flex Reliability Solutions | 2,667 |  |  | 2,505 |  |  | 4,908 |  |  | 4,773 |  |
|  | $ | 5,985 |  |  | $ | 6,088 |  |  | $ | 11,138 |  |  | $ | 12,264 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 88 |  |  | $ | 94 |  |  | $ | 160 |  |  | $ | 203 |  |
| Flex Reliability Solutions | 179 |  |  | 159 |  |  | 294 |  |  | 289 |  |
| Corporate and Other | (20) |  |  | (26) |  |  | (44) |  |  | (57) |  |
| Total segment income | 247 |  |  | 227 |  |  | 410 |  |  | 435 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 16 |  |  | 16 |  |  | 31 |  |  | 33 |  |
| Stock-based compensation | 24 |  |  | 19 |  |  | 37 |  |  | 34 |  |
| Customer related asset impairments (recoveries) (1) | (3) |  |  | 91 |  |  | (3) |  |  | 91 |  |
| Restructuring charges (Note 15) | 35 |  |  | 128 |  |  | 45 |  |  | 185 |  |
| Legal and other (2) | — |  |  | 19 |  |  | 28 |  |  | 21 |  |
| Interest and other, net | 22 |  |  | 50 |  |  | 51 |  |  | 103 |  |
| Income before income taxes | $ | 153 |  |  | $ | (96) |  |  | $ | 221 |  |  | $ | (32) |  |

[0000866374-20-000030:notes:148]
(1)Customer related asset impairments for the three-month and six-month periods ended September 25, 2020 were not material and for the three-month and six-month periods ended September 27, 2019 primarily relate to additional provision for doubtful accounts receivable, and reserves for excess and obsolete inventory for certain customers experiencing financial difficulties and/or related to inventory that will not be recovered due to significant reductions in future customer demand as the Company reduced its exposure to certain higher volatility businesses.

[0000866374-20-000030:notes:149]
(2)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis. During the first quarter of fiscal year 2021, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-20-000030:notes:150]
Legal and other during the three-month and six-month periods ended September 27, 2019 primarily consists of direct and incremental costs associated with certain wind-down activities related to the disengagement of a certain customer primarily in China and India.

[0000866374-20-000030:notes:151]
[same as prior period, unchanged from 0000866374-20-000012:notes:146]

[0000866374-20-000030:notes:152]
[same as prior period, unchanged from 0000866374-20-000012:notes:147]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-20-000030:notes:153]
RESTRUCTURING CHARGESIn order to support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, the Company has identified and is engaging in certain structural changes. These restructuring actions will eliminate non-core activities primarily within the Company’s corporate function, align the Company’s cost structure with its reorganizing and optimizing of its operations model along its two reporting segments, and further sharpen its focus to winning business in end markets where it has competitive advantages and deep domain expertise. 
During the three-month and six-month periods ended September 25, 2020, the Company recognized approximately $35.4 million and $45.1 million of restructuring charges, respectively, most of which related to employee severance.

[0000866374-20-000030:notes:154]
During the first half of fiscal year 2020 in connection with geopolitical developments and uncertainties at the time, primarily impacting one customer in China, the Company experienced a reduction in demand for products assembled for that customer. As a result, the Company accelerated its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and streamline its cost structure. During the three-month and six-month periods ended September 27, 2019, the Company recognized $128.3 million and $184.5 million of restructuring charges, respectively. The Company incurred cash charges of approximately $97.0 million and $127.8 million, respectively, that were predominantly for employee severance, and non-cash charges of $31.3 million and $56.7 million, respectively, primarily related to asset impairments during the three and six-month periods ended September 27, 2019.

[0000866374-20-000030:notes:155]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of September 25, 2020 for charges incurred during the six-month period ended September 25, 2020:

[0000866374-20-000030:notes:156]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2020 | $ | 20 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 24 |  |
| Provision for charges incurred during the six-month period ended September 25, 2020 | 42 |  |  | 3 |  |  | — |  |  | 45 |  |
| Cash payments for charges incurred in the fiscal year 2020 and prior | (13) |  |  | — |  |  | (1) |  |  | (14) |  |
| Cash payments for charges incurred during the six-month period ended September 25, 2020 | (20) |  |  | — |  |  | (1) |  |  | (21) |  |
| Non-cash charges incurred during the six-month period ended September 25, 2020 | — |  |  | (3) |  |  | 1 |  |  | (2) |  |
| Balance as of September 25, 2020 | 29 |  |  | — |  |  | 3 |  |  | 32 |  |
| Less: Current portion (classified as other current liabilities) | 29 |  |  | — |  |  | 3 |  |  | 32 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
