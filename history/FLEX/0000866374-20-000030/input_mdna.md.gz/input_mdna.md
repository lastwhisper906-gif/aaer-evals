# FLEX MD&A — 0000866374-20-000030


## mdna

[0000866374-20-000030:mdna:1]
[same as prior period, unchanged from 0000866374-20-000012:mdna:1]

[0000866374-20-000030:mdna:2]
[same as prior period, unchanged from 0000866374-20-000012:mdna:2]

[0000866374-20-000030:mdna:3]
[same as prior period, unchanged from 0000866374-20-000012:mdna:3]

[0000866374-20-000030:mdna:4]
[same as prior period, unchanged from 0000866374-20-000012:mdna:4]

[0000866374-20-000030:mdna:5]
[same as prior period, unchanged from 0000866374-20-000012:mdna:5]

[0000866374-20-000030:mdna:6]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure;

[0000866374-20-000030:mdna:7]
[same as prior period, unchanged from 0000866374-20-000012:mdna:7]

[0000866374-20-000030:mdna:8]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-20-000030:mdna:9]
[same as prior period, unchanged from 0000866374-20-000012:mdna:10]

[0000866374-20-000030:mdna:10]
[same as prior period, unchanged from 0000866374-20-000012:mdna:11]

[0000866374-20-000030:mdna:11]
[same as prior period, unchanged from 0000866374-20-000012:mdna:12]

[0000866374-20-000030:mdna:12]
[same as prior period, unchanged from 0000866374-20-000012:mdna:13]

[0000866374-20-000030:mdna:13]
Refer to "note 14 - Segment Reporting,” to the condensed consolidated financial statements for additional information on the changes in operating and reportable segments.

[0000866374-20-000030:mdna:14]
[same as prior period, unchanged from 0000866374-20-000012:mdna:15]

[0000866374-20-000030:mdna:15]
[same as prior period, unchanged from 0000866374-20-000012:mdna:16]

[0000866374-20-000030:mdna:16]
[same as prior period, unchanged from 0000866374-20-000012:mdna:17]

[0000866374-20-000030:mdna:17]
During the first half of fiscal year 2020 in connection with geopolitical developments and uncertainties at the time, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During the first half of fiscal year 2021, in order to support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, the Company has identified and is engaging in certain structural changes.

[0000866374-20-000030:mdna:18]
[same as prior period, unchanged from 0000866374-20-000012:mdna:19]

[0000866374-20-000030:mdna:19]
[same as prior period, unchanged from 0000866374-20-000012:mdna:20]

[0000866374-20-000030:mdna:20]
As anticipated, our results were negatively impacted by COVID-19 disruptions to our factories, workforce, and suppliers most notably in our first quarter as the impact from the pandemic extended throughout the entire quarter. Total COVID-19 related costs incurred over the first half of the fiscal year 2021 were over $130 million and were primarily comprised of enhanced health and safety protocols, incremental labor incentives, incremental supply chain costs and forced under-absorption

[0000866374-20-000030:mdna:21]
of idle and underutilized labor and overhead costs. As we expected, these incremental costs persisted in our second quarter, but declined significantly from the June quarter as demand improved.

[0000866374-20-000030:mdna:22]
While both the FAS and FRS segments experienced sequential growth, COVID-19 related demand and production pressures remain in certain end markets that we serve. Net sales declined $0.1 billion and $1.1 billion during the three-month and six-month periods ended September 25, 2020 versus the prior year periods, primarily due to declines noted in the FAS segment. Included in the FRS segment, our Health Solutions business performed well during the first half of the fiscal year driven by the increased demand for critical care products and diagnostics and patient monitoring programs. Our factories were productive for the entire second quarter resulting in second quarter sales recovering specifically for the automotive businesses that were shut down during the majority of the first quarter. However, this business is still operating at a revenue run rate that is below pre-pandemic levels which we expect to continue in the near term. In addition, while we anticipate revenue will continue to improve across our end markets, we believe that our businesses tied to consumer spending, such as Lifestyle and Consumer Devices, will continue to be impacted if there is a prolonged demand slowdown. Refer to “Risk Factors - The COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material,” as disclosed in Part I, “Item 1A. Risk Factors” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0000866374-20-000030:mdna:23]
As part of our continuous response to the outbreak, we maintained salary cuts, furloughs and other programs to cut costs that were initiated at the beginning of our first quarter through the second quarter. This also included aggressively reducing discretionary corporate spend. Employees that have been operating on a work-from-home basis are continuing to do so. While there still remains an elevated degree of uncertainty, we have removed specific austerity measures involving employee compensation. Further, to continue to support our strategy and build a sustainable organization, and after considering that the economic recovery will be slower than anticipated, we have identified and are continuing to engage in certain structural changes. See additional discussion regarding these restructuring actions below under "Restructuring charges".

[0000866374-20-000030:mdna:24]
[same as prior period, unchanged from 0000866374-20-000012:mdna:25]

[0000866374-20-000030:mdna:25]
[same as prior period, unchanged from 0000866374-20-000012:mdna:26]

[0000866374-20-000030:mdna:26]
[same as prior period, unchanged from 0000866374-20-000012:mdna:52]

[0000866374-20-000030:mdna:27]
We are one of the world's largest providers of global supply chain solutions, with revenues of $11.1 billion for the six-month period ended September 25, 2020 and $24.2 billion in fiscal year 2020. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-20-000030:mdna:28]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 2,453 |  |  | 41 | % |  | $ | 2,572 |  |  | 42 | % |  | $ | 4,557 |  |  | 41 | % |  | $ | 5,031 |  |  | 41 | % |
| Asia | 2,277 |  |  | 38 | % |  | 2,368 |  |  | 39 | % |  | 4,290 |  |  | 39 | % |  | 4,947 |  |  | 40 | % |
| Europe | 1,255 |  |  | 21 | % |  | 1,148 |  |  | 19 | % |  | 2,291 |  |  | 20 | % |  | 2,286 |  |  | 19 | % |
|  | $ | 5,985 |  |  |  |  | $ | 6,088 |  |  |  |  | $ | 11,138 |  |  |  |  | $ | 12,264 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 1,493 |  |  | 25 | % |  | $ | 1,446 |  |  | 24 | % |  | $ | 2,910 |  |  | 26 | % |  | $ | 2,897 |  |  | 24 | % |
| Mexico | 1,153 |  |  | 19 | % |  | 1,158 |  |  | 19 | % |  | 2,060 |  |  | 18 | % |  | 2,237 |  |  | 18 | % |
| U.S. | 895 |  |  | 15 | % |  | 907 |  |  | 15 | % |  | 1,764 |  |  | 16 | % |  | 1,711 |  |  | 14 | % |
| Malaysia | 433 |  |  | 7 | % |  | 408 |  |  | 7 | % |  | 732 |  |  | 7 | % |  | 834 |  |  | 7 | % |
| Brazil | 389 |  |  | 6 | % |  | 489 |  |  | 8 | % |  | 711 |  |  | 6 | % |  | 1,044 |  |  | 9 | % |
| Hungary | 307 |  |  | 5 | % |  | 321 |  |  | 5 | % |  | 557 |  |  | 5 | % |  | 642 |  |  | 5 | % |
| Israel | 189 |  |  | 3 | % |  | 186 |  |  | 3 | % |  | 376 |  |  | 3 | % |  | 370 |  |  | 3 | % |
| Other | 1,126 |  |  | 20 | % |  | 1,173 |  |  | 19 | % |  | 2,028 |  |  | 19 | % |  | 2,529 |  |  | 20 | % |
|  | $ | 5,985 |  |  |  |  | $ | 6,088 |  |  |  |  | $ | 11,138 |  |  |  |  | $ | 12,264 |  |  |  |

[0000866374-20-000030:mdna:29]
|  | As of |  | As of |
| Property and equipment, net: | September 25, 2020 |  | March 31, 2020 |
|  | (In millions) |
| Mexico | $ | 536 |  |  | 25 | % |  | $ | 555 |  |  | 25 | % |
| U.S. | 365 |  |  | 17 | % |  | 378 |  |  | 17 | % |
| China | 346 |  |  | 16 | % |  | 396 |  |  | 18 | % |
| India | 185 |  |  | 9 | % |  | 207 |  |  | 9 | % |
| Malaysia | 105 |  |  | 5 | % |  | 111 |  |  | 5 | % |
| Hungary | 101 |  |  | 5 | % |  | 100 |  |  | 4 | % |
| Other | 468 |  |  | 23 | % |  | 469 |  |  | 22 | % |
|  | $ | 2,106 |  |  |  |  | $ | 2,216 |  |  |  |

[0000866374-20-000030:mdna:30]
[same as prior period, unchanged from 0000866374-20-000012:mdna:30]

[0000866374-20-000030:mdna:31]
[same as prior period, unchanged from 0000866374-20-000012:mdna:31]

[0000866374-20-000030:mdna:32]
[same as prior period, unchanged from 0000866374-20-000012:mdna:32]

[0000866374-20-000030:mdna:33]
[same as prior period, unchanged from 0000866374-20-000012:mdna:33]

[0000866374-20-000030:mdna:34]
[same as prior period, unchanged from 0000866374-20-000012:mdna:34]

[0000866374-20-000030:mdna:35]
[same as prior period, unchanged from 0000866374-20-000012:mdna:35]

[0000866374-20-000030:mdna:36]
[same as prior period, unchanged from 0000866374-20-000012:mdna:36]

[0000866374-20-000030:mdna:37]
[same as prior period, unchanged from 0000866374-20-000012:mdna:37]

[0000866374-20-000030:mdna:38]
[same as prior period, unchanged from 0000866374-20-000012:mdna:38]

[0000866374-20-000030:mdna:39]
[same as prior period, unchanged from 0000866374-20-000012:mdna:39]

[0000866374-20-000030:mdna:40]
[same as prior period, unchanged from 0000866374-20-000012:mdna:40]

[0000866374-20-000030:mdna:41]
[same as prior period, unchanged from 0000866374-20-000012:mdna:41]

[0000866374-20-000030:mdna:42]
[same as prior period, unchanged from 0000866374-20-000012:mdna:42]

[0000866374-20-000030:mdna:43]
[same as prior period, unchanged from 0000866374-20-000012:mdna:43]

[0000866374-20-000030:mdna:44]
[same as prior period, unchanged from 0000866374-20-000012:mdna:44]

[0000866374-20-000030:mdna:45]
[same as prior period, unchanged from 0000866374-20-000012:mdna:45]

[0000866374-20-000030:mdna:46]
[same as prior period, unchanged from 0000866374-20-000012:mdna:46]

[0000866374-20-000030:mdna:47]
[same as prior period, unchanged from 0000866374-20-000012:mdna:47]

[0000866374-20-000030:mdna:48]
[same as prior period, unchanged from 0000866374-20-000012:mdna:48]

[0000866374-20-000030:mdna:49]
[same as prior period, unchanged from 0000866374-20-000012:mdna:49]

[0000866374-20-000030:mdna:50]
[same as prior period, unchanged from 0000866374-20-000012:mdna:50]

[0000866374-20-000030:mdna:51]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020. As previously disclosed, we made certain changes in our organization structure. As a result of these changes, we revised our reportable segments as further discussed in note 14 to the condensed consolidated financial statements. There was no change to our condensed consolidated financial statements. For comparability purposes, segment reporting for the prior period has been recast to conform to the current presentation.

[0000866374-20-000030:mdna:52]
32

[0000866374-20-000030:mdna:53]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.0 |  |  | 95.0 |  |  | 93.4 |  |  | 94.3 |  |
| Restructuring charges | 0.4 |  |  | 1.9 |  |  | 0.3 |  |  | 1.3 |  |
| Gross profit | 6.6 |  |  | 3.1 |  |  | 6.3 |  |  | 4.4 |  |
| Selling, general and administrative expenses | 3.2 |  |  | 3.4 |  |  | 3.4 |  |  | 3.4 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.2 |  |  | 0.2 |  |  | 0.1 |  |  | 0.2 |  |
| Interest and other, net | 0.4 |  |  | 0.8 |  |  | 0.5 |  |  | 0.8 |  |
| Income (loss) before income taxes | 2.6 |  |  | (1.6) |  |  | 2.0 |  |  | (0.3) |  |
| Provision for income taxes | 0.7 |  |  | 0.3 |  |  | 0.5 |  |  | 0.3 |  |
| Net income (loss) | 1.9 | % |  | (1.9) | % |  | 1.5 | % |  | (0.6) | % |

[0000866374-20-000030:mdna:54]
[same as prior period, unchanged from 0000866374-20-000012:mdna:54]

[0000866374-20-000030:mdna:55]
The following table sets forth our net sales by segment, and their relative percentages (amounts may not sum due to rounding):

[0000866374-20-000030:mdna:56]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,318 |  |  | 55 | % |  | $ | 3,583 |  |  | 59 | % |  | $ | 6,230 |  |  | 56 | % |  | $ | 7,491 |  |  | 61 | % |
| Flex Reliability Solutions | 2,667 |  |  | 45 | % |  | 2,505 |  |  | 41 | % |  | 4,908 |  |  | 44 | % |  | 4,773 |  |  | 39 | % |
|  | $ | 5,985 |  |  |  |  | $ | 6,088 |  |  |  |  | $ | 11,138 |  |  |  |  | $ | 12,264 |  |  |  |

[0000866374-20-000030:mdna:57]
Net sales during the three-month period ended September 25, 2020 totaled $6.0 billion, representing a decrease of approximately $0.1 billion, or 2% from $6.1 billion during the three-month period ended September 27, 2019. Net sales for our FAS segment decreased $265 million, or 7%, primarily driven by a decrease of approximately 30% in revenue from our Consumer Devices business resulting from lower demand due to the impact of COVID-19, and our continued strategic shift away from high volatility, short cycle businesses that we initiated in the prior year. The majority of COVID-19 related supplier constraints noted in the first quarter were abated in the second quarter of fiscal year 2021. Net sales for our FRS segment increased $162 million, or 6%, primarily due to an increase of over 30% in sales in our Health Solution business as a result of increased demand for critical care products and diagnostics and patient monitoring programs. Net sales decreased $119 million to $2.5 billion in the Americas, $91 million to $2.3 billion in Asia, partially offset by an increase of $107 million to $1.3 billion in Europe.

[0000866374-20-000030:mdna:58]
Net sales during the six-month period ended September 25, 2020 totaled $11.1 billion, representing a decrease of approximately $1.1 billion, or 9% from $12.3 billion during the six-month period ended September 27, 2019. The decrease in net sales was most notable in our FAS segment, down $1.3 billion, or 17%,  from the prior year, mainly due to a drop of approximately 50% in our Consumer Devices business led by the same factors described above. Offsetting a portion of the overall decline in revenue was an increase in revenues from the FRS segment of $135 million, or 3%, driven primarily by an increase of 25% in sales from our Health Solutions business, as noted above, and an increase of 10% in our Industrial business led by strong demand. These increases in our FRS segment were offset by a drop of approximately 30% in our Automotive business due to the factory shutdowns in the first quarter of fiscal year 2021. Net sales decreased $657 million to $4.3 billion in Asia, $474 million to $4.6 billion in the Americas, partially offset by a modest increase of $5 million to $2.3 billion in Europe.

[0000866374-20-000030:mdna:59]
Our ten largest customers, during the three and six-month periods ended September 25, 2020 and September 27, 2019, accounted for approximately 39% and 38% of net sales, respectively. Our ten largest customers, during the three and six-month periods ended September 27, 2019, accounted for approximately 39% of net sales for each of the periods. No customer accounted for more than 10% of net sales during the three and six-month periods ended September 25, 2020 or September 27, 2019.

[0000866374-20-000030:mdna:60]
Cost of sales

[0000866374-20-000030:mdna:61]
Cost of sales is affected by a number of factors, including the number and size of new manufacturing programs, product mix, labor cost fluctuations by region, component costs and availability and capacity utilization.

[0000866374-20-000030:mdna:62]
Cost of sales during the three-month period ended September 25, 2020 totaled $5.6 billion, representing a decrease of approximately $0.2 billion, or 4% from $5.8 billion during the three-month period ended September 27, 2019. The decrease in cost of sales for the three-month period is more notable in our FAS segment. Cost of sales in FAS for the three-month period ended September 25, 2020 declined 7%, or $249 million from the three-month period ended September 27, 2019, which is in line with the overall 7% decrease in FAS revenue during the same period primarily as a result of COVID-19 impacting our Consumer Devices businesses, coupled with our targeted disengagement of high volatility, short cycle businesses initiated in the prior year. This was partially offset by the $145 million or 6% increase of cost of sales in FRS, from the second quarter of fiscal year 2020 in line with the overall 6% increase in FRS revenue during the same period, as our Health Solutions businesses continued to ramp as discussed above. Cost of sales was also higher in the prior year due to $88 million of customer assets impairment charges for customers that were experiencing financial difficulties as well as the write-down of inventory not recoverable due to significant reductions in future customer demand as we reduced our exposure to certain higher volatility businesses.

[0000866374-20-000030:mdna:63]
Cost of sales during the six-month period ended September 25, 2020 totaled $10.4 billion, representing a decrease of approximately $1.2 billion, or 10% from $11.6 billion during the six-month period ended September 27, 2019. Cost of sales in FAS for the six-month period ended September 25, 2020 decreased $1.2 billion or 17% from the six-month period ended September 27, 2019. Offsetting the decrease in cost of sales in FAS is an increase of $0.2 billion, or 4%, related to the FRS segment during the six-month period ended September 25, 2020. These fluctuations are consistent with the associated changes in net sales noted above. Cost of sales was also higher in the prior year due to $88 million of customer assets impairment charges and write-down of inventory, as discussed in the three-months period above.

[0000866374-20-000030:mdna:64]
[same as prior period, unchanged from 0000866374-20-000012:mdna:60]

[0000866374-20-000030:mdna:65]
Gross profit is affected by a fluctuations in costs of sales elements as outlined above and further by product life cycles, unit volumes, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-20-000030:mdna:66]
Gross profit during the three-month period ended September 25, 2020 increased $206 million to $395 million, or 6.6% of net sales, from $189 million, or 3.1% of net sales, during the three-month period ended September 27, 2019. Gross margin improved 350 basis points during the same period. The increase in gross profit and gross margin resulted primarily from a higher mix of more profitable business in fiscal year 2021 versus the prior year. As noted above, the relative percentage of revenue from our FRS segment increased to 45% from 41%. FRS carries a higher gross profit percentage than FAS. Gross profit also was impacted by lower restructuring costs, $24 million in the three-month period ended September 25, 2020, versus $114 million in the three-month period ended September 27, 2019, a decline of $90 million which is primarily due to charges taken in fiscal year 2020 due to geopolitical challenges and uncertainties which impacted certain of our customers. Finally, gross profit increased due to the $88 million of customer assets impairment charges recorded in the prior year for customers that were experiencing financial difficulties coupled with the write-down of inventory not recoverable due to the significant reductions in future customer demand as we reduced our exposure to certain higher volatility businesses.

[0000866374-20-000030:mdna:67]
Gross profit during the six-month period ended September 25, 2020 increased $156 million to $698 million, or 6.3% of net sales, from $542 million, or 4.4% of net sales, during the six-month period ended September 27, 2019. Gross margin improved 190 basis points during the same period. The increase in gross profit and gross margin during the six-month period ended September 25, 2020 primarily resulted from the same factors impacting the three-month period as described above relating to the higher restructuring and customer assets impairment charges incurred in fiscal year 2020, which was partially offset by the decline in revenue and gross profit in our Consumer Devices and Automotive end markets reflecting COVID-19 demand and production pressures during the first half of fiscal year 2021.

[0000866374-20-000030:mdna:68]
Segment income

[0000866374-20-000030:mdna:69]
[same as prior period, unchanged from 0000866374-20-000012:mdna:65]

[0000866374-20-000030:mdna:70]
[same as prior period, unchanged from 0000866374-20-000012:mdna:66]

[0000866374-20-000030:mdna:71]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 88 |  |  | 2.7 | % |  | $ | 94 |  |  | 2.6 | % |  | $ | 160 |  |  | 2.6 | % |  | $ | 203 |  |  | 2.7 | % |
| Flex Reliability Solutions | 179 |  |  | 6.7 | % |  | 159 |  |  | 6.3 | % |  | 294 |  |  | 6.0 | % |  | 289 |  |  | 6.1 | % |

[0000866374-20-000030:mdna:72]
FAS segment margin increased 10 basis points, to 2.7% for the three-month period ended September 25, 2020, from 2.6% for the three-month period ended September 27, 2019. The margin increase was driven by additional flow through revenue from new programs in our CEC business and recovered demand in our Lifestyle end market, coupled with the austerity measures taken by the Company in response to the outbreak, partially offset with direct COVID-19 related expenses in the current quarter and decline in Consumer Devices that experienced some headwinds due to less favorable mix and continued pruning to align with our forward strategy. The FAS segment margin decreased 10 basis points, to 2.6% for the six-month period ended September 25, 2020, from 2.7% for the six-month period ended September 27, 2019. The decrease in FAS segment margin during the six-month period is primarily the result of elevated under-absorption and supply chain constraints specifically in our Consumer Devices end market throughout the first quarter and to a lesser extent, the second quarter of fiscal year 2021.

[0000866374-20-000030:mdna:73]
FRS segment margin increased 40 basis points, to 6.7% for the three-month period ended September 25, 2020, from 6.3% for the three-month period ended September 27, 2019. The margin improvement was driven by favorable mix impacting our Industrial and Health Solutions end markets, coupled with the austerity measures taken by the Company in response to the COVID-19 outbreak which more than offset the related direct COVID-19 expenses as well as ramp costs for certain new programs in the Health Solutions businesses. FRS segment margin decreased 10 basis points, to 6.0% for the six-month period ended September 25, 2020, from 6.1% for the six-month period ended September 27, 2019. The decrease in FRS segment margin during the six-month period is primarily the results of plant shutdowns during most of our first quarter of fiscal year 2021, which affected the entire automotive ecosystem across all regions, coupled with under-absorption and efficiency impacts. Even though Automotive saw a strong rebound through our second quarter of fiscal year 2021, we are running at a reduced run rate and expect that it will take some time to return to pre-COVID levels.

[0000866374-20-000030:mdna:74]
35

[0000866374-20-000030:mdna:75]
As a result of the organizational structure changes, as previously disclosed, we revised our reportable segments as further discussed in note 14 to the condensed consolidated financial statements. Selected unaudited quarterly financial information for fiscal year 2020 in the table below have been recast reflecting the new reportable segments (amounts may not sum due to rounding).

[0000866374-20-000030:mdna:76]
|  | Three-Month Periods Ended |  | Fiscal Year Ended |
|  | June 28, 2019 |  | September 27, 2019 |  | December 31, 2019 |  | March 31, 2020 |  | March 31, 2020 |
|  | (In millions) |
|  | (Unaudited) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,908 |  |  | 63 | % |  | $ | 3,583 |  |  | 59 | % |  | $ | 3,631 |  |  | 56 | % |  | $ | 2,931 |  |  | 53 | % |  | $ | 14,053 |  |  | 58 | % |
| Flex Reliability Solutions | 2,268 |  |  | 37 | % |  | 2,505 |  |  | 41 | % |  | 2,830 |  |  | 44 | % |  | 2,554 |  |  | 47 | % |  | 10,157 |  |  | 42 | % |
|  | $ | 6,176 |  |  |  |  | $ | 6,088 |  |  |  |  | $ | 6,461 |  |  |  |  | $ | 5,484 |  |  |  |  | $ | 24,210 |  |  |  |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 109 |  |  | 2.8 | % |  | $ | 94 |  |  | 2.6 | % |  | $ | 98 |  |  | 2.7 | % |  | $ | 68 |  |  | 2.3 | % |  | $ | 369 |  |  | 2.6 | % |
| Flex Reliability Solutions | 130 |  |  | 5.7 | % |  | 159 |  |  | 6.3 | % |  | 186 |  |  | 6.6 | % |  | 167 |  |  | 6.5 | % |  | 642 |  |  | 6.3 | % |

[0000866374-20-000030:mdna:77]
During fiscal year 2020, depreciation expense included in the segments' measure of operating performance above is as follows (amounts may not sum due to rounding).

[0000866374-20-000030:mdna:78]
|  |  | Fiscal Year Ended |
|  |  | March 31, 2020 |
|  |  | (In millions) |
|  |  | (Unaudited) |
| Depreciation expense: |  |  |
| Flex Agility Solutions |  | $ | 218 |  |
| Flex Reliability Solutions |  | 173 |  |
| Corporate and Other |  | 32 |  |
| Total depreciation expense |  | $ | 422 |  |

[0000866374-20-000030:mdna:79]
[same as prior period, unchanged from 0000866374-20-000012:mdna:75]

[0000866374-20-000030:mdna:80]
[same as prior period, unchanged from 0000866374-20-000012:mdna:76]

[0000866374-20-000030:mdna:81]
In order to support our strategy and build a sustainable organization, and after considering that the economic recovery from the pandemic will be slower than anticipated, we have identified and are engaging in certain structural changes. These restructuring actions will eliminate non-core activities primarily within our corporate function, align our cost structure with our reorganizing and optimizing of our operations model along our two reporting segments, and further sharpen our focus to winning business in end markets where we have competitive advantages and deep domain expertise. During the three and six-month periods ended September 25, 2020, we recognized approximately $35 million and $45 million, respectively, of restructuring charges, primarily cash charges related to employee severance. We expect to recognize approximately $60 million of additional charges as additional activities are approved over the remaining fiscal year 2021 period.

[0000866374-20-000030:mdna:82]
During the first half of fiscal year 2020 in connection with the recent geopolitical developments and uncertainties, primarily impacting one customer in China, we experienced a reduction in demand for products assembled for that customer. As a result, we accelerated our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. During the three and six-month periods ended September 27, 2019, we recognized $128 million and $185 million of restructuring charges. We incurred cash charges of approximately $97 million and $128 million, respectively, that were predominantly for employee severance, and non-cash charges of $31 million and $57 million, respectively, primarily related to asset impairments.

[0000866374-20-000030:mdna:83]
[same as prior period, unchanged from 0000866374-20-000012:mdna:81]

[0000866374-20-000030:mdna:84]
Selling, general and administrative expenses (“SG&A”) was $193 million, or 3.2% of net sales, during the three-month period ended September 25, 2020, decreasing $12 million from $205 million, or 3.4% of net sales, during the three-month period ended September 27, 2019. SG&A was $384 million, or 3.4% of net sales, during the six-month period ended

[0000866374-20-000030:mdna:85]
September 25, 2020, decreasing $31 million from $415 million, or 3.4% of net sales, during the six-month period ended September 27, 2019. The decrease reflects strong cost discipline practiced across the enterprise as well as the benefits from our distinct actions taken to temporarily reduce compensation costs across our employee base and aggressively reduce our discretionary spend levels. In addition, it reflects a refined cost structure benefiting from prior restructuring initiatives.

[0000866374-20-000030:mdna:86]
[same as prior period, unchanged from 0000866374-20-000012:mdna:83]

[0000866374-20-000030:mdna:87]
Amortization of intangible assets remains consistent at $16 million during the three-month periods ended September 25, 2020 and September 27, 2019.  During the six-month period ended September 25, 2020, amortization of intangible assets marginally declined to $31 million, from $33 million for the six-month period ended September 27, 2019, primarily due to certain intangibles now being fully amortized.

[0000866374-20-000030:mdna:88]
[same as prior period, unchanged from 0000866374-20-000012:mdna:85]

[0000866374-20-000030:mdna:89]
Interest and other, net was $22 million during the three-month period ended September 25, 2020 compared to $50 million during the three-month period ended September 27, 2019, driven by an increase of $12 million gain from higher equity in earnings recognized for certain of our non-core equity method investments in fiscal year 2021, coupled with approximately $9 million of lower expenses from our asset-backed securitization programs as we reduced outstanding balances for these programs.

[0000866374-20-000030:mdna:90]
Interest and other, net was $51 million during the six-month period ended September 25, 2020 compared to $103 million during the six-month period ended September 27, 2019. Consistent with the factors above, the increase is primarily driven by $21 million of gains from higher equity in earnings recognized for certain of our non-core equity method investments in fiscal year 2021, in addition to approximately $17 million of lower expenses from our asset-backed securitization programs as we reduced outstanding balances for these programs.

[0000866374-20-000030:mdna:91]
[same as prior period, unchanged from 0000866374-20-000012:mdna:87]

[0000866374-20-000030:mdna:92]
[same as prior period, unchanged from 0000866374-20-000012:mdna:88]

[0000866374-20-000030:mdna:93]
The consolidated effective tax rate was 26% and 25% for the three-month and six-month periods ended September 25, 2020 and (22)% and (128)% for the three-month and six-month periods ended September 27, 2019, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, India, the Netherlands and Israel. The effective tax rate for the three-month and six-month periods ended September 25, 2020 is higher than the effective tax rate for the three-month and six-month periods ended September 27, 2019, primarily due to the changing jurisdictional mix of income, and the Company's recognition of approximately $308 million in restructuring charges, impairment of non-core investment, and customer related asset impairments with minimal associated tax benefit which resulted in tax expense recorded on a U.S. GAAP loss for the six-month period ended September 27, 2019.

[0000866374-20-000030:mdna:94]
[same as prior period, unchanged from 0000866374-20-000012:mdna:91]

[0000866374-20-000030:mdna:95]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of September 25, 2020, we had cash and cash equivalents of approximately $2.4 billion and bank and other borrowings of approximately $3.8 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. We also issued $675 million of 3.750% Notes due February 2026 and $650 million of 4.875% Notes due May 2030 and repaid $433 million for the term loan due June 2022.  Refer to note 6 to the condensed consolidated financial statement for details. As of September 25, 2020, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-20-000030:mdna:96]
Cash used in operating activities was $365 million during the six-month period ended September 25, 2020, primarily driven by cash outflows related to accounts receivables as we reduced our outstanding balances on our ABS and AR factoring programs, and used proceeds from our debt funding in accordance with our revised capital strategy. These were offset by $165 million of net income for the period plus $362 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation.

[0000866374-20-000030:mdna:97]
37

[0000866374-20-000030:mdna:98]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts,  plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. Net working capital increased $1.2 billion as of September 25, 2020, from $1.4 billion as of March 31, 2020. This increase is primarily driven by a $1.4 billion increase in net receivables as we reduced our outstanding balances on our ABS and AR factoring programs as discussed above, partially offset by a $0.2 billion decrease in inventories. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended September 25, 2020, increased to 10.6% from 6.3% of annualized net sales for the quarter ended March 31, 2020 as a direct result of reducing the outstanding balance of our ABS and AR factoring programs. The Company expects to operate in this range going forward. Though we have mitigated most of the initial supplier constraints and component shortages that we had encountered in the first quarter of fiscal year 2021, we continue to operate in an unusual and dynamic environment with respect to virus-related production limitations and fluctuating demand. We expect it will take additional time to adequately drive down our inventory levels to align with the current demand environment. We are actively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative resetting our load planning.

[0000866374-20-000030:mdna:99]
Cash used in investing activities was $158 million during the six-month period ended September 25, 2020. This was primarily driven by $171 million of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Health Solutions and Industrial businesses.

[0000866374-20-000030:mdna:100]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, plus cash collections of deferred purchase price receivables, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency (refer to Part II, Item 8, note 11 of our Annual Report on Form 10-K for the fiscal year ended March 31, 2020, for discussion of the amendment of the ABS Programs). We also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation. During the first half of fiscal year 2021, we proactively and strategically utilized the proceeds of our debt issuances during the fiscal year to reduce the outstanding balance of our ABS programs. We reduced the balance on this short-term financing product by $786 million as of September 25, 2020, from $798 million as of March 31, 2020, which has the accounting effect of reducing our cash flow from operations. As this decrease in cash flow reflects the change of our capital strategy, we have added this back for our adjusted free cash flow calculation. Our adjusted free cash flows for the six-month period ended September 25, 2020 was an inflow of $252 million compared to an inflow of $301 million for the six-month period ended September 27, 2019. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-20-000030:mdna:101]
|  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |
|  | (In millions) |
| Net cash used in operating activities | $ | (365) |  |  | $ | (1,648) |  |
| Reduction in ABS levels | 786 |  |  | — |  |
| Cash collection of deferred purchase price and other | 2 |  |  | 2,167 |  |
| Purchases of property and equipment | (185) |  |  | (271) |  |
| Proceeds from the disposition of property and equipment | 14 |  |  | 53 |  |
| Adjusted free cash flow | $ | 252 |  |  | $ | 301 |  |

[0000866374-20-000030:mdna:102]
Cash provided by financing activities was $940 million during the six-month period ended September 25, 2020, which was primarily driven by $1.4 billion of proceeds received in aggregate, and net of discounts and after premiums, following the issuance of the 2026 Notes and the 2030 Notes, partially offset by $433 million cash paid for the repayment of the term loan due June 2022. For further information, see note 6 to the condensed consolidated financial statements.

[0000866374-20-000030:mdna:103]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of September 25, 2020, and March 31, 2020, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although

[0000866374-20-000030:mdna:104]
38

[0000866374-20-000030:mdna:105]
substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.4 billion as of March 31, 2020). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-20-000030:mdna:106]
[same as prior period, unchanged from 0000866374-20-000012:mdna:102]

[0000866374-20-000030:mdna:107]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs amounted to approximately $0.2 billion and $0.5 billion for the three and six-month periods ended September 25, 2020, respectively, and approximately $0.2 billion and $0.3 billion for the three and six-month periods ended September 27, 2019, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-20-000030:mdna:108]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to commercial paper program, and revolving sale and repurchase of subordinated note established under the securitization facility, under which there were no borrowings outstanding as of September 25, 2020.

[0000866374-20-000030:mdna:109]
[same as prior period, unchanged from 0000866374-20-000012:mdna:105]

[0000866374-20-000030:mdna:110]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-20-000030:mdna:111]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 7, 2020. During the six-month period ended September 25, 2020, there were no purchases of our ordinary shares made by us. As of September 25, 2020, shares in the aggregate amount of $500 million were available to be repurchased under the current plan.

[0000866374-20-000030:mdna:112]
[same as prior period, unchanged from 0000866374-20-000012:mdna:108]

[0000866374-20-000030:mdna:113]
[same as prior period, unchanged from 0000866374-20-000012:mdna:109]

[0000866374-20-000030:mdna:114]
During the first half of fiscal year 2021, we issued $675 million of 3.750% Notes due February 2026 and $650 million of 4.875% Notes due May 2030 and repaid $433 million for the term loan due June 2022.

[0000866374-20-000030:mdna:115]
[same as prior period, unchanged from 0000866374-20-000012:mdna:111]

[0000866374-20-000030:mdna:116]
39

[0000866374-20-000030:mdna:117]
[same as prior period, unchanged from 0000866374-20-000012:mdna:112]

[0000866374-20-000030:mdna:118]
As of September 25, 2020, and March 31, 2020, the outstanding balance on receivables sold for cash was $0.2 billion and $1.2 billion, respectively, under our asset-backed securitization programs and accounts receivable factoring program, which were removed from accounts receivable balances in our condensed consolidated balance sheets. For further information, see note 10 to the condensed consolidated financial statements.
