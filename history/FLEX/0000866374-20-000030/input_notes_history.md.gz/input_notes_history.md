# FLEX note change history — 0000866374-20-000012 → 0000866374-20-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0000866374-20-000030:note_history:1]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor agreed to an immaterial settlement.
  (was, 2020-08-05, similarity 0.98):
[0000866374-20-000012:note_history:1]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions and have agreed in principle to an immaterial settlement.

- changed (2020-11-02):
[0000866374-20-000030:note_history:2]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. The motion has been fully briefed and defendants’ motion to dismiss is set for hearing on December 3, 2020. The Company believes that the claims are without merit and intends to vigorously defend this case.
  (was, 2020-08-05, similarity 0.9028):
[0000866374-20-000012:note_history:2]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, Defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted Defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, Defendants filed a motion to dismiss the amended complaint. Defendants’ motion to dismiss is set for hearing on December 3, 2020. The Company believes that the claims are without merit and intends to vigorously defend this case.

- changed (2020-11-02):
[0000866374-20-000030:note_history:3]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a
  (was, 2020-08-05, similarity 0.7842):
[0000866374-20-000012:note_history:3]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible

- changed (2020-11-02):
[0000866374-20-000030:note_history:4]
period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.
  (was, 2020-08-05, similarity 0.7389):
[0000866374-20-000012:note_history:4]
contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- changed (2020-11-02):
[0000866374-20-000030:note_history:5]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling 373.7 million Brazilian reals (approximately USD $67.3 million based on the exchange rate as of September 25, 2020). Four of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60.5 million Brazilian reals or USD $10.9 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Sao Paolo, Brazil on March 23, 2020; the value of that assessment is 33.9 million Brazilian reals (approximately USD $6.1 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.
  (was, 2020-08-05, similarity 0.9909):
[0000866374-20-000012:note_history:5]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling 373.7 million Brazilian reals (approximately USD $71.1 million based on the exchange rate as of June 26, 2020). Four of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60.5 million Brazilian reals or USD $11.5 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Sao Paolo, Brazil on March 23, 2020; the value of that assessment is 33.9 million Brazilian reals (approximately USD $6.4 million). The Company believes there is no legal basis for any of these assessments and has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

- added (2020-11-02):
[0000866374-20-000030:note_history:6]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2020-11-02):
[0000866374-20-000012:note_history:7]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter which is ongoing. The Company expects to complete the investigation and report to OFAC by the end of the second quarter of fiscal year 2021, and it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0000866374-20-000030:note_history:8]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure;
  (was, 2020-08-05, similarity 0.9924):
[0000866374-20-000012:note_history:8]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure.

- changed (2020-11-02):
[0000866374-20-000030:note_history:9]
◦Consumer Devices, including mobile and high velocity consumer devices.
  (was, 2020-08-05, similarity 0.9859):
[0000866374-20-000012:note_history:9]
◦Consumer Devices, including mobile and high velocity consumer devices;

- changed (2020-11-02):
[0000866374-20-000030:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2020 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and six-month periods ended September 25, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021. Beginning in the second quarter of fiscal year 2021, the Company began reporting all dollar amounts in millions. In certain circumstances, this change in rounding resulted in line items being removed within prior year disclosures. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.
  (was, 2020-08-05, similarity 0.7115):
[0000866374-20-000012:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2020 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month periods ended June 26, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021.

- changed (2020-11-02):
[0000866374-20-000030:note_history:11]
The first quarters for fiscal years 2021 and 2020 ended on June 26, 2020, which is comprised of 87 days in the period, and June 28, 2019, which is comprised of 89 days in the period, respectively. The second quarters for fiscal years 2021 and 2020 ended on September 25, 2020 and September 27, 2019, which are comprised of 91 days in both periods.
  (was, 2020-08-05, similarity 0.7258):
[0000866374-20-000012:note_history:11]
The first quarters for fiscal years 2021 and 2020 ended on June 26, 2020, which is comprised of 87 days in the period, and June 28, 2019, which is comprised of 89 days in the period, respectively.

- changed (2020-11-02):
[0000866374-20-000030:note_history:12]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not
  (was, 2020-08-05, similarity 0.8648):
[0000866374-20-000012:note_history:12]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

- added (2020-11-02):
[0000866374-20-000030:note_history:13]
material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

- changed (2020-11-02):
[0000866374-20-000030:note_history:14]
The changes to the Company’s organizational structure noted above had no impact on the condensed consolidated financial statements. For comparability purposes, segment reporting for prior periods have been restated to conform to the current presentation. Refer to note 14, “Segment Reporting,” for additional information on the changes in operating and reportable segments.
  (was, 2020-08-05, similarity 0.7791):
[0000866374-20-000012:note_history:14]
The changes to the Company’s organizational structure noted above had no impact to the condensed consolidated financial statements. For comparability purposes, segment reporting for prior periods have been restated to conform to the current

- changed (2020-11-02):
[0000866374-20-000030:note_history:15]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, including highly liquid investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2020-08-05, similarity 0.8517):
[0000866374-20-000012:note_history:15]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments including highly liquid investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rate in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- removed (2020-11-02):
[0000866374-20-000012:note_history:16]
presentation. Refer to note 14, “Segments Reporting,” for additional information on the changes in operating and reportable segments.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0000866374-20-000030:note_history:17]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 25, 2020 are as follows:
  (was, 2020-08-05, similarity 0.9463):
[0000866374-20-000012:note_history:17]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 26, 2020 are as follows:

- changed (2020-11-02):
[0000866374-20-000030:note_history:18]
|  | As of September 25, 2020 |  | As of March 31, 2020 |
|  | (In millions) |
| Term Loan, including current portion, due in installments through June 2022 | — |  |  | 433 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 318 |  |  | 310 |  |
| 4.750% Notes due June 2025 | 597 |  |  | 597 |  |
| 3.750% Notes due February 2026 | 696 |  |  | — |  |
| 4.875% Notes due June 2029 | 661 |  |  | 662 |  |
| 4.875% Notes due May 2030 | 696 |  |  | — |  |
| India Facilities | 138 |  |  | 138 |  |
| Other | 220 |  |  | 211 |  |
| Debt issuance costs | (24) |  |  | (13) |  |
|  | 3,802 |  |  | 2,838 |  |
| Current portion, net of debt issuance costs | (63) |  |  | (149) |  |
| Non-current portion | $ | 3,739 |  |  | $ | 2,689 |  |
  (was, 2020-08-05, similarity 0.9512):
[0000866374-20-000012:note_history:18]
|  | As of June 26, 2020 |  | As of March 31, 2020 |
|  | (In thousands) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | 433,406 |  |  | 433,406 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 313,596 |  |  | 310,115 |  |
| 4.750% Notes due June 2025 | 597,380 |  |  | 597,265 |  |
| 3.750% Notes due February 2026 | 423,411 |  |  | — |  |
| 4.875% Notes due June 2029 | 661,610 |  |  | 661,908 |  |
| 4.875% Notes due May 2030 | 323,595 |  |  | — |  |
| India Facilities | 138,238 |  |  | 138,238 |  |
| Other | 213,881 |  |  | 210,684 |  |
| Debt issuance costs | (19,668) |  |  | (13,377) |  |
|  | 3,585,449 |  |  | 2,838,239 |  |
| Current portion, net of debt issuance costs | (162,287) |  |  | (149,130) |  |
| Non-current portion | $ | 3,423,162 |  |  | $ | 2,689,109 |  |

- changed (2020-11-02):
[0000866374-20-000030:note_history:19]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.0% as of September 25, 2020 and March 31, 2020, respectively.
  (was, 2020-08-05, similarity 0.9565):
[0000866374-20-000012:note_history:19]
The weighted-average interest rate for the Company's long-term debt was 3.8% and 4.0% as of June 26, 2020 and March 31, 2020, respectively.

- changed (2020-11-02):
[0000866374-20-000030:note_history:20]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 25, 2020 are as follows:
  (was, 2020-08-05, similarity 0.9479):
[0000866374-20-000012:note_history:20]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 26, 2020 are as follows:

- changed (2020-11-02):
[0000866374-20-000030:note_history:21]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2021 (1) |  | $ | 56 |  |
| 2022 |  | 216 |  |
| 2023 |  | 531 |  |
| 2024 |  | 53 |  |
| 2025 |  | 318 |  |
| Thereafter |  | 2,652 |  |
| Total |  | $ | 3,826 |  |
  (was, 2020-08-05, similarity 0.9705):
[0000866374-20-000012:note_history:21]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2021 (1) |  | $ | 149,983 |  |
| 2022 |  | 212,255 |  |
| 2023 |  | 870,178 |  |
| 2024 |  | 53,109 |  |
| 2025 |  | 313,596 |  |
| Thereafter |  | 2,005,996 |  |
| Total |  | $ | 3,605,117 |  |

- changed (2020-11-02):
[0000866374-20-000030:note_history:22]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2021.
  (was, 2020-08-05, similarity 0.9733):
[0000866374-20-000012:note_history:22]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2021.

- added (2020-11-02):
[0000866374-20-000030:note_history:23]
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026 (the "Existing 2026 Notes"), at 99.617% of face value and $325 million aggregate principal amount of 4.875% Notes due May 2030 (the "Existing 2030 Notes" and, together with the Existing 2026 Notes, the "Existing Notes"), at 99.562% of face value. In August 2020, as a further issuance of the Existing Notes, the Company issued under the same terms (other than the initial interest accrual date and first interest payment date for the additional 2026 Notes, and the initial offering price and the issue date for the additional 2026 and 2030 Notes), an additional $250 million of 3.750% Notes due February 2026 (together with the "Existing 2026 Notes" above, the "2026 Notes"), at 109.294% of face value, and $325 million of 4.875% Notes due May 2030 (together with the "Existing 2030 Notes" above, the "2030 Notes"), at 114.863% of face value. Immediately after the issuance of the additional notes issued in August 2020, the Company has $675 million aggregate principal amount of 3.750% Notes due 2026 outstanding and $650 million aggregate principal amount of 4.875% Notes due 2030 outstanding. The Company received in aggregate, proceeds of approximately $1.4 billion, net of discounts and after premiums, from the issuances, which have been used for working capital and other general corporate purposes, in addition to repaying the term loan due June 2022. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet approximately $12.8 million of costs in conjunction with the issuance of the Notes.

- changed (2020-11-02):
[0000866374-20-000030:note_history:24]
Interest on the 2026 Notes and the 2030 Notes is payable semi-annually, commencing on August 1, 2020 and November 12, 2020, respectively, except that interest on the additional 2026 Notes is payable commencing February 1, 2021. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2026 Notes or 2030 Notes may declare all of such series of Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of such series of Notes. As of September 25, 2020, the Company was in compliance with the covenants in the indenture governing the Notes.
  (was, 2020-08-05, similarity 0.883):
[0000866374-20-000012:note_history:24]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of 
default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2026 Notes or 2030 Notes may declare all of such series of Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of such series of Notes. As of June 26, 2020, the Company was in compliance with the covenants in the indenture governing the Notes.

- removed (2020-11-02):
[0000866374-20-000012:note_history:25]
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026 (the "2026 Notes"), at 99.617% of face value and $325 million aggregate principal amount of 4.875% Notes due May 2020 (the "2030 Notes" and , together with the 2026 Notes, the " Notes"), at 99.562% of face value. The Company received in aggregate, proceeds of approximately $747 million, net of discount, from the issuance which were used for working capital and other general corporate purposes. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet approximately $7.1 million of costs in conjunction with the issuance of the Notes.

- removed (2020-11-02):
[0000866374-20-000012:note_history:26]
Interest on the 2026 Notes and the 2030 Notes is payable semi-annually, commencing on August 1, 2020 and November 12, 2020, respectively. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0000866374-20-000030:note_history:27]
|  | As of September 25, 2020 |  | As of March 31, 2020 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | $ | — |  |  | $ | — |  |  | $ | 433 |  |  | $ | 414 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500 |  |  | 545 |  |  | 500 |  |  | 500 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 318 |  |  | 318 |  |  | 310 |  |  | 310 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597 |  |  | 675 |  |  | 597 |  |  | 613 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 696 |  |  | 760 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 661 |  |  | 760 |  |  | 662 |  |  | 628 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 696 |  |  | 795 |  |  | — |  |  | — |  |  | Level 1 |
| Euro Term Loans | 167 |  |  | 167 |  |  | 208 |  |  | 208 |  |  | Level 2 |
| India Facilities | 138 |  |  | 138 |  |  | 138 |  |  | 138 |  |  | Level 2 |
  (was, 2020-08-05, similarity 0.934):
[0000866374-20-000012:note_history:27]
|  | As of June 26, 2020 |  |  |  | As of March 31, 2020 |  |  |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |  |  |  |  |  |  |  |  |
| Term Loan, including current portion, due in installments through June 2022 | 433,406 |  |  | 433,363 |  |  | 433,406 |  |  | 413,903 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 535,591 |  |  | 500,000 |  |  | 499,710 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 313,596 |  |  | 313,596 |  |  | 310,115 |  |  | 310,115 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597,380 |  |  | 663,623 |  |  | 597,265 |  |  | 613,152 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 423,411 |  |  | 449,958 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 661,610 |  |  | 734,043 |  |  | 661,908 |  |  | 628,419 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 323,595 |  |  | 358,899 |  |  | — |  |  | — |  |  | Level 1 |
| Euro Term Loans | 212,678 |  |  | 212,678 |  |  | 207,646 |  |  | 207,646 |  |  | Level 2 |
| India Facilities | 138,238 |  |  | 138,238 |  |  | 138,238 |  |  | 138,238 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0000866374-20-000030:note_history:28]
Bank borrowings and long-term debt as of September 25, 2020 are as follows:
  (was, 2020-08-05, similarity 0.9185):
[0000866374-20-000012:note_history:28]
Bank borrowings and long-term debt as of June 26, 2020 are as follows:

- changed (2020-11-02):
[0000866374-20-000030:note_history:29]
|  | As of September 25, 2020 |  | As of March 31, 2020 |
|  | (In millions) |
| Term Loan, including current portion, due in installments through June 2022 | — |  |  | 433 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 318 |  |  | 310 |  |
| 4.750% Notes due June 2025 | 597 |  |  | 597 |  |
| 3.750% Notes due February 2026 | 696 |  |  | — |  |
| 4.875% Notes due June 2029 | 661 |  |  | 662 |  |
| 4.875% Notes due May 2030 | 696 |  |  | — |  |
| India Facilities | 138 |  |  | 138 |  |
| Other | 220 |  |  | 211 |  |
| Debt issuance costs | (24) |  |  | (13) |  |
|  | 3,802 |  |  | 2,838 |  |
| Current portion, net of debt issuance costs | (63) |  |  | (149) |  |
| Non-current portion | $ | 3,739 |  |  | $ | 2,689 |  |
  (was, 2020-08-05, similarity 0.9512):
[0000866374-20-000012:note_history:29]
|  | As of June 26, 2020 |  | As of March 31, 2020 |
|  | (In thousands) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | 433,406 |  |  | 433,406 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 313,596 |  |  | 310,115 |  |
| 4.750% Notes due June 2025 | 597,380 |  |  | 597,265 |  |
| 3.750% Notes due February 2026 | 423,411 |  |  | — |  |
| 4.875% Notes due June 2029 | 661,610 |  |  | 661,908 |  |
| 4.875% Notes due May 2030 | 323,595 |  |  | — |  |
| India Facilities | 138,238 |  |  | 138,238 |  |
| Other | 213,881 |  |  | 210,684 |  |
| Debt issuance costs | (19,668) |  |  | (13,377) |  |
|  | 3,585,449 |  |  | 2,838,239 |  |
| Current portion, net of debt issuance costs | (162,287) |  |  | (149,130) |  |
| Non-current portion | $ | 3,423,162 |  |  | $ | 2,689,109 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0000866374-20-000030:note_history:30]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 25, 2020 are as follows:
  (was, 2020-08-05, similarity 0.9479):
[0000866374-20-000012:note_history:30]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 26, 2020 are as follows:

- changed (2020-11-02):
[0000866374-20-000030:note_history:31]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2021 (1) |  | $ | 56 |  |
| 2022 |  | 216 |  |
| 2023 |  | 531 |  |
| 2024 |  | 53 |  |
| 2025 |  | 318 |  |
| Thereafter |  | 2,652 |  |
| Total |  | $ | 3,826 |  |
  (was, 2020-08-05, similarity 0.9705):
[0000866374-20-000012:note_history:31]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In thousands) |
| 2021 (1) |  | $ | 149,983 |  |
| 2022 |  | 212,255 |  |
| 2023 |  | 870,178 |  |
| 2024 |  | 53,109 |  |
| 2025 |  | 313,596 |  |
| Thereafter |  | 2,005,996 |  |
| Total |  | $ | 3,605,117 |  |

- changed (2020-11-02):
[0000866374-20-000030:note_history:32]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2021.
  (was, 2020-08-05, similarity 0.9733):
[0000866374-20-000012:note_history:32]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2021.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0000866374-20-000030:note_history:33]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended September 25, 2020 and September 27, 2019, respectively.
  (was, 2020-08-05, similarity 0.8199):
[0000866374-20-000012:note_history:33]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 26, 2020 and June 28, 2019 (in thousands), respectively.

- added (2020-11-02):
[0000866374-20-000030:note_history:34]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,823 |  |  | $ | 2,987 |  |  | $ | 5,269 |  |  | $ | 5,956 |  |
| Over time | 495 |  |  | 596 |  |  | 961 |  |  | 1,535 |  |
| Total | 3,318 |  |  | 3,583 |  |  | 6,230 |  |  | 7,491 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,779 |  |  | 1,597 |  |  | 3,103 |  |  | 3,050 |  |
| Over time | 888 |  |  | 908 |  |  | 1,805 |  |  | 1,723 |  |
| Total | 2,667 |  |  | 2,505 |  |  | 4,908 |  |  | 4,773 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,602 |  |  | 4,584 |  |  | 8,372 |  |  | 9,006 |  |
| Over time | 1,383 |  |  | 1,504 |  |  | 2,766 |  |  | 3,258 |  |
| Total | $ | 5,985 |  |  | $ | 6,088 |  |  | $ | 11,138 |  |  | $ | 12,264 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0000866374-20-000030:note_history:35]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of
  (was, 2020-08-05, similarity 0.7426):
[0000866374-20-000012:note_history:35]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion

- added (2020-11-02):
[0000866374-20-000030:note_history:36]
costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- changed (2020-11-02):
[0000866374-20-000030:note_history:37]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $354.9 million and $361.5 million as of September 25, 2020 and March 31, 2020, respectively.
  (was, 2020-08-05, similarity 0.9807):
[0000866374-20-000012:note_history:37]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $362.1 million and $361.5 million as of June 26, 2020 and March 31, 2020, respectively.

- added (2020-11-02):
[0000866374-20-000030:note_history:38]
Disaggregation of Revenue

- changed (2020-11-02):
[0000866374-20-000030:note_history:39]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and six-month periods ended September 25, 2020 and September 27, 2019, respectively.
  (was, 2020-08-05, similarity 0.7723):
[0000866374-20-000012:note_history:39]
Disaggregation of Revenue
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 26, 2020 and June 28, 2019 (in thousands), respectively.

- added (2020-11-02):
[0000866374-20-000030:note_history:40]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2020 |  | September 27, 2019 |  | September 25, 2020 |  | September 27, 2019 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,823 |  |  | $ | 2,987 |  |  | $ | 5,269 |  |  | $ | 5,956 |  |
| Over time | 495 |  |  | 596 |  |  | 961 |  |  | 1,535 |  |
| Total | 3,318 |  |  | 3,583 |  |  | 6,230 |  |  | 7,491 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,779 |  |  | 1,597 |  |  | 3,103 |  |  | 3,050 |  |
| Over time | 888 |  |  | 908 |  |  | 1,805 |  |  | 1,723 |  |
| Total | 2,667 |  |  | 2,505 |  |  | 4,908 |  |  | 4,773 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,602 |  |  | 4,584 |  |  | 8,372 |  |  | 9,006 |  |
| Over time | 1,383 |  |  | 1,504 |  |  | 2,766 |  |  | 3,258 |  |
| Total | $ | 5,985 |  |  | $ | 6,088 |  |  | $ | 11,138 |  |  | $ | 12,264 |  |

- removed (2020-11-02):
[0000866374-20-000012:note_history:41]
of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.
