# FLEX notes — 0000866374-25-000051


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-25-000051:notes:1]
[same as prior period, unchanged from 0000866374-25-000043:notes:1]

[0000866374-25-000051:notes:2]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, and power. As of September 26, 2025, Flex's two operating and reportable segments were as follows:

[0000866374-25-000051:notes:3]
[same as prior period, unchanged from 0000866374-25-000043:notes:3]

[0000866374-25-000051:notes:4]
[same as prior period, unchanged from 0000866374-25-000043:notes:4]

[0000866374-25-000051:notes:5]
[same as prior period, unchanged from 0000866374-25-000043:notes:5]

[0000866374-25-000051:notes:6]
[same as prior period, unchanged from 0000866374-25-000043:notes:6]

[0000866374-25-000051:notes:7]
[same as prior period, unchanged from 0000866374-25-000043:notes:7]

[0000866374-25-000051:notes:8]
◦Industrial, including industrial devices, capital equipment, renewables, critical power, and embedded power

[0000866374-25-000051:notes:9]
[same as prior period, unchanged from 0000866374-25-000043:notes:9]

[0000866374-25-000051:notes:10]
[same as prior period, unchanged from 0000866374-25-000043:notes:10]

[0000866374-25-000051:notes:11]
[same as prior period, unchanged from 0000866374-25-000043:notes:11]

[0000866374-25-000051:notes:12]
[same as prior period, unchanged from 0000866374-25-000043:notes:12]

[0000866374-25-000051:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2025 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 26, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026.

[0000866374-25-000051:notes:14]
The first quarters for fiscal years 2026 and 2025 ended on June 27, 2025, which is comprised of 88 days in the period, and June 28, 2024, which is comprised of 89 days, respectively. The second quarters for fiscal years 2026 and 2025 ended on September 26, 2025 and September 27, 2024, respectively, which are comprised of 91 days in both periods.

[0000866374-25-000051:notes:15]
[same as prior period, unchanged from 0000866374-25-000043:notes:15]

[0000866374-25-000051:notes:16]
[same as prior period, unchanged from 0000866374-25-000043:notes:16]

[0000866374-25-000051:notes:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are

[0000866374-25-000051:notes:18]
used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; valuation of warrants, and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas conflict, and other geopolitical conflicts) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-25-000051:notes:19]
Impact of Missile Strike in Ukraine

[0000866374-25-000051:notes:20]
During the three months ended September 26, 2025, the Company recognized $23 million of long-lived asset impairments, $13 million of inventory write-downs and $5 million of other charges as a result of a missile strike on its Mukachevo, Ukraine facility in Western Ukraine on August 21, 2025. The missile strike represents an unusual and infrequent event as hostilities related to the Russian invasion of Ukraine have been primarily focused in Eastern Ukraine. The missile strike caused substantial physical damage and disrupted normal operations at the facility. In response, the Company activated contingency manufacturing plans and transitioned production to alternative facilities. As restoration activities progress in Mukachevo, the Company expects to incur additional immaterial near-term inefficiencies. The total $41 million expense is included in restructuring and impairment charges in the condensed consolidated statements of operations.

[0000866374-25-000051:notes:21]
Recently Issued Accounting Pronouncements

[0000866374-25-000051:notes:22]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and income taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

[0000866374-25-000051:notes:23]
In November 2024, the FASB issued ASU 2024-03 "Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses", which requires public entities to disclose specified information about certain costs and expenses. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2028 and will be applied retrospectively to all prior periods presented on its consolidated financial statements. The Company is currently evaluating the guidance to determine the impact on the Company's disclosures. In January 2025, the FASB issued ASU 2025-01 on the same topic to clarify the amendments for ASU 2024-03 are effective for the Company in the fourth quarter of fiscal year 2028.

[0000866374-25-000051:notes:24]
In September 2025, the FASB issued ASU 2025-06 "Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40)", which eliminates prescriptive software development stages, requiring capitalization upon funding authorization and commitment. Additionally, the ASU clarifies the scope for capitalization and supersedes website development guidance. The guidance is effective for the Company beginning in the first quarter of fiscal year 2029. The Company is currently evaluating the guidance to determine the method of adoption and impact on the Company's disclosures.

[0000866374-25-000051:notes:25]
Recently Adopted Accounting Pronouncements

[0000866374-25-000051:notes:26]
In July 2025, the FASB issued ASU 2025-05 "Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets", which provides for the use of a new practical expedient when estimating expected credit losses for accounts receivable and contract assets arising from transactions accounted for under Topic 606 that assumes that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for the Company, and has been adopted, beginning in the second quarter of fiscal year 2026.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-25-000051:notes:27]
[same as prior period, unchanged from 0000866374-25-000043:notes:22]

[0000866374-25-000051:notes:28]
[same as prior period, unchanged from 0000866374-25-000043:notes:23]

[0000866374-25-000051:notes:29]
|  | As of September 26, 2025 |  | As of March 31, 2025 |
|  | (In millions) |
| Raw materials | $ | 4,189 |  |  | $ | 4,092 |  |
| Work-in-progress | 536 |  |  | 485 |  |
| Finished goods | 545 |  |  | 494 |  |
|  | $ | 5,270 |  |  | $ | 5,071 |  |

[0000866374-25-000051:notes:30]
In addition to the Flex controlled inventory shown above, the Company held inventory controlled by customers of $768 million and $416 million as of September 26, 2025 and March 31, 2025, respectively. This amount is reported in other current assets in the condensed consolidated balance sheets.

[0000866374-25-000051:notes:31]
[same as prior period, unchanged from 0000866374-25-000043:notes:25]

[0000866374-25-000051:notes:32]
During the six-month period ended September 26, 2025, goodwill increased by $34 million with $8 million from an acquisition completed in the first quarter of fiscal year 2026 and currency impacts of $26 million. See note 12 for further details.

[0000866374-25-000051:notes:33]
[same as prior period, unchanged from 0000866374-25-000043:notes:27]

[0000866374-25-000051:notes:34]
|  | As of September 26, 2025 |  | As of March 31, 2025 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 317 |  |  | $ | (137) |  |  | $ | 180 |  |  | $ | 383 |  |  | $ | (186) |  |  | $ | 197 |  |
| Licenses and other intangibles | 199 |  |  | (65) |  |  | 134 |  |  | 365 |  |  | (219) |  |  | 146 |  |
| Total | $ | 516 |  |  | $ | (202) |  |  | $ | 314 |  |  | $ | 748 |  |  | $ | (405) |  |  | $ | 343 |  |

[0000866374-25-000051:notes:35]
[same as prior period, unchanged from 0000866374-25-000043:notes:29]

[0000866374-25-000051:notes:36]
[same as prior period, unchanged from 0000866374-25-000043:notes:30]

[0000866374-25-000051:notes:37]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2026 (1) |  | $ | 31 |  |
| 2027 |  | 58 |  |
| 2028 |  | 44 |  |
| 2029 |  | 41 |  |
| 2030 |  | 36 |  |
| Thereafter |  | 104 |  |
| Total amortization expense |  | $ | 314 |  |

[0000866374-25-000051:notes:38]
(1)Represents estimated amortization for the remaining six-month period of the fiscal year ending March 31, 2026.

[0000866374-25-000051:notes:39]
[same as prior period, unchanged from 0000866374-25-000043:notes:33]

[0000866374-25-000051:notes:40]
Customer working capital advances were $1.5 billion and $1.6 billion as of September 26, 2025 and March 31, 2025, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-25-000051:notes:41]
[same as prior period, unchanged from 0000866374-25-000043:notes:35]

[0000866374-25-000051:notes:42]
Other non-current assets include deferred tax assets of $575 million and $577 million as of September 26, 2025 and March 31, 2025, respectively.

[0000866374-25-000051:notes:43]
[same as prior period, unchanged from 0000866374-25-000043:notes:37]

[0000866374-25-000051:notes:44]
Other current liabilities include customer-related accruals of $304 million and $246 million as of September 26, 2025 and March 31, 2025, respectively.

[0000866374-25-000051:notes:45]
[same as prior period, unchanged from 0000866374-25-000043:notes:39]

[0000866374-25-000051:notes:46]
[same as prior period, unchanged from 0000866374-25-000043:notes:40]

[0000866374-25-000051:notes:47]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of September 26, 2025 and March 31, 2025 were $136 million and $119 million, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-25-000051:notes:48]
[same as prior period, unchanged from 0000866374-25-000043:notes:42]

[0000866374-25-000051:notes:49]
A contract asset is recognized when the Company has recognized revenue but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional and invoiced.

[0000866374-25-000051:notes:50]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $429 million and $377 million as of September 26, 2025 and March 31, 2025, respectively, of which $392 million and $347 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-25-000051:notes:51]
Warrant

[0000866374-25-000051:notes:52]
During the quarter ended September 26, 2025, the Company issued a warrant (“the Warrant”) to a customer for the purchase of up to an aggregate of approximately 3.9 million ordinary shares of the Company ("Warrant Shares"). The Warrant Shares vest based on qualifying payments (as defined in the Warrant) for the purchase of all products and services over the term of the Warrant and are recognized as a deduction to revenue as qualifying revenues are recognized. Refer to “Note 4 – Share-Based Compensation and Warrants” for further information.

[0000866374-25-000051:notes:53]
[same as prior period, unchanged from 0000866374-25-000043:notes:46]

[0000866374-25-000051:notes:54]
[same as prior period, unchanged from 0000866374-25-000043:notes:47]

[0000866374-25-000051:notes:55]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,874 |  |  | $ | 2,924 |  |  | $ | 5,769 |  |  | $ | 5,797 |  |
| Over time | 892 |  |  | 682 |  |  | 1,688 |  |  | 1,174 |  |
| Total | 3,766 |  |  | 3,606 |  |  | 7,457 |  |  | 6,971 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,970 |  |  | 2,237 |  |  | 3,829 |  |  | 4,870 |  |
| Over time | 1,068 |  |  | 702 |  |  | 2,093 |  |  | 1,018 |  |
| Total | 3,038 |  |  | 2,939 |  |  | 5,922 |  |  | 5,888 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,844 |  |  | 5,161 |  |  | 9,598 |  |  | 10,667 |  |
| Over time | 1,960 |  |  | 1,384 |  |  | 3,781 |  |  | 2,192 |  |
| Total | $ | 6,804 |  |  | $ | 6,545 |  |  | $ | 13,379 |  |  | $ | 12,859 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-25-000051:notes:56]
SHARE-BASED COMPENSATION AND WARRANTS
Flex historically maintains share-based compensation plans at the corporate level. The Company grants equity compensation awards under its 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-25-000051:notes:57]
[same as prior period, unchanged from 0000866374-25-000043:notes:50]

[0000866374-25-000051:notes:58]
[same as prior period, unchanged from 0000866374-25-000043:notes:51]

[0000866374-25-000051:notes:59]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
|  | (In millions) |
| Cost of sales | $ | 9 |  |  | $ | 8 |  |  | $ | 17 |  |  | $ | 16 |  |
| Selling, general and administrative expenses | 28 |  |  | 20 |  |  | 54 |  |  | 44 |  |
| Total share-based compensation expense | $ | 37 |  |  | $ | 28 |  |  | $ | 71 |  |  | $ | 60 |  |

[0000866374-25-000051:notes:60]
[same as prior period, unchanged from 0000866374-25-000043:notes:53]

[0000866374-25-000051:notes:61]
During the six-month period ended September 26, 2025, the Company granted approximately 4.3 million restricted share unit ("RSU") awards. Of this amount, approximately 2.0 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, with an average grant date price of $43.92 per award. In addition, approximately 1.0 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, with an average grant date price of $45.09 per award. These performance-based RSUs include awards tied to the Company's adjusted earnings per share growth and awards tied to operating profit goals. The number of shares that will ultimately vest will range from zero up to a maximum of approximately 2.4 million based on the level of achievement of these performance conditions. The awards will cliff vest after a period of three years, depending on the specific performance metrics, to the extent such performance conditions have been met. Further, approximately 0.2 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards that are contingent on certain market conditions was estimated to be $58.55 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 0.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met. The remaining balance of approximately 1.1 million represents the number of shares issued upon the vesting of RSU awards above target levels based on the achievement of certain market and performance conditions for awards granted in fiscal year 2023. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-25-000051:notes:62]
As of September 26, 2025, approximately 9.7 million unvested RSU awards under the 2017 Plan were outstanding, of which vesting for a targeted amount of approximately 0.8 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of approximately 1.7 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to approximately 1.7 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to approximately 3.9 million based on the achievement levels. During the six-month period ended September 26, 2025, approximately 2.3 million shares vested in connection with the awards with market and performance conditions granted in fiscal year 2023.

[0000866374-25-000051:notes:63]
As of September 26, 2025, total unrecognized compensation expense related to unvested RSU awards under the 2017 Plan was approximately $265 million and will be recognized over a weighted-average remaining vesting period of 2.2 years.

[0000866374-25-000051:notes:64]
On August 15, 2025, the Company issued the Warrant to Amazon.com NV Investment Holdings LLC (“Warrantholder”), a wholly-owned subsidiary of Amazon.com, Inc. ("Parent") to purchase up to an aggregate of 3,859,851 Warrant Shares at an exercise price of $51.29 per share, which is the preceding 30 trading days Volume-Weighted Average Price. The Warrant allows for cashless exercise and expires on August 15, 2030; however, if there are unexercised Warrant Shares as of the expiration date, and the Company and Warrantholder maintain a continued commercial relationship, the Company shall negotiate in good faith with Warrantholder to agree to issue to Warrantholder a new two-year warrant as of the expiration date that provides the same exercise price and other terms for vested and unexercised Warrant Shares, that also takes into account the commercial relationship in effect at such time. The Warrant Shares are subject to vesting based on qualifying payments (as defined in the Warrant) for the purchase of all products and services by or on behalf of Parent and its affiliates over the term of the Warrant. Upon the consummation of an acquisition transaction (as defined in the related transaction agreement), subject to a specified condition, the unvested portion of the Warrant will vest in full. So long as the Warrant is unexercised, the Warrant does not entitle Warrantholder to any voting rights or any other shareholder rights. The exercise price and the number of Warrant Shares are subject to customary anti-dilution adjustments. The expense associated with the Warrant Shares will be recorded as a deduction to revenue as the customer purchases products and services over the vesting period.

[0000866374-25-000051:notes:65]
The estimated fair value of the Warrant was determined as of the issuance date, using the Black-Scholes option pricing model. The following assumptions were used in the model:

[0000866374-25-000051:notes:66]
|  | As of August 15, 2025 |
| Expected volatility | 45.8 | % |
| Expected dividend yield | — | % |
| Expected life | 7 years |
| Risk-free interest rate | 4.0 | % |

[0000866374-25-000051:notes:67]
The calculated fair value of each Warrant Share at the issuance date was $25.47. The Company recorded charges of $2 million during the three months ended September 26, 2025. No Warrant Shares vested, or were exercised, during the three months ended September 26, 2025.


## us-gaap:EarningsPerShareTextBlock

[0000866374-25-000051:notes:68]
[same as prior period, unchanged from 0000866374-25-000043:notes:58]

[0000866374-25-000051:notes:69]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
|  | (In millions, except per share amounts) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 199 |  |  | $ | 214 |  |  | $ | 391 |  |  | $ | 353 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding - basic | 374 |  |  | 394 |  |  | 374 |  |  | 398 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 6 |  |  | 6 |  |  | 7 |  |  | 7 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding - diluted | 380 |  |  | 400 |  |  | 381 |  |  | 405 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.53 |  |  | $ | 0.54 |  |  | $ | 1.05 |  |  | $ | 0.89 |  |
| Diluted | $ | 0.52 |  |  | $ | 0.54 |  |  | $ | 1.03 |  |  | $ | 0.87 |  |

[0000866374-25-000051:notes:70]
(1)An immaterial amount of RSU awards for the three and six-month periods ended September 26, 2025, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. An immaterial amount of RSU awards and 1.9 million RSU awards for the three and six-month periods ended September 27, 2024, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-25-000051:notes:71]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 26, 2025 and March 31, 2025 are as follows:

[0000866374-25-000051:notes:72]
|  | Maturity Date |  | As of September 26, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | — |  |  | $ | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 676 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 673 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 300 |  |  | 269 |  |
| Debt issuance costs |  |  | (12) |  |  | (14) |  |
|  |  |  | 3,689 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (676) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,013 |  |  | $ | 2,483 |  |

[0000866374-25-000051:notes:73]
(1)The notes are carried at the principal amount of each note less any unamortized discount and unamortized debt issuance costs and inclusive of any unamortized premium. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

[0000866374-25-000051:notes:74]
(2)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at the Secured Overnight Financing Rate ("SOFR") plus 100 basis points.

[0000866374-25-000051:notes:75]
(3)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

[0000866374-25-000051:notes:76]
The weighted-average interest rate for the Company's long-term debt was 4.6% as of September 26, 2025 and March 31, 2025, respectively.

[0000866374-25-000051:notes:77]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 26, 2025 are as follows:

[0000866374-25-000051:notes:78]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2026 (1) |  | $ | 676 |  |
| 2027 |  | — |  |
| 2028 |  | 898 |  |
| 2029 |  | 30 |  |
| 2030 |  | 685 |  |
| Thereafter |  | 1,412 |  |
| Total |  | $ | 3,701 |  |

[0000866374-25-000051:notes:79]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2026.

[0000866374-25-000051:notes:80]
The 2030 Credit Facility

[0000866374-25-000051:notes:81]
In July 2025, the Company entered into a new $2.75 billion credit facility (“2030 Credit Facility”) which matures in July 2030 and consists of a $2.75 billion revolving credit facility with a sub-limit of $400 million available for swing line loans and a sub-limit of $200 million available for the issuance of letters of credit. The 2030 Credit Facility replaced the previous $2.5 billion credit facility, which was due to mature in July 2027. Borrowings under the 2030 Credit Facility bear interest at the Company’s option at various market based rates, adjusted for the Company’s credit rating, or at the SOFR or similar non-reporting currency benchmarks based on the underlying borrowing currency, adjusted for the Company’s credit rating. The Company is required to pay a quarterly commitment fee on the unutilized portion of the 2030 Credit Facility ranging from 0.100% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.00% to 1.750% per annum, based on the Company’s credit ratings, on the daily average amount of outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

[0000866374-25-000051:notes:82]
Term Loan due December 2027

[0000866374-25-000051:notes:83]
In March 2025, the Company entered into a $500 million delayed draw term loan agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general purposes. All borrowings on the delayed draw term loan will come due on December 31, 2027. Interest is based on a Term SOFR-based formula plus a margin of 100 basis points. The Company had $500 million in borrowings outstanding under the loan agreement as of September 26, 2025.


## flex:InterestAndOtherNetTextBlock

[0000866374-25-000051:notes:84]
INTEREST EXPENSE AND INTEREST INCOME
Interest expense and interest income for the three and six-month periods ended September 26, 2025 and September 27, 2024 are composed of the following:

[0000866374-25-000051:notes:85]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 47 |  |  | $ | 46 |  |  | $ | 92 |  |  | $ | 89 |  |
| AR sale program related expenses | 5 |  |  | 7 |  |  | 11 |  |  | 20 |  |
| Interest income | (10) |  |  | (16) |  |  | (23) |  |  | (32) |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-25-000051:notes:86]
[same as prior period, unchanged from 0000866374-25-000043:notes:74]

[0000866374-25-000051:notes:87]
[same as prior period, unchanged from 0000866374-25-000043:notes:75]

[0000866374-25-000051:notes:88]
As of September 26, 2025, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $7.0 billion as summarized below:

[0000866374-25-000051:notes:89]
|  |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  | p |
| MXN |  | $ | 509 |  |  | $ | — |  |
| HUF |  | 427 |  |  | — |  |
| CNY |  | 294 |  |  | — |  |
| Other |  | 452 |  |  | 18 |  |
|  |  | 1,682 |  |  | 18 |  |
| Other Foreign Currency Contracts |  |  |  |  |
| EUR |  | 685 |  |  | 519 |  |
| CNY |  | 711 |  |  | 269 |  |
| MXN |  | 422 |  |  | 298 |  |
| MYR |  | 278 |  |  | 136 |  |
| BRL |  | 68 |  |  | 304 |  |
| Other |  | 932 |  |  | 710 |  |
|  |  | 3,096 |  |  | 2,236 |  |
| Total Notional Contract Value in USD |  | $ | 4,778 |  |  | $ | 2,254 |  |

[0000866374-25-000051:notes:90]
As of September 26, 2025, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the condensed consolidated statements of operations. The Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were $30 million as of September 26, 2025, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations over the next twelve-month period, except for gains attributable to changes in fair value of the USD HUF cross currency swaps, which are discussed below.

[0000866374-25-000051:notes:91]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other current liabilities and other non-current liabilities as of September 26, 2025, and in other current assets and other non-current liabilities as of March 31, 2025, respectively. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-25-000051:notes:92]
The following table presents the fair value of the Company’s derivative instruments utilized for foreign currency risk management purposes at September 26, 2025 and March 31, 2025:

[0000866374-25-000051:notes:93]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 26,2025 |  | March 31,2025 |  | Balance SheetLocation |  | September 26,2025 |  | March 31,2025 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 52 |  |  | $ | 13 |  |  | Other current liabilities |  | $ | (7) |  |  | $ | (18) |  |
| Foreign currency contracts | Other non-current assets |  | — |  |  | — |  |  | Other non-current liabilities |  | (13) |  |  | (46) |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 13 |  |  | $ | 21 |  |  | Other current liabilities |  | $ | (10) |  |  | $ | (15) |  |

[0000866374-25-000051:notes:94]
[same as prior period, unchanged from 0000866374-25-000043:notes:83]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-25-000051:notes:95]
[same as prior period, unchanged from 0000866374-25-000043:notes:84]

[0000866374-25-000051:notes:96]
|  | Three-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | 20 |  |  | $ | (136) |  |  | $ | (116) |  |  | $ | (23) |  |  | $ | (215) |  |  | $ | (238) |  |
| Other comprehensive gain (loss) before reclassifications | 23 |  |  | 5 |  |  | 28 |  |  | 8 |  |  | 55 |  |  | 63 |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | (23) |  |  | — |  |  | (23) |  |  | 2 |  |  | — |  |  | 2 |  |
| Net current-period other comprehensive gain (loss) | — |  |  | 5 |  |  | 5 |  |  | 10 |  |  | 55 |  |  | 65 |  |
| Ending balance | $ | 20 |  |  | $ | (131) |  |  | $ | (111) |  |  | $ | (13) |  |  | $ | (160) |  |  | $ | (173) |  |

[0000866374-25-000051:notes:97]
|  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain (loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (19) |  |  | $ | (205) |  |  | $ | (224) |  |  | $ | 4 |  |  | $ | (199) |  |  | $ | (195) |  |
| Other comprehensive gain (loss) before reclassifications | 81 |  |  | 74 |  |  | 155 |  |  | (22) |  |  | 39 |  |  | 17 |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | (42) |  |  | — |  |  | (42) |  |  | 5 |  |  | — |  |  | 5 |  |
| Net current-period other comprehensive gain (loss) | 39 |  |  | 74 |  |  | 113 |  |  | (17) |  |  | 39 |  |  | 22 |  |
| Ending balance | $ | 20 |  |  | $ | (131) |  |  | $ | (111) |  |  | $ | (13) |  |  | $ | (160) |  |  | $ | (173) |  |

[0000866374-25-000051:notes:98]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and six-month periods ended September 26, 2025 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the condensed consolidated statements of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in accumulated other comprehensive loss for the three-month periods ended September 26, 2025 and September 27, 2024 were $(2) million and $2 million, respectively. The tax impacts on the changes in accumulated other comprehensive loss for the six-month periods ended September 26, 2025 and September 27, 2024 were $(13) million and $11 million, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-25-000051:notes:99]
TRADE RECEIVABLES SALES PROGRAMSThe Company sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was $0.7 billion as of both September 26, 2025 and March 31, 2025. For the six-month periods ended September 26, 2025 and September 27, 2024, total accounts receivable sold to certain third-party banking institutions was approximately $1.7 billion and $2.1 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000866374-25-000051:notes:100]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES 
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-25-000051:notes:101]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000866374-25-000051:notes:102]
Level 2 - Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-25-000051:notes:103]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-25-000051:notes:104]
The Company’s cash equivalents include bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value. 
Level 3 - Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-25-000051:notes:105]
[same as prior period, unchanged from 0000866374-25-000043:notes:92]

[0000866374-25-000051:notes:106]
[same as prior period, unchanged from 0000866374-25-000043:notes:94]

[0000866374-25-000051:notes:107]
The Company has accrued for contingent consideration related to an acquisition in fiscal year 2025, classified as a level 3 measurement in the fair value hierarchy due to significant unobservable inputs. Fair value is determined using internal cash flow models that incorporate unobservable inputs, including the probability of achieving performance milestones. As of September 26, 2025 and March 31, 2025, the balance of contingent consideration was $2 million and $5 million, respectively.

[0000866374-25-000051:notes:108]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other non-current assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as either level 1 or level 2, dependent on the valuation inputs, within the fair value hierarchy.

[0000866374-25-000051:notes:109]
[same as prior period, unchanged from 0000866374-25-000043:notes:96]

[0000866374-25-000051:notes:110]
During the six-month periods ended September 26, 2025 and September 27, 2024, there were no other additions to the accrual, payments, fair value adjustments, or unrealized gains or losses included in earnings.

[0000866374-25-000051:notes:111]
[same as prior period, unchanged from 0000866374-25-000043:notes:99]

[0000866374-25-000051:notes:112]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of September 26, 2025 and March 31, 2025:

[0000866374-25-000051:notes:113]
|  | Fair Value Measurements as of September 26, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,383 |  |  | $ | — |  |  | $ | 1,383 |  |
| Foreign currency contracts (Note 8) | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | 35 |  |  | 14 |  |  | — |  |  | 49 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (30) |  |  | $ | — |  |  | $ | (30) |  |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (2) |  |  | (2) |  |
|  | Fair Value Measurements as of March 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,535 |  |  | $ | — |  |  | $ | 1,535 |  |
| Foreign currency contracts (Note 8) | — |  |  | 34 |  |  | — |  |  | 34 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (79) |  |  | $ | — |  |  | $ | (79) |  |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (5) |  |  | (5) |  |

[0000866374-25-000051:notes:114]
[same as prior period, unchanged from 0000866374-25-000043:notes:102]

[0000866374-25-000051:notes:115]
The following table presents the Company’s major debts not carried at fair value as of September 26, 2025 and March 31, 2025:

[0000866374-25-000051:notes:116]
|  | As of September 26, 2025 |  | As of March 31, 2025 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | — |  |  | $ | — |  |  | $ | 531 |  |  | $ | 531 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 676 |  |  | 674 |  |  | 678 |  |  | 672 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 411 |  |  | 398 |  |  | 409 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 655 |  |  | 662 |  |  | 655 |  |  | 651 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 673 |  |  | 679 |  |  | 676 |  |  | 669 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 511 |  |  | 499 |  |  | 497 |  |  | Level 1 |
| Delayed Draw Term Loan due December 2027 | 500 |  |  | 500 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 300 |  |  | 240 |  |  | 269 |  |  | 215 |  |  | Level 2 |

[0000866374-25-000051:notes:117]
The Notes due June 2025, February 2026, January 2028, June 2029, May 2030 and January 2032 are valued based on broker trading prices in active markets. The Delayed Draw Term Loan due December 2027 bears interest at variable interest rates; therefore, as of September 26, 2025, the carrying amount approximates fair value. HUF Bonds are valued based on the broker trading prices in an inactive market.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-25-000051:notes:118]
BUSINESS ACQUISITIONS
In the first quarter of fiscal year 2026, the Company completed the acquisition of a manufacturing business in Bielsko Biała, Poland, for total purchase consideration of $35 million. The site is included in the FRS segment. The results of the acquired business are included in the Company’s condensed consolidated financial statements from the acquisition date. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed is based on their estimated fair values as of the date of acquisition. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of the acquisition. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the measurement period.

[0000866374-25-000051:notes:119]
[same as prior period, unchanged from 0000866374-25-000043:notes:107]

[0000866374-25-000051:notes:120]
| Current Assets: |  |
| Inventory | $ | 15 |  |
| Unbilled Accounts Receivable | 9 |  |
| Accounts Receivable | 1 |  |
| Total current assets | 25 |  |
| Operating lease right-of-use assets, net | 28 |  |
| Property and equipment | 4 |  |
| Intangible assets (1) | 2 |  |
| Goodwill | 8 |  |
| Total assets | $ | 67 |  |
| Current Liabilities: |  |
| Accrued payroll | $ | 4 |  |
| Operating lease liabilities | 2 |  |
| Total current liabilities | 6 |  |
| Operating lease liabilities, non-current | 26 |  |
| Total liabilities | 32 |  |
| Total aggregate purchase price | $ | 35 |  |

[0000866374-25-000051:notes:121]
(1)Intangible assets are comprised of customer related intangible assets and acquired technology, both of which will be amortized over a weighted-average estimated useful life of 5 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-25-000051:notes:122]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-25-000051:notes:123]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-25-000051:notes:124]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. The Company was unsuccessful at the administrative level in two of the remaining assessments and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 37 million Brazilian reals (approximately USD $7 million). The Brazilian court ruled in favor of the Company on the first annulment action on March 7, 2025 and the assessment obligation has been canceled, although it remains subject to appeal. The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 60 million Brazilian reals (approximately USD $11 million). The Company is still awaiting a resolution of the second annulment action. The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on the remaining assessments and annulment actions in the near future.

[0000866374-25-000051:notes:125]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-25-000051:notes:126]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material effect on the Company’s financial position, results of operations or cash flows.

[0000866374-25-000051:notes:127]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-25-000051:notes:128]
SHARE REPURCHASES 
During the three and six-month period ended September 26, 2025, the Company repurchased 5.6 million and 12.9 million shares at aggregate purchase prices of $297 million and $544 million, respectively, and retired all of these shares.

[0000866374-25-000051:notes:129]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.7 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the most recent Annual General Meeting held on August 6, 2025. As of September 26, 2025, shares in the aggregate amount of $1.5 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-25-000051:notes:130]
[same as prior period, unchanged from 0000866374-25-000043:notes:120]

[0000866374-25-000051:notes:131]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, certain restructuring and impairment charges, customer related asset impairment, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-25-000051:notes:132]
[same as prior period, unchanged from 0000866374-25-000043:notes:122]

[0000866374-25-000051:notes:133]
Selected financial information by segment for the three and six-month periods ended September 26, 2025 and September 27, 2024 are in the tables below:

[0000866374-25-000051:notes:134]
|  | FAS |  | FRS |  | Corporate & Other |  | Total |
| Three-Months Ended September 26, 2025 | (In millions) |
| Net Sales | $ | 3,766 |  |  | $ | 3,038 |  |  | $ | — |  |  | $ | 6,804 |  |
| Cost of inventory | (2,780) |  |  | (1,956) |  |  | (1) |  |  | (4,737) |  |
| Manufacturing expenses | (667) |  |  | (768) |  |  | — |  |  | (1,435) |  |
| Segment selling, general and administrative expenses | (92) |  |  | (117) |  |  | (14) |  |  | (223) |  |
| Segment income | $ | 227 |  |  | $ | 197 |  |  | $ | (15) |  |  | $ | 409 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 16 |  |
| Stock-based compensation |  |  |  |  |  |  | 37 |  |
| Restructuring and impairment charges (1) |  |  |  |  |  |  | 51 |  |
| Legal and other (2) |  |  |  |  |  |  | 9 |  |
| Interest expenses |  |  |  |  |  |  | 52 |  |
| Interest income |  |  |  |  |  |  | 10 |  |
| Other charges (income), net |  |  |  |  |  |  | (13) |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (5) |  |
| Income before income taxes |  |  |  |  |  |  | $ | 262 |  |

[0000866374-25-000051:notes:135]
(1)The Company recognized a total of $41 million in asset impairments, inventory write-downs and other related charges as a result of a missile strike on its Mukachevo, Ukraine facility on August 21, 2025. Refer to note 1 "Organization of the Company and Basis of Presentation" for further details.

[0000866374-25-000051:notes:136]
(2)Legal and other consists of costs not directly related to core business results and including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs. During fiscal year 2026, legal costs were primarily related to costs from acquisitions occurring in fiscal year 2025 and the first quarter of fiscal year 2026.

[0000866374-25-000051:notes:137]
|  | FAS |  | FRS |  | Corporate & Other |  | Total |
| Six-Months Ended September 26, 2025 | (In millions) |
| Net Sales | $ | 7,457 |  |  | $ | 5,922 |  |  | $ | — |  |  | $ | 13,379 |  |
| Cost of inventory | (5,512) |  |  | (3,883) |  |  | (1) |  |  | (9,396) |  |
| Manufacturing expenses | (1,301) |  |  | (1,449) |  |  | (5) |  |  | (2,755) |  |
| Segment selling, general and administrative expenses | (177) |  |  | (221) |  |  | (26) |  |  | (424) |  |
| Segment income | $ | 467 |  |  | $ | 369 |  |  | $ | (32) |  |  | $ | 804 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 37 |  |
| Stock-based compensation |  |  |  |  |  |  | 71 |  |
| Restructuring and impairment charges (1) |  |  |  |  |  |  | 74 |  |
| Legal and other (2) |  |  |  |  |  |  | 15 |  |
| Interest expenses |  |  |  |  |  |  | 103 |  |
| Interest income |  |  |  |  |  |  | 23 |  |
| Other charges (income), net |  |  |  |  |  |  | (6) |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (25) |  |
| Income before income taxes |  |  |  |  |  |  | $ | 508 |  |

[0000866374-25-000051:notes:138]
|  | FAS |  | FRS |  | Corporate & Other |  | Total |
| Three-Months Ended September 27, 2024 | (In millions) |
| Net Sales | $ | 3,606 |  |  | $ | 2,939 |  |  | $ | — |  |  | $ | 6,545 |  |
| Cost of inventory | (2,680) |  |  | (1,988) |  |  | — |  |  | (4,668) |  |
| Manufacturing expenses | (625) |  |  | (692) |  |  | (6) |  |  | (1,323) |  |
| Segment selling, general and administrative expenses | (83) |  |  | (100) |  |  | (13) |  |  | (196) |  |
| Segment income | $ | 218 |  |  | $ | 159 |  |  | $ | (19) |  |  | $ | 358 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 16 |  |
| Stock-based compensation |  |  |  |  |  |  | 28 |  |
| Restructuring charges |  |  |  |  |  |  | 17 |  |
| Interest expenses |  |  |  |  |  |  | 53 |  |
| Interest income |  |  |  |  |  |  | 16 |  |
| Other charges (income), net |  |  |  |  |  |  | (8) |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (4) |  |
| Income before income taxes |  |  |  |  |  |  | $ | 264 |  |

[0000866374-25-000051:notes:139]
|  | FAS |  | FRS |  | Corporate & Other |  | Total |
| Six-Months Ended September 27, 2024 | (In millions) |
| Net Sales | $ | 6,971 |  |  | $ | 5,888 |  |  | $ | — |  |  | $ | 12,859 |  |
| Cost of inventory | (5,176) |  |  | (3,991) |  |  | — |  |  | (9,167) |  |
| Manufacturing expenses | (1,238) |  |  | (1,391) |  |  | (14) |  |  | (2,643) |  |
| Segment selling, general and administrative expenses | (160) |  |  | (200) |  |  | (25) |  |  | (385) |  |
| Segment income | $ | 397 |  |  | $ | 306 |  |  | $ | (39) |  |  | $ | 664 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 32 |  |
| Stock-based compensation |  |  |  |  |  |  | 60 |  |
| Restructuring charges |  |  |  |  |  |  | 42 |  |
| Interest expenses |  |  |  |  |  |  | 109 |  |
| Interest income |  |  |  |  |  |  | 32 |  |
| Other charges (income), net |  |  |  |  |  |  | (6) |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (3) |  |
| Income before income taxes |  |  |  |  |  |  | $ | 456 |  |

[0000866374-25-000051:notes:140]
Corporate and Other primarily includes corporate service costs that are not included in the CODM's assessment of the performance of each of the identified reportable segments.

[0000866374-25-000051:notes:141]
[same as prior period, unchanged from 0000866374-25-000043:notes:128]

[0000866374-25-000051:notes:142]
[same as prior period, unchanged from 0000866374-25-000043:notes:129]

[0000866374-25-000051:notes:143]
Total depreciation expense, including amounts allocated to the reportable segments and Corporate and Other for the three and six-month periods ended September 26, 2025 and September 27, 2024 are as follows:

[0000866374-25-000051:notes:144]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
|  | (In millions) |  | (In millions) |
| Depreciation expense: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 44 |  |  | $ | 45 |  |  | $ | 94 |  |  | $ | 89 |  |
| Flex Reliability Solutions | 66 |  |  | 64 |  |  | 128 |  |  | 126 |  |
| Corporate and Other | 4 |  |  | 2 |  |  | 7 |  |  | 6 |  |
| Total depreciation expense | $ | 114 |  |  | $ | 111 |  |  | $ | 229 |  |  | $ | 221 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-25-000051:notes:145]
RESTRUCTURING CHARGES
The Company continued to improve operational efficiencies through targeted restructuring activities during the second quarter of fiscal year 2026. During the three and six-month periods ended September 26, 2025, the Company recognized approximately $10 million and $33 million of restructuring charges, respectively, most of which related to employee severance.

[0000866374-25-000051:notes:146]
The following table summarizes the provisions, respective payments, and remaining accrued balance for charges incurred as of September 26, 2025:

[0000866374-25-000051:notes:147]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2025 | $ | 51 |  |  | $ | — |  |  | $ | — |  |  | $ | 51 |  |
| Provision for net charges incurred | 24 |  |  | 6 |  |  | 3 |  |  | 33 |  |
| Cash payments | (35) |  |  | — |  |  | (3) |  |  | (38) |  |
| Non-cash reductions | — |  |  | (6) |  |  | — |  |  | (6) |  |
| Other adjustments | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Balance as of September 26, 2025 | 40 |  |  | — |  |  | 1 |  |  | 41 |  |
| Less: Current portion (classified as other current liabilities) | 40 |  |  | — |  |  | 1 |  |  | 41 |  |
| Accrued restructuring costs, net of current portion (classified as other non-current liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000866374-25-000051:notes:148]
On September 12, 2025, Daniel J. Wendler, Senior Vice President and Chief Accounting Officer, adopted a trading plan that provides for the sale of up to 10,000 ordinary shares of the Company. The plan will terminate on May 29, 2026, subject to early termination for certain specified events set forth in the plan.
