# FLEX note change history — 0000866374-25-000043 → 0000866374-25-000051


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- removed (2025-10-31):
[0000866374-25-000043:note_history:1]
The Company was involved in a commercial dispute related to a construction matter with related production objectives. Management had assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment recognized $50 million in Selling, general and administrative expenses in the fourth

- removed (2025-10-31):
[0000866374-25-000043:note_history:2]
quarter of the fiscal year ended March 31, 2024 as an accrual. The parties reached a settlement in line with the accrued amount during the first quarter of fiscal year 2026 and the Company made an initial payment of $21 million in line with this agreement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0000866374-25-000051:note_history:3]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, and power. As of September 26, 2025, Flex's two operating and reportable segments were as follows:
  (was, 2025-07-25, similarity 0.9414):
[0000866374-25-000043:note_history:3]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, automotive, industrial, healthcare, industrial and power. As of June 27, 2025, Flex's two operating and reportable segments were as follows:

- changed (2025-10-31):
[0000866374-25-000051:note_history:4]
◦Industrial, including industrial devices, capital equipment, renewables, critical power, and embedded power
  (was, 2025-07-25, similarity 0.9953):
[0000866374-25-000043:note_history:4]
◦Industrial, including industrial devices, capital equipment, renewables, critical power and embedded power

- changed (2025-10-31):
[0000866374-25-000051:note_history:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2025 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 26, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026.
  (was, 2025-07-25, similarity 0.8606):
[0000866374-25-000043:note_history:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2025 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 27, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026.

- added (2025-10-31):
[0000866374-25-000051:note_history:6]
The first quarters for fiscal years 2026 and 2025 ended on June 27, 2025, which is comprised of 88 days in the period, and June 28, 2024, which is comprised of 89 days, respectively. The second quarters for fiscal years 2026 and 2025 ended on September 26, 2025 and September 27, 2024, respectively, which are comprised of 91 days in both periods.

- changed (2025-10-31):
[0000866374-25-000051:note_history:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are
  (was, 2025-07-25, similarity 0.7427):
[0000866374-25-000043:note_history:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and

- changed (2025-10-31):
[0000866374-25-000051:note_history:8]
used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; valuation of warrants, and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas conflict, and other geopolitical conflicts) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2025-07-25, similarity 0.6016):
[0000866374-25-000043:note_history:8]
intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- added (2025-10-31):
[0000866374-25-000051:note_history:9]
Impact of Missile Strike in Ukraine

- added (2025-10-31):
[0000866374-25-000051:note_history:10]
During the three months ended September 26, 2025, the Company recognized $23 million of long-lived asset impairments, $13 million of inventory write-downs and $5 million of other charges as a result of a missile strike on its Mukachevo, Ukraine facility in Western Ukraine on August 21, 2025. The missile strike represents an unusual and infrequent event as hostilities related to the Russian invasion of Ukraine have been primarily focused in Eastern Ukraine. The missile strike caused substantial physical damage and disrupted normal operations at the facility. In response, the Company activated contingency manufacturing plans and transitioned production to alternative facilities. As restoration activities progress in Mukachevo, the Company expects to incur additional immaterial near-term inefficiencies. The total $41 million expense is included in restructuring and impairment charges in the condensed consolidated statements of operations.

- changed (2025-10-31):
[0000866374-25-000051:note_history:11]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and income taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.
  (was, 2025-07-25, similarity 0.9823):
[0000866374-25-000043:note_history:11]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

- added (2025-10-31):
[0000866374-25-000051:note_history:12]
In September 2025, the FASB issued ASU 2025-06 "Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40)", which eliminates prescriptive software development stages, requiring capitalization upon funding authorization and commitment. Additionally, the ASU clarifies the scope for capitalization and supersedes website development guidance. The guidance is effective for the Company beginning in the first quarter of fiscal year 2029. The Company is currently evaluating the guidance to determine the method of adoption and impact on the Company's disclosures.

- added (2025-10-31):
[0000866374-25-000051:note_history:13]
Recently Adopted Accounting Pronouncements

- added (2025-10-31):
[0000866374-25-000051:note_history:14]
In July 2025, the FASB issued ASU 2025-05 "Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets", which provides for the use of a new practical expedient when estimating expected credit losses for accounts receivable and contract assets arising from transactions accounted for under Topic 606 that assumes that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for the Company, and has been adopted, beginning in the second quarter of fiscal year 2026.

- removed (2025-10-31):
[0000866374-25-000043:note_history:15]
The first quarters for fiscal years 2026 and 2025 ended on June 27, 2025 and June 28, 2024, respectively, and are comprised of 88 and 89 days.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0000866374-25-000051:note_history:16]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 26, 2025 and March 31, 2025 are as follows:
  (was, 2025-07-25, similarity 0.9528):
[0000866374-25-000043:note_history:16]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 27, 2025 and March 31, 2025 are as follows:

- added (2025-10-31):
[0000866374-25-000051:note_history:17]
|  | Maturity Date |  | As of September 26, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | — |  |  | $ | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 676 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 673 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 300 |  |  | 269 |  |
| Debt issuance costs |  |  | (12) |  |  | (14) |  |
|  |  |  | 3,689 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (676) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,013 |  |  | $ | 2,483 |  |

- changed (2025-10-31):
[0000866374-25-000051:note_history:18]
(1)The notes are carried at the principal amount of each note less any unamortized discount and unamortized debt issuance costs and inclusive of any unamortized premium. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.
  (was, 2025-07-25, similarity 0.9112):
[0000866374-25-000043:note_history:18]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

- changed (2025-10-31):
[0000866374-25-000051:note_history:19]
(2)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at the Secured Overnight Financing Rate ("SOFR") plus 100 basis points.
  (was, 2025-07-25, similarity 0.8776):
[0000866374-25-000043:note_history:19]
(2)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at SOFR plus 100 basis points.

- changed (2025-10-31):
[0000866374-25-000051:note_history:20]
The weighted-average interest rate for the Company's long-term debt was 4.6% as of September 26, 2025 and March 31, 2025, respectively.
  (was, 2025-07-25, similarity 0.954):
[0000866374-25-000043:note_history:20]
The weighted-average interest rate for the Company's long-term debt was 4.6% as of June 27, 2025 and March 31, 2025, respectively.

- changed (2025-10-31):
[0000866374-25-000051:note_history:21]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 26, 2025 are as follows:
  (was, 2025-07-25, similarity 0.9479):
[0000866374-25-000043:note_history:21]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 27, 2025 are as follows:

- changed (2025-10-31):
[0000866374-25-000051:note_history:22]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2026.
  (was, 2025-07-25, similarity 0.9733):
[0000866374-25-000043:note_history:22]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2026.

- added (2025-10-31):
[0000866374-25-000051:note_history:23]
The 2030 Credit Facility

- added (2025-10-31):
[0000866374-25-000051:note_history:24]
In July 2025, the Company entered into a new $2.75 billion credit facility (“2030 Credit Facility”) which matures in July 2030 and consists of a $2.75 billion revolving credit facility with a sub-limit of $400 million available for swing line loans and a sub-limit of $200 million available for the issuance of letters of credit. The 2030 Credit Facility replaced the previous $2.5 billion credit facility, which was due to mature in July 2027. Borrowings under the 2030 Credit Facility bear interest at the Company’s option at various market based rates, adjusted for the Company’s credit rating, or at the SOFR or similar non-reporting currency benchmarks based on the underlying borrowing currency, adjusted for the Company’s credit rating. The Company is required to pay a quarterly commitment fee on the unutilized portion of the 2030 Credit Facility ranging from 0.100% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.00% to 1.750% per annum, based on the Company’s credit ratings, on the daily average amount of outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

- changed (2025-10-31):
[0000866374-25-000051:note_history:25]
In March 2025, the Company entered into a $500 million delayed draw term loan agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general purposes. All borrowings on the delayed draw term loan will come due on December 31, 2027. Interest is based on a Term SOFR-based formula plus a margin of 100 basis points. The Company had $500 million in borrowings outstanding under the loan agreement as of September 26, 2025.
  (was, 2025-07-25, similarity 0.8004):
[0000866374-25-000043:note_history:25]
In March 2025, the Company entered into a delayed draw term loan agreement for an amount of $500 million. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general purposes. All borrowings on the delayed draw term loan will be come due on December 31, 2027. Interest is based on a Term SOFR-based formula plus a margin of 100 basis points. The Company has fully drawn the $500 million loan as of June 27, 2025.

- removed (2025-10-31):
[0000866374-25-000043:note_history:26]
|  | Maturity Date |  | As of June 27, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | — |  |  | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 677 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 675 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 290 |  |  | 269 |  |
| Debt issuance costs |  |  | (13) |  |  | (14) |  |
|  |  |  | 3,681 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (677) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,004 |  |  | $ | 2,483 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0000866374-25-000051:note_history:27]
The following table presents the Company’s major debts not carried at fair value as of September 26, 2025 and March 31, 2025:
  (was, 2025-07-25, similarity 0.8265):
[0000866374-25-000043:note_history:27]
The following table presents the Company’s major debts not carried at fair value:

- changed (2025-10-31):
[0000866374-25-000051:note_history:28]
|  | As of September 26, 2025 |  | As of March 31, 2025 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | — |  |  | $ | — |  |  | $ | 531 |  |  | $ | 531 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 676 |  |  | 674 |  |  | 678 |  |  | 672 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 411 |  |  | 398 |  |  | 409 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 655 |  |  | 662 |  |  | 655 |  |  | 651 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 673 |  |  | 679 |  |  | 676 |  |  | 669 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 511 |  |  | 499 |  |  | 497 |  |  | Level 1 |
| Delayed Draw Term Loan due December 2027 | 500 |  |  | 500 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 300 |  |  | 240 |  |  | 269 |  |  | 215 |  |  | Level 2 |
  (was, 2025-07-25, similarity 0.9735):
[0000866374-25-000043:note_history:28]
|  | As of June 27, 2025 |  | As of March 31, 2025 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | — |  |  | — |  |  | 531 |  |  | 531 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 677 |  |  | 673 |  |  | 678 |  |  | 672 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 411 |  |  | 398 |  |  | 409 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 655 |  |  | 659 |  |  | 655 |  |  | 651 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 675 |  |  | 678 |  |  | 676 |  |  | 669 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 504 |  |  | 499 |  |  | 497 |  |  | Level 1 |
| Delayed Draw Term Loan due December 2027 | 500 |  |  | 500 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 290 |  |  | 232 |  |  | 269 |  |  | 215 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0000866374-25-000051:note_history:29]
Bank borrowings and long-term debt as of September 26, 2025 and March 31, 2025 are as follows:
  (was, 2025-07-25, similarity 0.9325):
[0000866374-25-000043:note_history:29]
Bank borrowings and long-term debt as of June 27, 2025 and March 31, 2025 are as follows:

- added (2025-10-31):
[0000866374-25-000051:note_history:30]
|  | Maturity Date |  | As of September 26, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | — |  |  | $ | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 676 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 673 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 300 |  |  | 269 |  |
| Debt issuance costs |  |  | (12) |  |  | (14) |  |
|  |  |  | 3,689 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (676) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,013 |  |  | $ | 2,483 |  |

- changed (2025-10-31):
[0000866374-25-000051:note_history:31]
(1)The notes are carried at the principal amount of each note less any unamortized discount and unamortized debt issuance costs and inclusive of any unamortized premium. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.
  (was, 2025-07-25, similarity 0.9112):
[0000866374-25-000043:note_history:31]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

- changed (2025-10-31):
[0000866374-25-000051:note_history:32]
(2)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at the Secured Overnight Financing Rate ("SOFR") plus 100 basis points.
  (was, 2025-07-25, similarity 0.8776):
[0000866374-25-000043:note_history:32]
(2)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at SOFR plus 100 basis points.

- removed (2025-10-31):
[0000866374-25-000043:note_history:33]
|  | Maturity Date |  | As of June 27, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | — |  |  | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 677 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 675 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 290 |  |  | 269 |  |
| Debt issuance costs |  |  | (13) |  |  | (14) |  |
|  |  |  | 3,681 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (677) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,004 |  |  | $ | 2,483 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0000866374-25-000051:note_history:34]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 26, 2025 are as follows:
  (was, 2025-07-25, similarity 0.9479):
[0000866374-25-000043:note_history:34]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 27, 2025 are as follows:

- changed (2025-10-31):
[0000866374-25-000051:note_history:35]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2026.
  (was, 2025-07-25, similarity 0.9733):
[0000866374-25-000043:note_history:35]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2026.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0000866374-25-000051:note_history:36]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,874 |  |  | $ | 2,924 |  |  | $ | 5,769 |  |  | $ | 5,797 |  |
| Over time | 892 |  |  | 682 |  |  | 1,688 |  |  | 1,174 |  |
| Total | 3,766 |  |  | 3,606 |  |  | 7,457 |  |  | 6,971 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,970 |  |  | 2,237 |  |  | 3,829 |  |  | 4,870 |  |
| Over time | 1,068 |  |  | 702 |  |  | 2,093 |  |  | 1,018 |  |
| Total | 3,038 |  |  | 2,939 |  |  | 5,922 |  |  | 5,888 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,844 |  |  | 5,161 |  |  | 9,598 |  |  | 10,667 |  |
| Over time | 1,960 |  |  | 1,384 |  |  | 3,781 |  |  | 2,192 |  |
| Total | $ | 6,804 |  |  | $ | 6,545 |  |  | $ | 13,379 |  |  | $ | 12,859 |  |
  (was, 2025-07-25, similarity 0.7768):
[0000866374-25-000043:note_history:36]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
| Timing of Transfer |  |  |  |  | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | $ | 2,895 |  |  | $ | 2,873 |  |
| Over time |  |  |  |  | 796 |  |  | 492 |  |
| Total |  |  |  |  | 3,691 |  |  | 3,365 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 1,859 |  |  | 2,633 |  |
| Over time |  |  |  |  | 1,025 |  |  | 316 |  |
| Total |  |  |  |  | 2,884 |  |  | 2,949 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 4,754 |  |  | 5,506 |  |
| Over time |  |  |  |  | 1,821 |  |  | 808 |  |
| Total |  |  |  |  | $ | 6,575 |  |  | $ | 6,314 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0000866374-25-000051:note_history:37]
A contract asset is recognized when the Company has recognized revenue but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional and invoiced.
  (was, 2025-07-25, similarity 0.9982):
[0000866374-25-000043:note_history:37]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional and invoiced.

- changed (2025-10-31):
[0000866374-25-000051:note_history:38]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $429 million and $377 million as of September 26, 2025 and March 31, 2025, respectively, of which $392 million and $347 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.
  (was, 2025-07-25, similarity 0.6677):
[0000866374-25-000043:note_history:38]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $450 million and $377 million as of June 27, 2025 and March 31, 2025,

- added (2025-10-31):
[0000866374-25-000051:note_history:39]
Warrant

- added (2025-10-31):
[0000866374-25-000051:note_history:40]
During the quarter ended September 26, 2025, the Company issued a warrant (“the Warrant”) to a customer for the purchase of up to an aggregate of approximately 3.9 million ordinary shares of the Company ("Warrant Shares"). The Warrant Shares vest based on qualifying payments (as defined in the Warrant) for the purchase of all products and services over the term of the Warrant and are recognized as a deduction to revenue as qualifying revenues are recognized. Refer to “Note 4 – Share-Based Compensation and Warrants” for further information.

- changed (2025-10-31):
[0000866374-25-000051:note_history:41]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,874 |  |  | $ | 2,924 |  |  | $ | 5,769 |  |  | $ | 5,797 |  |
| Over time | 892 |  |  | 682 |  |  | 1,688 |  |  | 1,174 |  |
| Total | 3,766 |  |  | 3,606 |  |  | 7,457 |  |  | 6,971 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,970 |  |  | 2,237 |  |  | 3,829 |  |  | 4,870 |  |
| Over time | 1,068 |  |  | 702 |  |  | 2,093 |  |  | 1,018 |  |
| Total | 3,038 |  |  | 2,939 |  |  | 5,922 |  |  | 5,888 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,844 |  |  | 5,161 |  |  | 9,598 |  |  | 10,667 |  |
| Over time | 1,960 |  |  | 1,384 |  |  | 3,781 |  |  | 2,192 |  |
| Total | $ | 6,804 |  |  | $ | 6,545 |  |  | $ | 13,379 |  |  | $ | 12,859 |  |
  (was, 2025-07-25, similarity 0.7768):
[0000866374-25-000043:note_history:41]
|  |  |  | Three-Month Periods Ended |
|  |  |  |  |  | June 27, 2025 |  | June 28, 2024 |
| Timing of Transfer |  |  |  |  | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | $ | 2,895 |  |  | $ | 2,873 |  |
| Over time |  |  |  |  | 796 |  |  | 492 |  |
| Total |  |  |  |  | 3,691 |  |  | 3,365 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 1,859 |  |  | 2,633 |  |
| Over time |  |  |  |  | 1,025 |  |  | 316 |  |
| Total |  |  |  |  | 2,884 |  |  | 2,949 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time |  |  |  |  | 4,754 |  |  | 5,506 |  |
| Over time |  |  |  |  | 1,821 |  |  | 808 |  |
| Total |  |  |  |  | $ | 6,575 |  |  | $ | 6,314 |  |

- removed (2025-10-31):
[0000866374-25-000043:note_history:42]
respectively, of which $406 million and $347 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-10-31):
[0000866374-25-000043:note_history:43]
SUBSEQUENT EVENTS
On July 15, 2025, the Company entered into a new $2.75 billion credit facility (the "New Credit Facility") which matures in July 2030 and consists of a $2.75 billion revolving credit facility with a sub-limit of $400 million available for swing line loans and a sub-limit of $200 million available for the issuance of letters of credit. The New Credit Facility replaced the previous $2.5 billion credit facility. Under the New Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are determined based on standard benchmark interest rates subject to potential adjustment based on the Company’s credit rating.
