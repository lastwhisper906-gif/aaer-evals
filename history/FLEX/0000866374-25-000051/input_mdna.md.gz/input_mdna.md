# FLEX MD&A — 0000866374-25-000051


## mdna

[0000866374-25-000051:mdna:1]
[same as prior period, unchanged from 0000866374-25-000043:mdna:1]

[0000866374-25-000051:mdna:2]
[same as prior period, unchanged from 0000866374-25-000043:mdna:2]

[0000866374-25-000051:mdna:3]
[same as prior period, unchanged from 0000866374-25-000043:mdna:3]

[0000866374-25-000051:mdna:4]
We are the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we deliver technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. Our full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. We partner with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, and power. As of September 26, 2025, our two operating and reportable segments were as follows:

[0000866374-25-000051:mdna:5]
[same as prior period, unchanged from 0000866374-25-000043:mdna:5]

[0000866374-25-000051:mdna:6]
[same as prior period, unchanged from 0000866374-25-000043:mdna:6]

[0000866374-25-000051:mdna:7]
[same as prior period, unchanged from 0000866374-25-000043:mdna:7]

[0000866374-25-000051:mdna:8]
[same as prior period, unchanged from 0000866374-25-000043:mdna:8]

[0000866374-25-000051:mdna:9]
[same as prior period, unchanged from 0000866374-25-000043:mdna:9]

[0000866374-25-000051:mdna:10]
◦Industrial, including industrial devices, capital equipment, renewables, critical power, and embedded power

[0000866374-25-000051:mdna:11]
[same as prior period, unchanged from 0000866374-25-000043:mdna:11]

[0000866374-25-000051:mdna:12]
[same as prior period, unchanged from 0000866374-25-000043:mdna:12]

[0000866374-25-000051:mdna:13]
[same as prior period, unchanged from 0000866374-25-000043:mdna:13]

[0000866374-25-000051:mdna:14]
[same as prior period, unchanged from 0000866374-25-000043:mdna:14]

[0000866374-25-000051:mdna:15]
[same as prior period, unchanged from 0000866374-25-000043:mdna:15]

[0000866374-25-000051:mdna:16]
We believe that our strategy has positioned us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-25-000051:mdna:17]
[same as prior period, unchanged from 0000866374-25-000043:mdna:17]

[0000866374-25-000051:mdna:18]
Russian Invasion of Ukraine and Israel-Hamas Conflict

[0000866374-25-000051:mdna:19]
We continue to monitor and respond to the conflict in Ukraine and the associated sanctions and other restrictions. We also are monitoring and responding to the Israel-Hamas conflict. The full impact of the conflicts on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflicts and their impact on regional and global economic conditions. We will continue to monitor the conflicts and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-25-000051:mdna:20]
During the three months ended September 26, 2025, the Company recognized a total of $41 million primarily in asset impairments and inventory write-downs as a result of a missile strike on its Mukachevo, Ukraine facility in Western Ukraine on August 21, 2025. The missile strike represents an unusual and infrequent event as hostilities related to the Russian invasion of Ukraine have been primarily focused in Eastern Ukraine. The missile strike caused substantial physical damage and disrupted normal operations at the facility. In response, the Company activated contingency manufacturing plans and transitioned production to alternative facilities. As restoration activities progress in Mukachevo, the Company expects to incur additional near-term inefficiencies. The $41 million in asset impairments and inventory write-downs are included in restructuring and impairment charges. For further information, refer to Part I, Item 1A, Risk Factors - “Global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets have in the past adversely affected, and may in the future adversely affect, our business, results of operations, financial condition, and access to capital markets.” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0000866374-25-000051:mdna:21]
[same as prior period, unchanged from 0000866374-25-000043:mdna:20]

[0000866374-25-000051:mdna:22]
In the fourth quarter of our fiscal year ended March 31, 2025, the U.S. implemented a series of global tariffs, including on a number of countries in which Flex operates. Although we have been and expect to continue to be able to pass tariff costs through to our customers, the global tariff landscape, which continues to evolve, has the potential to meaningfully impact end customer demand. During the three and six-month periods ended September 26, 2025, tariff costs paid and recoveries from our customers impacted our revenues and costs of goods by approximately one percent and had a negligible impact on our profitability. If, in the future, we are no longer able to fully pass through these tariffs, our results from operations and cash flows would be negatively impacted. For further information, refer to Part I, Item 1A, Risk Factors - "Global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets have in the past adversely affected, and may in the future adversely affect, our business, results of operations, financial condition, and access to capital markets." in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0000866374-25-000051:mdna:23]
29

[0000866374-25-000051:mdna:24]
[same as prior period, unchanged from 0000866374-25-000043:mdna:23]

[0000866374-25-000051:mdna:25]
We are one of the world's largest providers of global supply chain solutions, with revenues of $13.4 billion for the six-month period ended September 26, 2025 and $25.8 billion in the fiscal year ended March 31, 2025. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of approximately 100 facilities in approximately 30 countries across four continents. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites.

[0000866374-25-000051:mdna:26]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 3,400 |  |  | 50 | % |  | $ | 3,147 |  |  | 48 | % |  | $ | 6,764 |  |  | 51 | % |  | $ | 6,165 |  |  | 48 | % |
| Asia | 2,019 |  |  | 30 | % |  | 2,020 |  |  | 31 | % |  | 3,889 |  |  | 29 | % |  | 3,927 |  |  | 31 | % |
| Europe | 1,385 |  |  | 20 | % |  | 1,378 |  |  | 21 | % |  | 2,726 |  |  | 20 | % |  | 2,767 |  |  | 21 | % |
|  | $ | 6,804 |  |  |  |  | $ | 6,545 |  |  |  |  | $ | 13,379 |  |  |  |  | $ | 12,859 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 1,688 |  |  | 25 | % |  | $ | 1,734 |  |  | 26 | % |  | $ | 3,397 |  |  | 25 | % |  | $ | 3,321 |  |  | 26 | % |
| U.S. | 1,336 |  |  | 20 | % |  | 978 |  |  | 15 | % |  | 2,619 |  |  | 20 | % |  | 1,982 |  |  | 15 | % |
| China | 1,123 |  |  | 17 | % |  | 1,109 |  |  | 17 | % |  | 2,195 |  |  | 16 | % |  | 2,177 |  |  | 17 | % |
| Malaysia | 656 |  |  | 10 | % |  | 608 |  |  | 9 | % |  | 1,253 |  |  | 9 | % |  | 1,199 |  |  | 9 | % |
| Brazil | 355 |  |  | 5 | % |  | 412 |  |  | 6 | % |  | 709 |  |  | 5 | % |  | 812 |  |  | 6 | % |
| Hungary | 342 |  |  | 5 | % |  | 328 |  |  | 5 | % |  | 688 |  |  | 5 | % |  | 671 |  |  | 5 | % |
| Other | 1,304 |  |  | 18 | % |  | 1,376 |  |  | 22 | % |  | 2,518 |  |  | 20 | % |  | 2,697 |  |  | 22 | % |
|  | $ | 6,804 |  |  |  |  | $ | 6,545 |  |  |  |  | $ | 13,379 |  |  |  |  | $ | 12,859 |  |  |  |

[0000866374-25-000051:mdna:27]
|  | As of |  | As of |
|  | September 26, 2025 |  | March 31, 2025 |
| Property and equipment, net: | (In millions) |
| Mexico | $ | 826 |  |  | 35 | % |  | $ | 815 |  |  | 35 | % |
| U.S. | 383 |  |  | 16 | % |  | 376 |  |  | 16 | % |
| China | 294 |  |  | 13 | % |  | 293 |  |  | 13 | % |
| Malaysia | 181 |  |  | 8 | % |  | 163 |  |  | 7 | % |
| Hungary | 153 |  |  | 7 | % |  | 140 |  |  | 6 | % |
| Brazil | 80 |  |  | 3 | % |  | 83 |  |  | 4 | % |
| Other | 435 |  |  | 18 | % |  | 460 |  |  | 19 | % |
|  | $ | 2,352 |  |  |  |  | $ | 2,330 |  |  |  |

[0000866374-25-000051:mdna:28]
[same as prior period, unchanged from 0000866374-25-000043:mdna:27]

[0000866374-25-000051:mdna:29]
[same as prior period, unchanged from 0000866374-25-000043:mdna:28]

[0000866374-25-000051:mdna:30]
•global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, including trade restrictions impacting the semiconductor supply chain, tariffs, geopolitical uncertainty and conflicts (including the ongoing Russia-Ukraine conflict) and instability in financial markets;

[0000866374-25-000051:mdna:31]
[same as prior period, unchanged from 0000866374-25-000043:mdna:101]

[0000866374-25-000051:mdna:32]
•the impacts on our business due to supply chain issues, including component shortages, semiconductors and particularly involving suppliers who are our sole or primary sources, disruptions in transportation or other supply chain related constraints;

[0000866374-25-000051:mdna:33]
[same as prior period, unchanged from 0000866374-25-000043:mdna:31]

[0000866374-25-000051:mdna:34]
[same as prior period, unchanged from 0000866374-25-000043:mdna:32]

[0000866374-25-000051:mdna:35]
[same as prior period, unchanged from 0000866374-25-000043:mdna:33]

[0000866374-25-000051:mdna:36]
[same as prior period, unchanged from 0000866374-25-000043:mdna:34]

[0000866374-25-000051:mdna:37]
[same as prior period, unchanged from 0000866374-25-000043:mdna:35]

[0000866374-25-000051:mdna:38]
[same as prior period, unchanged from 0000866374-25-000043:mdna:37]

[0000866374-25-000051:mdna:39]
[same as prior period, unchanged from 0000866374-25-000043:mdna:38]

[0000866374-25-000051:mdna:40]
•changes in tax legislation; and

[0000866374-25-000051:mdna:41]
•changes in trade regulations and treaties

[0000866374-25-000051:mdna:42]
[same as prior period, unchanged from 0000866374-25-000043:mdna:42]

[0000866374-25-000051:mdna:43]
[same as prior period, unchanged from 0000866374-25-000043:mdna:43]

[0000866374-25-000051:mdna:44]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas conflict), there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-25-000051:mdna:45]
[same as prior period, unchanged from 0000866374-25-000043:mdna:45]

[0000866374-25-000051:mdna:46]
31

[0000866374-25-000051:mdna:47]
[same as prior period, unchanged from 0000866374-25-000043:mdna:47]

[0000866374-25-000051:mdna:48]
[same as prior period, unchanged from 0000866374-25-000043:mdna:48]

[0000866374-25-000051:mdna:49]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 90.8 |  |  | 91.6 |  |  | 90.9 |  |  | 92.0 |  |
| Restructuring charges | 0.2 |  |  | 0.3 |  |  | 0.2 |  |  | 0.2 |  |
| Gross profit | 9.0 |  |  | 8.1 |  |  | 8.9 |  |  | 7.8 |  |
| Selling, general and administrative expenses | 3.8 |  |  | 3.3 |  |  | 3.7 |  |  | 3.3 |  |
| Restructuring and impairment charges | 0.6 |  |  | — |  |  | 0.4 |  |  | 0.1 |  |
| Intangible amortization | 0.2 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Operating income | 4.4 |  |  | 4.5 |  |  | 4.5 |  |  | 4.1 |  |
| Interest expense | 0.8 |  |  | 0.8 |  |  | 0.8 |  |  | 0.8 |  |
| Interest income | 0.1 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Other charges (income), net | (0.1) |  |  | (0.1) |  |  | (0.1) |  |  | — |  |
| Equity in earnings (losses) of unconsolidated affiliates | (0.1) |  |  | — |  |  | (0.2) |  |  | — |  |
| Income before income taxes | 3.9 |  |  | 4.0 |  |  | 3.8 |  |  | 3.5 |  |
| Provision for (benefit from) income taxes | 1.0 |  |  | 0.7 |  |  | 0.9 |  |  | 0.8 |  |
| Net income | 2.9 | % |  | 3.3 | % |  | 2.9 | % |  | 2.7 | % |

[0000866374-25-000051:mdna:50]
[same as prior period, unchanged from 0000866374-25-000043:mdna:50]

[0000866374-25-000051:mdna:51]
[same as prior period, unchanged from 0000866374-25-000043:mdna:51]

[0000866374-25-000051:mdna:52]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,766 |  |  | 55 | % |  | $ | 3,606 |  |  | 55 | % |  | $ | 7,457 |  |  | 56 | % |  | $ | 6,971 |  |  | 54 | % |
| Flex Reliability Solutions | 3,038 |  |  | 45 | % |  | 2,939 |  |  | 45 | % |  | 5,922 |  |  | 44 | % |  | 5,888 |  |  | 46 | % |
|  | $ | 6,804 |  |  |  |  | $ | 6,545 |  |  |  |  | $ | 13,379 |  |  |  |  | $ | 12,859 |  |  |  |

[0000866374-25-000051:mdna:53]
Net sales during the three-month period ended September 26, 2025 totaled $6.8 billion, representing an increase of approximately $0.3 billion, or 4% from $6.5 billion during the three-month period ended September 27, 2024. Net sales for our FAS segment increased approximately $0.2 billion, or 4% from the three-month period ended September 27, 2024, primarily driven by a mid-teen percentage increase in our CEC business from increased demand in data center cloud, partially offset by an expected decrease in traditional telecom and consumer end-markets. Net sales for our FRS segment increased approximately $0.1 billion, or 3% from the three-month period ended September 27, 2024, which was primarily driven by low double-digit growth in our Industrial business with strength in power and moderate growth in Health Solutions, partially offset by a mid-single-digit decrease in our Automotive business due to lower demand. Net sales remained consistent in Asia and Europe at $2.0 billion and $1.4 billion, respectively and increased $0.3 billion to $3.4 billion in the Americas.

[0000866374-25-000051:mdna:54]
Net sales during the six-month period ended September 26, 2025 totaled $13.4 billion, representing an increase of approximately $0.5 billion, or 4% from $12.9 billion during the six-month period ended September 27, 2024. Net sales for our FAS segment increased approximately $0.5 billion, or 7% from the six-month period ended September 27, 2024, primarily driven by a high-teen percentage increase in our CEC business from increased demand in data center cloud, partially offset by a significant decrease in our Consumer Devices business due to lower demand. Net sales for our FRS segment increased

[0000866374-25-000051:mdna:55]
32

[0000866374-25-000051:mdna:56]
approximately $34 million, or 1% from the six-month period ended September 27, 2024, primarily driven by a low single-digit percentage increase in our Industrial business, primarily in power due to data center growth and business acquisitions, offset by a mid-single-digit percentage decrease in our Automotive business due to lower demand. Net sales remained consistent in Asia at $3.9 billion, decreased by $0.1 billion to $2.7 billion in Europe, and increased $0.6 billion to $6.8 billion in the Americas.

[0000866374-25-000051:mdna:57]
Our ten largest customers during the three and six-month periods ended September 26, 2025 accounted for approximately 46% and 47% of net sales, respectively. No customer accounted for more than 10% of net sales during the six-month periods ended September 26, 2025 or September 27, 2024.

[0000866374-25-000051:mdna:58]
[same as prior period, unchanged from 0000866374-25-000043:mdna:56]

[0000866374-25-000051:mdna:59]
[same as prior period, unchanged from 0000866374-25-000043:mdna:57]

[0000866374-25-000051:mdna:60]
Cost of sales during the three-month period ended September 26, 2025 totaled $6.2 billion, representing an increase of $0.2 billion, or 3% from $6.0 billion during the three-month period ended September 27, 2024. The higher cost of sales for the three-month period ended September 26, 2025 was primarily driven by a $0.3 billion, or 4%, increase in consolidated sales, partially offset by cost efficiencies and favorable mix. Cost of sales in our FAS segment for the three-month period ended September 26, 2025 increased by 4% from the three-month period ended September 27, 2024, in line with revenue growth. Cost of sales in our FRS segment for the three-month period ended September 26, 2025 increased by 2% from the three-month period ended September 27, 2024, primarily driven by revenue growth of 3%, partially offset by favorable mix and cost efficiencies.

[0000866374-25-000051:mdna:61]
Cost of sales during the six-month period ended September 26, 2025 totaled $12.2 billion, representing an increase of $0.3 billion, or 3% from $11.8 billion during the six-month period ended September 27, 2024. The higher cost of sales for the six-month period ended September 26, 2025 was primarily driven by a $0.5 billion, or 4% increase in consolidated sales. Cost of sales in our FAS segment for the six-month period ended September 26, 2025 increased approximately $0.4 billion, or 6%, from the six-month period ended September 27, 2024 due to revenue growth of 7%. Cost of sales in our FRS segment for the six-month period ended September 26, 2025 decreased approximately $0.1 billion, or 1%, from the six-month period ended September 27, 2024 due to a favorable mix and cost efficiencies, partially offset by revenue growth of 1%.

[0000866374-25-000051:mdna:62]
[same as prior period, unchanged from 0000866374-25-000043:mdna:59]

[0000866374-25-000051:mdna:63]
[same as prior period, unchanged from 0000866374-25-000043:mdna:60]

[0000866374-25-000051:mdna:64]
Gross profit during the three-month period ended September 26, 2025 increased $0.1 billion to $0.6 billion, or 9.0% of net sales, from $0.5 billion, or 8.1% of net sales, during the three-month period ended September 27, 2024. Gross margin improved 90 basis points year over year primarily due to favorable mix and continued operational execution.

[0000866374-25-000051:mdna:65]
Gross profit during the six-month period ended September 26, 2025 increased $0.2 billion to $1.2 billion, or 8.9% of net sales, from $1.0 billion, or 7.8% of net sales, during the six-month period ended September 27, 2024. Gross margin improved 110 basis points year over year primarily due to favorable mix and continued operational execution.

[0000866374-25-000051:mdna:66]
[same as prior period, unchanged from 0000866374-25-000043:mdna:62]

[0000866374-25-000051:mdna:67]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, certain restructuring and impairment charges, customer related asset impairment, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of

[0000866374-25-000051:mdna:68]
unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-25-000051:mdna:69]
[same as prior period, unchanged from 0000866374-25-000043:mdna:64]

[0000866374-25-000051:mdna:70]
[same as prior period, unchanged from 0000866374-25-000043:mdna:65]

[0000866374-25-000051:mdna:71]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 227 |  |  | 6.0 | % |  | $ | 218 |  |  | 6.1 | % |  | $ | 467 |  |  | 6.3 | % |  | $ | 397 |  |  | 5.7 | % |
| Flex Reliability Solutions | 197 |  |  | 6.5 | % |  | 159 |  |  | 5.4 | % |  | 369 |  |  | 6.2 | % |  | 306 |  |  | 5.2 | % |

[0000866374-25-000051:mdna:72]
FAS segment margin decreased by 10 basis points to 6.0% for the three-month period ended September 26, 2025, compared to the three-month period ended September 27, 2024, as continued margin growth in cloud was offset by the effect of revenue decreases in our consumer businesses. The FAS segment margin increased approximately 60 basis points, to 6.3% for the six-month period ended September 26, 2025 from 5.7% for the six-month period ended September 27, 2024, primarily due to continued margin growth in cloud offset by the effect of revenue decreases in our consumer businesses.

[0000866374-25-000051:mdna:73]
FRS segment margin increased approximately 110 basis points to 6.5% for the three-month period ended September 26, 2025, compared to 5.4% for the three-month period ended September 27, 2024, primarily driven by favorable mix with growth in power and renewables. FRS segment margin increased approximately 100 basis points to 6.2% for the six-month period ended September 26, 2025 compared to 5.2% for the six-month period ended September 27, 2024, primarily driven by favorable mix and strong execution across the portfolio.

[0000866374-25-000051:mdna:74]
Restructuring and impairment charges

[0000866374-25-000051:mdna:75]
We undertook targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. During the three and six-month periods ended September 26, 2025, we recognized approximately $10 million and $33 million of restructuring charges, respectively, primarily related to employee severance. In addition, we incurred $41 million in impairment and other charges related to a missile strike on our Mukachevo, Ukraine facility, as discussed in the Overview section above.

[0000866374-25-000051:mdna:76]
[same as prior period, unchanged from 0000866374-25-000043:mdna:72]

[0000866374-25-000051:mdna:77]
Selling, general and administrative expenses (“SG&A”) was $0.3 billion, or 3.8% of net sales, during the three-month period ended September 26, 2025, increasing by $44 million compared to the three-month period ended September 27, 2024. The increase was largely driven by increases in employee compensation and other corporate costs. SG&A was $0.5 billion or 3.7%, of net sales, during the six-month period ended September 26, 2025, increasing $64 million from $0.4 billion or 3.3% of net sales during the six-month period ended September 27, 2024, driven by the same factors as noted for the three-month period.

[0000866374-25-000051:mdna:78]
[same as prior period, unchanged from 0000866374-25-000043:mdna:74]

[0000866374-25-000051:mdna:79]
Amortization of intangible assets remained consistent at $16 million for the three-month period ended September 26, 2025, compared to $16 million in the previous year as amortization related to acquisitions from the second half of fiscal year 2025 was offset by the effect of other intangible assets fully amortizing at the end of the first quarter of fiscal year 2026. Amortization increased to $37 million during the six-month period ended September 26, 2025, from $32 million for the six-month period ended September 27, 2024 as a result of acquisitions from the second half of fiscal year 2025.

[0000866374-25-000051:mdna:80]
[same as prior period, unchanged from 0000866374-25-000043:mdna:76]

[0000866374-25-000051:mdna:81]
Interest expense decreased to $52 million for the three-month period ended September 26, 2025, from $53 million during the three-month period ended September 27, 2024. Interest expense decreased to $103 million during the six-month period ended September 26, 2025 compared to $109 million during the six-month period ended September 27, 2024. Decreased interest expense was primarily driven by a decrease in lower commercial paper borrowings and reduced receivables factoring costs, partially offset by increased interest expense on our long-term debt.

[0000866374-25-000051:mdna:82]
[same as prior period, unchanged from 0000866374-25-000043:mdna:78]

[0000866374-25-000051:mdna:83]
Interest income decreased to $10 million for the three-month period ended September 26, 2025 compared to $16 million for the same period in fiscal year 2025. Interest income decreased to $23 million for the six-month period ended September 26, 2025 compared to $32 million for the six-month period ended September 27, 2024. The decrease in interest income is primarily due to  lower interest rates.

[0000866374-25-000051:mdna:84]
[same as prior period, unchanged from 0000866374-25-000043:mdna:80]

[0000866374-25-000051:mdna:85]
Other income, net was $13 million during the three-month period ended September 26, 2025 compared to $8 million during the three-month period ended September 27, 2024, primarily due to a higher tax receivable agreement payment from Flex's former subsidiary Nextracker partially offset by fluctuations in foreign exchange rates during the quarter.

[0000866374-25-000051:mdna:86]
Other income, net remained consistent at $6 million for the six-month periods ended September 26, 2025 and September 27, 2024 as increased foreign exchanges losses offset the effect of higher tax receivable agreement payments from Nextracker.

[0000866374-25-000051:mdna:87]
[same as prior period, unchanged from 0000866374-25-000043:mdna:82]

[0000866374-25-000051:mdna:88]
Equity in losses of unconsolidated affiliates of $5 million during the three-month period ended September 26, 2025 was consistent with losses of $4 million in the three-month period ended September 27, 2024, due to losses in certain non-core equity method investments.

[0000866374-25-000051:mdna:89]
Equity in losses of unconsolidated affiliates was $25 million during the six-month period ended September 26, 2025, compared to $3 million in the six-month period ended September 27, 2024, primarily due to a $17 million loss related to a specific venture capital fund in the three-month period ended June 27, 2025.

[0000866374-25-000051:mdna:90]
[same as prior period, unchanged from 0000866374-25-000043:mdna:84]

[0000866374-25-000051:mdna:91]
[same as prior period, unchanged from 0000866374-25-000043:mdna:85]

[0000866374-25-000051:mdna:92]
The consolidated effective tax rate was 24% and 23% for the three and six-month periods ended September 26, 2025, and 19% and 23% for the three and six-month periods ended September 27, 2024, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effects of certain tax holidays and incentives granted to our subsidiaries primarily in China, Costa Rica, Malaysia, the Netherlands and Israel. The effective tax rate for the three-month period ended September 26, 2025 was higher than the effective tax rate for the three-month period ended September 27, 2024, for a variety of reasons, primarily due to the changing jurisdiction of income and the minimal tax benefit recorded on the $41 million Mukachevo, Ukraine asset impairment and related charges recognized in the three-months ended September 26, 2025.

[0000866374-25-000051:mdna:93]
The OECD Pillar Two Global Anti-Base Erosion (“GloBE”) model rules, issued under the OECD Inclusive Framework on Base Erosion and Profit Shifting, introduce a global minimum tax of 15% applicable to multinational enterprise groups with consolidated financial statement revenue in excess of €750 million. Numerous foreign jurisdictions have already enacted tax legislation based on the GloBE rules, with some effective as early as January 1, 2024. As of September 26, 2025, the Company has reflected all estimated impacts of the Pillar Two GloBE minimum tax accordingly within its estimated annual effective tax rate for the year.

[0000866374-25-000051:mdna:94]
On July 4, 2025, The One Big Beautiful Bill Act (“OBBBA”) was enacted in the U.S. The OBBBA makes permanent various provisions of the Tax Cuts and Jobs Act which otherwise would have expired as well as makes significant modifications to the U.S. international tax framework. The Company is in the process of evaluating the impact of the OBBBA to our consolidated financial statements.

[0000866374-25-000051:mdna:95]
[same as prior period, unchanged from 0000866374-25-000043:mdna:90]

[0000866374-25-000051:mdna:96]
Net income was $199 million during the three-month period ended September 26, 2025, compared to $214 million during the three-month period ended September 27, 2024 and net income was $391 million during the six-month period ended September 26, 2025 compared to $353 million during the six-month period ended September 27, 2024, driven by the factors discussed above.

[0000866374-25-000051:mdna:97]
35

[0000866374-25-000051:mdna:98]
[same as prior period, unchanged from 0000866374-25-000043:mdna:92]

[0000866374-25-000051:mdna:99]
We continuously evaluate our ability to meet our obligations over the next 12 months and beyond and proactively reset our capital structure to improve maturities and liquidity. We expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of September 26, 2025, we had cash and cash equivalents of approximately $2.2 billion, bank and other borrowings of approximately $3.7 billion and a $2.75 billion revolving credit facility under which we had no borrowings outstanding. As of September 26, 2025, we were in compliance with the covenants under all of our credit facilities and indentures; we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-25-000051:mdna:100]
Cash provided by operating activities was $0.9 billion during the six-month period ended September 26, 2025, primarily driven by $0.4 billion of net income for the period plus $0.3 billion of non-cash charges such as depreciation, amortization, and impairment charges and $0.2 billion of changes in working capital and other.

[0000866374-25-000051:mdna:101]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital increased approximately $0.5 billion to $3.5 billion as of September 26, 2025, from $3.0 billion as of March 31, 2025. The increase was primarily the result of a $0.5 billion decrease in the current portion of long-term debt driven by the repayment of the 4.750% Senior Notes during the first quarter. Other movements in working capital largely offset themselves with increases of $0.2 billion in accounts receivable, $0.2 billion in contract assets, $0.2 billion in inventory, and $0.5 billion in other current assets, against increases of $1.0 billion in accounts payable and $0.1 billion in other current liabilities.

[0000866374-25-000051:mdna:102]
Net cash used in investing activities was $0.3 billion during the six-month period ended September 26, 2025. This was primarily driven by $0.3 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our business growth as well as payment for a business acquisition during the period.

[0000866374-25-000051:mdna:103]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investors. Our free cash flow for the six-month periods ended September 26, 2025 and September 27, 2024 was an inflow of $0.6 billion and $0.5 billion, respectively. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-25-000051:mdna:104]
|  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 852 |  |  | $ | 659 |  |
| Purchases of property and equipment | (283) |  |  | (214) |  |
| Proceeds from the disposition of property and equipment | 4 |  |  | 6 |  |
| Free cash flow | $ | 573 |  |  | $ | 451 |  |

[0000866374-25-000051:mdna:105]
Cash used by financing activities was $0.6 billion during the six-month period ended September 26, 2025, which was primarily driven by $0.5 billion of cash paid for the repurchase of our ordinary shares and debt repayments of $0.5 billion, offset by borrowings of $0.5 billion.

[0000866374-25-000051:mdna:106]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months and beyond. As of September 26, 2025 and March 31, 2025, approximately 59% and 81%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $0.8 billion as of March 31, 2025). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of

[0000866374-25-000051:mdna:107]
Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-25-000051:mdna:108]
[same as prior period, unchanged from 0000866374-25-000043:mdna:103]

[0000866374-25-000051:mdna:109]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of September 26, 2025.

[0000866374-25-000051:mdna:110]
[same as prior period, unchanged from 0000866374-25-000043:mdna:105]

[0000866374-25-000051:mdna:111]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-25-000051:mdna:112]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1.7 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 6, 2025. During the six-month period ended September 26, 2025, we paid $0.5 billion to repurchase shares under the current and previous repurchase plans at an average price of $42.35 per share. As of September 26, 2025, shares in the aggregate amount of $1.5 billion were available to be repurchased under the current plan.

[0000866374-25-000051:mdna:113]
Warrant

[0000866374-25-000051:mdna:114]
On August 15, 2025, the Company issued a warrant (the “Warrant”) to Amazon.com NV Investment Holdings LLC (“Warrantholder”), a wholly-owned subsidiary of Amazon.com, Inc. (“Parent”) to purchase up to an aggregate of 3,859,851 ordinary shares of the Company (“Warrant Shares”) at an exercise price of $51.29 per share. The Warrant allows for cashless exercise and expires on August 15, 2030. The Warrant Shares are subject to vesting based on qualifying payments (as defined in the Warrant) for the purchase of all products and services by or on behalf of Parent and its affiliates over the term of the Warrant. The expense associated with the Warrant Shares will be recorded as a deduction to revenue as the customer purchases products and services over the vesting period. The Company recorded charges of $2 million during the three months ended September 26, 2025.

[0000866374-25-000051:mdna:115]
[same as prior period, unchanged from 0000866374-25-000043:mdna:108]

[0000866374-25-000051:mdna:116]
[same as prior period, unchanged from 0000866374-25-000043:mdna:109]

[0000866374-25-000051:mdna:117]
In June 2025, the Company drew down the 2027 Delayed Draw Term Loan and repaid the 4.750% Senior Notes due June 2025. There were no other material changes in our contractual obligations and commitments as of September 26, 2025.
