# FLEX MD&A — 0000866374-26-000005


## mdna

[0000866374-26-000005:mdna:1]
[same as prior period, unchanged from 0000866374-25-000051:mdna:1]

[0000866374-26-000005:mdna:2]
[same as prior period, unchanged from 0000866374-25-000051:mdna:2]

[0000866374-26-000005:mdna:3]
[same as prior period, unchanged from 0000866374-25-000051:mdna:3]

[0000866374-26-000005:mdna:4]
We are the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we deliver technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. Our full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. We partner with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, and power. As of December 31, 2025, our two operating and reportable segments were as follows:

[0000866374-26-000005:mdna:5]
[same as prior period, unchanged from 0000866374-25-000051:mdna:5]

[0000866374-26-000005:mdna:6]
[same as prior period, unchanged from 0000866374-25-000051:mdna:6]

[0000866374-26-000005:mdna:7]
[same as prior period, unchanged from 0000866374-25-000051:mdna:7]

[0000866374-26-000005:mdna:8]
[same as prior period, unchanged from 0000866374-25-000051:mdna:8]

[0000866374-26-000005:mdna:9]
[same as prior period, unchanged from 0000866374-25-000051:mdna:9]

[0000866374-26-000005:mdna:10]
[same as prior period, unchanged from 0000866374-25-000051:mdna:10]

[0000866374-26-000005:mdna:11]
[same as prior period, unchanged from 0000866374-25-000051:mdna:11]

[0000866374-26-000005:mdna:12]
[same as prior period, unchanged from 0000866374-25-000051:mdna:12]

[0000866374-26-000005:mdna:13]
[same as prior period, unchanged from 0000866374-25-000051:mdna:13]

[0000866374-26-000005:mdna:14]
[same as prior period, unchanged from 0000866374-25-000051:mdna:14]

[0000866374-26-000005:mdna:15]
[same as prior period, unchanged from 0000866374-25-000051:mdna:15]

[0000866374-26-000005:mdna:16]
[same as prior period, unchanged from 0000866374-25-000051:mdna:16]

[0000866374-26-000005:mdna:17]
[same as prior period, unchanged from 0000866374-25-000051:mdna:17]

[0000866374-26-000005:mdna:18]
[same as prior period, unchanged from 0000866374-25-000051:mdna:18]

[0000866374-26-000005:mdna:19]
[same as prior period, unchanged from 0000866374-25-000051:mdna:19]

[0000866374-26-000005:mdna:20]
During the three and nine-month periods ended December 31, 2025, the Company recognized $5 million and $46 million, respectively, in asset impairments, inventory write-downs and other charges as a result of a missile strike on its Mukachevo, Ukraine facility in Western Ukraine on August 21, 2025. The missile strike represents an unusual and infrequent event as hostilities related to the Russian invasion of Ukraine have been primarily focused in Eastern Ukraine. The missile strike caused substantial physical damage and disrupted normal operations at the facility. In response, the Company activated contingency manufacturing plans and transitioned production to alternative facilities. As restoration activities progress in Mukachevo, the Company expects to incur additional near-term inefficiencies. The $46 million in asset impairments, inventory write-downs and other charges are included in restructuring and impairment charges in the condensed consolidated statements of operations. For further information, refer to Part I, Item 1A, Risk Factors - “Global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets have in the past adversely affected, and may in the future adversely affect, our business, results of operations, financial condition, and access to capital markets.” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0000866374-26-000005:mdna:21]
[same as prior period, unchanged from 0000866374-25-000051:mdna:21]

[0000866374-26-000005:mdna:22]
In the fourth quarter of our fiscal year ended March 31, 2025, the U.S. implemented a series of global tariffs, including on a number of countries in which Flex operates. Although we have been and expect to continue to be able to pass tariff costs through to our customers, the global tariff landscape, which continues to evolve, has the potential to meaningfully impact end customer demand. During the three and nine-month periods ended December 31, 2025, tariff costs paid and recoveries from our customers impacted our revenues and costs of goods by approximately one percent and had a negligible impact on our profitability. If, in the future, we are no longer able to fully pass through these tariffs, our results from operations and cash flows would be negatively impacted. There are several court cases challenging the U.S. administration’s authority to impose tariffs, including a case pending before the U.S. Supreme Court, the outcomes of which could add complexity to our operations in terms of seeking refunds from the U.S. government and adjusting pricing with customers. For further information, refer to Part I, Item 1A, Risk Factors - "Global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets have in the past adversely affected, and may in the future adversely affect, our business, results of operations, financial condition, and access to capital markets." in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0000866374-26-000005:mdna:23]
[same as prior period, unchanged from 0000866374-25-000051:mdna:31]

[0000866374-26-000005:mdna:24]
[same as prior period, unchanged from 0000866374-25-000051:mdna:24]

[0000866374-26-000005:mdna:25]
We are one of the world's largest providers of global supply chain solutions, with revenues of $20.4 billion for the nine-month period ended December 31, 2025 and $25.8 billion in the fiscal year ended March 31, 2025. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of approximately 100 facilities in approximately 30 countries across four continents. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites.

[0000866374-26-000005:mdna:26]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 3,371 |  |  | 48 | % |  | $ | 3,195 |  |  | 49 | % |  | $ | 10,135 |  |  | 50 | % |  | $ | 9,360 |  |  | 48 | % |
| Asia | 2,233 |  |  | 32 | % |  | 1,998 |  |  | 30 | % |  | 6,122 |  |  | 30 | % |  | 5,925 |  |  | 31 | % |
| Europe | 1,454 |  |  | 20 | % |  | 1,363 |  |  | 21 | % |  | 4,180 |  |  | 20 | % |  | 4,130 |  |  | 21 | % |
|  | $ | 7,058 |  |  |  |  | $ | 6,556 |  |  |  |  | $ | 20,437 |  |  |  |  | $ | 19,415 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 1,719 |  |  | 24 | % |  | $ | 1,721 |  |  | 26 | % |  | $ | 5,116 |  |  | 25 | % |  | $ | 5,042 |  |  | 26 | % |
| U.S. | 1,219 |  |  | 17 | % |  | 1,071 |  |  | 16 | % |  | 3,838 |  |  | 19 | % |  | 3,053 |  |  | 16 | % |
| China | 1,159 |  |  | 16 | % |  | 1,101 |  |  | 17 | % |  | 3,354 |  |  | 16 | % |  | 3,278 |  |  | 17 | % |
| Malaysia | 828 |  |  | 12 | % |  | 630 |  |  | 10 | % |  | 2,081 |  |  | 10 | % |  | 1,829 |  |  | 9 | % |
| Brazil | 414 |  |  | 6 | % |  | 386 |  |  | 6 | % |  | 1,123 |  |  | 5 | % |  | 1,198 |  |  | 6 | % |
| Hungary | 317 |  |  | 4 | % |  | 313 |  |  | 5 | % |  | 1,005 |  |  | 5 | % |  | 984 |  |  | 5 | % |
| Other | 1,402 |  |  | 21 | % |  | 1,334 |  |  | 20 | % |  | 3,920 |  |  | 20 | % |  | 4,031 |  |  | 21 | % |
|  | $ | 7,058 |  |  |  |  | $ | 6,556 |  |  |  |  | $ | 20,437 |  |  |  |  | $ | 19,415 |  |  |  |

[0000866374-26-000005:mdna:27]
|  | As of |  | As of |
|  | December 31, 2025 |  | March 31, 2025 |
| Property and equipment, net: | (In millions) |
| Mexico | $ | 833 |  |  | 35 | % |  | $ | 815 |  |  | 35 | % |
| U.S. | 416 |  |  | 17 | % |  | 376 |  |  | 16 | % |
| China | 293 |  |  | 12 | % |  | 293 |  |  | 13 | % |
| Malaysia | 186 |  |  | 8 | % |  | 163 |  |  | 7 | % |
| Hungary | 155 |  |  | 6 | % |  | 140 |  |  | 6 | % |
| Brazil | 78 |  |  | 3 | % |  | 83 |  |  | 4 | % |
| Other | 432 |  |  | 19 | % |  | 460 |  |  | 19 | % |
|  | $ | 2,393 |  |  |  |  | $ | 2,330 |  |  |  |

[0000866374-26-000005:mdna:28]
[same as prior period, unchanged from 0000866374-25-000051:mdna:28]

[0000866374-26-000005:mdna:29]
[same as prior period, unchanged from 0000866374-25-000051:mdna:29]

[0000866374-26-000005:mdna:30]
[same as prior period, unchanged from 0000866374-25-000051:mdna:30]

[0000866374-26-000005:mdna:31]
[same as prior period, unchanged from 0000866374-25-000051:mdna:46]

[0000866374-26-000005:mdna:32]
[same as prior period, unchanged from 0000866374-25-000051:mdna:32]

[0000866374-26-000005:mdna:33]
[same as prior period, unchanged from 0000866374-25-000051:mdna:33]

[0000866374-26-000005:mdna:34]
[same as prior period, unchanged from 0000866374-25-000051:mdna:34]

[0000866374-26-000005:mdna:35]
[same as prior period, unchanged from 0000866374-25-000051:mdna:35]

[0000866374-26-000005:mdna:36]
[same as prior period, unchanged from 0000866374-25-000051:mdna:36]

[0000866374-26-000005:mdna:37]
[same as prior period, unchanged from 0000866374-25-000051:mdna:37]

[0000866374-26-000005:mdna:38]
[same as prior period, unchanged from 0000866374-25-000051:mdna:38]

[0000866374-26-000005:mdna:39]
[same as prior period, unchanged from 0000866374-25-000051:mdna:39]

[0000866374-26-000005:mdna:40]
[same as prior period, unchanged from 0000866374-25-000051:mdna:40]

[0000866374-26-000005:mdna:41]
[same as prior period, unchanged from 0000866374-25-000051:mdna:41]

[0000866374-26-000005:mdna:42]
[same as prior period, unchanged from 0000866374-25-000051:mdna:42]

[0000866374-26-000005:mdna:43]
[same as prior period, unchanged from 0000866374-25-000051:mdna:43]

[0000866374-26-000005:mdna:44]
[same as prior period, unchanged from 0000866374-25-000051:mdna:44]

[0000866374-26-000005:mdna:45]
[same as prior period, unchanged from 0000866374-25-000051:mdna:45]

[0000866374-26-000005:mdna:46]
[same as prior period, unchanged from 0000866374-25-000051:mdna:55]

[0000866374-26-000005:mdna:47]
[same as prior period, unchanged from 0000866374-25-000051:mdna:47]

[0000866374-26-000005:mdna:48]
[same as prior period, unchanged from 0000866374-25-000051:mdna:48]

[0000866374-26-000005:mdna:49]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 90.3 |  |  | 90.8 |  |  | 90.7 |  |  | 91.6 |  |
| Restructuring charges | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Gross profit | 9.6 |  |  | 9.1 |  |  | 9.1 |  |  | 8.2 |  |
| Selling, general and administrative expenses | 3.8 |  |  | 3.7 |  |  | 3.7 |  |  | 3.5 |  |
| Restructuring and impairment charges | 0.1 |  |  | — |  |  | 0.3 |  |  | — |  |
| Intangible amortization | 0.2 |  |  | 0.3 |  |  | 0.2 |  |  | 0.2 |  |
| Operating income | 5.5 |  |  | 5.1 |  |  | 4.9 |  |  | 4.5 |  |
| Interest expense | 0.8 |  |  | 0.9 |  |  | 0.8 |  |  | 0.9 |  |
| Interest income | 0.2 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Other charges (income), net | 0.4 |  |  | — |  |  | 0.1 |  |  | — |  |
| Equity in earnings (losses) of unconsolidated affiliates | — |  |  | — |  |  | (0.1) |  |  | — |  |
| Income before income taxes | 4.5 |  |  | 4.4 |  |  | 4.1 |  |  | 3.8 |  |
| Provision for (benefit from) income taxes | 1.1 |  |  | 0.4 |  |  | 1.0 |  |  | 0.6 |  |
| Net income | 3.4 | % |  | 4.0 | % |  | 3.1 | % |  | 3.2 | % |

[0000866374-26-000005:mdna:50]
[same as prior period, unchanged from 0000866374-25-000051:mdna:50]

[0000866374-26-000005:mdna:51]
[same as prior period, unchanged from 0000866374-25-000051:mdna:51]

[0000866374-26-000005:mdna:52]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,818 |  |  | 54 | % |  | $ | 3,599 |  |  | 55 | % |  | $ | 11,275 |  |  | 55 | % |  | $ | 10,570 |  |  | 54 | % |
| Flex Reliability Solutions | 3,240 |  |  | 46 | % |  | 2,957 |  |  | 45 | % |  | 9,162 |  |  | 45 | % |  | 8,845 |  |  | 46 | % |
|  | $ | 7,058 |  |  |  |  | $ | 6,556 |  |  |  |  | $ | 20,437 |  |  |  |  | $ | 19,415 |  |  |  |

[0000866374-26-000005:mdna:53]
Net sales during the three-month period ended December 31, 2025 totaled $7.1 billion, representing an increase of $0.5 billion, or 8% from $6.6 billion during the three-month period ended December 31, 2024. Net sales for our FAS segment increased $0.2 billion, or 6% from the three-month period ended December 31, 2024, primarily driven by a high single-digit percentage increase in our CEC business due to increased demand and a mid single-digit percentage increase in Lifestyle primarily due to net sales contributed by our Orangeburg Manufacturing Facility acquired on February 4, 2025. This was partially offset by a mid single-digit percentage decrease in Consumer Devices due to lower demand. Net sales for our FRS segment increased $0.3 billion, or 10% from the three-month period ended December 31, 2024, which was primarily driven by high-teen percentage growth in our Industrial business with strength in power and high single-digit percentage growth in Health Solutions, partially offset by a low single-digit percentage decrease in our Automotive business due to lower demand. Net sales increased $0.2 billion in the Americas, $0.2 billion in Asia, and $0.1 billion in Europe for a total gain of $0.5 billion.

[0000866374-26-000005:mdna:54]
Net sales during the nine-month period ended December 31, 2025 totaled $20.4 billion, representing an increase of $1.0 billion, or 5% from $19.4 billion during the nine-month period ended December 31, 2024. Net sales for our FAS segment increased $0.7 billion, or 7% from the nine-month period ended December 31, 2024, primarily driven by a mid-teen percentage increase in our CEC business most notably from increased demand in data center cloud, partially offset by a high-teen

[0000866374-26-000005:mdna:55]
33

[0000866374-26-000005:mdna:56]
percentage decrease in our Consumer Devices business due to lower demand. Net sales for our FRS segment increased $0.3 billion, or 4% from the nine-month period ended December 31, 2024, primarily driven by a high single-digit percentage increase in our Industrial business, primarily in power due to data center growth and business acquisitions, and a low single-digit percentage increase in our Health Solutions business, offset by a low single-digit percentage decrease in our Automotive business due to lower demand. Net sales increased $0.8 billion in the Americas and $0.2 billion in Asia and remained consistent in Europe for a total gain of $1.0 billion.

[0000866374-26-000005:mdna:57]
Our ten largest customers during both the three and nine-month periods ended December 31, 2025 accounted for approximately 46% of net sales. No customer accounted for more than 10% of net sales during the nine-month periods ended December 31, 2025 or December 31, 2024.

[0000866374-26-000005:mdna:58]
[same as prior period, unchanged from 0000866374-25-000051:mdna:58]

[0000866374-26-000005:mdna:59]
[same as prior period, unchanged from 0000866374-25-000051:mdna:59]

[0000866374-26-000005:mdna:60]
Cost of sales during the three-month period ended December 31, 2025 totaled $6.4 billion, representing an increase of $0.4 billion, or 7% from $6.0 billion during the three-month period ended December 31, 2024. The higher cost of sales for the three-month period ended December 31, 2025 was primarily driven by a $0.5 billion, or 8%, increase in consolidated sales, partially offset by cost efficiencies and favorable mix. Cost of sales in our FAS segment for the three-month period ended December 31, 2025 increased by 6% from the three-month period ended December 31, 2024, in line with revenue growth. Cost of sales in our FRS segment for the three-month period ended December 31, 2025 increased by 9% from the three-month period ended December 31, 2024, primarily driven by revenue growth of 10%, partially offset by favorable mix and cost efficiencies.

[0000866374-26-000005:mdna:61]
Cost of sales during the nine-month period ended December 31, 2025 totaled $18.5 billion, representing an increase of $0.8 billion, or 4% from $17.8 billion during the nine-month period ended December 31, 2024. The higher cost of sales for the nine-month period ended December 31, 2025 was primarily driven by a $1.0 billion, or 5% increase in consolidated sales, partially offset by favorable mix and cost efficiencies. Cost of sales in our FAS segment for the nine-month period ended December 31, 2025 increased $0.6 billion, or 6%, from the nine-month period ended December 31, 2024 due to revenue growth of 7%. Cost of sales in our FRS segment for the nine-month period ended December 31, 2025 increased $0.2 billion, or 2%, from the nine-month period ended December 31, 2024 due to revenue growth of 4%, partially offset by favorable mix and cost efficiencies.

[0000866374-26-000005:mdna:62]
[same as prior period, unchanged from 0000866374-25-000051:mdna:62]

[0000866374-26-000005:mdna:63]
[same as prior period, unchanged from 0000866374-25-000051:mdna:63]

[0000866374-26-000005:mdna:64]
Gross profit during the three-month period ended December 31, 2025 increased $0.1 billion to $0.7 billion, or 9.6% of net sales, from $0.6 billion, or 9.1% of net sales, during the three-month period ended December 31, 2024. Gross margin improved 50 basis points year over year primarily due to revenue growth, favorable mix and continued operational execution.

[0000866374-26-000005:mdna:65]
Gross profit during the nine-month period ended December 31, 2025 increased $0.3 billion to $1.9 billion, or 9.1% of net sales, from $1.6 billion, or 8.2% of net sales, during the nine-month period ended December 31, 2024. Gross margin improved 90 basis points year over year primarily due to the same factors as for the three-month periods described above.

[0000866374-26-000005:mdna:66]
[same as prior period, unchanged from 0000866374-25-000051:mdna:66]

[0000866374-26-000005:mdna:67]
[same as prior period, unchanged from 0000866374-25-000051:mdna:67]

[0000866374-26-000005:mdna:68]
[same as prior period, unchanged from 0000866374-25-000051:mdna:68]

[0000866374-26-000005:mdna:69]
[same as prior period, unchanged from 0000866374-25-000051:mdna:69]

[0000866374-26-000005:mdna:70]
[same as prior period, unchanged from 0000866374-25-000051:mdna:70]

[0000866374-26-000005:mdna:71]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 239 |  |  | 6.3 | % |  | $ | 227 |  |  | 6.3 | % |  | $ | 706 |  |  | 6.3 | % |  | $ | 624 |  |  | 5.9 | % |
| Flex Reliability Solutions | 233 |  |  | 7.2 | % |  | 198 |  |  | 6.7 | % |  | 602 |  |  | 6.6 | % |  | 504 |  |  | 5.7 | % |

[0000866374-26-000005:mdna:72]
FAS segment margin remained consistent for the three-month period ended December 31, 2025, compared to the three-month period ended December 31, 2024, primarily driven by growth in our higher margin CEC business, offset by unfavorable mix in our consumer businesses. The FAS segment margin increased 40 basis points, to 6.3% for the nine-month period ended December 31, 2025 from 5.9% for the nine-month period ended December 31, 2024, primarily due to favorable mix with growth being driven by our cloud business.

[0000866374-26-000005:mdna:73]
FRS segment margin increased 50 basis points to 7.2% for the three-month period ended December 31, 2025, compared to 6.7% for the three-month period ended December 31, 2024, primarily due to favorable mix with growth in core Industrial, Health Solutions and our power business. FRS segment margin increased 90 basis points to 6.6% for the nine-month period ended December 31, 2025 compared to 5.7% for the nine-month period ended December 31, 2024, primarily due to the same factors as for the three-month period.

[0000866374-26-000005:mdna:74]
[same as prior period, unchanged from 0000866374-25-000051:mdna:74]

[0000866374-26-000005:mdna:75]
We undertook targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. During the three and nine-month periods ended December 31, 2025, we recognized $6 million and $39 million of restructuring charges, respectively, primarily related to employee severance. In addition, during the three and nine-month periods ended December 31, 2025, we incurred $5 million and $46 million in impairment and other charges related to a missile strike on our Mukachevo, Ukraine facility, as discussed in the Overview section above.

[0000866374-26-000005:mdna:76]
[same as prior period, unchanged from 0000866374-25-000051:mdna:76]

[0000866374-26-000005:mdna:77]
Selling, general and administrative expenses (“SG&A”) was $0.3 billion, or 3.8% of net sales, during the three-month period ended December 31, 2025, increasing by $29 million compared to the three-month period ended December 31, 2024. The increase was largely driven by increases in employee compensation and other corporate costs. SG&A was $0.8 billion or 3.7%, of net sales, during the nine-month period ended December 31, 2025, increasing by $93 million from $0.7 billion or 3.5% of net sales during the nine-month period ended December 31, 2024, driven by the same factors as noted for the three-month period.

[0000866374-26-000005:mdna:78]
[same as prior period, unchanged from 0000866374-25-000051:mdna:78]

[0000866374-26-000005:mdna:79]
Amortization of intangible assets decreased to $15 million for the three-month period ended December 31, 2025, compared to $17 million in the previous year as certain intangible assets fully amortized during fiscal year 2026. Amortization increased to $52 million during the nine-month period ended December 31, 2025, from $49 million for the nine-month period ended December 31, 2024 as a result of acquisitions in the second half of fiscal year 2025.

[0000866374-26-000005:mdna:80]
[same as prior period, unchanged from 0000866374-25-000051:mdna:80]

[0000866374-26-000005:mdna:81]
Interest expense increased to $58 million for the three-month period ended December 31, 2025, from $57 million during the three-month period ended December 31, 2024, primarily due to senior debt issuances during the quarter. Interest expense decreased to $161 million during the nine-month period ended December 31, 2025 compared to $166 million during the nine-month period ended December 31, 2024. Decreased interest expense for the nine-month period was primarily driven by reduced receivables factoring costs, partially offset by increased interest expense on our long-term debt.

[0000866374-26-000005:mdna:82]
[same as prior period, unchanged from 0000866374-25-000051:mdna:82]

[0000866374-26-000005:mdna:83]
Interest income decreased to $15 million for the three-month period ended December 31, 2025 compared to $16 million for the same period in fiscal year 2025. Interest income decreased to $38 million for the nine-month period ended December 31,

[0000866374-26-000005:mdna:84]
[same as prior period, unchanged from 0000866374-25-000051:mdna:97]

[0000866374-26-000005:mdna:85]
2025 compared to $48 million for the nine-month period ended December 31, 2024. The decrease in interest income is primarily due to lower interest rates, and lower average cash balances.

[0000866374-26-000005:mdna:86]
[same as prior period, unchanged from 0000866374-25-000051:mdna:84]

[0000866374-26-000005:mdna:87]
Other charges, net was $25 million during the three-month period ended December 31, 2025 compared to $5 million during the three-month period ended December 31, 2024. The increase was primarily due to an impairment recorded on one of Flex's unconsolidated cost method investments of $21 million during the quarter.

[0000866374-26-000005:mdna:88]
Other charges, net was $19 million for the nine-month periods ended December 31, 2025 compared to $1 million in income during the nine-month periods ended December 31, 2024. The increase was due to the aforementioned impairment on one of Flex's unconsolidated cost method investments.

[0000866374-26-000005:mdna:89]
[same as prior period, unchanged from 0000866374-25-000051:mdna:87]

[0000866374-26-000005:mdna:90]
Equity in losses of unconsolidated affiliates was $1 million during the three-month period ended December 31, 2025, compared to zero in the three-month period ended December 31, 2024, primarily due to losses in certain non-core equity method investments.

[0000866374-26-000005:mdna:91]
Equity in losses of unconsolidated affiliates was $26 million during the nine-month periods ended December 31, 2025, compared to $3 million in the nine-month period ended December 31, 2024, primarily due to losses related to a specific venture capital fund.

[0000866374-26-000005:mdna:92]
[same as prior period, unchanged from 0000866374-25-000051:mdna:90]

[0000866374-26-000005:mdna:93]
[same as prior period, unchanged from 0000866374-25-000051:mdna:91]

[0000866374-26-000005:mdna:94]
The consolidated effective tax rate was 25% and 24% for the three and nine-month periods ended December 31, 2025, and 9% and 17% for the three and nine-month periods ended December 31, 2024, respectively. The effective tax rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effects of certain tax holidays and incentives granted to our subsidiaries primarily in China, Costa Rica, Malaysia, the Netherlands and Israel. The effective tax rate for the three-month period ended December 31, 2025 was higher than the effective tax rate for the three-month period ended December 31, 2024 for a variety of reasons, primarily due to the changing jurisdictions of income and recognition of a $19 million income tax expense related to an audit settlement with a foreign tax authority during the three-month period ended December 31, 2025 and recognition of a $26 million interest receivable on an income tax receivable for prior period taxes paid by one of its Brazilian subsidiaries during the three-month period ended December 31, 2024.

[0000866374-26-000005:mdna:95]
The OECD Pillar Two Global Anti-Base Erosion (“GloBE”) model rules, issued under the OECD Inclusive Framework on Base Erosion and Profit Shifting, introduce a global minimum tax of 15% applicable to multinational enterprise groups with consolidated financial statement revenue in excess of €750 million. Numerous foreign jurisdictions have already enacted tax legislation based on the GloBE rules, with some effective as early as January 1, 2024. As of December 31, 2025 the Company has reflected all estimated impacts of the Pillar Two GloBE minimum tax accordingly within its estimated annual effective tax rate for the year.

[0000866374-26-000005:mdna:96]
On July 4, 2025, The One Big Beautiful Bill Act (“OBBBA”) was enacted in the U.S. The OBBBA makes permanent various provisions of the Tax Cuts and Jobs Act which otherwise would have expired as well as makes significant modifications to the U.S. international tax framework. The Company is in the process of evaluating the impact of the OBBBA on our consolidated financial statements.

[0000866374-26-000005:mdna:97]
[same as prior period, unchanged from 0000866374-25-000051:mdna:95]

[0000866374-26-000005:mdna:98]
Net income was $239 million during the three-month period ended December 31, 2025, compared to $263 million during the three-month period ended December 31, 2024 and net income was $630 million during the nine-month period ended December 31, 2025 compared to $616 million during the nine-month period ended December 31, 2024, driven by the factors discussed above.

[0000866374-26-000005:mdna:99]
[same as prior period, unchanged from 0000866374-25-000051:mdna:98]

[0000866374-26-000005:mdna:100]
We continuously evaluate our ability to meet our obligations over the next 12 months and beyond and proactively reset our capital structure to improve maturities and liquidity. We expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of December 31, 2025, we had cash and cash equivalents of approximately $3.1 billion, bank and other borrowings of approximately $4.4 billion and a $2.75 billion revolving credit facility under which we had no borrowings outstanding. We also issued $600 million of 5.375% Notes due November 2035 and $150 million of 5.250% Notes due January 2032 in the third quarter of fiscal year 2026. As of December 31, 2025, we were in compliance with the covenants under all of our credit facilities and indentures; we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-26-000005:mdna:101]
Cash provided by operating activities was $1.3 billion during the nine-month period ended December 31, 2025, primarily driven by $0.6 billion of net income for the period plus $0.4 billion of non-cash charges such as depreciation, amortization, and impairment charges and $0.2 billion of changes in working capital and other.

[0000866374-26-000005:mdna:102]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital increased $1.3 billion to $4.3 billion as of December 31, 2025, from $3.0 billion as of March 31, 2025. The increase was primarily the result of a $0.5 billion decrease in the current portion of long-term debt driven by the repayment of the 4.750% Senior Notes during the first quarter, along with a $0.8 billion increase in cash and cash equivalents driven by the net increase from senior note issuances and repayments. Other movements in working capital largely offset themselves with increases of $0.2 billion in accounts receivable, $0.3 billion in contract assets, $0.5 billion in inventory, and $0.6 billion in other current assets (principally customer-controlled inventory), against increases of $1.3 billion in accounts payable and $0.2 billion in other current liabilities.

[0000866374-26-000005:mdna:103]
Net cash used in investing activities was $0.5 billion during the nine-month period ended December 31, 2025. This was primarily driven by $0.4 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our business growth as well as payment for a business acquisition during the period.

[0000866374-26-000005:mdna:104]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investors. Our free cash flow for the nine-month periods ended December 31, 2025 and December 31, 2024 was an inflow of $0.8 billion during both periods. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-26-000005:mdna:105]
|  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,272 |  |  | $ | 1,072 |  |
| Purchases of property and equipment | (431) |  |  | (326) |  |
| Proceeds from the disposition of property and equipment | 7 |  |  | 11 |  |
| Free cash flow | $ | 848 |  |  | $ | 757 |  |

[0000866374-26-000005:mdna:106]
Cash used by financing activities was $46 million during the nine-month period ended December 31, 2025, which was primarily driven by $0.7 billion of cash paid for the repurchase of our ordinary shares and debt repayments of $0.5 billion, offset by $1.3 billion of proceeds from debt issuances. Refer to Note 6 and Note 14 to the condensed, consolidated financial statements in Item 1, "Financial Statements" for additional details.

[0000866374-26-000005:mdna:107]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve-month period and beyond. As of December 31, 2025 and March 31, 2025, approximately 52% and 81%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities

[0000866374-26-000005:mdna:108]
on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $0.8 billion as of March 31, 2025). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-26-000005:mdna:109]
[same as prior period, unchanged from 0000866374-25-000051:mdna:108]

[0000866374-26-000005:mdna:110]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of December 31, 2025.

[0000866374-26-000005:mdna:111]
[same as prior period, unchanged from 0000866374-25-000051:mdna:110]

[0000866374-26-000005:mdna:112]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-26-000005:mdna:113]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1.7 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 6, 2025. During the nine-month period ended December 31, 2025, we paid $0.7 billion to repurchase shares under the current and previous repurchase plans at an average price of $46.22 per share. As of December 31, 2025, shares in the aggregate amount of $1.3 billion were available to be repurchased under the current plan.

[0000866374-26-000005:mdna:114]
[same as prior period, unchanged from 0000866374-25-000051:mdna:113]

[0000866374-26-000005:mdna:115]
On August 15, 2025, the Company issued a warrant (the “Warrant”) to Amazon.com NV Investment Holdings LLC (“Warrantholder”), a wholly-owned subsidiary of Amazon.com, Inc. (“Parent”) to purchase up to an aggregate of 3,859,851 ordinary shares of the Company (“Warrant Shares”) at an exercise price of $51.29 per share. The Warrant allows for cashless exercise and expires on August 15, 2030. The Warrant Shares are subject to vesting based on qualifying payments (as defined in the Warrant) for the purchase of all products and services by or on behalf of Parent and its affiliates over the term of the Warrant. The expense associated with the Warrant Shares will be recorded as a deduction to revenue as the customer purchases products and services over the vesting period. The Company recorded charges of $5 million related to the Warrant during the nine-month period ended December 31, 2025.

[0000866374-26-000005:mdna:116]
[same as prior period, unchanged from 0000866374-25-000051:mdna:115]

[0000866374-26-000005:mdna:117]
[same as prior period, unchanged from 0000866374-25-000051:mdna:116]

[0000866374-26-000005:mdna:118]
In June 2025, the Company drew down the 2027 Delayed Draw Term Loan and repaid the 4.750% Senior Notes due June 2025. We issued $600 million of 5.375% Notes due November 2035 and $150 million of 5.250% Notes due January 2032 in the third quarter of fiscal year 2026. There were no other material changes in our contractual obligations and commitments as of December 31, 2025.
