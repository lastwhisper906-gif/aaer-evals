# FLEX note change history — 0000866374-25-000051 → 0000866374-26-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0000866374-26-000005:note_history:1]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagreed with the Tax Authority’s assessments and was actively contesting the assessments through the administrative and judicial processes. During the three-month period ended December 31, 2025, the Company and the Tax Authority agreed to a $50 million settlement covering all open fiscal years and all assessed amounts. The Company had previously expensed $31 million and paid $30 million to the Tax Authority in prior fiscal years and agreed to make an
  (was, 2025-10-31, similarity 0.7491):
[0000866374-25-000051:note_history:1]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.

- added (2026-02-06):
[0000866374-26-000005:note_history:2]
additional $20 million cash payment to the Tax Authority subsequent to the execution of a definitive settlement agreement, which resulted in a charge to income tax expense of $19 million in the third quarter ended December 31, 2025. The definitive settlement agreement was executed on February 3, 2026 and the $20 million cash payment is expected to occur in the fourth quarter of fiscal year ending March 31, 2026.

- removed (2026-02-06):
[0000866374-25-000051:note_history:3]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material effect on the Company’s financial position, results of operations or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0000866374-26-000005:note_history:4]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, and power. As of December 31, 2025, Flex's two operating and reportable segments were as follows:
  (was, 2025-10-31, similarity 0.9961):
[0000866374-25-000051:note_history:4]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, and power. As of September 26, 2025, Flex's two operating and reportable segments were as follows:

- changed (2026-02-06):
[0000866374-26-000005:note_history:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2025 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026.
  (was, 2025-10-31, similarity 0.9928):
[0000866374-25-000051:note_history:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2025 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 26, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026.

- added (2026-02-06):
[0000866374-26-000005:note_history:6]
The third quarters for fiscal years 2026 and 2025 ended on December 31 of each year and are comprised of 96 and 95 days, respectively. The first three quarters for fiscal years 2026 and 2025 are comprised of 275 days in both periods.

- changed (2026-02-06):
[0000866374-26-000005:note_history:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for
  (was, 2025-10-31, similarity 0.8538):
[0000866374-25-000051:note_history:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are

- changed (2026-02-06):
[0000866374-26-000005:note_history:8]
deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; valuation of warrants, and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas conflict, and other geopolitical conflicts) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2025-10-31, similarity 0.9615):
[0000866374-25-000051:note_history:8]
used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; valuation of warrants, and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas conflict, and other geopolitical conflicts) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- added (2026-02-06):
[0000866374-26-000005:note_history:9]
During the three and nine-month periods ended December 31, 2025, the Company recognized $5 million and $46 million, respectively, in asset impairments, inventory write-downs and other charges as a result of a missile strike on its Mukachevo, Ukraine facility in Western Ukraine on August 21, 2025. The total $46 million expense includes $23 million of long-lived asset impairments, $13 million of inventory write-downs and $10 million of other charges. The missile strike represents an unusual and infrequent event as hostilities related to the Russian invasion of Ukraine have been primarily focused in Eastern Ukraine. The missile strike caused substantial physical damage and disrupted normal operations at the facility. In response, the Company activated contingency manufacturing plans and transitioned production to alternative facilities. As restoration activities progress in Mukachevo, the Company expects to incur additional immaterial near-term inefficiencies. The total $46 million expense is included in restructuring and impairment charges in the condensed consolidated statements of operations.

- changed (2026-02-06):
[0000866374-26-000005:note_history:10]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and income taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.
  (was, 2025-10-31, similarity 0.9991):
[0000866374-25-000051:note_history:10]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and income taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

- added (2026-02-06):
[0000866374-26-000005:note_history:11]
In December 2025, the FASB issued ASU 2025-10 "Government Grants (Topic 832)", which establishes comprehensive guidance on the recognition, measurement, presentation, and disclosure of government grants. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements and intends to adopt the guidance prospectively when it becomes effective in the first quarter of fiscal year 2030.

- added (2026-02-06):
[0000866374-26-000005:note_history:12]
In December 2025, the FASB issued ASU 2025-12 "Codification Improvements", which includes numerous refinements and enhancements, including clarifications on the accounting for the retirement of treasury stock among others. The guidance is effective for the Company beginning in the first quarter of fiscal year 2028. The Company is currently evaluating the guidance to determine the method of adoption and impact on the Company's disclosures.

- removed (2026-02-06):
[0000866374-25-000051:note_history:13]
The first quarters for fiscal years 2026 and 2025 ended on June 27, 2025, which is comprised of 88 days in the period, and June 28, 2024, which is comprised of 89 days, respectively. The second quarters for fiscal years 2026 and 2025 ended on September 26, 2025 and September 27, 2024, respectively, which are comprised of 91 days in both periods.

- removed (2026-02-06):
[0000866374-25-000051:note_history:14]
During the three months ended September 26, 2025, the Company recognized $23 million of long-lived asset impairments, $13 million of inventory write-downs and $5 million of other charges as a result of a missile strike on its Mukachevo, Ukraine facility in Western Ukraine on August 21, 2025. The missile strike represents an unusual and infrequent event as hostilities related to the Russian invasion of Ukraine have been primarily focused in Eastern Ukraine. The missile strike caused substantial physical damage and disrupted normal operations at the facility. In response, the Company activated contingency manufacturing plans and transitioned production to alternative facilities. As restoration activities progress in Mukachevo, the Company expects to incur additional immaterial near-term inefficiencies. The total $41 million expense is included in restructuring and impairment charges in the condensed consolidated statements of operations.

- removed (2026-02-06):
[0000866374-25-000051:note_history:15]
In September 2025, the FASB issued ASU 2025-06 "Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40)", which eliminates prescriptive software development stages, requiring capitalization upon funding authorization and commitment. Additionally, the ASU clarifies the scope for capitalization and supersedes website development guidance. The guidance is effective for the Company beginning in the first quarter of fiscal year 2029. The Company is currently evaluating the guidance to determine the method of adoption and impact on the Company's disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0000866374-26-000005:note_history:16]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2025 and March 31, 2025 are as follows:
  (was, 2025-10-31, similarity 0.9789):
[0000866374-25-000051:note_history:16]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 26, 2025 and March 31, 2025 are as follows:

- changed (2026-02-06):
[0000866374-26-000005:note_history:17]
|  | Maturity Date |  | As of December 31, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | — |  |  | $ | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 675 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 654 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 672 |  |  | 676 |  |
| 5.250% Notes (1) (2) | January 2032 |  | 651 |  |  | 499 |  |
| 5.375% Notes (1) (2) | November 2035 |  | 598 |  |  | — |  |
| Delayed Draw Term Loan (3) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (4) | December 2031 |  | 305 |  |  | 269 |  |
| Debt issuance costs |  |  | (18) |  |  | (14) |  |
|  |  |  | 4,435 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (675) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,760 |  |  | $ | 2,483 |  |
  (was, 2025-10-31, similarity 0.6392):
[0000866374-25-000051:note_history:17]
|  | Maturity Date |  | As of September 26, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | — |  |  | $ | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 676 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 673 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 300 |  |  | 269 |  |
| Debt issuance costs |  |  | (12) |  |  | (14) |  |
|  |  |  | 3,689 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (676) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,013 |  |  | $ | 2,483 |  |

- added (2026-02-06):
[0000866374-26-000005:note_history:18]
(2)In November 2025, the Company issued $600 million of 5.375% Notes due November 2035 and $150 million of 5.250% Notes due January 2032.

- changed (2026-02-06):
[0000866374-26-000005:note_history:19]
The weighted-average interest rate for the Company's long-term debt was 4.7% and 4.6% as of December 31, 2025 and March 31, 2025, respectively.
  (was, 2025-10-31, similarity 0.952):
[0000866374-25-000051:note_history:19]
The weighted-average interest rate for the Company's long-term debt was 4.6% as of September 26, 2025 and March 31, 2025, respectively.

- changed (2026-02-06):
[0000866374-26-000005:note_history:20]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2025 are as follows:
  (was, 2025-10-31, similarity 0.9767):
[0000866374-25-000051:note_history:20]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 26, 2025 are as follows:

- changed (2026-02-06):
[0000866374-26-000005:note_history:21]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2026. On February 2, 2026, the Company repaid the 3.750% Notes due February 2026.
  (was, 2025-10-31, similarity 0.7171):
[0000866374-25-000051:note_history:21]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2026.

- added (2026-02-06):
[0000866374-26-000005:note_history:22]
Notes due January 2032 and November 2035

- added (2026-02-06):
[0000866374-26-000005:note_history:23]
In November 2025, the Company issued $600 million of 5.375% Notes ("2035 Notes") due November 2035 at 99.732% of face value and as a further issuance of the existing Notes due January 2032, the Company issued under the same terms an additional $150 million of 5.250% Notes ("additional 2032 Notes") due January 2032 at 101.561% of face value. Interest on the 2035 Notes is payable on May 13 and November 13 of each year, beginning on May 13, 2026, until maturity on November 13, 2035. Interest on the additional 2032 Notes is payable on January 15 and July 15 of each year, beginning on January 15, 2026, until maturity on January 15, 2032. Immediately after the issuance of the additional 2032 Notes, the Company had $650 million aggregate principal amount of 5.250% Notes due 2032 outstanding. The Company received proceeds in aggregate of $746 million, net of discount, certain issuance costs, and prepaid interest and inclusive of premium for the issuances in November 2025. The Company incurred and capitalized $7 million of costs in conjunction with the Note issuances in November 2025 as a direct reduction to the carrying amount of the Notes presented on the balance sheet. Proceeds from issuances in November 2025 may be used for general corporate purposes, including repaying, redeeming or repurchasing outstanding debt including repayment or redemption of the 3.750% Notes due February 2026, and for working capital, capital expenditures and acquisitions. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.

- added (2026-02-06):
[0000866374-26-000005:note_history:24]
As of December 31, 2025, the Company was in compliance with all covenants in the indentures governing the Notes.

- changed (2026-02-06):
[0000866374-26-000005:note_history:25]
In March 2025, the Company entered into a $500 million delayed draw term loan agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general purposes. All borrowings on the delayed draw term loan will come due on December 31, 2027. Interest is based on a Term SOFR-based formula plus a margin of 100 basis points. The Company had $500 million in borrowings outstanding under the loan agreement as of December 31, 2025.
  (was, 2025-10-31, similarity 0.9745):
[0000866374-25-000051:note_history:25]
In March 2025, the Company entered into a $500 million delayed draw term loan agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general purposes. All borrowings on the delayed draw term loan will come due on December 31, 2027. Interest is based on a Term SOFR-based formula plus a margin of 100 basis points. The Company had $500 million in borrowings outstanding under the loan agreement as of September 26, 2025.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0000866374-26-000005:note_history:26]
The following table presents the Company’s major debts not carried at fair value as of December 31, 2025 and March 31, 2025:
  (was, 2025-10-31, similarity 0.9782):
[0000866374-25-000051:note_history:26]
The following table presents the Company’s major debts not carried at fair value as of September 26, 2025 and March 31, 2025:

- changed (2026-02-06):
[0000866374-26-000005:note_history:27]
|  | As of December 31, 2025 |  | As of March 31, 2025 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | — |  |  | $ | — |  |  | $ | 531 |  |  | $ | 531 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 675 |  |  | 674 |  |  | 678 |  |  | 672 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 411 |  |  | 398 |  |  | 409 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 654 |  |  | 665 |  |  | 655 |  |  | 651 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 672 |  |  | 683 |  |  | 676 |  |  | 669 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 651 |  |  | 666 |  |  | 499 |  |  | 497 |  |  | Level 1 |
| 5.375% Notes due November 2035 | 598 |  |  | 600 |  |  | — |  |  | — |  |  | Level 1 |
| Delayed Draw Term Loan due December 2027 | 500 |  |  | 500 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 305 |  |  | 244 |  |  | 269 |  |  | 215 |  |  | Level 2 |
  (was, 2025-10-31, similarity 0.8005):
[0000866374-25-000051:note_history:27]
|  | As of September 26, 2025 |  | As of March 31, 2025 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | — |  |  | $ | — |  |  | $ | 531 |  |  | $ | 531 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 676 |  |  | 674 |  |  | 678 |  |  | 672 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 411 |  |  | 398 |  |  | 409 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 655 |  |  | 662 |  |  | 655 |  |  | 651 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 673 |  |  | 679 |  |  | 676 |  |  | 669 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 511 |  |  | 499 |  |  | 497 |  |  | Level 1 |
| Delayed Draw Term Loan due December 2027 | 500 |  |  | 500 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 300 |  |  | 240 |  |  | 269 |  |  | 215 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0000866374-26-000005:note_history:28]
Bank borrowings and long-term debt as of December 31, 2025 and March 31, 2025 are as follows:
  (was, 2025-10-31, similarity 0.9701):
[0000866374-25-000051:note_history:28]
Bank borrowings and long-term debt as of September 26, 2025 and March 31, 2025 are as follows:

- changed (2026-02-06):
[0000866374-26-000005:note_history:29]
|  | Maturity Date |  | As of December 31, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | — |  |  | $ | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 675 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 654 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 672 |  |  | 676 |  |
| 5.250% Notes (1) (2) | January 2032 |  | 651 |  |  | 499 |  |
| 5.375% Notes (1) (2) | November 2035 |  | 598 |  |  | — |  |
| Delayed Draw Term Loan (3) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (4) | December 2031 |  | 305 |  |  | 269 |  |
| Debt issuance costs |  |  | (18) |  |  | (14) |  |
|  |  |  | 4,435 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (675) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,760 |  |  | $ | 2,483 |  |
  (was, 2025-10-31, similarity 0.6392):
[0000866374-25-000051:note_history:29]
|  | Maturity Date |  | As of September 26, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | — |  |  | $ | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 676 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 655 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 673 |  |  | 676 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | 499 |  |
| Delayed Draw Term Loan (2) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 300 |  |  | 269 |  |
| Debt issuance costs |  |  | (12) |  |  | (14) |  |
|  |  |  | 3,689 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (676) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,013 |  |  | $ | 2,483 |  |

- added (2026-02-06):
[0000866374-26-000005:note_history:30]
(2)In November 2025, the Company issued $600 million of 5.375% Notes due November 2035 and $150 million of 5.250% Notes due January 2032.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0000866374-26-000005:note_history:31]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2025 are as follows:
  (was, 2025-10-31, similarity 0.9767):
[0000866374-25-000051:note_history:31]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 26, 2025 are as follows:

- changed (2026-02-06):
[0000866374-26-000005:note_history:32]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2026. On February 2, 2026, the Company repaid the 3.750% Notes due February 2026.
  (was, 2025-10-31, similarity 0.7171):
[0000866374-25-000051:note_history:32]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2026.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0000866374-26-000005:note_history:33]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,702 |  |  | $ | 2,849 |  |  | $ | 8,471 |  |  | $ | 8,646 |  |
| Over time | 1,116 |  |  | 750 |  |  | 2,804 |  |  | 1,924 |  |
| Total | 3,818 |  |  | 3,599 |  |  | 11,275 |  |  | 10,570 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,027 |  |  | 1,960 |  |  | 5,856 |  |  | 6,830 |  |
| Over time | 1,213 |  |  | 997 |  |  | 3,306 |  |  | 2,015 |  |
| Total | 3,240 |  |  | 2,957 |  |  | 9,162 |  |  | 8,845 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,729 |  |  | 4,809 |  |  | 14,327 |  |  | 15,476 |  |
| Over time | 2,329 |  |  | 1,747 |  |  | 6,110 |  |  | 3,939 |  |
| Total | $ | 7,058 |  |  | $ | 6,556 |  |  | $ | 20,437 |  |  | $ | 19,415 |  |
  (was, 2025-10-31, similarity 0.9737):
[0000866374-25-000051:note_history:33]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,874 |  |  | $ | 2,924 |  |  | $ | 5,769 |  |  | $ | 5,797 |  |
| Over time | 892 |  |  | 682 |  |  | 1,688 |  |  | 1,174 |  |
| Total | 3,766 |  |  | 3,606 |  |  | 7,457 |  |  | 6,971 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,970 |  |  | 2,237 |  |  | 3,829 |  |  | 4,870 |  |
| Over time | 1,068 |  |  | 702 |  |  | 2,093 |  |  | 1,018 |  |
| Total | 3,038 |  |  | 2,939 |  |  | 5,922 |  |  | 5,888 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,844 |  |  | 5,161 |  |  | 9,598 |  |  | 10,667 |  |
| Over time | 1,960 |  |  | 1,384 |  |  | 3,781 |  |  | 2,192 |  |
| Total | $ | 6,804 |  |  | $ | 6,545 |  |  | $ | 13,379 |  |  | $ | 12,859 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0000866374-26-000005:note_history:34]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $456 million and $377 million as of December 31, 2025 and March 31, 2025, respectively, of which $418 million and $347 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.
  (was, 2025-10-31, similarity 0.9912):
[0000866374-25-000051:note_history:34]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $429 million and $377 million as of September 26, 2025 and March 31, 2025, respectively, of which $392 million and $347 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2026-02-06):
[0000866374-26-000005:note_history:35]
During the second quarter of fiscal year 2026, the Company issued a warrant (“the Warrant”) to a customer for the purchase of up to an aggregate of 3.9 million ordinary shares of the Company ("Warrant Shares"). The Warrant Shares vest based on qualifying payments (as defined in the Warrant) for the purchase of all products and services over the term of the Warrant and are recognized as a deduction to revenue as qualifying revenues are recognized. Refer to “Note 4 – Share-Based Compensation and Warrants” for further information.
  (was, 2025-10-31, similarity 0.9511):
[0000866374-25-000051:note_history:35]
During the quarter ended September 26, 2025, the Company issued a warrant (“the Warrant”) to a customer for the purchase of up to an aggregate of approximately 3.9 million ordinary shares of the Company ("Warrant Shares"). The Warrant Shares vest based on qualifying payments (as defined in the Warrant) for the purchase of all products and services over the term of the Warrant and are recognized as a deduction to revenue as qualifying revenues are recognized. Refer to “Note 4 – Share-Based Compensation and Warrants” for further information.

- changed (2026-02-06):
[0000866374-26-000005:note_history:36]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,702 |  |  | $ | 2,849 |  |  | $ | 8,471 |  |  | $ | 8,646 |  |
| Over time | 1,116 |  |  | 750 |  |  | 2,804 |  |  | 1,924 |  |
| Total | 3,818 |  |  | 3,599 |  |  | 11,275 |  |  | 10,570 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,027 |  |  | 1,960 |  |  | 5,856 |  |  | 6,830 |  |
| Over time | 1,213 |  |  | 997 |  |  | 3,306 |  |  | 2,015 |  |
| Total | 3,240 |  |  | 2,957 |  |  | 9,162 |  |  | 8,845 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,729 |  |  | 4,809 |  |  | 14,327 |  |  | 15,476 |  |
| Over time | 2,329 |  |  | 1,747 |  |  | 6,110 |  |  | 3,939 |  |
| Total | $ | 7,058 |  |  | $ | 6,556 |  |  | $ | 20,437 |  |  | $ | 19,415 |  |
  (was, 2025-10-31, similarity 0.9737):
[0000866374-25-000051:note_history:36]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 26, 2025 |  | September 27, 2024 |  | September 26, 2025 |  | September 27, 2024 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,874 |  |  | $ | 2,924 |  |  | $ | 5,769 |  |  | $ | 5,797 |  |
| Over time | 892 |  |  | 682 |  |  | 1,688 |  |  | 1,174 |  |
| Total | 3,766 |  |  | 3,606 |  |  | 7,457 |  |  | 6,971 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,970 |  |  | 2,237 |  |  | 3,829 |  |  | 4,870 |  |
| Over time | 1,068 |  |  | 702 |  |  | 2,093 |  |  | 1,018 |  |
| Total | 3,038 |  |  | 2,939 |  |  | 5,922 |  |  | 5,888 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,844 |  |  | 5,161 |  |  | 9,598 |  |  | 10,667 |  |
| Over time | 1,960 |  |  | 1,384 |  |  | 3,781 |  |  | 2,192 |  |
| Total | $ | 6,804 |  |  | $ | 6,545 |  |  | $ | 13,379 |  |  | $ | 12,859 |  |
