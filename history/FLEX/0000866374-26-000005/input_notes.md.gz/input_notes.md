# FLEX notes — 0000866374-26-000005


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-26-000005:notes:1]
[same as prior period, unchanged from 0000866374-25-000051:notes:1]

[0000866374-26-000005:notes:2]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, and power. As of December 31, 2025, Flex's two operating and reportable segments were as follows:

[0000866374-26-000005:notes:3]
[same as prior period, unchanged from 0000866374-25-000051:notes:3]

[0000866374-26-000005:notes:4]
[same as prior period, unchanged from 0000866374-25-000051:notes:4]

[0000866374-26-000005:notes:5]
[same as prior period, unchanged from 0000866374-25-000051:notes:5]

[0000866374-26-000005:notes:6]
[same as prior period, unchanged from 0000866374-25-000051:notes:6]

[0000866374-26-000005:notes:7]
[same as prior period, unchanged from 0000866374-25-000051:notes:7]

[0000866374-26-000005:notes:8]
[same as prior period, unchanged from 0000866374-25-000051:notes:8]

[0000866374-26-000005:notes:9]
[same as prior period, unchanged from 0000866374-25-000051:notes:9]

[0000866374-26-000005:notes:10]
[same as prior period, unchanged from 0000866374-25-000051:notes:10]

[0000866374-26-000005:notes:11]
[same as prior period, unchanged from 0000866374-25-000051:notes:11]

[0000866374-26-000005:notes:12]
[same as prior period, unchanged from 0000866374-25-000051:notes:12]

[0000866374-26-000005:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2025 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026.

[0000866374-26-000005:notes:14]
The third quarters for fiscal years 2026 and 2025 ended on December 31 of each year and are comprised of 96 and 95 days, respectively. The first three quarters for fiscal years 2026 and 2025 are comprised of 275 days in both periods.

[0000866374-26-000005:notes:15]
[same as prior period, unchanged from 0000866374-25-000051:notes:15]

[0000866374-26-000005:notes:16]
[same as prior period, unchanged from 0000866374-25-000051:notes:16]

[0000866374-26-000005:notes:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for

[0000866374-26-000005:notes:18]
deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; valuation of warrants, and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas conflict, and other geopolitical conflicts) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-26-000005:notes:19]
[same as prior period, unchanged from 0000866374-25-000051:notes:19]

[0000866374-26-000005:notes:20]
During the three and nine-month periods ended December 31, 2025, the Company recognized $5 million and $46 million, respectively, in asset impairments, inventory write-downs and other charges as a result of a missile strike on its Mukachevo, Ukraine facility in Western Ukraine on August 21, 2025. The total $46 million expense includes $23 million of long-lived asset impairments, $13 million of inventory write-downs and $10 million of other charges. The missile strike represents an unusual and infrequent event as hostilities related to the Russian invasion of Ukraine have been primarily focused in Eastern Ukraine. The missile strike caused substantial physical damage and disrupted normal operations at the facility. In response, the Company activated contingency manufacturing plans and transitioned production to alternative facilities. As restoration activities progress in Mukachevo, the Company expects to incur additional immaterial near-term inefficiencies. The total $46 million expense is included in restructuring and impairment charges in the condensed consolidated statements of operations.

[0000866374-26-000005:notes:21]
Recently Issued Accounting Pronouncements

[0000866374-26-000005:notes:22]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and income taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

[0000866374-26-000005:notes:23]
In November 2024, the FASB issued ASU 2024-03 "Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses", which requires public entities to disclose specified information about certain costs and expenses. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2028 and will be applied retrospectively to all prior periods presented on its consolidated financial statements. The Company is currently evaluating the guidance to determine the impact on the Company's disclosures. In January 2025, the FASB issued ASU 2025-01 on the same topic to clarify the amendments for ASU 2024-03 are effective for the Company in the fourth quarter of fiscal year 2028.

[0000866374-26-000005:notes:24]
In December 2025, the FASB issued ASU 2025-10 "Government Grants (Topic 832)", which establishes comprehensive guidance on the recognition, measurement, presentation, and disclosure of government grants. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements and intends to adopt the guidance prospectively when it becomes effective in the first quarter of fiscal year 2030.

[0000866374-26-000005:notes:25]
In December 2025, the FASB issued ASU 2025-12 "Codification Improvements", which includes numerous refinements and enhancements, including clarifications on the accounting for the retirement of treasury stock among others. The guidance is effective for the Company beginning in the first quarter of fiscal year 2028. The Company is currently evaluating the guidance to determine the method of adoption and impact on the Company's disclosures.

[0000866374-26-000005:notes:26]
Recently Adopted Accounting Pronouncements

[0000866374-26-000005:notes:27]
In July 2025, the FASB issued ASU 2025-05 "Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets", which provides for the use of a new practical expedient when estimating expected credit losses for accounts receivable and contract assets arising from transactions accounted for under Topic 606 that assumes that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for the Company, and has been adopted, beginning in the second quarter of fiscal year 2026.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-26-000005:notes:28]
[same as prior period, unchanged from 0000866374-25-000051:notes:27]

[0000866374-26-000005:notes:29]
[same as prior period, unchanged from 0000866374-25-000051:notes:28]

[0000866374-26-000005:notes:30]
|  | As of December 31, 2025 |  | As of March 31, 2025 |
|  | (In millions) |
| Raw materials | $ | 4,447 |  |  | $ | 4,092 |  |
| Work-in-progress | 462 |  |  | 485 |  |
| Finished goods | 640 |  |  | 494 |  |
|  | $ | 5,549 |  |  | $ | 5,071 |  |

[0000866374-26-000005:notes:31]
In addition to the Flex controlled inventory shown above, the Company held inventory controlled by customers of $924 million and $416 million as of December 31, 2025 and March 31, 2025, respectively. These amounts are reported in other current assets in the condensed consolidated balance sheets.

[0000866374-26-000005:notes:32]
[same as prior period, unchanged from 0000866374-25-000051:notes:31]

[0000866374-26-000005:notes:33]
During the nine-month period ended December 31, 2025, goodwill increased by $34 million with $8 million from an acquisition completed in the first quarter of fiscal year 2026 and currency impacts of $26 million. See note 12 for further details.

[0000866374-26-000005:notes:34]
[same as prior period, unchanged from 0000866374-25-000051:notes:33]

[0000866374-26-000005:notes:35]
|  | As of December 31, 2025 |  | As of March 31, 2025 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 318 |  |  | $ | (147) |  |  | $ | 171 |  |  | $ | 383 |  |  | $ | (186) |  |  | $ | 197 |  |
| Licenses and other intangibles | 199 |  |  | (70) |  |  | 129 |  |  | 365 |  |  | (219) |  |  | 146 |  |
| Total | $ | 517 |  |  | $ | (217) |  |  | $ | 300 |  |  | $ | 748 |  |  | $ | (405) |  |  | $ | 343 |  |

[0000866374-26-000005:notes:36]
[same as prior period, unchanged from 0000866374-25-000051:notes:35]

[0000866374-26-000005:notes:37]
[same as prior period, unchanged from 0000866374-25-000051:notes:36]

[0000866374-26-000005:notes:38]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2026 (1) |  | $ | 15 |  |
| 2027 |  | 59 |  |
| 2028 |  | 44 |  |
| 2029 |  | 41 |  |
| 2030 |  | 36 |  |
| Thereafter |  | 105 |  |
| Total amortization expense |  | $ | 300 |  |

[0000866374-26-000005:notes:39]
(1)Represents estimated amortization for the remaining three-month period of the fiscal year ending March 31, 2026.

[0000866374-26-000005:notes:40]
[same as prior period, unchanged from 0000866374-25-000051:notes:39]

[0000866374-26-000005:notes:41]
Customer working capital advances were $1.5 billion and $1.6 billion as of December 31, 2025 and March 31, 2025, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-26-000005:notes:42]
[same as prior period, unchanged from 0000866374-25-000051:notes:41]

[0000866374-26-000005:notes:43]
Other non-current assets include deferred tax assets of $580 million and $577 million as of December 31, 2025 and March 31, 2025, respectively.

[0000866374-26-000005:notes:44]
[same as prior period, unchanged from 0000866374-25-000051:notes:43]

[0000866374-26-000005:notes:45]
Other current liabilities include customer-related accruals of $374 million and $246 million as of December 31, 2025 and March 31, 2025, respectively.

[0000866374-26-000005:notes:46]
[same as prior period, unchanged from 0000866374-25-000051:notes:45]

[0000866374-26-000005:notes:47]
[same as prior period, unchanged from 0000866374-25-000051:notes:46]

[0000866374-26-000005:notes:48]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of December 31, 2025 and March 31, 2025 were $129 million and $119 million, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-26-000005:notes:49]
[same as prior period, unchanged from 0000866374-25-000051:notes:48]

[0000866374-26-000005:notes:50]
[same as prior period, unchanged from 0000866374-25-000051:notes:49]

[0000866374-26-000005:notes:51]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $456 million and $377 million as of December 31, 2025 and March 31, 2025, respectively, of which $418 million and $347 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-26-000005:notes:52]
[same as prior period, unchanged from 0000866374-25-000051:notes:51]

[0000866374-26-000005:notes:53]
During the second quarter of fiscal year 2026, the Company issued a warrant (“the Warrant”) to a customer for the purchase of up to an aggregate of 3.9 million ordinary shares of the Company ("Warrant Shares"). The Warrant Shares vest based on qualifying payments (as defined in the Warrant) for the purchase of all products and services over the term of the Warrant and are recognized as a deduction to revenue as qualifying revenues are recognized. Refer to “Note 4 – Share-Based Compensation and Warrants” for further information.

[0000866374-26-000005:notes:54]
[same as prior period, unchanged from 0000866374-25-000051:notes:53]

[0000866374-26-000005:notes:55]
[same as prior period, unchanged from 0000866374-25-000051:notes:54]

[0000866374-26-000005:notes:56]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,702 |  |  | $ | 2,849 |  |  | $ | 8,471 |  |  | $ | 8,646 |  |
| Over time | 1,116 |  |  | 750 |  |  | 2,804 |  |  | 1,924 |  |
| Total | 3,818 |  |  | 3,599 |  |  | 11,275 |  |  | 10,570 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,027 |  |  | 1,960 |  |  | 5,856 |  |  | 6,830 |  |
| Over time | 1,213 |  |  | 997 |  |  | 3,306 |  |  | 2,015 |  |
| Total | 3,240 |  |  | 2,957 |  |  | 9,162 |  |  | 8,845 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,729 |  |  | 4,809 |  |  | 14,327 |  |  | 15,476 |  |
| Over time | 2,329 |  |  | 1,747 |  |  | 6,110 |  |  | 3,939 |  |
| Total | $ | 7,058 |  |  | $ | 6,556 |  |  | $ | 20,437 |  |  | $ | 19,415 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-26-000005:notes:57]
[same as prior period, unchanged from 0000866374-25-000051:notes:56]

[0000866374-26-000005:notes:58]
[same as prior period, unchanged from 0000866374-25-000051:notes:57]

[0000866374-26-000005:notes:59]
[same as prior period, unchanged from 0000866374-25-000051:notes:58]

[0000866374-26-000005:notes:60]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
|  | (In millions) |
| Cost of sales | $ | 9 |  |  | $ | 9 |  |  | $ | 26 |  |  | $ | 25 |  |
| Selling, general and administrative expenses | 28 |  |  | 24 |  |  | 82 |  |  | 68 |  |
| Total share-based compensation expense | $ | 37 |  |  | $ | 33 |  |  | $ | 108 |  |  | $ | 93 |  |

[0000866374-26-000005:notes:61]
[same as prior period, unchanged from 0000866374-25-000051:notes:60]

[0000866374-26-000005:notes:62]
During the nine-month period ended December 31, 2025, the Company granted 4.3 million restricted share unit ("RSU") awards. Of this amount, 2.0 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, with an average grant date price of $43.99 per award. In addition, 1.0 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, with an average grant date price of $45.09 per award. These performance-based RSUs include awards tied to the Company's adjusted earnings per share growth and awards tied to operating profit goals. The number of shares that will ultimately vest will range from zero up to a maximum of approximately 2.4 million based on the level of achievement of these performance conditions. The awards will cliff vest after a period of three years, depending on the specific performance metrics, to the extent such performance conditions have been met. Further, 0.2 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards that are contingent on certain market conditions was estimated to be $58.55 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 0.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met. The remaining balance of 1.1 million represents the number of shares issued upon the vesting of RSU awards above target levels based on the achievement of certain market and performance conditions for awards granted in fiscal year 2023. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-26-000005:notes:63]
As of December 31, 2025, 9.5 million unvested RSU awards under the 2017 Plan were outstanding, of which vesting for a targeted amount of 0.8 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of 1.7 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to approximately 1.6 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to approximately 3.9 million based on the achievement levels. During the nine-month period ended December 31, 2025, 2.3 million shares vested in connection with the awards with market and performance conditions granted in fiscal year 2023.

[0000866374-26-000005:notes:64]
As of December 31, 2025, total unrecognized compensation expense related to unvested RSU awards under the 2017 Plan was $224 million and will be recognized over a weighted-average remaining vesting period of 2.1 years.

[0000866374-26-000005:notes:65]
[same as prior period, unchanged from 0000866374-25-000051:notes:64]

[0000866374-26-000005:notes:66]
[same as prior period, unchanged from 0000866374-25-000051:notes:65]

[0000866374-26-000005:notes:67]
[same as prior period, unchanged from 0000866374-25-000051:notes:66]

[0000866374-26-000005:notes:68]
The calculated fair value of each Warrant Share at the issuance date was $25.47. The Company recorded charges of $3 million and $5 million during the three and nine-month periods ended December 31, 2025, respectively. No Warrant Shares have vested, or were exercised, as of December 31, 2025.


## us-gaap:EarningsPerShareTextBlock

[0000866374-26-000005:notes:69]
[same as prior period, unchanged from 0000866374-25-000051:notes:68]

[0000866374-26-000005:notes:70]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
|  | (In millions, except per share amounts) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 239 |  |  | $ | 263 |  |  | $ | 630 |  |  | $ | 616 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding - basic | 369 |  |  | 387 |  |  | 372 |  |  | 394 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 7 |  |  | 7 |  |  | 7 |  |  | 7 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding - diluted | 376 |  |  | 394 |  |  | 379 |  |  | 401 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.65 |  |  | $ | 0.68 |  |  | $ | 1.69 |  |  | $ | 1.56 |  |
| Diluted | $ | 0.64 |  |  | $ | 0.67 |  |  | $ | 1.66 |  |  | $ | 1.54 |  |

[0000866374-26-000005:notes:71]
(1)An immaterial amount of RSU awards for both the three and nine-month periods ended December 31, 2025 and December 31, 2024, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-26-000005:notes:72]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2025 and March 31, 2025 are as follows:

[0000866374-26-000005:notes:73]
|  | Maturity Date |  | As of December 31, 2025 |  | As of March 31, 2025 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | — |  |  | $ | 531 |  |
| 3.750% Notes (1) | February 2026 |  | 675 |  |  | 678 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 398 |  |
| 4.875% Notes (1) | June 2029 |  | 654 |  |  | 655 |  |
| 4.875% Notes (1) | May 2030 |  | 672 |  |  | 676 |  |
| 5.250% Notes (1) (2) | January 2032 |  | 651 |  |  | 499 |  |
| 5.375% Notes (1) (2) | November 2035 |  | 598 |  |  | — |  |
| Delayed Draw Term Loan (3) | December 2027 |  | 500 |  |  | — |  |
| 3.600% HUF Bonds (4) | December 2031 |  | 305 |  |  | 269 |  |
| Debt issuance costs |  |  | (18) |  |  | (14) |  |
|  |  |  | 4,435 |  |  | 3,692 |  |
| Current portion, net of debt issuance costs |  |  | (675) |  |  | (1,209) |  |
| Non-current portion |  |  | $ | 3,760 |  |  | $ | 2,483 |  |

[0000866374-26-000005:notes:74]
(1)The notes are carried at the principal amount of each note less any unamortized discount and unamortized debt issuance costs and inclusive of any unamortized premium. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

[0000866374-26-000005:notes:75]
(2)In November 2025, the Company issued $600 million of 5.375% Notes due November 2035 and $150 million of 5.250% Notes due January 2032.

[0000866374-26-000005:notes:76]
(3)In March 2025, the Company entered into a $500 million Delayed Draw Term Loan agreement and drew down the funds in June 2025 at the Secured Overnight Financing Rate ("SOFR") plus 100 basis points.

[0000866374-26-000005:notes:77]
(4)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

[0000866374-26-000005:notes:78]
The weighted-average interest rate for the Company's long-term debt was 4.7% and 4.6% as of December 31, 2025 and March 31, 2025, respectively.

[0000866374-26-000005:notes:79]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2025 are as follows:

[0000866374-26-000005:notes:80]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2026 (1) |  | $ | 675 |  |
| 2027 |  | — |  |
| 2028 |  | 898 |  |
| 2029 |  | 30 |  |
| 2030 |  | 685 |  |
| Thereafter |  | 2,165 |  |
| Total |  | $ | 4,453 |  |

[0000866374-26-000005:notes:81]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2026. On February 2, 2026, the Company repaid the 3.750% Notes due February 2026.

[0000866374-26-000005:notes:82]
Notes due January 2032 and November 2035

[0000866374-26-000005:notes:83]
In November 2025, the Company issued $600 million of 5.375% Notes ("2035 Notes") due November 2035 at 99.732% of face value and as a further issuance of the existing Notes due January 2032, the Company issued under the same terms an additional $150 million of 5.250% Notes ("additional 2032 Notes") due January 2032 at 101.561% of face value. Interest on the 2035 Notes is payable on May 13 and November 13 of each year, beginning on May 13, 2026, until maturity on November 13, 2035. Interest on the additional 2032 Notes is payable on January 15 and July 15 of each year, beginning on January 15, 2026, until maturity on January 15, 2032. Immediately after the issuance of the additional 2032 Notes, the Company had $650 million aggregate principal amount of 5.250% Notes due 2032 outstanding. The Company received proceeds in aggregate of $746 million, net of discount, certain issuance costs, and prepaid interest and inclusive of premium for the issuances in November 2025. The Company incurred and capitalized $7 million of costs in conjunction with the Note issuances in November 2025 as a direct reduction to the carrying amount of the Notes presented on the balance sheet. Proceeds from issuances in November 2025 may be used for general corporate purposes, including repaying, redeeming or repurchasing outstanding debt including repayment or redemption of the 3.750% Notes due February 2026, and for working capital, capital expenditures and acquisitions. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.

[0000866374-26-000005:notes:84]
As of December 31, 2025, the Company was in compliance with all covenants in the indentures governing the Notes.

[0000866374-26-000005:notes:85]
The 2030 Credit Facility

[0000866374-26-000005:notes:86]
In July 2025, the Company entered into a new $2.75 billion credit facility (“2030 Credit Facility”) which matures in July 2030 and consists of a $2.75 billion revolving credit facility with a sub-limit of $400 million available for swing line loans and a sub-limit of $200 million available for the issuance of letters of credit. The 2030 Credit Facility replaced the previous $2.5 billion credit facility, which was due to mature in July 2027. Borrowings under the 2030 Credit Facility bear interest at the Company’s option at various market based rates, adjusted for the Company’s credit rating, or at the SOFR or similar non-reporting currency benchmarks based on the underlying borrowing currency, adjusted for the Company’s credit rating. The Company is required to pay a quarterly commitment fee on the unutilized portion of the 2030 Credit Facility ranging from 0.100% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.00% to 1.750% per annum, based on the Company’s credit ratings, on the daily average amount of outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

[0000866374-26-000005:notes:87]
Term Loan due December 2027

[0000866374-26-000005:notes:88]
In March 2025, the Company entered into a $500 million delayed draw term loan agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general purposes. All borrowings on the delayed draw term loan will come due on December 31, 2027. Interest is based on a Term SOFR-based formula plus a margin of 100 basis points. The Company had $500 million in borrowings outstanding under the loan agreement as of December 31, 2025.


## flex:InterestAndOtherNetTextBlock

[0000866374-26-000005:notes:89]
INTEREST EXPENSE AND INTEREST INCOME
Interest expense and interest income for the three and nine-month periods ended December 31, 2025 and 2024 are composed of the following:

[0000866374-26-000005:notes:90]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 54 |  |  | $ | 50 |  |  | $ | 146 |  |  | $ | 139 |  |
| AR sale program related expenses | 4 |  |  | 7 |  |  | 15 |  |  | 27 |  |
| Interest income | (15) |  |  | (16) |  |  | (38) |  |  | (48) |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-26-000005:notes:91]
[same as prior period, unchanged from 0000866374-25-000051:notes:86]

[0000866374-26-000005:notes:92]
[same as prior period, unchanged from 0000866374-25-000051:notes:87]

[0000866374-26-000005:notes:93]
As of December 31, 2025, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $7.6 billion as summarized below:

[0000866374-26-000005:notes:94]
|  |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  | p |
| MXN |  | $ | 548 |  |  | $ | — |  |
| HUF |  | 449 |  |  | — |  |
| CNY |  | 280 |  |  | — |  |
| Other |  | 507 |  |  | 12 |  |
|  |  | 1,784 |  |  | 12 |  |
| Other Foreign Currency Contracts |  |  |  |  |
| CNY |  | 713 |  |  | 298 |  |
| EUR |  | 658 |  |  | 500 |  |
| MXN |  | 470 |  |  | 363 |  |
| MYR |  | 276 |  |  | 130 |  |
| JPY |  | 15 |  |  | 286 |  |
| BRL |  | — |  |  | 283 |  |
| Other |  | 1,000 |  |  | 775 |  |
|  |  | 3,132 |  |  | 2,635 |  |
| Total Notional Contract Value in USD |  | $ | 4,916 |  |  | $ | 2,647 |  |

[0000866374-26-000005:notes:95]
As of December 31, 2025, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the condensed consolidated statements of operations. The Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were $34 million as of December 31, 2025 and are expected to be recognized primarily as a component of cost of sales in the condensed

[0000866374-26-000005:notes:96]
consolidated statements of operations over the next twelve-month period, except for gains attributable to changes in fair value of the USD HUF cross currency swaps, which are discussed below.

[0000866374-26-000005:notes:97]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other current assets and other non-current liabilities as of December 31, 2025 and March 31, 2025, respectively. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-26-000005:notes:98]
The following table presents the fair value of the Company’s derivative instruments utilized for foreign currency risk management purposes at December 31, 2025 and March 31, 2025:

[0000866374-26-000005:notes:99]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31,2025 |  | March 31,2025 |  | Balance SheetLocation |  | December 31,2025 |  | March 31,2025 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 61 |  |  | $ | 13 |  |  | Other current liabilities |  | $ | (4) |  |  | $ | (18) |  |
| Foreign currency contracts | Other non-current assets |  | — |  |  | — |  |  | Other non-current liabilities |  | (15) |  |  | (46) |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 21 |  |  | $ | 21 |  |  | Other current liabilities |  | $ | (10) |  |  | $ | (15) |  |

[0000866374-26-000005:notes:100]
[same as prior period, unchanged from 0000866374-25-000051:notes:94]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-26-000005:notes:101]
[same as prior period, unchanged from 0000866374-25-000051:notes:95]

[0000866374-26-000005:notes:102]
|  | Three-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | 20 |  |  | $ | (131) |  |  | $ | (111) |  |  | $ | (13) |  |  | $ | (160) |  |  | $ | (173) |  |
| Other comprehensive gain (loss) before reclassifications | 31 |  |  | 3 |  |  | 34 |  |  | (65) |  |  | (85) |  |  | (150) |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | (27) |  |  | — |  |  | (27) |  |  | 44 |  |  | — |  |  | 44 |  |
| Net current-period other comprehensive gain (loss) | 4 |  |  | 3 |  |  | 7 |  |  | (21) |  |  | (85) |  |  | (106) |  |
| Ending balance | $ | 24 |  |  | $ | (128) |  |  | $ | (104) |  |  | $ | (34) |  |  | $ | (245) |  |  | $ | (279) |  |

[0000866374-26-000005:notes:103]
|  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain (loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (19) |  |  | $ | (205) |  |  | $ | (224) |  |  | $ | 4 |  |  | $ | (199) |  |  | $ | (195) |  |
| Other comprehensive gain (loss) before reclassifications | 112 |  |  | 77 |  |  | 189 |  |  | (87) |  |  | (46) |  |  | (133) |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | (69) |  |  | — |  |  | (69) |  |  | 49 |  |  | — |  |  | 49 |  |
| Net current-period other comprehensive gain (loss) | 43 |  |  | 77 |  |  | 120 |  |  | (38) |  |  | (46) |  |  | (84) |  |
| Ending balance | $ | 24 |  |  | $ | (128) |  |  | $ | (104) |  |  | $ | (34) |  |  | $ | (245) |  |  | $ | (279) |  |

[0000866374-26-000005:notes:104]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and nine-month periods ended December 31, 2025 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the condensed consolidated statements of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in accumulated other comprehensive loss for the three-month periods ended December 31, 2025 and 2024 were $(1) million and $5 million, respectively. The tax impacts on the changes in accumulated other comprehensive loss for the nine-month periods ended December 31, 2025 and 2024 were $(14) million and $16 million, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-26-000005:notes:105]
TRADE RECEIVABLES SALES PROGRAMSThe Company sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was $0.6 billion and $0.7 billion as of December 31, 2025 and March 31, 2025. For the nine-month periods ended December 31, 2025 and 2024, total accounts receivable sold to certain third-party banking institutions was $2.3 billion and $3.0 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000866374-26-000005:notes:106]
[same as prior period, unchanged from 0000866374-25-000051:notes:100]

[0000866374-26-000005:notes:107]
[same as prior period, unchanged from 0000866374-25-000051:notes:101]

[0000866374-26-000005:notes:108]
[same as prior period, unchanged from 0000866374-25-000051:notes:102]

[0000866374-26-000005:notes:109]
[same as prior period, unchanged from 0000866374-25-000051:notes:103]

[0000866374-26-000005:notes:110]
[same as prior period, unchanged from 0000866374-25-000051:notes:104]


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-26-000005:notes:111]
[same as prior period, unchanged from 0000866374-25-000051:notes:105]

[0000866374-26-000005:notes:112]
[same as prior period, unchanged from 0000866374-25-000051:notes:106]

[0000866374-26-000005:notes:113]
The Company has accrued for contingent consideration related to an acquisition in fiscal year 2025, classified as a level 3 measurement in the fair value hierarchy due to significant unobservable inputs. Fair value is determined using internal cash flow models that incorporate unobservable inputs, including the probability of achieving performance milestones. As of December 31, 2025 and March 31, 2025, the balance of contingent consideration was $2 million and $5 million, respectively.

[0000866374-26-000005:notes:114]
[same as prior period, unchanged from 0000866374-25-000051:notes:109]

[0000866374-26-000005:notes:115]
During the nine-month periods ended December 31, 2025 and 2024, there were no other additions to the accrual, payments, fair value adjustments, or unrealized gains or losses included in earnings.

[0000866374-26-000005:notes:116]
[same as prior period, unchanged from 0000866374-25-000051:notes:108]

[0000866374-26-000005:notes:117]
[same as prior period, unchanged from 0000866374-25-000051:notes:111]

[0000866374-26-000005:notes:118]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of December 31, 2025 and March 31, 2025:

[0000866374-26-000005:notes:119]
|  | Fair Value Measurements as of December 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 2,254 |  |  | $ | — |  |  | $ | 2,254 |  |
| Foreign currency contracts (Note 8) | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | 35 |  |  | 14 |  |  | — |  |  | 49 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (29) |  |  | $ | — |  |  | $ | (29) |  |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (2) |  |  | (2) |  |
|  | Fair Value Measurements as of March 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,535 |  |  | $ | — |  |  | $ | 1,535 |  |
| Foreign currency contracts (Note 8) | — |  |  | 34 |  |  | — |  |  | 34 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (79) |  |  | $ | — |  |  | $ | (79) |  |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (5) |  |  | (5) |  |

[0000866374-26-000005:notes:120]
[same as prior period, unchanged from 0000866374-25-000051:notes:114]

[0000866374-26-000005:notes:121]
The following table presents the Company’s major debts not carried at fair value as of December 31, 2025 and March 31, 2025:

[0000866374-26-000005:notes:122]
|  | As of December 31, 2025 |  | As of March 31, 2025 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | — |  |  | $ | — |  |  | $ | 531 |  |  | $ | 531 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 675 |  |  | 674 |  |  | 678 |  |  | 672 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 411 |  |  | 398 |  |  | 409 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 654 |  |  | 665 |  |  | 655 |  |  | 651 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 672 |  |  | 683 |  |  | 676 |  |  | 669 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 651 |  |  | 666 |  |  | 499 |  |  | 497 |  |  | Level 1 |
| 5.375% Notes due November 2035 | 598 |  |  | 600 |  |  | — |  |  | — |  |  | Level 1 |
| Delayed Draw Term Loan due December 2027 | 500 |  |  | 500 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 305 |  |  | 244 |  |  | 269 |  |  | 215 |  |  | Level 2 |

[0000866374-26-000005:notes:123]
The Notes due June 2025, February 2026, January 2028, June 2029, May 2030, January 2032, and November 2035 are valued based on broker trading prices in active markets. The Delayed Draw Term Loan due December 2027 bears interest at variable interest rates; therefore, as of December 31, 2025, the carrying amount approximates fair value. HUF Bonds are valued based on the broker trading prices in an inactive market.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-26-000005:notes:124]
[same as prior period, unchanged from 0000866374-25-000051:notes:118]

[0000866374-26-000005:notes:125]
[same as prior period, unchanged from 0000866374-25-000051:notes:119]

[0000866374-26-000005:notes:126]
[same as prior period, unchanged from 0000866374-25-000051:notes:120]

[0000866374-26-000005:notes:127]
[same as prior period, unchanged from 0000866374-25-000051:notes:121]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-26-000005:notes:128]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-26-000005:notes:129]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-26-000005:notes:130]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. The Company was unsuccessful at the administrative level in two of the remaining assessments and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 37 million Brazilian reals (approximately USD $7 million). The Brazilian court ruled in favor of the Company on the first annulment action on March 7, 2025 and the assessment obligation has been canceled, although it remains subject to appeal. The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 60 million Brazilian reals (approximately USD $11 million). The Company is still awaiting a resolution of the second annulment action. The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on the remaining assessments and annulment actions in the near future.

[0000866374-26-000005:notes:131]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagreed with the Tax Authority’s assessments and was actively contesting the assessments through the administrative and judicial processes. During the three-month period ended December 31, 2025, the Company and the Tax Authority agreed to a $50 million settlement covering all open fiscal years and all assessed amounts. The Company had previously expensed $31 million and paid $30 million to the Tax Authority in prior fiscal years and agreed to make an

[0000866374-26-000005:notes:132]
additional $20 million cash payment to the Tax Authority subsequent to the execution of a definitive settlement agreement, which resulted in a charge to income tax expense of $19 million in the third quarter ended December 31, 2025. The definitive settlement agreement was executed on February 3, 2026 and the $20 million cash payment is expected to occur in the fourth quarter of fiscal year ending March 31, 2026.

[0000866374-26-000005:notes:133]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-26-000005:notes:134]
SHARE REPURCHASES 
During the three and nine-month period ended December 31, 2025, the Company repurchased 3.3 million and 16.1 million shares at aggregate purchase prices of $200 million and $744 million, respectively, and retired all of these shares.

[0000866374-26-000005:notes:135]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.7 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the most recent Annual General Meeting held on August 6, 2025. As of December 31, 2025, shares in the aggregate amount of $1.3 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-26-000005:notes:136]
[same as prior period, unchanged from 0000866374-25-000051:notes:130]

[0000866374-26-000005:notes:137]
[same as prior period, unchanged from 0000866374-25-000051:notes:131]

[0000866374-26-000005:notes:138]
[same as prior period, unchanged from 0000866374-25-000051:notes:132]

[0000866374-26-000005:notes:139]
Selected financial information by segment for the three and nine-month period ended December 31, 2025 and 2024 are in the tables below:

[0000866374-26-000005:notes:140]
|  | FAS |  | FRS |  | Corporate & Other |  | Total |
| Three-Months Ended December 31, 2025 | (In millions) |
| Net Sales | $ | 3,818 |  |  | $ | 3,240 |  |  | $ | — |  |  | $ | 7,058 |  |
| Cost of inventory | (2,795) |  |  | (2,137) |  |  | 1 |  |  | (4,931) |  |
| Manufacturing expenses | (695) |  |  | (758) |  |  | 16 |  |  | (1,437) |  |
| Segment selling, general and administrative expenses | (89) |  |  | (112) |  |  | (29) |  |  | (230) |  |
| Segment income | $ | 239 |  |  | $ | 233 |  |  | $ | (12) |  |  | $ | 460 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 15 |  |
| Stock-based compensation |  |  |  |  |  |  | 37 |  |
| Restructuring and impairment charges (1) |  |  |  |  |  |  | 9 |  |
| Customer related asset recoveries (2) |  |  |  |  |  |  | (2) |  |
| Legal and other (3) |  |  |  |  |  |  | 12 |  |
| Interest expenses |  |  |  |  |  |  | 58 |  |
| Interest income |  |  |  |  |  |  | 15 |  |
| Other charges (income), net |  |  |  |  |  |  | 25 |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (1) |  |
| Income before income taxes |  |  |  |  |  |  | $ | 320 |  |

[0000866374-26-000005:notes:141]
(1)Certain restructuring charges of $2 million are excluded from the reconciling amount of $9 million as they are included within segment income.

[0000866374-26-000005:notes:142]
(2)Customer related asset impairments (recoveries) may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value.

[0000866374-26-000005:notes:143]
(3)Legal and other consists of costs not directly related to core business results and including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims, impairments and other costs such as acquisition and portfolio optimization related costs. During the third quarter of fiscal year 2026, costs primarily related to other costs.

[0000866374-26-000005:notes:144]
|  | FAS |  | FRS |  | Corporate & Other |  | Total |
| Nine-Months Ended December 31, 2025 | (In millions) |
| Net Sales | $ | 11,275 |  |  | $ | 9,162 |  |  | $ | — |  |  | $ | 20,437 |  |
| Cost of inventory | (8,307) |  |  | (6,020) |  |  | — |  |  | (14,327) |  |
| Manufacturing expenses | (1,996) |  |  | (2,207) |  |  | 11 |  |  | (4,192) |  |
| Segment selling, general and administrative expenses | (266) |  |  | (333) |  |  | (55) |  |  | (654) |  |
| Segment income | $ | 706 |  |  | $ | 602 |  |  | $ | (44) |  |  | $ | 1,264 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 52 |  |
| Stock-based compensation |  |  |  |  |  |  | 108 |  |
| Restructuring and impairment charges (1) |  |  |  |  |  |  | 83 |  |
| Customer related asset recoveries (2) |  |  |  |  |  |  | (2) |  |
| Legal and other (3) |  |  |  |  |  |  | 27 |  |
| Interest expenses |  |  |  |  |  |  | 161 |  |
| Interest income |  |  |  |  |  |  | 38 |  |
| Other charges (income), net |  |  |  |  |  |  | 19 |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (26) |  |
| Income before income taxes |  |  |  |  |  |  | $ | 828 |  |

[0000866374-26-000005:notes:145]
(1)During the nine-month period ended December 31, 2025, the Company recognized a total of $46 million in asset impairments, inventory write-downs and other related charges as a result of a missile strike on its Mukachevo, Ukraine facility on August 21, 2025. Refer to note 1 "Organization of the Company and Basis of Presentation" for further details. Certain restructuring charges of $2 million are excluded from the reconciling amount of $83 million as they are included within segment income.

[0000866374-26-000005:notes:146]
(3)Legal and other consists of costs not directly related to core business results and including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims, impairments and other costs such as acquisition and portfolio optimization related costs. During fiscal year 2026, legal and other costs primarily related to other costs.

[0000866374-26-000005:notes:147]
|  | FAS |  | FRS |  | Corporate & Other |  | Total |
| Three-Months Ended December 31, 2024 | (In millions) |
| Net Sales | $ | 3,599 |  |  | $ | 2,957 |  |  | $ | — |  |  | $ | 6,556 |  |
| Cost of inventory | (2,650) |  |  | (1,967) |  |  | — |  |  | (4,617) |  |
| Manufacturing expenses | (637) |  |  | (685) |  |  | (7) |  |  | (1,329) |  |
| Segment selling, general and administrative expenses | (85) |  |  | (107) |  |  | (19) |  |  | (211) |  |
| Segment income | $ | 227 |  |  | $ | 198 |  |  | $ | (26) |  |  | $ | 399 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 17 |  |
| Stock-based compensation |  |  |  |  |  |  | 33 |  |
| Restructuring charges |  |  |  |  |  |  | 12 |  |
| Customer related asset recoveries (1) |  |  |  |  |  |  | (2) |  |
| Legal and other (2) |  |  |  |  |  |  | 5 |  |
| Interest expenses |  |  |  |  |  |  | 57 |  |
| Interest income |  |  |  |  |  |  | 16 |  |
| Other charges (income), net |  |  |  |  |  |  | 5 |  |
| Income before income taxes |  |  |  |  |  |  | $ | 288 |  |

[0000866374-26-000005:notes:148]
(1)Customer related asset impairments (recoveries) may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. During the three-month period ended December 31, 2024, the Company recognized $2 million of customer related asset recoveries.

[0000866374-26-000005:notes:149]
(2)Legal and other consists of costs not directly related to core business results and including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims, impairments and other costs such as acquisition and portfolio optimization related costs. During the third quarter of fiscal year 2025, the Company accrued for a $5 million asset impairment where losses were considered probable and estimable.

[0000866374-26-000005:notes:150]
|  | FAS |  | FRS |  | Corporate & Other |  | Total |
| Nine-Months Ended December 31, 2024 | (In millions) |
| Net Sales | $ | 10,570 |  |  | $ | 8,845 |  |  | $ | — |  |  | $ | 19,415 |  |
| Cost of inventory | (7,826) |  |  | (5,958) |  |  | — |  |  | (13,784) |  |
| Manufacturing expenses | (1,875) |  |  | (2,076) |  |  | (21) |  |  | (3,972) |  |
| Segment selling, general and administrative expenses | (245) |  |  | (307) |  |  | (44) |  |  | (596) |  |
| Segment income | $ | 624 |  |  | $ | 504 |  |  | $ | (65) |  |  | $ | 1,063 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization |  |  |  |  |  |  | $ | 49 |  |
| Stock-based compensation |  |  |  |  |  |  | 93 |  |
| Restructuring charges |  |  |  |  |  |  | 54 |  |
| Customer related asset recoveries (1) |  |  |  |  |  |  | (2) |  |
| Legal and other (2) |  |  |  |  |  |  | 5 |  |
| Interest expenses |  |  |  |  |  |  | 166 |  |
| Interest income |  |  |  |  |  |  | 48 |  |
| Other charges (income), net |  |  |  |  |  |  | (1) |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (3) |  |
| Income before income taxes |  |  |  |  |  |  | $ | 744 |  |

[0000866374-26-000005:notes:151]
(1)Customer related asset impairments (recoveries) may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. During the nine-month period ended December 31, 2024, the Company recognized $2 million of customer related asset recoveries.

[0000866374-26-000005:notes:152]
(2)Legal and other consists of costs not directly related to core business results and including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims, impairments and other costs such as acquisition and portfolio optimization related costs. During the first three quarters of fiscal year 2025, the Company accrued for a $5 million asset impairment where losses were considered probable and estimable.

[0000866374-26-000005:notes:153]
[same as prior period, unchanged from 0000866374-25-000051:notes:140]

[0000866374-26-000005:notes:154]
[same as prior period, unchanged from 0000866374-25-000051:notes:141]

[0000866374-26-000005:notes:155]
[same as prior period, unchanged from 0000866374-25-000051:notes:142]

[0000866374-26-000005:notes:156]
Total depreciation expense, including amounts allocated to the reportable segments and Corporate and Other for the three and nine-month period ended December 31, 2025 and 2024 are as follows:

[0000866374-26-000005:notes:157]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
|  | (In millions) |  | (In millions) |
| Depreciation expense: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 44 |  |  | $ | 45 |  |  | $ | 138 |  |  | $ | 134 |  |
| Flex Reliability Solutions | 67 |  |  | 62 |  |  | 195 |  |  | 188 |  |
| Corporate and Other | 2 |  |  | 3 |  |  | 9 |  |  | 9 |  |
| Total depreciation expense | $ | 113 |  |  | $ | 110 |  |  | $ | 342 |  |  | $ | 331 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-26-000005:notes:158]
RESTRUCTURING CHARGES
The Company continued to improve operational efficiencies through targeted restructuring activities during the third quarter of fiscal year 2026. During the three and nine-month periods ended December 31, 2025, the Company recognized $6 million and $39 million of restructuring charges, respectively, most of which related to employee severance. Certain restructuring charges of $2 million are included in segment income.

[0000866374-26-000005:notes:159]
The following table summarizes the provisions, respective payments, and remaining accrued balance for charges incurred as of December 31, 2025:

[0000866374-26-000005:notes:160]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2025 | $ | 51 |  |  | $ | — |  |  | $ | — |  |  | $ | 51 |  |
| Provision for net charges incurred | 26 |  |  | 9 |  |  | 4 |  |  | 39 |  |
| Cash payments | (47) |  |  | — |  |  | (4) |  |  | (51) |  |
| Non-cash reductions | — |  |  | (9) |  |  | — |  |  | (9) |  |
| Other adjustments | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Balance as of December 31, 2025 | 30 |  |  | — |  |  | 1 |  |  | 31 |  |
| Less: Current portion (classified as other current liabilities) | 30 |  |  | — |  |  | 1 |  |  | 31 |  |
| Accrued restructuring costs, net of current portion (classified as other non-current liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000866374-26-000005:notes:161]
On December 8, 2025, Hooi Tan, Chief Operating Officer, adopted a trading plan that provides for the sale of up to 70,000 ordinary shares of the Company. The plan will terminate on December 10, 2026, subject to early termination for certain specified events set forth in the plan.
