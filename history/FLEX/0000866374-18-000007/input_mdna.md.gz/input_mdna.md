# FLEX MD&A — 0000866374-18-000007


## mdna

[0000866374-18-000007:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-18-000007:mdna:2]
OVERVIEW

[0000866374-18-000007:mdna:3]
We are a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer and enterprise products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through our activities in the following segments:

[0000866374-18-000007:mdna:4]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads, and small cells for wireless infrastructure; our networking business which includes optical, routing, broadcasting, and switching products for the data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions; |

[0000866374-18-000007:mdna:5]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion and apparel, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

[0000866374-18-000007:mdna:6]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, electric vehicle infrastructure, smart solar energy, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation, and kiosks; and |

[0000866374-18-000007:mdna:7]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; our automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies. |

[0000866374-18-000007:mdna:8]
These segments represent components of the Company for which separate financial information is available that is utilized on a regular basis by the Chief Operating Decision Maker (“CODM”). Our segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 20 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for additional information on our operating segments.

[0000866374-18-000007:mdna:9]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-18-000007:mdna:10]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0000866374-18-000007:mdna:11]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customer's supply chain solutions needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-18-000007:mdna:12]
During the past several years, we have evolved our long-term portfolio towards a mix of businesses which possess longer product life cycles and higher segment operating margins such as reflected in our IEI and HRS businesses. Since the beginning of fiscal year 2016, we launched several programs broadly across our portfolio of services and in some instances we deployed certain new technologies. We continue to invest in innovation and we have expanded our design and engineering relationships through our product innovation centers.

[0000866374-18-000007:mdna:13]
We believe that our continued business transformation is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services, which remain strong.

[0000866374-18-000007:mdna:14]
We are one of the world's largest providers of global supply chain solutions, with revenues of $25.4 billion in fiscal year 2018. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 35 countries across four continents. As of March 31, 2018, our total manufacturing capacity was approximately 28 million square feet. In fiscal year 2018, our net sales in Asia, the Americas and Europe represented approximately 44%, 39% and 17%, respectively, of our total net sales, based on the location of the manufacturing site. The following tables set forth net sales and net property and equipment, by country, based on the location of our manufacturing sites and the relative percentages:

[0000866374-18-000007:mdna:15]
|  | Fiscal Year Ended March 31, |
| Net sales: | 2018 |  | 2017 |  | 2016 |
|  | (In millions) |
| China | $ | 7,450 |  |  | 29 | % |  | $ | 7,214 |  |  | 30 | % |  | $ | 8,471 |  |  | 35 | % |
| Mexico | 4,362 |  |  | 17 | % |  | 4,076 |  |  | 17 | % |  | 3,645 |  |  | 15 | % |
| U.S. | 2,860 |  |  | 11 | % |  | 2,560 |  |  | 11 | % |  | 2,768 |  |  | 11 | % |
| Brazil | 2,578 |  |  | 10 | % |  | 1,908 |  |  | 8 | % |  | 1,839 |  |  | 8 | % |
| Malaysia | 2,005 |  |  | 8 | % |  | 2,267 |  |  | 10 | % |  | 2,242 |  |  | 9 | % |
| Other | 6,186 |  |  | 25 | % |  | 5,838 |  |  | 24 | % |  | 5,454 |  |  | 22 | % |
|  | $ | 25,441 |  |  |  |  | $ | 23,863 |  |  |  |  |  | $ | 24,419 |  |  |  |  |

[0000866374-18-000007:mdna:16]
|  | Fiscal Year Ended March 31, |
| Property and equipment, net: | 2018 |  | 2017 |
|  | (In millions) |
| Mexico | $ | 587 |  |  | 26 | % |  | $ | 525 |  |  | 23 | % |
| China | 492 |  |  | 22 | % |  | 720 |  |  | 31 | % |
| U.S. | 305 |  |  | 14 | % |  | 291 |  |  | 13 | % |
| Malaysia | 153 |  |  | 7 | % |  | 173 |  |  | 7 | % |
| Hungary | 150 |  |  | 7 | % |  | 133 |  |  | 6 | % |
| Other | 553 |  |  | 24 | % |  | 475 |  |  | 21 | % |
|  | $ | 2,240 |  |  |  |  | $ | 2,317 |  |  |  |

[0000866374-18-000007:mdna:17]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-18-000007:mdna:18]
Our operating results are affected by a number of factors, including the following:

[0000866374-18-000007:mdna:19]
| • | changes in the macro-economic environment and related changes in consumer demand; |

[0000866374-18-000007:mdna:20]
| • | the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors; |

[0000866374-18-000007:mdna:21]
| • | the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance; |

[0000866374-18-000007:mdna:22]
| • | our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers; |

[0000866374-18-000007:mdna:23]
| • | the effects on our business due to certain customers' products having short product life cycles; |

[0000866374-18-000007:mdna:24]
| • | our customers' ability to cancel or delay orders or change production quantities; |

[0000866374-18-000007:mdna:25]
| • | our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements; |

[0000866374-18-000007:mdna:26]
| • | our exposure to financially troubled customers; |

[0000866374-18-000007:mdna:27]
| • | integration of acquired businesses and facilities; |

[0000866374-18-000007:mdna:28]
| • | increased labor costs due to adverse labor conditions in the markets we operate; |

[0000866374-18-000007:mdna:29]
| • | changes in tax legislation; and |

[0000866374-18-000007:mdna:30]
| • | changes in trade regulations and treaties. |

[0000866374-18-000007:mdna:31]
We also are subject to other risks as outlined in Item 1A, "Risk Factors".

[0000866374-18-000007:mdna:32]
Net sales for fiscal year 2018 increased 7% or $1.6 billion to $25.4 billion from the prior year. The increase was primarily due to a $1.0 billion increase in our IEI segment, as well as $0.6 billion increases in each of our HRS and CTG segments, partially offset by a $0.7 billion decrease in our CEC segment. Our fiscal year 2018 gross profit totaled $1.6 billion, representing an increase of $75 million, or 4.9%, from the prior year, which is primarily due to contribution flow through from the additional $1.6 billion in sales from the prior year, offset by restructuring charges of $67 million included in cost of sales in fiscal year 2018. Our net income totaled $429 million, representing an increase of $109 million, or 34%, compared to fiscal year 2017. The increase in net income during fiscal year 2018 is primarily due to the same factors explained above coupled

[0000866374-18-000007:mdna:33]
35

[0000866374-18-000007:mdna:34]
with the recognition of a $152 million gain from the deconsolidation of our subsidiary, Elementum SCM (Cayman) Ltd ("Elementum"), and a $39 million gain from sale of Wink Labs Inc. ("Wink"). Refer to note 6 and note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details of the deconsolidation of Elementum and the disposition of Wink, respectively.

[0000866374-18-000007:mdna:35]
Cash provided by operations decreased by approximately $0.3 billion to $0.8 billion for fiscal years 2018 compared with $1.1 billion for fiscal year 2017 primarily due to unfavorable changes in operating assets and liabilities. Our average net working capital, defined as accounts receivable, including the deferred purchase price receivables from our asset-backed securitization programs, plus inventory, less accounts payable, as a percentage of annualized sales decreased by 0.5% to 6.4%. Our free cash flow, which we define as cash from operating activities less net purchases of property and equipment, was $236 million for fiscal year 2018 compared to $660 million for fiscal year 2017. The decrease in free cash flow is primarily due to lesser cash flows from operations and higher capital expenditures in fiscal year 2018. Refer to the Liquidity and Capital Resources section for the free cash flows reconciliation to our most directly comparable GAAP financial measure of cash flows from operations. Cash used in investing activities increased by approximately $0.2 billion to $0.9 billion for fiscal year 2018, compared with $0.7 billion for fiscal year 2017, primarily due to an increase in the amount of cash paid for acquired businesses during fiscal year 2018. Cash used in financing activities totaled $188 million during fiscal year 2018, which decreased $54 million from $242 million in the prior year, primarily due to a lower level of repurchases of ordinary shares.

[0000866374-18-000007:mdna:36]
Additionally, in fiscal year 2018, the Company initiated targeted restructuring activities, focused on optimizing our cost structure in lower growth areas and, more importantly, streamlining certain corporate and segment functions. The objective of the plan is to make Flex a faster, more responsive and agile company, better positioned to react to marketplace opportunities. During the year ended March 31, 2018, we recognized $91 million of pre-tax restructuring charges, comprised of $79 million of cash charges predominantly related to severance costs and $12 million of non-cash charges primarily related to asset impairment and other exit charges.

[0000866374-18-000007:mdna:37]
Audit Committee Investigation Completed

[0000866374-18-000007:mdna:38]
As previously disclosed, the Audit Committee of the Company’s Board of Directors (the “Audit Committee”), with the assistance of independent outside counsel, undertook an independent investigation relating to the accounting treatment of customer obligations and certain related reserves. The independent outside counsel also notified the SEC. The Audit Committee has now completed its investigation.

[0000866374-18-000007:mdna:39]
The Company, working with its independent registered public accounting firm, identified and the Audit Committee concurred with such identification, material weaknesses in our internal control over financial reporting which could, if not remediated, result in material misstatements in our financial statements. Notwithstanding the identification of such material weaknesses, management believes that the Company’s financial statements included in this annual report on Form 10-K fairly present, in all material respects, the Company’s financial condition, results of operations and cash flows as of, and for the periods presented, in conformity with accounting principles generally accepted in the United States of America. The conclusions of management, with which the Audit Committee concurred, concerning the material weaknesses in the Company’s internal control over financial reporting are described further in Item 9A “Controls and Procedures”.

[0000866374-18-000007:mdna:40]
We have undertaken, and will continue to undertake, steps to improve our internal control over financial reporting to address and remediate the material weaknesses. The proposed plan to remediate the material weaknesses is described further in Item 9A “Controls and Procedures”.

[0000866374-18-000007:mdna:41]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000866374-18-000007:mdna:42]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results may differ from those estimates and assumptions.

[0000866374-18-000007:mdna:43]
We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-18-000007:mdna:44]
Revenue Recognition

[0000866374-18-000007:mdna:45]
36

[0000866374-18-000007:mdna:46]
We recognize manufacturing revenue when we ship goods or the goods are received by our customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then we recognize the related revenues at the time when such requirements are completed, and the obligations are fulfilled. Some of our customer contracts allow the recovery of certain costs related to manufacturing services that are over and above the prices charged for the related products. Also, certain customer contracts may contain certain commitments and obligations that may result in additional expenses or decrease in revenue. Refer to note 3 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-18-000007:mdna:47]
Customer Credit Risk

[0000866374-18-000007:mdna:48]
We have an established customer credit policy through which we manage customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. We perform ongoing credit evaluations of our customers' financial condition and make provisions for doubtful accounts based on the outcome of those credit evaluations. We evaluate the collectability of accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent we identify exposures as a result of customer credit issues, we also review other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-18-000007:mdna:49]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison"), filed a petition for reorganization under bankruptcy law. During the fiscal year ended March 31, 2016, we recognized a bad debt reserve charge of $61 million associated with our outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90 million. During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. We determined that certain solar panel inventory previously designated for SunEdison on hand at the end of the second quarter of fiscal year 2017 was not fully recoverable and recorded a charge of $60 million to reduce the carrying costs to market during fiscal year 2017. In addition, we recognized a $16 million impairment charge for solar module equipment and incurred $17 million of incremental costs primarily related to negative margin sales and other associated solar panel direct costs. The total charge of $93 million is included in cost of sales for fiscal year 2017.

[0000866374-18-000007:mdna:50]
Restructuring Charges

[0000866374-18-000007:mdna:51]
We recognize restructuring charges related to our plans to close or consolidate excess manufacturing facilities and rationalize administrative functions and to realign our corporate cost structure. In connection with these activities, we recognize restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-18-000007:mdna:52]
The recognition of these restructuring charges requires that we make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned restructuring activity. To the extent our actual results differ from our estimates and assumptions, we may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, we evaluate the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed exit plans.

[0000866374-18-000007:mdna:53]
Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-18-000007:mdna:54]
Inventory Valuation

[0000866374-18-000007:mdna:55]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regards to inventory procured to fulfill customer demand.

[0000866374-18-000007:mdna:56]
Valuation of Private Company Investments

[0000866374-18-000007:mdna:57]
We assess our cost method investments for impairment whenever events or changes in circumstances indicate that the assets may be impaired. The factors we consider in our evaluation of potential impairment of our cost method investments, include, but are not limited to a significant deterioration in the earnings performance or business prospects of the investee, or

[0000866374-18-000007:mdna:58]
factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. The carrying value of certain of our investments are individually material, thus there is the potential for material charges in future periods if we determine that those investments are impaired.

[0000866374-18-000007:mdna:59]
Carrying Value of Long-Lived Assets

[0000866374-18-000007:mdna:60]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset may not be recoverable. An impairment loss is recognized when the carrying amount of these long-lived assets exceeds their fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such assets are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, general business environment and other factors. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize additional impairment charges in the future.

[0000866374-18-000007:mdna:61]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. The Company performed its goodwill impairment assessment on January 1, 2018 and determined that no impairment existed as of the date of the impairment test because the fair value of each reporting unit exceeded its carrying value.

[0000866374-18-000007:mdna:62]
Contingent Liabilities

[0000866374-18-000007:mdna:63]
We may be exposed to certain liabilities relating to our business operations, acquisitions of businesses and assets and other activities. We make provisions for such liabilities when it is probable that the settlement of the liability will result in an outflow of economic resources or the impairment of an asset. We make these assessments based on facts and circumstances that may change in the future resulting in additional expenses.

[0000866374-18-000007:mdna:64]
Refer to note 13 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our contingent liabilities.

[0000866374-18-000007:mdna:65]
Income Taxes

[0000866374-18-000007:mdna:66]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-18-000007:mdna:67]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-18-000007:mdna:68]
RESULTS OF OPERATIONS

[0000866374-18-000007:mdna:69]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data." The data below, and discussion that follows, represents our results from operations.

[0000866374-18-000007:mdna:70]
|  | Fiscal Year EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.5 |  |  | 93.5 |  |  | 93.4 |  |
| Restructuring charges | 0.3 |  |  | 0.2 |  |  | — |  |
| Gross profit | 6.2 |  |  | 6.3 |  |  | 6.6 |  |
| Selling, general and administrative expenses | 4.0 |  |  | 3.9 |  |  | 3.9 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.1 |  |  | — |  |  | — |  |
| Other charges (income), net | (0.7 | ) |  | 0.1 |  |  | 0.2 |  |
| Interest and other, net | 0.5 |  |  | 0.4 |  |  | 0.3 |  |
| Income before income taxes | 2.0 |  |  | 1.6 |  |  | 1.9 |  |
| Provision for income taxes | 0.4 |  |  | 0.2 |  |  | — |  |
| Net Income | 1.6 | % |  | 1.4 | % |  | 1.9 | % |

[0000866374-18-000007:mdna:71]
Net sales

[0000866374-18-000007:mdna:72]
Net sales during fiscal year 2018 totaled $25.4 billion, representing an increase of $1.5 billion, or 7%, from $23.9 billion during fiscal year 2017. The overall increase in sales was driven by increases in three of our segments offset by a decline in sales in our CEC segment. During fiscal year 2018, the increase in net sales was primarily driven by an increase of $1.3 billion in the Americas and to a lesser extent, $0.2 billion in Asia with Europe remaining relatively consistent in fiscal year 2017.

[0000866374-18-000007:mdna:73]
Net sales during fiscal year 2017 totaled $23.9 billion, representing a decrease of $0.5 billion, or 2%, from $24.4 billion during fiscal year 2016. During fiscal year 2017, net sales decreased $0.8 billion in Asia, while increasing $0.2 billion in the Americas, and $36 million in Europe.

[0000866374-18-000007:mdna:74]
The following table sets forth net sales by segments and their relative percentages. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0000866374-18-000007:mdna:75]
|  | Fiscal Year Ended March 31, |
| Segments: | 2018 |  | 2017 |  | 2016 |
|  | (In millions) |
| Communications & Enterprise Compute | $ | 7,729 |  |  | 30 | % |  | $ | 8,384 |  |  | 35 | % |  | $ | 8,842 |  |  | 36 | % |
| Consumer Technologies Group | 6,970 |  |  | 27 | % |  | 6,362 |  |  | 27 | % |  | 6,997 |  |  | 29 | % |
| Industrial & Emerging Industries | 5,972 |  |  | 24 | % |  | 4,968 |  |  | 21 | % |  | 4,681 |  |  | 19 | % |
| High Reliability Solutions | 4,769 |  |  | 19 | % |  | 4,149 |  |  | 17 | % |  | 3,899 |  |  | 16 | % |
|  | $ | 25,441 |  |  |  |  |  | $ | 23,863 |  |  |  |  |  | $ | 24,419 |  |  |  |  |

[0000866374-18-000007:mdna:76]
Net sales during fiscal year 2018 increased $1.0 billion or 20% in our IEI segment, which was mainly driven by our industrial, home and lifestyle businesses in addition to growth in our solar energy business. Our CTG segment increased $0.6 billion or 10% largely attributable to stronger sale in our connected living and mobile devices businesses, offset by a decrease in gaming. Our HRS segment increased $0.6 billion or 15% from higher sales in our automotive business. These increases were partially offset by a decrease of $0.7 billion or 8% in our CEC segment, largely attributable to lower sales within our telecom and networking businesses, offset by increased sales in our cloud and data center business.

[0000866374-18-000007:mdna:77]
Net sales during fiscal year 2017 decreased $0.6 billion or 9% in the CTG segment and $0.5 billion or 5% in the CEC segment. The decline in sales for CTG was primarily due to a decline in demand from our largest smartphone customer, Lenovo/Motorola, in connection with our exit of a China operation dedicated to this customer, partially offset by revenues from our Bose acquisition, as well as ramping of a broad mix of customers. The decrease in CEC is largely attributable to lower sales within our legacy server and storage business. These decreases were partially offset by a $287 million or 6% increase in sales from our IEI segment driven by contribution from our NEXTracker Inc. ("NEXTracker") acquisition and expansion within our capital equipment business, and by a $250 million or 6% increase in sales from our HRS segment primarily driven by our automotive business.

[0000866374-18-000007:mdna:78]
Our ten largest customers during fiscal years 2018, 2017 and 2016 accounted for approximately 41%, 43% and 46% of net sales, respectively. We have made substantial efforts toward the diversification of our portfolio which allows us to operate at scale in many different industries, and, as a result, no customer accounted for greater than 10% of net sales in fiscal year 2018 and 2017. During fiscal year 2016, only Lenovo/Motorola, which is reflected in our CTG segment, accounted for greater than 10% of net sales.

[0000866374-18-000007:mdna:79]
Gross profit

[0000866374-18-000007:mdna:80]
Gross profit is affected by a number of factors, including the number, size and complexity of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization, and the expansion and consolidation of manufacturing facilities including specific restructuring activities from time to time. The flexible design of our manufacturing processes allows us to build a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-18-000007:mdna:81]
Gross profit during fiscal year 2018 increased $75 million to $1.6 billion from $1.5 billion during fiscal year 2017, primarily as a result of the increase in revenue offset by $67 million, or 30 basis points, of restructuring charges incurred during fiscal year 2018. Gross margin decreased 10 basis points, to 6.2% of net sales in fiscal year 2018, from 6.3% of net sales in fiscal year 2017, mainly attributable to the same factors previously described, coupled with elevated levels of investments in ramping new operations for our strategic footwear customer.

[0000866374-18-000007:mdna:82]
Gross profit during fiscal year 2017 decreased $87 million to $1.5 billion from $1.6 billion during fiscal year 2016, primarily as a result of the $93 million, or 40 basis points, of charges recognized related to the significant decline in prices for solar modules and the slowdown in demand as previously discussed under our customer credit risk section, coupled with the restructuring charges incurred during fiscal year 2017, to accelerate our ability to support more Sketch-to-Scaletm efforts across the Company. A portion of this decrease was offset by our strategic evolution and structural mix shift to higher margin end markets in our IEI and HRS segments, while also providing greater levels of innovation, design and engineering services. Gross margin decreased 30 basis points to 6.3% of net sales in fiscal year 2017, from 6.6% of net sales in fiscal year 2016, mainly attributable to the same factors previously described. In addition, we have been ramping several new programs this year along with the continued development of our long-term strategic partnership with a CTG customer which has negatively impacted our margins due to elevated investment costs and under-absorbed overhead.

[0000866374-18-000007:mdna:83]
Segment income

[0000866374-18-000007:mdna:84]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales, less cost of sales and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, distressed customer charges, contingencies and other, restructuring charges, other charges (income), net and interest and other, net. A portion of depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-18-000007:mdna:85]
The following table sets forth segment income and margins:

[0000866374-18-000007:mdna:86]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In millions) |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 186 |  |  | 2.4 | % |  | $ | 229 |  |  | 2.7 | % |  | $ | 265 |  |  | 3.0 | % |
| Consumer Technologies Group | 112 |  |  | 1.6 | % |  | 180 |  |  | 2.8 | % |  | 164 |  |  | 2.3 | % |
| Industrial & Emerging Industries | 235 |  |  | 3.9 | % |  | 180 |  |  | 3.6 | % |  | 157 |  |  | 3.4 | % |
| High Reliability Solutions | 381 |  |  | 8.0 | % |  | 334 |  |  | 8.1 | % |  | 295 |  |  | 7.6 | % |
| Corporate and Other | (128 | ) |  |  |  | (108 | ) |  |  |  | (89 | ) |  |  |
| Total segment income | 786 |  |  | 3.1 | % |  | 815 |  |  | 3.4 | % |  | 792 |  |  | 3.2 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 79 |  |  |  |  | 81 |  |  |  |  | 66 |  |  |  |
| Stock-based compensation | 85 |  |  |  |  | 82 |  |  |  |  | 77 |  |  |  |
| Distressed customers asset impairments (1) | 6 |  |  |  |  | 93 |  |  |  |  | 61 |  |  |  |
| Restructuring charges (2) | 91 |  |  |  |  | 49 |  |  |  |  | — |  |  |  |
| Contingencies and other (3) | 51 |  |  |  |  | 18 |  |  |  |  | — |  |  |  |
| Other charges (income), net | (170 | ) |  |  |  | 21 |  |  |  |  | 48 |  |  |  |
| Interest and other, net | 123 |  |  |  |  | 100 |  |  |  |  | 85 |  |  |  |
| Income before income taxes | $ | 521 |  |  |  |  | $ | 371 |  |  |  |  | $ | 455 |  |  |  |

[0000866374-18-000007:mdna:87]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-18-000007:mdna:88]
| (1) | During fiscal year 2016, we accepted return of previously shipped inventory from a former customer, SunEdison, Inc. ("SunEdison"), of approximately $90 million. On April 21, 2016, SunEdison filed a petition for reorganization under bankruptcy law, and as a result, we recognized a bad debt reserve of $61 million as of March 31, 2016, associated with our outstanding SunEdison receivables. |

[0000866374-18-000007:mdna:89]
During fiscal year 2017, prices for solar panel modules declined significantly. We determined that certain solar panel inventory on hand at the end of the fiscal year 2017 was not fully recoverable and recorded a charge of $60 million to reduce the carrying costs to market in fiscal year 2017. We also recognized a $16 million impairment charge for solar module equipment and $17 million primarily related to negative margin sales and other associated direct costs. The total charge of $93 million is included in cost of sales for fiscal year 2017 but is excluded from segment results above.

[0000866374-18-000007:mdna:90]
| (2) | The Company initiated restructuring plans in fiscal years 2018 and 2017 and incurred charges primarily for employee terminations costs, as well as other asset impairments. These charges are split between cost of sales and selling, general and administration expenses on the Company's consolidated statement of operations, and are excluded from the measurement of the Company's operating segment's performance. Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data". |

[0000866374-18-000007:mdna:91]
| (3) | During fiscal year 2018, we incurred charges in connection with the matters described in note 13 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data," for certain loss contingencies where we believe that losses are probable and estimable, coupled with various other charges predominately related to damages incurred from a typhoon that impacted one of our China facilities. Additionally, certain assets impairments were recorded during both fiscal years 2018 and 2017. |

[0000866374-18-000007:mdna:92]
CEC segment margin decreased 30 basis points to 2.4% for fiscal year 2018, from 2.7% during fiscal year 2017. The decrease was driven by lower revenues which negatively impacted profitability with under-absorbed overhead and higher investment costs. CEC segment margin decreased 30 basis points to 2.7%, for fiscal year 2017, from 3.0% during fiscal year 2016. The decrease was driven by lower capacity utilization causing reduced overhead absorption, and pricing pressures coupled with incremental costs for proactive repositioning of certain programs and actions to better align CEC's operating structure.

[0000866374-18-000007:mdna:93]
41

[0000866374-18-000007:mdna:94]
CTG segment margin decreased 120 basis points to 1.6% for fiscal year 2018, from 2.8% during fiscal year 2017, primarily driven by negatively impacted profits due to a lower contribution, and continued losses from our strategic partnership with a certain customer. CTG segment margin increased 50 basis points to 2.8% for fiscal year 2017, from 2.3% during fiscal year 2016, primarily driven by a portfolio shift within the CTG product mix with a greater concentration of higher margin products where we provide greater levels of design and engineering value-added content, as well as exiting of lower margin businesses and the benefit from a better-than-expected execution on certain products which were going end of life.

[0000866374-18-000007:mdna:95]
IEI segment margin increased 30 basis points to 3.9% for fiscal year 2018, from 3.6% during fiscal year 2017. The improvement reflected strong revenue expansion which has been led by several new customer programs and an improving overall demand across its diverse market that has contributed to overhead absorption benefits. IEI segment margin increased 20 basis points to 3.6% for fiscal year 2017, from 3.4% during fiscal year 2016. This is primarily driven by new program ramps and demand increase in capital equipment and our household, industrial and lifestyle businesses, partially offset by underperformance from the loss of SunEdison, which was formerly our largest IEI customer and relatedly, from sales of solar panel inventory acquired from SunEdison in 2016.

[0000866374-18-000007:mdna:96]
HRS segment margin decreased 10 basis point to 8.0% for fiscal year 2018, from 8.1% during fiscal year 2017. The slight decrease reflects investments in expanding the segment's design and engineering capabilities, coupled with ramping up new customers and programs. HRS segment margin increased 50 basis points to 8.1% for fiscal year 2017, from 7.6% during fiscal year 2016. The improvements are primarily the result of new program launches and richer mix with greater value-added business engagements as a result of greater design and engineering solutions as part of our Sketch-to-Scaletm offering.

[0000866374-18-000007:mdna:97]
Restructuring charges

[0000866374-18-000007:mdna:98]
During fiscal year 2018, we initiated targeted restructuring activities, focused on optimizing our cost structure in lower growth areas and, more importantly, streamlining certain corporate and segment functions. The objective of the plan is to make Flex a faster, more responsive and agile company, better positioned to react to marketplace opportunities. We recognized $79 million of pre-tax cash charges, predominantly related to employee severance costs, and $12 million of pre-tax non-cash charges for asset impairment and other exit charges. The restructuring charges by geographic region were $64 million in the Americas, $17 million in Asia and $10 million in Europe. We classified $67 million of these charges as a component of cost of sales and $24 million as a component of selling, general and administrative expenses during fiscal year 2018.

[0000866374-18-000007:mdna:99]
During fiscal year 2017, we initiated a restructuring plan to accelerate our ability to support more Sketch-to-Scaletm efforts across the Company and reposition away from historical legacy programs and structures through rationalizing our current footprint at existing sites including certain corporate SG&A functions. We recognized $49 million of pre-tax restructuring charges predominantly for employee termination costs. The restructuring charges by geographic region were $28 million in the Americas, $15 million in Asia and $6 million in Europe. We classified $39 million of these charges as a component of cost of sales and $10 million as a component of selling, general and administrative expenses. There were no material restructuring activities during fiscal years 2016.

[0000866374-18-000007:mdna:100]
Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-18-000007:mdna:101]
Selling, general and administrative expenses

[0000866374-18-000007:mdna:102]
Selling, general and administrative expenses ("SG&A") totaled $1.0 billion or 4.0% of net sales, during fiscal year 2018, compared to $937 million, or 3.9% of net sales, during fiscal year 2017, increasing by $82 million or 9%. This increase in SG&A was due to incremental costs associated with our continued expansion of our design and engineering resources and innovation system but also, due to the recognition of certain contingencies that are probable and estimable of payout. Refer to note 13 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of litigation and other legal matters, which could impact our results of operations, cash flow or financial condition in future periods. We also incurred incremental costs from our acquisitions in fiscal year 2018.

[0000866374-18-000007:mdna:103]
SG&A totaled $937 million, or 3.9% of net sales, during fiscal year 2017, compared to $955 million, or 3.9% of net sales, during fiscal year 2016, decreasing by $18 million or 2%. The decrease in SG&A in dollars is primarily the result of the nonrecurring $61 million bad debt reserve charge recognized in fiscal year 2016 as previously explained, offset by further investments in design and engineering resources by us to support our increased Sketch-to-Scaletm initiatives in fiscal year 2017. We also incurred incremental costs associated with our targeted acquisitions in fiscal year 2017.

[0000866374-18-000007:mdna:104]
Intangible amortization

[0000866374-18-000007:mdna:105]
Amortization of intangible assets in fiscal year 2018 decreased by $2 million to $79 million from $81 million in fiscal year 2017, primarily as a result of certain intangible assets being fully amortized during fiscal year 2018.

[0000866374-18-000007:mdna:106]
Amortization of intangible assets in fiscal year 2017 increased by $15 million to $81 million from $66 million in fiscal year 2016, primarily as a result of incremental amortization expense on intangibles assets relating to our acquisitions completed during fiscal year 2017, as well as those completed in the second half of fiscal year 2016.

[0000866374-18-000007:mdna:107]
Other charges (income), net

[0000866374-18-000007:mdna:108]
During fiscal year 2018, we recognized $152 million of gain from the deconsolidation of Elementum, and $39 million of gain from the sale of Wink. Refer to note 6 and note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details of the deconsolidation of Elementum and the disposition of Wink, respectively. We also recorded $22 million related to the impairment of certain non-core investments during fiscal year 2018. No other components of other charges and income, net incurred during fiscal year 2018 were material.

[0000866374-18-000007:mdna:109]
The fiscal year ended March 31, 2017 includes a $7 million loss attributable to a non-strategic facility sold during the second quarter of fiscal year 2017. No other components of other charges and income, net incurred during fiscal year 2017 were material.

[0000866374-18-000007:mdna:110]
During fiscal year 2016, we recognized other charges of $48 million primarily due to a $27 million loss on the disposition of a non-strategic Western European manufacturing facility which included a non-cash foreign currency translation loss of $25 million, and $22 million from the impairment of a non-core investment.

[0000866374-18-000007:mdna:111]
Interest and other, net

[0000866374-18-000007:mdna:112]
Interest and other, net was $123 million during fiscal year 2018, compared to $100 million during fiscal year 2017. The increase in interest and other, net of $23 million was primarily due to a $15 million increase of interest expense from higher weighted average interest rates and a higher borrowing level.

[0000866374-18-000007:mdna:113]
Interest and other, net was $100 million during fiscal year 2017, compared to $85 million during fiscal year 2016. The increase in interest and other, net of $15 million was primarily due to a $10 million increase of interest expense from the 4.750% Notes due June 15, 2025 and the Term Loan due November 2021, as further discussed in note 8 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data", and an $8 million decrease in foreign exchange gains, offset by $8 million of acquisition-related costs incurred during fiscal year 2016.

[0000866374-18-000007:mdna:114]
Income taxes

[0000866374-18-000007:mdna:115]
The Company works to ensure it accrues and pays the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which it operates. Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were 17.7%, 13.8% and 2.3% for the fiscal years 2018, 2017 and 2016, respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0000866374-18-000007:mdna:116]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  | 17.0 | % |
| Effect of tax rate differential | (46.9 | ) |  | (23.0 | ) |  | (13.7 | ) |
| Change in liability for uncertain tax positions | 4.3 |  |  | 0.2 |  |  | (3.0 | ) |
| Change in valuation allowance | 57.1 |  |  | 21.2 |  |  | 0.2 |  |
| Recognition of prior year taxes recoverable | (10.3 | ) |  | — |  |  | — |  |
| Other | (3.5 | ) |  | (1.6 | ) |  | 1.8 |  |
| Provision for income taxes | 17.7 | % |  | 13.8 | % |  | 2.3 | % |

[0000866374-18-000007:mdna:117]
The variation in our effective tax rate each year is primarily a result of recognition of earnings in foreign jurisdictions which are taxed at rates lower than the Singapore statutory rate including the effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia, Costa Rica, Netherlands and Israel of $22 million, $16 million and $7 million in fiscal years 2018, 2017 and 2016, respectively.  Additionally, our effective tax rate is impacted by changes in our liabilities for uncertain tax positions of $22 million, $1 million, and ($14) million and changes in our valuation allowances on deferred tax assets of $297 million, $79 million and $1 million in fiscal years 2018, 2017 and 2016, respectively. We generate most of our revenues and profits from operations outside of Singapore.

[0000866374-18-000007:mdna:118]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examinations, there could be a material adverse effect on our tax position, operating results, financial position and cash flows.

[0000866374-18-000007:mdna:119]
We provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized. During fiscal year 2018, we released valuation allowances totaling $1 million primarily related to our operations in Taiwan, Mexico and Ireland as these amounts were deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those subsidiaries. However, these valuation allowance eliminations were offset primarily by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions. In addition, due to increased negative evidence during the fiscal year ended March 31, 2018, the Company added a valuation allowance of $365 million for a Brazilian subsidiary which did not previously have a valuation allowance recorded.  Lastly, the Company released $705 million of valuation allowance to account for the reduced deferred tax asset as a result of the lower US corporate income tax rate which became effective January 1, 2018.

[0000866374-18-000007:mdna:120]
During fiscal year 2018, the Company recognized an income tax receivable of $54 million for prior period taxes paid by one of its Brazilian subsidiaries which was deemed recoverable during the period.

[0000866374-18-000007:mdna:121]
Impact of the U.S. Tax Reform

[0000866374-18-000007:mdna:122]
On December 22, 2017, the U.S. President signed the Tax Cuts and Jobs Act (the “Act”) into law. Effective January 1, 2018, among other changes, the Act reduces the U.S. federal corporate tax rate to 21 percent, provides for a deemed repatriation and taxation at reduced rates of certain non-US subsidiaries owned by U.S. companies’ historical earnings (a “transition tax”), and establishes new mechanisms to tax such earnings going forward. Similar to other large multinational companies with complex tax structures, the Act has wide ranging implications for Flex. However, the impact on Flex's financial statements for the twelve-month periods ended March 31, 2018 is immaterial, primarily because the Company has a full valuation allowance on deferred tax assets in the U.S., which results in there being no U.S. deferred tax assets or liabilities recorded on the balance sheet that need to be remeasured at the new 21% rate. Further, the Company expects that the new transition tax will be offset by foreign tax credits or net operating loss carryforwards, and thus will not result in any incremental taxes payable.  The Company will continue to analyze the effects of the Act on its financial statements and operations.  Any additional impacts from the enactment of the Act will be recorded as they are identified during the measurement period provided for in Staff Bulletin 118.

[0000866374-18-000007:mdna:123]
See note 14, "Income Taxes," to the consolidated financial statements included in Item 8, "Financial Statements and Supplementary Data" for further discussion.

[0000866374-18-000007:mdna:124]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-18-000007:mdna:125]
As of March 31, 2018, we had cash and cash equivalents of $1.5 billion and bank and other borrowings of $2.9 billion. We have a $1.75 billion revolving credit facility that is due to mature in June 2022, under which we had no borrowings outstanding as of March 31, 2018.

[0000866374-18-000007:mdna:126]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2018, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2018). Repatriation could result in an additional income tax payment; however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-18-000007:mdna:127]
Fiscal Year 2018

[0000866374-18-000007:mdna:128]
Cash provided by operating activities was $0.8 billion during fiscal year 2018. This resulted primarily from $429 million of net income for the period plus $478 million of non-cash charges such as depreciation, amortization and stock-based compensation, net of a gain from the deconsolidation of Elementum that are included in the determination of net income. Depreciation expense was $434 million of those non-cash charges which is relatively consistent with our normal annual run rate. These were partially offset by a net change in our operating assets and liabilities of $153 million, driven primarily by a $354 million increase in inventories, a $88 million increase in other current and noncurrent assets, and a $347 million increase

[0000866374-18-000007:mdna:129]
44

[0000866374-18-000007:mdna:130]
in accounts receivable, including the change in sales of accounts receivable, offset by a $623 million increase in accounts payable and a $13 million increase in other current and noncurrent liabilities. Net working capital ("NWC"), defined as net accounts receivable, including deferred purchase price receivables, plus inventory less accounts payable decreased by $30 million.

[0000866374-18-000007:mdna:131]
Cash used in investing activities totaled $0.9 billion during fiscal year 2018. This resulted primarily from $214 million paid for the acquisition of AGM Automotive ("AGM") for our HRS segment, net of cash acquired, and $55 million paid for a power module business for our CEC segment, net of cash acquired. Further, we invested $517 million of net capital expenditures for property and equipment to expand capabilities and capacity in support of our automotive, medical, footwear and IEI businesses. In addition, other investing activities includes $73 million of cash of Elementum derecognized as of the date of deconsolidation, and $46 million of payments for non-core investments, net of cash received.

[0000866374-18-000007:mdna:132]
Cash used in financing activities was $188 million during fiscal year 2018. This was primarily the result of repurchases of ordinary shares in the amount of $180 million, and the repayment of $55 million of debt, partially offset by $65 million received from third party investors in fiscal year 2018 in exchange for an additional noncontrolling equity interest in Elementum prior to the deconsolidation described above.

[0000866374-18-000007:mdna:133]
Fiscal Year 2017

[0000866374-18-000007:mdna:134]
Cash provided by operating activities was $1.1 billion during fiscal year 2017. This resulted primarily from $320 million of net income for the period plus $674 million of non-cash charges such as depreciation, amortization, other impairment charges, provision for doubtful accounts and stock-based compensation expense that are included in the determination of net income. Depreciation expense was $432 million of those non-cash charges, which was relatively consistent with our normal annual run rate. We generated $157 million in cash as a result of changes in our operating assets and liabilities, driven primarily by a $268 million increase in accounts payable, offset by a $184 million increase in accounts receivable, including the change in sales of accounts receivable.

[0000866374-18-000007:mdna:135]
Cash used in investing activities was $0.7 billion during fiscal year 2017. This resulted primarily from $490 million of net capital expenditures for property and equipment to expand capability and capacity in support of our automotive and medical businesses and further investments in both automation and expanding technologies to support our innovation services. We also paid $189 million for the acquisition of four businesses, net of cash acquired, including $162 million, net of $18 million of cash acquired related to the acquisition of manufacturing facilities from Bose. Further, $60 million was paid for a non-controlling interest in a joint venture with RIB Software AG as our partner. Offsetting this was proceeds from various other investing activities of $64 million, most notably the receipt of $38 million for the sale of two non-strategic businesses.

[0000866374-18-000007:mdna:136]
Cash used in financing activities was $242 million during fiscal year 2017. This was primarily the result of repurchases of ordinary shares in the amount $350 million, and $31 million of cash paid to a third-party banking institution for certain assets that were financed by the third party banking institution on behalf of a customer, which is included in other financing activities, as further discussed in note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data". These cash outflows were partially offset by $171 million of net proceeds from bank borrowings and long-term debt, of which $130 million is the incremental amount borrowed extending the maturity date of one of our loan agreements from August 30, 2018 to November 30, 2021, and $107 million is the amount of proceeds from the €100 million term loan, discussed further in note 8 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data".

[0000866374-18-000007:mdna:137]
Fiscal Year 2016

[0000866374-18-000007:mdna:138]
Cash provided by operating activities was $1.1 billion during fiscal year 2016. This resulted primarily from $444 million of net income for the period plus $625 million of non-cash charges such as depreciation, amortization, other impairment charges, provision for doubtful accounts and stock-based compensation expense that are included in the determination of net income. Depreciation expense was $426 million of those non-cash charges, which was relatively consistent with our normal annual run rate. We generated $67 million in cash as a result of changes in our operating assets and liabilities, driven primarily by a $424 million reduction in accounts receivable, including the change in sales of accounts receivable, due to improved collection efforts and lower business levels, offset by a $365 million reduction in accounts payable.

[0000866374-18-000007:mdna:139]
Cash used in investing activities was $1.4 billion during fiscal year 2016. This resulted primarily from $917 million for the acquisition of eleven businesses completed during fiscal year 2016, including approximately $555 million, net of cash acquired, related to the acquisition of MCi, $241 million, net of cash acquired, related to the acquisition of NEXTracker, and approximately $68 million to acquire an optical transport facility from Alcatel-Lucent. We also paid $511 million in gross capital expenditures for property and equipment to support certain programs, offset by $14 million of proceeds from the sale of certain buildings and machinery and equipment. Other investing activities also includes $45 million paid for the purchase of

[0000866374-18-000007:mdna:140]
certain investments, offset by $54 million of proceeds from the sale of certain assets that were purchased on behalf of a customer and financed by a third party banking institution included in other investing activities.

[0000866374-18-000007:mdna:141]
Cash provided by financing activities was $250 million during fiscal year 2016, which was primarily the result of net proceeds from bank borrowings and long-term debt of $695 million mainly resulting from our new debt issuance discussed further in note 8 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data", and $61 million from the issuance of our shares for option exercises. These cash inflows were partially offset by $420 million of cash paid for the repurchase of our ordinary shares, and $75.8 million of cash paid to a third party banking institution for certain assets that were financed by the third party banking institution on behalf of a customer, which is included in other financing activities.

[0000866374-18-000007:mdna:142]
Free Cash Flow

[0000866374-18-000007:mdna:143]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repurchase company shares, fund acquisitions, make investments, repay debt obligations, and for certain other activities. Our free cash flow, which is calculated as cash provided by operations less net purchases of property and equipment, was $236 million, $660 million and $639 million for fiscal years 2018, 2017 and 2016, respectively.

[0000866374-18-000007:mdna:144]
Free cash flow is not a measure of liquidity under generally accepted accounting principles in the United States, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-18-000007:mdna:145]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 754 |  |  | $ | 1,150 |  |  | $ | 1,136 |  |
| Purchases of property and equipment | (562 | ) |  | (525 | ) |  | (511 | ) |
| Proceeds from the disposition of property and equipment | 44 |  |  | 36 |  |  | 14 |  |
| Free cash flow | $ | 236 |  |  | $ | 660 |  |  | $ | 639 |  |

[0000866374-18-000007:mdna:146]
Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Cash balances are generated and held in many locations throughout the world. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months.

[0000866374-18-000007:mdna:147]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volumes of customer orders.

[0000866374-18-000007:mdna:148]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. During fiscal years 2018, 2017 and 2016, we received approximately $9.4 billion, $8.6 billion and $7.0 billion, respectively from transfers of receivables under our ABS programs, and $1.5 billion, $1.3 billion and $2.3 billion, respectively from other sales of receivables. As of March 31, 2018 and 2017, the outstanding balance on receivables sold for cash was $1.3 billion and $1.2 billion, for each year respectively, under all our accounts receivable sales programs, which are removed from accounts receivable balances in our consolidated balance sheets.

[0000866374-18-000007:mdna:149]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth.

[0000866374-18-000007:mdna:150]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect

[0000866374-18-000007:mdna:151]
our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-18-000007:mdna:152]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In June 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $503 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature in March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6 million from September 30, 2017 through June 30, 2020 and approximately $13 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity.

[0000866374-18-000007:mdna:153]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 15, 2017. During fiscal year 2018, we paid $180 million to repurchase shares (under the current and prior repurchase plans) at an average price of $16.63 per share. As of March 31, 2018, shares in the aggregate amount of $410 million were available to be repurchased under the current plan.

[0000866374-18-000007:mdna:154]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-18-000007:mdna:155]
Bank borrowings and long-term debt are as follows:

[0000866374-18-000007:mdna:156]
|  | As of March 31, |
|  | 2018 |  | 2017 |
|  | (In millions) |
| 4.625% Notes due February 2020 | $ | 500 |  |  | $ | 500 |  |
| Term Loan, including current portion, due in installments through November 2021 | 688 |  |  | 700 |  |
| Term Loan, including current portion, due in installments through June 2022 | 484 |  |  | 503 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| 4.750% Notes due June 2025 | 596 |  |  | 596 |  |
| Other | 187 |  |  | 170 |  |
| Debt issuance costs | (14 | ) |  | (16 | ) |
|  | 2,941 |  |  | 2,952 |  |
| Current portion, net of debt issuance costs | (43 | ) |  | (62 | ) |
| Non-current portion | $ | 2,898 |  |  | $ | 2,891 |  |

[0000866374-18-000007:mdna:157]
Refer to the discussion in note 8 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details of our debt obligations.

[0000866374-18-000007:mdna:158]
We have purchase obligations that arise in the normal course of business, primarily consisting of binding purchase orders for inventory related items and capital expenditures. Additionally, we have leased certain of our property and equipment under capital lease commitments, and certain of our facilities and equipment under operating lease commitments.

[0000866374-18-000007:mdna:159]
Future payments due under our purchase obligations, debt including capital leases and related interest obligations and operating leases are as follows:

[0000866374-18-000007:mdna:160]
|  | Total |  | Less Than1 Year |  | 1 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In millions) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase obligations | $ | 3,478 |  |  | $ | 3,478 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Long-term debt and capital lease obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt | 2,954 |  |  | 44 |  |  | 659 |  |  | 1,652 |  |  | 599 |  |
| Capital leases | 14 |  |  | 5 |  |  | 9 |  |  | — |  |  | — |  |
| Interest on long-term debt obligations | 544 |  |  | 119 |  |  | 219 |  |  | 142 |  |  | 64 |  |
| Operating leases, net of subleases | 562 |  |  | 119 |  |  | 164 |  |  | 101 |  |  | 178 |  |
| Restructuring costs | 61 |  |  | 61 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 7,613 |  |  | $ | 3,826 |  |  | $ | 1,051 |  |  | $ | 1,895 |  |  | $ | 841 |  |

[0000866374-18-000007:mdna:161]
We have excluded $228 million of liabilities for unrecognized tax benefits from the contractual obligations table as we cannot make a reasonably reliable estimate of the periodic settlements with the respective taxing authorities. See note 14, "Income Taxes" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-18-000007:mdna:162]
Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-18-000007:mdna:163]
OFF-BALANCE SHEET ARRANGEMENTS

[0000866374-18-000007:mdna:164]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of March 31, 2018 and 2017, the fair value of our deferred purchase price receivable was approximately $445 million and $507 million, respectively. As of March 31, 2018 and 2017, the outstanding balance on receivables sold for cash was $1.3 billion and $1.2 billion for each period respectively, under all our accounts receivable sales programs, which were removed from accounts receivable balances in our consolidated balance sheets. For further information, see note 11 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data".

[0000866374-18-000007:mdna:165]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-18-000007:mdna:166]
Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for recent accounting pronouncements.

[0000866374-18-000007:mdna:167]
48
