# FLEX notes — 0000866374-18-000007


## flex:BasisOfPresentationAndPrinciplesOfConsolidationPolicyTextBlock

[0000866374-18-000007:notes:1]
Basis of Presentation and Principles of Consolidation

[0000866374-18-000007:notes:2]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of March 31, 2018, the noncontrolling interest was not material as a result of the deconsolidation of one of our subsidiaries (refer to note 6 for additional information). In prior years, the noncontrolling interest was included on the consolidated balance sheets as a component of total shareholders' equity. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for any period presented, and is classified as a component of interest and other, net, in the consolidated statements of operations.

[0000866374-18-000007:notes:3]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the consolidated statements of oper


## flex:InterestAndOtherNetTextBlock

[0000866374-18-000007:notes:4]
INTEREST AND OTHER, NET

[0000866374-18-000007:notes:5]
For the fiscal years ended March 31, 2018, 2017 and 2016, the Company recognized interest income of $18.8 million, $12.1 million and $12.3 million.

[0000866374-18-000007:notes:6]
For the fiscal years ended March 31, 2018, 2017 and 2016, the Company recognized interest expense of $123.1 million, $108.0 million and $98.0 million, respectively, on its debt obligations outstanding during the period.

[0000866374-18-000007:notes:7]
For the fiscal years ended March 31, 2018, 2017 and 2016, the Company recognized gains on foreign exchange transactions of $15.2 million, $16.5 million and $24.4 million, respectively.

[0000866374-18-000007:notes:8]
For the fiscal years ended March 31, 2018, 2017 and 2016, the Company recognized $25.0 million, $15.3 million and $11.0 million of expense related to its ABS and AR Sales Programs.


## flex:ScheduleOfShareBonusAwardsWithMarketConditionsTableTextBlock

[0000866374-18-000007:notes:9]
Of the 13.9 million unvested share bonus awards outstanding under the 2017 and 2010 Plans as of the fiscal year ended 2018, approximately 2.0 million of unvested share bonus awards represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-18-000007:notes:10]
|  |  | Targetednumber ofawards as ofMarch 31, 2018(in shares) |  |  |  | Range of sharesthat may be issued (1) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |
|  |  |  | Assessment dates |
| Year of grant |  |  | Minimum |  | Maximum |  |
| Fiscal 2018 |  | 623,620 |  |  | $ | 20.25 |  |  | — |  |  | 1,247,240 |  |  | June 2020 |
| Fiscal 2017 |  | 677,523 |  |  | $ | 17.57 |  |  | — |  |  | 1,355,046 |  |  | June 2019 |
| Fiscal 2016 |  | 648,929 |  |  | $ | 14.96 |  |  | — |  |  | 1,297,858 |  |  | June 2018 |
| Totals |  | 1,950,072 |  |  |  |  |  | — |  |  | 3,900,144 |  |  |  |

[0000866374-18-000007:notes:11]
(1)       Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against the Standard and Poor's ("S&P") 500 Composite Index.


## flex:ScheduleOfTaxLossesAndOtherCarryforwardsTableTextBlock

[0000866374-18-000007:notes:12]
These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-18-000007:notes:13]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
|  | (In thousands) |
| 2019 - 2024 | $ | 513,828 |  |
| 2025 - 2030 | 614,307 |  |
| 2031 and post | 178,484 |  |
| Indefinite | 852,455 |  |
|  | $ | 2,159,074 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-18-000007:notes:14]
SUMMARY OF ACCOUNTING POLICIES

[0000866374-18-000007:notes:15]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the consolidated statements of operations.

[0000866374-18-000007:notes:16]
Use of Estimates

[0000866374-18-000007:notes:17]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; asset impairments; fair values of financial instruments including investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; fair values of assets obtained and liabilities assumed in business combinations and the fair values of stock options and share bonus awards granted under the Company's stock-based compensation plans. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-18-000007:notes:18]
Translation of Foreign Currencies

[0000866374-18-000007:notes:19]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive loss, a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for any of the periods presented, and have been classified as a component of interest and other, net in the consolidated statements of operations.

[0000866374-18-000007:notes:20]
Revenue Recognition

[0000866374-18-000007:notes:21]
The Company recognizes manufacturing revenue when it ships goods or the goods are received by its customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then the Company recognizes the related revenues at the time when such requirements are completed, and the obligations are fulfilled. Some of the Company's customer contracts allow the recovery of certain costs related to manufacturing services that are over and above the prices charged for the related products. Also, certain customer contracts may contain certain commitments and obligations that may result in additional expenses or decreases in revenue. Refer to note 3 "Revenue Recognition" for further details.

[0000866374-18-000007:notes:22]
Concentration of Credit Risk

[0000866374-18-000007:notes:23]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, cash and cash equivalents, and derivative instruments.

[0000866374-18-000007:notes:24]
Customer Credit Risk

[0000866374-18-000007:notes:25]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-18-000007:notes:26]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison"), filed a petition for reorganization under bankruptcy law. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory previously designated for SunEdison on hand at the end of the second quarter of fiscal year 2017 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market during fiscal year 2017. In addition, the Company recognized a $16.0 million impairment charge for solar module equipment and incurred $16.9 million of incremental costs primarily related to negative margin sales and other associated solar panel direct costs. The total charge for fiscal year 2017 of $92.9 million is included in cost of sales.

[0000866374-18-000007:notes:27]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2018, 2017 and 2016:

[0000866374-18-000007:notes:28]
|  | Balance atBeginningof Year |  | Charged toCosts andExpenses |  | Deductions/Write-Offs |  | Balance atEnd ofYear |
|  | (In thousands) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2016 | $ | 4,534 |  |  | $ | 72,295 |  |  | $ | (12,221 | ) |  | $ | 64,608 |  |
| Year ended March 31, 2017 | $ | 64,608 |  |  | $ | (184 | ) |  | $ | (7,122 | ) |  | $ | 57,302 |  |
| Year ended March 31, 2018 | $ | 57,302 |  |  | $ | 8,225 |  |  | $ | (5,476 | ) |  | $ | 60,051 |  |

[0000866374-18-000007:notes:29]
For the fiscal year ended March 31, 2016, the Company recognized a bad debt charge of $61.0 million associated with its outstanding SunEdison receivables as explained above, and another charge of $10.5 million relating to a separate distressed customer which was also written-off during the year.

[0000866374-18-000007:notes:30]
No customer accounted for greater than 10% of the Company's net sales in fiscal years 2018 and 2017. One customer (including net sales from its parent company) within the Company's CTG segment, accounted for approximately 11% of the Company's net sales in fiscal year 2016, and approximately 17% of the Company's total accounts receivable balances in fiscal years 2018 and 2017, respectively. Another customer included in the Company's CEC segment, accounted for approximately 11% of the Company's total accounts receivable balance in fiscal year 2016.

[0000866374-18-000007:notes:31]
The Company's ten largest customers accounted for approximately 41%, 43% and 46%, of its net sales in fiscal years 2018, 2017 and 2016, respectively.

[0000866374-18-000007:notes:32]
Derivative Instruments

[0000866374-18-000007:notes:33]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 9.

[0000866374-18-000007:notes:34]
Cash and Cash Equivalents

[0000866374-18-000007:notes:35]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-18-000007:notes:36]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-18-000007:notes:37]
Cash and cash equivalents consisted of the following:

[0000866374-18-000007:notes:38]
|  | As of March 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| Cash and bank balances | $ | 1,019,802 |  |  | $ | 763,834 |  |
| Money market funds and time deposits | 452,622 |  |  | 1,066,841 |  |
|  | $ | 1,472,424 |  |  | $ | 1,830,675 |  |

[0000866374-18-000007:notes:39]
Inventories

[0000866374-18-000007:notes:40]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or net realizable value write-downs, were as follows:

[0000866374-18-000007:notes:41]
|  | As of March 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| Raw materials | $ | 2,760,410 |  |  | $ | 2,537,623 |  |
| Work-in-progress | 450,569 |  |  | 279,493 |  |
| Finished goods | 588,850 |  |  | 579,346 |  |
|  | $ | 3,799,829 |  |  | $ | 3,396,462 |  |

[0000866374-18-000007:notes:42]
Property and Equipment, Net

[0000866374-18-000007:notes:43]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are amortized over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment was comprised of the following:

[0000866374-18-000007:notes:44]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2018 |  | 2017 |
|  |  |  | (In thousands) |
| Machinery and equipment | 3 - 10 |  | $ | 3,004,707 |  |  | $ | 3,233,392 |  |
| Buildings | 30 |  | 1,154,881 |  |  | 1,237,739 |  |
| Leasehold improvements | up to 30 |  | 414,917 |  |  | 395,663 |  |
| Furniture, fixtures, computer equipment and software | 3 - 7 |  | 482,248 |  |  | 502,223 |  |
| Land | — |  | 152,992 |  |  | 145,663 |  |
| Construction-in-progress | — |  | 287,724 |  |  | 212,326 |  |
|  |  |  | 5,497,469 |  |  | 5,727,006 |  |
| Accumulated depreciation and amortization |  |  | (3,257,963 | ) |  | (3,409,980 | ) |
| Property and equipment, net |  |  | $ | 2,239,506 |  |  | $ | 2,317,026 |  |

[0000866374-18-000007:notes:45]
Total depreciation expense associated with property and equipment amounted to approximately $434.4 million, $432.2 million and $425.7 million in fiscal years 2018, 2017 and 2016, respectively. Property and equipment excludes assets held for sale as a result of the Company's agreement with a certain Chinese manufacturing company to sell its China-based Multek operations, as discussed in note 18.

[0000866374-18-000007:notes:46]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-18-000007:notes:47]
Deferred Income Taxes

[0000866374-18-000007:notes:48]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-18-000007:notes:49]
Accounting for Business and Asset Acquisitions

[0000866374-18-000007:notes:50]
The Company has actively pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0000866374-18-000007:notes:51]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-18-000007:notes:52]
Goodwill

[0000866374-18-000007:notes:53]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. If the recorded value of the assets, including goodwill, and liabilities ("net book value") of any reporting unit exceeds its fair value, an impairment loss may be required to be recognized. Further, to the extent the net book value of the Company as a whole is greater than its fair value in the aggregate, all, or a significant portion of its goodwill may be considered impaired.

[0000866374-18-000007:notes:54]
The Company has four reporting units, which correspond to its four reportable operating segments: HRS, CTG, IEI and CEC. The Company concluded that there was no change to its reporting units in fiscal year 2018 and performed its goodwill impairment assessment on January 1, 2018. The Company bypassed the qualitative "Step Zero" assessment and performed a quantitative assessment of its goodwill and determined that no impairment existed as of the date of the impairment test because the fair value of each reporting unit exceeded its carrying value.

[0000866374-18-000007:notes:55]
The following table summarizes the activity in the Company's goodwill during fiscal years 2018 and 2017 (in thousands):

[0000866374-18-000007:notes:56]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Balance, as of March 31, 2016 | 439,336 |  |  | 68,234 |  |  | 322,803 |  |  | 111,693 |  |  | 942,066 |  |
| Additions (1) | — |  |  | 42,989 |  |  | 17,544 |  |  | 3,309 |  |  | 63,842 |  |
| Divestitures (2) | (1,787 | ) |  | — |  |  | (2,640 | ) |  | — |  |  | (4,427 | ) |
| Purchase accounting adjustments (3) | 794 |  |  | — |  |  | — |  |  | — |  |  | 794 |  |
| Foreign currency translation adjustments (4) | (17,408 | ) |  | — |  |  | — |  |  | — |  |  | (17,408 | ) |
| Balance, as of March 31, 2017 | $ | 420,935 |  |  | $ | 111,223 |  |  | $ | 337,707 |  |  | $ | 115,002 |  |  | $ | 984,867 |  |
| Additions (1) | 75,280 |  |  | — |  |  | — |  |  | 9,744 |  |  | 85,024 |  |
| Divestitures (2) | — |  |  | (3,475 | ) |  | — |  |  | — |  |  | (3,475 | ) |
| Purchase accounting adjustments (3) | — |  |  | — |  |  | — |  |  | (14 | ) |  | (14 | ) |
| Foreign currency translation adjustments (4) | 54,768 |  |  | — |  |  | — |  |  | — |  |  | 54,768 |  |
| Balance, as of March 31, 2018 | $ | 550,983 |  |  | $ | 107,748 |  |  | $ | 337,707 |  |  | $ | 124,732 |  |  | $ | 1,121,170 |  |

[0000866374-18-000007:notes:57]
_______________________________________________________________________________

[0000866374-18-000007:notes:58]
| (1) | The goodwill generated from the Company's business combinations completed during the fiscal years 2018 and 2017 are primarily related to value placed on the employee workforce, service offerings and capabilities and expected synergies. The goodwill is not deductible for income tax purposes. Refer to the discussion of the Company's business acquisitions in note 18. |

[0000866374-18-000007:notes:59]
| (2) | During the fiscal year ended March 31, 2018, the Company disposed of Wink Labs Inc. ("Wink"), a business within the CTG segment, and recorded an aggregate reduction of goodwill of $3.5 million, which is included in the gain on sale recorded in other charges, net on the consolidated statement of operations. During the fiscal year ended March 31, 2017, the Company disposed of two non-strategic businesses within the IEI and HRS segments, and recorded an aggregate reduction of goodwill of $4.4 million, which is included in the loss on sale recorded in other charges, net on the consolidated statement of operations. |

[0000866374-18-000007:notes:60]
| (3) | Includes adjustments based on management's estimates resulting from its review and finalization of the valuation of assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition. These adjustments were not individually, nor in the aggregate, significant to the Company. |

[0000866374-18-000007:notes:61]
| (4) | During the fiscal years ended March 31, 2018 and 2017, the Company recorded $54.8 million and $17.4 million, respectively, of foreign currency translation adjustments primarily related to the goodwill associated with the acquisition of AGM Automotive ("AGM") in fiscal year 2018 and Mirror Controls International ("MCi") in fiscal year 2016, as the U.S. Dollar fluctuated against foreign currencies. |

[0000866374-18-000007:notes:62]
Other Intangible Assets

[0000866374-18-000007:notes:63]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2018 and concluded that such amounts continued to be recoverable.

[0000866374-18-000007:notes:64]
Intangible assets are comprised of customer-related intangible assets that include contractual agreements and customer relationships; and licenses and other intangible assets, that are primarily comprised of licenses and also include patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight-line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability. The components of acquired intangible assets are as follows:

[0000866374-18-000007:notes:65]
|  | As of March 31, 2018 |  | As of March 31, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 306,943 |  |  | $ | (79,051 | ) |  | $ | 227,892 |  |  | $ | 260,704 |  |  | $ | (105,912 | ) |  | $ | 154,792 |  |
| Licenses and other intangibles | 304,007 |  |  | (107,466 | ) |  | 196,541 |  |  | 283,897 |  |  | (76,508 | ) |  | 207,389 |  |
| Total | $ | 610,950 |  |  | $ | (186,517 | ) |  | $ | 424,433 |  |  | $ | 544,601 |  |  | $ | (182,420 | ) |  | $ | 362,181 |  |

[0000866374-18-000007:notes:66]
The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2018, the gross carrying amounts of fully amortized intangible assets totaled $38.3 million. During fiscal year 2018, the gross carrying amount of intangible assets increased primarily in connection with the Company's acquisitions during the year. Total intangible asset amortization expense recognized in operations during fiscal years 2018, 2017 and 2016 was $78.6 million, $81.4 million and $66.0 million, respectively. As of March 31, 2018, the weighted-average remaining useful lives of the Company's intangible assets were approximately 7.1 years for customer-related intangibles and approximately 6.1 years for licenses and other intangible assets. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-18-000007:notes:67]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2019 | $ | 75,319 |  |
| 2020 | 68,981 |  |
| 2021 | 64,440 |  |
| 2022 | 55,301 |  |
| 2023 | 46,762 |  |
| Thereafter | 113,630 |  |
| Total amortization expense | $ | 424,433 |  |

[0000866374-18-000007:notes:68]
We own or license various United States and foreign patents relating to a variety of technologies. For certain of our proprietary processes, inventions, and works of authorship, we rely on trade secret or copyright protection. We also maintain trademark rights (including registrations) for our corporate name and several other trademarks and service marks that we use in our business in the United States and other countries throughout the world. We have implemented appropriate policies and procedures (including both technological means and training programs for our employees) to identify and protect our intellectual property, as well as that of our customers and suppliers. As of March 31, 2018 and 2017, the carrying value of our intellectual property was not material.

[0000866374-18-000007:notes:69]
Derivative Instruments and Hedging Activities

[0000866374-18-000007:notes:70]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Additional information is included in note 9.

[0000866374-18-000007:notes:71]
Other Current Assets

[0000866374-18-000007:notes:72]
Other current assets include approximately $445.4 million and $506.5 million as of March 31, 2018 and 2017, respectively for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 11 for additional information. Further, the Company recorded in other current assets, approximately $321.1 million of assets, primarily property and equipment and accounts receivable, classified as held for sale. See note 18 for additional information.

[0000866374-18-000007:notes:73]
Investments

[0000866374-18-000007:notes:74]
During the first quarter of fiscal year 2018, the Company sold Wink to an unrelated third-party venture backed company in exchange for consideration fair valued at $59.0 million. This estimated consideration was based on the value of the acquirer as of the most recent third-party funding of which the Company participated. The Company recognized a non-cash gain on sale of $38.7 million, which is recorded in other charges (income), net on the condensed consolidated statement of operations in the year ended March 31, 2018. As of March 31, 2018, the total investment, including working capital advances, of $76.5 million is accounted for as a cost method investment, and is included in other assets on the consolidated balance sheet.

[0000866374-18-000007:notes:75]
During the second quarter of fiscal year 2018, the Company deconsolidated one of its majority owned subsidiaries, following the amendments of certain agreements that resulted in joint control of the board of directors between the Company and other non-controlling interest holders. As of March 31, 2018, this subsidiary is accounted for as a cost method investment of approximately $124.6 million and is included in other assets on the consolidated balance sheet. See note 6 for additional information on the deconsolidation.

[0000866374-18-000007:notes:76]
The Company has certain equity investments in, and notes receivable from, non-publicly traded companies which are included within other assets. The equity method of accounting is used for investments in common stock or in-substance common stock when the Company has the ability to significantly influence the operating decisions of the issuer; otherwise the cost method is used. Non-majority-owned investments in corporations are accounted for using the equity method when the Company has a voting percentage equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments, include, but are not limited to a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, primarily comparable company multiples and discounted cash flow projections.

[0000866374-18-000007:notes:77]
As of March 31, 2018 and 2017, the Company's equity investments in non-majority owned companies totaled $411.1 million and $200.1 million, respectively. The equity in the earnings or losses of the Company's equity method investments was not material to the consolidated results of operations for any period presented and is included in interest and other, net.

[0000866374-18-000007:notes:78]
During fiscal year 2017, the Company formed a joint venture with RIB Software AG, a provider of technology for the construction industry. This joint venture will offer a fully integrated enterprise software platform for building and housing projects. The Company contributed $60.0 million for a non-controlling interest in this joint venture. This contribution, net of the Company's equity in losses, which is immaterial, is included in other assets on the consolidated balance sheet. The cash outflows to pay for this investment have been included in cash flows from other investing activities during the fiscal year ended March 31, 2017.

[0000866374-18-000007:notes:79]
Other Current Liabilities

[0000866374-18-000007:notes:80]
Other current liabilities include customer working capital advances of $153.6 million and $231.3 million, customer-related accruals of $439.0 million and $501.9 million, and deferred revenue of $329.0 million and $280.7 million as of March 31, 2018 and 2017, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.

[0000866374-18-000007:notes:81]
Restructuring Charges

[0000866374-18-000007:notes:82]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and rationalize administrative functions. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-18-000007:notes:83]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed restructuring plans. See note 15 for additional information regarding restructuring charges.

[0000866374-18-000007:notes:84]
Recently Adopted Accounting Pronouncements

[0000866374-18-000007:notes:85]
In July 2015, the Financial Accounting standards Board ("FASB") issued Accounting Standard Updates ("ASU") No. 2015-11 "Inventory (Topic 330): Simplifying the Measurement of Inventory", to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. The Company adopted the guidance, prospectively, effective April 1, 2017 and it did not have a material impact on its consolidated financial statements.

[0000866374-18-000007:notes:86]
In October 2016, the FASB issued ASU 2016-16 "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory", intended to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early adoption permitted in the first interim period of fiscal year 2018. The Company adopted the guidance, on a modified retrospective basis, effective April 1, 2017 and it did not have a material impact on its consolidated financial statements.

[0000866374-18-000007:notes:87]
In October 2016, the FASB issued ASU 2016-17 "Consolidation (Topic 810): Interests Held through Related Parties That Are under Common Control" to amend the consolidation guidance on how a reporting entity that is the single decision maker of a variable interest entity ("VIE") should treat indirect interests in the entity held through related parties that are under common control with the reporting entity when determining whether it is the primary beneficiary of that VIE. This guidance requires that the amendments be applied on a retrospective or modified retrospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2018, with early adoption permitted. The Company adopted the guidance, retrospectively, effective April 1, 2017 and it did not have a material impact on its consolidated financial statements.

[0000866374-18-000007:notes:88]
Recently Issued Accounting Pronouncements

[0000866374-18-000007:notes:89]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-18-000007:notes:90]
In January 2017, the FASB issued ASU 2017-04 "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment" to simplify the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. This guidance requires that the change be applied on a prospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2021, with early application permitted. The Company is currently assessing the impact of the new guidance and the timing of adoption.

[0000866374-18-000007:notes:91]
In January 2017, the FASB issued ASU 2017-01 “Business Combinations (Topic 805): Clarifying the Definition of a Business” to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses.  This guidance is effective for Flex beginning in the first quarter of fiscal year 2019, with early adoption permitted, and it should be applied on a prospective basis starting on date of adoption. The Company plans to adopt the guidance effective the first quarter of fiscal year 2019.

[0000866374-18-000007:notes:92]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force)." The ASU is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 is consistent with our current cash flow classification. However, cash receipts on the deferred purchase price as described in note 11 will be classified as cash flow from investing activities instead of the Company's current presentation as cash flows from operations. The Company intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2019 and retrospectively report cash flows from operating and investing activities for all periods presented. While the Company is still quantifying the impact of adoption of this standard, it does expect the standard to result in a material increase in cash flows from investing activities and corresponding reduction in cash flows from operating activities for all periods presented.

[0000866374-18-000007:notes:93]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. The Company intends to adopt the new lease guidance beginning when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach. Upon initial evaluation, the Company believes the new guidance will have a material impact on its consolidated balance sheets when adopted.

[0000866374-18-000007:notes:94]
In January 2016, the FASB issued ASU 2016-01 "Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This guidance generally requires equity investments, except those accounted for under the equity method of accounting or those that result in consolidation of the investee, to be measured at fair value with changes in fair value recognized in net income. This guidance also requires the separate presentation of financial assets and financial liabilities by measurement category and form of financial asset on the balance sheet or in the accompanying notes to the financial statements. This guidance is effective for interim and annual reporting periods beginning after December 15, 2017; early adoption is permitted, and the guidance must be applied prospectively to equity investments that exist as of the adoption date. The Company will adopt this guidance on April 1, 2018 when effective. The adoption of this guidance is not expected to have any material impact on the Company's financial position, results of operations or cash flows.

[0000866374-18-000007:notes:95]
In May 2014, the FASB issued ASU 2014-09 "Revenue from Contracts with Customers (Topic 606)" which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. The guidance is effective for the Company beginning in the first quarter of fiscal year 2019.

[0000866374-18-000007:notes:96]
The adoption of the new standard will change the timing of revenue recognition for a portion of Flex’s business. Under the new standard, revenue for certain of Flex's manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery).

[0000866374-18-000007:notes:97]
The new guidance allows for two transition methods in application: retrospective to each prior reporting period presented (full retrospective method), or retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). The Company will adopt the standard on April 1, 2018 using the modified retrospective approach. Under this approach, prior financial statements presented will not be restated.

[0000866374-18-000007:notes:98]
Upon adoption of the standard, the Company estimates an adjustment to its beginning accumulated deficit in the range of $30 million to $70 million as of April 1, 2018. In addition, the Company estimates reduction in finished good and work-in-progress inventories in the range of $300 million to $500 million in aggregate. The Company estimates a corresponding increase to unbilled receivables of approximately $330 million to $550 million. The Company is continuing to assess the impact of adopting the new standard on its consolidated financial statements. The Company is also continuing to adjust its accounting policies, operational and financial reporting processes, systems capabilities and relevant internal controls.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-18-000007:notes:99]
BUSINESS AND ASSET ACQUISITIONS & DIVESTITURES

[0000866374-18-000007:notes:100]
In March 2018, the Company entered into an agreement with a certain Chinese manufacturing company, to divest its China-based Multek operations, for proceeds of approximately $273 million, net of cash.  The planned divestiture does not qualify as discontinued operations, but certain Multek assets and liabilities meet the definition of held for sale as of March 31, 2018. Accordingly, approximately $321.1 million of assets, primarily property and equipment and accounts receivable, were classified as held for sale and included in other current assets, and approximately $144.1 million of liabilities, primarily accounts payables, were classified as held for sale and included in other current liabilities as of March 31, 2018 in the consolidated balance sheet. The Company expects to recognize an immaterial gain on the divestiture upon closing which is expected in the second quarter of fiscal year 2019, subject to customary closing conditions, including regulatory approvals.

[0000866374-18-000007:notes:101]
The business and asset acquisitions described below were accounted for using the purchase method of accounting, and accordingly, the fair value of the net assets acquired and the results of the acquired businesses were included in the Company's consolidated financial statements from the acquisition dates forward. The Company has not finalized the allocation of the consideration for certain of its recently completed acquisitions and completes these allocations in less than one year of the respective acquisition dates.

[0000866374-18-000007:notes:102]
Fiscal 2018 Business and asset acquisitions

[0000866374-18-000007:notes:103]
During the fiscal year ended March 31, 2018, the Company completed two acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operation and cash flows of the Company.

[0000866374-18-000007:notes:104]
In April 2017, the Company completed its acquisition of AGM, which expanded its capabilities in the automotive market, and is included within the HRS segment. The Company paid $213.7 million, net of cash acquired.

[0000866374-18-000007:notes:105]
Additionally, in September 2017, the Company acquired a power modules business, which expanded its capabilities within the CEC segment. The Company paid $54.7 million, net of cash acquired.

[0000866374-18-000007:notes:106]
A summary of the allocation of the total purchase consideration is presented as follows (in thousands):

[0000866374-18-000007:notes:107]
|  |  | Purchase Consideration |  | Net Tangible Assets Acquired |  | Purchased Intangible Assets |  | Goodwill |
| AGM |  | $ | 213,718 |  |  | $ | 56,438 |  |  | $ | 82,000 |  |  | $ | 75,280 |  |
| Power Modules Business |  | 54,659 |  |  | 11,615 |  |  | 33,300 |  |  | 9,744 |  |

[0000866374-18-000007:notes:108]
The intangibles of AGM comprised solely of customer relationships, will amortize over a weighted-average estimated useful life of 10 years. The intangibles of the power modules business, comprised of $16.0 million of customer relationships and $17.3 million of licenses and other intangibles, will amortize over a weighted-average estimated useful life of 10 years and 8 years, respectively.

[0000866374-18-000007:notes:109]
The results of operations of the acquisitions were included in the Company’s consolidated financial results beginning on the respective acquisition dates, and the total amount of net income and revenue, collectively, were immaterial to the Company's consolidated financial results for the fiscal year ended March 31, 2018. Pro-forma results of operations for the acquisitions completed in fiscal year 2018 have not been presented because the effects, individually and in aggregate, were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-18-000007:notes:110]
Fiscal 2017 Business and asset acquisitions

[0000866374-18-000007:notes:111]
During the fiscal year ended March 31, 2017, the Company completed four acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. Most notable is the Company’s acquisition of two manufacturing and development facilities from Bose Corporation (“Bose”), a global leader in audio systems. The acquisition expanded the Company’s capabilities in the audio market and is included in the CTG segment. The other acquired businesses strengthen the Company's capabilities in the communications market and energy market within the CEC and IEI segments, respectively. At the acquisition dates, the Company paid a total of $189.1 million, net of cash acquired, of which $161.7 million, net of $18.0 million of cash acquired is related to the Bose acquisition which is included in cash from investing activities in the consolidated statements of cash flows. The Company acquired primarily $73.1 million of inventory, $60.8 million of property and equipment, and recorded goodwill of $63.8 million and intangible assets of $47.4 million principally related to the Bose acquisition. The intangibles will amortize over a weighted-average estimated useful life of 6.5 years. In connection with these acquisitions, the Company assumed $63.3 million in other liabilities including additional consideration of $28.0 million which was paid in the fourth quarter of fiscal year 2017 and included in other financing activities in the consolidated statements of cash flows. Further, the equity incentive plan of one of the acquirees was assumed as part of the acquisition.

[0000866374-18-000007:notes:112]
The results of operations for each of the acquisitions completed in fiscal year 2017, including the Bose acquisition, were included in the Company’s consolidated financial results beginning on the date of each acquisition, and the total amount of net income and revenue of the acquisitions, collectively, were immaterial to the Company's consolidated financial results for the fiscal year ended March 31, 2017. Pro-forma results of operations for the acquisitions completed in fiscal year 2017 were not presented because the effects, individually and in the aggregate, were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-18-000007:notes:113]
Fiscal 2017 Divestitures

[0000866374-18-000007:notes:114]
During the fiscal year ended March 31, 2017, the Company disposed of two non-strategic businesses within the HRS and IEI segments. The Company received $30.7 million of proceeds, net of an immaterial amount of cash held in one of the divested businesses. The property and equipment and various other assets sold, and liabilities transferred were not material to the Company's consolidated financial results. The loss on disposition was not material to the Company’s consolidated financial results, and was included in other charges, net in the condensed consolidated statements of operations for the fiscal year 2017.

[0000866374-18-000007:notes:115]
Fiscal 2016 Business acquisitions

[0000866374-18-000007:notes:116]
Acquisition of Mirror Controls International

[0000866374-18-000007:notes:117]
In June 2015, the Company completed its acquisition of 100% of the outstanding share capital of MCi, and paid approximately $555.2 million, net of $27.7 million of cash acquired. This acquisition expanded the Company's capabilities in the automotive market, and was included in the HRS segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed was allocated to goodwill.

[0000866374-18-000007:notes:118]
The intangible assets of $236.8 million is comprised of customer relationships of $75.5 million and licenses and other intangible assets of $161.3 million. Customer relationships and licenses and other intangibles are each amortized over a weighted-average estimated useful life of 10 years. In addition to net working capital, the Company acquired $38.8 million of machinery and equipment and assumed $61.5 million of other liabilities primarily comprised of deferred tax liabilities. The Company incurred $6.6 million in acquisition-related costs related to the acquisition of MCi during fiscal year 2016.

[0000866374-18-000007:notes:119]
Acquisition of a facility from Alcatel-Lucent

[0000866374-18-000007:notes:120]
In July 2015, the Company acquired an optical transport facility from Alcatel-Lucent for approximately $67.5 million, which expanded its capabilities in the telecom market and was included in the CEC segment. The Company acquired primarily $55.1 million of inventory and $10.0 million of property and equipment primarily comprised of a building and land, and recorded goodwill and intangible assets for a customer relationship of $3.6 million and $2.1 million, respectively, and assumed $3.3 million in other net liabilities in connection with this acquisition. The customer relationship intangible will amortize over a weighted-average estimated useful life of 5 years.

[0000866374-18-000007:notes:121]
Acquisition of NEXTracker

[0000866374-18-000007:notes:122]
In September 2015, the Company acquired 100% of the outstanding share capital of NEXTracker, a provider of smart solar tracking solutions. The initial cash consideration was approximately $240.8 million, net of $13.2 million of cash acquired, with an additional $81.0 million of estimated potential contingent consideration, for a total purchase consideration of $321.8 million. At the date of the acquisition, the maximum possible contingent consideration under the agreement was $97.2 million based upon the achievement of future revenue performance targets. The Company also acquired NEXTracker’s equity incentive plan. The financial results of NEXTracker were included in the IEI segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed was allocated to goodwill.

[0000866374-18-000007:notes:123]
The intangible assets of $108.7 million is comprised of customer-related intangibles of $47.3 million and licenses and other intangible assets of $61.4 million. Customer-related intangibles are amortized over a weighted-average estimated useful life of 4 years while licenses and other intangibles are amortized over a weighted-average estimated useful life of 6 years.

[0000866374-18-000007:notes:124]
Other business acquisitions

[0000866374-18-000007:notes:125]
Additionally, during fiscal year 2016, the Company completed eight acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. Four of the acquired businesses expanded the Company’s capabilities in the medical devices market, particularly precision plastics and molding within the HRS segment, two of them strengthened capabilities in the consumer electronics market within the CTG segment, one strengthened the capabilities in the communications market within the CEC segment, and the last one strengthened capabilities in the household industrial and lifestyle market within the IEI segment. The Company paid $53.3 million, net of $3.7 million of cash held by the targets. The Company acquired $14.4 million of property and equipment, assumed liabilities of $17.7 million and recorded goodwill and intangibles of $57.4 million. These intangibles will amortize over a weighted-average estimated useful life of 4 years.

[0000866374-18-000007:notes:126]
The results of operations for all of the acquisitions completed in fiscal year 2016 were included in the Company’s consolidated financial results beginning on the date of each acquisition.  The total amount of net income for all of the acquisitions completed in fiscal year 2016, collectively, was $41.4 million. The total amount of revenue of these acquisitions, collectively, was not material to the Company’s consolidated financial results for the fiscal year 2016.

[0000866374-18-000007:notes:127]
On a pro-forma basis, and assuming the fiscal year 2016 acquisitions occurred on the first day of the prior period, or April 1, 2014, the Company's net income would have been estimated to be $410.1 million for the fiscal year 2016. The estimated pro-forma net income did not include the $43.0 million tax benefit for the release of the valuation allowance on deferred tax assets primarily relating to the NEXTracker acquisition, recognized in fiscal year 2016, to promote comparability. Pro-forma revenue for the acquisitions in fiscal year 2016 were not presented because the effect, collectively, was not material to the Company’s consolidated revenues for fiscal year 2016.

[0000866374-18-000007:notes:128]
The Company continues to evaluate certain assets and liabilities related to its acquisition of the power module business completed during fiscal year 2018. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Changes to amounts recorded as assets or liabilities, as a result of such additional information, may result in a corresponding adjustment to goodwill.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-18-000007:notes:129]
SUPPLEMENTAL CASH FLOW DISCLOSURES

[0000866374-18-000007:notes:130]
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-18-000007:notes:131]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 152,750 |  |  | $ | 127,346 |  |  | $ | 114,578 |  |
| Income taxes | 91,846 |  |  | 86,651 |  |  | 105,453 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 128,044 |  |  | $ | 84,375 |  |  | $ | 93,310 |  |
| Customer-related third party banking institution equipment financing net settlement | — |  |  | 90,576 |  |  | — |  |
| Non-cash investment in Elementum (Note 6) | 132,679 |  |  | — |  |  | — |  |
| Non-cash proceeds from sales of Wink (Note 2) | 59,000 |  |  | — |  |  | — |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-18-000007:notes:132]
COMMITMENTS AND CONTINGENCIES

[0000866374-18-000007:notes:133]
Commitments

[0000866374-18-000007:notes:134]
As of March 31, 2018 and 2017, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under capital leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2035 and require the following minimum lease payments:

[0000866374-18-000007:notes:135]
| Fiscal Year Ending March 31, | Operating Lease |
|  | (In thousands) |
| 2019 | $ | 119,008 |  |
| 2020 | 97,476 |  |
| 2021 | 66,713 |  |
| 2022 | 54,497 |  |
| 2023 | 46,861 |  |
| Thereafter | 178,089 |  |
| Total minimum lease payments | $ | 562,644 |  |

[0000866374-18-000007:notes:136]
Total rent expense amounted to $140.3 million, $124.7 million and $124.2 million in fiscal years 2018, 2017 and 2016, respectively.

[0000866374-18-000007:notes:137]
Litigation and other legal matters

[0000866374-18-000007:notes:138]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The Company does not believe that the amounts accrued are material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-18-000007:notes:139]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conduct it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-18-000007:notes:140]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable our use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g. base price) for any royalty amounts owed are audited by licensors and may be challenged.  Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing a patent license agreement, and requesting information relating to royalties for products that it assembles for a customer in China. If any of these inquiries result in a claim, the Company intends to contest and defend against any such claim vigorously. If a claim is asserted and the Company is unsuccessful in its defense, a material loss is reasonably possible. The Company cannot predict or estimate an amount or reasonable range of outcomes with respect to the matter.

[0000866374-18-000007:notes:141]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. The deadline for applications for appointment as lead plaintiff is July 9, 2018.

[0000866374-18-000007:notes:142]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-18-000007:notes:143]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 346 million Brazilian reals (approximately USD $104 million based on the exchange rate as of March 31, 2018). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-18-000007:notes:144]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-18-000007:notes:145]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0000866374-18-000007:notes:146]
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2018, 2017 and 2016 are as follows:

[0000866374-18-000007:notes:147]
|  | Fiscal Year Ended March 31, 2018 |
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |
| Other comprehensive gain before reclassifications | 15,667 |  |  | 46,022 |  |  | 61,689 |  |
| Net gains reclassified from accumulated other comprehensive loss | (18,987 | ) |  | (404 | ) |  | (19,391 | ) |
| Net current-period other comprehensive gain (loss) | (3,320 | ) |  | 45,618 |  |  | 42,298 |  |
| Ending balance | $ | (35,746 | ) |  | $ | (50,099 | ) |  | $ | (85,845 | ) |

[0000866374-18-000007:notes:148]
|  | Fiscal Year Ended March 31, 2017 |
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |
| Other comprehensive gain (loss) before reclassifications | 6,925 |  |  | (1,198 | ) |  | 5,727 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 2,171 |  |  | (126 | ) |  | 2,045 |  |
| Net current-period other comprehensive gain (loss) | 9,096 |  |  | (1,324 | ) |  | 7,772 |  |
| Ending balance | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |

[0000866374-18-000007:notes:149]
|  | Fiscal Year Ended March 31, 2016 |
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |
| Other comprehensive loss before reclassifications | (2,199 | ) |  | (3,145 | ) |  | (5,344 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 28,943 |  |  | 20,991 |  |  | 49,934 |  |
| Net current-period other comprehensive gain | 26,744 |  |  | 17,846 |  |  | 44,590 |  |
| Ending balance | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |

[0000866374-18-000007:notes:150]
Net gains reclassified from accumulated other comprehensive loss during fiscal year 2018 relating to derivative instruments and other includes $20.8 million attributable to the Company's cash flow hedge instruments which were recognized as a component of cost of sales in the consolidated statement of operations.

[0000866374-18-000007:notes:151]
Net (gains) losses reclassified from accumulated other comprehensive loss were immaterial during fiscal year 2017.

[0000866374-18-000007:notes:152]
During fiscal year 2016, the Company recognized a loss of $26.8 million in connection with the disposition of a non-strategic Western European manufacturing facility, which included a $25.3 million cumulative foreign currency translation loss offset by the release of certain immaterial cumulative foreign currency translation gains, which were reclassified from accumulated other comprehensive loss during the period and included in other charges (income), net in consolidated statement of operations.


## us-gaap:DebtDisclosureTextBlock

[0000866374-18-000007:notes:153]
BANK BORROWINGS AND LONG-TERM DEBT

[0000866374-18-000007:notes:154]
Bank borrowings and long-term debt are as follows:

[0000866374-18-000007:notes:155]
|  | As of March 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 687,813 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 483,656 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 596,387 |  |  | 595,979 |  |
| Other | 186,601 |  |  | 169,671 |  |
| Debt issuance costs | (13,815 | ) |  | (16,007 | ) |
|  | 2,940,642 |  |  | 2,952,143 |  |
| Current portion, net of debt issuance costs | (43,011 | ) |  | (61,534 | ) |
| Non-current portion | $ | 2,897,631 |  |  | $ | 2,890,609 |  |

[0000866374-18-000007:notes:156]
The weighted-average interest rates for the Company's long-term debt were 3.9% and 3.5% as of March 31, 2018 and 2017, respectively.

[0000866374-18-000007:notes:157]
Repayments of the Company's long-term debt are as follows:

[0000866374-18-000007:notes:158]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2019 | $ | 44,015 |  |
| 2020 | 542,915 |  |
| 2021 | 116,423 |  |
| 2022 | 812,500 |  |
| 2023 | 839,188 |  |
| Thereafter | 599,416 |  |
| Total | $ | 2,954,457 |  |

[0000866374-18-000007:notes:159]
Term Loan due November 2021

[0000866374-18-000007:notes:160]
In August 2013, the Company entered into a $600 million term loan agreement due August 2018. In November 2016, the Company entered into a new arrangement to extend the maturity date of the agreement from August 30, 2018 to November 30, 2021, and borrowed an incremental amount of $130 million under this term loan, thereby increasing the total amount under the term loan to $700 million. This loan is repayable in quarterly installments of $4.1 million, which commenced October 31, 2017 and continue through September 30, 2021, with the remaining amount due at maturity.

[0000866374-18-000007:notes:161]
Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the prime rate in effect on each day as published in The Wall Street Journal, the federal funds rate plus 0.5% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating.

[0000866374-18-000007:notes:162]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term; provided that the requirement to maintain the minimum interest coverage ratio may be suspended in certain circumstances. As of March 31, 2018, the Company was in compliance with the covenants under this term loan agreement.

[0000866374-18-000007:notes:163]
Term Loan Agreement due June 2022 and Revolving Line of Credit

[0000866374-18-000007:notes:164]
In June 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature in March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualified as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the term of the 2022 Credit Facility.

[0000866374-18-000007:notes:165]
Borrowings under the 2022 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate that would be calculated as of each day in respect of a proposed LIBOR loan with a one-month interest period, plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 1.875% per annum, based on the Company’s credit ratings.

[0000866374-18-000007:notes:166]
The 2022 Credit Facility is unsecured and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of March 31, 2018, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.

[0000866374-18-000007:notes:167]
Notes due February 2020 and February 2023

[0000866374-18-000007:notes:168]
In February 2013, the Company issued $500.0 million of 4.625% Notes due February 15, 2020 and $500.0 million of 5.000% Notes due February 15, 2023 (collectively the "Notes") in a private offering pursuant to Rule 144A and Regulation S under the Securities Act. In July 2013, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission. The Company received net proceeds of approximately $990.6 million from the issuance and used those proceeds, together with $9.4 million of cash on hand, to repay $1.0 billion of outstanding borrowings under its previous term loan that was due October 2014.

[0000866374-18-000007:notes:169]
Interest on the Notes is payable semi-annually, which commenced on August 15, 2013. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and up until June 30, 2017 were guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). The Company replaced its $2.1 billion credit facility, which was due to expire in March 2019 and was guaranteed by the guarantor subsidiaries, with the 2022 Credit Facility, which is not guaranteed by the guarantor subsidiaries. Effective upon the replacement, all guarantor subsidiaries were released from their guarantees under each indenture for the Notes. As a result, the Company will no longer be providing supplemental guarantor and non-guarantor consolidating financial statements.

[0000866374-18-000007:notes:170]
At any time prior to maturity, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0000866374-18-000007:notes:171]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately. As of March 31, 2018, the Company was in compliance with the covenants in the indenture governing the Notes.

[0000866374-18-000007:notes:172]
Notes due June 2025

[0000866374-18-000007:notes:173]
In June 2015, the Company issued $600 million of 4.750% Notes ("2025 Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at 99.213% of face value, and an effective yield of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which was used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.

[0000866374-18-000007:notes:174]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the 2025 Notes. The issuance costs were capitalized and presented on the balance sheet as a direct deduction from the carrying amount of the 2025 Notes.

[0000866374-18-000007:notes:175]
Interest on the 2025 Notes is payable semi-annually, commencing on December 15, 2015. The 2025 Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and up until June 30, 2017 were guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). The Company replaced its $2.1 billion credit facility, which was due to expire in March 2019 and was guaranteed by the guarantor subsidiaries, with the 2022 Credit Facilities, which is not guaranteed by the guarantor subsidiaries. Effective upon the replacement, all guarantor subsidiaries were released from their guarantees under the indenture for the 2025 Notes. As a result, the Company will no longer be providing supplemental guarantor and non-guarantor consolidating financial statements.

[0000866374-18-000007:notes:176]
At any time prior to March 15, 2025, the Company may redeem some or all of the 2025 Notes at a redemption price equal to 100% of the principal amount of the 2025 Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the 2025 Notes indenture), the Company must offer to repurchase the 2025 Notes at a repurchase price equal to 101% of the principal amount of the 2025 Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0000866374-18-000007:notes:177]
The indenture governing the 2025 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2025 Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2025 Notes may declare all of the 2025 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2025 Notes. As of March 31, 2018, the Company was in compliance with the covenants in the indenture governing the 2025 Notes.

[0000866374-18-000007:notes:178]
Other Credit Lines

[0000866374-18-000007:notes:179]
In January 2017, the Company borrowed €100 million (approximately $123.5 million as of March 31, 2018), under a 5-year, term-loan agreement due January 2, 2022. Borrowings under this term loan bear interest at EURIBOR minus 0.1% plus the applicable margin ranging between 0.40% and 1.35%, based on the Company's credit ratings. The loan is repayable upon maturity.

[0000866374-18-000007:notes:180]
In October 2015, the Company borrowed €50 million (approximately $61.8 million as of March 31, 2018), under a 5-year, term-loan agreement due September 30, 2020. Borrowings under this term loan bear interest at EURIBOR plus the applicable margin ranging between 0.80% and 2.00%, based on the Company’s credit ratings. The loan is repayable beginning December 30, 2016 in quarterly payments of €312,500 through June 30, 2020 with the remainder due upon maturity.

[0000866374-18-000007:notes:181]
These term loans are unsecured and are guaranteed by the Company. These term loan agreements contain customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. These term loan agreements also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during their terms. As of March 31, 2018, the Company was in compliance with the covenants under these term loan agreements.

[0000866374-18-000007:notes:182]
As of March 31, 2018, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities in the amount of $256.5 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2018 and 2017. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin, and generally have maturities that expire on various dates in future fiscal years.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-18-000007:notes:183]
FINANCIAL INSTRUMENTS

[0000866374-18-000007:notes:184]
Foreign Currency Contracts

[0000866374-18-000007:notes:185]
The Company transacts business in various foreign countries and is therefore exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency unit of the operating entity. The Company enters into short-term foreign currency derivatives contracts, including forward, swap, and options contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-18-000007:notes:186]
As of March 31, 2018, the aggregate notional amount of the Company's outstanding foreign currency derivative contracts was $7.6 billion as summarized below:

[0000866374-18-000007:notes:187]
|  | Foreign CurrencyAmount |  | Notional ContractValue in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| CNY | 2,472,000 |  |  | — |  |  | $ | 392,493 |  |  | $ | — |  |
| EUR | 74,696 |  |  | 102,508 |  |  | 92,292 |  |  | 123,347 |  |
| HUF | 20,482,360 |  |  | — |  |  | 80,961 |  |  | — |  |
| ILS | 104,570 |  |  | 17,325 |  |  | 29,853 |  |  | 4,946 |  |
| MXN | 3,820,600 |  |  | — |  |  | 208,688 |  |  | — |  |
| MYR | 235,400 |  |  | 78,000 |  |  | 60,277 |  |  | 19,973 |  |
| RON | 125,190 |  |  | — |  |  | 33,224 |  |  | — |  |
| SGD | 35,250 |  |  | — |  |  | 26,908 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 49,734 |  |  | 3,225 |  |
|  |  |  |  |  | 974,430 |  |  | 151,491 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |
| AUD | 29,887 |  |  | 39,839 |  |  | 22,925 |  |  | 30,834 |  |
| BRL | — |  |  | 706,000 |  |  | — |  |  | 211,580 |  |
| CAD | 306,196 |  |  | 336,629 |  |  | 237,601 |  |  | 261,216 |  |
| CHF | 13,122 |  |  | 26,611 |  |  | 13,763 |  |  | 27,912 |  |
| CNY | 2,238,583 |  |  | — |  |  | 347,121 |  |  | — |  |
| EUR | 1,190,730 |  |  | 1,442,218 |  |  | 1,469,945 |  |  | 1,780,517 |  |
| GBP | 38,445 |  |  | 65,222 |  |  | 54,179 |  |  | 91,794 |  |
| HUF | 106,548,846 |  |  | 116,231,762 |  |  | 421,158 |  |  | 459,432 |  |
| INR | 4,052,331 |  |  | 747,986 |  |  | 61,992 |  |  | 11,476 |  |
| MXN | 2,342,814 |  |  | 2,109,080 |  |  | 127,969 |  |  | 115,202 |  |
| MYR | 844,010 |  |  | 627,500 |  |  | 216,119 |  |  | 160,679 |  |
| PLN | 99,330 |  |  | 54,465 |  |  | 29,180 |  |  | 16,000 |  |
| SEK | 144,590 |  |  | 267,169 |  |  | 17,492 |  |  | 32,172 |  |
| SGD | 73,918 |  |  | 40,994 |  |  | 56,426 |  |  | 31,293 |  |
| Other | N/A |  |  | N/A |  |  | 89,386 |  |  | 45,739 |  |
|  |  |  |  |  | 3,165,256 |  |  | 3,275,846 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 4,139,686 |  |  | $ | 3,427,337 |  |

[0000866374-18-000007:notes:188]
As of March 31, 2018 and 2017, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in non-functional currencies and are not accounted for as hedges under the accounting standards. Accordingly, changes in fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the consolidated statements of operations. As of March 31, 2018 and 2017, the Company also has included net deferred gains and losses, in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains totaled $6.6 million as of March 31, 2018, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal years presented and are included as a component of interest and other, net in the consolidated statements of operations.

[0000866374-18-000007:notes:189]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2018 and 2017:

[0000866374-18-000007:notes:190]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31, 2018 |  | March 31, 2017 |  | Balance SheetLocation |  | March 31, 2018 |  | March 31, 2017 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 19,422 |  |  | $ | 11,936 |  |  | Other current liabilities |  | $ | 7,065 |  |  | $ | 1,814 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 23,912 |  |  | $ | 10,086 |  |  | Other current liabilities |  | $ | 18,246 |  |  | $ | 9,928 |  |

[0000866374-18-000007:notes:191]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with the counterparty upon maturity. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-18-000007:notes:192]
SHARE-BASED COMPENSATION

[0000866374-18-000007:notes:193]
Equity Compensation Plans

[0000866374-18-000007:notes:194]
Historically, the Company's primary plan used for granting equity compensation awards was the 2010 Equity Incentive Plan (the "2010 Plan"). Effective August 15, 2017, awards are granted under the Company's 2017 Equity Incentive Plan (the "2017 Plan"), which was approved by the Company's shareholders at the 2017 Annual General Meeting of Shareholders, to replace the 2010 Plan for further grants. For additional discussion about the 2017 Plan, refer to the Company's Proxy Statement, which was filed with the Securities and Exchange Commission on July 5, 2017.

[0000866374-18-000007:notes:195]
During fiscal year 2016, in conjunction with the acquisition of NEXTracker, the Company assumed all of the outstanding, unvested share bonus awards and outstanding, unvested options to purchase shares of common stock of NEXTracker, and converted all these shares into Flex awards. As a result, the Company now maintains the 2014 NEXTracker Equity Incentive Plan (the "NEXTracker Plan").

[0000866374-18-000007:notes:196]
Additionally, during fiscal year 2017, in conjunction with an immaterial acquisition, the Company assumed all of the outstanding, unvested options to purchase shares of common stock of the acquiree, and converted all of these shares into Flex awards. As a result, the Company now maintains an additional equity compensation plan, the BrightBox Technologies 2013 Plan (the "BrightBox Plan"). The BrightBox Plan is immaterial to the Company for all periods presented.

[0000866374-18-000007:notes:197]
As a result of the deconsolidation of Elementum during fiscal year 2018, the Company no longer grants equity compensation awards under the 2013 Elementum Plan. Refer to note 6 for additional information on the deconsolidation.

[0000866374-18-000007:notes:198]
Share-Based Compensation Expense

[0000866374-18-000007:notes:199]
The following table summarizes the Company's share-based compensation expense for all Equity Incentive Plans:

[0000866374-18-000007:notes:200]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Cost of sales | $ | 19,102 |  |  | $ | 10,023 |  |  | $ | 8,986 |  |
| Selling, general and administrative expenses | 66,142 |  |  | 72,243 |  |  | 68,594 |  |
| Total share-based compensation expense | $ | 85,244 |  |  | $ | 82,266 |  |  | $ | 77,580 |  |

[0000866374-18-000007:notes:201]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as operating cash flows. During fiscal years 2018, 2017 and 2016, the Company did not recognize any excess tax benefits as an operating cash inflow.

[0000866374-18-000007:notes:202]
The 2017 Equity Incentive Plan

[0000866374-18-000007:notes:203]
As of March 31, 2018, the Company had approximately 22.2 million shares available for grant under the 2017 Plan. Options issued to employees under the 2017 Plan generally vest over four years and expire ten years from the date of grant. Options granted to non-employee directors expire five years from the date of grant.

[0000866374-18-000007:notes:204]
The exercise price of options granted to employees is determined by the Company's Board of Directors or the Compensation Committee and may not be less than the closing price of the Company's ordinary shares on the date of grant.

[0000866374-18-000007:notes:205]
As of March 31, 2018, the total unrecognized compensation cost related to unvested share options granted to employees under the 2017 Plan was not significant and will be amortized on a straight-line basis over a weighted-average period of approximately six months.

[0000866374-18-000007:notes:206]
The Company also grants share bonus awards under its equity compensation plan. Share bonus awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. Share bonus awards generally vest in installments over a three to five-year period and unvested share bonus awards are forfeited upon termination of employment.

[0000866374-18-000007:notes:207]
Vesting for certain share bonus awards is contingent upon both service and market conditions. Further, vesting for certain share bonus awards granted to certain executive officers is contingent upon meeting certain free cash flow targets.

[0000866374-18-000007:notes:208]
As of March 31, 2018, the total unrecognized compensation cost related to unvested share bonus awards granted to employees was approximately $134.2 million under the 2017 Plan. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.5 years. Approximately $14.2 million of the unrecognized compensation cost related to the 2017 Plan is related to share bonus awards granted to certain key employees whereby vesting is contingent on meeting a certain market condition.

[0000866374-18-000007:notes:209]
Determining Fair Value - Options and share bonus awards

[0000866374-18-000007:notes:210]
Valuation and Amortization Method—The Company estimates the fair value of share options granted under the 2017 and 2010 Plans using the Black-Scholes valuation method and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period. The fair market value of share bonus awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-18-000007:notes:211]
Expected Term—The Company's expected term used in the Black-Scholes valuation method represents the period that the Company's share options are expected to be outstanding and is determined based on historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share options.

[0000866374-18-000007:notes:212]
Expected Volatility—The Company's expected volatility used in the Black-Scholes valuation method is derived from a combination of implied volatility related to publicly traded options to purchase Flex ordinary shares and historical variability in the Company's periodic share price.

[0000866374-18-000007:notes:213]
Expected Dividend—The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-18-000007:notes:214]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0000866374-18-000007:notes:215]
There were no options granted under the 2017 and 2010 Plans during fiscal years 2018, 2017 and 2016.

[0000866374-18-000007:notes:216]
Determining Fair Value - Share bonus awards with service and market conditions

[0000866374-18-000007:notes:217]
Valuation and Amortization Method—The Company estimates the fair value of share bonus awards granted under the 2017 and 2010 Plans whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-18-000007:notes:218]
Expected volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the share bonus awards granted. The service period is three years for those share bonus awards granted in fiscal years 2018, 2017 and 2016.

[0000866374-18-000007:notes:219]
Average peer volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of the Standard and Poor's ("S&P") 500 index for the share bonus awards granted in fiscal years 2018, 2017 and 2016.

[0000866374-18-000007:notes:220]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to the S&P 500 index for the share bonus awards granted in fiscal years 2018, 2017 and 2016.

[0000866374-18-000007:notes:221]
Expected Dividend and Risk-Free Interest Rate assumptions—Same methodology as discussed above.

[0000866374-18-000007:notes:222]
The fair value of the Company's share-bonus awards under the 2017 and 2010 Plans, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2018, 2017 and 2016 was estimated using the following weighted-average assumptions:

[0000866374-18-000007:notes:223]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Expected volatility | 25.1 | % |  | 25.8 | % |  | 26.0 | % |
| Average peer volatility | 28.7 | % |  | 25.1 | % |  | 23.0 | % |
| Average peer correlation | 0.6 |  |  | 0.6 |  |  | 0.6 |  |
| Expected dividends | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate | 1.5 | % |  | 0.9 | % |  | 1.2 | % |

[0000866374-18-000007:notes:224]
Share-Based Awards Activity

[0000866374-18-000007:notes:225]
The following is a summary of option activity for the Company's 2017 and 2010 Plans ("Price" reflects the weighted-average exercise price):

[0000866374-18-000007:notes:226]
|  | Fiscal Year Ended March 31, |
|  | 2018 | 2017 | 2016 |
|  | Options |  | Price |  | Options |  | Price |  | Options |  | Price |
| Outstanding, beginning of fiscal year | 142,327 |  |  | $ | 8.97 |  |  | 2,369,636 |  |  | $ | 8.31 |  |  | 15,992,894 |  |  | $ | 7.81 |  |
| Granted | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised | (125,949 | ) |  | 8.63 |  |  | (1,573,356 | ) |  | 6.89 |  |  | (10,006,774 | ) |  | 6.10 |  |
| Forfeited | (9,500 | ) |  | 11.55 |  |  | (653,953 | ) |  | 12.39 |  |  | (3,616,484 | ) |  | 12.23 |  |
| Outstanding, end of fiscal year | 6,878 |  |  | $ | 9.78 |  |  | 142,327 |  |  | $ | 8.97 |  |  | 2,369,636 |  |  | $ | 8.31 |  |
| Options exercisable, end of fiscal year | 5,751 |  |  | $ | 9.52 |  |  | 138,950 |  |  | $ | 8.93 |  |  | 2,359,527 |  |  | $ | 8.30 |  |

[0000866374-18-000007:notes:227]
The aggregate intrinsic value of options exercised under the Company's 2010 Plan (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise for options exercised in-the-money) was $1.1 million, $9.3 million and $55.3 million during fiscal years 2018, 2017 and 2016, respectively.

[0000866374-18-000007:notes:228]
Cash received from option exercises under the 2010 Plan was $1.1 million, $10.9 million and $61.1 million for fiscal years 2018, 2017 and 2016, respectively.

[0000866374-18-000007:notes:229]
As of March 31, 2018 the aggregate intrinsic value for options outstanding, options vested and expected to vest, and options exercisable under the Company's 2017 and 2010 Plans were immaterial. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2018 for the immaterial amount of options that were in-the-money at March 31, 2018.

[0000866374-18-000007:notes:230]
The following table summarizes the Company's share bonus award activity under the 2017 and 2010 Plans ("Price" reflects the weighted-average grant-date fair value):

[0000866374-18-000007:notes:231]
|  | Fiscal Year Ended March 31, |
|  | 2018 | 2017 | 2016 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested share bonus awards outstanding, beginning of fiscal year | 15,698,582 |  |  | $ | 12.44 |  |  | 17,000,076 |  |  | $ | 10.77 |  |  | 18,993,252 |  |  | $ | 9.01 |  |
| Granted (1) | 6,155,761 |  |  | 16.99 |  |  | 8,261,666 |  |  | 13.46 |  |  | 7,619,722 |  |  | 12.23 |  |
| Vested (1) | (6,473,562 | ) |  | 12.17 |  |  | (8,606,246 | ) |  | 9.44 |  |  | (8,529,378 | ) |  | 7.93 |  |
| Forfeited | (1,488,739 | ) |  | 13.38 |  |  | (956,914 | ) |  | 11.20 |  |  | (1,083,520 | ) |  | 9.67 |  |
| Unvested share bonus awards outstanding, end of fiscal year | 13,892,042 |  |  | $ | 14.52 |  |  | 15,698,582 |  |  | $ | 12.44 |  |  | 17,000,076 |  |  | $ | 10.77 |  |

[0000866374-18-000007:notes:232]
(1)  Included in the fiscal years 2018 and 2017 amounts are 0.7 million and 1.7 million of share bonus awards, respectively, representing the number of awards achieved above target levels based on the achievement of certain market conditions, as further described in the table below. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-18-000007:notes:233]
Of the 6.2 million unvested share bonus awards granted under the 2017 and 2010 Plans in fiscal year 2018, approximately 4.7 million are plain-vanilla unvested share bonus awards with no performance or market conditions with an average grant date price of $16.57 per share. Further, approximately 0.2 million of these unvested share bonus awards have an average grant date price of $16.34 per share and represents the target amount of grants made to certain executive officers whereby vesting is contingent on meeting certain free cash flow targets. These awards cliff vest after three years and will ultimately pay out over a range from zero up to a maximum of 0.4 million of the target payment based on a measurement of cumulative three-year increase of free cash flow from operations of the Company. Further, 0.6 million of these unvested share bonus awards granted in fiscal year 2018 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $20.25 per award and was calculated using a Monte Carlo simulation. Vesting information for these shares are further detailed in the table below. Finally, the remaining balance of 0.7 million represents the number of awards achieved above target levels, as described in the table above.

[0000866374-18-000007:notes:234]
The Company will recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2018, 1.4 million shares vested in connection with the share bonus awards with market conditions granted in fiscal year 2015.

[0000866374-18-000007:notes:235]
The total intrinsic value of share bonus awards vested under the Company's 2017 and 2010 Plans was $108.4 million, $109.5 million and $103.2 million during fiscal years 2018, 2017 and 2016, respectively, based on the closing price of the Company's ordinary shares on the date vested.

[0000866374-18-000007:notes:236]
The 2014 NEXTracker Equity Incentive Plan

[0000866374-18-000007:notes:237]
All awards previously granted under the NEXTracker Plan are the result of the Company's conversion of all outstanding, unvested shares of NEXTracker into unvested shares of the Company, as part of the acquisition.  During fiscal year 2018, the Company modified the vesting conditions of 0.3 million unvested options and 0.5 million share bonus awards under the NEXTracker Plan contingent on meeting certain performance targets.  These options and share bonus awards were then re-granted to vest in installments over a three-year period commencing September 29, 2017.  The Company determined that the transaction falls under the accounting for modification of awards, and accordingly adjusted the recognized compensation expense with an immaterial impact on the statement of operations for fiscal year 2018.

[0000866374-18-000007:notes:238]
Options issued to employees under the NEXTracker Plan generally have a vesting period of two to four years from vesting commencement date and expire ten years from the date of grant.

[0000866374-18-000007:notes:239]
The exercise price of options granted to employees was determined by the Company based on a conversion rate agreed upon in the purchase agreement of NEXTracker.

[0000866374-18-000007:notes:240]
As of March 31, 2018, the total unrecognized compensation cost related to unvested share options granted to employees under the NEXTracker Plan was $6.3 million and will be amortized on a straight-line basis over a weighted-average period of approximately 2.1 years.

[0000866374-18-000007:notes:241]
Share bonus awards issued to employees under the NEXTracker Plan vest in installments over a three to five-year period from vesting commencement date, and unvested share bonus awards are forfeited upon termination of employment. Vesting for certain of these share bonus awards is contingent on meeting certain performance targets over a three-year period commencing September 29, 2017, following the modification of vesting conditions described above.

[0000866374-18-000007:notes:242]
As of March 31, 2018, the total unrecognized compensation cost related to unvested share bonus awards granted to employees under the NEXTracker Plan was approximately $10.5 million and will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.5 years.

[0000866374-18-000007:notes:243]
Determining Fair Value

[0000866374-18-000007:notes:244]
As noted above, the Company re-granted certain shares options under the NEXTracker Plan during fiscal year 2018 after modifying the vesting conditions.  The fair value of share options granted under the NEXTracker Plan for fiscal years 2018 and 2016 was estimated using the following weighted-average assumptions:

[0000866374-18-000007:notes:245]
|  | Fiscal Year EndedMarch 31, 2018 | Fiscal Year EndedMarch 31, 2016 |
| Expected term | 6.5 years | 2.9 years |
| Expected volatility | 28.8% | 28.8% |
| Expected dividends | 0.0% | 0.0% |
| Risk-free interest rate | 2.1% | 0.9% |
| Weighted-average fair value | $16.29 | $7.76 |

[0000866374-18-000007:notes:246]
The following is a summary of option activity for the NEXTracker Plan ("Price" reflects the weighted-average exercise price):

[0000866374-18-000007:notes:247]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | Options |  | Price |  | Options |  | Price |  | Options |  | Price |
| Outstanding, beginning of fiscal year | 1,636,016 |  |  | $ | 3.61 |  |  | 2,741,854 |  |  | $ | 3.44 |  |  | — |  |  | $ | — |  |
| Granted | 288,386 |  |  | 0.54 |  |  | — |  |  | — |  |  | 3,205,806 |  |  | 3.28 |  |
| Exercised | (510,322 | ) |  | 3.27 |  |  | (709,845 | ) |  | 2.24 |  |  | (237,380 | ) |  | 0.99 |  |
| Forfeited | (352,820 | ) |  | 5.69 |  |  | (395,993 | ) |  | 4.64 |  |  | (226,572 | ) |  | 3.75 |  |
| Outstanding, end of fiscal year | 1,061,260 |  |  | $ | 3.55 |  |  | 1,636,016 |  |  | $ | 3.61 |  |  | 2,741,854 |  |  | $ | 3.44 |  |
| Options exercisable, end of fiscal year | 352,829 |  |  | $ | 5.11 |  |  | 369,015 |  |  | $ | 5.00 |  |  | 223,869 |  |  | $ | 4.95 |  |

[0000866374-18-000007:notes:248]
The aggregate intrinsic value of options exercised under the NEXTracker plan (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise for options exercised in-the-money) was $7.3 million, $8.0 million and 2.3 million as of March 31, 2018, 2017 and 2016, respectively.

[0000866374-18-000007:notes:249]
Cash received from option exercises under the NEXTracker Plan was $1.7 million, $1.6 million and $0.2 million for fiscal years 2018, 2017 and 2016, respectively.

[0000866374-18-000007:notes:250]
As of March 31, 2018 the aggregate intrinsic value for options outstanding, options vested and expected to vest, and options exercisable under the Company's NEXTracker Plan, were $13.6 million, $13.6 million, and $4.0 million, respectively. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2018 for the approximately 1.1 million options under the NEXTracker Plan that were in-the-money at March 31, 2018.

[0000866374-18-000007:notes:251]
The following table summarizes the Company's share bonus award activity under the NEXTracker Plan ("Price" reflects the weighted-average grant-date fair value):

[0000866374-18-000007:notes:252]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested share bonus awards outstanding, beginning of fiscal year | 1,543,437 |  |  | $ | 10.23 |  |  | 2,309,096 |  |  | $ | 10.27 |  |  | — |  |  | $ | — |  |
| Granted | 524,978 |  |  | 16.73 |  |  | — |  |  | — |  |  | 2,393,195 |  |  | 10.27 |  |
| Vested | (471,831 | ) |  | 7.63 |  |  | (705,738 | ) |  | 10.19 |  |  | (31,925 | ) |  | 10.27 |  |
| Forfeited | (868,934 | ) |  | 10.18 |  |  | (59,921 | ) |  | 10.27 |  |  | (52,174 | ) |  | 10.27 |  |
| Unvested share bonus awards outstanding, end of fiscal year | 727,650 |  |  | $ | 11.85 |  |  | 1,543,437 |  |  | $ | 10.23 |  |  | 2,309,096 |  |  | $ | 10.27 |  |

[0000866374-18-000007:notes:253]
The total intrinsic value of share bonus awards vested under the Company's NEXTracker Plan was $8.0 million and $9.6 million, during fiscal year 2018 and 2017, respectively, based on the closing price of the Company's ordinary shares on the date vested. The total intrinsic value of share bonus awards vested under the Company's NEXTracker Plan was immaterial during fiscal year 2016.


## us-gaap:EarningsPerShareTextBlock

[0000866374-18-000007:notes:254]
EARNINGS PER SHARE

[0000866374-18-000007:notes:255]
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-18-000007:notes:256]
Diluted earnings per share reflects the potential dilution from stock options and share bonus awards. The potential dilution from stock options exercisable into ordinary share equivalents and share bonus awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-18-000007:notes:257]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income per share:

[0000866374-18-000007:notes:258]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands, exceptper share amounts) |
| Basic earnings per share: |  |  |  |  |  |
| Net income | $ | 428,534 |  |  | $ | 319,564 |  |  | $ | 444,081 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 529,782 |  |  | 540,503 |  |  | 557,667 |  |
| Basic earnings per share | $ | 0.81 |  |  | $ | 0.59 |  |  | $ | 0.80 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 428,534 |  |  | $ | 319,564 |  |  | $ | 444,081 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 529,782 |  |  | 540,503 |  |  | 557,667 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) | 6,816 |  |  | 5,717 |  |  | 7,202 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 536,598 |  |  | 546,220 |  |  | 564,869 |  |
| Diluted earnings per share | $ | 0.80 |  |  | $ | 0.59 |  |  | $ | 0.79 |  |

[0000866374-18-000007:notes:259]
_________________________________________________________________________

[0000866374-18-000007:notes:260]
| (1) | An immaterial amount of options to purchase ordinary shares during fiscal year 2018 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. Options to purchase ordinary shares of 0.5 million and 2.0 million during fiscal years 2017 and 2016, respectively, were excluded from the computation of diluted earnings per share. |

[0000866374-18-000007:notes:261]
Share bonus awards of less than 0.1 million during fiscal year 2018 and 2017, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. There were no anti-dilutive share bonus awards in fiscal year 2016.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-18-000007:notes:262]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES

[0000866374-18-000007:notes:263]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-18-000007:notes:264]
Level 1—Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000866374-18-000007:notes:265]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other noncurrent assets on the consolidated balance sheets and include investments in equity securities that are valued using active market prices.

[0000866374-18-000007:notes:266]
Level 2—Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-18-000007:notes:267]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-18-000007:notes:268]
The Company's cash equivalents are comprised of bank deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-18-000007:notes:269]
The Company's deferred compensation plan assets also include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-18-000007:notes:270]
Level 3—Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-18-000007:notes:271]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs.

[0000866374-18-000007:notes:272]
The significant inputs in the fair value measurement not supported by market activity included the Company's probability assessments of expected future revenue during the earn-out period and associated volatility, appropriately discounted considering the uncertainties associated with the obligation, and calculated in accordance with the terms of the merger agreement. Significant decreases in expected revenue during the earn-out period, or significant increases in the discount rate or volatility in isolation would result in lower fair value estimates. The interrelationship between these inputs is not considered significant.

[0000866374-18-000007:notes:273]
The following table summarizes the activities related to contingent consideration:

[0000866374-18-000007:notes:274]
|  | As of March 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| Beginning balance | $ | 22,426 |  |  | $ | 73,423 |  |
| Additions to accrual | — |  |  | — |  |
| Payments and settlements | (17,109 | ) |  | (44,912 | ) |
| Fair value adjustments | (5,317 | ) |  | (6,085 | ) |
| Ending balance | $ | — |  |  | $ | 22,426 |  |

[0000866374-18-000007:notes:275]
In connection with the acquisition of NEXTracker, Inc. in fiscal year 2016, the Company had an obligation to pay additional cash consideration to the former shareholders contingent upon NEXTracker, Inc.'s achievement of revenue targets during the two years after acquisition (ending on September 30, 2017). During fiscal year 2018, the Company paid $17.1 million of the total contingent consideration following the second year's targets achievement in accordance with the terms of the merger agreement. The payment of the contingent consideration is included in other financing activities, net, in the consolidated statements of cash flows.

[0000866374-18-000007:notes:276]
There were no transfers between levels in the fair value hierarchy during fiscal years 2018 and 2017.

[0000866374-18-000007:notes:277]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-18-000007:notes:278]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2018 and 2017:

[0000866374-18-000007:notes:279]
|  | Fair Value Measurements as of March 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 452,622 |  |  | $ | — |  |  | $ | 452,622 |  |
| Foreign exchange forward contracts (Note 9) | — |  |  | 43,334 |  |  | — |  |  | 43,334 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 7,196 |  |  | 67,532 |  |  | — |  |  | 74,728 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 9) | $ | — |  |  | $ | (25,311 | ) |  | $ | — |  |  | $ | (25,311 | ) |

[0000866374-18-000007:notes:280]
|  | Fair Value Measurements as of March 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 1,066,841 |  |  | $ | — |  |  | $ | 1,066,841 |  |
| Foreign exchange forward contracts (Note 9) | — |  |  | 22,022 |  |  | — |  |  | 22,022 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 7,062 |  |  | 52,680 |  |  | — |  |  | 59,742 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 9) | $ | — |  |  | $ | (11,742 | ) |  | $ | — |  |  | $ | (11,742 | ) |
| Contingent consideration in connection with acquisitions | — |  |  | — |  |  | (22,426 | ) |  | (22,426 | ) |

[0000866374-18-000007:notes:281]
Other financial instruments

[0000866374-18-000007:notes:282]
The following table presents the Company's liabilities not carried at fair value as of March 31, 2018 and 2017:

[0000866374-18-000007:notes:283]
|  | As of March 31, 2018 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In thousands) |  | (In thousands) |  |  |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 513,596 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 687,813 |  |  | 689,966 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 483,656 |  |  | 485,470 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 525,292 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,387 |  |  | 627,407 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 59,443 |  |  | 59,443 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 123,518 |  |  | 123,518 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,950,817 |  |  | $ | 3,024,692 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |

[0000866374-18-000007:notes:284]
(1)    In June 2017, the Company entered into a new agreement that effectively extended the maturity date of the loan from March 31, 2019 to June 30, 2022. Refer to note 8 for further details of the arrangement.

[0000866374-18-000007:notes:285]
The Term Loans due November 2021 and June 2022, and the Notes due February 2020, February 2023 and June 2025 are valued based on broker trading prices in active markets.

[0000866374-18-000007:notes:286]
The Company values its Euro Term Loans due September 2020 and January 2022 based on the current market rate, and as of March 31, 2018, the carrying amounts approximate fair values.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-18-000007:notes:287]
INCOME TAXES

[0000866374-18-000007:notes:288]
The domestic (Singapore) and foreign components of income before income taxes were comprised of the following:

[0000866374-18-000007:notes:289]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Domestic | $ | 323,522 |  |  | $ | 435,709 |  |  | $ | 199,283 |  |
| Foreign | 197,371 |  |  | (64,861 | ) |  | 255,392 |  |
| Total | $ | 520,893 |  |  | $ | 370,848 |  |  | $ | 454,675 |  |

[0000866374-18-000007:notes:290]
The provision for income taxes consisted of the following:

[0000866374-18-000007:notes:291]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Domestic | $ | 2,894 |  |  | $ | 1,037 |  |  | $ | 56 |  |
| Foreign | 50,889 |  |  | 71,773 |  |  | 74,706 |  |
|  | 53,783 |  |  | 72,810 |  |  | 74,762 |  |
| Deferred: |  |  |  |  |  |
| Domestic | 422 |  |  | 350 |  |  | 3,779 |  |
| Foreign | 38,154 |  |  | (21,876 | ) |  | (67,947 | ) |
|  | 38,576 |  |  | (21,526 | ) |  | (64,168 | ) |
| Provision for income taxes | $ | 92,359 |  |  | $ | 51,284 |  |  | $ | 10,594 |  |

[0000866374-18-000007:notes:292]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2018, 2017 and 2016. The reconciliation of the income tax expense expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0000866374-18-000007:notes:293]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Income taxes based on domestic statutory rates | $ | 88,552 |  |  | $ | 63,044 |  |  | $ | 77,295 |  |
| Effect of tax rate differential | (244,128 | ) |  | (85,132 | ) |  | (62,072 | ) |
| Change in liability for uncertain tax positions | 22,180 |  |  | 684 |  |  | (13,724 | ) |
| Change in valuation allowance | 297,330 |  |  | 78,728 |  |  | 1,049 |  |
| Recognition of prior year taxes recoverable | (53,757 | ) |  | — |  |  | — |  |
| Other | (17,818 | ) |  | (6,040 | ) |  | 8,046 |  |
| Provision for income taxes | $ | 92,359 |  |  | $ | 51,284 |  |  | $ | 10,594 |  |

[0000866374-18-000007:notes:294]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2018, 2017 and 2016 was $21.7 million, $15.5 million and $6.6 million, respectively. For the fiscal year ended March 31, 2018, the effect on basic and diluted earnings per share was $0.04 and $0.04  respectively, and the effect on basic and diluted earnings per share were $0.03 and $0.03 during fiscal year 2017, and $0.01 and $0.01 during fiscal year 2016, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in the fiscal year ending March 31, 2019 through fiscal year 2027.

[0000866374-18-000007:notes:295]
We provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized. During fiscal year 2018, 2017, and 2016 we released valuation allowances totaling $1.3 million, $39.6 million and $63.3 million, respectively.  For fiscal year 2018, these valuation allowance releases were primarily related to our operations in Ireland, Mexico and Taiwan as these amounts were deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those subsidiaries. However, these valuation allowance releases were offset primarily by current period valuation allowance additions due to increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions. For fiscal years 2018, 2017 and 2016, the offsetting amounts totaled $(65.9) million, $103.9 million and $64.3 million, respectively.  Included in these offsets for fiscal year 2018, the Company released $705.3 million of valuation allowance to account for the reduced deferred tax asset as a result of the lower US corporate income tax rate which became effective January 1, 2018. In addition, due to changes with respect to the jurisdiction’s tax position during the fiscal year ended March 31, 2018, the Company established a valuation allowance of $364.5 million for a Brazilian subsidiary which did not previously have a valuation allowance recorded.

[0000866374-18-000007:notes:296]
During fiscal year 2018, the Company recognized an income tax receivable of $53.7 million for prior period taxes paid by one of its Brazilian subsidiaries which was deemed recoverable during the period due to a favorable change in tax law whereby certain incentives are no longer includable in taxable income.

[0000866374-18-000007:notes:297]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years 2018, 2017 and 2016 were $65.8 million, $67.9 million and $36.6 million, respectively.

[0000866374-18-000007:notes:298]
Impact of the U.S. Tax Reform

[0000866374-18-000007:notes:299]
On December 22, 2017, the U.S. President signed the Tax Cuts and Jobs Act (the “Act”) into law. Effective January 1, 2018, among other changes, the Act reduces the U.S. federal corporate tax rate to 21 percent, provides for a deemed repatriation and taxation at reduced rates of certain non-US subsidiaries owned by U.S. companies’ historical earnings (a “transition tax”), and establishes new mechanisms to tax such earnings going forward. Similar to other large multinational companies with complex tax structures, the Act has wide ranging implications for Flex. However, the impact on Flex's financial statements for the twelve-month periods ended March 31, 2018 is immaterial, primarily because the Company has a full valuation allowance on deferred tax assets in the U.S., which results in there being no U.S. deferred tax assets or liabilities recorded on the balance sheet that need to be remeasured at the new 21% rate. Further, the Company expects that the new transition tax will be offset by foreign tax credits or net operating loss carryforwards, and thus will not result in any incremental taxes payable.  The Company will continue to analyze the effects of the Act on its financial statements and operations.  Any additional impacts from the enactment of the Act will be recorded as they are identified during the measurement period provided for in Staff Bulletin 118.

[0000866374-18-000007:notes:300]
The components of deferred income taxes are as follows:

[0000866374-18-000007:notes:301]
|  | As of March 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (33,056 | ) |  | $ | (40,324 | ) |
| Intangible assets | (80,565 | ) |  | (76,432 | ) |
| Others | (12,544 | ) |  | (20,702 | ) |
| Total deferred tax liabilities | (126,165 | ) |  | (137,458 | ) |
| Deferred tax assets: |  |  |  |
| Fixed assets | 65,155 |  |  | 57,869 |  |
| Intangible assets | 11,237 |  |  | 3,153 |  |
| Deferred compensation | 13,475 |  |  | 19,335 |  |
| Inventory valuation | 6,952 |  |  | 8,489 |  |
| Provision for doubtful accounts | 3,073 |  |  | 2,911 |  |
| Net operating loss and other carryforwards | 2,133,097 |  |  | 2,369,405 |  |
| Others | 236,916 |  |  | 266,367 |  |
| Total deferred tax assets | 2,469,905 |  |  | 2,727,529 |  |
| Valuation allowances | (2,259,956 | ) |  | (2,442,105 | ) |
| Total deferred tax assets, net of valuation allowances | 209,949 |  |  | 285,424 |  |
| Net deferred tax asset | $ | 83,784 |  |  | $ | 147,966 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Long-term asset | $ | 165,319 |  |  | $ | 223,285 |  |
| Long-term liability | (81,535 | ) |  | (75,319 | ) |
| Total | $ | 83,784 |  |  | $ | 147,966 |  |

[0000866374-18-000007:notes:302]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-18-000007:notes:303]
The Company has recorded deferred tax assets of approximately $2.2 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $81.3 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-18-000007:notes:304]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-18-000007:notes:305]
The Company does not provide for income taxes on approximately $1.6 billion of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. Determination of the amount of the unrecognized deferred tax liability on these undistributed earnings is not practicable. As of March 31, 2018, we have provided for earnings in foreign subsidiaries that are not considered to be indefinitely reinvested and therefore subject to withholding taxes on $23.1 million of undistributed foreign earnings, recording a deferred tax liability of approximately $1.7 million thereon.

[0000866374-18-000007:notes:306]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-18-000007:notes:307]
|  | Fiscal Year EndedMarch 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| Balance, beginning of fiscal year | $ | 203,323 |  |  | $ | 212,326 |  |
| Additions based on tax position related to the current year | 24,415 |  |  | 29,007 |  |
| Additions for tax positions of prior years | 5,926 |  |  | 9,728 |  |
| Reductions for tax positions of prior years | (11,936 | ) |  | (22,065 | ) |
| Reductions related to lapse of applicable statute of limitations | (9,029 | ) |  | (13,390 | ) |
| Settlements | — |  |  | (3,684 | ) |
| Impact from foreign exchange rates fluctuation | 14,891 |  |  | (8,599 | ) |
| Balance, end of fiscal year | $ | 227,590 |  |  | $ | 203,323 |  |

[0000866374-18-000007:notes:308]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an estimated range of an additional $11 million to $41 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-18-000007:notes:309]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2007.

[0000866374-18-000007:notes:310]
Of the $227.6 million of unrecognized tax benefits at March 31, 2018, $210.7 million will affect the annual effective tax rate if the benefits are eventually recognized. The amount that doesn’t impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-18-000007:notes:311]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company’s tax expense. During the fiscal years ended March 31, 2018, 2017 and 2016, the Company recognized interest and penalty of approximately ($3.3) million and ($1.6) million and $(2.4) million, respectively. The Company had approximately $16.2 million, $12.9 million and $14.6 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2018, 2017 and 2016, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000866374-18-000007:notes:312]
NONCONTROLLING INTEREST AND DECONSOLIDATION OF SUBSIDIARY ENTITY

[0000866374-18-000007:notes:313]
Starting in fiscal year 2014, the Company had a majority owned subsidiary, Elementum SCM (Cayman) Ltd ("Elementum"), which qualified as a variable interest entity for accounting purposes.  The Company owned a majority of Elementum' s outstanding equity (consisting primarily of preferred stock) and as of March 31, 2017, controlled its board of directors, which gave the Company the power to direct the activities of Elementum that most significantly impact its economic performance.  Accordingly, the Company recognized the carrying value of the noncontrolling interest as a component of total shareholders' equity, and the consolidated financial statements included the financial position and results of operations of Elementum as of and for the periods ended March 31, 2017 and 2016.

[0000866374-18-000007:notes:314]
During the second quarter of fiscal year 2018, the Company and other minority shareholders of Elementum amended certain agreements resulting in joint control of the board of directors between the Company and other non-controlling interest holders.  As a result, the Company concluded it is no longer the primary beneficiary of Elementum and accordingly, deconsolidated the entity.  The Company no longer recognizes the carrying value of the noncontrolling interest as a component of total shareholder’s equity resulting in a reduction of $90.6 million of noncontrolling interest from its consolidated balance sheet upon deconsolidation. Further, the Company derecognized approximately $72.6 million of cash of Elementum as of the date of deconsolidation which is reflected as an outflow from investing activities within other investing activities, net in the consolidated statement of cash flows for the year ended March 31, 2018.  There were no other material impacts to the consolidated balance sheet or consolidated cash flows resulting from deconsolidation of the entity.  The noncontrolling interest in the operating losses of Elementum prior to deconsolidation is immaterial for all periods presented and is classified as a component of interest and other, net, in the Company's consolidated statements of operations.

[0000866374-18-000007:notes:315]
The carrying amount of the Company’s variable interest in Elementum was approximately $124.6 million as of March 31, 2018, is accounted for as a cost method investment, and is included in other assets on the consolidated balance sheet.  The value of the Company’s variable interest on the date of deconsolidation was based on management’s estimate of the fair value of Elementum at that time.  The Company concluded that the market approach was the most appropriate method to determine the fair value of the entity on the date of deconsolidation, given that Elementum raised equity funding from third-party investors around the same period (i.e., level 2 inputs).  The Company recognized a gain on deconsolidation of approximately $151.6 million with no related tax impact, which is included in other charges (income), net on the consolidated statement of operations.  As the Company is not obligated to fund future losses of Elementum, the carrying amount is the Company’s maximum risk of loss.  Pro-forma financials have not been presented because the effects were not material to the Company’s consolidated financial position and results of operation for all periods presented.  Elementum remains a related party to the Company after deconsolidation and transactions between the Company and Elementum during the year ended March 31, 2018 were immaterial.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-18-000007:notes:316]
ORGANIZATION OF THE COMPANY

[0000866374-18-000007:notes:317]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and enterprise products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

[0000866374-18-000007:notes:318]
| • | Communications & Enterprise Compute ("CEC"), which includes telecom business of radio access base stations, remote radio heads, and small cells for wireless infrastructure; networking business which includes optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions; |

[0000866374-18-000007:notes:319]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion and apparel, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

[0000866374-18-000007:notes:320]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, electric vehicle infrastructure, smart solar energy, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation, and kiosks; and |

[0000866374-18-000007:notes:321]
| • | High Reliability Solutions ("HRS"), which is comprised of health solutions business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies. |

[0000866374-18-000007:notes:322]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-18-000007:notes:323]
OTHER CHARGES (INCOME), NET

[0000866374-18-000007:notes:324]
The fiscal year ended March 31, 2018 includes a $151.6 million gain from the deconsolidation of Elementum, and a $38.7 million gain from the sale of Wink. See note 6 for additional information on the deconsolidation of Elementum and note 2 for additional information on the sale of Wink. The above gains are partially offset by $21.9 million of impairment recognized during fiscal year 2018 for certain non-core investments. No other components of other charges and income, net incurred during fiscal year 2018 were material.

[0000866374-18-000007:notes:325]
The fiscal year ended March 31, 2017 includes a $7.4 million loss attributable to a non-strategic facility sold during the second quarter of fiscal year 2017. No other components of other charges and income, net incurred during fiscal year 2017 were material.

[0000866374-18-000007:notes:326]
During fiscal year 2016, the Company incurred net losses of $47.7 million primarily due to a $26.8 million loss on the disposition of a non-strategic Western European manufacturing facility, which included a non-cash foreign currency translation loss of $25.3 million, and a $21.8 million loss from the impairment of a non-core investment offset by immaterial currency translation gains.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000866374-18-000007:notes:327]
QUARTERLY FINANCIAL DATA (UNAUDITED)

[0000866374-18-000007:notes:328]
The Company's third fiscal quarter ends on December 31, and the fourth fiscal quarter and year ends on March 31 of each year. The first fiscal quarters of 2018 and 2017 ended on June 30, 2017 and July 1, 2016, respectively, and the second fiscal quarters of 2018 and 2017, ended on September 29, 2017 and September 30, 2016, respectively.

[0000866374-18-000007:notes:329]
The following table contains unaudited quarterly financial data for fiscal years 2018 and 2017.

[0000866374-18-000007:notes:330]
|  | Fiscal Year Ended March 31, 2018 |  | Fiscal Year Ended March 31, 2017 |
|  | First |  | Second |  | Third |  | Fourth (2) |  | First |  | Second (3) |  | Third |  | Fourth |
| Net sales | $ | 6,008,272 |  |  | $ | 6,270,420 |  |  | $ | 6,751,552 |  |  | $ | 6,410,887 |  |  | $ | 5,876,813 |  |  | $ | 6,008,525 |  |  | $ | 6,114,999 |  |  | $ | 5,862,597 |  |
| Gross profit | 406,932 |  |  | 393,325 |  |  | 446,328 |  |  | 349,297 |  |  | 405,995 |  |  | 313,691 |  |  | 416,455 |  |  | 384,804 |  |
| Net income (loss) (1) | 124,710 |  |  | 205,086 |  |  | 118,333 |  |  | (19,595 | ) |  | 105,729 |  |  | (2,508 | ) |  | 129,469 |  |  | 86,874 |  |
| Earnings (losses) per share (4): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.24 |  |  | $ | 0.39 |  |  | $ | 0.22 |  |  | $ | (0.04 | ) |  | $ | 0.19 |  |  | $ | 0.00 |  |  | $ | 0.24 |  |  | $ | 0.16 |  |
| Diluted | $ | 0.23 |  |  | $ | 0.38 |  |  | $ | 0.22 |  |  | $ | (0.04 | ) |  | $ | 0.19 |  |  | $ | 0.00 |  |  | $ | 0.24 |  |  | $ | 0.16 |  |

[0000866374-18-000007:notes:331]
| (1) | Net income for the first quarter of fiscal year 2018 was affected by a $38.7 million gain recognized for the disposition of Wink. Refer to note 2 for additional information. Net income for the second quarter of fiscal year 2018 was affected by $151.6 million non-cash gain as a result of the deconsolidation of our investment in Elementum. Refer to note 6 for further details on the deconsolidation. |

[0000866374-18-000007:notes:332]
| (2) | The Company recorded restructuring charges during the fourth quarter of fiscal year 2018. The Company classified approximately $58.9 million of these charges as a component of cost of sales and approximately $23.8 million of these charges as a component of selling, general and administrative expenses. Refer to note 15 for additional information on these charges. |

[0000866374-18-000007:notes:333]
| (3) | Gross profit and net income for the second quarter of fiscal year 2017 was affected by $92.9 million of SunEdison bankruptcy related charges, as further described in note 2. |

[0000866374-18-000007:notes:334]
| (4) | Earnings per share are computed independently for each quarter presented; therefore, the sum of the quarterly earnings per share may not equal the total earnings per share amounts for the fiscal year. |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-18-000007:notes:335]
RESTRUCTURING CHARGES

[0000866374-18-000007:notes:336]
Fiscal Year 2018

[0000866374-18-000007:notes:337]
During fiscal year 2018, the Company initiated targeted restructuring activities focused on optimizing our cost structure in lower growth areas and, more importantly, streamlining certain corporate and segment functions. Restructuring charges are recorded based upon employee termination dates, site closure and consolidation plans generally in conjunction with an overall corporate initiative to drive cost reduction and realign the Company's global footprint. The Company recognized approximately $78.6 million of cash charges predominantly related to related to employee severance costs and $12.1 million of non-cash charges for asset impairment and other exit charges under the above plan. Of these total charges, approximately $66.8 million was recognized in cost of sales. Employee severance costs were associated with the terminations of 6,203 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 5,336, 741 and 126 for the Americas, Asia and Europe, respectively. A majority of the fiscal year 2018 restructuring activities were completed as of March 31, 2018.

[0000866374-18-000007:notes:338]
Restructuring charges are not included in segment income, as disclosed further in note 20.

[0000866374-18-000007:notes:339]
The components of the restructuring charges by geographic region incurred in fiscal year 2018 are as follows:

[0000866374-18-000007:notes:340]
|  | Second Quarter |  | Fourth Quarter |  | Total |
|  | (In thousands) |
| Americas: |  |  |  |  |  |
| Severance | $ | 6,031 |  |  | $ | 36,973 |  |  | $ | 43,004 |  |
| Long-Lived Asset Impairment | — |  |  | 9,417 |  |  | 9,417 |  |
| Other Exit Costs | — |  |  | 11,835 |  |  | 11,835 |  |
| Total | 6,031 |  |  | 58,225 |  |  | 64,256 |  |
| Asia: |  |  |  |  |  |
| Severance | 1,950 |  |  | 14,590 |  |  | 16,540 |  |
| Long-Lived Asset Impairment | — |  |  | — |  |  | — |  |
| Other Exit Costs | — |  |  | — |  |  | — |  |
| Total | 1,950 |  |  | 14,590 |  |  | 16,540 |  |
| Europe: |  |  |  |  |  |
| Severance | — |  |  | 9,895 |  |  | 9,895 |  |
| Long-Lived Asset Impairment | — |  |  | — |  |  | — |  |
| Other Exit Costs | — |  |  | — |  |  | — |  |
| Total | — |  |  | 9,895 |  |  | 9,895 |  |
| Total |  |  |  |  |  |
| Severance | 7,981 |  |  | 61,458 |  |  | 69,439 |  |
| Long-Lived Asset Impairment | — |  |  | 9,417 |  |  | 9,417 |  |
| Other Exit Costs | — |  |  | 11,835 |  |  | 11,835 |  |
| Total restructuring charges | $ | 7,981 |  |  | $ | 82,710 |  |  | $ | 90,691 |  |

[0000866374-18-000007:notes:341]
Fiscal Year 2017

[0000866374-18-000007:notes:342]
During fiscal year 2017, the Company initiated a restructuring plan to accelerate its ability to support more Sketch-to-Scaletm efforts across the Company and reposition away from historical legacy programs and structures through rationalizing its current footprint at existing sites and at corporate SG&A functions. The Company recognized restructuring charges of approximately $49.4 million primarily for employee termination costs under the above plan. Of these total charges, approximately $38.8 million was recognized in cost of sales. Employee severance costs were associated with the terminations of 4,311 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 2,229, 1,988 and 94 for Asia, the Americas and Europe, respectively. All fiscal year 2017 restructuring activities were completed as of March 31, 2017. There were no material restructuring activities during fiscal year 2016.

[0000866374-18-000007:notes:343]
The components of the restructuring charges by geographic region incurred in fiscal year 2017 were as follows:

[0000866374-18-000007:notes:344]
|  | Second Quarter |  | Third Quarter |  | Fourth Quarter |  | Total |
|  | (In thousands) |
| Americas: |  |  |  |  |  |  |  |
| Severance | $ | 10,822 |  |  | $ | 6,263 |  |  | $ | 7,623 |  |  | $ | 24,708 |  |
| Contractual obligations | — |  |  | 489 |  |  | 3,353 |  |  | 3,842 |  |
| Total | 10,822 |  |  | 6,752 |  |  | 10,976 |  |  | 28,550 |  |
| Asia: |  |  |  |  |  |  |  |
| Severance | 263 |  |  | 9,701 |  |  | 5,110 |  |  | 15,074 |  |
| Contractual obligations | — |  |  | — |  |  | — |  |  | — |  |
| Total | 263 |  |  | 9,701 |  |  | 5,110 |  |  | 15,074 |  |
| Europe: |  |  |  |  |  |  |  |
| Severance | 454 |  |  | 968 |  |  | 1,049 |  |  | 2,471 |  |
| Contractual obligations | — |  |  | — |  |  | 3,300 |  |  | 3,300 |  |
| Total | 454 |  |  | 968 |  |  | 4,349 |  |  | 5,771 |  |
| Total |  |  |  |  |  |  |  |
| Severance | 11,539 |  |  | 16,932 |  |  | 13,782 |  |  | 42,253 |  |
| Contractual obligations | — |  |  | 489 |  |  | 6,653 |  |  | 7,142 |  |
| Total restructuring charges | $ | 11,539 |  |  | $ | 17,421 |  |  | $ | 20,435 |  |  | $ | 49,395 |  |

[0000866374-18-000007:notes:345]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of March 31, 2018 for charges incurred in fiscal years 2018, 2017 and 2016 and prior periods:

[0000866374-18-000007:notes:346]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
| Balance as of April 1, 2015 | 13,363 |  |  | — |  |  | 1,694 |  |  | 15,057 |  |
| Cash payments for charges incurred in fiscal year 2016 and prior | (1,458 | ) |  | — |  |  | (359 | ) |  | (1,817 | ) |
| Balance as of March 31, 2016 | 11,905 |  |  | — |  |  | 1,335 |  |  | 13,240 |  |
| Provision for charges incurred in fiscal year 2017 | 42,253 |  |  | — |  |  | 7,142 |  |  | 49,395 |  |
| Cash payments for charges incurred in fiscal year 2017 | (25,894 | ) |  | — |  |  | — |  |  | (25,894 | ) |
| Cash payments for charges incurred in fiscal year 2016 and prior | (11,905 | ) |  | — |  |  | (1,335 | ) |  | (13,240 | ) |
| Balance as of March 31, 2017 | 16,359 |  |  | — |  |  | 7,142 |  |  | 23,501 |  |
| Provision for charges incurred in fiscal year 2018 | 69,439 |  |  | 9,417 |  |  | 11,835 |  |  | 90,691 |  |
| Cash payments for charges incurred in fiscal year 2017 and prior | (13,237 | ) |  | — |  |  | (3,671 | ) |  | (16,908 | ) |
| Cash payments for charges incurred in fiscal year 2018 | (24,555 | ) |  | — |  |  | — |  |  | (24,555 | ) |
| Non-cash charges incurred in fiscal year 2018 | — |  |  | (9,417 | ) |  | (1,968 | ) |  | (11,385 | ) |
| Balance as of March 31, 2018 | 48,006 |  |  | — |  |  | 13,338 |  |  | 61,344 |  |
| Less: Current portion (classified as other current liabilities) | 48,006 |  |  | — |  |  | 13,338 |  |  | 61,344 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-18-000007:notes:347]
REVENUE RECOGNITION

[0000866374-18-000007:notes:348]
The Company recognizes manufacturing revenue when it ships goods or the goods are received by its customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then the Company recognizes the related revenues at the time when such requirements are completed, and the obligations are fulfilled. Some of the Company's customer contracts allow the recovery of certain costs related to manufacturing services that are over and above the prices charged for the related products. The Company determines the amount of costs that are recoverable based on agreements with those customers. Also, certain customer contracts contain commitments and obligations that may result in additional expenses or decreases in revenue. The Company accrues for these commitments and obligations based on facts and circumstances including historical practice and contractual terms. Please see additional details in the customer contract section below. The Company also makes provisions for estimated sales returns at the time revenue is recognized based upon contractual terms and an analysis of historical returns and adjustments. Provisions for sales returns were not material to the consolidated financial statements for any of the periods presented.

[0000866374-18-000007:notes:349]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The Company recognizes service revenue when the services have been performed, and the related costs are expensed as incurred. Sales for services were less than 10% of the Company's total sales for all periods presented, and accordingly, are included in net sales in the consolidated statements of operations. The Company recognized research and development costs primarily related to its design and innovations businesses of $78.2 million, $65.6 million, and $61.0 million for the fiscal years ended March 31, 2018, 2017 and 2016, respectively.

[0000866374-18-000007:notes:350]
Transition to ASC 606

[0000866374-18-000007:notes:351]
ASU 2014-09 “Revenue Contracts with Customers (Topic 606)” establishes a comprehensive framework for determining the nature, amount, timing and uncertainty of revenues and cash flows arising from a contract with a customer. Upon adoption of the new guidance, effective April 1, 2018 for Flex, the timing of revenue recognition for a portion of the Company’s business will change, resulting in the recognition of revenue for certain of the Company’s manufacturing services customer contracts earlier than under the previous recognition rules. Refer to note 2 for further detail about the impact to the Company upon adoption.

[0000866374-18-000007:notes:352]
Customer Contracts and Related Obligations

[0000866374-18-000007:notes:353]
The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc. On occasion, the level of business under those agreements is not guaranteed. In those instances, we bid on a program-by-program basis and typically receive customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work that embody the commitment by the customer.

[0000866374-18-000007:notes:354]
Certain of the Company’s customer agreements include terms that result in potential price adjustments. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually restricted to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company accrues for these contractual provisions as a reduction of revenues when incurred which generally approximates the same time that revenue for the portion of the arrangement that is not subject to such price adjustments is recognized. The Company determines the amounts to be accrued based on the amount of potential refund required by the contract, where applicable, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices in future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In some instances, the agreement might be silent on the settlement mechanism.  Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet, and disclosed as part of customer related accruals in note 2. Refer to note 2 for further details about other current liabilities.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0000866374-18-000007:notes:355]
|  | As of March 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Asia | $ | 747,314 |  |  | 33 | % |  | $ | 960,290 |  |  | 41 | % |
| Americas | 1,012,188 |  |  | 45 | % |  | 939,888 |  |  | 41 | % |
| Europe | 480,004 |  |  | 22 | % |  | 416,848 |  |  | 18 | % |
|  | $ | 2,239,506 |  |  |  |  | $ | 2,317,026 |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000866374-18-000007:notes:356]
Geographic information is as follows:

[0000866374-18-000007:notes:357]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 11,210,793 |  |  | 44 | % |  | $ | 10,962,075 |  |  | 46 | % |  | $ | 11,788,992 |  |  | 48 | % |
| Americas | 9,880,626 |  |  | 39 | % |  | 8,582,849 |  |  | 36 | % |  | 8,347,514 |  |  | 34 | % |
| Europe | 4,349,712 |  |  | 17 | % |  | 4,318,010 |  |  | 18 | % |  | 4,282,379 |  |  | 18 | % |
|  | $ | 25,441,131 |  |  |  |  | $ | 23,862,934 |  |  |  |  | $ | 24,418,885 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-18-000007:notes:358]
During fiscal year 2018, 2017 and 2016, depreciation expense included in the segments' measure of operating performance above is as follows:

[0000866374-18-000007:notes:359]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Depreciation expense |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 118,150 |  |  | $ | 133,057 |  |  | $ | 117,710 |  |
| Consumer Technologies Group | 110,276 |  |  | 110,379 |  |  | 123,139 |  |
| Industrial & Emerging Industries | 75,366 |  |  | 70,814 |  |  | 72,415 |  |
| High Reliability Solutions | 105,065 |  |  | 88,604 |  |  | 80,935 |  |
| Corporate and Other | 25,575 |  |  | 29,384 |  |  | 31,530 |  |
| Total depreciation expense | $ | 434,432 |  |  | $ | 432,238 |  |  | $ | 425,729 |  |

[0000866374-18-000007:notes:360]
Selected financial information by segment is as follows:

[0000866374-18-000007:notes:361]
|  | Fiscal Year Ended March 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 7,729,350 |  |  | $ | 8,383,420 |  |  | $ | 8,841,642 |  |
| Consumer Technologies Group | 6,969,821 |  |  | 6,362,338 |  |  | 6,997,526 |  |
| Industrial & Emerging Industries | 5,972,496 |  |  | 4,967,738 |  |  | 4,680,718 |  |
| High Reliability Solutions | 4,769,464 |  |  | 4,149,438 |  |  | 3,898,999 |  |
|  | $ | 25,441,131 |  |  | $ | 23,862,934 |  |  | $ | 24,418,885 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 186,335 |  |  | $ | 229,332 |  |  | $ | 265,076 |  |
| Consumer Technologies Group | 111,629 |  |  | 179,910 |  |  | 163,677 |  |
| Industrial & Emerging Industries | 235,422 |  |  | 179,749 |  |  | 157,588 |  |
| High Reliability Solutions | 380,878 |  |  | 334,108 |  |  | 294,635 |  |
| Corporate and Other | (127,810 | ) |  | (107,850 | ) |  | (89,219 | ) |
| Total income | 786,454 |  |  | 815,249 |  |  | 791,757 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 78,640 |  |  | 81,396 |  |  | 65,965 |  |
| Stock-based compensation | 85,244 |  |  | 82,266 |  |  | 77,580 |  |
| Distressed customers asset impairments (1) | 6,251 |  |  | 92,915 |  |  | 61,006 |  |
| Restructuring charges (2) | 90,691 |  |  | 49,395 |  |  | — |  |
| Contingencies and other (3) | 51,631 |  |  | 17,704 |  |  | — |  |
| Other charges (income), net | (169,719 | ) |  | 21,193 |  |  | 47,738 |  |
| Interest and other, net | 122,823 |  |  | 99,532 |  |  | 84,793 |  |
| Income before income taxes | $ | 520,893 |  |  | $ | 370,848 |  |  | $ | 454,675 |  |

[0000866374-18-000007:notes:362]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-18-000007:notes:363]
| (1) | During fiscal year 2016, the Company accepted return of previously shipped inventory from a former customer, SunEdison, Inc. ("SunEdison"), of approximately $90 million. On April 21, 2016, SunEdison filed a petition for reorganization under bankruptcy law, and as a result, the Company recognized a bad debt reserve of $61 million as of March 31, 2016, associated with its outstanding SunEdison receivables. |

[0000866374-18-000007:notes:364]
During fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand at the end of the fiscal year 2017 was not fully recoverable and recorded a charge of $60 million to reduce the carrying costs to market in fiscal year 2017. The Company also recognized a $16 million impairment charge for solar module equipment and $17 million primarily related to negative margin sales and other associated direct costs. The total charge of $93 million is included in cost of sales for fiscal year 2017 but is excluded from segment results above.

[0000866374-18-000007:notes:365]
| (2) | The Company initiated restructuring plans in fiscal years 2018 and 2017 and incurred charges primarily for employee terminations costs, as well as other asset impairments. These charges are split between cost of sales and selling, general and administration expenses on the Company's consolidated statement of operations, and are excluded from the measurement of the Company's operating segment's performance. Refer to note 15 for more details about our restructuring charges. |

[0000866374-18-000007:notes:366]
| (3) | During fiscal year 2018, the Company incurred charges in connection with the matters described in note 13 for certain loss contingencies where it believes that losses are probable and estimable; coupled with various other charges predominately related to damages incurred from a typhoon that impacted one of its China facilities. Additionally, certain assets impairments were recorded during both fiscal years 2018 and 2017. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-18-000007:notes:367]
SEGMENT REPORTING

[0000866374-18-000007:notes:368]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the Chief Operating Decision Maker ("CODM"), or a decision making group, in deciding how to allocate resources and in assessing performance. Resource allocation decisions and the Company's performance are assessed by its Chief Executive Officer ("CEO"), with support from his direct staff who oversee certain operations of the business, collectively identified as the CODM or the decision making group.

[0000866374-18-000007:notes:369]
The Company has four reportable segments: HRS, CTG, IEI, and CEC. These segments represent components of the Company for which separate financial information is available that is utilized on a regular basis by the CODM. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 for a description of the various product categories manufactured under each of these segments.

[0000866374-18-000007:notes:370]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, distressed customer charges, contingencies and other, restructuring charges, other charges (income), net and interest and other, net.

[0000866374-18-000007:notes:371]
Property and equipment on a segment basis is not disclosed as it is not separately identified and is not internally reported by segment to the Company's CODM. During fiscal year 2018, 2017 and 2016, depreciation expense included in the segments' measure of operating performance above is as follows:

[0000866374-18-000007:notes:372]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0000866374-18-000007:notes:373]
During fiscal years 2018, 2017 and 2016, net sales generated from Singapore, the principal country of domicile, were approximately $686.9 million, $595.3 million and $519.1 million, respectively.

[0000866374-18-000007:notes:374]
During fiscal year 2018, China, Mexico, the United States and Brazil accounted for approximately 29%, 17%, 11% and 10% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2018.

[0000866374-18-000007:notes:375]
During fiscal year 2017, China, Mexico, the United States and Malaysia accounted for approximately 30%, 17%, 11% and 10% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2017.

[0000866374-18-000007:notes:376]
During fiscal year 2016, China, Mexico, and the United States accounted for approximately 35%, 15% and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2016.

[0000866374-18-000007:notes:377]
As of March 31, 2018 and 2017, property and equipment, net held in Singapore were approximately $12.6 million and $13.2 million, respectively.

[0000866374-18-000007:notes:378]
As of March 31, 2018, Mexico, China and the United States accounted for approximately 26%, 22% and 14%, respectively, of property and equipment, net. No other country accounted for more than 10% of property and equipment, net as of March 31, 2018. The decrease in China's property and equipment is primarily driven by assets related to the Company's China-based Multek operations, which were classified as held for sale, as further described in note 18.

[0000866374-18-000007:notes:379]
As of March 31, 2017, China, Mexico and the United States accounted for approximately 31%, 23% and 13%, respectively, of property and equipment, net. No other country accounted for more than 10% of property and equipment, net as of March 31, 2017.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-18-000007:notes:380]
TRADE RECEIVABLES SECURITIZATION

[0000866374-18-000007:notes:381]
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-18-000007:notes:382]
Asset-Backed Securitization Programs

[0000866374-18-000007:notes:383]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the "Global Program") and its North American Asset-Backed Securitization Agreement (the "North American Program," collectively, the "ABS Programs") to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $950.0 million for the Global Program, of which $775.0 million is committed and $175.0 million is uncommitted, and $250.0 million for the North American Program, of which $210.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0000866374-18-000007:notes:384]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the fiscal years ended March 31, 2018, 2017 and 2016 were not material and are included in interest and other, net within the consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-18-000007:notes:385]
The Company's deferred purchase price receivables relating to its asset-backed securitization program are recorded initially at fair value based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not material. The interrelationship between these inputs is also insignificant.

[0000866374-18-000007:notes:386]
As of March 31, 2018 and 2017, the accounts receivable balances that were sold under the ABS Programs were removed from the consolidated balance sheets and the net cash proceeds received by the Company during fiscal years ended March 31, 2018, 2017 and 2016 were included as cash provided by operating activities in the consolidated statements of cash flows.

[0000866374-18-000007:notes:387]
As of March 31, 2018, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of $1.1 billion and deferred purchase price receivables of $445.4 million. As of March 31, 2017, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $1.0 billion and deferred purchase price receivables of $506.5 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of March 31, 2018 and 2017, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the consolidated statements of operations. Refer to note 17 for more details.

[0000866374-18-000007:notes:388]
For the fiscal years ended March 31, 2018, 2017 and 2016, cash flows from sales of receivables under the ABS Programs consisted of approximately $9.4 billion, $8.6 billion and $7.0 billion, respectively, for transfers of receivables, and approximately $3.2 billion, $4.0 billion and $4.2 billion, respectively, for collections on deferred purchase price receivables. The Company corrected previously reported disclosures related to these cash flows from sales of receivable under the ABS Programs by increasing by $2.9 billion and $1.8 billion, and the collections on deferred purchase price receivables by increasing such amounts by $0.7 billion and $0.6 billion for the fiscal years ended March 31, 2017 and 2016, respectively. The Company determined that these revisions are not material. The Company's cash flows from transfer of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfer were not significant for all periods presented.

[0000866374-18-000007:notes:389]
Trade Accounts Receivable Sale Programs

[0000866374-18-000007:notes:390]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $286.4 million and $225.2 million as of March 31, 2018 and 2017, respectively. For the years ended March 31, 2018, 2017 and 2016, total accounts receivables sold to certain third party banking institutions was approximately $1.5 billion, $1.3 billion and $2.3 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and were reflected as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-18-000007:notes:391]
SHARE REPURCHASE PLAN

[0000866374-18-000007:notes:392]
During fiscal year 2018, the Company repurchased approximately 10.8 million shares for an aggregate purchase value of approximately $180.0 million under two separate repurchase plans as further discussed below.

[0000866374-18-000007:notes:393]
During the first and second quarters of fiscal year 2018, the Company repurchased the entire remaining amount, or approximately 5.5 million shares for an aggregate purchase value of approximately $90.1 million, under the share repurchase plan that was approved by the Company's Board of Directors on August 24, 2016 and the Company's shareholders at the 2016 Annual General Meeting. The Company retired all of these shares.

[0000866374-18-000007:notes:394]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 15, 2017. During fiscal year 2018, the Company repurchased approximately 5.3 million shares for an aggregate purchase value of approximately $89.9 million under this plan, and retired all of these shares. As of March 31, 2018, shares in the aggregate amount of $410.1 million were available to be repurchased under the current plan.
