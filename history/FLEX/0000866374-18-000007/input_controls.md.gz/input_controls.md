# FLEX 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000866374-18-000007:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0000866374-18-000007:item_9a:2]
| (a) | Evaluation of Disclosure Controls and Procedures |

[0000866374-18-000007:item_9a:3]
The Company's management, with the participation of the Chief Executive Officer and Chief Financial Officer has evaluated the effectiveness of the Company's disclosure controls and procedures (as defined in Rule 13a-15(e) under the Exchange Act) as of March 31, 2018. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer concluded that, as of March 31, 2018, the Company's disclosure controls and procedures were not effective, as a result of the material weaknesses further described below, in ensuring that information required to be disclosed by the Company in reports that it files or submits under the Securities Exchange Act of 1934, as amended, is (i) recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms and (ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000866374-18-000007:item_9a:4]
Notwithstanding such material weaknesses, which is described below in Management’s Report on Internal Control over Financial Reporting, our management has concluded that the consolidated financial statements included in this Form 10-K present fairly, in all material respects, our financial position, results of operations and cash flows for the periods presented in conformity with accounting principles generally accepted in the United States of America.

[0000866374-18-000007:item_9a:5]
| (b) | Management's Annual Report on Internal Control over Financial Reporting |

[0000866374-18-000007:item_9a:6]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Rule 13a- 15(f) under the Securities Exchange Act of 1934, as amended. Internal control over financial reporting consists of policies and procedures that: (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (2) are designed and operated to provide reasonable assurance regarding the reliability of our financial reporting and our process for the preparation of financial statements for external purposes in accordance with generally accepted accounting principles and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of the Company’s assets that could have a material effect on the financial statements. Because of its inherent limitations, a system of internal control over financial reporting can provide only reasonable assurance and may not prevent or detect misstatements or prevent or detect instances of fraud. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of simple error or mistake. Additionally, controls may be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the control. The projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000866374-18-000007:item_9a:7]
As of March 31, 2018, under the supervision and with the participation of management, including the Company's Chief Executive Officer and Chief Financial Officer, an evaluation was conducted of the effectiveness of the Company's internal control over financial reporting based on the framework in Internal Control—Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO").

[0000866374-18-000007:item_9a:8]
Management's annual assessment of the effectiveness of our internal control over financial reporting as of March 31, 2018 excluded the internal control over financial reporting of one of our acquisitions that was completed during the year ended March 31, 2018, which constitutes less than 1% of both total assets and net sales of the consolidated financial statements amount as of, and for the fiscal year ended March 31, 2018.

[0000866374-18-000007:item_9a:9]
| (c) | Material Weaknesses Identified |

[0000866374-18-000007:item_9a:10]
Our management concluded that, as of the end of the period covered in this report, material weaknesses existed in our internal control over financial reporting. A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. These deficiencies resulted in a reasonable possibility that a material misstatement in our financial statements will not be prevented or detected on a timely basis and aggregated to material weaknesses in our internal control over financial reporting relating to the accounting for customer contractual obligations and aspects of our control environment and monitoring activities.

[0000866374-18-000007:item_9a:11]
We determined that there was insufficient documentation of, and ineffective design of controls over, the accounting for accrued customer obligations related to customer contracts.  Factors contributing to this included insufficient training of site and segment operational and accounting personnel, and inadequate monitoring, including contract compliance, to ensure the components of internal control were present and functioning properly.  In addition, the control environment was ineffective in ensuring that executive management’s expectations of adherence to the Company’s policies and standards of conduct were followed at all levels of the Company and in ensuring that any deviations therefrom were identified and corrected in a timely manner.

[0000866374-18-000007:item_9a:12]
As a result of these material weaknesses, our management has concluded that we did not maintain effective internal control over financial reporting as of March 31, 2018.

[0000866374-18-000007:item_9a:13]
The effectiveness of the Company's internal control over financial reporting as of March 31, 2018 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, as stated in their report which appears in this Item under the heading "Report of Independent Registered Public Accounting Firm."

[0000866374-18-000007:item_9a:14]
(d)  Remediation Efforts to Address Material Weaknesses

[0000866374-18-000007:item_9a:15]
Management is committed to the planning and implementation of remediation efforts to address the material weaknesses, as well as to foster continuous improvement in the Company’s internal controls. We have undertaken, and will continue to undertake, steps to improve our internal control over financial reporting to address and remediate the material weaknesses. The remediation efforts and actions to address the deficiencies identified above are summarized below. Some of these remediation efforts have been implemented already or are in the process of implementation, and the details to address the material weaknesses and to enhance our overall financial control environment will be finalized over the coming months. Our initiatives include:

[0000866374-18-000007:item_9a:16]
| • | Design and implement additional site level controls related to accounting for customer contractual obligations including criteria for effective contract reviews and approvals and documentation to evidence judgements and estimates. |

[0000866374-18-000007:item_9a:17]
| • | Designing and implementing a centralized Contract Management Office to determine the appropriate accounting and provide evidence of review for each material contract. |

[0000866374-18-000007:item_9a:18]
| • | Designing and implementing systematic centralized reporting controls that provide enhanced visibility to the accounting for customer contracts, which improve monitoring controls that are designed to prevent or detect material errors and help ensure that proper oversight is being provided related to certain decentralized activities. |

[0000866374-18-000007:item_9a:19]
| • | Enhancing the quality and frequency of training across all levels to improve awareness of Company policies and knowledge of the expected standards of conduct. |

[0000866374-18-000007:item_9a:20]
While this remediation plan is being executed, the Company has also engaged additional external resources to support and supplement the Company’s existing internal resources.

[0000866374-18-000007:item_9a:21]
Management believes these measures, when fully implemented and operational, will remediate the control deficiencies we have identified and strengthen our internal control over financial reporting. The material weaknesses in our internal control over financial reporting will not be considered remediated until the remediated controls operate for a sufficient period and management has concluded, through testing, that these controls are operating effectively. We are working to have the material weaknesses remediated as soon as possible. As we continue to evaluate and improve our internal control over financial reporting, we may take additional measures to address control deficiencies or modify or change the proposed remediation measures described above.

[0000866374-18-000007:item_9a:22]
(e)  Changes in Internal Control Over Financial Reporting

[0000866374-18-000007:item_9a:23]
There were no changes in our internal control over financial reporting that occurred during the fourth quarter ended March 31, 2018 that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.

[0000866374-18-000007:item_9a:24]
104

[0000866374-18-000007:item_9a:25]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000866374-18-000007:item_9a:26]
To the Board of Directors and Shareholders of Flex Ltd.

[0000866374-18-000007:item_9a:27]
Singapore

[0000866374-18-000007:item_9a:28]
Opinion on Internal Control over Financial Reporting

[0000866374-18-000007:item_9a:29]
We have audited the internal control over financial reporting of Flex Ltd. and subsidiaries (the "Company") as of March 31, 2018, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, because of the effect of the material weaknesses identified below on the achievement of the objectives of the control criteria, the Company has not maintained effective internal control over financial reporting as of March 31, 2018, based on the criteria established in Internal Control - Integrated Framework (2013) issued by COSO.

[0000866374-18-000007:item_9a:30]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States), the consolidated financial statements as of and for the year ended March 31, 2018, of the Company and our report dated June 14, 2018 expressed an unqualified opinion on those financial statements.

[0000866374-18-000007:item_9a:31]
As described in Management’s Annual Report on Internal Control over Financial Reporting, management excluded from its assessment the internal control over financial reporting of one acquisition completed during the year ended March 31, 2018, which constitutes less than 1% of both assets and net sales of the consolidated financial statements amount as of, and for the fiscal year ended March 31, 2018. Accordingly, our audit did not include the internal control over financial reporting of this acquisition.

[0000866374-18-000007:item_9a:32]
Basis for Opinion

[0000866374-18-000007:item_9a:33]
The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Annual Report on Internal Control over Financial Reporting.  Our responsibility is to express an opinion on the Company's internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000866374-18-000007:item_9a:34]
We conducted our audit in accordance with the standards of the PCAOB (United States).  Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects.  Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances.  We believe that our audit provides a reasonable basis for our opinion.

[0000866374-18-000007:item_9a:35]
Definition and Limitations of Internal Control over Financial Reporting

[0000866374-18-000007:item_9a:36]
A company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles.  A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

[0000866374-18-000007:item_9a:37]
Because of the inherent limitations, internal control over financial reporting, may not prevent or detect misstatements. Also, projections of any evaluation of the effectiveness to future periods are subject to the risk that the controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000866374-18-000007:item_9a:38]
Material Weaknesses

[0000866374-18-000007:item_9a:39]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the Company’s annual or interim financial statements will not be prevented or detected on a timely basis. The following material weaknesses have been identified and included in management’s assessment: There was insufficient documentation of, and ineffective design of controls over, the accounting for accrued customer obligations related to customer contracts. Factors contributing to this included insufficient training of site and segment operational and accounting personnel, and inadequate monitoring, including of contract compliance, to ensure the components of internal control were present and functioning properly. In addition, the control environment was ineffective in ensuring that executive management’s expectations of adherence to the Company’s policies and standards of conduct were followed at all levels of the Company and in ensuring that any deviations therefrom were identified and corrected in a timely manner. These material weaknesses were considered in determining the nature, timing, and extent of audit tests applied in our audit of the consolidated financial statements of the Company as of and for the year ended March 31, 2018 and this report does not affect our report on such financial statements.

[0000866374-18-000007:item_9a:40]
/s/ DELOITTE & TOUCHE LLP

[0000866374-18-000007:item_9a:41]
San Jose, California

[0000866374-18-000007:item_9a:42]
June 14, 2018

[0000866374-18-000007:item_9a:43]
106
