# FLEX notes — 0000866374-16-000007


## flex:InterestAndOtherNetTextBlock

[0000866374-16-000007:notes:1]
INTEREST AND OTHER, NET

[0000866374-16-000007:notes:2]
During the three-month and six-month periods ended September 30, 2016, the Company recognized interest expense of $26.5 million and $53.4 million, respectively, on its debt obligations outstanding during the periods. During the three-month and six-month periods ended September 25, 2015, the Company recognized interest expense of $25.1 million and $45.2 million, respectively.


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0000866374-16-000007:notes:3]
[same as prior period, unchanged from 0001628280-16-017813:notes:1]

[0000866374-16-000007:notes:4]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |  | September 30, 2016 |  | September 25, 2015 |
|  | (In thousands) |
| Beginning balance | $ | 460,334 |  |  | $ | 516,287 |  |  | $ | 501,097 |  |  | $ | 600,672 |  |
| Transfers of receivables | 760,540 |  |  | 983,677 |  |  | 1,522,724 |  |  | 1,750,725 |  |
| Collections | (759,330 | ) |  | (962,345 | ) |  | (1,562,277 | ) |  | (1,813,778 | ) |
| Ending balance | $ | 461,544 |  |  | $ | 537,619 |  |  | $ | 461,544 |  |  | $ | 537,619 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0000866374-16-000007:notes:5]
[same as prior period, unchanged from 0001628280-16-017813:notes:3]

[0000866374-16-000007:notes:6]
Flex Ltd. (“Parent”) has three tranches of Notes of $500 million, $500 million, and $600 million, respectively, each outstanding, which mature on February 15, 2020, February 15, 2023 and June 15, 2025, respectively. These Notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company’s 100% owned subsidiaries (the “guarantor subsidiaries”). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade, provided that each rating agency confirms that the Notes will continue to be rated investment grade after the Note Guaranties are terminated.

[0000866374-16-000007:notes:7]
[same as prior period, unchanged from 0001628280-16-017813:notes:5]

[0000866374-16-000007:notes:8]
Condensed Consolidating Balance Sheets as of September 30, 2016

[0000866374-16-000007:notes:9]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 823,435 |  |  | $ | 122,531 |  |  | $ | 591,090 |  |  | $ | — |  |  | $ | 1,537,056 |  |
| Accounts receivable | — |  |  | 941,596 |  |  | 1,399,797 |  |  | — |  |  | 2,341,393 |  |
| Inventories | — |  |  | 1,545,142 |  |  | 2,017,075 |  |  | — |  |  | 3,562,217 |  |
| Inter company receivable | 9,952,291 |  |  | 7,457,490 |  |  | 14,178,475 |  |  | (31,588,256 | ) |  | — |  |
| Other current assets | 2,947 |  |  | 179,553 |  |  | 835,454 |  |  | — |  |  | 1,017,954 |  |
| Total current assets | 10,778,673 |  |  | 10,246,312 |  |  | 19,021,891 |  |  | (31,588,256 | ) |  | 8,458,620 |  |
| Property and equipment, net | — |  |  | 576,336 |  |  | 1,759,623 |  |  | — |  |  | 2,335,959 |  |
| Goodwill and other intangible assets, net | 1,239 |  |  | 90,316 |  |  | 1,304,208 |  |  | — |  |  | 1,395,763 |  |
| Other assets | 2,224,133 |  |  | 276,072 |  |  | 2,001,421 |  |  | (4,030,834 | ) |  | 470,792 |  |
| Investment in subsidiaries | 2,739,759 |  |  | 3,274,766 |  |  | 17,932,399 |  |  | (23,946,924 | ) |  | — |  |
| Total assets | $ | 15,743,804 |  |  | $ | 14,463,802 |  |  | $ | 42,019,542 |  |  | $ | (59,566,014 | ) |  | $ | 12,661,134 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 58,836 |  |  | $ | 946 |  |  | $ | 6,187 |  |  | $ | — |  |  | $ | 65,969 |  |
| Accounts payable | — |  |  | 1,497,129 |  |  | 3,017,437 |  |  | — |  |  | 4,514,566 |  |
| Accrued payroll | — |  |  | 119,846 |  |  | 290,741 |  |  | — |  |  | 410,587 |  |
| Inter company payable | 10,416,283 |  |  | 10,238,176 |  |  | 10,933,797 |  |  | (31,588,256 | ) |  | — |  |
| Other current liabilities | 21,350 |  |  | 796,156 |  |  | 1,045,039 |  |  | — |  |  | 1,862,545 |  |
| Total current liabilities | 10,496,469 |  |  | 12,652,253 |  |  | 15,293,201 |  |  | (31,588,256 | ) |  | 6,853,667 |  |
| Long term liabilities | 2,685,469 |  |  | 2,058,750 |  |  | 2,489,774 |  |  | (4,030,834 | ) |  | 3,203,159 |  |
| Flex Ltd. shareholders’ equity (deficit) | 2,561,866 |  |  | (247,201 | ) |  | 24,194,125 |  |  | (23,946,924 | ) |  | 2,561,866 |  |
| Noncontrolling interests | — |  |  | — |  |  | 42,442 |  |  | — |  |  | 42,442 |  |
| Total shareholders’ equity (deficit) | 2,561,866 |  |  | (247,201 | ) |  | 24,236,567 |  |  | (23,946,924 | ) |  | 2,604,308 |  |
| Total liabilities and shareholders’ equity | $ | 15,743,804 |  |  | $ | 14,463,802 |  |  | $ | 42,019,542 |  |  | $ | (59,566,014 | ) |  | $ | 12,661,134 |  |

[0000866374-16-000007:notes:10]
[same as prior period, unchanged from 0001628280-16-017813:notes:8]

[0000866374-16-000007:notes:11]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 734,869 |  |  | $ | 148,201 |  |  | $ | 724,500 |  |  | $ | — |  |  | $ | 1,607,570 |  |
| Accounts receivable | — |  |  | 729,331 |  |  | 1,315,426 |  |  | — |  |  | 2,044,757 |  |
| Inventories | — |  |  | 1,482,410 |  |  | 2,009,246 |  |  | — |  |  | 3,491,656 |  |
| Inter company receivable | 9,105,728 |  |  | 5,568,392 |  |  | 12,404,722 |  |  | (27,078,842 | ) |  | — |  |
| Other current assets | 2,951 |  |  | 180,842 |  |  | 987,350 |  |  | — |  |  | 1,171,143 |  |
| Total current assets | 9,843,548 |  |  | 8,109,176 |  |  | 17,441,244 |  |  | (27,078,842 | ) |  | 8,315,126 |  |
| Property and equipment, net | — |  |  | 553,072 |  |  | 1,704,561 |  |  | — |  |  | 2,257,633 |  |
| Goodwill and other intangible assets, net | 175 |  |  | 60,895 |  |  | 1,284,750 |  |  | — |  |  | 1,345,820 |  |
| Other assets | 2,249,145 |  |  | 267,034 |  |  | 2,004,437 |  |  | (4,054,214 | ) |  | 466,402 |  |
| Investment in subsidiaries | 2,815,426 |  |  | 3,010,111 |  |  | 18,175,348 |  |  | (24,000,885 | ) |  | — |  |
| Total assets | $ | 14,908,294 |  |  | $ | 12,000,288 |  |  | $ | 40,610,340 |  |  | $ | (55,133,941 | ) |  | $ | 12,384,981 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 58,836 |  |  | $ | 946 |  |  | $ | 5,384 |  |  | $ | — |  |  | $ | 65,166 |  |
| Accounts payable | — |  |  | 1,401,835 |  |  | 2,846,457 |  |  | — |  |  | 4,248,292 |  |
| Accrued payroll | — |  |  | 114,509 |  |  | 239,038 |  |  | — |  |  | 353,547 |  |
| Inter company payable | 9,562,405 |  |  | 7,999,335 |  |  | 9,517,102 |  |  | (27,078,842 | ) |  | — |  |
| Other current liabilities | 33,008 |  |  | 869,470 |  |  | 1,002,722 |  |  | — |  |  | 1,905,200 |  |
| Total current liabilities | 9,654,249 |  |  | 10,386,095 |  |  | 13,610,703 |  |  | (27,078,842 | ) |  | 6,572,205 |  |
| Long term liabilities | 2,683,173 |  |  | 2,063,988 |  |  | 2,514,299 |  |  | (4,054,214 | ) |  | 3,207,246 |  |
| Flex Ltd. shareholders’ equity (deficit) | 2,570,872 |  |  | (449,795 | ) |  | 24,450,680 |  |  | (24,000,885 | ) |  | 2,570,872 |  |
| Noncontrolling interests | — |  |  | — |  |  | 34,658 |  |  | — |  |  | 34,658 |  |
| Total shareholders’ equity (deficit) | 2,570,872 |  |  | (449,795 | ) |  | 24,485,338 |  |  | (24,000,885 | ) |  | 2,605,530 |  |
| Total liabilities and shareholders’ equity | $ | 14,908,294 |  |  | $ | 12,000,288 |  |  | $ | 40,610,340 |  |  | $ | (55,133,941 | ) |  | $ | 12,384,981 |  |

[0000866374-16-000007:notes:12]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended September 30, 2016

[0000866374-16-000007:notes:13]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 3,991,248 |  |  | $ | 5,191,500 |  |  | $ | (3,174,223 | ) |  | $ | 6,008,525 |  |
| Cost of sales | — |  |  | 3,686,831 |  |  | 5,182,226 |  |  | (3,174,223 | ) |  | 5,694,834 |  |
| Gross profit | — |  |  | 304,417 |  |  | 9,274 |  |  | — |  |  | 313,691 |  |
| Selling, general and administrative expenses | — |  |  | 75,351 |  |  | 168,592 |  |  | — |  |  | 243,943 |  |
| Intangible amortization | 75 |  |  | 717 |  |  | 21,194 |  |  | — |  |  | 21,986 |  |
| Interest and other, net | 125,803 |  |  | 243,460 |  |  | (336,243 | ) |  | — |  |  | 33,020 |  |
| Income (loss) from continuing operations before income taxes | (125,878 | ) |  | (15,111 | ) |  | 155,731 |  |  | — |  |  | 14,742 |  |
| Provision for income taxes | 11 |  |  | 2,476 |  |  | 14,763 |  |  | — |  |  | 17,250 |  |
| Equity in earnings in subsidiaries | 123,381 |  |  | (63,394 | ) |  | (52,231 | ) |  | (7,756 | ) |  | — |  |
| Net income (loss) | $ | (2,508 | ) |  | $ | (80,981 | ) |  | $ | 88,737 |  |  | $ | (7,756 | ) |  | $ | (2,508 | ) |

[0000866374-16-000007:notes:14]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended September 25, 2015

[0000866374-16-000007:notes:15]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 4,482,213 |  |  | $ | 5,514,535 |  |  | $ | (3,679,986 | ) |  | $ | 6,316,762 |  |
| Cost of sales | — |  |  | 4,141,254 |  |  | 5,458,578 |  |  | (3,679,986 | ) |  | 5,919,846 |  |
| Gross profit | — |  |  | 340,959 |  |  | 55,957 |  |  | — |  |  | 396,916 |  |
| Selling, general and administrative expenses | — |  |  | 66,682 |  |  | 150,114 |  |  | — |  |  | 216,796 |  |
| Intangible amortization | 75 |  |  | 960 |  |  | 15,092 |  |  | — |  |  | 16,127 |  |
| Interest and other, net | (131,637 | ) |  | 277,002 |  |  | (121,652 | ) |  | — |  |  | 23,713 |  |
| Income (loss) from continuing operations before income taxes | 131,562 |  |  | (3,685 | ) |  | 12,403 |  |  | — |  |  | 140,280 |  |
| Provision for (benefit from) income taxes | — |  |  | (5,658 | ) |  | 22,961 |  |  | — |  |  | 17,303 |  |
| Equity in earnings in subsidiaries | (8,585 | ) |  | (33,421 | ) |  | 16,794 |  |  | 25,212 |  |  | — |  |
| Net income (loss) | $ | 122,977 |  |  | $ | (31,448 | ) |  | $ | 6,236 |  |  | $ | 25,212 |  |  | $ | 122,977 |  |

[0000866374-16-000007:notes:16]
Condensed Consolidating Statements of Operations for the Six-Month Period Ended September 30, 2016

[0000866374-16-000007:notes:17]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 7,821,600 |  |  | $ | 9,528,146 |  |  | $ | (5,464,408 | ) |  | $ | 11,885,338 |  |
| Cost of sales | — |  |  | 7,100,113 |  |  | 9,529,947 |  |  | (5,464,408 | ) |  | 11,165,652 |  |
| Gross profit | — |  |  | 721,487 |  |  | (1,801 | ) |  | — |  |  | 719,686 |  |
| Selling, general and administrative expenses | — |  |  | 145,321 |  |  | 338,168 |  |  | — |  |  | 483,489 |  |
| Intangible amortization | 150 |  |  | 1,434 |  |  | 42,000 |  |  | — |  |  | 43,584 |  |
| Interest and other, net | (190,588 | ) |  | 659,777 |  |  | (408,241 | ) |  | — |  |  | 60,948 |  |
| Income (loss) from continuing operations before income taxes | 190,438 |  |  | (85,045 | ) |  | 26,272 |  |  | — |  |  | 131,665 |  |
| Provision for income taxes | 11 |  |  | 3,070 |  |  | 25,363 |  |  | — |  |  | 28,444 |  |
| Equity in earnings in subsidiaries | (87,206 | ) |  | (64,121 | ) |  | (74,336 | ) |  | 225,663 |  |  | — |  |
| Net income (loss) | $ | 103,221 |  |  | $ | (152,236 | ) |  | $ | (73,427 | ) |  | $ | 225,663 |  |  | $ | 103,221 |  |

[0000866374-16-000007:notes:18]
Condensed Consolidating Statements of Operations for the Six-Month Period Ended September 25, 2015

[0000866374-16-000007:notes:19]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 8,528,598 |  |  | $ | 9,450,050 |  |  | $ | (6,095,638 | ) |  | $ | 11,883,010 |  |
| Cost of sales | — |  |  | 7,785,313 |  |  | 9,444,078 |  |  | (6,095,638 | ) |  | 11,133,753 |  |
| Gross profit | — |  |  | 743,285 |  |  | 5,972 |  |  | — |  |  | 749,257 |  |
| Selling, general and administrative expenses | — |  |  | 130,238 |  |  | 295,943 |  |  | — |  |  | 426,181 |  |
| Intangible amortization | 150 |  |  | 1,921 |  |  | 21,727 |  |  | — |  |  | 23,798 |  |
| Interest and other, net | (397,020 | ) |  | 613,414 |  |  | (176,012 | ) |  | — |  |  | 40,382 |  |
| Income (loss) from continuing operations before income taxes | 396,870 |  |  | (2,288 | ) |  | (135,686 | ) |  | — |  |  | 258,896 |  |
| Provision for income taxes | — |  |  | 3,441 |  |  | 21,628 |  |  | — |  |  | 25,069 |  |
| Equity in earnings in subsidiaries | (163,043 | ) |  | (51,830 | ) |  | 52,755 |  |  | 162,118 |  |  | — |  |
| Net income (loss) | $ | 233,827 |  |  | $ | (57,559 | ) |  | $ | (104,559 | ) |  | $ | 162,118 |  |  | $ | 233,827 |  |

[0000866374-16-000007:notes:20]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended September 30, 2016

[0000866374-16-000007:notes:21]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | (2,508 | ) |  | $ | (80,981 | ) |  | $ | 88,737 |  |  | $ | (7,756 | ) |  | $ | (2,508 | ) |
| Other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 4,213 |  |  | (7,528 | ) |  | (3,368 | ) |  | 10,896 |  |  | 4,213 |  |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax | (2,059 | ) |  | 1,050 |  |  | (2,059 | ) |  | 1,009 |  |  | (2,059 | ) |
| Comprehensive income (loss) | $ | (354 | ) |  | $ | (87,459 | ) |  | $ | 83,310 |  |  | $ | 4,149 |  |  | $ | (354 | ) |

[0000866374-16-000007:notes:22]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended September 25, 2015

[0000866374-16-000007:notes:23]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 122,977 |  |  | $ | (31,448 | ) |  | $ | 6,236 |  |  | $ | 25,212 |  |  | $ | 122,977 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (30,267 | ) |  | (33,696 | ) |  | (30,633 | ) |  | 64,329 |  |  | (30,267 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax | (5,544 | ) |  | 1,160 |  |  | (5,544 | ) |  | 4,384 |  |  | (5,544 | ) |
| Comprehensive income (loss) | $ | 87,166 |  |  | $ | (63,984 | ) |  | $ | (29,941 | ) |  | $ | 93,925 |  |  | $ | 87,166 |  |

[0000866374-16-000007:notes:24]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Six-Month Period Ended September 30, 2016

[0000866374-16-000007:notes:25]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 103,221 |  |  | $ | (152,236 | ) |  | $ | (73,427 | ) |  | $ | 225,663 |  |  | $ | 103,221 |  |
| Other comprehensive income (loss): | 0 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 14,074 |  |  | 10,181 |  |  | 21,395 |  |  | (31,576 | ) |  | 14,074 |  |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax | (711 | ) |  | 3,500 |  |  | (711 | ) |  | (2,789 | ) |  | (711 | ) |
| Comprehensive income (loss) | $ | 116,584 |  |  | $ | (138,555 | ) |  | $ | (52,743 | ) |  | $ | 191,298 |  |  | $ | 116,584 |  |

[0000866374-16-000007:notes:26]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Six-Month Period Ended September 25, 2015

[0000866374-16-000007:notes:27]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 233,827 |  |  | $ | (57,559 | ) |  | $ | (104,559 | ) |  | $ | 162,118 |  |  | $ | 233,827 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (27,484 | ) |  | (57,186 | ) |  | (51,530 | ) |  | 108,716 |  |  | (27,484 | ) |
| Unrealized gain on derivative instruments and other, net of zero tax | 7,285 |  |  | 5,785 |  |  | 7,285 |  |  | (13,070 | ) |  | 7,285 |  |
| Comprehensive income (loss) | $ | 213,628 |  |  | $ | (108,960 | ) |  | $ | (148,804 | ) |  | $ | 257,764 |  |  | $ | 213,628 |  |

[0000866374-16-000007:notes:28]
Condensed Consolidating Statements of Cash Flows for the Six-Month Period Ended September 30, 2016

[0000866374-16-000007:notes:29]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 157,337 |  |  | $ | (390,057 | ) |  | $ | 776,305 |  |  | $ | (33 | ) |  | $ | 543,552 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (92,393 | ) |  | (186,982 | ) |  | — |  |  | (279,375 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | (80,339 | ) |  | (109,556 | ) |  | — |  |  | (189,895 | ) |
| Proceeds from divestiture of businesses, net of cash held in divested businesses | — |  |  | 20,500 |  |  | 15,573 |  |  | — |  |  | 36,073 |  |
| Investing cash flows to affiliates | (426,040 | ) |  | (2,041,309 | ) |  | (669,967 | ) |  | 3,137,316 |  |  | — |  |
| Other investing activities, net | (1,213 | ) |  | (7,051 | ) |  | 28,621 |  |  | — |  |  | 20,357 |  |
| Net cash used in investing activities | (427,253 | ) |  | (2,200,592 | ) |  | (922,311 | ) |  | 3,137,316 |  |  | (412,840 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 74,944 |  |  | — |  |  | 91 |  |  | — |  |  | 75,035 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (105,000 | ) |  | (3,491 | ) |  | (2,101 | ) |  |  |  |  | (110,592 | ) |
| Payments for repurchases of ordinary shares | (184,698 | ) |  | — |  |  | — |  |  | — |  |  | (184,698 | ) |
| Net proceeds from issuance of ordinary shares | 11,344 |  |  | — |  |  | — |  |  | — |  |  | 11,344 |  |
| Financing cash flows from affiliates | 539,454 |  |  | 2,581,240 |  |  | 16,589 |  |  | (3,137,283 | ) |  | — |  |
| Other financing activities, net | 30,000 |  |  | (11,347 | ) |  | (25,489 | ) |  | — |  |  | (6,836 | ) |
| Net cash provided by financing activities | 366,044 |  |  | 2,566,402 |  |  | (10,910 | ) |  | (3,137,283 | ) |  | (215,747 | ) |
| Effect of exchange rates on cash and cash equivalents | (7,562 | ) |  | (1,423 | ) |  | 23,506 |  |  | — |  |  | 14,521 |  |
| Net increase (decrease) in cash and cash equivalents | 88,566 |  |  | (25,670 | ) |  | (133,410 | ) |  | — |  |  | (70,514 | ) |
| Cash and cash equivalents, beginning of period | 734,869 |  |  | 148,201 |  |  | 724,500 |  |  | — |  |  | 1,607,570 |  |
| Cash and cash equivalents, end of period | $ | 823,435 |  |  | $ | 122,531 |  |  | $ | 591,090 |  |  | $ | — |  |  | $ | 1,537,056 |  |

[0000866374-16-000007:notes:30]
Condensed Consolidating Statements of Cash Flows for the Six-Month Period Ended September 25, 2015

[0000866374-16-000007:notes:31]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 389,949 |  |  | $ | (248,082 | ) |  | $ | 520,128 |  |  | $ | — |  |  | $ | 661,995 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (88,699 | ) |  | (205,330 | ) |  | 11 |  |  | (294,018 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | (559,442 | ) |  | (82,471 | ) |  | — |  |  | (641,913 | ) |
| Investing cash flows from (to) affiliates | (1,326,493 | ) |  | (836,415 | ) |  | (1,194,368 | ) |  | 3,357,276 |  |  | — |  |
| Other investing activities, net | — |  |  | (22,822 | ) |  | 12,306 |  |  | — |  |  | (10,516 | ) |
| Net cash used in investing activities | (1,326,493 | ) |  | (1,507,378 | ) |  | (1,469,863 | ) |  | 3,357,287 |  |  | (946,447 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 595,309 |  |  | 209 |  |  | 35 |  |  | — |  |  | 595,553 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (17,507 | ) |  | (1,039 | ) |  | (2,544 | ) |  | — |  |  | (21,090 | ) |
| Payments for repurchases of ordinary shares | (241,978 | ) |  | — |  |  | — |  |  | — |  |  | (241,978 | ) |
| Net proceeds from issuance of ordinary shares | 49,074 |  |  | — |  |  | — |  |  | — |  |  | 49,074 |  |
| Financing cash flows from affiliates | 435,540 |  |  | 1,811,532 |  |  | 1,110,215 |  |  | (3,357,287 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | (37,872 | ) |  | — |  |  | (37,872 | ) |
| Net cash provided by financing activities | 820,438 |  |  | 1,810,702 |  |  | 1,069,834 |  |  | (3,357,287 | ) |  | 343,687 |  |
| Effect of exchange rates on cash and cash equivalents | 24,766 |  |  | 2,955 |  |  | (46,937 | ) |  | — |  |  | (19,216 | ) |
| Net decrease (increase) in cash and cash equivalents | (91,340 | ) |  | 58,197 |  |  | 73,162 |  |  | — |  |  | 40,019 |  |
| Cash and cash equivalents, beginning of period | 608,971 |  |  | 168,272 |  |  | 851,165 |  |  | — |  |  | 1,628,408 |  |
| Cash and cash equivalents, end of period | $ | 517,631 |  |  | $ | 226,469 |  |  | $ | 924,327 |  |  | $ | — |  |  | $ | 1,668,427 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-16-000007:notes:32]
BUSINESS AND ASSET ACQUISITIONS & DIVESTITURES

[0000866374-16-000007:notes:33]
Business and asset acquisitions

[0000866374-16-000007:notes:34]
During the six-month period ended September 30, 2016, the Company completed three acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. Most notably is the Company’s acquisition of two manufacturing and development facilities from Bose Corporation (“Bose”), a global leader in audio systems. The acquisition expanded the Company’s capabilities in the audio market and is included in the CTG segment. The other acquired businesses strengthen the Company's capabilities in the energy market within the IEI segment. The Company paid a total of $189.3 million, net of cash acquired, of which $171.6 million, net of $17.8 million of cash acquired is related to the Bose acquisition. The Company acquired primarily $73.6 million of inventory, $66.8 million of property and equipment, recorded goodwill of $52.8 million and intangible assets of $44.9 million substantially related to Bose. The intangibles will amortize over a weighted-average estimated useful life of 7.4 years. In connection with these acquisitions, the Company assumed $57.5 million in other liabilities including additional consideration of $28.0 million payable to Bose by the end of fiscal year 2017. Further, the equity incentive plan of one of the acquirees was assumed as part of the acquisition.

[0000866374-16-000007:notes:35]
The results of operations for each of the acquisitions completed in fiscal year 2017, including the Bose acquisition, were included in the Company’s consolidated financial results beginning on the date of each acquisition, and the total amount of net income and revenue of the acquisitions, collectively, were immaterial to the Company's consolidated financial results for the three-month and six-month periods ended September 30, 2016. Pro-forma results of operations for the acquisitions completed in fiscal year 2017 have not been presented because the effects, individually and in the aggregate, were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-16-000007:notes:36]
The total amount of net income and revenue for the acquisitions completed in fiscal year 2016, collectively, was not material to the Company’s consolidated financial results for the three-month and six-month period ended September 30, 2016. On a pro-forma basis, and assuming the fiscal year 2016 acquisitions occurred on the first day of that fiscal year, or April 1, 2015, the Company's net income would have been estimated to be $130.1 million and $243.1 million for the three-month and six-month periods ended September 25, 2015, respectively. Pro-forma revenue for the acquisitions in fiscal year 2016 has not been presented because the effect, collectively, was not material to the Company’s consolidated revenues for all periods presented.

[0000866374-16-000007:notes:37]
The Company is in the process of evaluating the fair value of the assets and liabilities related to business combinations completed during fiscal year 2017. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisition. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the respective measurement periods.

[0000866374-16-000007:notes:38]
Divestitures

[0000866374-16-000007:notes:39]
During the six-month period ended September 30, 2016, the Company disposed of two non-strategic businesses within the HRS and IEI segments. The Company received $33.0 million of proceeds, net of an immaterial amount of cash held in one of the divested businesses. The property and equipment and various other assets sold, and liabilities transferred were not material to the Company's consolidated financial results. The loss on disposition was not material to the Company’s consolidated financial results, and is included in other charges, net in the condensed consolidated statements of operations for the six-month period ended September 30, 2016.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-16-000007:notes:40]
COMMITMENTS AND CONTINGENCIES

[0000866374-16-000007:notes:41]
Litigation and other legal matters

[0000866374-16-000007:notes:42]
During the third quarter of fiscal year 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice was for nine months of calendar year 2010 for an alleged amount of 52 million Brazilian reals (approximately USD $16 million based on the exchange rate as of September 30, 2016) plus interest. This assessment is in the second stage of the review process at the administrative level. During the fourth quarter of fiscal year 2016, the same Brazilian subsidiary received a further assessment related to the same import taxes of an additional 57 million Brazilian reals (approximately USD $18 million based on the exchange rate as of September 30, 2016) plus interest. This assessment is in the first stage of the review process at the administrative level. The Company plans to continue to vigorously oppose both of these assessments, as well as any future assessments. The Company is unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on either of these claims for several years.

[0000866374-16-000007:notes:43]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately USD $100 million related to income and social contribution taxes, interest and penalties. During the first quarter of fiscal year 2017, the Company received a final favorable judgment in the judicial process reversing the assessment and the case is now closed. As the Company had previously determined there was no legal basis for the assessment, no adjustment was required to be recorded during the first quarter of fiscal year 2017.

[0000866374-16-000007:notes:44]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-16-000007:notes:45]
[same as prior period, unchanged from 0001628280-16-017813:notes:36]

[0000866374-16-000007:notes:46]
[same as prior period, unchanged from 0001628280-16-017813:notes:37]

[0000866374-16-000007:notes:47]
|  | Three-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (40,174 | ) |  | $ | (84,532 | ) |  | $ | (124,706 | ) |  | $ | (55,437 | ) |  | $ | (109,456 | ) |  | $ | (164,893 | ) |
| Other comprehensive gain (loss) before reclassifications | (1,169 | ) |  | 4,213 |  |  | 3,044 |  |  | (13,818 | ) |  | (30,267 | ) |  | (44,085 | ) |
| Net (gain) losses reclassified from accumulated other comprehensive loss | (890 | ) |  | — |  |  | (890 | ) |  | 8,274 |  |  | — |  |  | 8,274 |  |
| Net current-period other comprehensive gain (loss) | (2,059 | ) |  | 4,213 |  |  | 2,154 |  |  | (5,544 | ) |  | (30,267 | ) |  | (35,811 | ) |
| Ending balance | $ | (42,233 | ) |  | $ | (80,319 | ) |  | $ | (122,552 | ) |  | $ | (60,981 | ) |  | $ | (139,723 | ) |  | $ | (200,704 | ) |

[0000866374-16-000007:notes:48]
|  | Six-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |  | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |
| Other comprehensive gain (loss) before reclassifications | 324 |  |  | 14,299 |  |  | 14,623 |  |  | (14,419 | ) |  | (27,636 | ) |  | (42,055 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (1,035 | ) |  | (225 | ) |  | (1,260 | ) |  | 21,704 |  |  | 152 |  |  | 21,856 |  |
| Net current-period other comprehensive gain (loss) | (711 | ) |  | 14,074 |  |  | 13,363 |  |  | 7,285 |  |  | (27,484 | ) |  | (20,199 | ) |
| Ending balance | $ | (42,233 | ) |  | $ | (80,319 | ) |  | $ | (122,552 | ) |  | $ | (60,981 | ) |  | $ | (139,723 | ) |  | $ | (200,704 | ) |

[0000866374-16-000007:notes:49]
Net gains reclassified from accumulated other comprehensive loss during the six-month period ended September 30, 2016 relating to derivative instruments and other includes $1.9 million attributable to the Company’s cash flow hedge instruments which were primarily recognized as a component of cost of sales in the condensed consolidated statement of operations.

[0000866374-16-000007:notes:50]
Net losses reclassified from accumulated other comprehensive loss during the six-month period ended September 25, 2015 relating to derivative instruments and other includes $20.7 million attributable to the Company’s cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations.

[0000866374-16-000007:notes:51]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month and six-month periods ended September 25, 2015, was recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-16-000007:notes:52]
[same as prior period, unchanged from 0001628280-16-017813:notes:41]

[0000866374-16-000007:notes:53]
[same as prior period, unchanged from 0001628280-16-017813:notes:42]

[0000866374-16-000007:notes:54]
The Company primarily enters into forward contracts and foreign currency swap contracts to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions. The Company hedges committed exposures and does not engage in speculative transactions. As of September 30, 2016, the aggregate notional amount of the Company’s outstanding foreign currency contracts was $4.2 billion as summarized below:

[0000866374-16-000007:notes:55]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  |
| CNY |  | 874,000 |  |  | — |  |  | $ | 130,927 |  |  | $ | — |  |
| EUR |  | 23,090 |  |  | 104,160 |  |  | 25,842 |  |  | 118,953 |  |
| HUF |  | 15,775,600 |  |  | — |  |  | 57,280 |  |  | — |  |
| ILS |  | 112,280 |  |  | — |  |  | 29,891 |  |  | — |  |
| INR |  | 1,282,982 |  |  | — |  |  | 18,600 |  |  | — |  |
| MXN |  | 1,673,000 |  |  | — |  |  | 85,680 |  |  | — |  |
| MYR |  | 153,000 |  |  | 7,000 |  |  | 36,970 |  |  | 1,691 |  |
| PLN |  | 62,840 |  |  | — |  |  | 16,379 |  |  | — |  |
| Other |  | N/A |  |  | N/A |  |  | 35,271 |  |  | 12,350 |  |
|  |  |  |  |  |  |  |  | 436,840 |  |  | 132,994 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 392,000 |  |  | — |  |  | 120,653 |  |
| CHF |  | 8,960 |  |  | 21,150 |  |  | 9,210 |  |  | 21,739 |  |
| CNY |  | 2,582,317 |  |  | — |  |  | 386,097 |  |  | — |  |
| DKK |  | 167,400 |  |  | 157,200 |  |  | 25,141 |  |  | 23,609 |  |
| EUR |  | 869,642 |  |  | 1,150,415 |  |  | 973,337 |  |  | 1,287,735 |  |
| GBP |  | 32,336 |  |  | 58,752 |  |  | 42,023 |  |  | 76,386 |  |
| HUF |  | 21,422,970 |  |  | 19,425,090 |  |  | 77,786 |  |  | 70,532 |  |
| ILS |  | 58,900 |  |  | 91,420 |  |  | 15,680 |  |  | 24,338 |  |
| INR |  | 2,780,000 |  |  | 26,687 |  |  | 41,817 |  |  | 400 |  |
| MXN |  | 1,808,051 |  |  | 637,803 |  |  | 93,003 |  |  | 32,889 |  |
| MYR |  | 348,477 |  |  | 20,200 |  |  | 84,204 |  |  | 4,881 |  |
| PLN |  | 122,136 |  |  | 73,747 |  |  | 31,834 |  |  | 19,222 |  |
| SEK |  | 225,946 |  |  | 298,985 |  |  | 26,294 |  |  | 34,857 |  |
| SGD |  | 43,274 |  |  | 3,620 |  |  | 31,775 |  |  | 2,658 |  |
| Other |  | N/A |  |  | N/A |  |  | 45,748 |  |  | 34,906 |  |
|  |  |  |  |  |  |  |  | 1,883,949 |  |  | 1,754,805 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  |  | $ | 2,320,789 |  |  | $ | 1,887,799 |  |

[0000866374-16-000007:notes:56]
As of September 30, 2016, the fair value of the Company’s short-term foreign currency contracts was not material and is included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of September 30, 2016 and March 31, 2016, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses were not material as of September 30, 2016, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0000866374-16-000007:notes:57]
[same as prior period, unchanged from 0001628280-16-017813:notes:46]

[0000866374-16-000007:notes:58]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 30, 2016 |  | March 31, 2016 |  | Balance SheetLocation |  | September 30, 2016 |  | March 31, 2016 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 6,253 |  |  | $ | 5,510 |  |  | Other current liabilities |  | $ | 4,456 |  |  | $ | 2,446 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 5,226 |  |  | $ | 17,138 |  |  | Other current liabilities |  | $ | 6,361 |  |  | $ | 18,645 |  |

[0000866374-16-000007:notes:59]
[same as prior period, unchanged from 0001628280-16-017813:notes:48]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-16-000007:notes:60]
[same as prior period, unchanged from 0001628280-16-017813:notes:49]

[0000866374-16-000007:notes:61]
[same as prior period, unchanged from 0001628280-16-017813:notes:50]

[0000866374-16-000007:notes:62]
[same as prior period, unchanged from 0001628280-16-017813:notes:51]

[0000866374-16-000007:notes:63]
[same as prior period, unchanged from 0001628280-16-017813:notes:52]

[0000866374-16-000007:notes:64]
[same as prior period, unchanged from 0001628280-16-017813:notes:54]

[0000866374-16-000007:notes:65]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |  | September 30, 2016 |  | September 25, 2015 |
|  | (In thousands) |
| Cost of sales | $ | 2,636 |  |  | $ | 2,015 |  |  | $ | 5,069 |  |  | $ | 4,033 |  |
| Selling, general and administrative expenses | 20,097 |  |  | 14,185 |  |  | 41,461 |  |  | 28,293 |  |
| Total share-based compensation expense | $ | 22,733 |  |  | $ | 16,200 |  |  | $ | 46,530 |  |  | $ | 32,326 |  |

[0000866374-16-000007:notes:66]
[same as prior period, unchanged from 0001628280-16-017813:notes:56]

[0000866374-16-000007:notes:67]
Total unrecognized compensation expense related to share options under the 2010 Plan is not significant. As of September 30, 2016, the number of options outstanding and exercisable under the 2010 Plan was 0.2 million, for both, and at a weighted-average exercise price of $9.27 per share and $9.23 per share, respectively.

[0000866374-16-000007:notes:68]
During the six-month period ended September 30, 2016, the Company granted 5.9 million unvested share bonus awards under the 2010 Plan. Of this amount, approximately 5.0 million unvested share bonus awards have an average grant date price of $12.81 per share. Further, approximately 0.7 million of these unvested shares represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $17.57 per award and was calculated using a Monte Carlo simulation. The remaining 0.2 million of unvested share bonus awards under the 2010 Plan have an average grant date price of $12.82 per share and represents the target amount of grants made to certain executive officers whereby vesting is contingent on meeting certain free cash flow targets. The number of shares under the 2010 Plan, contingent on market conditions that ultimately will vest range from zero up to a maximum of 1.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met. The number of shares under the 2010 Plan, contingent on free cash flow targets that ultimately will vest range from zero up to a maximum of 0.4 million of the target payment based on a measurement of cumulative three-year increase of free cash flow from operations of the Company, and will cliff vest after a period of three years.

[0000866374-16-000007:notes:69]
As of September 30, 2016, approximately 15.9 million unvested share bonus awards under the 2010 Plan were outstanding, of which vesting for a targeted amount of 2.3 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 4.6 million based on the achievement levels of the respective conditions. During the six-month period ended September 30, 2016, 3.5 million shares under the 2010 Plan vested in connection with the share bonus awards with market conditions granted in fiscal year 2014.

[0000866374-16-000007:notes:70]
As of September 30, 2016, total unrecognized compensation expense related to unvested share bonus awards under the 2010 Plan is $159.5 million, and will be recognized over a weighted-average remaining vesting period of 2.8 years. Approximately $26.3 million of the total unrecognized compensation cost, is related to awards under the 2010 Plan whereby vesting is contingent on meeting certain market conditions.

[0000866374-16-000007:notes:71]
[same as prior period, unchanged from 0001628280-16-017813:notes:61]

[0000866374-16-000007:notes:72]
All shares previously granted under the NEXTracker plan are the result of the Company's conversion of all outstanding, unvested shares of NEXTracker into unvested shares of the Company, as part of the acquisition. Therefore, no additional share options or share bonus awards were granted by the Company during the six-month period ended September 30, 2016.

[0000866374-16-000007:notes:73]
As of September 30, 2016, total unrecognized compensation expense related to share options under the NEXTracker Plan is $11.1 million, and will be recognized over a weighted-average remaining vesting period of 2.3 years. As of September 30, 2016, the number of options outstanding and exercisable was 2.2 million and 0.6 million, respectively, at a weighted-average exercise price of $3.44 per share and $2.72 per share, respectively.

[0000866374-16-000007:notes:74]
As of September 30, 2016, approximately 2.3 million unvested share bonus awards were outstanding. The total unrecognized compensation expense related to unvested share bonus awards under the NEXTracker Plan is $12.2 million, and will be recognized over a weighted-average remaining vesting period of 2.0 years.

[0000866374-16-000007:notes:75]
[same as prior period, unchanged from 0001628280-16-017813:notes:65]

[0000866374-16-000007:notes:76]
During the first quarter of fiscal year 2017, the Company granted 0.2 million share options under the BrightBox Plan, at an average grant date fair value price of $11.99 per share, and with a vesting period of three years from the vesting commencement date. All shares granted under the BrightBox plan are the result of the Company's conversion of all outstanding, unvested shares of BrightBox into unvested shares of the Company, as part of the acquisition. No additional grants will be made out of this plan in the future.

[0000866374-16-000007:notes:77]
As of September 30, 2016, total unrecognized compensation expense related to share options under the BrightBox Plan is $1.6 million, and will be recognized over a weighted-average remaining vesting period of 2.6 years. As of September 30, 2016, the number of options outstanding was 0.2 million, at a weighted-average exercise price of $0.51 per share. No options under this plan were exercisable as of September 30, 2016.


## us-gaap:EarningsPerShareTextBlock

[0000866374-16-000007:notes:78]
[same as prior period, unchanged from 0001628280-16-017813:notes:68]

[0000866374-16-000007:notes:79]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share attributable to the shareholders of Flex Ltd.:

[0000866374-16-000007:notes:80]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |  | September 30, 2016 |  | September 25, 2015 |
|  | (In thousands, except per share amounts) |
| Net income (loss) | $ | (2,508 | ) |  | $ | 122,977 |  |  | $ | 103,221 |  |  | $ | 233,827 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 544,055 |  |  | 563,333 |  |  | 544,353 |  |  | 564,417 |  |
| Basic earnings (losses) per share | $ | 0.00 |  |  | $ | 0.22 |  |  | $ | 0.19 |  |  | $ | 0.41 |  |
| Diluted earnings (losses) per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | (2,508 | ) |  | $ | 122,977 |  |  | $ | 103,221 |  |  | $ | 233,827 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 544,055 |  |  | 563,333 |  |  | 544,353 |  |  | 564,417 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) | — |  |  | 6,322 |  |  | 5,581 |  |  | 8,871 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 544,055 |  |  | 569,655 |  |  | 549,934 |  |  | 573,288 |  |
| Diluted earnings (losses) per share | $ | 0.00 |  |  | $ | 0.22 |  |  | $ | 0.19 |  |  | $ | 0.41 |  |

[0000866374-16-000007:notes:81]
[same as prior period, unchanged from 0001628280-16-017813:notes:71]

[0000866374-16-000007:notes:82]
(1)         As a result of the Company's net loss, ordinary share equivalents from approximately 4.3 million options and share bonus awards were excluded from the calculation of diluted earnings (losses) per share for the three-month period ended September 30, 2016. Options to purchase ordinary shares of 1.7 million and 1.1 million during the three-month periods ended September 30, 2016 and September 25, 2015, respectively, and share bonus awards of 3.4 million and 5.3 million for the three-month period ended September 30, 2016 and September 25, 2015, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.

[0000866374-16-000007:notes:83]
(2)         Options to purchase ordinary shares of 0.9 million and 1.2 million during the six-month periods ended September 30, 2016 and September 25, 2015, respectively, and share bonus awards of 2.9 million for the six-month period ended September 25, 2015 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. An immaterial amount of anti-dilutive share bonus awards was excluded for the six-month period ended September 30, 2016.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-16-000007:notes:84]
[same as prior period, unchanged from 0001628280-16-017813:notes:73]

[0000866374-16-000007:notes:85]
[same as prior period, unchanged from 0001628280-16-017813:notes:74]

[0000866374-16-000007:notes:86]
[same as prior period, unchanged from 0001628280-16-017813:notes:75]

[0000866374-16-000007:notes:87]
[same as prior period, unchanged from 0001628280-16-017813:notes:76]

[0000866374-16-000007:notes:88]
[same as prior period, unchanged from 0001628280-16-017813:notes:77]

[0000866374-16-000007:notes:89]
[same as prior period, unchanged from 0001628280-16-017813:notes:78]

[0000866374-16-000007:notes:90]
[same as prior period, unchanged from 0001628280-16-017813:notes:79]

[0000866374-16-000007:notes:91]
[same as prior period, unchanged from 0001628280-16-017813:notes:80]

[0000866374-16-000007:notes:92]
[same as prior period, unchanged from 0001628280-16-017813:notes:81]

[0000866374-16-000007:notes:93]
[same as prior period, unchanged from 0001628280-16-017813:notes:82]

[0000866374-16-000007:notes:94]
[same as prior period, unchanged from 0001628280-16-017813:notes:83]

[0000866374-16-000007:notes:95]
[same as prior period, unchanged from 0001628280-16-017813:notes:84]

[0000866374-16-000007:notes:96]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |  | September 30, 2016 |  | September 25, 2015 |
|  | (In thousands) |
| Beginning balance | $ | 75,258 |  |  | $ | 4,500 |  |  | $ | 73,423 |  |  | $ | 4,500 |  |
| Additions to accrual | — |  |  | — |  |  | — |  |  | — |  |
| Payments | (2,221 | ) |  | — |  |  | (2,221 | ) |  | — |  |
| Fair value adjustments | 2,577 |  |  | — |  |  | 4,412 |  |  | — |  |
| Ending balance | $ | 75,614 |  |  | $ | 4,500 |  |  | $ | 75,614 |  |  | $ | 4,500 |  |

[0000866374-16-000007:notes:97]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not meaningful. The interrelationship between these inputs is also insignificant. Refer to note 8 for a reconciliation of the change in the deferred purchase price receivable during the three-month and six-month periods ended September 30, 2016 and September 25, 2015.

[0000866374-16-000007:notes:98]
There were no transfers between levels in the fair value hierarchy during the three-month and six-month periods ended September 30, 2016 and September 25, 2015.

[0000866374-16-000007:notes:99]
[same as prior period, unchanged from 0001628280-16-017813:notes:88]

[0000866374-16-000007:notes:100]
[same as prior period, unchanged from 0001628280-16-017813:notes:89]

[0000866374-16-000007:notes:101]
|  | Fair Value Measurements as of September 30, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,120,831 |  |  | $ | — |  |  | $ | 1,120,831 |  |
| Deferred purchase price receivable (Note 8) | — |  |  | — |  |  | 461,544 |  |  | 461,544 |  |
| Foreign exchange contracts (Note 6) | — |  |  | 11,479 |  |  | — |  |  | 11,479 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,497 |  |  | 48,124 |  |  | — |  |  | 55,621 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 6) | $ | — |  |  | $ | (10,817 | ) |  | $ | — |  |  | $ | (10,817 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (75,614 | ) |  | (75,614 | ) |
|  | Fair Value Measurements as of March 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,074,132 |  |  | $ | — |  |  | $ | 1,074,132 |  |
| Deferred purchase price receivable (Note 8) | — |  |  | — |  |  | 501,097 |  |  | 501,097 |  |
| Foreign exchange contracts (Note 6) | — |  |  | 22,648 |  |  | — |  |  | 22,648 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 9,228 |  |  | 40,556 |  |  | — |  |  | 49,784 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 6) | $ | — |  |  | $ | (21,091 | ) |  | $ | — |  |  | $ | (21,091 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (73,423 | ) |  | (73,423 | ) |

[0000866374-16-000007:notes:102]
[same as prior period, unchanged from 0001628280-16-017813:notes:91]

[0000866374-16-000007:notes:103]
[same as prior period, unchanged from 0001628280-16-017813:notes:92]

[0000866374-16-000007:notes:104]
|  | As of September 30, 2016 |  | As of March 31, 2016 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 570,000 |  |  | $ | 568,222 |  |  | $ | 577,500 |  |  | $ | 573,533 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 525,000 |  |  | 520,406 |  |  | 547,500 |  |  | 542,709 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 536,250 |  |  | 500,000 |  |  | 524,735 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 550,000 |  |  | 500,000 |  |  | 507,500 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,782 |  |  | 639,000 |  |  | 595,589 |  |  | 604,926 |  |  | Level 1 |
| Total | $ | 2,690,782 |  |  | $ | 2,813,878 |  |  | $ | 2,720,589 |  |  | $ | 2,753,403 |  |  |  |

[0000866374-16-000007:notes:105]
[same as prior period, unchanged from 0001628280-16-017813:notes:94]

[0000866374-16-000007:notes:106]
The Company values its €50 million (approximately $56.1 million as of September 30, 2016), 5-year, unsecured, term-loan due September 30, 2020 based on the current market rate, and as of September 30, 2016, the carrying amount approximates fair value.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000866374-16-000007:notes:107]
Recently Adopted Accounting Pronouncement

[0000866374-16-000007:notes:108]
In March 2016, the Financial Accounting Standards Board ("FASB") issued new guidance intended to reduce the cost and complexity of the accounting for share-based payments. The new guidance simplifies various aspects of the accounting for share-based payments including income tax effects, withholding requirements and forfeitures. The Company elected to early adopt this new guidance beginning in the first quarter of fiscal year 2017. The guidance eliminates additional paid in capital ("APIC") pools and requires companies to recognize all excess tax benefits and tax deficiencies in the income statement when the awards vest or are settled. It also addresses the presentation of excess tax benefits and employee taxes paid on the statement of cash flows. Prior to adoption, the Company elected to not deduct tax benefits for stock-based compensation awards on its tax returns, and accordingly, did not have any excess tax benefits or tax deficiencies upon adoption. The Company therefore determined that adoption of the new guidance had no impact on the condensed consolidated statement of operations and the condensed consolidated statement of cash flows. Further, the new guidance eliminates the requirement to estimate forfeitures and reduce stock compensation expense during the vesting period. Instead, companies can elect to account for actual forfeitures as they occur and record any previously unrecognized compensation expense for estimated forfeitures up to the period of adoption as a retrospective adjustment to beginning retained earnings. The Company has made the election to account for actual forfeitures as they occur starting in fiscal year 2017. After assessment, it was determined that the cumulative effect adjustment required under the new guidance was immaterial and therefore the Company did not record a retrospective adjustment. The Company finally determined that the adoption of this guidance did not have a significant impact on the consolidated financial position, results of operations and cash flows of the Company.

[0000866374-16-000007:notes:109]
Recently Issued Accounting Pronouncement

[0000866374-16-000007:notes:110]
In August 2016, the FASB issued new guidance intended to address specific cash flow issues with the objective of reducing the existing diversity in practice. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early application permitted. The Company is currently assessing the impact of this update and the timing of adoption.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-16-000007:notes:111]
[same as prior period, unchanged from 0001628280-16-017813:notes:98]

[0000866374-16-000007:notes:112]
[same as prior period, unchanged from 0001628280-16-017813:notes:99]

[0000866374-16-000007:notes:113]
Flex Ltd., formerly Flextronics International Ltd., ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scaletm; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of its medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electronics, connectivity, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes its mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables the Company's OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-16-000007:notes:114]
[same as prior period, unchanged from 0001628280-16-017813:notes:101]

[0000866374-16-000007:notes:115]
Basis of Presentation

[0000866374-16-000007:notes:116]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2016 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and six-month periods ended September 30, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017.

[0000866374-16-000007:notes:117]
The first quarters for fiscal year 2017 and fiscal year 2016 ended on July 1, 2016, which is comprised of 92 days in the period, and June 26, 2015, which is comprised of 87 days in the period, respectively. The second quarters for fiscal year 2017 and fiscal year 2016 ended on September 30, 2016 and September 25, 2015, which are comprised of 91 days in both periods, respectively.

[0000866374-16-000007:notes:118]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The associated noncontrolling owners' interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

[0000866374-16-000007:notes:119]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has an ownership percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000866374-16-000007:notes:120]
[same as prior period, unchanged from 0001628280-16-017813:notes:104]

[0000866374-16-000007:notes:121]
|  | As of September 30, 2016 |  | As of March 31, 2016 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 261,695 |  |  | $ | (89,596 | ) |  | $ | 172,099 |  |  | $ | 223,046 |  |  | $ | (66,473 | ) |  | $ | 156,573 |  |
| Licenses and other intangibles | 290,020 |  |  | (58,050 | ) |  | 231,970 |  |  | 285,053 |  |  | (37,872 | ) |  | 247,181 |  |
| Total | $ | 551,715 |  |  | $ | (147,646 | ) |  | $ | 404,069 |  |  | $ | 508,099 |  |  | $ | (104,345 | ) |  | $ | 403,754 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000866374-16-000007:notes:122]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the six-month period ended September 30, 2016:

[0000866374-16-000007:notes:123]
|  |  | HRS |  | CTG |  | IEI |  | CEC |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year |  | $ | 439,336 |  |  | $ | 68,234 |  |  | $ | 322,803 |  |  | $ | 111,693 |  |  | $ | 942,066 |  |
| Additions (1) |  | — |  |  | 39,822 |  |  | 16,031 |  |  | — |  |  | 55,853 |  |
| Divestitures (2) |  | (1,787 | ) |  | — |  |  | (2,640 | ) |  | — |  |  | (4,427 | ) |
| Purchase accounting adjustments (3) |  | 794 |  |  | — |  |  | — |  |  | — |  |  | 794 |  |
| Foreign currency translation adjustments |  | (2,592 | ) |  | — |  |  | — |  |  | — |  |  | (2,592 | ) |
| Balance, end of the period |  | $ | 435,751 |  |  | $ | 108,056 |  |  | $ | 336,194 |  |  | $ | 111,693 |  |  | $ | 991,694 |  |

[0000866374-16-000007:notes:124]
| (1) | The goodwill generated from the Company’s business combinations completed during the six-month period ended September 30, 2016 is primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired businesses. The goodwill is not deductible for income tax purposes. See note 10 for additional information. |

[0000866374-16-000007:notes:125]
| (2) | During the six-month period ended September 30, 2016, the Company disposed of two non-strategic businesses within the IEI and HRS segments, and recorded an aggregate reduction of goodwill of $4.4 million accordingly, which is included in the loss on sale in other expense on the condensed consolidated statement of operations. |

[0000866374-16-000007:notes:126]
[same as prior period, unchanged from 0001628280-16-017813:notes:110]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000866374-16-000007:notes:127]
[same as prior period, unchanged from 0001628280-16-017813:notes:111]

[0000866374-16-000007:notes:128]
|  | As of September 30, 2016 |  | As of March 31, 2016 |
|  | (In thousands) |
| Raw materials | $ | 2,443,372 |  |  | $ | 2,234,512 |  |
| Work-in-progress | 477,896 |  |  | 561,282 |  |
| Finished goods | 640,949 |  |  | 695,862 |  |
|  | $ | 3,562,217 |  |  | $ | 3,491,656 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-16-000007:notes:129]
[same as prior period, unchanged from 0001628280-16-017813:notes:113]

[0000866374-16-000007:notes:130]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |  | September 30, 2016 |  | September 25, 2015 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 2,101,922 |  |  | $ | 2,204,966 |  |  | $ | 4,297,912 |  |  | $ | 4,171,528 |  |
| Consumer Technology Group | 1,664,736 |  |  | 2,011,089 |  |  | 2,978,518 |  |  | 3,576,052 |  |
| Industrial & Emerging Industries | 1,242,722 |  |  | 1,145,842 |  |  | 2,531,737 |  |  | 2,275,981 |  |
| High Reliability Solutions | 999,145 |  |  | 954,865 |  |  | 2,077,171 |  |  | 1,859,449 |  |
|  | $ | 6,008,525 |  |  | $ | 6,316,762 |  |  | $ | 11,885,338 |  |  | $ | 11,883,010 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 52,453 |  |  | $ | 65,758 |  |  | $ | 114,352 |  |  | $ | 122,822 |  |
| Consumer Technology Group | 55,314 |  |  | 41,170 |  |  | 79,948 |  |  | 80,013 |  |
| Industrial & Emerging Industries | 37,363 |  |  | 32,268 |  |  | 87,340 |  |  | 61,268 |  |
| High Reliability Solutions | 78,707 |  |  | 71,199 |  |  | 167,243 |  |  | 131,085 |  |
| Corporate and Other | (26,902 | ) |  | (14,075 | ) |  | (61,702 | ) |  | (39,786 | ) |
| Total segment income | 196,935 |  |  | 196,320 |  |  | 387,181 |  |  | 355,402 |  |
| Reconciling items: |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 21,986 |  |  | 16,127 |  |  | 43,584 |  |  | 23,798 |  |
| Stock-based compensation | 22,733 |  |  | 16,200 |  |  | 46,530 |  |  | 32,326 |  |
| Inventory impairment and other (1) | 92,915 |  |  | — |  |  | 92,915 |  |  | — |  |
| Restructuring (2) | 11,539 |  |  | — |  |  | 11,539 |  |  | — |  |
| Other charges, net | 8,388 |  |  | 1,678 |  |  | 11,917 |  |  | 1,842 |  |
| Interest and other, net | 24,632 |  |  | 22,035 |  |  | 49,031 |  |  | 38,540 |  |
| Income before income taxes | $ | 14,742 |  |  | $ | 140,280 |  |  | $ | 131,665 |  |  | $ | 258,896 |  |

[0000866374-16-000007:notes:131]
| (1) | During the fourth quarter of fiscal year 2016, the Company accepted return of previously shipped inventory from a former customer, SunEdison, Inc. ("SunEdison"), of approximately $90 million. On April 21, 2016, SunEdison filed a petition for reorganization under bankruptcy law, and as a result, the Company recognized a bad debt reserve of $61.0 million as of March 31, 2016, associated with its outstanding SunEdison receivables. |

[0000866374-16-000007:notes:132]
During the three-month period ended September 30, 2016, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand as of September 30, 2016 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market in the three and six-month periods ended September 30, 2016. The Company also recognized a $16.0 million impairment charge for solar module equipment and $16.9 million primarily related to negative margin sales and other associated solar panel direct costs incurred during the same periods. The total charge of $92.9 million is included in cost of sales for the three and six-month periods ended September 30, 2016 but is excluded from segment results above.

[0000866374-16-000007:notes:133]
| (2) | The Company has initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its sketch to scaletm initiatives. As part of this plan, approximately $11.5 million was recognized in the quarter ended September 30, 2016. |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0000866374-16-000007:notes:134]
[same as prior period, unchanged from 0001628280-16-017813:notes:115]

[0000866374-16-000007:notes:135]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2017 (1) | $ | 40,069 |  |
| 2018 | 68,052 |  |
| 2019 | 61,398 |  |
| 2020 | 52,804 |  |
| 2021 | 48,562 |  |
| Thereafter | 133,184 |  |
| Total amortization expense | $ | 404,069 |  |

[0000866374-16-000007:notes:136]
| (1) | Represents estimated amortization for the remaining six-month period ending March 31, 2017. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-16-000007:notes:137]
[same as prior period, unchanged from 0001628280-16-017813:notes:118]

[0000866374-16-000007:notes:138]
[same as prior period, unchanged from 0001628280-16-017813:notes:119]

[0000866374-16-000007:notes:139]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges, distressed customer charges, other charges (income), net and interest and other, net.

[0000866374-16-000007:notes:140]
| (2) | The Company has initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its sketch to scaletm initiatives. As part of this plan, approximately $11.5 million was recognized in the quarter ended September 30, 2016. The Company expects to finalize the plan by the end of fiscal year 2017. |

[0000866374-16-000007:notes:141]
[same as prior period, unchanged from 0001628280-16-017813:notes:121]

[0000866374-16-000007:notes:142]
[same as prior period, unchanged from 0001628280-16-017813:notes:122]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-16-000007:notes:143]
[same as prior period, unchanged from 0001628280-16-017813:notes:123]

[0000866374-16-000007:notes:144]
[same as prior period, unchanged from 0001628280-16-017813:notes:124]

[0000866374-16-000007:notes:145]
[same as prior period, unchanged from 0001628280-16-017813:notes:125]

[0000866374-16-000007:notes:146]
The gross carrying amounts of intangible assets are removed when fully amortized. During the six-month period ended September 30, 2016, the total value of intangible assets increased primarily as a result of three acquisitions. The estimated future annual amortization expense for intangible assets is as follows:

[0000866374-16-000007:notes:147]
[same as prior period, unchanged from 0001628280-16-017813:notes:127]

[0000866374-16-000007:notes:148]
Other current assets include approximately $461.5 million and $501.1 million as of September 30, 2016 and March 31, 2016, respectively, for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 8 for additional information.

[0000866374-16-000007:notes:149]
Also included in other current assets is the remaining value of certain assets purchased on behalf of a customer and financed by a third party banking institution in the amounts of $83.9 million and $83.6 million as of September 30, 2016 and March 31, 2016, respectively, the nature of which is more fully discussed in Note 17, "Business and Asset Acquisitions" to the Company's Form 10-K for the year ended March 31, 2016.

[0000866374-16-000007:notes:150]
[same as prior period, unchanged from 0001628280-16-017813:notes:130]

[0000866374-16-000007:notes:151]
Other current liabilities include customer working capital advances of $223.9 million and $253.7 million, customer-related accruals of $511.7 million and $479.5 million, and deferred revenue of $302.9 million and $332.3 million as of September 30, 2016 and March 31, 2016, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Other current liabilities also include the outstanding balance due to the third party banking institution related to the financed equipment discussed above of $90.6 million and $122.0 million as of September 30, 2016 and March 31, 2016, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-16-000007:notes:152]
[same as prior period, unchanged from 0001628280-16-017813:notes:132]

[0000866374-16-000007:notes:153]
[same as prior period, unchanged from 0001628280-16-017813:notes:133]

[0000866374-16-000007:notes:154]
[same as prior period, unchanged from 0001628280-16-017813:notes:134]

[0000866374-16-000007:notes:155]
[same as prior period, unchanged from 0001628280-16-017813:notes:135]

[0000866374-16-000007:notes:156]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month and six-month periods ended September 30, 2016 and September 25, 2015 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0000866374-16-000007:notes:157]
As of September 30, 2016, approximately $1.3 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $851.0 million and deferred purchase price receivables of approximately $461.5 million. As of March 31, 2016, approximately $1.4 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $880.8 million and deferred purchase price receivables of approximately $501.1 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of September 30, 2016 and March 31, 2016, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-16-000007:notes:158]
As of September 30, 2016 and March 31, 2016, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-16-000007:notes:159]
For the six-month periods ended September 30, 2016 and September 25, 2015, cash flows from sales of receivables under the ABS Programs consisted of approximately $2.8 billion and $2.4 billion, for transfers of receivables, respectively (of which approximately $92.7 million and $255.3 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0000866374-16-000007:notes:160]
[same as prior period, unchanged from 0001628280-16-017813:notes:140]

[0000866374-16-000007:notes:161]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $362.7 million and $339.1 million as of September 30, 2016 and March 31, 2016, respectively. For the six-month periods ended September 30, 2016 and September 25, 2015, total accounts receivable sold to certain third party banking institutions was approximately $0.8 billion and $1.2 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-16-000007:notes:162]
[same as prior period, unchanged from 0001628280-16-017813:notes:142]

[0000866374-16-000007:notes:163]
During the three-month and six-month periods ended September 30, 2016, the Company repurchased 6.9 million shares at an aggregate purchase price of $90.0 million, and 14.2 million shares at an aggregate purchase price of $181.0 million, respectively, and retired all of these shares.

[0000866374-16-000007:notes:164]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 24, 2016. As of September 30, 2016, shares in the aggregate amount of $450.2 million were available to be repurchased under the current plan.
