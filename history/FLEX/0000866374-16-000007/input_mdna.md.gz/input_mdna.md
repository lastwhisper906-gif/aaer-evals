# FLEX MD&A — 0000866374-16-000007


## mdna

[0000866374-16-000007:mdna:1]
[same as prior period, unchanged from 0001628280-16-017813:mdna:1]

[0000866374-16-000007:mdna:2]
Unless otherwise specifically stated, references in this report to “Flex,” “the Company,” “we,” “us,” “our” and similar terms mean Flex Ltd., formerly known as Flextronics International Ltd., and its subsidiaries.

[0000866374-16-000007:mdna:3]
[same as prior period, unchanged from 0001628280-16-017813:mdna:3]

[0000866374-16-000007:mdna:4]
We are a globally-recognized, leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scaletm; from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through our activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of our medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; our automotive business, including vehicle electronics, connectivity, and clean technologies; and our defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes our mobile devices business, including smart phones; our consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, our CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions.

[0000866374-16-000007:mdna:5]
[same as prior period, unchanged from 0001628280-16-017813:mdna:5]

[0000866374-16-000007:mdna:6]
[same as prior period, unchanged from 0001628280-16-017813:mdna:6]

[0000866374-16-000007:mdna:7]
[same as prior period, unchanged from 0001628280-16-017813:mdna:7]

[0000866374-16-000007:mdna:8]
[same as prior period, unchanged from 0001628280-16-017813:mdna:8]

[0000866374-16-000007:mdna:9]
[same as prior period, unchanged from 0001628280-16-017813:mdna:9]

[0000866374-16-000007:mdna:10]
We are one of the world's largest providers of global supply chain solutions, with revenues of $11.9 billion for the six-month period ended September 30, 2016 and $24.4 billion in fiscal year 2016. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-16-000007:mdna:11]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Net sales: |  | September 30, 2016 |  | September 25, 2015 |  | September 30, 2016 |  | September 25, 2015 |
|  |  | (In thousands) |
| China |  | $ | 1,959,064 |  |  | 32 | % |  | $ | 2,340,475 |  |  | 37 | % |  | $ | 3,799,916 |  |  | 32 | % |  | $ | 4,176,663 |  |  | 35 | % |
| Mexico |  | 952,857 |  |  | 16 | % |  | 943,624 |  |  | 15 | % |  | 1,868,202 |  |  | 16 | % |  | 1,850,503 |  |  | 16 | % |
| U.S. |  | 708,858 |  |  | 12 | % |  | 627,757 |  |  | 10 | % |  | 1,417,268 |  |  | 12 | % |  | 1,270,346 |  |  | 11 | % |
| Malaysia |  | 539,985 |  |  | 9 | % |  | 566,919 |  |  | 9 | % |  | 1,112,748 |  |  | 9 | % |  | 1,112,289 |  |  | 9 | % |
| Brazil |  | 417,958 |  |  | 7 | % |  | 498,697 |  |  | 8 | % |  | 789,631 |  |  | 7 | % |  | 982,827 |  |  | 8 | % |
| Other |  | 1,429,803 |  |  | 24 | % |  | 1,339,290 |  |  | 21 | % |  | 2,897,573 |  |  | 24 | % |  | 2,490,382 |  |  | 21 | % |
|  |  | $ | 6,008,525 |  |  |  |  |  | $ | 6,316,762 |  |  |  |  |  | $ | 11,885,338 |  |  |  |  |  | $ | 11,883,010 |  |  |  |  |

[0000866374-16-000007:mdna:12]
|  |  | As of |  | As of |
| Property and equipment, net: |  | September 30, 2016 |  | March 31, 2016 |
|  |  | (In thousands) |
| China |  | $ | 765,432 |  |  | 33 | % |  | $ | 789,571 |  |  | 35 | % |
| Mexico |  | 484,418 |  |  | 21 | % |  | 429,989 |  |  | 19 | % |
| U.S. |  | 302,163 |  |  | 13 | % |  | 330,778 |  |  | 15 | % |
| Malaysia |  | 190,161 |  |  | 8 | % |  | 159,787 |  |  | 7 | % |
| Hungary |  | 127,902 |  |  | 5 | % |  | 107,492 |  |  | 5 | % |
| Other |  | 465,883 |  |  | 20 | % |  | 425,559 |  |  | 19 | % |
|  |  | $ | 2,335,959 |  |  |  |  |  | $ | 2,257,633 |  |  |  |  |

[0000866374-16-000007:mdna:13]
[same as prior period, unchanged from 0001628280-16-017813:mdna:13]

[0000866374-16-000007:mdna:14]
[same as prior period, unchanged from 0001628280-16-017813:mdna:14]

[0000866374-16-000007:mdna:15]
[same as prior period, unchanged from 0001628280-16-017813:mdna:15]

[0000866374-16-000007:mdna:16]
[same as prior period, unchanged from 0001628280-16-017813:mdna:79]

[0000866374-16-000007:mdna:17]
[same as prior period, unchanged from 0001628280-16-017813:mdna:16]

[0000866374-16-000007:mdna:18]
[same as prior period, unchanged from 0001628280-16-017813:mdna:18]

[0000866374-16-000007:mdna:19]
[same as prior period, unchanged from 0001628280-16-017813:mdna:19]

[0000866374-16-000007:mdna:20]
[same as prior period, unchanged from 0001628280-16-017813:mdna:20]

[0000866374-16-000007:mdna:21]
[same as prior period, unchanged from 0001628280-16-017813:mdna:21]

[0000866374-16-000007:mdna:22]
[same as prior period, unchanged from 0001628280-16-017813:mdna:22]

[0000866374-16-000007:mdna:23]
[same as prior period, unchanged from 0001628280-16-017813:mdna:23]

[0000866374-16-000007:mdna:24]
[same as prior period, unchanged from 0001628280-16-017813:mdna:24]

[0000866374-16-000007:mdna:25]
[same as prior period, unchanged from 0001628280-16-017813:mdna:25]

[0000866374-16-000007:mdna:26]
[same as prior period, unchanged from 0001628280-16-017813:mdna:26]

[0000866374-16-000007:mdna:27]
[same as prior period, unchanged from 0001628280-16-017813:mdna:27]

[0000866374-16-000007:mdna:28]
[same as prior period, unchanged from 0001628280-16-017813:mdna:28]

[0000866374-16-000007:mdna:29]
[same as prior period, unchanged from 0001628280-16-017813:mdna:29]

[0000866374-16-000007:mdna:30]
[same as prior period, unchanged from 0001628280-16-017813:mdna:30]

[0000866374-16-000007:mdna:31]
[same as prior period, unchanged from 0001628280-16-017813:mdna:31]

[0000866374-16-000007:mdna:32]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |  | September 30, 2016 |  | September 25, 2015 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 94.8 |  |  | 93.7 |  |  | 93.9 |  |  | 93.7 |  |
| Gross profit | 5.2 |  |  | 6.3 |  |  | 6.1 |  |  | 6.3 |  |
| Selling, general and administrative expenses | 4.1 |  |  | 3.4 |  |  | 4.1 |  |  | 3.6 |  |
| Intangible amortization | 0.4 |  |  | 0.3 |  |  | 0.4 |  |  | 0.2 |  |
| Interest and other, net | 0.4 |  |  | 0.3 |  |  | 0.4 |  |  | 0.3 |  |
| Other charges, net | 0.1 |  |  | 0.0 |  |  | 0.1 |  |  | 0.0 |  |
| Income before income taxes | 0.2 |  |  | 2.3 |  |  | 1.1 |  |  | 2.2 |  |
| Provision for income taxes | 0.3 |  |  | 0.3 |  |  | 0.2 |  |  | 0.2 |  |
| Net income (loss) | (0.1 | )% |  | 2.0 | % |  | 0.9 | % |  | 2.0 | % |

[0000866374-16-000007:mdna:33]
36

[0000866374-16-000007:mdna:34]
[same as prior period, unchanged from 0001628280-16-017813:mdna:34]

[0000866374-16-000007:mdna:35]
[same as prior period, unchanged from 0001628280-16-017813:mdna:35]

[0000866374-16-000007:mdna:36]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Segments: |  | September 30, 2016 |  | September 25, 2015 |  | September 30, 2016 |  | September 25, 2015 |
|  |  | (In thousands) |
| Communications & Enterprise Compute |  | $ | 2,101,922 |  |  | 35 | % |  | $ | 2,204,966 |  |  | 35 | % |  | $ | 4,297,912 |  |  | 36 | % |  | $ | 4,171,528 |  |  | 35 | % |
| Consumer Technology Group |  | 1,664,736 |  |  | 28 | % |  | 2,011,089 |  |  | 32 | % |  | 2,978,518 |  |  | 25 | % |  | 3,576,052 |  |  | 30 | % |
| Industrial & Emerging Industries |  | 1,242,722 |  |  | 21 | % |  | 1,145,842 |  |  | 18 | % |  | 2,531,737 |  |  | 21 | % |  | 2,275,981 |  |  | 19 | % |
| High Reliability Solutions |  | 999,145 |  |  | 16 | % |  | 954,865 |  |  | 15 | % |  | 2,077,171 |  |  | 18 | % |  | 1,859,449 |  |  | 16 | % |
|  |  | $ | 6,008,525 |  |  |  |  |  | $ | 6,316,762 |  |  |  |  |  | $ | 11,885,338 |  |  |  |  |  | $ | 11,883,010 |  |  |  |  |

[0000866374-16-000007:mdna:37]
Net sales during the three-month period ended September 30, 2016 totaled $6.0 billion, representing a decrease of approximately $0.3 billion, or 4.9% from $6.3 billion during the three-month period ended September 25, 2015. The overall decline in sales was driven by decreases in two of our segments, with our CTG segment declining $346.4 million, almost entirely due to a decline in demand from our largest smartphone customer Lenovo/Motorola in connection with our exit of a China operation dedicated to them, and a $103.0 million decrease in our CEC segment largely attributable to lower sales within our legacy server and storage business. These decreases were offset by modest increases in our other segments with a $96.9 million increase in our IEI segment driven by contribution from our NEXTracker Inc. ("NEXTracker") acquisition and expansion within our capital equipment business. Also offsetting the declines in CTG and CEC segments was a $44.3 million increase in our HRS segment primarily attributable to successful new program ramps in our automotive and medical businesses. Net sales decreased $290.0 million to $2.9 billion in Asia, while remaining relatively consistent in the Americas and Europe at $2.1 billion and $1.0 billion, respectively.

[0000866374-16-000007:mdna:38]
Net sales during the six-month periods ended September 30, 2016 and September 25, 2015, remained consistent at $11.9 billion. Net sales within our CTG segment decreased by $597.5 million primarily as a result of the decline in demand from our largest smartphone customer Lenovo/Motorola in connection with the exit of the China operation described above, offset by slight increases in each of our other three segments. Net sales increased $213.9 million to $2.2 billion in Europe offset by a decrease of $190.1 million to $5.6 billion in Asia. Sales in the Americas remained relatively consistent at $4.1 billion.

[0000866374-16-000007:mdna:39]
Our ten largest customers, during the three-month and six-month periods ended September 30, 2016, accounted for approximately 42% and 43% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and six-month periods ended September 30, 2016.

[0000866374-16-000007:mdna:40]
Our ten largest customers, during the three-month and six-month periods ended September 25, 2015, accounted for approximately 47% and 46% of net sales, respectively. Lenovo/Motorola accounted for more than 10% of net sales during the three and six-month periods ended September 25, 2015.

[0000866374-16-000007:mdna:41]
[same as prior period, unchanged from 0001628280-16-017813:mdna:40]

[0000866374-16-000007:mdna:42]
[same as prior period, unchanged from 0001628280-16-017813:mdna:41]

[0000866374-16-000007:mdna:43]
37

[0000866374-16-000007:mdna:44]
Gross profit during the three-month period ended September 30, 2016 decreased $83.2 million to $313.7 million, or 5.2% of net sales, from $396.9 million, or 6.3% of net sales, during the three-month period ended September 25, 2015. Gross profit during the six-month period ended September 30, 2016 decreased $29.6 million to $719.7 million, or 6.1% of net sales from $749.3 million, or 6.3% of net sales, during the six-month period ended September 25, 2015. Gross profit for both the three-month and the six-month periods ended September 30, 2016 was negatively impacted by the $92.9 million, or 160 basis points and 70 basis points for the three and six-month periods, respectively, of charges recognized related to the significant decline in prices for solar modules and the slowdown in demand. This negative impact was partially offset by a richer business mix due to a greater concentration of our higher margin HRS business coupled with improved operational efficiencies and improved customer mix in our CTG segment.

[0000866374-16-000007:mdna:45]
Gross margins deteriorated 110 and 20 basis points in the three-month and six-month periods ended September 30, 2016, respectively, compared to that of the three-month and six-month periods ended September 25, 2015, as a result of the various factors described above.

[0000866374-16-000007:mdna:46]
[same as prior period, unchanged from 0001628280-16-017813:mdna:43]

[0000866374-16-000007:mdna:47]
An operating segment’s performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock‑based compensation, restructuring charges, distressed customer charges, other charges (income), net and interest and other, net. A portion of amortization and depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-16-000007:mdna:48]
[same as prior period, unchanged from 0001628280-16-017813:mdna:46]

[0000866374-16-000007:mdna:49]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |  | September 30, 2016 |  | September 25, 2015 |
|  | (In thousands) |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 52,453 |  |  | 2.5 | % |  | $ | 65,758 |  |  | 3.0 | % |  | $ | 114,352 |  |  | 2.7 | % |  | $ | 122,822 |  |  | 2.9 | % |
| Consumer Technology Group | 55,314 |  |  | 3.3 | % |  | 41,170 |  |  | 2.0 | % |  | 79,948 |  |  | 2.7 | % |  | 80,013 |  |  | 2.2 | % |
| Industrial & Emerging Industries | 37,363 |  |  | 3.0 | % |  | 32,268 |  |  | 2.8 | % |  | 87,340 |  |  | 3.4 | % |  | 61,268 |  |  | 2.7 | % |
| High Reliability Solutions | 78,707 |  |  | 7.9 | % |  | 71,199 |  |  | 7.5 | % |  | 167,243 |  |  | 8.1 | % |  | 131,085 |  |  | 7.0 | % |
| Corporate and Other | (26,902 | ) |  |  |  | (14,075 | ) |  |  |  | (61,702 | ) |  |  |  | (39,786 | ) |  |  |
| Total segment income | 196,935 |  |  | 3.3 | % |  | 196,320 |  |  | 3.1 | % |  | 387,181 |  |  | 3.3 | % |  | 355,402 |  |  | 3.0 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 21,986 |  |  |  |  | 16,127 |  |  |  |  | 43,584 |  |  |  |  | 23,798 |  |  |  |
| Stock-based compensation | 22,733 |  |  |  |  | 16,200 |  |  |  |  | 46,530 |  |  |  |  | 32,326 |  |  |  |
| Inventory impairment and other (1) | 92,915 |  |  |  |  | — |  |  |  |  | 92,915 |  |  |  |  | — |  |  |  |
| Restructuring (2) | 11,539 |  |  |  |  | — |  |  |  |  | 11,539 |  |  |  |  | — |  |  |  |
| Other charges, net | 8,388 |  |  |  |  | 1,678 |  |  |  |  | 11,917 |  |  |  |  | 1,842 |  |  |  |
| Interest and other, net | 24,632 |  |  |  |  | 22,035 |  |  |  |  | 49,031 |  |  |  |  | 38,540 |  |  |  |
| Income before income taxes | $ | 14,742 |  |  |  |  | $ | 140,280 |  |  |  |  | $ | 131,665 |  |  |  |  | $ | 258,896 |  |  |  |

[0000866374-16-000007:mdna:50]
| (1) | During the fourth quarter of fiscal year 2016, the Company accepted return of previously shipped inventory from a former customer, SunEdison, Inc. ("SunEdison"), of approximately $90 million. On April 21, 2016, SunEdison filed a petition for reorganization under bankruptcy law, and as a result, the Company recognized a bad debt reserve of $61.0 million as of March 31, 2016, associated with its outstanding SunEdison receivables. |

[0000866374-16-000007:mdna:51]
38

[0000866374-16-000007:mdna:52]
During the three-month period ended September 30, 2016, prices for solar panel modules declined significantly due to global oversupply and continued deregulation. The Company determined that certain solar panel inventory on hand as of September 30, 2016 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market in the three and six-month periods ended September 30, 2016. The Company also recognized a $16.0 million impairment charge for solar module equipment and $16.9 million primarily related to negative margin sales and other associated solar panel direct costs incurred during the same periods. The total charge of $92.9 million is included in cost of sales for the three and six-month periods ended September 30, 2016 but is excluded from segment results above.

[0000866374-16-000007:mdna:53]
| (2) | The Company has initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of our sketch to scaletm initiatives. As part of this plan, approximately $11.5 million was recognized in the quarter ended September 30, 2016. The Company expects to finalize the plan by the end of fiscal year 2017. |

[0000866374-16-000007:mdna:54]
CEC segment margin decreased 50 basis points, to 2.5% for the three-month period ended September 30, 2016, from 3.0% during the three-month period ended September 25, 2015 due to lower capacity utilization causing reduced overhead absorption, as well as incurring incremental costs associated with our proactive repositioning of certain programs and actions to better align CEC's operating structure. CEC segment margin decreased 20 basis points, to 2.7% for the six-month period ended September 30, 2016, from 2.9% during the six-month period ended September 25, 2015 as a result of changes in product mix as well as incurring incremental costs associated with our proactive repositioning of certain programs and actions to better align CEC's operating structure.

[0000866374-16-000007:mdna:55]
CTG segment margin increased 130 and 50 basis points, to 3.3% and 2.7%, respectively, for the three-month and six-month periods ended September 30, 2016, from 2.0% and 2.2%, during the three-month and six-month periods ended September 25, 2015, respectively. The increase is primarily driven by portfolio shift within the CTG product mix with a greater concentration of higher margin consumer products where we provide greater levels of design and engineering value-added content, as well as our exiting of lower margin businesses.

[0000866374-16-000007:mdna:56]
IEI segment margin increased 20 and 70 basis points, to 3.0% and 3.4%, respectively, for the three-month and six-month periods ended September 30, 2016, from 2.8% and 2.7% during the three-month and six-month periods ended September 25, 2015, respectively. The increases are primarily due to contribution from our NEXTracker acquisition, partially offset by underperformance primarily driven by our formerly largest IEI customer, SunEdison, declaring bankruptcy in April 2016.

[0000866374-16-000007:mdna:57]
HRS segment margin increased 40 and 110 basis points, to 7.9% and 8.1%, respectively, for the three-month and six-month periods ended September 30, 2016, from 7.5% and 7.0%, during the three-month and six-month periods ended September 25, 2015, respectively. These improvements are primarily the result of new program launches and richer mix with greater value-added business engagements as a result of greater design and engineering solutions as part of our sketch to scaletm offering in our core HRS business, and contribution from our MCi acquisition since the second quarter of fiscal year 2016.

[0000866374-16-000007:mdna:58]
[same as prior period, unchanged from 0001628280-16-017813:mdna:52]

[0000866374-16-000007:mdna:59]
Selling, general and administrative expenses (“SG&A”) was $243.9 million, or 4.1% of net sales, during the three-month period ended September 30, 2016, increasing $27.1 million from $216.8 million, or 3.4% of net sales, during the three-month period ended September 25, 2015. SG&A was $483.5 million, or 4.1% of net sales, during the six-month period ended September 30, 2016, increasing $57.3 million from $426.2 million, or 3.6% of net sales, during the six-month period ended September 25, 2015. The increase in SG&A in dollars and as a percentage of net sales was primarily due to increases in stock-based compensation expense, incremental costs associated with our acquisition of NEXTracker which drives a higher proportional SG&A level and further investments in design and engineering resources by the Company, to support our increased sketch to scaletm initiatives, and to a lesser extent the charges described below.

[0000866374-16-000007:mdna:60]
The Company has initiated a plan to accelerate its ability to support more sketch to scaletm efforts across the company and reposition away from historical legacy programs and structures through rationalizing its current footprint at existing sites and at corporate SG&A functions. The Company estimates that costs associated with its plan will range from $40 million to $60 million in fiscal year 2017, including approximately $11.5 million recognized in the quarter ended September 30, 2016, of which $4.7 million is included in SG&A and $6.8 million is included in cost of sales. The Company expects to finalize the plan by the end of fiscal year 2017.

[0000866374-16-000007:mdna:61]
[same as prior period, unchanged from 0001628280-16-017813:mdna:54]

[0000866374-16-000007:mdna:62]
Amortization of intangible assets increased by $5.9 million during the three-month period ended September 30, 2016 to $22.0 million from $16.1 million for the three-month period ended September 25, 2015, and increased by $19.8 million during the six-month period ended September 30, 2016 to $43.6 million from $23.8 million during the six-month period ended September 25, 2015. The increase is primarily due to incremental amortization expense on intangible assets relating to our acquisitions completed during the second half of fiscal year 2016.

[0000866374-16-000007:mdna:63]
[same as prior period, unchanged from 0001628280-16-017813:mdna:58]

[0000866374-16-000007:mdna:64]
Interest and other, net was $24.6 million during the three-month period ended September 30, 2016 compared to $22.0 million during the three-month period ended September 25, 2015. The increase in interest and other, net of $2.6 million was primarily due to a decline of $9.1 million of foreign currency gains recognized during the three-month period ended September 30, 2016 primarily related to the Chinese Yuan (CNY). The increase was partially offset by $8.1 million of non-recurring acquisition-related costs incurred during the three-month period ended September 25, 2015.

[0000866374-16-000007:mdna:65]
Interest and other, net was $49.0 million during the six-month period ended September 30, 2016 compared to $38.5 million during the six-month period ended September 25, 2015. The increase in interest and other, net of $10.5 million was primarily as a result of $8.1 million of incremental interest expense mainly from the 4.750% Notes due June 15, 2025 issued during the first quarter of fiscal year 2016, as well as the decline in foreign currency gains recognized, offset by the acquisition-related costs as discussed above.

[0000866374-16-000007:mdna:66]
[same as prior period, unchanged from 0001628280-16-017813:mdna:60]

[0000866374-16-000007:mdna:67]
Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 13, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2016 for further discussion.

[0000866374-16-000007:mdna:68]
[same as prior period, unchanged from 0001628280-16-017813:mdna:62]

[0000866374-16-000007:mdna:69]
The consolidated effective tax rate was 117.0% and 21.6% for the three-month and six-month periods ended September 30, 2016, respectively, and 12.3% and 9.7% for the three-month and six-month periods ended September 25, 2015, respectively, and varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions, operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. We generate most of our revenues and profits from operations outside of Singapore. The effective tax rates for the three and six-month periods ended September 30, 2016 are higher than the effective tax rates for the three and six-month periods ended September 25, 2015 primarily due to the charges related to the solar panel inventory impairment and business exit and the rationalization costs incurred during the three-month period ended September 30, 2016 that were in jurisdictions which resulted in minimal tax benefit thereby increasing the company’s effective tax rate.

[0000866374-16-000007:mdna:70]
[same as prior period, unchanged from 0001628280-16-017813:mdna:64]

[0000866374-16-000007:mdna:71]
As of September 30, 2016, we had cash and cash equivalents of approximately $1.5 billion and bank and other borrowings of approximately $2.7 billion. We have a $1.5 billion revolving credit facility that expires in March 2019, under which there were no borrowings outstanding as of the end of the quarter. As of September 30, 2016, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0000866374-16-000007:mdna:72]
Cash provided by operating activities was $543.6 million during the six-month period ended September 30, 2016. This resulted from $103.2 million of net income for the period plus adjustments for $337.4 million of non-cash charges such as depreciation, amortization, and other impairment charges (which includes the $60.0 million inventory write-down recorded during the three-month period ended September 30, 2016), and $102.9 million from changes in our operating assets and liabilities. These changes were mainly related to an increase in accounts payable due to timing of payments to suppliers, offset by an increase in accounts receivable driven by the increase in sales activity.

[0000866374-16-000007:mdna:73]
[same as prior period, unchanged from 0001628280-16-017813:mdna:67]

[0000866374-16-000007:mdna:74]
|  | Three-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |
| Days in trade accounts receivable | 40 days |  | 41 days |
| Days in inventory | 58 days |  | 54 days |
| Days in accounts payable | 72 days |  | 70 days |
| Cash conversion cycle | 26 days |  | 25 days |

[0000866374-16-000007:mdna:75]
Days in trade accounts receivable was calculated as average accounts receivable, net of allowance for double accounts, for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended September 30, 2016, days in trade accounts receivable decreased by 1 day compared to the three-month period ended September 25, 2015 largely due to an improvement in our collection efforts and timing of invoicing customers during the current period. Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $461.5 million and $537.6 million for the quarters ended September 30, 2016 and September 25, 2015, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 8 to the condensed consolidated financial statements.

[0000866374-16-000007:mdna:76]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in inventory increased by 4 days during the three-month period ended September 30, 2016, compared to the three-month period ended September 25, 2015, primarily due to lower sales activities in the current quarter.

[0000866374-16-000007:mdna:77]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable increased by 2 days during the three-month period ended September 30, 2016, compared to the three-month period ended September 25, 2015, primarily due to timing of payments, combined with a lower cost of sales attributable to lower sales in the current period compared to the prior year.

[0000866374-16-000007:mdna:78]
Our cash conversion cycle was calculated as the sum of days of inventory and days of account receivables outstanding less days payable outstanding. Our cash conversion cycle increased by 1 day during the three-month period ended September 30, 2016, compared to the three-month period ended September 25, 2015, due to the factors for each of the components in the calculation discussed above.

[0000866374-16-000007:mdna:79]
Cash used in investing activities amounted to $412.8 million during the six-month period ended September 30, 2016. This resulted primarily from $279.4 million of net capital expenditures for property and equipment to expand capability and capacity in support of our automotive and medical businesses and further investments in both automation and expanding technologies to support our innovation services. In addition, $189.9 million was paid primarily for the acquisition of three businesses, net of cash acquired, including $171.6 million, net of $17.8 million of cash acquired related to the acquisition of the manufacturing facilities from Bose. Offsets in other investing activities include $33.0 million received for the sale of two non-strategic businesses, and $26.8 million of proceeds from the sale of certain assets that were purchased on behalf of a customer and financed by a third party banking institution.

[0000866374-16-000007:mdna:80]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the six-month period ended September 30, 2016 was $264.2 million compared to $368.0 million for the six-month period ended September 25, 2015. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-16-000007:mdna:81]
|  | Six-Month Periods Ended |
|  | September 30, 2016 |  | September 25, 2015 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 543,552 |  |  | $ | 661,995 |  |
| Purchases of property and equipment | (305,936 | ) |  | (296,401 | ) |
| Proceeds from the disposition of property and equipment | 26,561 |  |  | 2,383 |  |
| Free cash flow | $ | 264,177 |  |  | $ | 367,977 |  |

[0000866374-16-000007:mdna:82]
Cash used in financing activities was $215.7 million during the six-month period ended September 30, 2016, which was primarily for the repurchase of our ordinary shares in the amount of $184.7 million, and $110.6 million for repayment of bank borrowings and long-term debt. These cash outflows were partially offset by $75.0 million of net proceeds from bank borrowings and long-term debt.

[0000866374-16-000007:mdna:83]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of September 30, 2016 approximately half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. As of March 31, 2016, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $916.0 million as of March 31, 2016). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-16-000007:mdna:84]
[same as prior period, unchanged from 0001628280-16-017813:mdna:81]

[0000866374-16-000007:mdna:85]
[same as prior period, unchanged from 0001628280-16-017813:mdna:82]

[0000866374-16-000007:mdna:86]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-16-000007:mdna:87]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 24, 2016. During the six-month period ended September 30, 2016, we paid $184.7 million to repurchase shares (under the current and prior repurchase plans) at an average price of $12.69 per share. As of September 30, 2016, shares in the aggregate amount of $450.2 million were available to be repurchased under the current plan.

[0000866374-16-000007:mdna:88]
[same as prior period, unchanged from 0001628280-16-017813:mdna:85]

[0000866374-16-000007:mdna:89]
[same as prior period, unchanged from 0001628280-16-017813:mdna:86]

[0000866374-16-000007:mdna:90]
[same as prior period, unchanged from 0001628280-16-017813:mdna:87]

[0000866374-16-000007:mdna:91]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of September 30, 2016 and March 31, 2016, the fair values of our deferred purchase price receivable were approximately $461.5 million and $501.1 million, respectively. As of September 30, 2016 and March 31, 2016, the outstanding balances on receivables sold for cash were $1.2 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information see note 8 to the condensed consolidated financial statements.
