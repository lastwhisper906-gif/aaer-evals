# FLEX MD&A — 0001628280-15-005450


## mdna

[0001628280-15-005450:mdna:1]
[same as prior period, unchanged from 0001104659-15-005354:mdna:1]

[0001628280-15-005450:mdna:2]
[same as prior period, unchanged from 0001104659-15-005354:mdna:2]

[0001628280-15-005450:mdna:3]
[same as prior period, unchanged from 0001104659-15-005354:mdna:3]

[0001628280-15-005450:mdna:4]
We are a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. We design, build, ship, and service complete packaged consumer electronics and industrial products for original equipment manufacturers (“OEMs”), through our activities in the following business groups: High Reliability Solutions (“HRS”), which is comprised of our medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and our defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group (“CTG”), which includes our mobile devices business, including smart phones; our consumer electronics business, including connected living, wearable electronics, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for notebook personal computing, tablets and printers; Industrial and Emerging Industries (“IEI”), which is comprised of semiconductor and capital equipment, office solutions, test and measurement, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions (“INS”), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products and rack level solutions, converged infrastructure and software-defined product solutions.

[0001628280-15-005450:mdna:5]
On July 23, 2015, we introduced our new brand and website to help us more efficiently manage our business opportunities and explain our new product and service offerings. We are shortening our name from Flextronics to “Flex” to signify that our business continues to evolve past the boundaries and confines of electronics alone. Our new tag line, “Live Smarter” highlights our belief that all devices are becoming intelligent and that value will ultimately be created in the “intelligence of things” and the convergence of technologies and digitization of products across multiple industries and market segments.

[0001628280-15-005450:mdna:6]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship, and service a complete packaged product for our OEM customers. This enables our OEM customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001628280-15-005450:mdna:7]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0001628280-15-005450:mdna:8]
We use a portfolio approach to manage our extensive service offerings. As our OEM customers change the way they go to market, we are able to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet a specific customer's supply chain solutions needs across all of the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0001628280-15-005450:mdna:9]
During the past few years we have made significant efforts to evolve our long-term portfolio towards a higher mix of businesses which possess longer product life cycles and higher margins such as reflected in our IEI and HRS businesses. During the last two fiscal years we launched several programs broadly across our portfolio of services and in some instances we deployed certain new technologies. Some of these programs have started to yield better results, as demonstrated by our margin improvement while our sales decreased compared to the prior year. We continue to invest in innovation and we have expanded our design and engineering relationships through our product innovation centers.

[0001628280-15-005450:mdna:10]
We believe that our business transformation has strategically positioned us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services, which remain strong.

[0001628280-15-005450:mdna:11]
We are one of the world's largest providers of global supply chain solutions, with revenues of $5.6 billion for the three-month period ended June 26, 2015 and $26.1 billion in fiscal year 2015. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0001628280-15-005450:mdna:12]
|  |  | Three-Month Periods Ended |
| Net sales: |  | June 26, 2015 |  | June 27, 2014 |
|  |  | (In thousands) |
| China |  | $ | 1,836,188 |  |  | 33 | % |  | $ | 2,550,230 |  |  | 38 | % |
| Mexico |  | 906,879 |  |  | 16 | % |  | 849,598 |  |  | 13 | % |
| U.S. |  | 642,589 |  |  | 11 | % |  | 754,720 |  |  | 11 | % |
| Malaysia |  | 545,370 |  |  | 10 | % |  | 541,113 |  |  | 8 | % |
| Brazil |  | 484,130 |  |  | 9 | % |  | 596,647 |  |  | 9 | % |
| Other |  | 1,151,092 |  |  | 21 | % |  | 1,350,417 |  |  | 21 | % |
|  |  | $ | 5,566,248 |  |  |  |  |  | $ | 6,642,725 |  |  |  |  |

[0001628280-15-005450:mdna:13]
|  |  | As of |  | As of |
| Property and equipment, net: |  | June 26, 2015 |  | March 31, 2015 |
|  |  | (In thousands) |
| China |  | $ | 796,608 |  |  | 37 | % |  | $ | 776,914 |  |  | 37 | % |
| U.S. |  | 317,501 |  |  | 15 | % |  | 314,613 |  |  | 15 | % |
| Mexico |  | 293,754 |  |  | 13 | % |  | 364,435 |  |  | 17 | % |
| Malaysia |  | 164,494 |  |  | 8 | % |  | 165,779 |  |  | 8 | % |
| Brazil |  | 107,616 |  |  | 5 | % |  | 103,496 |  |  | 5 | % |
| Other |  | 463,248 |  |  | 22 | % |  | 366,930 |  |  | 18 | % |
|  |  | $ | 2,143,221 |  |  |  |  |  | $ | 2,092,167 |  |  |  |  |

[0001628280-15-005450:mdna:14]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and industrial campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer electronics and industrial products for leading multinational and regional OEMs. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0001628280-15-005450:mdna:15]
31

[0001628280-15-005450:mdna:16]
[same as prior period, unchanged from 0001104659-15-005354:mdna:13]

[0001628280-15-005450:mdna:17]
| • | changes in the macro-economic environment and related changes in consumer demand; |

[0001628280-15-005450:mdna:18]
| • | the mix of the manufacturing services we are providing, the number and size of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors; |

[0001628280-15-005450:mdna:19]
| • | the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance; |

[0001628280-15-005450:mdna:20]
| • | our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our OEM customers; |

[0001628280-15-005450:mdna:21]
| • | the effects on our business due to our customers’ products having short product life cycles; |

[0001628280-15-005450:mdna:22]
| • | our customers’ ability to cancel or delay orders or change production quantities; |

[0001628280-15-005450:mdna:23]
| • | our customers’ decision to choose internal manufacturing instead of outsourcing for their product requirements; |

[0001628280-15-005450:mdna:24]
| • | our exposure to financially troubled customers; |

[0001628280-15-005450:mdna:25]
| • | integration of acquired businesses and facilities; |

[0001628280-15-005450:mdna:26]
| • | increased labor costs due to adverse labor conditions in the markets we operate; and |

[0001628280-15-005450:mdna:27]
| • | changes in tax legislation. |

[0001628280-15-005450:mdna:28]
[same as prior period, unchanged from 0001104659-15-005354:mdna:25]

[0001628280-15-005450:mdna:29]
[same as prior period, unchanged from 0001104659-15-005354:mdna:26]

[0001628280-15-005450:mdna:30]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2015, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0001628280-15-005450:mdna:31]
[same as prior period, unchanged from 0001104659-15-005354:mdna:28]

[0001628280-15-005450:mdna:32]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read in conjunction with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our 2015 Annual Report on Form 10-K.

[0001628280-15-005450:mdna:33]
|  | Three-Month Periods Ended |
|  | June 26, 2015 |  | June 27, 2014 |
| Net sales | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.7 |  |  | 94.3 |  |
| Gross profit | 6.3 |  |  | 5.7 |  |
| Selling, general and administrative expenses | 3.8 |  |  | 3.2 |  |
| Intangible amortization | 0.1 |  |  | 0.1 |  |
| Interest and other, net | 0.3 |  |  | 0.3 |  |
| Other charges (income), net | 0.0 |  |  | (0.7 | ) |
| Income before income taxes | 2.1 |  |  | 2.8 |  |
| Provision for income taxes | 0.1 |  |  | 0.2 |  |
| Net income | 2.0 | % |  | 2.6 | % |

[0001628280-15-005450:mdna:34]
[same as prior period, unchanged from 0001104659-15-005354:mdna:31]

[0001628280-15-005450:mdna:35]
[same as prior period, unchanged from 0001104659-15-005354:mdna:32]

[0001628280-15-005450:mdna:36]
|  |  | Three-Month Periods Ended |
| Business groups: |  | June 26, 2015 |  | June 27, 2014 |
|  |  | (In thousands) |
| Integrated Network Solutions |  | $ | 1,966,562 |  |  | 35 | % |  | $ | 2,440,425 |  |  | 37 | % |
| Consumer Technology Group |  | 1,564,964 |  |  | 28 | % |  | 2,222,141 |  |  | 33 | % |
| Industrial & Emerging Industries |  | 1,130,138 |  |  | 21 | % |  | 1,124,466 |  |  | 17 | % |
| High Reliability Solutions |  | 904,584 |  |  | 16 | % |  | 855,713 |  |  | 13 | % |
|  |  | $ | 5,566,248 |  |  |  |  |  | $ | 6,642,745 |  |  |  |  |

[0001628280-15-005450:mdna:37]
Net sales during the three-month period ended June 26, 2015 totaled $5.6 billion, representing a decrease of approximately $1.0 billion, or 16% from $6.6 billion during the three-month period ended June 27, 2014. The decline in net sales was primarily due to $0.7 billion and $0.5 billion decreases in our CTG and INS business groups, respectively, predominantly due to softness in our mobile devices business as well as broad declines in our telecom, server and storage businesses. These decreases were offset by small increases in our HRS business group, attributable to higher sales to our medical customers. Net sales decreased $0.7 billion to $2.7 billion in Asia, $0.2 billion to $2.0 billion in the Americas and $0.2 billion to $0.9 billion in Europe, respectively.

[0001628280-15-005450:mdna:38]
Our ten largest customers during the three-month period ended June 26, 2015 and June 27, 2014 accounted for approximately 45% and 53% of net sales, respectively. Motorola Mobility (including net sales from its parent Lenovo) accounted for more than 10% of net sales during the three-month period ended June 26, 2015. Motorola Mobility (including net sales from its former parent Google at that time) accounted for more than 10% of net sales during the three-month period ended June 27, 2014.

[0001628280-15-005450:mdna:39]
[same as prior period, unchanged from 0001104659-15-005354:mdna:37]

[0001628280-15-005450:mdna:40]
[same as prior period, unchanged from 0001104659-15-005354:mdna:38]

[0001628280-15-005450:mdna:41]
33

[0001628280-15-005450:mdna:42]
Gross profit during the three-month period ended June 26, 2015 decreased $28.4 million to $352.3 million, or 6.3% of net sales, from $380.8 million, or 5.7% of net sales, during the three-month period ended June 27, 2014. Gross margins improved 60 basis points in the three-month period ended June 26, 2015 compared to that of the three-month period ended June 27, 2014 primarily as a result of increased sales from our higher margin HRS business group coupled with improved operational efficiencies, which was offset by a decrease in the gross margin of our IEI business group due to underperformance on certain program ramps during the quarter and heavier investments in segment resources.

[0001628280-15-005450:mdna:43]
[same as prior period, unchanged from 0001104659-15-005354:mdna:40]

[0001628280-15-005450:mdna:44]
Selling, general and administrative expenses (“SG&A”) amounted to $209.4 million, or 3.8% of net sales, during the three-month period ended June 26, 2015, remaining consistent from the three-month period ended June 27, 2014, which amounted to $209.3 million, or 3.2% of net sales. The slight increase in SG&A compared to the prior year is due to an increase of share-based compensation expense of $4.0 million, offset by $3.9 million of cost reductions as we continue to drive productivity and efficiency improvements.

[0001628280-15-005450:mdna:45]
We expect SG&A to increase in subsequent periods as we integrate new acquisitions.

[0001628280-15-005450:mdna:46]
[same as prior period, unchanged from 0001104659-15-005354:mdna:42]

[0001628280-15-005450:mdna:47]
Amortization of intangible assets increased by $0.7 million during the three-month period ended June 26, 2015 to $7.7 million from $7.0 million for the three-month period ended June 27, 2014. The increase is primarily due to incremental amortization expense on intangible assets relating to our acquisitions completed during the latter part of fiscal year 2015. We expect intangible amortization to increase in subsequent periods due to previously announced acquisitions that have closed at the beginning of our second quarter ending September 25, 2015.

[0001628280-15-005450:mdna:48]
[same as prior period, unchanged from 0001104659-15-005354:mdna:44]

[0001628280-15-005450:mdna:49]
Interest and other, net was $16.5 million during the three-month period ended June 26, 2015 compared to $18.6 million during the three-month period ended June 27, 2014. The decrease in interest and other, net of $2.1 million was primarily due to an increase of foreign currency gain in the current period of $3.6 million, offset by an increase of interest expense of $1.6 million primarily from the new 4.750% Notes due June 15, 2025 as further discussed in note 6 to the condensed consolidated financial statements. We expect interest and other, net to increase in subsequent periods for the interest expense on the 4.750% Notes.

[0001628280-15-005450:mdna:50]
[same as prior period, unchanged from 0001104659-15-005354:mdna:48]

[0001628280-15-005450:mdna:51]
Other charges (income), net was $44.0 million of other income during the three-month period ended June 27, 2014 principally as a result of the reversal of a contractual obligation with a certain customer recognized during the fourth quarter of fiscal year 2014 in the amount of $55.0 million. This was partially offset by an $11.0 million loss in connection with the disposition of a manufacturing facility in Western Europe.

[0001628280-15-005450:mdna:52]
[same as prior period, unchanged from 0001104659-15-005354:mdna:51]

[0001628280-15-005450:mdna:53]
Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 13, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2015 for further discussion.

[0001628280-15-005450:mdna:54]
[same as prior period, unchanged from 0001104659-15-005354:mdna:53]

[0001628280-15-005450:mdna:55]
The consolidated effective tax rate was 6.5% and 8.4% for the three-month periods ended June 26, 2015 and June 27, 2014, respectively, and varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions, operating loss carryforwards, income tax credits, previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. We generate most of our revenues and profits from operations outside of Singapore. The effective tax rate for the three-month periods ended June 26, 2015 is lower than the effective tax rate for the

[0001628280-15-005450:mdna:56]
three-month periods ended June 27, 2014 primarily due to a favorable audit settlement which resulted in the release of an accrual for uncertain tax positions.

[0001628280-15-005450:mdna:57]
[same as prior period, unchanged from 0001104659-15-005354:mdna:55]

[0001628280-15-005450:mdna:58]
As of June 26, 2015, we had cash and cash equivalents of approximately $2.3 billion and bank and other borrowings of approximately $2.7 billion, of which approximately $595.3 million relates to proceeds received from a debt offering during the three-month period ended June 26, 2015. In the beginning of our second quarter ending September 25, 2015, we paid approximately $555.0 million, net of cash acquired, related to the acquisition of MCi, of which approximately $477.0 million was paid to acquire the outstanding share capital and approximately $78.0 million was paid to retire the pre-existing debt. We also paid approximately $69.5 million in the beginning of the second quarter ending September 25, 2015, to acquire an optical transport plant from Alcatel-Lucent. We have a $1.5 billion revolving credit facility that expires in March 2019, under which there were no borrowings outstanding as of the end of the quarter. As of June 26, 2015, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0001628280-15-005450:mdna:59]
Cash provided by operating activities was $362.3 million during the three-month period ended June 26, 2015. This resulted primarily from $110.9 million of net income for the period plus adjustments for $110.1 million of non-cash charges such as depreciation, amortization, and other impairment charges, and by $141.3 million from changes in our operating assets and liabilities. These changes were mainly related to a decrease in accounts receivable and inventory driven by the decline in sales activity, offset by a decrease in accounts payable due to timing of payments to suppliers.

[0001628280-15-005450:mdna:60]
[same as prior period, unchanged from 0001104659-15-005354:mdna:58]

[0001628280-15-005450:mdna:61]
|  | Three-Month Periods Ended |
|  | June 26, 2015 |  | March 31, 2015 |  | June 27, 2014 |
| Days in trade accounts receivable | 46 days |  | 46 days |  | 45 days |
| Days in inventory | 60 days |  | 58 days |  | 52 days |
| Days in accounts payable | 78 days |  | 77 days |  | 69 days |
| Cash conversion cycle | 28 days |  | 27 days |  | 28 days |

[0001628280-15-005450:mdna:62]
Days in trade accounts receivable was calculated as average accounts receivable for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended June 26, 2015, days in trade accounts receivable increased by 1 day compared to the three-month period ended June 27, 2014 largely due to timing of invoicing customers during the current period. Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $516.3 million, $600.7 million, and $463.1 million for the quarters ended June 26, 2015, March 31, 2015, and June 27, 2014, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 10 to the condensed consolidated financial statements.

[0001628280-15-005450:mdna:63]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in inventory increased by 8 days compared to the three-month period ended June 27, 2014 primarily as a result of increased inventory driven from several programs launched in the latter part of fiscal year 2015 coupled with lower than expected sales activity in the current quarter.

[0001628280-15-005450:mdna:64]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable increased by 9 days during the three-month period ended June 26, 2015, compared to the three-month period ended June 27, 2014 primarily due to timing of payments, combined with lower cost of sales.

[0001628280-15-005450:mdna:65]
Our cash conversion cycle was calculated as the sum of days of inventory and days of accounts receivables outstanding less days payable outstanding. Our cash conversion cycle remained constant at 28 days for both periods ended June 26, 2015 and June 27, 2014, respectively, due to the factors for each of the components in the calculation discussed above.

[0001628280-15-005450:mdna:66]
35

[0001628280-15-005450:mdna:67]
Cash used in investing activities amounted to $162.0 million during the three-month period ended June 26, 2015. This resulted primarily from $136.8 million of net capital expenditures for property and equipment to support certain programs. We also paid $18.6 million for the acquisition of three businesses completed during the three-month period ended June 26, 2015. Other investing activities includes $12.2 million of proceeds from the sale of certain assets that were purchased on behalf of a customer and financed by a third party banking institution.

[0001628280-15-005450:mdna:68]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the three-month period ended June 26, 2015 was $225.4 million compared to a use of $154.1 million for the three-month period ended June 27, 2014. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0001628280-15-005450:mdna:69]
|  | Three-Month Periods Ended |
|  | June 26, 2015 |  | June 27, 2014 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 362,276 |  |  | $ | (81,169 | ) |
| Purchases of property and equipment | (138,348 | ) |  | (87,101 | ) |
| Proceeds from the disposition of property and equipment | 1,512 |  |  | 14,184 |  |
| Free cash flow | $ | 225,440 |  |  | $ | (154,086 | ) |

[0001628280-15-005450:mdna:70]
Cash provided by financing activities was $506.4 million during the three-month period ended June 26, 2015, which was primarily for net proceeds from bank borrowings and long-term debt of $595.5 million mainly resulting from our new debt issuance discussed further in note 5 to the condensed consolidated financial statements, and $44.6 million from the issuance of our shares for option exercises. These cash inflows were partially offset by cash paid for the repurchase of our ordinary shares in the amount of $100.0 million.

[0001628280-15-005450:mdna:71]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of June 26, 2015 and March 31, 2015, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $800.0 million as of March 31, 2015). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0001628280-15-005450:mdna:72]
[same as prior period, unchanged from 0001104659-15-005354:mdna:69]

[0001628280-15-005450:mdna:73]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under asset-backed securitization programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements.

[0001628280-15-005450:mdna:74]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0001628280-15-005450:mdna:75]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 28, 2014. During the three-month period ended June 26, 2015, we paid $100.0 million to repurchase shares (under the current repurchase plan) at an average price of $12.25 per share. As of June 26, 2015, shares in the aggregate amount of $144.0 million were available to be repurchased under the current plan.

[0001628280-15-005450:mdna:76]
[same as prior period, unchanged from 0001104659-15-005354:mdna:73]

[0001628280-15-005450:mdna:77]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2015. There have been no material changes in our contractual obligations and commitments since March 31, 2015.

[0001628280-15-005450:mdna:78]
[same as prior period, unchanged from 0001104659-15-005354:mdna:75]

[0001628280-15-005450:mdna:79]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of June 26, 2015 and March 31, 2015, the fair values of our deferred purchase price receivable were approximately $516.3 million and $600.7 million, respectively. As of June 26, 2015 and March 31, 2015, the outstanding balances on receivables sold for cash were $1.4 billion and $1.3 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information see note 10 to the condensed consolidated financial statements.
