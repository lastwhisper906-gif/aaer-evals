# FLEX notes — 0001628280-15-005450


## flex:InterestAndOtherNetTextBlock

[0001628280-15-005450:notes:1]
INTEREST AND OTHER, NET

[0001628280-15-005450:notes:2]
During the three-month periods ended June 26, 2015 and June 27, 2014, the Company recognized interest expense of $20.1 million and $18.5 million, respectively, on its debt obligations outstanding during the period.

[0001628280-15-005450:notes:3]
During the three-month periods ended June 26, 2015 and June 27, 2014, the Company recognized interest income of $3.5 million and $5.3 million, respectively.


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0001628280-15-005450:notes:4]
The following table summarizes the activity in the deferred purchase price receivables account:

[0001628280-15-005450:notes:5]
|  | Three-Month Periods Ended |
|  | June 26, 2015 |  | June 27, 2014 |
|  | (In thousands) |
| Beginning balance | $ | 600,672 |  |  | $ | 470,908 |  |
| Transfers of receivables | 767,048 |  |  | 778,860 |  |
| Collections | (851,433 | ) |  | (786,644 | ) |
| Ending balance | $ | 516,287 |  |  | $ | 463,124 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001628280-15-005450:notes:6]
SUPPLEMENTAL GUARANTOR AND NON-GUARANTOR CONDENSED CONSOLIDATING FINANCIAL STATEMENTS

[0001628280-15-005450:notes:7]
Flextronics International Ltd. (“Parent”) has three tranches of Notes of $500 million, $500 million, and $600 million, respectively, each outstanding, which mature on February 15, 2020, February 15, 2023 and June 15, 2025, respectively. These Notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company’s 100% owned subsidiaries (the “guarantor subsidiaries”). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade.

[0001628280-15-005450:notes:8]
[same as prior period, unchanged from 0001104659-15-005354:notes:9]

[0001628280-15-005450:notes:9]
Condensed Consolidating Balance Sheets as of June 26, 2015

[0001628280-15-005450:notes:10]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1,347,411 |  |  | $ | 209,441 |  |  | $ | 774,559 |  |  | $ | — |  |  | $ | 2,331,411 |  |
| Accounts receivable | — |  |  | 1,080,525 |  |  | 1,056,730 |  |  | — |  |  | 2,137,255 |  |
| Inventories | — |  |  | 1,616,735 |  |  | 1,796,695 |  |  | — |  |  | 3,413,430 |  |
| Inter company receivable | 7,095,635 |  |  | 5,210,421 |  |  | 11,167,310 |  |  | (23,473,366 | ) |  | — |  |
| Other current assets | 1,677 |  |  | 208,381 |  |  | 988,073 |  |  | — |  |  | 1,198,131 |  |
| Total current assets | 8,444,723 |  |  | 8,325,503 |  |  | 15,783,367 |  |  | (23,473,366 | ) |  | 9,080,227 |  |
| Property and equipment, net | — |  |  | 497,172 |  |  | 1,646,049 |  |  | — |  |  | 2,143,221 |  |
| Goodwill and other intangible assets, net | 400 |  |  | 59,725 |  |  | 368,161 |  |  | — |  |  | 428,286 |  |
| Other assets | 2,257,484 |  |  | 192,856 |  |  | 2,118,449 |  |  | (4,120,343 | ) |  | 448,446 |  |
| Investment in subsidiaries | 1,678,491 |  |  | 1,801,725 |  |  | 16,697,245 |  |  | (20,177,461 | ) |  | — |  |
| Total assets | $ | 12,381,098 |  |  | $ | 10,876,981 |  |  | $ | 36,613,271 |  |  | $ | (47,771,170 | ) |  | $ | 12,100,180 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 40,000 |  |  | $ | 952 |  |  | $ | 3,975 |  |  | $ | — |  |  | $ | 44,927 |  |
| Accounts payable | — |  |  | 1,619,892 |  |  | 2,717,021 |  |  | — |  |  | 4,336,913 |  |
| Accrued payroll | — |  |  | 117,485 |  |  | 246,044 |  |  | — |  |  | 363,529 |  |
| Inter company payable | 7,179,540 |  |  | 7,858,602 |  |  | 8,435,224 |  |  | (23,473,366 | ) |  | — |  |
| Other current liabilities | 47,001 |  |  | 776,252 |  |  | 927,606 |  |  | — |  |  | 1,750,859 |  |
| Total current liabilities | 7,266,541 |  |  | 10,373,183 |  |  | 12,329,870 |  |  | (23,473,366 | ) |  | 6,496,228 |  |
| Long term liabilities | 2,662,890 |  |  | 2,105,617 |  |  | 2,468,232 |  |  | (4,120,343 | ) |  | 3,116,396 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) | 2,451,667 |  |  | (1,601,819 | ) |  | 21,779,273 |  |  | (20,177,461 | ) |  | 2,451,660 |  |
| Noncontrolling interests | — |  |  | — |  |  | 35,896 |  |  | — |  |  | 35,896 |  |
| Total shareholders’ equity (deficit) | 2,451,667 |  |  | (1,601,819 | ) |  | 21,815,169 |  |  | (20,177,461 | ) |  | 2,487,556 |  |
| Total liabilities and shareholders’ equity | $ | 12,381,098 |  |  | $ | 10,876,981 |  |  | $ | 36,613,271 |  |  | $ | (47,771,170 | ) |  | $ | 12,100,180 |  |

[0001628280-15-005450:notes:11]
Condensed Consolidating Balance Sheets as of March 31, 2015

[0001628280-15-005450:notes:12]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 608,971 |  |  | $ | 168,272 |  |  | $ | 851,165 |  |  | $ | — |  |  | $ | 1,628,408 |  |
| Accounts receivable | — |  |  | 1,193,491 |  |  | 1,144,024 |  |  | — |  |  | 2,337,515 |  |
| Inventories | — |  |  | 1,729,593 |  |  | 1,759,159 |  |  | — |  |  | 3,488,752 |  |
| Inter company receivable | 6,417,410 |  |  | 4,774,526 |  |  | 10,218,788 |  |  | (21,410,724 | ) |  | — |  |
| Other current assets | 8,143 |  |  | 200,476 |  |  | 1,077,606 |  |  | — |  |  | 1,286,225 |  |
| Total current assets | 7,034,524 |  |  | 8,066,358 |  |  | 15,050,742 |  |  | (21,410,724 | ) |  | 8,740,900 |  |
| Property and equipment, net | — |  |  | 471,052 |  |  | 1,621,115 |  |  | — |  |  | 2,092,167 |  |
| Goodwill and other intangible assets, net | 475 |  |  | 60,782 |  |  | 353,918 |  |  | — |  |  | 415,175 |  |
| Other assets | 2,223,402 |  |  | 155,172 |  |  | 2,131,523 |  |  | (4,092,715 | ) |  | 417,382 |  |
| Investment in subsidiaries | 1,799,956 |  |  | 1,677,813 |  |  | 16,641,211 |  |  | (20,118,980 | ) |  | — |  |
| Total assets | $ | 11,058,357 |  |  | $ | 10,431,177 |  |  | $ | 35,798,509 |  |  | $ | (45,622,419 | ) |  | $ | 11,665,624 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 40,000 |  |  | $ | 917 |  |  | $ | 5,245 |  |  | $ | — |  |  | $ | 46,162 |  |
| Accounts payable | — |  |  | 1,772,695 |  |  | 2,788,499 |  |  | — |  |  | 4,561,194 |  |
| Accrued payroll | — |  |  | 112,692 |  |  | 227,047 |  |  | — |  |  | 339,739 |  |
| Inter company payable | 6,559,569 |  |  | 7,309,944 |  |  | 7,541,211 |  |  | (21,410,724 | ) |  | — |  |
| Other current liabilities | 30,553 |  |  | 772,015 |  |  | 1,006,560 |  |  | — |  |  | 1,809,128 |  |
| Total current liabilities | 6,630,122 |  |  | 9,968,263 |  |  | 11,568,562 |  |  | (21,410,724 | ) |  | 6,756,223 |  |
| Long term liabilities | 2,067,421 |  |  | 2,102,483 |  |  | 2,435,962 |  |  | (4,092,715 | ) |  | 2,513,151 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) | 2,360,814 |  |  | (1,639,569 | ) |  | 21,758,549 |  |  | (20,118,980 | ) |  | 2,360,814 |  |
| Noncontrolling interests | — |  |  | — |  |  | 35,436 |  |  | — |  |  | 35,436 |  |
| Total shareholders’ equity (deficit) | 2,360,814 |  |  | (1,639,569 | ) |  | 21,793,985 |  |  | (20,118,980 | ) |  | 2,396,250 |  |
| Total liabilities and shareholders’ equity | $ | 11,058,357 |  |  | $ | 10,431,177 |  |  | $ | 35,798,509 |  |  | $ | (45,622,419 | ) |  | $ | 11,665,624 |  |

[0001628280-15-005450:notes:13]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended June 26, 2015

[0001628280-15-005450:notes:14]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 3,834,526 |  |  | $ | 3,945,465 |  |  | $ | (2,213,743 | ) |  | $ | 5,566,248 |  |
| Cost of sales | — |  |  | 3,442,739 |  |  | 3,984,911 |  |  | (2,213,743 | ) |  | 5,213,907 |  |
| Gross profit | — |  |  | 391,787 |  |  | (39,446 | ) |  | — |  |  | 352,341 |  |
| Selling, general and administrative expenses | — |  |  | 60,944 |  |  | 148,441 |  |  | — |  |  | 209,385 |  |
| Intangible amortization | 75 |  |  | 731 |  |  | 6,865 |  |  | — |  |  | 7,671 |  |
| Interest and other, net | (267,052 | ) |  | 331,716 |  |  | (47,995 | ) |  | — |  |  | 16,669 |  |
| Income (loss) from continuing operations before income taxes | 266,977 |  |  | (1,604 | ) |  | (146,757 | ) |  | — |  |  | 118,616 |  |
| Provision for income taxes | — |  |  | 9,099 |  |  | (1,333 | ) |  | — |  |  | 7,766 |  |
| Equity in earnings in subsidiaries | (156,127 | ) |  | (18,807 | ) |  | 35,653 |  |  | 139,281 |  |  | — |  |
| Net income (loss) | $ | 110,850 |  |  | $ | (29,510 | ) |  | $ | (109,771 | ) |  | $ | 139,281 |  |  | $ | 110,850 |  |

[0001628280-15-005450:notes:15]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended June 27, 2014

[0001628280-15-005450:notes:16]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 4,511,228 |  |  | $ | 4,805,682 |  |  | $ | (2,674,165 | ) |  | $ | 6,642,745 |  |
| Cost of sales | — |  |  | 4,158,191 |  |  | 4,777,934 |  |  | (2,674,165 | ) |  | 6,261,960 |  |
| Gross profit | — |  |  | 353,037 |  |  | 27,748 |  |  | — |  |  | 380,785 |  |
| Selling, general and administrative expenses | — |  |  | 54,494 |  |  | 154,783 |  |  | — |  |  | 209,277 |  |
| Intangible amortization | 75 |  |  | 623 |  |  | 6,253 |  |  | — |  |  | 6,951 |  |
| Interest and other, net | 16,531 |  |  | 259,751 |  |  | (301,654 | ) |  | — |  |  | (25,372 | ) |
| Income (loss) from continuing operations before income taxes | (16,606 | ) |  | 38,169 |  |  | 168,366 |  |  | — |  |  | 189,929 |  |
| Provision for income taxes | — |  |  | 6,648 |  |  | 9,394 |  |  | — |  |  | 16,042 |  |
| Equity in earnings in subsidiaries | 190,493 |  |  | 60,982 |  |  | 36,431 |  |  | (287,906 | ) |  | — |  |
| Net income | $ | 173,887 |  |  | $ | 92,503 |  |  | $ | 195,403 |  |  | $ | (287,906 | ) |  | $ | 173,887 |  |

[0001628280-15-005450:notes:17]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended June 26, 2015

[0001628280-15-005450:notes:18]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 110,850 |  |  | $ | (29,510 | ) |  | $ | (109,771 | ) |  | $ | 139,281 |  |  | $ | 110,850 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 2,783 |  |  | (23,490 | ) |  | (20,897 | ) |  | 44,387 |  |  | 2,783 |  |
| Unrealized gain on derivative instruments and other, net of zero tax | 12,829 |  |  | 4,624 |  |  | 12,829 |  |  | (17,453 | ) |  | 12,829 |  |
| Comprehensive income (loss) | $ | 126,462 |  |  | $ | (48,376 | ) |  | $ | (117,839 | ) |  | $ | 166,215 |  |  | $ | 126,462 |  |

[0001628280-15-005450:notes:19]
Condensed Consolidating Statements of Comprehensive Income for the Three-Month Period Ended June 27, 2014

[0001628280-15-005450:notes:20]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income | $ | 173,887 |  |  | $ | 92,503 |  |  | $ | 195,403 |  |  | $ | (287,906 | ) |  | $ | 173,887 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (4,145 | ) |  | 15,950 |  |  | 5,726 |  |  | (21,676 | ) |  | (4,145 | ) |
| Unrealized gain on derivative instruments and other, net of zero tax | 10,725 |  |  | 1,830 |  |  | 10,725 |  |  | (12,555 | ) |  | 10,725 |  |
| Comprehensive income | $ | 180,467 |  |  | $ | 110,283 |  |  | $ | 211,854 |  |  | $ | (322,137 | ) |  | $ | 180,467 |  |

[0001628280-15-005450:notes:21]
Condensed Consolidating Statements of Cash Flows for the Three-Month Period Ended June 26, 2015

[0001628280-15-005450:notes:22]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 279,177 |  |  | $ | (6,637 | ) |  | $ | 89,736 |  |  | $ | — |  |  | 362,276 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (47,108 | ) |  | (89,728 | ) |  | — |  |  | (136,836 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | (2,785 | ) |  | (15,795 | ) |  | — |  |  | (18,580 | ) |
| Proceeds from divesture of business, net of cash held in divested business | — |  |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Investing cash flows to affiliates | (718,381 | ) |  | (263,348 | ) |  | (1,077,202 | ) |  | 2,058,931 |  |  | — |  |
| Other investing activities, net | — |  |  | (14,732 | ) |  | 7,152 |  |  | — |  |  | (7,580 | ) |
| Net cash used in investing activities | (718,381 | ) |  | (327,973 | ) |  | (1,174,573 | ) |  | 2,058,931 |  |  | (161,996 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 595,309 |  |  | 221 |  |  | 18 |  |  | — |  |  | 595,548 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (6,604 | ) |  | (493 | ) |  | (1,360 | ) |  | — |  |  | (8,457 | ) |
| Payments for repurchases of ordinary shares | (99,995 | ) |  | — |  |  | — |  |  | — |  |  | (99,995 | ) |
| Net proceeds from issuance of ordinary shares | 44,602 |  |  | — |  |  | — |  |  | — |  |  | 44,602 |  |
| Financing cash flows from affiliates | 619,970 |  |  | 377,012 |  |  | 1,061,949 |  |  | (2,058,931 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | (25,252 | ) |  | — |  |  | (25,252 | ) |
| Net cash provided by financing activities | 1,153,282 |  |  | 376,740 |  |  | 1,035,355 |  |  | (2,058,931 | ) |  | 506,446 |  |
| Effect of exchange rates on cash and cash equivalents | 24,362 |  |  | (961 | ) |  | (27,124 | ) |  | — |  |  | (3,723 | ) |
| Net increase (decrease) in cash and cash equivalents | 738,440 |  |  | 41,169 |  |  | (76,606 | ) |  | — |  |  | 703,003 |  |
| Cash and cash equivalents, beginning of period | 608,971 |  |  | 168,272 |  |  | 851,165 |  |  | — |  |  | 1,628,408 |  |
| Cash and cash equivalents, end of period | $ | 1,347,411 |  |  | $ | 209,441 |  |  | $ | 774,559 |  |  | $ | — |  |  | $ | 2,331,411 |  |

[0001628280-15-005450:notes:23]
Condensed Consolidating Statements of Cash Flows for the Three-Month Period Ended June 27, 2014

[0001628280-15-005450:notes:24]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | (13,025 | ) |  | $ | 231,140 |  |  | $ | (299,284 | ) |  | $ | — |  |  | $ | (81,169 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (39,690 | ) |  | (33,227 | ) |  | — |  |  | (72,917 | ) |
| Proceeds from divestiture of business, net of cash held in divested business | — |  |  | — |  |  | (5,493 | ) |  | — |  |  | (5,493 | ) |
| Investing cash flows from (to) affiliates | (1,185,671 | ) |  | (532,104 | ) |  | 593,559 |  |  | 1,124,216 |  |  | — |  |
| Other investing activities, net | — |  |  | (959 | ) |  | (20,503 | ) |  | — |  |  | (21,462 | ) |
| Net cash provided by (used in) investing activities | (1,185,671 | ) |  | (572,753 | ) |  | 534,336 |  |  | 1,124,216 |  |  | (99,872 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | — |  |  | — |  |  | 26,615 |  |  | — |  |  | 26,615 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | — |  |  | (393 | ) |  | (466 | ) |  | — |  |  | (859 | ) |
| Payments for repurchases of ordinary shares | (105,568 | ) |  | — |  |  | — |  |  | — |  |  | (105,568 | ) |
| Net proceeds from issuance of ordinary shares | 9,329 |  |  | — |  |  | — |  |  | — |  |  | 9,329 |  |
| Financing cash flows from (to) affiliates | 931,635 |  |  | 347,775 |  |  | (155,194 | ) |  | (1,124,216 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | 300 |  |  | — |  |  | 300 |  |
| Net cash provided by (used in) financing activities | 835,396 |  |  | 347,382 |  |  | (128,745 | ) |  | (1,124,216 | ) |  | (70,183 | ) |
| Effect of exchange rates on cash and cash equivalents | (10,141 | ) |  | (504 | ) |  | 15,831 |  |  | — |  |  | 5,186 |  |
| Net decrease (increase) in cash and cash equivalents | (373,441 | ) |  | 5,265 |  |  | 122,138 |  |  | — |  |  | (246,038 | ) |
| Cash and cash equivalents, beginning of period | 638,714 |  |  | 210,462 |  |  | 744,552 |  |  | — |  |  | 1,593,728 |  |
| Cash and cash equivalents, end of period | $ | 265,273 |  |  | $ | 215,727 |  |  | $ | 866,690 |  |  | $ | — |  |  | $ | 1,347,690 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-15-005450:notes:25]
BUSINESS AND ASSETS ACQUISITIONS

[0001628280-15-005450:notes:26]
During the three-month period ended June 26, 2015, the Company completed three acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company.  Two of the acquired businesses expanded the Company’s capabilities in the medical devices market, particularly precision plastics and molding within the HRS business group, and the other strengthened capabilities in the household industrial market within the IEI business group. The Company paid $15.3 million, net of $0.1 million of cash held by the acquirees. The Company primarily acquired $2.0 million of property and equipment, assumed liabilities of $0.6 million and recorded goodwill and intangibles of $18.9 million. The results of operations were included in the Company’s consolidated financial results beginning on the date of these acquisitions. Pro-forma results of operations for these acquisitions have not been presented because the effects of the acquisitions were immaterial to the Company’s consolidated financial results for all periods presented.

[0001628280-15-005450:notes:27]
The Company is in the process of evaluating the fair value of the assets and liabilities related to business combinations completed during the recent periods. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisition. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the respective measurement periods.

[0001628280-15-005450:notes:28]
In the beginning of the Company's second quarter ending September 25, 2015, the Company completed the acquisition of Mirror Controls International (MCi) from private equity firm Egeria, and paid approximately $555.0 million, net of cash acquired, of which approximately $477.0 million was paid to acquire the entire outstanding share capital of MCi and approximately $78.0 million was to retire pre-existing debt. The financial results of MCi will be included in the consolidated financial statements of the Company as part of the HRS business group beginning in the second quarter of fiscal year 2016.

[0001628280-15-005450:notes:29]
The Company also paid approximately $69.5 million in the beginning of the second quarter ending September 25, 2015, to acquire an optical transport plant from Alcatel-Lucent, which will be included in the INS business group.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-15-005450:notes:30]
COMMITMENTS AND CONTINGENCIES

[0001628280-15-005450:notes:31]
Litigation and other legal matters

[0001628280-15-005450:notes:32]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431). The complaint asserted various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products. The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys' fees and costs. The plaintiff also seeks a jury trial. Although the outcome of this matter is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of this matter, which are in excess of amounts already accrued in the Company's consolidated balance sheets, would not be material to the financial statements.

[0001628280-15-005450:notes:33]
During the fourth quarter of fiscal year 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010. This assessment is in the second stage of the review process at the administrative level, and the Company plans to continue to vigorously oppose it as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, the Company is unable to reasonably estimate a range of loss, if any. The Company does not expect final judicial determination on these claims for several years.

[0001628280-15-005450:notes:34]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties. The Company believes there is no legal basis for the assessment and expects that any losses are remote. The Company plans to vigorously defend itself through the administrative and judicial processes.

[0001628280-15-005450:notes:35]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-15-005450:notes:36]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001628280-15-005450:notes:37]
[same as prior period, unchanged from 0001104659-15-005354:notes:43]

[0001628280-15-005450:notes:38]
|  | Three-Month Period Ended |  | Three-Month Period Ended |
|  | June 26, 2015 |  | June 27, 2014 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
| Beginning balance | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |  | $ | (32,849 | ) |  | $ | (93,307 | ) |  | $ | (126,156 | ) |
| Other comprehensive gain (loss) before reclassifications | (601 | ) |  | 2,631 |  |  | 2,030 |  |  | 1,000 |  |  | 5,107 |  |  | 6,107 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 13,430 |  |  | 152 |  |  | 13,582 |  |  | 9,725 |  |  | (9,252 | ) |  | 473 |  |
| Net current-period other comprehensive gain (loss) | 12,829 |  |  | 2,783 |  |  | 15,612 |  |  | 10,725 |  |  | (4,145 | ) |  | 6,580 |  |
| Ending balance | $ | (55,437 | ) |  | $ | (109,456 | ) |  | $ | (164,893 | ) |  | $ | (22,124 | ) |  | $ | (97,452 | ) |  | $ | (119,576 | ) |

[0001628280-15-005450:notes:39]
Net losses reclassified from accumulated other comprehensive loss during the three-month period ended June 26, 2015 relating to derivative instruments and other includes $12.9 million attributable to the Company’s cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations.

[0001628280-15-005450:notes:40]
During the three-month period ended June 27, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. This loss includes the settlement of unrealized losses of $4.2 million on an insignificant defined benefit plan associated with the disposed facility offset by the release of cumulative foreign currency translation gains of $9.3 million, both of which have been reclassified from accumulated other comprehensive loss during the period. The loss on sale is included in other charges (income), net in the condensed consolidated statement of operations.

[0001628280-15-005450:notes:41]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended June 27, 2014, was recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:DebtDisclosureTextBlock

[0001628280-15-005450:notes:42]
BANK BORROWINGS AND LONG TERM DEBT

[0001628280-15-005450:notes:43]
Bank borrowings and long-term debt are as follows:

[0001628280-15-005450:notes:44]
|  | As of June 26, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 592,500 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 475,000 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,278 |  |  | — |  |
| Other | 14,287 |  |  | 16,233 |  |
| Total | $ | 2,677,065 |  |  | $ | 2,083,733 |  |

[0001628280-15-005450:notes:45]
The weighted average interest rates for the Company’s long-term debt were 3.5% and 3.2% as of June 26, 2015 and March 31, 2015, respectively,

[0001628280-15-005450:notes:46]
On June 8, 2015, the Company issued $600 million of 4.750% Notes ("Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at a discount of 99.213%. The Company received net proceeds of approximately $595.3 million from the issuance which will be used for general corporate purposes.

[0001628280-15-005450:notes:47]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the Notes. The issuance costs were capitalized and will be amortized over the life of the Notes.

[0001628280-15-005450:notes:48]
Interest on the Notes is payable semi-annually, commencing on December 15, 2015. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Term Loan Agreement and Revolving Line of Credit.

[0001628280-15-005450:notes:49]
At any time prior to March 15, 2025, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0001628280-15-005450:notes:50]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of June 26, 2015, the Company was in compliance with the covenants in the indenture governing the Notes.

[0001628280-15-005450:notes:51]
In connection with the issuance of the Notes, the Company entered into a registration rights agreement under which it has agreed to consummate an offer registered with the Securities and Exchange Commission to issue new notes having terms substantially identical to the Notes (except that the new notes will not be subject to restrictions on transfer) in exchange for outstanding Notes. In some circumstances, the Company may be required to file a shelf registration statement to cover resale of the Notes. If the Company fails to satisfy these obligations, the Company may be required to pay additional interest to holders of the Notes under certain circumstances.

[0001628280-15-005450:notes:52]
Repayment of the Company’s long term debt outstanding as of June 26, 2015 is as follows:

[0001628280-15-005450:notes:53]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 40,000 |  |
| 2017 | 52,500 |  |
| 2018 | 52,500 |  |
| 2019 | 922,500 |  |
| 2020 | 500,000 |  |
| Thereafter | 1,109,565 |  |
| Total | $ | 2,677,065 |  |

[0001628280-15-005450:notes:54]
____________________________________________________________

[0001628280-15-005450:notes:55]
| (1) | Represents scheduled repayment for the remaining nine-month period ending March 31, 2016. |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-15-005450:notes:56]
FINANCIAL INSTRUMENTS

[0001628280-15-005450:notes:57]
[same as prior period, unchanged from 0001104659-15-005354:notes:51]

[0001628280-15-005450:notes:58]
The Company primarily enters into forward contracts and foreign currency swap contracts to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions. The Company hedges committed exposures and does not engage in speculative transactions. As of June 26, 2015, the aggregate notional amount of the Company’s outstanding foreign currency contracts was $5.2 billion as summarized below:

[0001628280-15-005450:notes:59]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  |  |
| CNY |  | 2,449,000 |  |  | — |  |  | $ | 394,542 |  |  | $ | — |  |
| HUF |  | 14,186,000 |  |  | — |  |  | 51,001 |  |  | — |  |
| ILS |  | 112,700 |  |  | — |  |  | 30,024 |  |  | — |  |
| MXN |  | 1,560,700 |  |  | — |  |  | 101,021 |  |  | — |  |
| MYR |  | 220,000 |  |  | — |  |  | 58,640 |  |  | — |  |
| Other |  | N/A |  |  | N/A |  |  | 53,595 |  |  | 6,704 |  |
|  |  |  |  |  |  |  |  | 688,823 |  |  | 6,704 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 581,000 |  |  | — |  |  | 188,020 |  |
| CAD |  | 63,479 |  |  | 56,866 |  |  | 50,900 |  |  | 45,685 |  |
| CHF |  | 7,709 |  |  | 36,309 |  |  | 8,234 |  |  | 38,829 |  |
| CNY |  | 540,765 |  |  | — |  |  | 86,937 |  |  | — |  |
| DKK |  | 196,400 |  |  | 155,700 |  |  | 29,448 |  |  | 23,346 |  |
| EUR |  | 1,514,440 |  |  | 1,353,824 |  |  | 1,692,028 |  |  | 1,513,387 |  |
| GBP |  | 29,331 |  |  | 56,807 |  |  | 46,063 |  |  | 89,114 |  |
| HUF |  | 13,076,000 |  |  | 14,330,000 |  |  | 47,011 |  |  | 51,519 |  |
| ILS |  | 84,400 |  |  | 53,600 |  |  | 22,484 |  |  | 14,279 |  |
| JPY |  | 3,935,864 |  |  | 2,966,700 |  |  | 31,855 |  |  | 24,060 |  |
| MXN |  | 1,326,660 |  |  | 506,980 |  |  | 85,872 |  |  | 32,816 |  |
| MYR |  | 278,081 |  |  | 22,750 |  |  | 74,121 |  |  | 6,064 |  |
| SEK |  | 444,196 |  |  | 801,591 |  |  | 53,694 |  |  | 96,277 |  |
| SGD |  | 34,644 |  |  | 5,774 |  |  | 25,754 |  |  | 4,292 |  |
| Other |  | N/A |  |  | N/A |  |  | 70,483 |  |  | 36,708 |  |
|  |  |  |  |  |  |  |  | 2,324,884 |  |  | 2,164,396 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  |  | $ | 3,013,707 |  |  | $ | 2,171,100 |  |

[0001628280-15-005450:notes:60]
As of June 26, 2015, the fair value of the Company’s short-term foreign currency contracts was not material and is included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of June 26, 2015 and March 31, 2015, the Company also has included net deferred losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to the effective portion of changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses totaled $3.1 million as of June 26, 2015, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0001628280-15-005450:notes:61]
[same as prior period, unchanged from 0001104659-15-005354:notes:55]

[0001628280-15-005450:notes:62]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | June 26, 2015 |  | March 31, 2015 |  | Balance SheetLocation |  | June 26, 2015 |  | March 31, 2015 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 4,498 |  |  | $ | 2,896 |  |  | Other current liabilities |  | $ | 6,160 |  |  | $ | 19,729 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 16,369 |  |  | $ | 22,933 |  |  | Other current liabilities |  | $ | 21,606 |  |  | $ | 11,328 |  |

[0001628280-15-005450:notes:63]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any period presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-15-005450:notes:64]
SHARE-BASED COMPENSATION

[0001628280-15-005450:notes:65]
[same as prior period, unchanged from 0001104659-15-005354:notes:59]

[0001628280-15-005450:notes:66]
|  | Three-Month Periods Ended |
|  | June 26, 2015 |  | June 27, 2014 |
|  | (In thousands) |
| Cost of sales | $ | 2,018 |  |  | $ | 1,611 |  |
| Selling, general and administrative expenses | 14,108 |  |  | 10,071 |  |
| Total share-based compensation expense | $ | 16,126 |  |  | $ | 11,682 |  |

[0001628280-15-005450:notes:67]
Total unrecognized compensation expense related to share options is not significant. As of June 26, 2015, the number of options outstanding and exercisable was 7.9 million and 7.8 million, respectively, at a weighted-average exercise price of $4.66 and $4.65 per share, respectively.

[0001628280-15-005450:notes:68]
During the three-month period ended June 26, 2015, the Company granted 5.7 million unvested share bonus awards. Of this amount, approximately 4.8 million unvested share bonus awards have an average grant date price of $12.10 per share, under the Company's 2010 Equity Incentive Plan. Further, approximately 0.7 million of these unvested shares represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions, and 0.2 million represents the target amount of grants made to certain executive officers whereby vesting is contingent on meeting certain free cash flow targets. The number of shares contingent on market conditions that ultimately will vest range from zero up to a maximum of 1.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met. The number of shares contingent on free cash flow targets that ultimately will vest range from zero up to a maximum of 0.4 million of the target payment based on a measurement of cumulative three-year increase of free cash flow from operations of the Company, and will cliff vest after a period of three years.

[0001628280-15-005450:notes:69]
As of June 26, 2015, approximately 17.7 million unvested share bonus awards were outstanding, of which vesting for a targeted amount of 3.8 million is contingent primarily on meeting certain market conditions.  The number of shares that will ultimately be issued can range from zero to 7.6 million based on the achievement levels of the respective conditions. During the three-month period ended June 26, 2015, 2.2 million shares vested in connection with the share bonus awards with market conditions granted in fiscal year 2013, and 0.5 million shares vested in connection with the share bonus awards with market conditions granted in fiscal year 2012.

[0001628280-15-005450:notes:70]
As of June 26, 2015, total unrecognized compensation expense related to unvested share bonus awards is $146.5 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of 3.03 years. Approximately $22.5 million of the total unrecognized compensation cost, net of estimated forfeitures, is related to awards whereby vesting is contingent on meeting certain market conditions.


## us-gaap:EarningsPerShareTextBlock

[0001628280-15-005450:notes:71]
EARNINGS PER SHARE

[0001628280-15-005450:notes:72]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share attributable to the shareholders of Flextronics International Ltd.:

[0001628280-15-005450:notes:73]
|  | Three-Month Periods Ended |
|  | June 26, 2015 |  | June 27, 2014 |
|  | (In thousands, except per share amounts) |
| Net income | $ | 110,850 |  |  | $ | 173,887 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 565,545 |  |  | 587,233 |  |
| Basic earnings per share | 0.20 |  |  | 0.30 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | 110,850 |  |  | 173,887 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 565,545 |  |  | 587,233 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) | 12,452 |  |  | 14,067 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 577,997 |  |  | 601,300 |  |
| Diluted earnings per share | 0.19 |  |  | 0.29 |  |

[0001628280-15-005450:notes:74]
(1)         Options to purchase ordinary shares of 2.0 million and 12.6 million during the three-month periods ended June 26, 2015 and June 27, 2014, respectively, and share bonus awards of 0.4 million for the three-month period ended June 27, 2014, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary share equivalents. No anti-dilutive share bonus awards were excluded for the three-month period ended June 26, 2015.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-15-005450:notes:75]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES

[0001628280-15-005450:notes:76]
[same as prior period, unchanged from 0001104659-15-005354:notes:71]

[0001628280-15-005450:notes:77]
[same as prior period, unchanged from 0001104659-15-005354:notes:72]

[0001628280-15-005450:notes:78]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager. The Company’s deferred compensation plan assets are for the most part included in other noncurrent assets on the condensed consolidated balance sheets and primarily include investments in equity securities that are valued using active market prices.

[0001628280-15-005450:notes:79]
[same as prior period, unchanged from 0001104659-15-005354:notes:74]

[0001628280-15-005450:notes:80]
[same as prior period, unchanged from 0001104659-15-005354:notes:75]

[0001628280-15-005450:notes:81]
[same as prior period, unchanged from 0001104659-15-005354:notes:76]

[0001628280-15-005450:notes:82]
The Company’s deferred compensation plan assets also include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0001628280-15-005450:notes:83]
[same as prior period, unchanged from 0001104659-15-005354:notes:78]

[0001628280-15-005450:notes:84]
The Company has accrued for certain contingent consideration in connection with its business acquisitions, which is measured at fair value based on internal cash flow models and other inputs. During the three-month periods ended June 26, 2015 and June 27, 2014, no additions to accrual, payments or fair value adjustments were incurred. As of June 26, 2015 and June 27, 2014, balances of contingent consideration were $4.5 million and $11.3 million, respectively.

[0001628280-15-005450:notes:85]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not meaningful. The interrelationship between these inputs is also insignificant. Refer to note 10 for a reconciliation of the change in the deferred purchase price receivable during the three-month periods ended June 26, 2015 and June 27, 2014.

[0001628280-15-005450:notes:86]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended June 26, 2015 and June 27, 2014.

[0001628280-15-005450:notes:87]
[same as prior period, unchanged from 0001104659-15-005354:notes:83]

[0001628280-15-005450:notes:88]
[same as prior period, unchanged from 0001104659-15-005354:notes:84]

[0001628280-15-005450:notes:89]
|  | Fair Value Measurements as of June 26, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 440,274 |  |  | $ | — |  |  | $ | 440,274 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 516,287 |  |  | 516,287 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 20,867 |  |  | — |  |  | 20,867 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 8,809 |  |  | 39,162 |  |  | — |  |  | 47,971 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (27,766 | ) |  | $ | — |  |  | $ | (27,766 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (4,500 | ) |  | (4,500 | ) |
|  | Fair Value Measurements as of March 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 674,859 |  |  | $ | — |  |  | $ | 674,859 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 600,672 |  |  | 600,672 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 25,829 |  |  | — |  |  | 25,829 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 9,068 |  |  | 37,041 |  |  | — |  |  | 46,109 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (31,057 | ) |  | $ | — |  |  | $ | (31,057 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (4,500 | ) |  | (4,500 | ) |

[0001628280-15-005450:notes:90]
[same as prior period, unchanged from 0001104659-15-005354:notes:90]

[0001628280-15-005450:notes:91]
[same as prior period, unchanged from 0001104659-15-005354:notes:91]

[0001628280-15-005450:notes:92]
|  | As of June 26, 2015 |  | As of March 31, 2015 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 592,500 |  |  | $ | 587,689 |  |  | $ | 592,500 |  |  | $ | 582,131 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 475,000 |  |  | 472,625 |  |  | 475,000 |  |  | 465,500 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 517,300 |  |  | 500,000 |  |  | 523,750 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 520,990 |  |  | 500,000 |  |  | 543,150 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,278 |  |  | 597,000 |  |  | — |  |  | — |  |  | Level 1 |
| Total | $ | 2,662,778 |  |  | $ | 2,695,604 |  |  | $ | 2,067,500 |  |  | $ | 2,114,531 |  |  |  |

[0001628280-15-005450:notes:93]
The term loans and Notes due February 2020, February 2023 and June 2025 are valued based on broker trading prices in active markets.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-15-005450:notes:94]
ORGANIZATION OF THE COMPANY AND BASIS OF PRESENTATION

[0001628280-15-005450:notes:95]
[same as prior period, unchanged from 0001104659-15-005354:notes:95]

[0001628280-15-005450:notes:96]
Flextronics International Ltd. ("Flextronics" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following business groups: High Reliability Solutions ("HRS"), which is comprised of our medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and our defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group ("CTG"), which includes our mobile devices business, including smart phones; our consumer electronics business, including connected living, wearable electronics, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for notebook personal computing, tablets, and printers; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, test and measurement, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions ("INS"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables our OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001628280-15-005450:notes:97]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).

[0001628280-15-005450:notes:98]
[same as prior period, unchanged from 0001104659-15-005354:notes:98]

[0001628280-15-005450:notes:99]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2015 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 26, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016.

[0001628280-15-005450:notes:100]
The first quarters for fiscal year 2016 and fiscal year 2015 ended on June 26, 2015, and June 27, 2014, respectively.

[0001628280-15-005450:notes:101]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority-owned subsidiary of the Company. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The operating results of the subsidiary attributable to the noncontrolling interests are immaterial for all of the periods presented, and are included in other charges (income), net in the condensed consolidated statements of operations.

[0001628280-15-005450:notes:102]
Recent Accounting Pronouncement

[0001628280-15-005450:notes:103]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. In July 2015, the FASB deferred the effective date of the standard by a year. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019. The Company is in the process of assessing the impact on its consolidated financial statements.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001628280-15-005450:notes:104]
OTHER CHARGES (INCOME), NET

[0001628280-15-005450:notes:105]
During the three-month period ended June 27, 2014, an amendment to a customer contract to reimburse a customer for certain performance provisions was executed which included the removal of a $55.0 million contractual obligation recognized during fiscal year 2014. Accordingly, the Company reversed the charge recognized in fiscal year 2014 with a corresponding credit to other charges (income), net in the consolidated statement of operations.

[0001628280-15-005450:notes:106]
Further, during the three-month period ended June 27, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a certain manufacturing facility in Western Europe. The Company received $11.5 million in cash for the sale of $27.2 million in net assets of the facility. The loss also includes $4.6 million of estimated transaction costs, partially offset by a credit of $9.3 million for the release of cumulative foreign translation gains triggered by the disposition.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-15-005450:notes:107]
The components of acquired intangible assets are as follows:

[0001628280-15-005450:notes:108]
|  | As of June 26, 2015 |  | As of March 31, 2015 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 146,098 |  |  | $ | (83,820 | ) |  | $ | 62,278 |  |  | $ | 133,853 |  |  | $ | (80,506 | ) |  | $ | 53,347 |  |
| Licenses and other intangibles | 40,217 |  |  | (14,002 | ) |  | 26,215 |  |  | 39,985 |  |  | (11,788 | ) |  | 28,197 |  |
| Total | $ | 186,315 |  |  | $ | (97,822 | ) |  | $ | 88,493 |  |  | $ | 173,838 |  |  | $ | (92,294 | ) |  | $ | 81,544 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001628280-15-005450:notes:109]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the three-month period ended June 26, 2015:

[0001628280-15-005450:notes:110]
|  |  | HRS |  | CTG |  | IEI |  | INS |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year |  | $ | 93,138 |  |  | $ | 68,234 |  |  | $ | 64,221 |  |  | $ | 108,038 |  |  | $ | 333,631 |  |
| Additions (1) |  | 2,130 |  |  | — |  |  | 2,982 |  |  | — |  |  | 5,112 |  |
| Purchase accounting adjustments (2) |  | 125 |  |  | — |  |  | — |  |  | — |  |  | 125 |  |
| Foreign currency translation adjustments |  | 925 |  |  | — |  |  | — |  |  | — |  |  | 925 |  |
| Balance, end of the period |  | $ | 96,318 |  |  | $ | 68,234 |  |  | $ | 67,203 |  |  | $ | 108,038 |  |  | $ | 339,793 |  |

[0001628280-15-005450:notes:111]
| (1) | The goodwill generated from the Company’s business combinations completed during the three-month period ended June 26, 2015 is primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired businesses and expected synergies. The goodwill is not deductible for income tax purposes. See note 12 for additional information. |

[0001628280-15-005450:notes:112]
| (2) | Includes adjustments based on management's estimates resulting from their review and finalization of the valuation of assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition. These adjustments were not individually, nor in the aggregate, significant to the Company. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-15-005450:notes:113]
The components of inventories, net of applicable lower of cost or market write-downs, were as follows:

[0001628280-15-005450:notes:114]
|  | As of June 26, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Raw materials | $ | 2,158,161 |  |  | $ | 2,330,428 |  |
| Work-in-progress | 582,041 |  |  | 557,786 |  |
| Finished goods | 673,228 |  |  | 600,538 |  |
|  | $ | 3,413,430 |  |  | $ | 3,488,752 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-15-005450:notes:115]
Selected financial information by segment is as follows:

[0001628280-15-005450:notes:116]
|  | Three-Month Periods Ended |
|  | June 26, 2015 |  | June 27, 2014 |
|  | (In thousands) |
| Net sales: |  |  |  |
| Integrated Network Solutions | $ | 1,966,562 |  |  | $ | 2,440,425 |  |
| Consumer Technology Group | 1,564,964 |  |  | 2,222,141 |  |
| Industrial & Emerging Industries | 1,130,138 |  |  | 1,124,466 |  |
| High Reliability Solutions | 904,584 |  |  | 855,713 |  |
|  | $ | 5,566,248 |  |  | $ | 6,642,745 |  |
| Segment income and reconciliation of income before tax: |  |  |  |
| Integrated Network Solutions | $ | 57,065 |  |  | $ | 72,711 |  |
| Consumer Technology Group | 38,843 |  |  | 29,865 |  |
| Industrial & Emerging Industries | 28,999 |  |  | 47,324 |  |
| High Reliability Solutions | 59,886 |  |  | 54,142 |  |
| Corporate and Other | (25,711 | ) |  | (20,852 | ) |
| Total segment income | 159,082 |  |  | 183,190 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 7,671 |  |  | 6,951 |  |
| Stock-based compensation | 16,126 |  |  | 11,682 |  |
| Other charges (income), net | 164 |  |  | (44,009 | ) |
| Interest and other, net | 16,505 |  |  | 18,637 |  |
| Income before income taxes | $ | 118,616 |  |  | $ | 189,929 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001628280-15-005450:notes:117]
The estimated future annual amortization expense for intangible assets is as follows:

[0001628280-15-005450:notes:118]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 21,587 |  |
| 2017 | 21,428 |  |
| 2018 | 15,677 |  |
| 2019 | 11,386 |  |
| 2020 | 6,807 |  |
| Thereafter | 11,608 |  |
| Total amortization expense | $ | 88,493 |  |

[0001628280-15-005450:notes:119]
| (1) | Represents estimated amortization for the remaining nine-month period ending March 31, 2016. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-15-005450:notes:120]
SEGMENT REPORTING

[0001628280-15-005450:notes:121]
The Company has four reportable operating segments which are aligned to its four business groups: HRS, CTG, IEI, and INS. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 for a description of the various product categories manufactured under each of these segments.

[0001628280-15-005450:notes:122]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges, other charges (income), net and interest and other, net.

[0001628280-15-005450:notes:123]
Asset information on a segment basis is not disclosed, as property and equipment is not allocated to each segment.

[0001628280-15-005450:notes:124]
Corporate and other primarily includes corporate services costs that are not included in the assessment of the performance of each of the identified reporting segments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-15-005450:notes:125]
BALANCE SHEET ITEMS

[0001628280-15-005450:notes:126]
[same as prior period, unchanged from 0001104659-15-005354:notes:126]

[0001628280-15-005450:notes:127]
[same as prior period, unchanged from 0001104659-15-005354:notes:128]

[0001628280-15-005450:notes:128]
The gross carrying amounts of intangible assets are removed when the recorded amounts have been fully amortized.  During the three-month period ended June 26, 2015, the value of customer-related intangible assets increased in connection with the Company’s acquisitions, and licenses and other intangibles decreased primarily as a result of additional amortization.  The estimated future annual amortization expense for intangible assets is as follows:

[0001628280-15-005450:notes:129]
Other Current Assets

[0001628280-15-005450:notes:130]
Other current assets includes approximately $516.3 million and $600.7 million as of June 26, 2015 and March 31, 2015, respectively for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0001628280-15-005450:notes:131]
In connection with an acquisition, the Company entered into an agreement with a customer and a third party banking institution to procure certain manufacturing equipment that was financed by the third party banking institution, acting as an agent of the customer.  The manufacturing equipment was used exclusively for the benefit of this customer.  The Company has the ability to settle the obligation related to these financed assets by returning the equipment to the customer and cannot be required to pay cash by either the customer or the third party banking institution.

[0001628280-15-005450:notes:132]
During fiscal year 2015, the Company ceased manufacturing of the product related to the financed equipment.  As a result, the Company as an agent on behalf of the customer is in the process of dispositioning the equipment and forwarding the proceeds to the third party banking institution reducing the outstanding obligation. Included in other current assets is the value of the certain assets purchased on behalf of a customer and financed by a third party banking institution in the amounts of $84.3 million and $169.2 million as of June 26, 2015 and March 31, 2015, respectively.  Additionally, other current assets as of June 26, 2015 include an amount of $87.1 million relating to these assets that have been sold to third parties but not yet collected.

[0001628280-15-005450:notes:133]
During the three-month period ended June 26, 2015, the Company disposed of all the assets and the remaining amount of $84.3 million  reflects the shortfall between the original purchase price of these assets and the amount recovered by selling them to third parties. The Company expects this amount to be funded by the customer, which in turn would be paid back to the third party banking institution.

[0001628280-15-005450:notes:134]
Other Current Liabilities

[0001628280-15-005450:notes:135]
Other current liabilities include customer working capital advances of $172.7 million and $189.6 million, customer-related accruals of $443.1 million and $454.8 million, and deferred revenue of $301.1 million and $272.6 million as of June 26, 2015 and March 31, 2015, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Other current liabilities also includes the outstanding balance due to the third party banking institution related to the financed equipment discussed above, that amounted to $172.5 million and $197.7 million as of June 26, 2015 and March 31, 2015, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001628280-15-005450:notes:136]
TRADE RECEIVABLES SECURITIZATION

[0001628280-15-005450:notes:137]
[same as prior period, unchanged from 0001104659-15-005354:notes:135]

[0001628280-15-005450:notes:138]
[same as prior period, unchanged from 0001104659-15-005354:notes:136]

[0001628280-15-005450:notes:139]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $650.0 million for the Global Program and $225.0 million for the North American Program. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001628280-15-005450:notes:140]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month periods ended June 26, 2015 and June 27, 2014 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0001628280-15-005450:notes:141]
As of June 26, 2015, approximately $1.4 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $866.4 million and deferred purchase price receivables of approximately $516.3 million. As of March 31, 2015, approximately $1.3 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $740.7 million and deferred purchase price receivables of approximately $600.7 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of June 26, 2015 and March 31, 2015, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0001628280-15-005450:notes:142]
As of June 26, 2015 and March 31, 2015, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0001628280-15-005450:notes:143]
For the three-month periods ended June 26, 2015 and June 27, 2014, cash flows from sales of receivables under the ABS Programs consisted of approximately $1.1 billion for both periods, for transfers of receivables, respectively (of which approximately $162.7 million and $42.5 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0001628280-15-005450:notes:144]
[same as prior period, unchanged from 0001104659-15-005354:notes:143]

[0001628280-15-005450:notes:145]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $368.0 million and $485.6 million as of June 26, 2015 and March 31, 2015, respectively. For the three-month periods ended June 26, 2015 and June 27, 2014, total accounts receivable sold to certain third party banking institutions was approximately $0.6 billion and $1.2 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0001628280-15-005450:notes:146]
SHARE REPURCHASES

[0001628280-15-005450:notes:147]
During the three-month period ended June 26, 2015 the Company repurchased 7.7 million shares at an aggregate purchase price of $94.4 million, and retired all of these shares.

[0001628280-15-005450:notes:148]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Extraordinary General Meeting held on August 28, 2014. As of June 26, 2015, shares in the aggregate amount of $144.0 million were available to be repurchased under the current plan.
