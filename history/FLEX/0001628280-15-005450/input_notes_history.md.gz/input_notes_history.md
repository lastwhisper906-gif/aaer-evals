# FLEX note change history — 0001104659-15-005354 → 0001628280-15-005450


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-07-27):
[0001628280-15-005450:note_history:1]
COMMITMENTS AND CONTINGENCIES
  (was, 2015-01-29, similarity 0.9667):
[0001104659-15-005354:note_history:1]
13.  COMMITMENTS AND CONTINGENCIES

- changed (2015-07-27):
[0001628280-15-005450:note_history:2]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431). The complaint asserted various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products. The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys' fees and costs. The plaintiff also seeks a jury trial. Although the outcome of this matter is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of this matter, which are in excess of amounts already accrued in the Company's consolidated balance sheets, would not be material to the financial statements.
  (was, 2015-01-29, similarity 0.8662):
[0001104659-15-005354:note_history:2]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International, Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431).  The complaint asserts various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products.  The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys’ fees and costs.  The plaintiff also seeks a jury trial.  On June 25, 2014, we filed motions for Demurrer and to Strike asking the court to dismiss the claims against us.  The court has scheduled a hearing on the motions for January 30, 2015.  Although the outcome of this matter is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of this matter, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements.

- added (2015-07-27):
[0001628280-15-005450:note_history:3]
During the fourth quarter of fiscal year 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010. This assessment is in the second stage of the review process at the administrative level, and the Company plans to continue to vigorously oppose it as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, the Company is unable to reasonably estimate a range of loss, if any. The Company does not expect final judicial determination on these claims for several years.

- changed (2015-07-27):
[0001628280-15-005450:note_history:4]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties. The Company believes there is no legal basis for the assessment and expects that any losses are remote. The Company plans to vigorously defend itself through the administrative and judicial processes.
  (was, 2015-01-29, similarity 0.8991):
[0001104659-15-005354:note_history:4]
During the nine-month period ended December 31, 2014, one of our non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties.  The Company believes there is no legal basis for the assessment and expects that any losses are remote.  The Company plans to vigorously defend itself through the administrative and judicial processes.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-07-27):
[0001628280-15-005450:note_history:5]
ORGANIZATION OF THE COMPANY AND BASIS OF PRESENTATION
  (was, 2015-01-29, similarity 0.9815):
[0001104659-15-005354:note_history:5]
1.  ORGANIZATION OF THE COMPANY AND BASIS OF PRESENTATION

- added (2015-07-27):
[0001628280-15-005450:note_history:6]
Flextronics International Ltd. ("Flextronics" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following business groups: High Reliability Solutions ("HRS"), which is comprised of our medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and our defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group ("CTG"), which includes our mobile devices business, including smart phones; our consumer electronics business, including connected living, wearable electronics, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for notebook personal computing, tablets, and printers; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, test and measurement, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions ("INS"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables our OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

- changed (2015-07-27):
[0001628280-15-005450:note_history:7]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).
  (was, 2015-01-29, similarity 0.9951):
[0001104659-15-005354:note_history:7]
The Company’s service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement,  inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).

- changed (2015-07-27):
[0001628280-15-005450:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2015 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 26, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016.
  (was, 2015-01-29, similarity 0.9813):
[0001104659-15-005354:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2014 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015.

- added (2015-07-27):
[0001628280-15-005450:note_history:9]
The first quarters for fiscal year 2016 and fiscal year 2015 ended on June 26, 2015, and June 27, 2014, respectively.

- changed (2015-07-27):
[0001628280-15-005450:note_history:10]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority-owned subsidiary of the Company. Noncontrolling interests are presented as a separate component of total shareholders' equity in the condensed consolidated balance sheets. The operating results of the subsidiary attributable to the noncontrolling interests are immaterial for all of the periods presented, and are included in other charges (income), net in the condensed consolidated statements of operations.
  (was, 2015-01-29, similarity 0.9582):
[0001104659-15-005354:note_history:10]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority owned subsidiary of the Company.  Non-controlling interests are presented as a separate component of total shareholders’ equity in the condensed consolidated balance sheets.  The operating results of the subsidiary attributable to the non-controlling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- changed (2015-07-27):
[0001628280-15-005450:note_history:11]
Recent Accounting Pronouncement
  (was, 2015-01-29, similarity 0.9841):
[0001104659-15-005354:note_history:11]
Recent Accounting Pronouncements

- changed (2015-07-27):
[0001628280-15-005450:note_history:12]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. In July 2015, the FASB deferred the effective date of the standard by a year. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019. The Company is in the process of assessing the impact on its consolidated financial statements.
  (was, 2015-01-29, similarity 0.8065):
[0001104659-15-005354:note_history:12]
In May 2014, the FASB issued new guidance related to revenue recognition which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services.  In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018 and the Company is in the process of assessing the impact on its consolidated financial statements.

- removed (2015-07-27):
[0001104659-15-005354:note_history:13]
Flextronics International Ltd. (“Flextronics” or the “Company”) was incorporated in the Republic of Singapore in May 1990. The Company’s operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of supply chain solutions that span from concept through consumption. The Company designs, builds, ships and services a complete packaged electronic product for original equipment manufacturers (“OEMs”) in the following business groups: High Reliability Solutions (“HRS”), which is comprised of our medical, automotive, and defense and aerospace businesses; Consumer Technology Group (“CTG”), which includes our mobile devices business, including smart phones; our consumer electronics business, including game consoles and wearable electronics; and our high-volume computing business, including various supply chain solutions for notebook personal computing (“PC”), tablets, and printers; Industrial and Emerging Industries (“IEI”), which is comprised of our household appliances, semi-cap equipment, kiosks, energy and emerging industries businesses; and Integrated Network Solutions (“INS”), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses. The Company’s strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service complete packaged products for its OEM customers. This enables our OEM customers to leverage the Company’s supply chain solutions to meet their product requirements throughout the entire product life cycle.

- removed (2015-07-27):
[0001104659-15-005354:note_history:14]
The first quarters for fiscal year 2015 and fiscal year 2014 ended on June 27, 2014, which is comprised of 88 days in the period, and June 28, 2013, which is comprised of 89 days in the period, respectively. The second quarter for fiscal year 2015 and fiscal year 2014 ended on September 26, 2014 and September 27, 2013, which are comprised of 91 days in both periods, respectively. The Company’s third quarter ends on December 31 of each year, which is comprised of 96 days and 95 days in the respective periods for fiscal years 2015 and 2014.

- removed (2015-07-27):
[0001104659-15-005354:note_history:15]
In April 2014, the Financial Accounting Standards Board (“FASB”) issued guidance which requires an entity to report a disposal of a component of an entity in discontinued operations if the disposal represents a strategic shift that has a major effect on an entity’s operations and financial results when the component of an entity meets certain criteria to be classified as held for sale, or when the component of an entity is disposed of by a sale or disposed of other than by a sale. Further, additional disclosures about discontinued operations should include the following for the periods in which the results of operations of the discontinued operations are presented in the statement of operations: the major classes of line items constituting pretax profit or loss of discontinued operations; total operating and investing cash flows of discontinued operations; depreciation, amortization, capital expenditures, and significant operating and investing noncash items of discontinued operations; pretax profit or loss attributable to the parent if a discontinued operation includes a non-controlling interest; a reconciliation of major classes of assets and liabilities of the discontinued operation classified as held for sale; and a reconciliation of major classes of line items constituting the pretax profit or loss of the discontinued operation. The Company early adopted this accounting standard update in the first quarter of fiscal year 2015.  During the first quarter of fiscal 2015, the Company disposed of a manufacturing facility in Western Europe which did not meet the criteria of discontinued operations under this accounting standard, as further discussed in note 6 to the condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2015-07-27):
[0001628280-15-005450:note_history:16]
BANK BORROWINGS AND LONG TERM DEBT

- added (2015-07-27):
[0001628280-15-005450:note_history:17]
Bank borrowings and long-term debt are as follows:

- added (2015-07-27):
[0001628280-15-005450:note_history:18]
|  | As of June 26, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 592,500 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 475,000 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,278 |  |  | — |  |
| Other | 14,287 |  |  | 16,233 |  |
| Total | $ | 2,677,065 |  |  | $ | 2,083,733 |  |

- added (2015-07-27):
[0001628280-15-005450:note_history:19]
The weighted average interest rates for the Company’s long-term debt were 3.5% and 3.2% as of June 26, 2015 and March 31, 2015, respectively,

- added (2015-07-27):
[0001628280-15-005450:note_history:20]
On June 8, 2015, the Company issued $600 million of 4.750% Notes ("Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at a discount of 99.213%. The Company received net proceeds of approximately $595.3 million from the issuance which will be used for general corporate purposes.

- added (2015-07-27):
[0001628280-15-005450:note_history:21]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the Notes. The issuance costs were capitalized and will be amortized over the life of the Notes.

- added (2015-07-27):
[0001628280-15-005450:note_history:22]
Interest on the Notes is payable semi-annually, commencing on December 15, 2015. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Term Loan Agreement and Revolving Line of Credit.

- added (2015-07-27):
[0001628280-15-005450:note_history:23]
At any time prior to March 15, 2025, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

- added (2015-07-27):
[0001628280-15-005450:note_history:24]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of June 26, 2015, the Company was in compliance with the covenants in the indenture governing the Notes.

- added (2015-07-27):
[0001628280-15-005450:note_history:25]
In connection with the issuance of the Notes, the Company entered into a registration rights agreement under which it has agreed to consummate an offer registered with the Securities and Exchange Commission to issue new notes having terms substantially identical to the Notes (except that the new notes will not be subject to restrictions on transfer) in exchange for outstanding Notes. In some circumstances, the Company may be required to file a shelf registration statement to cover resale of the Notes. If the Company fails to satisfy these obligations, the Company may be required to pay additional interest to holders of the Notes under certain circumstances.

- added (2015-07-27):
[0001628280-15-005450:note_history:26]
Repayment of the Company’s long term debt outstanding as of June 26, 2015 is as follows:

- added (2015-07-27):
[0001628280-15-005450:note_history:27]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 40,000 |  |
| 2017 | 52,500 |  |
| 2018 | 52,500 |  |
| 2019 | 922,500 |  |
| 2020 | 500,000 |  |
| Thereafter | 1,109,565 |  |
| Total | $ | 2,677,065 |  |

- added (2015-07-27):
[0001628280-15-005450:note_history:28]
____________________________________________________________

- added (2015-07-27):
[0001628280-15-005450:note_history:29]
| (1) | Represents scheduled repayment for the remaining nine-month period ending March 31, 2016. |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-07-27):
[0001628280-15-005450:note_history:30]
The following table presents the Company’s debt not carried at fair value:

- added (2015-07-27):
[0001628280-15-005450:note_history:31]
|  | As of June 26, 2015 |  | As of March 31, 2015 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 592,500 |  |  | $ | 587,689 |  |  | $ | 592,500 |  |  | $ | 582,131 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 475,000 |  |  | 472,625 |  |  | 475,000 |  |  | 465,500 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 517,300 |  |  | 500,000 |  |  | 523,750 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 520,990 |  |  | 500,000 |  |  | 543,150 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,278 |  |  | 597,000 |  |  | — |  |  | — |  |  | Level 1 |
| Total | $ | 2,662,778 |  |  | $ | 2,695,604 |  |  | $ | 2,067,500 |  |  | $ | 2,114,531 |  |  |  |

- removed (2015-07-27):
[0001104659-15-005354:note_history:32]
|  |  | As of December 31, 2014 |  | As of March 31, 2014 |  |  |  |
|  |  | Carrying |  | Fair |  | Carrying |  | Fair |  | Fair Value |  |
|  |  | Amount |  | Value |  | Amount |  | Value |  | Hierarchy |  |
|  |  | (In thousands) |  |
| Term Loan, including current portion, due in installments through August 2018 |  | $ | 596,250 |  | $ | 584,701 |  | $ | 600,000 |  | $ | 591,750 |  | Level 1 |  |
| Term Loan, including current portion, due in installments through March 2019 |  | 481,250 |  | 472,828 |  | 500,000 |  | 497,190 |  | Level 1 |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 511,560 |  | 500,000 |  | 504,688 |  | Level 1 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 526,880 |  | 500,000 |  | 517,650 |  | Level 1 |  |
| Total |  | $ | 2,077,500 |  | $ | 2,095,969 |  | $ | 2,100,000 |  | $ | 2,111,278 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2015-07-27):
[0001628280-15-005450:note_history:33]
Bank borrowings and long-term debt are as follows:

- added (2015-07-27):
[0001628280-15-005450:note_history:34]
|  | As of June 26, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 592,500 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 475,000 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,278 |  |  | — |  |
| Other | 14,287 |  |  | 16,233 |  |
| Total | $ | 2,677,065 |  |  | $ | 2,083,733 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2015-07-27):
[0001628280-15-005450:note_history:35]
Repayment of the Company’s long term debt outstanding as of June 26, 2015 is as follows:

- added (2015-07-27):
[0001628280-15-005450:note_history:36]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 40,000 |  |
| 2017 | 52,500 |  |
| 2018 | 52,500 |  |
| 2019 | 922,500 |  |
| 2020 | 500,000 |  |
| Thereafter | 1,109,565 |  |
| Total | $ | 2,677,065 |  |

- added (2015-07-27):
[0001628280-15-005450:note_history:37]
____________________________________________________________

- added (2015-07-27):
[0001628280-15-005450:note_history:38]
| (1) | Represents scheduled repayment for the remaining nine-month period ending March 31, 2016. |
