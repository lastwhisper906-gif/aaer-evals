# FLEX note change history — 0001104659-14-005587 → 0001104659-14-054018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-07-28):
[0001104659-14-054018:note_history:1]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International, Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431).  The complaint asserts various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products.  The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys’ fees and costs.  The plaintiff also seeks a jury trial.  On June 25, 2014, we filed motions for Demurrer and to Strike asking the court to dismiss the claims against us.  The court has scheduled a hearing on the motions for August 29, 2014.  Although the outcome of this matter is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of this matter, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements.
  (was, 2014-01-31, similarity 0.6756):
[0001104659-14-005587:note_history:1]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International, Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431).  The complaint asserts various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products.  The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys’ fees and costs.  The plaintiff also seeks a jury trial.  The Company is investigating the allegations and is unable to estimate a range of reasonably possible losses in this matter at this time.

- added (2014-07-28):
[0001104659-14-054018:note_history:2]
During the first quarter of fiscal 2015, one of our non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties.  The Company believes there is no legal basis for the assessment and expects that any losses are remote.  The Company plans to vigorously defend itself through the administrative and judicial processes.

- changed (2014-07-28):
[0001104659-14-054018:note_history:3]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets would not be material to the financial statements as a whole.
  (was, 2014-01-31, similarity 0.965):
[0001104659-14-005587:note_history:3]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business including tax assessments. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in its condensed consolidated balance sheets would not be material to the financial statements as a whole.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-07-28):
[0001104659-14-054018:note_history:4]
Flextronics International Ltd. (“Flextronics” or the “Company”) was incorporated in the Republic of Singapore in May 1990. The Company’s operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of supply chain solutions that span from concept through consumption. The Company designs, builds, ships and services a complete packaged electronic product for original equipment manufacturers (“OEMs”) in the following business groups: High Reliability Solutions (“HRS”), which is comprised of our medical, automotive, and defense and aerospace businesses; Consumer Technology Group (“CTG”), which includes our mobile devices business, including smart phones; our consumer electronics business, including game consoles and wearable electronics; and our high-volume computing business, including various supply chain solutions for notebook personal computing (“PC”), tablets, and printers; Industrial and Emerging Industries (“IEI”), which is comprised of our household appliances, semi-cap equipment, kiosks, energy and emerging industries businesses; and Integrated Network Solutions (“INS”), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses. The Company’s strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables our OEM customers to leverage the Company’s supply chain solutions to meet their product requirements throughout the entire product life cycle.
  (was, 2014-01-31, similarity 0.7622):
[0001104659-14-005587:note_history:4]
Flextronics International Ltd. (“Flextronics” or the “Company”) was incorporated in the Republic of Singapore in May 1990. The Company’s operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a leading global supply chain solutions provider of advanced design, manufacturing and services to original equipment manufacturers (“OEMs”) of a broad range of electronic products serving customers in the following markets: High Reliability Solutions (“HRS”), which is comprised of our medical, automotive, and defense and aerospace businesses; High Velocity Solutions (“HVS”), which includes our mobile devices business, including smart phones, and consumer electronics, including game consoles and wearable electronics, and our high-volume computing business, including various supply chain solutions for notebook personal computing (“PC”), tablets, and printers; Industrial and Emerging Industries (“IEI”), which is comprised of household appliances, semi-cap equipment, kiosks, energy and our emerging industries businesses; and Integrated Network Solutions (“INS”), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses. The Company’s strategy is to provide customers with a full range of cost competitive, global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. OEM customers leverage the Company’s supply chain solutions to meet their product requirements throughout the entire product life cycle.

- changed (2014-07-28):
[0001104659-14-054018:note_history:5]
The Company’s service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).
  (was, 2014-01-31, similarity 0.9894):
[0001104659-14-005587:note_history:5]
The Company’s service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement,  inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings like rigid and flexible printed circuit boards and power adapters and chargers.

- changed (2014-07-28):
[0001104659-14-054018:note_history:6]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2014 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 27, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015.
  (was, 2014-01-31, similarity 0.9721):
[0001104659-14-005587:note_history:6]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2013 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and nine-month periods ended December 31, 2013 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2014.

- added (2014-07-28):
[0001104659-14-054018:note_history:7]
The first quarters for fiscal year 2015 and fiscal year 2014 ended on June 27, 2014 and June 28, 2013, respectively.

- added (2014-07-28):
[0001104659-14-054018:note_history:8]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority owned subsidiary of the Company.  Non-controlling interests are presented as a separate component of total shareholders’ equity in the condensed consolidated balance sheets.  The operating results of the subsidiary attributable to the non-controlling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- added (2014-07-28):
[0001104659-14-054018:note_history:9]
Recent Accounting Pronouncements

- added (2014-07-28):
[0001104659-14-054018:note_history:10]
In April 2014, the Financial Accounting Standards Board (“FASB”) issued guidance which requires an entity to report a disposal of a component of an entity in discontinued operations if the disposal represents a strategic shift that has a major effect on an entity’s operations and financial results when the component of an entity meets certain criteria to be classified as held for sale, or when the component of an entity is disposed of by a sale or disposed of other than by a sale. Further, additional disclosures about discontinued operations should include the following for the periods in which the results of operations of the discontinued operations are presented in the statement of operations: the major classes of line items constituting pretax profit or loss of discontinued operations; total operating and investing cash flows of discontinued operations; depreciation, amortization, capital expenditures, and significant operating and investing noncash items of discontinued operations; pretax profit or loss attributable to the parent if a discontinued operation includes a non-controlling interest; a reconciliation of major classes of assets, liabilities of the discontinued operation classified as held for sale; and a reconciliation of major classes of line items constituting the pretax profit or loss of the discontinued operation. The Company early adopted this accounting standard update in the first quarter of fiscal year 2015.  During the three-months ended June 27, 2014, the Company disposed of a certain manufacturing facility in western Europe which did not meet the criteria of discontinued operations under this accounting standard, as further discussed in note 6 to the condensed consolidated financial statements.

- added (2014-07-28):
[0001104659-14-054018:note_history:11]
In May 2014, the FASB issued new guidance related to revenue recognition which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services.  In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018 and the Company is in the process of assessing the impact on its consolidated financial statements.

- removed (2014-07-28):
[0001104659-14-005587:note_history:12]
During the fourth quarter of fiscal 2013, the Company recorded certain purchase accounting adjustments in connection with an acquisition of a business that was consummated in the third quarter of fiscal 2013.  These purchase accounting adjustments resulted in the release of $22.3 million of valuation allowances for deferred tax assets. In accordance with the accounting guidance applicable to business combinations, the Company re-casted the operating results for the quarter ended December 31, 2012 to reflect the release of the valuation allowance for deferred tax assets.

- removed (2014-07-28):
[0001104659-14-005587:note_history:13]
The first quarter for fiscal year 2014 and fiscal year 2013 ended on June 28, 2013 and June 29, 2012, respectively. The second quarter for fiscal year 2014 and fiscal year 2013 ended on September 27, 2013 and September 28, 2012, respectively. The Company’s third fiscal quarter ends on December 31, and the fourth fiscal quarter, and year, ends on March 31 of each year.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2014-07-28):
[0001104659-14-005587:note_history:14]
6.  BANK BORROWINGS AND LONG-TERM DEBT

- removed (2014-07-28):
[0001104659-14-005587:note_history:15]
Bank borrowings and long-term debt are as follows:

- removed (2014-07-28):
[0001104659-14-005587:note_history:16]
|  |  | As of |  | As of |  |
|  |  | December 31, 2013 |  | March 31, 2013 |  |
|  |  | (In thousands) |  |
| Term Loan, including current portion, due October 2014 |  | $ | — |  | $ | 170,340 |  |
| Term Loan, including current portion, due in installments through October 2016 |  | 436,641 |  | 517,500 |  |
| Term Loan, including current portion, due in installments through August 2018 |  | 600,000 |  | — |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 500,000 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 500,000 |  |
| Asia Term Loans |  | — |  | 375,000 |  |
| Other |  | 19,004 |  | 4,787 |  |
|  |  | 2,055,645 |  | 2,067,627 |  |
| Current portion |  | (54,951 | ) | (416,654 | ) |
| Non-current portion |  | $ | 2,000,694 |  | $ | 1,650,973 |  |

- removed (2014-07-28):
[0001104659-14-005587:note_history:17]
The weighted average interest rates for the Company’s long-term debt were 3.2% and 3.5% as of December 31, 2013 and March 31, 2013, respectively.

- removed (2014-07-28):
[0001104659-14-005587:note_history:18]
On August 30, 2013, the Company entered into a $600 million term loan agreement due August 30, 2018 and used part of the proceeds to repay the outstanding balances of the term loan due October 2014 and the Asia Term Loans in full amounting to $170.3 million and $374.5 million, respectively. The remaining $55.2 million was used to repay part of the term loan due October 2016 and upfront bank fees.

- removed (2014-07-28):
[0001104659-14-005587:note_history:19]
Borrowings under the term loan due August 2018 bear interest, at the Company’s option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.00% and 2.00%, based on the Company’s credit ratings or (ii) the base rate (the greatest of the agent’s prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.00% and 1.00%, based on the Company’s credit rating.

- removed (2014-07-28):
[0001104659-14-005587:note_history:20]
The term loan due August 2018 is unsecured, and contains customary restrictions on the Company’s and its subsidiaries’ ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2013, the Company was in compliance with the covenants under this term loan agreement.

- removed (2014-07-28):
[0001104659-14-005587:note_history:21]
Repayments of the Company’s long term debt outstanding as of December 31, 2013 are as follows:

- removed (2014-07-28):
[0001104659-14-005587:note_history:22]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2014 (1) |  | $ | 23,190 |  |
| 2015 |  | 44,518 |  |
| 2016 |  | 52,018 |  |
| 2017 |  | 368,351 |  |
| 2018 |  | 15,000 |  |
| Thereafter |  | 1,552,568 |  |
| Total |  | $ | 2,055,645 |  |

- removed (2014-07-28):
[0001104659-14-005587:note_history:23]
(1)                     Represents scheduled repayments for the remaining three-month period ending March 31, 2014.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-07-28):
[0001104659-14-054018:note_history:24]
|  |  | As of June 27, 2014 |  | As of March 31, 2014 |  |  |  |
|  |  | Carrying |  | Fair |  | Carrying |  | Fair |  | Fair Value |  |
|  |  | Amount |  | Value |  | Amount |  | Value |  | Hierarchy |  |
|  |  | (In thousands) |  |  |  |
| Term Loan, including current portion, due in installments through August 2018 |  | $ | 600,000 |  | $ | 592,500 |  | $ | 600,000 |  | $ | 591,750 |  | Level 1 |  |
| Term Loan, including current portion, due in installments through March 2019 |  | 500,000 |  | 492,500 |  | 500,000 |  | 497,190 |  | Level 1 |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 519,000 |  | 500,000 |  | 504,688 |  | Level 1 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 520,000 |  | 500,000 |  | 517,650 |  | Level 1 |  |
| Total |  | $ | 2,100,000 |  | $ | 2,124,000 |  | $ | 2,100,000 |  | $ | 2,111,278 |  |  |  |
  (was, 2014-01-31, similarity 0.7806):
[0001104659-14-005587:note_history:24]
|  |  | As of December 31, 2013 |  | As of March 31, 2013 |  |  |  |
|  |  | Carrying |  | Fair |  | Carrying |  | Fair |  | Fair Value |  |
|  |  | Amount |  | Value |  | Amount |  | Value |  | Hierarchy |  |
|  |  | (In thousands) |  |  |  |
| Term Loan, including current portion, due October 2014 |  | $ | — |  | $ | — |  | $ | 170,340 |  | $ | 170,496 |  | Level 1 |  |
| Term Loan, including current portion, due in installments through October 2016 |  | 436,641 |  | 435,824 |  | 517,500 |  | 518,794 |  | Level 1 |  |
| Term Loan, including current portion, due in installments through August 2018 |  | 600,000 |  | 591,000 |  | — |  | — |  | Level 1 |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 502,350 |  | 500,000 |  | 507,190 |  | Level 1 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 472,250 |  | 500,000 |  | 500,000 |  | Level 1 |  |
| Asia Term Loans |  | — |  | — |  | 375,000 |  | 375,343 |  | Level 2 |  |
| Total |  | $ | 2,036,641 |  | $ | 2,001,424 |  | $ | 2,062,840 |  | $ | 2,071,823 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2014-07-28):
[0001104659-14-005587:note_history:25]
|  |  | As of |  | As of |  |
|  |  | December 31, 2013 |  | March 31, 2013 |  |
|  |  | (In thousands) |  |
| Term Loan, including current portion, due October 2014 |  | $ | — |  | $ | 170,340 |  |
| Term Loan, including current portion, due in installments through October 2016 |  | 436,641 |  | 517,500 |  |
| Term Loan, including current portion, due in installments through August 2018 |  | 600,000 |  | — |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 500,000 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 500,000 |  |
| Asia Term Loans |  | — |  | 375,000 |  |
| Other |  | 19,004 |  | 4,787 |  |
|  |  | 2,055,645 |  | 2,067,627 |  |
| Current portion |  | (54,951 | ) | (416,654 | ) |
| Non-current portion |  | $ | 2,000,694 |  | $ | 1,650,973 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2014-07-28):
[0001104659-14-005587:note_history:26]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2014 (1) |  | $ | 23,190 |  |
| 2015 |  | 44,518 |  |
| 2016 |  | 52,018 |  |
| 2017 |  | 368,351 |  |
| 2018 |  | 15,000 |  |
| Thereafter |  | 1,552,568 |  |
| Total |  | $ | 2,055,645 |  |

- removed (2014-07-28):
[0001104659-14-005587:note_history:27]
(1)                     Represents scheduled repayments for the remaining three-month period ending March 31, 2014.
