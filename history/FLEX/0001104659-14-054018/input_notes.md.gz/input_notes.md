# FLEX notes — 0001104659-14-054018


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-14-054018:notes:1]
[same as prior period, unchanged from 0001104659-14-005587:notes:1]

[0001104659-14-054018:notes:2]
[same as prior period, unchanged from 0001104659-14-005587:notes:2]

[0001104659-14-054018:notes:3]
Flextronics International Ltd. (“Flextronics” or the “Company”) was incorporated in the Republic of Singapore in May 1990. The Company’s operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of supply chain solutions that span from concept through consumption. The Company designs, builds, ships and services a complete packaged electronic product for original equipment manufacturers (“OEMs”) in the following business groups: High Reliability Solutions (“HRS”), which is comprised of our medical, automotive, and defense and aerospace businesses; Consumer Technology Group (“CTG”), which includes our mobile devices business, including smart phones; our consumer electronics business, including game consoles and wearable electronics; and our high-volume computing business, including various supply chain solutions for notebook personal computing (“PC”), tablets, and printers; Industrial and Emerging Industries (“IEI”), which is comprised of our household appliances, semi-cap equipment, kiosks, energy and emerging industries businesses; and Integrated Network Solutions (“INS”), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses. The Company’s strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables our OEM customers to leverage the Company’s supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001104659-14-054018:notes:4]
The Company’s service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).

[0001104659-14-054018:notes:5]
[same as prior period, unchanged from 0001104659-14-005587:notes:5]

[0001104659-14-054018:notes:6]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2014 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 27, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015.

[0001104659-14-054018:notes:7]
The first quarters for fiscal year 2015 and fiscal year 2014 ended on June 27, 2014 and June 28, 2013, respectively.

[0001104659-14-054018:notes:8]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority owned subsidiary of the Company.  Non-controlling interests are presented as a separate component of total shareholders’ equity in the condensed consolidated balance sheets.  The operating results of the subsidiary attributable to the non-controlling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

[0001104659-14-054018:notes:9]
Recent Accounting Pronouncements

[0001104659-14-054018:notes:10]
In April 2014, the Financial Accounting Standards Board (“FASB”) issued guidance which requires an entity to report a disposal of a component of an entity in discontinued operations if the disposal represents a strategic shift that has a major effect on an entity’s operations and financial results when the component of an entity meets certain criteria to be classified as held for sale, or when the component of an entity is disposed of by a sale or disposed of other than by a sale. Further, additional disclosures about discontinued operations should include the following for the periods in which the results of operations of the discontinued operations are presented in the statement of operations: the major classes of line items constituting pretax profit or loss of discontinued operations; total operating and investing cash flows of discontinued operations; depreciation, amortization, capital expenditures, and significant operating and investing noncash items of discontinued operations; pretax profit or loss attributable to the parent if a discontinued operation includes a non-controlling interest; a reconciliation of major classes of assets, liabilities of the discontinued operation classified as held for sale; and a reconciliation of major classes of line items constituting the pretax profit or loss of the discontinued operation. The Company early adopted this accounting standard update in the first quarter of fiscal year 2015.  During the three-months ended June 27, 2014, the Company disposed of a certain manufacturing facility in western Europe which did not meet the criteria of discontinued operations under this accounting standard, as further discussed in note 6 to the condensed consolidated financial statements.

[0001104659-14-054018:notes:11]
In May 2014, the FASB issued new guidance related to revenue recognition which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services.  In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018 and the Company is in the process of assessing the impact on its consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-14-054018:notes:12]
[same as prior period, unchanged from 0001104659-14-005587:notes:9]

[0001104659-14-054018:notes:13]
[same as prior period, unchanged from 0001104659-14-005587:notes:10]

[0001104659-14-054018:notes:14]
[same as prior period, unchanged from 0001104659-14-005587:notes:11]

[0001104659-14-054018:notes:15]
|  |  | As of |  | As of |  |
|  |  | June 27, 2014 |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Raw materials |  | $ | 2,265,442 |  | $ | 2,349,278 |  |
| Work-in-progress |  | 617,390 |  | 608,284 |  |
| Finished goods |  | 627,331 |  | 641,446 |  |
|  |  | $ | 3,510,163 |  | $ | 3,599,008 |  |

[0001104659-14-054018:notes:16]
[same as prior period, unchanged from 0001104659-14-005587:notes:13]

[0001104659-14-054018:notes:17]
The following table summarizes the activity in the Company’s goodwill account during the three-month period ended June 27, 2014:

[0001104659-14-054018:notes:18]
|  |  | Amount |  |
|  |  | (In thousands) |  |
| Balance, beginning of the year |  | $ | 292,758 |  |
| Purchase accounting adjustments (1) |  | 8,272 |  |
| Foreign currency translation adjustments |  | 62 |  |
| Balance, end of the period |  | $ | 301,092 |  |

[0001104659-14-054018:notes:19]
(1)                 Fair value adjustment made to certain assets acquired in connection with the Company’s acquisition of Riwisa AG.

[0001104659-14-054018:notes:20]
[same as prior period, unchanged from 0001104659-14-005587:notes:18]

[0001104659-14-054018:notes:21]
|  |  | As of June 27, 2014 |  | As of March 31, 2014 |  |
|  |  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |
|  |  | Carrying |  | Accumulated |  | Carrying |  | Carrying |  | Accumulated |  | Carrying |  |
|  |  | Amount |  | Amortization |  | Amount |  | Amount |  | Amortization |  | Amount |  |
|  |  | (In thousands) |  |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles |  | $ | 204,249 |  | $ | (146,571 | ) | $ | 57,678 |  | $ | 204,369 |  | $ | (140,713 | ) | $ | 63,656 |  |
| Licenses and other intangibles |  | 43,436 |  | (12,837 | ) | 30,599 |  | 32,564 |  | (11,760 | ) | 20,804 |  |
| Total |  | $ | 247,685 |  | $ | (159,408 | ) | $ | 88,277 |  | $ | 236,933 |  | $ | (152,473 | ) | $ | 84,460 |  |

[0001104659-14-054018:notes:22]
The gross carrying amounts of intangible assets are removed when the recorded amounts have been fully amortized.  During the three-month period ended June 27, 2014, the value of licenses and other intangibles increased by $10.0 million as a result of the purchase of certain technology rights.  The estimated future annual amortization expense for intangible assets is as follows:

[0001104659-14-054018:notes:23]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2015 (1) |  | $ | 22,243 |  |
| 2016 |  | 24,845 |  |
| 2017 |  | 17,420 |  |
| 2018 |  | 9,708 |  |
| 2019 |  | 4,798 |  |
| Thereafter |  | 9,263 |  |
| Total amortization expense |  | $ | 88,277 |  |

[0001104659-14-054018:notes:24]
(1)     Represents estimated amortization for the remaining nine-month period ending March 31, 2015.

[0001104659-14-054018:notes:25]
Other Current Assets / Liabilities

[0001104659-14-054018:notes:26]
Other current assets include certain assets purchased on behalf of a customer and financed by a third party banking institution of $268.4 million and $267.5 million as of June 27, 2014 and March 31, 2014, respectively, with a corresponding liability recorded to other current liabilities of $286.5 million as of both dates.

[0001104659-14-054018:notes:27]
Other current liabilities also includes customer working capital advances of $246.2 million and $754.7 million as of June 27, 2014 and March 31, 2014, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-14-054018:notes:28]
[same as prior period, unchanged from 0001104659-14-005587:notes:25]

[0001104659-14-054018:notes:29]
During the first quarter of fiscal 2015, the Company granted equity compensation awards under the 2010 Equity Incentive Plan (the “2010 Plan”).  The following table summarizes the Company’s share-based compensation expense:

[0001104659-14-054018:notes:30]
|  |  | Three-Month Periods Ended |  |
|  |  | June 27, 2014 |  | June 28, 2013 |  |
|  |  | (In thousands) |  |
| Cost of sales |  | $ | 1,611 |  | $ | 1,352 |  |
| Selling, general and administrative expenses |  | 10,071 |  | 7,237 |  |
| Total stock-based compensation expense |  | $ | 11,682 |  | $ | 8,589 |  |

[0001104659-14-054018:notes:31]
No options were granted under the 2010 Plan during the first quarter of fiscal 2015.  Total unrecognized compensation expense related to share options is $0.4 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of 0.9 years. As of June 27, 2014, the number of options outstanding and exercisable was 20.7 million and 20.6 million, respectively, at weighted-average exercise prices of $8.36 and $8.38 per share, respectively.

[0001104659-14-054018:notes:32]
During the three-month period ended June 27, 2014, the Company granted 3.1 million unvested share bonus awards at an average grant date price of $11.20 per share, under its 2010 Plan.  Additionally, the Company granted share bonus awards to certain key employees of 0.9 million shares, which represents the target amount, whereby vesting is contingent primarily on certain market conditions.  These shares will cliff vest after a period of three years, if such conditions have been met. The number of shares issued can range from zero to 1.8 million based on the achievement levels of the respective conditions.

[0001104659-14-054018:notes:33]
As of June 27, 2014, approximately 18.6 million unvested share bonus awards were outstanding under the 2010 Plan, of which vesting for a targeted amount of 5.2 million is contingent primarily on meeting certain market conditions.  The number of shares that will ultimately be issued can range from zero to 10.1 million based on the achievement levels of the respective conditions.  During the three-month period ended June 27, 2014, 0.3 million shares vested in connection with the remaining number of share bonus awards with market conditions granted in fiscal 2011, and 0.4 million shares vested in connection with half of the share bonus awards with market conditions granted in fiscal 2012.

[0001104659-14-054018:notes:34]
As of June 27, 2014, total unrecognized compensation expense related to unvested share bonus awards granted under the 2010 Plan is $92.9 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of 2.75 years.

[0001104659-14-054018:notes:35]
Approximately $25.6 million of the total unrecognized compensation cost, net of estimated forfeitures, is related to awards whereby vesting is contingent on meeting certain market conditions.


## us-gaap:EarningsPerShareTextBlock

[0001104659-14-054018:notes:36]
[same as prior period, unchanged from 0001104659-14-005587:notes:32]

[0001104659-14-054018:notes:37]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share:

[0001104659-14-054018:notes:38]
|  |  | Three-Month Periods Ended |  |
|  |  | June 27, 2014 |  | June 28, 2013 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings per share: |  |  |  |  |  |
| Net income |  | $ | 173,887 |  | $ | 59,257 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  | 587,233 |  | 626,120 |  |
| Basic earnings per share |  | $ | 0.30 |  | $ | 0.09 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income |  | $ | 173,887 |  | $ | 59,257 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  | 587,233 |  | 626,120 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) |  | 14,067 |  | 13,779 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding |  | 601,300 |  | 639,899 |  |
| Diluted earnings per share |  | $ | 0.29 |  | $ | 0.09 |  |

[0001104659-14-054018:notes:39]
(1)     Options to purchase ordinary shares of 12.6 million and 19.2 million during the three-month periods ended June 27, 2014 and June 28, 2013, respectively, and share bonus awards of 0.4 million and 2.5 million during the three-month periods ended June 27, 2014 and June 28, 2013, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary share equivalents.


## flex:InterestAndOtherNetTextBlock

[0001104659-14-054018:notes:40]
5.  INTEREST AND OTHER, NET

[0001104659-14-054018:notes:41]
During the three-month periods ended June 27, 2014 and June 28, 2013, the Company recognized interest expense of $18.5 million and $20.2 million, respectively, on its debt obligations outstanding during the period.  The weighted average interest rates for the Company’s long-term debt were 3.2% and 3.5% for the three-month periods ended June 27, 2014 and June 28, 2013, respectively.

[0001104659-14-054018:notes:42]
During the three-month periods ended June 27, 2014 and June 28, 2013, the Company recognized interest income of $5.3 million and $3.3 million, respectively.

[0001104659-14-054018:notes:43]
During the three-month periods ended June 27, 2014 and June 28, 2013, the Company recognized a foreign exchange loss of $1.4 million and a gain of $4.7 million, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-14-054018:notes:44]
7.  FINANCIAL INSTRUMENTS

[0001104659-14-054018:notes:45]
[same as prior period, unchanged from 0001104659-14-005587:notes:53]

[0001104659-14-054018:notes:46]
The Company enters into forward contracts and foreign currency swap contracts to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions.  The Company hedges committed exposures and does not engage in speculative transactions.  As of June 27, 2014, the aggregate notional amount of the Company’s outstanding foreign currency forward and swap contracts was $4.2 billion as summarized below:

[0001104659-14-054018:notes:47]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |  |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |  |
|  |  | (In thousands) |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |
| CNY |  | 3,302,000 |  | — |  | $ | 529,650 |  | $ | — |  |
| EUR |  | 15,113 |  | 29,518 |  | 20,598 |  | 40,120 |  |
| HUF |  | 10,532,000 |  | — |  | 46,767 |  | — |  |
| PLN |  | 83,000 |  | — |  | 27,316 |  | — |  |
| MXN |  | 1,935,600 |  | — |  | 148,749 |  | — |  |
| MYR |  | 294,850 |  | — |  | 91,449 |  | — |  |
| SGD |  | 34,230 |  | — |  | 27,382 |  | — |  |
| Other |  | N/A |  | N/A |  | 31,373 |  | 450 |  |
|  |  |  |  |  |  | 923,284 |  | 40,570 |  |
| Other Forward/Swap Contracts |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  | 348,000 |  | — |  | 157,694 |  |
| CAD |  | 138,591 |  | 120,959 |  | 128,472 |  | 112,374 |  |
| CNY |  | 666,823 |  | — |  | 106,943 |  | — |  |
| EUR |  | 485,286 |  | 654,488 |  | 661,247 |  | 891,706 |  |
| GBP |  | 29,972 |  | 55,750 |  | 50,857 |  | 94,535 |  |
| HUF |  | 18,963,300 |  | 20,835,600 |  | 84,206 |  | 92,520 |  |
| JPY |  | 5,490,146 |  | 2,172,817 |  | 53,897 |  | 21,324 |  |
| MXN |  | 1,217,840 |  | 712,520 |  | 93,590 |  | 54,757 |  |
| MYR |  | 211,344 |  | 21,655 |  | 65,549 |  | 6,716 |  |
| SEK |  | 486,657 |  | 852,268 |  | 72,314 |  | 126,916 |  |
| Other |  | N/A |  | N/A |  | 176,694 |  | 140,468 |  |
|  |  |  |  |  |  | 1,493,769 |  | 1,699,010 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 2,417,053 |  | $ | 1,739,580 |  |

[0001104659-14-054018:notes:48]
As of June 27, 2014, the fair value of the Company’s short-term foreign currency contracts was not material and is included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards.  Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations.  As of June 27, 2014 and March 31, 2014, the Company also has included net deferred losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to the effective portion of changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses were not material as of June 27, 2014, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0001104659-14-054018:notes:49]
The following table presents the fair value of the Company’s derivative instruments utilized for foreign currency risk management purposes:

[0001104659-14-054018:notes:50]
|  |  | Fair Values of Derivative Instruments |  |
|  |  | Asset Derivatives |  | Liability Derivatives |  |
|  |  |  |  | Fair Value |  |  |  | Fair Value |  |
|  |  | Balance Sheet Location |  | June 27, 2014 |  | March 31, 2014 |  | Balance Sheet Location |  | June 27, 2014 |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 6,007 |  | $ | 3,464 |  | Other current liabilities |  | $ | 6,763 |  | $ | 10,457 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 3,574 |  | $ | 4,722 |  | Other current liabilities |  | $ | 4,077 |  | $ | 6,949 |  |

[0001104659-14-054018:notes:51]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with a single counterparty.  The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets.  The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any period presented.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001104659-14-054018:notes:52]
|  |  | Three-Month Period Ended |  | Three-Month Period Ended |  |
|  |  | June 27, 2014 |  | June 28, 2013 |  |
|  |  | Unrealized gain (loss) on derivative instruments and other |  | Foreign currency translation adjustments |  | Total |  | Unrealized gain (loss) on derivative instruments and other |  | Foreign currency translation adjustments |  | Total |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | (32,849 | ) | $ | (93,307 | ) | $ | (126,156 | ) | $ | (18,857 | ) | $ | (58,624 | ) | $ | (77,481 | ) |
| Other comprehensive gain (loss) before reclassifications |  | 1,000 |  | 5,107 |  | 6,107 |  | (6,245 | ) | (17,509 | ) | (23,754 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss |  | 9,725 |  | (9,252 | ) | 473 |  | (3,889 | ) | — |  | (3,889 | ) |
| Net current-period other comprehensive gain (loss) |  | 10,725 |  | (4,145 | ) | 6,580 |  | (10,134 | ) | (17,509 | ) | (27,643 | ) |
| Ending balance |  | $ | (22,124 | ) | $ | (97,452 | ) | $ | (119,576 | ) | $ | (28,991 | ) | $ | (76,133 | ) | $ | (105,124 | ) |


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0001104659-14-054018:notes:53]
|  |  | Three-Month Periods Ended |  |
|  |  | June 27, 2014 |  | June 28, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 470,908 |  | $ | 412,357 |  |
| Transfers of receivables |  | 778,860 |  | 882,918 |  |
| Collections |  | (786,644 | ) | (874,388 | ) |
| Ending balance |  | $ | 463,124 |  | $ | 420,887 |  |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionContingentConsiderationTextBlock

[0001104659-14-054018:notes:54]
|  |  | Three-Month Periods Ended |  |
|  |  | June 27, 2014 |  | June 28, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 11,300 |  | $ | 25,000 |  |
| Fair value adjustments |  | — |  | (6,000 | ) |
| Ending balance |  | $ | 11,300 |  | $ | 19,000 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001104659-14-054018:notes:55]
|  |  | Fair Value Measurements as of June 27, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) |  | $ | — |  | $ | 607,202 |  | $ | — |  | $ | 607,202 |  |
| Deferred purchase price receivable (Note 9) |  | — |  | — |  | 463,124 |  | 463,124 |  |
| Foreign exchange forward contracts (Note 7) |  | — |  | 9,581 |  | — |  | 9,581 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities |  | 9,526 |  | 38,738 |  | — |  | 48,264 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 7) |  | $ | — |  | $ | (10,840 | ) | $ | — |  | $ | (10,840 | ) |
| Contingent consideration in connection with business acquisitions |  | — |  | — |  | (11,300 | ) | (11,300 | ) |

[0001104659-14-054018:notes:56]
|  |  | Fair Value Measurements as of March 31, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) |  | $ | — |  | $ | 552,928 |  | $ | — |  | $ | 552,928 |  |
| Deferred purchase price receivable (Note 9) |  | — |  | — |  | 470,908 |  | 470,908 |  |
| Foreign exchange forward contracts (Note 7) |  | — |  | 8,186 |  | — |  | 8,186 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities |  | 9,456 |  | 36,751 |  | — |  | 46,207 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 7) |  | $ | — |  | $ | (17,406 | ) | $ | — |  | $ | (17,406 | ) |
| Contingent consideration in connection with business acquisitions |  | — |  | — |  | (11,300 | ) | (11,300 | ) |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0001104659-14-054018:notes:57]
|  |  | As of June 27, 2014 |  | As of March 31, 2014 |  |  |  |
|  |  | Carrying |  | Fair |  | Carrying |  | Fair |  | Fair Value |  |
|  |  | Amount |  | Value |  | Amount |  | Value |  | Hierarchy |  |
|  |  | (In thousands) |  |  |  |
| Term Loan, including current portion, due in installments through August 2018 |  | $ | 600,000 |  | $ | 592,500 |  | $ | 600,000 |  | $ | 591,750 |  | Level 1 |  |
| Term Loan, including current portion, due in installments through March 2019 |  | 500,000 |  | 492,500 |  | 500,000 |  | 497,190 |  | Level 1 |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 519,000 |  | 500,000 |  | 504,688 |  | Level 1 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 520,000 |  | 500,000 |  | 517,650 |  | Level 1 |  |
| Total |  | $ | 2,100,000 |  | $ | 2,124,000 |  | $ | 2,100,000 |  | $ | 2,111,278 |  |  |  |


## us-gaap:ScheduleOfRestructuringAndRelatedCostsTextBlock

[0001104659-14-054018:notes:58]
|  |  | Americas |  | Asia |  | Europe |  | Total |  |
|  |  | (In thousands) |  |
| Severance |  | $ | 11,331 |  | $ | 16,205 |  | $ | 4,631 |  | $ | 32,167 |  |
| Long-lived asset impairment |  | — |  | 1,900 |  | — |  | 1,900 |  |
| Other exit costs |  | 2,248 |  | 3,157 |  | 1,288 |  | 6,693 |  |
| Total restructuring charges |  | $ | 13,579 |  | $ | 21,262 |  | $ | 5,919 |  | $ | 40,760 |  |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0001104659-14-054018:notes:59]
Condensed Consolidating Balance Sheets as of June 27, 2014

[0001104659-14-054018:notes:60]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 265,273 |  | $ | 25,164 |  | $ | 1,057,253 |  | $ | — |  | $ | 1,347,690 |  |
| Accounts receivable |  | — |  | 806,735 |  | 2,087,887 |  | — |  | 2,894,622 |  |
| Inventories |  | — |  | 1,238,539 |  | 2,271,624 |  | — |  | 3,510,163 |  |
| Inter company receivable |  | 10,127,115 |  | 7,656,660 |  | 9,710,239 |  | (27,494,014 | ) | — |  |
| Other current assets |  | 389 |  | 145,098 |  | 1,091,461 |  | — |  | 1,236,948 |  |
| Total current assets |  | 10,392,777 |  | 9,872,196 |  | 16,218,464 |  | (27,494,014 | ) | 8,989,423 |  |
| Property and equipment, net |  | — |  | 438,870 |  | 1,815,794 |  | — |  | 2,254,664 |  |
| Goodwill and other intangible assets, net |  | 700 |  | 38,451 |  | 350,218 |  | — |  | 389,369 |  |
| Other assets |  | 2,573,176 |  | 98,214 |  | 2,126,471 |  | (4,363,493 | ) | 434,368 |  |
| Investment in subsidiaries |  | 1,013,070 |  | 858,751 |  | 16,602,017 |  | (18,473,838 | ) | — |  |
| Total assets |  | $ | 13,979,723 |  | $ | 11,306,482 |  | $ | 37,112,964 |  | $ | (50,331,345 | ) | $ | 12,067,824 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 36,250 |  | $ | 45 |  | $ | 19,043 |  | $ | — |  | $ | 55,338 |  |
| Accounts payable |  | — |  | 1,265,284 |  | 3,476,749 |  | — |  | 4,742,033 |  |
| Accrued payroll |  | — |  | 95,635 |  | 281,498 |  | — |  | 377,133 |  |
| Inter company payable |  | 9,539,121 |  | 9,978,361 |  | 7,976,532 |  | (27,494,014 | ) | — |  |
| Other current liabilities |  | 38,491 |  | 696,874 |  | 1,323,343 |  | — |  | 2,058,708 |  |
| Total current liabilities |  | 9,613,862 |  | 12,036,199 |  | 13,077,165 |  | (27,494,014 | ) | 7,233,212 |  |
| Long term liabilities |  | 2,103,601 |  | 2,007,345 |  | 2,786,291 |  | (4,363,493 | ) | 2,533,744 |  |
| Flextronics International Ltd. shareholders’ equity |  | 2,262,260 |  | (2,737,062 | ) | 21,210,900 |  | (18,473,838 | ) | 2,262,260 |  |
| Noncontrolling interests |  | — |  | — |  | 38,608 |  | — |  | 38,608 |  |
| Total shareholders’ equity |  | 2,262,260 |  | (2,737,062 | ) | 21,249,508 |  | (18,473,838 | ) | 2,300,868 |  |
| Total liabilities and shareholders’ equity |  | $ | 13,979,723 |  | $ | 11,306,482 |  | $ | 37,112,964 |  | $ | (50,331,345 | ) | $ | 12,067,824 |  |

[0001104659-14-054018:notes:61]
Condensed Consolidating Balance Sheets as of March 31, 2014

[0001104659-14-054018:notes:62]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 638,714 |  | $ | 30,500 |  | $ | 924,514 |  | $ | — |  | $ | 1,593,728 |  |
| Accounts receivable |  | — |  | 766,110 |  | 1,931,875 |  | — |  | 2,697,985 |  |
| Inventories |  | — |  | 1,387,510 |  | 2,211,498 |  | — |  | 3,599,008 |  |
| Inter company receivable |  | 8,867,520 |  | 6,968,138 |  | 9,149,244 |  | (24,984,902 | ) | — |  |
| Other current assets |  | 246 |  | 277,035 |  | 1,232,324 |  | — |  | 1,509,605 |  |
| Total current assets |  | 9,506,480 |  | 9,429,293 |  | 15,449,455 |  | (24,984,902 | ) | 9,400,326 |  |
| Property and equipment, net |  | — |  | 427,390 |  | 1,861,266 |  | — |  | 2,288,656 |  |
| Goodwill and other intangible assets, net |  | 775 |  | 39,074 |  | 337,369 |  | — |  | 377,218 |  |
| Other assets |  | 2,585,169 |  | 103,335 |  | 4,628,970 |  | (6,883,524 | ) | 433,950 |  |
| Investment in subsidiaries |  | 3,350,690 |  | 522,489 |  | 16,392,541 |  | (20,265,720 | ) | — |  |
| Total assets |  | $ | 15,443,114 |  | $ | 10,521,581 |  | $ | 38,669,601 |  | $ | (52,134,146 | ) | $ | 12,500,150 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 32,500 |  | $ | 60 |  | $ | 15 |  | $ | — |  | $ | 32,575 |  |
| Accounts payable |  | — |  | 1,256,204 |  | 3,491,575 |  | — |  | 4,747,779 |  |
| Accrued payroll |  | — |  | 83,288 |  | 271,601 |  | — |  | 354,889 |  |
| Inter company payable |  | 8,607,486 |  | 9,422,179 |  | 6,955,237 |  | (24,984,902 | ) | — |  |
| Other current liabilities |  | 24,868 |  | 626,550 |  | 1,870,026 |  | — |  | 2,521,444 |  |
| Total current liabilities |  | 8,664,854 |  | 11,388,281 |  | 12,588,454 |  | (24,984,902 | ) | 7,656,687 |  |
| Long term liabilities |  | 4,615,210 |  | 2,050,460 |  | 2,859,638 |  | (6,883,524 | ) | 2,641,784 |  |
| Flextronics International Ltd. shareholders’ equity |  | 2,163,050 |  | (2,917,160 | ) | 23,182,880 |  | (20,265,720 | ) | 2,163,050 |  |
| Noncontrolling interest |  | — |  | — |  | 38,629 |  | — |  | 38,629 |  |
| Total shareholders’ equity |  | 2,163,050 |  | (2,917,160 | ) | 23,221,509 |  | (20,265,720 | ) | 2,201,679 |  |
| Total liabilities and shareholders’ equity |  | $ | 15,443,114 |  | $ | 10,521,581 |  | $ | 38,669,601 |  | $ | (52,134,146 | ) | $ | 12,500,150 |  |


## us-gaap:ScheduleOfCondensedIncomeStatementTableTextBlock

[0001104659-14-054018:notes:63]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended June 27, 2014

[0001104659-14-054018:notes:64]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 3,915,326 |  | $ | 5,312,077 |  | $ | (2,584,658 | ) | $ | 6,642,745 |  |
| Cost of sales |  | — |  | 3,580,578 |  | 5,266,040 |  | (2,584,658 | ) | 6,261,960 |  |
| Gross profit |  | — |  | 334,748 |  | 46,037 |  | — |  | 380,785 |  |
| Selling, general and administrative expenses |  | — |  | 44,626 |  | 164,651 |  | — |  | 209,277 |  |
| Intangible amortization |  | 75 |  | 623 |  | 6,253 |  | — |  | 6,951 |  |
| Interest and other, net |  | 16,531 |  | 259,748 |  | (301,651 | ) | — |  | (25,372 | ) |
| Income (loss) from continuing operations before income taxes |  | (16,606 | ) | 29,751 |  | 176,784 |  | — |  | 189,929 |  |
| Provision for income taxes |  | — |  | 1,482 |  | 14,560 |  | — |  | 16,042 |  |
| Equity in earnings in subsidiaries |  | 190,493 |  | 67,301 |  | 33,179 |  | (290,973 | ) | — |  |
| Net income (loss) |  | $ | 173,887 |  | $ | 95,570 |  | $ | 195,403 |  | $ | (290,973 | ) | $ | 173,887 |  |

[0001104659-14-054018:notes:65]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended June 28, 2013

[0001104659-14-054018:notes:66]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 3,484,434 |  | $ | 4,595,431 |  | $ | (2,288,740 | ) | $ | 5,791,125 |  |
| Cost of sales |  | — |  | 3,140,837 |  | 4,627,993 |  | (2,288,740 | ) | 5,480,090 |  |
| Gross profit (loss) |  | — |  | 343,597 |  | (32,562 | ) | — |  | 311,035 |  |
| Selling, general and administrative expenses |  | 800 |  | 51,224 |  | 171,595 |  | — |  | 223,619 |  |
| Intangible amortization |  | 75 |  | 1,081 |  | 7,046 |  | — |  | 8,202 |  |
| Interest and other, net |  | (49,280 | ) | 267,202 |  | (198,238 | ) | — |  | 19,684 |  |
| Income (loss) from continuing operations before income taxes |  | 48,405 |  | 24,090 |  | (12,965 | ) | — |  | 59,530 |  |
| Provision for (benefit from) income taxes |  | 10 |  | 1,251 |  | (988 | ) | — |  | 273 |  |
| Equity in earnings in subsidiaries |  | 10,862 |  | (11,551 | ) | 2,772 |  | (2,083 | ) | — |  |
| Net income (loss) |  | $ | 59,257 |  | $ | 11,288 |  | $ | (9,205 | ) | $ | (2,083 | ) | $ | 59,257 |  |


## flex:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0001104659-14-054018:notes:67]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended June 27, 2014

[0001104659-14-054018:notes:68]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non- Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 173,887 |  | $ | 95,570 |  | $ | 195,403 |  | $ | (290,973 | ) | $ | 173,887 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (4,145 | ) | (77,152 | ) | (271,529 | ) | 348,681 |  | (4,145 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | 10,725 |  | (21,989 | ) | (22,124 | ) | 44,113 |  | 10,725 |  |
| Comprehensive income (loss) |  | $ | 180,467 |  | $ | (3,571 | ) | $ | (98,250 | ) | $ | 101,821 |  | $ | 180,467 |  |

[0001104659-14-054018:notes:69]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended June 28, 2013

[0001104659-14-054018:notes:70]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non- Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 59,257 |  | $ | 11,288 |  | $ | (9,205 | ) | $ | (2,083 | ) | $ | 59,257 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (17,509 | ) | (13,644 | ) | (27,281 | ) | 40,925 |  | (17,509 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | (10,134 | ) | 2 |  | (10,135 | ) | 10,133 |  | (10,134 | ) |
| Comprehensive income (loss) |  | $ | 31,614 |  | $ | (2,354 | ) | $ | (46,621 | ) | $ | 48,975 |  | $ | 31,614 |  |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0001104659-14-054018:notes:71]
Condensed Consolidating Statements of Cash Flows for the Three-Month Period Ended June 27, 2014

[0001104659-14-054018:notes:72]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | (13,025 | ) | $ | 248,848 |  | $ | (316,992 | ) | $ | — |  | (81,169 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  | — |  | (35,401 | ) | (37,516 | ) | — |  | (72,917 | ) |
| Proceeds from divesture of business, net of cash held in divested business |  | — |  | — |  | (5,493 | ) | — |  | (5,493 | ) |
| Investing cash flows from (to) affiliates |  | (1,185,671 | ) | (538,017 | ) | 572,278 |  | 1,151,410 |  | — |  |
| Other investing activities, net |  | — |  | (959 | ) | (20,503 | ) | — |  | (21,462 | ) |
| Net cash provided by (used in) investing activities |  | (1,185,671 | ) | (574,377 | ) | 508,766 |  | 1,151,410 |  | (99,872 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | — |  | — |  | 26,615 |  | — |  | 26,615 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations |  | — |  | (393 | ) | (466 | ) | — |  | (859 | ) |
| Payments for repurchases of ordinary shares |  | (105,568 | ) | — |  | — |  | — |  | (105,568 | ) |
| Net proceeds from issuance of ordinary shares |  | 9,329 |  | — |  | — |  | — |  | 9,329 |  |
| Financing cash flows from (to) affiliates |  | 931,635 |  | 321,342 |  | (101,567 | ) | (1,151,410 | ) | — |  |
| Other financing activities, net |  | — |  | — |  | 300 |  | — |  | 300 |  |
| Net cash provided by (used in) financing activities |  | 835,396 |  | 320,949 |  | (75,118 | ) | (1,151,410 | ) | (70,183 | ) |
| Effect of exchange rates on cash and cash equivalents |  | (10,141 | ) | (756 | ) | 16,083 |  | — |  | 5,186 |  |
| Net increase (decrease) in cash and cash equivalents |  | (373,441 | ) | (5,336 | ) | 132,739 |  | — |  | (246,038 | ) |
| Cash and cash equivalents, beginning of period |  | 638,714 |  | 30,500 |  | 924,514 |  | — |  | 1,593,728 |  |
| Cash and cash equivalents, end of period |  | $ | 265,273 |  | $ | 25,164 |  | $ | 1,057,253 |  | $ | — |  | $ | 1,347,690 |  |

[0001104659-14-054018:notes:73]
Condensed Consolidating Statements of Cash Flows for the Three-Month Period Ended June 28, 2013

[0001104659-14-054018:notes:74]
|  |  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | 51,963 |  | $ | (568,028 | ) | $ | 713,609 |  | $ | 1,032 |  | $ | 198,576 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  | — |  | (105,657 | ) | (35,165 | ) | (551 | ) | (141,373 | ) |
| Acquisition of businesses, net of cash acquired |  | — |  | (1,026 | ) | (186,517 | ) | — |  | (187,543 | ) |
| Investing cash flows from (to) affiliates |  | (438,186 | ) | 354,871 |  | (589,921 | ) | 673,236 |  | — |  |
| Other investing activities, net |  | — |  | 890 |  | 29,289 |  | — |  | 30,179 |  |
| Net cash provided by (used in) investing activities |  | (438,186 | ) | 249,078 |  | (782,314 | ) | 672,685 |  | (298,737 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | — |  | 133 |  | 25 |  | — |  | 158 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations |  | (8,636 | ) | (414 | ) | (101 | ) | — |  | (9,151 | ) |
| Payments for repurchases of ordinary shares |  | (215,210 | ) | — |  | — |  | — |  | (215,210 | ) |
| Net proceeds from issuance of ordinary shares |  | 10,909 |  | — |  | — |  | — |  | 10,909 |  |
| Financing cash flows from (to) affiliates |  | 371,446 |  | 311,306 |  | (9,035 | ) | (673,717 | ) | — |  |
| Other financing activities, net |  | — |  | — |  | 15,652 |  | — |  | 15,652 |  |
| Net cash provided by (used in) financing activities |  | 158,509 |  | 311,025 |  | 6,541 |  | (673,717 | ) | (197,642 | ) |
| Effect of exchange rates on cash and cash equivalents |  | 10,211 |  | 369 |  | (20,290 | ) | — |  | (9,710 | ) |
| Net decrease in cash and cash equivalents |  | (217,503 | ) | (7,556 | ) | (82,454 | ) | — |  | (307,513 | ) |
| Cash and cash equivalents, beginning of period |  | 740,515 |  | 82,900 |  | 763,672 |  | — |  | 1,587,087 |  |
| Cash and cash equivalents, end of period |  | $ | 523,012 |  | $ | 75,344 |  | $ | 681,218 |  | $ | — |  | $ | 1,279,574 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001104659-14-054018:notes:75]
8.  ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001104659-14-054018:notes:76]
The changes in accumulated other comprehensive loss by component, net of tax, are as follows:

[0001104659-14-054018:notes:77]
Net losses reclassified from accumulated other comprehensive loss during the three-month period ended June 27, 2014 relating to derivative instruments and other includes $5.5 million attributable to the Company’s cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations. During the three-month period ended June 27, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a certain manufacturing facility in western Europe.  This loss includes the settlement of unrealized losses of $4.2 million on an insignificant defined benefit plan associated with the disposed facility offset by the release of certain cumulative foreign currency translation gains of $9.3 million, both of which have been reclassified from accumulated other comprehensive loss during the period.  The loss on sale is included in other charges (income), net in the condensed consolidated statement of operations.

[0001104659-14-054018:notes:78]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended June 28, 2013, was recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001104659-14-054018:notes:79]
9.  TRADE RECEIVABLES SECURITIZATION

[0001104659-14-054018:notes:80]
[same as prior period, unchanged from 0001104659-14-005587:notes:65]

[0001104659-14-054018:notes:81]
[same as prior period, unchanged from 0001104659-14-005587:notes:66]

[0001104659-14-054018:notes:82]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sell 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables.  Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $500.0 million for the Global Program, of which $400.0 million is committed and $100.0 million is uncommitted, and $300.0 million for the North American Program. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001104659-14-054018:notes:83]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.5% to 1.00% of serviced receivables per annum.  Servicing fees recognized during the three-month periods ended June 27, 2014 and June 28, 2013 were not material and are included in interest and other, net within the condensed consolidated statements of operations.  As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0001104659-14-054018:notes:84]
As of June 27, 2014, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of $699.1 million and deferred purchase price receivables of approximately $463.1 million.  As of March 31, 2014, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $729.3 million and deferred purchase price receivables of approximately $470.9 million.  The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction.  The deferred purchase price receivables are included in other current assets as of June 27, 2014 and March 31, 2014, and were carried at the expected recovery amount of the related receivables.  The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0001104659-14-054018:notes:85]
As of June 27, 2014 and March 31, 2014, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0001104659-14-054018:notes:86]
For the three-month periods ended June 27, 2014 and June 28, 2013, cash flows from sales of receivables under the ABS Programs consisted of approximately $1.1 billion and $0.9 billion for transfers of receivables, respectively (of which approximately $42.5 million and $141.2 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0001104659-14-054018:notes:87]
[same as prior period, unchanged from 0001104659-14-005587:notes:72]

[0001104659-14-054018:notes:88]
[same as prior period, unchanged from 0001104659-14-005587:notes:74]

[0001104659-14-054018:notes:89]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $546.0 million and $341.8 million as of June 27, 2014 and March 31, 2014, respectively. For the three-month periods ended June 27, 2014 and June 28, 2013, total accounts receivable sold to certain third party banking institutions was approximately $1.2 billion and $268.7 million, respectively.  The receivables that were sold were removed from the condensed consolidated balance sheets and were reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-14-054018:notes:90]
10.  FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES

[0001104659-14-054018:notes:91]
[same as prior period, unchanged from 0001104659-14-005587:notes:77]

[0001104659-14-054018:notes:92]
[same as prior period, unchanged from 0001104659-14-005587:notes:78]

[0001104659-14-054018:notes:93]
The Company has deferred compensation plans for its officers and certain other employees.  Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager.  The Company’s deferred compensation plan assets are for the most part included in other noncurrent assets on the condensed consolidated balance sheets and primarily include investments in equity securities that are valued using active market prices.

[0001104659-14-054018:notes:94]
[same as prior period, unchanged from 0001104659-14-005587:notes:80]

[0001104659-14-054018:notes:95]
[same as prior period, unchanged from 0001104659-14-005587:notes:81]

[0001104659-14-054018:notes:96]
[same as prior period, unchanged from 0001104659-14-005587:notes:82]

[0001104659-14-054018:notes:97]
[same as prior period, unchanged from 0001104659-14-005587:notes:83]

[0001104659-14-054018:notes:98]
[same as prior period, unchanged from 0001104659-14-005587:notes:84]

[0001104659-14-054018:notes:99]
The Company has accrued for certain contingent consideration in connection with its business acquisitions, which is measured at fair value based on certain internal models and inputs. The following table summarizes the activities related to contingent consideration:

[0001104659-14-054018:notes:100]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor.  Due to its high credit quality and short term maturity their fair value approximates carrying value.  Significant increases in either of the significant unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is insignificant.  The interrelationship between these inputs is also insignificant.  Refer to note 9 to the condensed consolidated financial statements for a reconciliation of the change in the deferred purchase price receivable during the three-month periods ended June 27, 2014 and June 28, 2013.

[0001104659-14-054018:notes:101]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended June 27, 2014 and June 28, 2013.

[0001104659-14-054018:notes:102]
[same as prior period, unchanged from 0001104659-14-005587:notes:89]

[0001104659-14-054018:notes:103]
[same as prior period, unchanged from 0001104659-14-005587:notes:90]

[0001104659-14-054018:notes:104]
[same as prior period, unchanged from 0001104659-14-005587:notes:93]

[0001104659-14-054018:notes:105]
Assets held for sale are recorded at the lesser of the carrying value or fair value, which is based on comparable sales from prevailing market data (level 2 inputs).  As of June 27, 2014 and March 31, 2014, the fair value of assets that were no longer in use and held for sale totaled approximately $3.6 million and $43.5 million, respectively. These assets primarily represent manufacturing facilities that have been closed as part of the Company’s historical facility consolidations and that met the criteria to be classified as held for sale. During the three-month period ended June 27, 2014, the Company sold $39.9 million of assets held for sale.

[0001104659-14-054018:notes:106]
There were no transfers between levels in the fair value hierarchy for assets held-for-sale during the three-month periods ended June 27, 2014 and June 28, 2013.

[0001104659-14-054018:notes:107]
[same as prior period, unchanged from 0001104659-14-005587:notes:102]

[0001104659-14-054018:notes:108]
[same as prior period, unchanged from 0001104659-14-005587:notes:103]

[0001104659-14-054018:notes:109]
The term loans and Notes due February 2020 and February 2023 are valued based on broker trading prices in active markets.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001104659-14-054018:notes:110]
11.  RESTRUCTURING CHARGES

[0001104659-14-054018:notes:111]
The Company completed certain restructuring activities during fiscal year 2014 that were intended to improve its operational efficiencies by reducing excess workforce and capacity and realign the corporate cost structure. Restructuring charges are recorded based upon employee termination dates, site closure and consolidation plans.

[0001104659-14-054018:notes:112]
During the three-month period ended June 28, 2013, the Company recognized restructuring charges of approximately $40.8 million, of which $35.1 million were recorded as a component of cost of sales and $5.6 million were recorded as a component of selling, general and administrative expenses.  Of the total restructuring charges, $32.2 million was associated with the terminations of 5,106 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 3,947 in Asia, 1,105 in the Americas and 54 in Europe. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on equipment no longer in use and to be disposed of, and other exit related costs due to facility closures or rationalizations.  Of the total restructuring charges, $1.9 million were non-cash charges related to the impairment of long-lived assets, and were classified as a component of cost of sales.

[0001104659-14-054018:notes:113]
The components of the restructuring charges by geographic region incurred during the three-month period ended June 28, 2013 were as follows:

[0001104659-14-054018:notes:114]
[same as prior period, unchanged from 0001104659-14-005587:notes:112]

[0001104659-14-054018:notes:115]
During the three-month period ended June 28, 2013, the Company recognized approximately $6.7 million of other exit costs, which was primarily comprised of $3.8 million related to personnel costs and $2.9 million of contractual obligations that resulted from facility closures. The majority of these costs were classified as a component of cost of sales.

[0001104659-14-054018:notes:116]
During the three-month period ended June 27, 2014, the Company paid approximately $20.9 million for restructuring charges that were primarily incurred in fiscal year 2014 and prior.  Total restructuring charges accrued as of June 27, 2014 were approximately $27.3 million, of which $3.5 million was classified as a long-term obligation.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001104659-14-054018:notes:117]
12.  COMMITMENTS AND CONTINGENCIES

[0001104659-14-054018:notes:118]
Litigation and other legal matters

[0001104659-14-054018:notes:119]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International, Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431).  The complaint asserts various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products.  The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys’ fees and costs.  The plaintiff also seeks a jury trial.  On June 25, 2014, we filed motions for Demurrer and to Strike asking the court to dismiss the claims against us.  The court has scheduled a hearing on the motions for August 29, 2014.  Although the outcome of this matter is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of this matter, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements.

[0001104659-14-054018:notes:120]
During the first quarter of fiscal 2015, one of our non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties.  The Company believes there is no legal basis for the assessment and expects that any losses are remote.  The Company plans to vigorously defend itself through the administrative and judicial processes.

[0001104659-14-054018:notes:121]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0001104659-14-054018:notes:122]
13.  SHARE REPURCHASES

[0001104659-14-054018:notes:123]
During the three-month ended June 27, 2014 the Company repurchased 10.5 million shares at an aggregate purchase price of $102.1 million and retired all these shares.  As of June 27, 2014, approximately 26.5 million shares were available to be repurchased under the current plan.  Share repurchases by the Company under the repurchase plan, which was approved by the Company’s Board of Directors on July 24, 2013, are subject to an aggregate limit of 10% of the Company’s ordinary shares outstanding as of the date of the most recent the Extraordinary General Meeting held on July 29, 2013.


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001104659-14-054018:notes:124]
14.  SUPPLEMENTAL GUARANTOR AND NON-GUARANTOR CONDENSED CONSOLIDATING FINANCIAL STATEMENTS

[0001104659-14-054018:notes:125]
Flextronics International Ltd. (“Parent”) has two tranches of Notes of $500 million each outstanding, which mature on February 15, 2020 and February 15, 2023, respectively. These Notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company’s 100% owned subsidiaries (the “guarantor subsidiaries”). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade.

[0001104659-14-054018:notes:126]
[same as prior period, unchanged from 0001104659-14-005587:notes:140]


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001104659-14-054018:notes:127]
6.  OTHER CHARGES (INCOME), NET

[0001104659-14-054018:notes:128]
During the fourth quarter of fiscal year 2014, the Company recognized $55.0 million of other charges for a contractual obligation to reimburse a customer for certain performance provisions as defined in the customer contract.  During the first quarter of fiscal 2015, an amendment to this contract was executed which included the removal of the $55.0 million contractual obligation. Accordingly, the Company reversed this charge with a corresponding credit to other income, included in other charges (income), net in the condensed consolidated statement of operations.

[0001104659-14-054018:notes:129]
Further, during the three-month period ended June 27, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a certain manufacturing facility in western Europe.  The Company received $11.5 million in cash for the sale of $27.2 million in net assets of the facility.  The loss also includes $4.6 million of estimated transaction costs, partially offset by a credit of $9.3 million for the release of cumulative foreign translation gains triggered by the disposition.

[0001104659-14-054018:notes:130]
During the three-month period ended June 28, 2013, the Company recognized a loss of $7.1 million relating to the exercise of a warrant to purchase shares of a certain supplier and sale of the underlying shares for total proceeds of $67.3 million.
