# FLEX 8-K — 0001104659-14-053288 filed 2014-07-24

## item codes, every 8-K on or before 2014-07-28

- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2014-07-28

- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-14-053288:8k_2_02:1]
EX-99.1
2
a14-17675_1ex99d1.htm
EX-99.1

[0001104659-14-053288:8k_2_02:2]
Exhibit 99.1

[0001104659-14-053288:8k_2_02:3]
PRESS RELEASE

[0001104659-14-053288:8k_2_02:4]
| Renee Brotherton | Kevin Kessel |
| Corporate Communications | Investor Relations |
| (408) 576-7189 | (408) 576-7985 |
| renee.brotherton@flextronics.com | kevin.kessel@flextronics.com |

[0001104659-14-053288:8k_2_02:5]
FLEXTRONICS REPORTS FIRST QUARTER FISCAL 2015 RESULTS

[0001104659-14-053288:8k_2_02:6]
·    Net sales exceeded guidance, increasing over $850 million or 15% year-over-year

[0001104659-14-053288:8k_2_02:7]
·    Adjusted operating profit of $183 million exceeded guidance, up 34% year-over-year

[0001104659-14-053288:8k_2_02:8]
·    Adjusted EPS at $0.25 was above guidance and rose 39% year-over-year

[0001104659-14-053288:8k_2_02:9]
San Jose, CA, July 24, 2014 — Flextronics (NASDAQ: FLEX), a leading end-to-end supply chain solutions company, today announced results for its first quarter, fiscal 2015 ended June 27, 2014:

[0001104659-14-053288:8k_2_02:10]
|  |  | Three Month Periods Ended |  |
|  |  | June 27 |  | March 31 |  | June 28 |  |
| (US$ in millions, except WASO and EPS) |  | 2014 |  | 2014 |  | 2013 |  |
| Net sales |  | $ | 6,643 |  | $ | 6,724 |  | $ | 5,791 |  |
| Adjusted operating income |  | $ | 183 |  | $ | 182 |  | $ | 137 |  |
| GAAP operating income |  | $ | 172 |  | $ | 137 |  | $ | 87 |  |
| Adjusted net income |  | $ | 148 |  | $ | 146 |  | $ | 112 |  |
| GAAP net income |  | $ | 174 |  | $ | 43 |  | $ | 59 |  |
| Adjusted EPS |  | $ | 0.25 |  | $ | 0.24 |  | $ | 0.18 |  |
| GAAP EPS |  | $ | 0.29 |  | $ | 0.07 |  | $ | 0.09 |  |
| WASO (millions) |  | 601 |  | 612 |  | 640 |  |

[0001104659-14-053288:8k_2_02:11]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release.

[0001104659-14-053288:8k_2_02:12]
First Quarter Fiscal 2015 Results of Operations

[0001104659-14-053288:8k_2_02:13]
Net sales for the first quarter were $6.6 billion, higher than the Company’s previously provided revenue guidance of $6.0 billion to $6.5 billion.  The Company’s adjusted earnings per diluted share of $0.25 in the first quarter was also higher than the Company’s previously provided guidance of $0.20 to $0.24.

[0001104659-14-053288:8k_2_02:14]
First quarter adjusted operating income was $183 million, increasing 34% year-over-year and exceeding the high end of the guidance range of $150 to $180 million.

[0001104659-14-053288:8k_2_02:15]
Adjusted net income excludes recognition of $55 million of other income due to the reversal of the contractual obligation charge recorded last quarter, as expected.

[0001104659-14-053288:8k_2_02:16]
“We are the most advanced worldwide supply chain solutions provider and continue to make steady improvements across most of our core financial metrics,” said Mike McNamara, chief executive officer at Flextronics. “During the June quarter, all four of our business groups

[0001104659-14-053288:8k_2_02:17]
exceeded our expectations and both our IEI and our HRS businesses reached record levels for quarterly sales.”

[0001104659-14-053288:8k_2_02:18]
“We continue to return value to shareholders through our stock buyback program by repurchasing another 10.5 million shares during the quarter for $106 million,” said Chris Collier, chief financial officer at Flextronics.

[0001104659-14-053288:8k_2_02:19]
Guidance

[0001104659-14-053288:8k_2_02:20]
For the second quarter ending September 26, 2014, revenue is expected to be in the range of $6.2 to $6.6 billion and adjusted EPS is expected to be in the range of $0.22 to $0.26 per diluted share.

[0001104659-14-053288:8k_2_02:21]
GAAP earnings per share is expected to be lower than the guidance provided herein by approximately $0.03 per diluted share for intangible amortization and stock-based compensation expense.

[0001104659-14-053288:8k_2_02:22]
Conference Calls and Web Casts

[0001104659-14-053288:8k_2_02:23]
A conference call hosted by Flextronics’s management team will be held today at 2:00 PM (PT) / 5:00 PM (ET) to discuss the Company’s financial results for the first quarter ended June 27, 2014.  The conference call will be broadcast via the Internet and may be accessed by logging on to the Company’s website at www.flextronics.com. Additional information in the form of a slide presentation may also be found on the Company’s website.  A replay of the broadcast will remain available on the Company’s website afterwards.

[0001104659-14-053288:8k_2_02:24]
About Flextronics

[0001104659-14-053288:8k_2_02:25]
Flextronics International Ltd. (Reg. No. 199002645H) is a leading end-to-end supply chain solutions company that delivers design, engineering, manufacturing and logistics services to a range of industries and end-markets, including data networking, telecom, enterprise computing and storage, industrial, capital equipment, appliances, automation, medical, automotive, aerospace and defense, energy, mobile, computing and other electronic product categories. Flextronics is an industry leader with $26 billion in sales, generated from helping customers design, build, ship, and service their products through an unparalleled network of facilities in approximately 30 countries and across four continents. Flextronics service offerings and vertically integrated component technologies optimize customer supply chains by lowering costs, increasing flexibility, and reducing time-to-market. For more information, visit www.flextronics.com or follow us on Twitter @flextronics.

[0001104659-14-053288:8k_2_02:26]
# # #

[0001104659-14-053288:8k_2_02:27]
possibility that benefits of the Company’s restructuring actions may not materialize as expected; that the expected revenue and margins from recently launched programs may not be realized; that recently proposed changes in tax laws in certain jurisdictions where we operate may materially impact our tax expense, and the effects that the current macroeconomic environment could have on our business and demand for our products as well as the effects that current credit and market conditions could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations. Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our reports on Form 10-K and 10-Q that we file with the U.S. Securities and Exchange Commission. The forward-looking statements in this press release are based on current expectations and Flextronics assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0001104659-14-053288:8k_2_02:28]
SCHEDULE I

[0001104659-14-053288:8k_2_02:29]
FLEXTRONICS INTERNATIONAL LTD.

[0001104659-14-053288:8k_2_02:30]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-14-053288:8k_2_02:31]
(In thousands, except per share amounts)

[0001104659-14-053288:8k_2_02:32]
|  |  | Three Month Periods Ended |  |
|  |  | June 27, 2014 |  | March 31, 2014 |  | June 28, 2013 |  |
| GAAP: |  |  |  |  |  |  |  |
| Net sales |  | $ | 6,642,745 |  | $ | 6,723,934 |  | $ | 5,791,125 |  |
| Cost of sales |  | 6,261,960 |  | 6,361,790 |  | 5,480,090 |  |
| Gross profit |  | 380,785 |  | 362,144 |  | 311,035 |  |
| Selling, general and administrative expenses |  | 209,277 |  | 224,764 |  | 223,619 |  |
| Operating income |  | 171,508 |  | 137,380 |  | 87,416 |  |
| Intangible amortization |  | 6,951 |  | 7,397 |  | 8,202 |  |
| Interest and other, net |  | 18,637 |  | 16,388 |  | 12,573 |  |
| Other charges (income), net |  | (44,009 | ) | 55,000 |  | 7,111 |  |
| Income before income taxes |  | 189,929 |  | 58,595 |  | 59,530 |  |
| Provision for income taxes |  | 16,042 |  | 15,620 |  | 273 |  |
| Net income |  | $ | 173,887 |  | $ | 42,975 |  | $ | 59,257 |  |
| EPS: |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.29 |  | $ | 0.07 |  | $ | 0.09 |  |
| Non-GAAP |  | $ | 0.25 |  | $ | 0.24 |  | $ | 0.18 |  |
| Diluted shares used in computing per share amounts |  | 601,300 |  | 611,719 |  | 639,899 |  |

[0001104659-14-053288:8k_2_02:33]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule IV attached to this press release.

[0001104659-14-053288:8k_2_02:34]
SCHEDULE II

[0001104659-14-053288:8k_2_02:35]
FLEXTRONICS INTERNATIONAL LTD.

[0001104659-14-053288:8k_2_02:36]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-14-053288:8k_2_02:37]
(In thousands, except per share amounts)

[0001104659-14-053288:8k_2_02:38]
|  |  | Three Month Periods Ended |  |
|  |  | June 27, 2014 |  | March 31, 2013 |  | June 28, 2013 |  |
| GAAP gross profit |  | $ | 380,785 |  | $ | 362,144 |  | $ | 311,035 |  |
| Stock-based compensation expense |  | 1,611 |  | 1,522 |  | 1,352 |  |
| Restructuring charges |  | — |  | 23,522 |  | 35,126 |  |
| Non-GAAP gross profit |  | $ | 382,396 |  | $ | 387,188 |  | $ | 347,513 |  |
| GAAP SG&A Expenses |  | $ | 209,277 |  | $ | 224,764 |  | $ | 223,619 |  |
| Stock-based compensation expense |  | 10,071 |  | 8,500 |  | 7,237 |  |
| Restructuring charges |  | — |  | 11,029 |  | 5,634 |  |
| Non-GAAP SG&A Expenses |  | $ | 199,206 |  | $ | 205,235 |  | $ | 210,748 |  |
| GAAP operating income |  | $ | 171,508 |  | $ | 137,380 |  | $ | 87,416 |  |
| Stock-based compensation expense |  | 11,682 |  | 10,022 |  | 8,589 |  |
| Restructuring charges |  | — |  | 34,551 |  | 40,760 |  |
| Non-GAAP operating income |  | $ | 183,190 |  | $ | 181,953 |  | $ | 136,765 |  |
| GAAP provision for income taxes |  | $ | 16,042 |  | $ | 15,620 |  | $ | 273 |  |
| Intangible amortization benefit |  | 167 |  | 291 |  | 329 |  |
| Restructuring charges |  | — |  | 3,881 |  | 4,048 |  |
| Non-GAAP provision for income taxes |  | $ | 16,209 |  | $ | 19,792 |  | $ | 4,650 |  |
| GAAP net income |  | $ | 173,887 |  | $ | 42,975 |  | $ | 59,257 |  |
| Stock-based compensation expense |  | 11,682 |  | 10,022 |  | 8,589 |  |
| Intangible amortization |  | 6,951 |  | 7,397 |  | 8,202 |  |
| Restructuring charges |  | — |  | 34,551 |  | 40,760 |  |
| Other charges (income), net (2)(3) |  | (44,009 | ) | 55,000 |  | — |  |
| Adjustments for taxes |  | (167 | ) | (4,172 | ) | (4,377 | ) |
| Non-GAAP net income |  | $ | 148,344 |  | $ | 145,773 |  | $ | 112,431 |  |
| EPS: |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.29 |  | $ | 0.07 |  | $ | 0.09 |  |
| Non-GAAP |  | $ | 0.25 |  | $ | 0.24 |  | $ | 0.18 |  |

[0001104659-14-053288:8k_2_02:39]
SCHEDULE III

[0001104659-14-053288:8k_2_02:40]
FLEXTRONICS INTERNATIONAL LTD.

[0001104659-14-053288:8k_2_02:41]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-14-053288:8k_2_02:42]
(In thousands)

[0001104659-14-053288:8k_2_02:43]
|  |  | June 27, 2014 |  | March 31, 2014 |  |
| ASSETS |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,347,690 |  | $ | 1,593,728 |  |
| Accounts receivable, net |  | 2,894,622 |  | 2,697,985 |  |
| Inventories |  | 3,510,163 |  | 3,599,008 |  |
| Other current assets |  | 1,236,948 |  | 1,509,605 |  |
| Total current assets |  | 8,989,423 |  | 9,400,326 |  |
| Property and equipment, net |  | 2,254,664 |  | 2,288,656 |  |
| Goodwill and other intangible assets, net |  | 389,369 |  | 377,218 |  |
| Other assets |  | 434,368 |  | 433,950 |  |
| Total assets |  | $ | 12,067,824 |  | $ | 12,500,150 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 55,338 |  | $ | 32,575 |  |
| Accounts payable |  | 4,742,033 |  | 4,747,779 |  |
| Other current liabilities |  | 2,435,841 |  | 2,876,333 |  |
| Total current liabilities |  | 7,233,212 |  | 7,656,687 |  |
| Long-term debt, net of current portion: |  |  |  |  |  |
| Revolving credit facility |  | — |  | — |  |
| 4.625% Notes (due 2020) |  | 500,000 |  | 500,000 |  |
| 5.000% Notes (due 2023) |  | 500,000 |  | 500,000 |  |
| Term Loans |  | 1,067,500 |  | 1,067,500 |  |
| Other long-term debt |  | 6,354 |  | 2,520 |  |
| Other liabilities |  | 459,890 |  | 571,764 |  |
| Total shareholders’ equity |  | 2,300,868 |  | 2,201,679 |  |
| Total liabilities and shareholders’ equity |  | $ | 12,067,824 |  | $ | 12,500,150 |  |

[0001104659-14-053288:8k_2_02:44]
SCHEDULE IV

[0001104659-14-053288:8k_2_02:45]
FLEXTRONICS INTERNATIONAL LTD. AND SUBSIDIARIES

[0001104659-14-053288:8k_2_02:46]
NOTES TO SCHEDULES I, II, & III

[0001104659-14-053288:8k_2_02:47]
(1) To supplement Flextronics’s unaudited selected financial data presented on a basis consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP selling, general and administrative expenses, non-GAAP operating income, non-GAAP income from operations, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude stock-based compensation expense, restructuring charges, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies.  We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flextronics’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flextronics’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-14-053288:8k_2_02:48]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance.  We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors.  In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-14-053288:8k_2_02:49]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-14-053288:8k_2_02:50]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-14-053288:8k_2_02:51]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-14-053288:8k_2_02:52]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-14-053288:8k_2_02:53]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-14-053288:8k_2_02:54]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types.  In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-14-053288:8k_2_02:55]
Restructuring charges include severance, asset impairment, lease termination, contract and product exit costs and other charges primarily related to the closures and consolidations of various manufacturing

[0001104659-14-053288:8k_2_02:56]
facilities. These costs may vary in size based on the Company’s restructuring activities, and are not directly related to ongoing or core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends, and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-14-053288:8k_2_02:57]
Intangible amortization consists of non-cash charges that can be impacted by the timing and magnitude of acquisitions.  The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-14-053288:8k_2_02:58]
Other charges (income), net — see notes (2) and (3) below

[0001104659-14-053288:8k_2_02:59]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies.

[0001104659-14-053288:8k_2_02:60]
(2)         In accordance with a manufacturing agreement, the Company recognized a $55.0 million charge for a contractual obligation during the quarter ended March 31, 2014.  During the first quarter of fiscal 2015, an amendment was executed which included the removal of the $55.0 million obligation. Accordingly, the Company reversed this charge with a corresponding credit to other income, included in other charges (income), net with no impact to cash.

[0001104659-14-053288:8k_2_02:61]
(3)         During the first quarter of fiscal 2015, the Company recognized a loss of $11.0 million in connection with the disposition of a certain European manufacturing facility, which is included in other charges (income), net.
