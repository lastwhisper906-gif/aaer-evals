# FLEX MD&A — 0001104659-14-054018


## mdna

[0001104659-14-054018:mdna:1]
ITEM 2.  MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001104659-14-054018:mdna:2]
[same as prior period, unchanged from 0001104659-14-005587:mdna:2]

[0001104659-14-054018:mdna:3]
[same as prior period, unchanged from 0001104659-14-005587:mdna:3]

[0001104659-14-054018:mdna:4]
We are a globally-recognized leading provider of supply chain solutions that span from concept through consumption. We design, build, ship and service a complete packaged electronic product for original equipment manufacturers (“OEMs”) in the following business groups: High Reliability Solutions (“HRS”), which is comprised of our medical, automotive, and defense and aerospace businesses; Consumer Technology Group (“CTG”), which includes our mobile devices business, including smart phones; our consumer electronics business, including game consoles and wearable electronics; and our high-volume computing business, including various supply chain solutions for notebook personal computing (“PC”), tablets, and printers; Industrial and Emerging Industries (“IEI”), which is comprised of our household appliances, semi-cap equipment, kiosks, energy and emerging industries businesses; and Integrated Network Solutions (“INS”), which includes our telecommunications infrastructure, data networking, connected home, and server and storage businesses.

[0001104659-14-054018:mdna:5]
Our strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our OEM customers. This enables our OEM customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001104659-14-054018:mdna:6]
During the recent years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, internet service providers or e-commerce retailers have started to enter the highly competitive and rapidly evolving hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0001104659-14-054018:mdna:7]
We use a portfolio management approach to manage our extensive service offerings. As our OEM customers change in the way they go to market, we reorganize and rebalance our business portfolio in order to align with our customers’ needs and requirements and to optimize our operating results. With the acquisition of certain manufacturing operations from Google’s Motorola Mobility LLC during the first quarter of fiscal 2014, we have experienced an increase in the percentage of our revenues from the CTG business group, and expect the amount of revenue from our CTG business group, relative to total revenue, to stabilize going forward. The objective of our operating model is to allow us to redeploy and reposition our assets and resources to meet specific customer needs across all of the markets we serve, and we have been able to successfully reposition our assets and capacity between the various business groups to serve our customers as required, which illustrates the overall flexibility of our model.

[0001104659-14-054018:mdna:8]
During fiscal year 2014, we launched multiple programs broadly across our portfolio of services, and, in some instances, we deployed certain new technologies.  We expect that these new programs will continue to increase in complexity in order to provide competitive advantages to our customers.  We anticipate these programs will continue ramping with an increase in volume production during fiscal year 2015 and beyond.  Until we achieve such higher levels of revenue, we expect that our gross margin and operating margin may be negatively impacted as profitability normally lags revenue growth due to incremental start-up costs, operational inefficiencies, under-absorbed overhead costs and lower manufacturing program volumes while in the ramp phase.  We expect that our

[0001104659-14-054018:mdna:9]
margins for these programs will improve over time as the revenue increases due to increased volumes and certain cost control measures.

[0001104659-14-054018:mdna:10]
We are one of the world’s largest providers of global supply chain solutions, with revenues of $6.6 billion for the three-month period ended June 27, 2014 and $26.1 billion in fiscal year 2014.  We have established an extensive network of manufacturing facilities in the world’s major electronics markets (Asia, the Americas and Europe) in order to serve the growing outsourcing needs of both multinational and regional OEMs. We design, build, ship and service electronics products for our customers through a network of facilities in approximately 30 countries across four continents.  As of June 27, 2014, our total manufacturing capacity was approximately 25.6 million square feet.  The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0001104659-14-054018:mdna:11]
|  |  | Three-Month Periods Ended |  |
| Net sales: |  | June 27, 2014 |  | June 28, 2013 |  |
|  |  | (In thousands) |  |
| China |  | $ | 2,550,230 |  | 38 | % | $ | 2,135,041 |  | 37 | % |
| Mexico |  | 849,598 |  | 13 | % | 877,473 |  | 15 | % |
| U.S |  | 754,720 |  | 11 | % | 640,786 |  | 11 | % |
| Brazil |  | 596,647 |  | 9 | % | 330,594 |  | 6 | % |
| Malaysia |  | 541,113 |  | 8 | % | 535,620 |  | 9 | % |
| Hungary |  | 240,469 |  | 4 | % | 248,301 |  | 4 | % |
| Other |  | 1,109,968 |  | 17 | % | 1,023,310 |  | 18 | % |
|  |  | $ | 6,642,745 |  |  |  | $ | 5,791,125 |  |  |  |

[0001104659-14-054018:mdna:12]
|  |  | As of |  | As of |  |
| Property and equipment, net: |  | June 27, 2014 |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| China |  | $ | 895,657 |  | 40 | % | $ | 941,850 |  | 41 | % |
| U.S |  | 362,608 |  | 16 | % | 362,199 |  | 16 | % |
| Mexico |  | 286,789 |  | 13 | % | 326,287 |  | 14 | % |
| Malaysia |  | 154,497 |  | 7 | % | 153,194 |  | 7 | % |
| Hungary |  | 101,269 |  | 4 | % | 103,266 |  | 5 | % |
| Brazil |  | 89,702 |  | 4 | % | 88,867 |  | 4 | % |
| Other |  | 364,142 |  | 16 | % | 312,993 |  | 13 | % |
|  |  | $ | 2,254,664 |  |  |  | $ | 2,288,656 |  |  |  |

[0001104659-14-054018:mdna:13]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and industrial campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing electronics products for leading multinational and regional OEMs. Specifically, we have launched multiple product innovation centers (“PIC”) focused exclusively on offering our OEM customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0001104659-14-054018:mdna:14]
[same as prior period, unchanged from 0001104659-14-005587:mdna:13]

[0001104659-14-054018:mdna:15]
[same as prior period, unchanged from 0001104659-14-005587:mdna:14]

[0001104659-14-054018:mdna:16]
[same as prior period, unchanged from 0001104659-14-005587:mdna:15]

[0001104659-14-054018:mdna:17]
[same as prior period, unchanged from 0001104659-14-005587:mdna:16]

[0001104659-14-054018:mdna:18]
[same as prior period, unchanged from 0001104659-14-005587:mdna:17]

[0001104659-14-054018:mdna:19]
[same as prior period, unchanged from 0001104659-14-005587:mdna:18]

[0001104659-14-054018:mdna:20]
[same as prior period, unchanged from 0001104659-14-005587:mdna:19]

[0001104659-14-054018:mdna:21]
[same as prior period, unchanged from 0001104659-14-005587:mdna:20]

[0001104659-14-054018:mdna:22]
[same as prior period, unchanged from 0001104659-14-005587:mdna:21]

[0001104659-14-054018:mdna:23]
[same as prior period, unchanged from 0001104659-14-005587:mdna:22]

[0001104659-14-054018:mdna:24]
[same as prior period, unchanged from 0001104659-14-005587:mdna:23]

[0001104659-14-054018:mdna:25]
[same as prior period, unchanged from 0001104659-14-005587:mdna:24]

[0001104659-14-054018:mdna:26]
[same as prior period, unchanged from 0001104659-14-005587:mdna:26]

[0001104659-14-054018:mdna:27]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results may differ from those estimates and assumptions.

[0001104659-14-054018:mdna:28]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2014, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0001104659-14-054018:mdna:29]
[same as prior period, unchanged from 0001104659-14-005587:mdna:29]

[0001104659-14-054018:mdna:30]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read in conjunction with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our 2014 Annual Report on Form 10-K.

[0001104659-14-054018:mdna:31]
|  |  | Three-Month Periods Ended |  |
|  |  | June 27, 2014 |  | June 28, 2013 |  |
| Net sales |  | 100.0 | % | 100.0 | % |
| Cost of sales |  | 94.3 |  | 94.6 |  |
| Gross profit |  | 5.7 |  | 5.4 |  |
| Selling, general and administrative expenses |  | 3.2 |  | 3.9 |  |
| Intangible amortization |  | 0.1 |  | 0.1 |  |
| Interest and other, net |  | 0.3 |  | 0.2 |  |
| Other charges (income), net |  | (0.7 | ) | 0.1 |  |
| Income before income taxes |  | 2.8 |  | 1.1 |  |
| Provision for income taxes |  | 0.2 |  | — |  |
| Net income |  | 2.6 | % | 1.1 | % |

[0001104659-14-054018:mdna:32]
[same as prior period, unchanged from 0001104659-14-005587:mdna:32]

[0001104659-14-054018:mdna:33]
The following table sets forth our net sales by business group and their relative percentages. Historical information has been recast to reflect realignment of customers and/or products between business groups to ensure comparability:

[0001104659-14-054018:mdna:34]
|  |  | Three-Month Periods Ended |  |
| Business groups: |  | June 27, 2014 |  | June 28, 2013 |  |
|  |  | (In thousands) |  |
| Integrated Network Solutions |  | $ | 2,502,495 |  | 38 | % | $ | 2,532,146 |  | 44 | % |
| Consumer Technology Group |  | 2,160,134 |  | 33 | % | 1,546,483 |  | 27 | % |
| Industrial & Emerging Industries |  | 1,134,179 |  | 17 | % | 906,227 |  | 16 | % |
| High Reliability Solutions |  | 845,937 |  | 12 | % | 806,269 |  | 13 | % |
|  |  | $ | 6,642,745 |  |  |  | $ | 5,791,125 |  |  |  |

[0001104659-14-054018:mdna:35]
Net sales during the three-month period ended June 27, 2014 totaled $6.6 billion.  Sales increased by approximately $0.8 billion, or 14.7%, from $5.8 billion during the three-month period ended June 28, 2013.  Revenue increased across all of our business groups,

[0001104659-14-054018:mdna:36]
except for INS, which experienced a marginal decrease year over year.  Revenue from our CTG and IEI business groups increased by $0.6 billion and $0.2 billion, respectively.  The increased revenue from our CTG business group is primarily a result of our acquisition of certain manufacturing operations from Google’s Motorola Mobility LLC (Motorola) during the first quarter of fiscal 2014 and the business ramping up during the mid to latter part of fiscal 2014. The increase in revenue from our IEI business group is primarily attributable to an increase broadly across product categories, most notably in our semiconductor capital equipment and our household appliances businesses versus the prior year period.  For the three-month period ended June 27, 2014, net sales increased $0.4 billion in Asia, $0.3 billion in the Americas and $0.1 billion in Europe.

[0001104659-14-054018:mdna:37]
Our ten largest customers during the three-month period ended June 27, 2014 and June 28, 2013 accounted for approximately 53% and 49% of net sales, respectively. Google (including Motorola) accounted for more than 10% of net sales during the three-month period ended June 27, 2014. No single customer accounted for greater than 10% of our net sales during the three-month period ended June 28, 2013.

[0001104659-14-054018:mdna:38]
[same as prior period, unchanged from 0001104659-14-005587:mdna:38]

[0001104659-14-054018:mdna:39]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion and consolidation of manufacturing facilities. The flexible design of our manufacturing processes allows us to build a broad range of products in our facilities and better utilize our manufacturing capacity. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0001104659-14-054018:mdna:40]
Gross profit during the three-month period ended June 27, 2014 increased $69.8 million to $380.8 million, or 5.7% of net sales from $311.0 million, or 5.4% of net sales, during the three-month period ended June 28, 2013. Gross margins improved 30 basis points in the three-month period ended June 28, 2014 compared to that of the three-month period ended June 28, 2013 primarily as a result of restructuring charges of $35.1 million or 0.6% of net sales, included as a component of cost of sales, in the three-month period ended June 28, 2013. Gross profit for the first quarter of fiscal 2015 reflects an increase in the relative percentage of revenue from our CTG business group, which generally yields lower margins than our other business groups.

[0001104659-14-054018:mdna:41]
[same as prior period, unchanged from 0001104659-14-005587:mdna:45]

[0001104659-14-054018:mdna:42]
Selling, general and administrative expenses (“SG&A”) amounted to $209.3 million, or 3.2% of net sales, during the three-month period ended June 27, 2014, decreasing $14.3 million from $223.6 million, or 3.9% of net sales, during the three-month period ended June 28, 2013. Our SG&A expenses in dollar and percentage of revenue terms decreased in the current year period primarily as a result of certain cost reduction and rationalization measures that we undertook in the prior fiscal year.

[0001104659-14-054018:mdna:43]
Intangible amortization

[0001104659-14-054018:mdna:44]
Amortization of intangible assets decreased by $1.3 million during the three-month period ended June 27, 2014 to $6.9 million from $8.2 million for the three-month period ended June 28, 2013 primarily due to the use of the accelerated method of amortization for certain customer-related intangibles, which results in decreasing expense over time. Certain high value intangible assets were fully amortized during fiscal 2014, resulting in lower amortization expense during the three-month period ended June 27, 2014.

[0001104659-14-054018:mdna:45]
[same as prior period, unchanged from 0001104659-14-005587:mdna:47]

[0001104659-14-054018:mdna:46]
Interest and other, net was $18.6 million during the three-month period ended June 27, 2014 compared to $12.6 million during the three-month period ended June 28, 2013. The increase in interest and other, net of $6.0 million was primarily due to losses in the current period on the revaluation of the renminbi (“RMB”) denominated net asset positions of our U.S. dollar functional currency sites based in China due to the strengthening of the U.S. dollar against the RMB.

[0001104659-14-054018:mdna:47]
Refer to note 5 to the condensed consolidated financial statements for further discussion of our interest and other, net activities.

[0001104659-14-054018:mdna:48]
Other charges (income), net

[0001104659-14-054018:mdna:49]
Other charges (income), net was $44.0 million of other income, net during the three-month period ended June 27, 2014 principally as a result of the reversal of a contractual obligation with a certain customer recognized during the fourth quarter of fiscal 2014 in the amount of $55.0 million.  We executed an amendment to the customer contract during the current fiscal quarter which removed the

[0001104659-14-054018:mdna:50]
commitment.  This was partially offset by an $11.0 million loss in connection with the disposition of a certain manufacturing facility in western Europe.

[0001104659-14-054018:mdna:51]
During the three-month period ended June 28, 2013, we recognized a loss of $7.1 million relating to the exercise of a warrant to purchase shares of a certain supplier and sale of the underlying shares for total proceeds of $67.3 million.

[0001104659-14-054018:mdna:52]
[same as prior period, unchanged from 0001104659-14-005587:mdna:50]

[0001104659-14-054018:mdna:53]
Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 13, “Income Taxes,” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2014 for further discussion.

[0001104659-14-054018:mdna:54]
Our policy is to provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized.

[0001104659-14-054018:mdna:55]
The consolidated effective tax rate was 8.4% and 0.5% for three-month periods ended June 27, 2014 and June 28, 2013, respectively, and varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions, operating loss carryforwards, income tax credits, previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. We generate most of our revenues and profits from operations outside of Singapore. We currently do not anticipate a significant impact to our fiscal year 2015 effective rate as a result of changes to the mix in revenues and operating profits between taxing jurisdictions.  The effective tax rate for the three-month period ended June 27, 2014 is higher than the effective tax rate for the three-month period ended June 28, 2013 since the current quarter includes $55.0 million of other income from the reversal of the contractual obligation discussed above with no associated tax expense, and the three-month period ended June 28, 2013 included a net decrease of $8.6 million in liabilities for uncertain tax positions.

[0001104659-14-054018:mdna:56]
[same as prior period, unchanged from 0001104659-14-005587:mdna:55]

[0001104659-14-054018:mdna:57]
As of June 27, 2014, we had cash and cash equivalents of approximately $1.3 billion and bank and other borrowings of approximately $2.1 billion. We also have a $1.5 billion revolving credit facility that expires in March 2019, under which there were no borrowings outstanding as of the end of the quarter.  As of June 27, 2014, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0001104659-14-054018:mdna:58]
Cash used in operating activities was $81.2 million during the three-month period ended June 27, 2014. This resulted primarily from $173.9 million of net income for the period plus $121.5 million of non-cash charges such as depreciation, amortization, and other impairment charges, offset by $376.6 million from changes in our operating assets and liabilities, which was predominantly related to reductions in customer deposits that were received in prior periods to support increased working capital requirements in those periods.

[0001104659-14-054018:mdna:59]
[same as prior period, unchanged from 0001104659-14-005587:mdna:59]

[0001104659-14-054018:mdna:60]
|  |  | Three-Month Periods Ended |  |
|  |  | June 27, 2014 |  | March 31, 2014 |  | December 31, 2013 |  | September 27, 2013 |  | June 28, 2013 |  |
| Days in trade accounts receivable |  | 45 days |  | 42 days |  | 38 days |  | 42 days |  | 43 days |  |
| Days in inventory |  | 52 days |  | 54 days |  | 53 days |  | 53 days |  | 49 days |  |
| Days in accounts payable |  | 69 days |  | 70 days |  | 68 days |  | 71 days |  | 67 days |  |
| Cash conversion cycle |  | 28 days |  | 26 days |  | 23 days |  | 24 days |  | 25 days |  |

[0001104659-14-054018:mdna:61]
Days in trade accounts receivable was calculated as average accounts receivable for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended June 27, 2014, days in trade accounts receivable increased by 2 days to 45 days compared to the three-month periods ended June 28, 2013 largely due to the timing of invoicing customers during the current period.  Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $463.1 million, $470.9 million, $528.8 million, $558.3 million and $420.9 million for the quarters ended June 27, 2014, March 31, 2014, December 31, 2013, September 27, 2013 and June 28, 2013, respectively. Deferred purchase price receivables are recorded in other

[0001104659-14-054018:mdna:62]
current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 9 to the condensed consolidated financial statements.

[0001104659-14-054018:mdna:63]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day.  Days in inventory increased by 3 days to 52 days during the three-month period June 27, 2014, compared to the three-month period ended June 28, 2013.  The increase was primarily as a result of the positioning of raw material inventory to support increased operations driven from several programs launched in the latter part of last fiscal year.

[0001104659-14-054018:mdna:64]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. During the three-month period ended June 27, 2014, days in accounts payable increased by 2 days to 69 days compared to the three-month period ended June 28, 2013 primarily due to timing of payments and the increase in inventory purchases as explained above.

[0001104659-14-054018:mdna:65]
Our cash conversion cycle was calculated as the sum of days of inventory and days of accounts receivables outstanding less days payable outstanding.  During the three-month period ended June 27, 2014, our cash conversion cycle increased by 3 days to 28 days compared to the three-month period ended June 28, 2013, due to the factors for each of the components in the calculation discussed above.

[0001104659-14-054018:mdna:66]
Cash used by investing activities amounted to $99.9 million during the three-month period ended June 27, 2014.  This resulted primarily from $72.9 million in net capital expenditures for property and equipment to support certain programs and the purchase of rights to use certain injection molding technologies amounting to $10.0 million.

[0001104659-14-054018:mdna:67]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the three-month period ended June 27, 2014 was a utilization of $154.1 million compared to positive free cash flows of $57.2 million for the three-month period ended June 28, 2013. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities.  Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0001104659-14-054018:mdna:68]
|  |  | Three-Month Periods Ended |  |
|  |  | June 27, 2014 |  | June 28, 2013 |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | (81,169 | ) | $ | 198,576 |  |
| Purchases of property and equipment |  | (87,101 | ) | (144,737 | ) |
| Proceeds from the disposition of property and equipment |  | 14,184 |  | 3,364 |  |
| Free cash flow |  | $ | (154,086 | ) | $ | 57,203 |  |

[0001104659-14-054018:mdna:69]
Cash used in financing activities was $70.2 million during the three-month period ended June 27, 2014, which was primarily the result of cash paid for the repurchase of our ordinary shares in the amount of $105.6 million partially offset by net proceeds from bank borrowings of $25.8 million and proceeds from the issuance of our shares for option exercises amounting to $9.3 million.

[0001104659-14-054018:mdna:70]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of June 27, 2014 and March 31, 2014, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore.  Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $779.0 million as of March 31, 2014). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient

[0001104659-14-054018:mdna:71]
27

[0001104659-14-054018:mdna:72]
intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0001104659-14-054018:mdna:73]
[same as prior period, unchanged from 0001104659-14-005587:mdna:71]

[0001104659-14-054018:mdna:74]
[same as prior period, unchanged from 0001104659-14-005587:mdna:72]

[0001104659-14-054018:mdna:75]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0001104659-14-054018:mdna:76]
Our current share repurchase program was approved by the Board of Directors, on July 24, 2013, and allows us to repurchase up to 10% of the Company’s outstanding ordinary shares as of the date of the most recent the Extraordinary General Meeting held on July 29, 2013. During the three-month period ended June 27, 2014, the Company paid $105.6 million to repurchase shares at an average price of $9.69 per share.  As of June 27, 2014, we have approximately 26.5 million shares available to be repurchased under this plan.  We will request shareholder approval for the new program to repurchase our shares at our upcoming Extraordinary General Meeting to be held on August 28, 2014.

[0001104659-14-054018:mdna:77]
[same as prior period, unchanged from 0001104659-14-005587:mdna:77]

[0001104659-14-054018:mdna:78]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2014.  There have been no material changes in our contractual obligations and commitments since March 31, 2014, except for the reversal of a contractual obligation during the three-month period ended June 27, 2014 with a certain customer that was recognized during the fourth quarter of fiscal 2014 in the amount of $55.0 million discussed in note 6 to the condensed consolidated financial statements.

[0001104659-14-054018:mdna:79]
[same as prior period, unchanged from 0001104659-14-005587:mdna:82]

[0001104659-14-054018:mdna:80]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of June 27, 2014 and March 31, 2014, the fair values of our deferred purchase price receivable were approximately $463.1 million and $470.9 million, respectively. As of June 27, 2014 and March 31, 2014, the outstanding balances on receivables sold for cash were $1.2 billion and $1.1 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information see note 9 of our notes to the condensed consolidated financial statements.
