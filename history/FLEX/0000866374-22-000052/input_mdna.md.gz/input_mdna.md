# FLEX MD&A — 0000866374-22-000052


## mdna

[0000866374-22-000052:mdna:1]
[same as prior period, unchanged from 0000866374-22-000016:mdna:1]

[0000866374-22-000052:mdna:2]
[same as prior period, unchanged from 0000866374-22-000016:mdna:2]

[0000866374-22-000052:mdna:3]
[same as prior period, unchanged from 0000866374-22-000016:mdna:3]

[0000866374-22-000052:mdna:4]
We are the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we deliver advanced manufacturing solutions and operate one of the most trusted global supply chains, supporting the entire product lifecycle with fulfillment, after-market, and circular economy solutions for diverse industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. Our three operating and reportable segments are:

[0000866374-22-000052:mdna:5]
[same as prior period, unchanged from 0000866374-22-000016:mdna:5]

[0000866374-22-000052:mdna:6]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-22-000052:mdna:7]
[same as prior period, unchanged from 0000866374-22-000016:mdna:7]

[0000866374-22-000052:mdna:8]
[same as prior period, unchanged from 0000866374-22-000016:mdna:8]

[0000866374-22-000052:mdna:9]
[same as prior period, unchanged from 0000866374-22-000016:mdna:9]

[0000866374-22-000052:mdna:10]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies;

[0000866374-22-000052:mdna:11]
[same as prior period, unchanged from 0000866374-22-000016:mdna:11]

[0000866374-22-000052:mdna:12]
◦Industrial, including capital equipment, industrial devices, and renewables and grid edge.

[0000866374-22-000052:mdna:13]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

[0000866374-22-000052:mdna:14]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product lifecycle.

[0000866374-22-000052:mdna:15]
[same as prior period, unchanged from 0000866374-22-000016:mdna:14]

[0000866374-22-000052:mdna:16]
24

[0000866374-22-000052:mdna:17]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-22-000052:mdna:18]
We believe that our continued business transformation to improve our portfolio mix is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-22-000052:mdna:19]
Update on the Impact of COVID-19, Component Shortages and Logistical Constraints on our Business

[0000866374-22-000052:mdna:20]
With the second wave of the global pandemic including follow-on variants of COVID-19, there have been renewed disease control measures being taken to limit the spread including movement bans and shelter-in-place orders. Although not materially impacting our results for the first quarter of fiscal year 2023, most recently, with the lockdowns in China, we experienced temporary plant closures and/or restrictions at certain of our manufacturing facilities in China. We continue to closely monitor the situation in all the locations where we operate. Our priority remains the welfare of our employees. In addition, our end markets continue to be impacted by the global supply chain disruptions. Component shortages and logistical constraints are pervasive across the entire value chain. COVID-19 related restrictions also contributed to a declining workforce, including at ports and warehouses, as well as creating driver shortages around the world. We expect persistent waves of COVID-19 to remain a headwind into the near future. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future as we are continuing to see increasing supply constraints and costs. We continue to carefully monitor potential supply chain disruptions due to ongoing tightness in the overall component environment. Refer to “Risk Factors - The ongoing COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material.”  and “-- Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, could affect our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory. We have been and continue to be adversely affected by supply chain issues, including shortages of required electronic components.” as disclosed in Part I, “Item 1A. Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0000866374-22-000052:mdna:21]
[same as prior period, unchanged from 0000866374-22-000016:mdna:19]

[0000866374-22-000052:mdna:22]
Russian Invasion of Ukraine

[0000866374-22-000052:mdna:23]
We are monitoring and responding to the escalating conflict in Ukraine and the associated sanctions and other restrictions. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine. The full impact of the conflict on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflict and its impact on regional and global economic conditions. We will continue to monitor the conflict and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-22-000052:mdna:24]
[same as prior period, unchanged from 0000866374-22-000016:mdna:20]

[0000866374-22-000052:mdna:25]
On April 28, 2021, we announced that we confidentially submitted a draft registration statement on Form S-1 with the SEC relating to the proposed initial public offering of Nextracker's Class A common stock. The initial public offering and its timing are subject to market and other conditions and the SEC’s review process, and there can be no assurance that we will proceed with such offering or any alternative transaction. Refer to "Risk Factors - We are pursuing alternatives for our Nextracker business, including a full or partial separation of the business, through an initial public offering of Nextracker or otherwise, which may not be consummated as or when planned or at all, and may not achieve the intended benefits." as disclosed in Part I, "Item 1A. Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0000866374-22-000052:mdna:26]
On February 1, 2022, we sold Series A Preferred Units representing a 16.7% interest in Nextracker to TPG Rise for an aggregate purchase price of $500 million. The sale of the 16.7% interest in Nextracker reflects an implied value for Nextracker as of the date of the sale of $3.0 billion. See Note 7 to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022 for further information.

[0000866374-22-000052:mdna:27]
This Quarterly Report on Form 10-Q for the fiscal quarter ended July 1, 2022 does not constitute an offer to sell or a solicitation of an offer to buy securities, and shall not constitute an offer, solicitation or sale in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of that jurisdiction.

[0000866374-22-000052:mdna:28]
25

[0000866374-22-000052:mdna:29]
[same as prior period, unchanged from 0000866374-22-000016:mdna:24]

[0000866374-22-000052:mdna:30]
We are one of the world's largest providers of global supply chain solutions, with revenues of $7.3 billion for the three-month period ended July 1, 2022 and $26.0 billion in fiscal year ended March 31, 2022. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. We also provide intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-22-000052:mdna:31]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 3,315 |  |  | 45 | % |  | $ | 2,579 |  |  | 41 | % |  |  |  |  |  |  |  |  |
| Asia | 2,517 |  |  | 34 | % |  | 2,365 |  |  | 37 | % |  |  |  |  |  |  |  |  |
| Europe | 1,515 |  |  | 21 | % |  | 1,398 |  |  | 22 | % |  |  |  |  |  |  |  |  |
|  | $ | 7,347 |  |  |  |  | $ | 6,342 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 1,584 |  |  | 22 | % |  | $ | 1,531 |  |  | 24 | % |  |  |  |  |  |  |  |  |
| Mexico | 1,555 |  |  | 21 | % |  | 1,221 |  |  | 19 | % |  |  |  |  |  |  |  |  |
| U.S. | 1,216 |  |  | 17 | % |  | 876 |  |  | 14 | % |  |  |  |  |  |  |  |  |
| Malaysia | 570 |  |  | 8 | % |  | 411 |  |  | 6 | % |  |  |  |  |  |  |  |  |
| Brazil | 527 |  |  | 7 | % |  | 464 |  |  | 7 | % |  |  |  |  |  |  |  |  |
| Hungary | 286 |  |  | 4 | % |  | 352 |  |  | 6 | % |  |  |  |  |  |  |  |  |
| Other | 1,609 |  |  | 21 | % |  | 1,487 |  |  | 24 | % |  |  |  |  |  |  |  |  |
|  | $ | 7,347 |  |  |  |  | $ | 6,342 |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-22-000052:mdna:32]
|  | As of |  | As of |
| Property and equipment, net: | July 1, 2022 |  | March 31, 2022 |
|  | (In millions) |
| Mexico | $ | 643 |  |  | 30 | % |  | $ | 626 |  |  | 29 | % |
| U.S. | 350 |  |  | 16 | % |  | 354 |  |  | 17 | % |
| China | 304 |  |  | 14 | % |  | 299 |  |  | 14 | % |
| Malaysia | 123 |  |  | 6 | % |  | 110 |  |  | 5 | % |
| India | 120 |  |  | 6 | % |  | 129 |  |  | 6 | % |
| Hungary | 116 |  |  | 5 | % |  | 118 |  |  | 6 | % |
| Other | 479 |  |  | 23 | % |  | 489 |  |  | 23 | % |
|  | $ | 2,135 |  |  |  |  | $ | 2,125 |  |  |  |

[0000866374-22-000052:mdna:33]
[same as prior period, unchanged from 0000866374-22-000016:mdna:28]

[0000866374-22-000052:mdna:34]
[same as prior period, unchanged from 0000866374-22-000016:mdna:29]

[0000866374-22-000052:mdna:35]
•the impacts on our business due to component shortages, disruptions in transportation or other supply chain related constraints including as a result of the COVID-19 global pandemic;

[0000866374-22-000052:mdna:36]
•the effects of the COVID-19 global pandemic on our business and results of operations;

[0000866374-22-000052:mdna:37]
[same as prior period, unchanged from 0000866374-22-000016:mdna:32]

[0000866374-22-000052:mdna:38]
[same as prior period, unchanged from 0000866374-22-000016:mdna:33]

[0000866374-22-000052:mdna:39]
[same as prior period, unchanged from 0000866374-22-000016:mdna:34]

[0000866374-22-000052:mdna:40]
[same as prior period, unchanged from 0000866374-22-000016:mdna:35]

[0000866374-22-000052:mdna:41]
•the effects that current credit and market conditions (including as a result of the COVID-19 global pandemic and the ongoing conflict between Russia and Ukraine) could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-22-000052:mdna:42]
•the effects on our business due to certain customers' products having short product lifecycles;

[0000866374-22-000052:mdna:43]
•our customers' ability to cancel or delay orders or change production quantities;

[0000866374-22-000052:mdna:44]
•our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements;

[0000866374-22-000052:mdna:45]
[same as prior period, unchanged from 0000866374-22-000016:mdna:40]

[0000866374-22-000052:mdna:46]
[same as prior period, unchanged from 0000866374-22-000016:mdna:41]

[0000866374-22-000052:mdna:47]
[same as prior period, unchanged from 0000866374-22-000016:mdna:42]

[0000866374-22-000052:mdna:48]
[same as prior period, unchanged from 0000866374-22-000016:mdna:43]

[0000866374-22-000052:mdna:49]
We are also subject to other risks as outlined in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0000866374-22-000052:mdna:50]
[same as prior period, unchanged from 0000866374-22-000016:mdna:45]

[0000866374-22-000052:mdna:51]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to the COVID-19 pandemic and the ongoing conflict between Russia and Ukraine, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to COVID-19 and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from those estimates and assumptions.

[0000866374-22-000052:mdna:52]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0000866374-22-000052:mdna:53]
[same as prior period, unchanged from 0000866374-22-000016:mdna:48]

[0000866374-22-000052:mdna:54]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0000866374-22-000052:mdna:55]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of sales | 92.7 |  |  | 92.6 |  |  |  |  |  |
| Gross profit | 7.3 |  |  | 7.4 |  |  |  |  |  |
| Selling, general and administrative expenses | 3.3 |  |  | 3.2 |  |  |  |  |  |
| Intangible amortization | 0.3 |  |  | 0.2 |  |  |  |  |  |
| Operating income | 3.7 |  |  | 4.0 |  |  |  |  |  |
| Interest and other, net | 0.5 |  |  | 0.3 |  |  |  |  |  |
| Income before income taxes | 3.2 |  |  | 3.7 |  |  |  |  |  |
| Provision for income taxes | 0.5 |  |  | 0.4 |  |  |  |  |  |
| Net income | 2.7 | % |  | 3.3 | % |  |  |  |  |
| Net income attributable to redeemable noncontrolling interest | 0.1 |  |  | 0.0 |  |  |  |  |  |
| Net income attributable to Flex Ltd. | 2.6 | % |  | 3.3 | % |  |  |  |  |

[0000866374-22-000052:mdna:56]
[same as prior period, unchanged from 0000866374-22-000016:mdna:51]

[0000866374-22-000052:mdna:57]
[same as prior period, unchanged from 0000866374-22-000016:mdna:52]

[0000866374-22-000052:mdna:58]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,991 |  |  | 54 | % |  | $ | 3,432 |  |  | 54 | % |  |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 2,969 |  |  | 41 | % |  | 2,582 |  |  | 41 | % |  |  |  |  |  |  |  |  |
| Nextracker | 395 |  |  | 5 | % |  | 341 |  |  | 5 | % |  |  |  |  |  |  |  |  |
| Intersegment eliminations | (8) |  |  | — | % |  | (13) |  |  | — | % |  |  |  |  |  |  |  |  |
|  | $ | 7,347 |  |  |  |  | $ | 6,342 |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-22-000052:mdna:59]
Net sales during the three-month period ended July 1, 2022 totaled $7.3 billion, representing an increase of approximately $1.0 billion, or 16% from $6.3 billion during the three-month period ended July 2, 2021. Net sales for our FAS segment increased approximately $0.6 billion, or 16% from the three-month period ended July 2, 2021, primarily driven by strong year-over-year growth in our CEC business and a low double-digit year-over-year increase in our Lifestyle business due to new ramps, customer expansion, continued recoveries in consumer spending along with some effect from inflation pass-through while overcoming challenges from supply constraints. These increases in FAS were offset by a mid-teen year-over-year decrease in our Consumer Device business due to a planned project completion in fiscal year ended March 31, 2022. Net sales for our FRS segment increased approximately $0.4 billion, or 15% from the three-month period ended July 2, 2021, primarily driven by a strong year-over-year increase in our Industrial business and a mid-teen year-over-year increase in our Automotive business due to strong customer demand and ramps across various end markets coupled with incremental revenues from our Anord Mardix acquisition and the recovery of inflationary costs, despite continued supply constraints. Net sales for our Nextracker segment increased approximately $0.1 billion, or 16% from the three-month period ended July 2, 2021, primarily driven by increased billings directly associated with higher freight and logistics costs.

[0000866374-22-000052:mdna:60]
Net sales increased across all regions with a $0.7 billion increase to $3.3 billion in the Americas, a $0.2 billion increase to $2.5 billion in Asia, and a $0.1 billion increase to $1.5 billion in Europe.

[0000866374-22-000052:mdna:61]
Our ten largest customers during the three-month periods ended July 1, 2022 and July 2, 2021 accounted for approximately 35% of net sales, respectively. No customer accounted for more than 10% of net sales during the three-month periods ended July 1, 2022 or July 2, 2021.

[0000866374-22-000052:mdna:62]
[same as prior period, unchanged from 0000866374-22-000016:mdna:58]

[0000866374-22-000052:mdna:63]
[same as prior period, unchanged from 0000866374-22-000016:mdna:59]

[0000866374-22-000052:mdna:64]
Cost of sales during the three-month period ended July 1, 2022 totaled $6.8 billion, representing an increase of approximately $0.9 billion, or 16% from $5.9 billion during the three-month period ended July 2, 2021. The higher cost of sales for the three-month period ended July 1, 2022 was primarily driven by increased consolidated sales of $1.0 billion. Cost of sales in FAS for the three-month period ended July 1, 2022 increased approximately $0.5 billion, or 16% from the three-month period ended July 2, 2021, which is aligned with the overall 16% increase in FAS revenue during the same period primarily as a result of higher revenue in our CEC and Lifestyle businesses. Cost of sales in FRS for the three-month period ended July 1, 2022 increased $0.4 billion, or 16% from the three-month period ended July 2, 2021, which is relatively in line with the overall 15% increase in FRS revenue during the same period, primarily as a result of higher revenue in our Industrial and Automotive businesses. Cost of sales in our Nextracker segment for the three-month period ended July 1, 2022 increased approximately $45 million, or 15% from the three-month period ended July 2, 2021, which is aligned with the 16% increase in Nextracker revenue during the same period.

[0000866374-22-000052:mdna:65]
[same as prior period, unchanged from 0000866374-22-000016:mdna:62]

[0000866374-22-000052:mdna:66]
Gross profit is affected by a fluctuation in cost of sales elements as outlined above and further by a number of factors, including product life cycles, unit volumes, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-22-000052:mdna:67]
Gross profit during the three-month period ended July 1, 2022 increased $64 million to $0.5 billion, or 7.3% of net sales, from $0.5 billion, or 7.4% of net sales, during the three-month period ended July 2, 2021. Gross margin declined 10 basis points during the current period primarily due to the pass-through effect of inflationary cost recoveries in the three-month period ended July 1, 2022 along with continued pressure on margin from component shortages.

[0000866374-22-000052:mdna:68]
[same as prior period, unchanged from 0000866374-22-000016:mdna:66]

[0000866374-22-000052:mdna:69]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, and legal and other. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-22-000052:mdna:70]
The following table sets forth segment income and margins. Segment margins in the table below may not recalculate exactly due to rounding and are calculated based on unrounded numbers.

[0000866374-22-000052:mdna:71]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 171 |  |  | 4.3 | % |  | $ | 137 |  |  | 4.0 | % |  |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 147 |  |  | 5.0 | % |  | 144 |  |  | 5.6 | % |  |  |  |  |  |  |  |  |
| Nextracker | 30 |  |  | 7.6 | % |  | 25 |  |  | 7.4 | % |  |  |  |  |  |  |  |  |

[0000866374-22-000052:mdna:72]
FAS segment margin increased 30 basis points, to 4.3% for the three-month period ended July 1, 2022, from 4.0% for the three-month period ended July 2, 2021. The margin increase was driven by strong execution against new project ramps and product mix, partially offset by the elevated costs due to component shortages and logistics constraints and the effect of certain inflation pass-through recoveries.

[0000866374-22-000052:mdna:73]
29

[0000866374-22-000052:mdna:74]
FRS segment margin decreased approximately 60 basis points, to 5.0% for the three-month period ended July 1, 2022, from 5.6% for the three-month period ended July 2, 2021. The margin decrease in FRS was primarily driven by component shortages related production disruptions in our Automotive business, as well as inflationary cost pressures impacting our Automotive and Health Solutions businesses during the three-month period ended July 1, 2022.

[0000866374-22-000052:mdna:75]
Nextracker segment margin increased approximately 20 basis points, to 7.6% for the three-month period ended July 1, 2022, from 7.4% for the three-month period ended July 2, 2021. The margin increase was driven by improved cost controls and better cost absorption with increased revenue.

[0000866374-22-000052:mdna:76]
[same as prior period, unchanged from 0000866374-22-000016:mdna:73]

[0000866374-22-000052:mdna:77]
Selling, general and administrative expenses (“SG&A”) was $0.2 billion, or 3.3% of net sales, during the three-month period ended July 1, 2022, increasing $40 million from $0.2 billion, or 3.2% of net sales, during the three-month period ended July 2, 2021, which reflects our enhanced cost control efforts to support higher revenue growth while keeping our SG&A expenses relatively flat.

[0000866374-22-000052:mdna:78]
[same as prior period, unchanged from 0000866374-22-000016:mdna:75]

[0000866374-22-000052:mdna:79]
Amortization of intangible assets increased to $22 million during the three-month period ended July 1, 2022, from $15 million for the three-month period ended July 2, 2021, primarily due to amortization expense related to new intangible assets from the Anord Mardix acquisition completed in December 2021.

[0000866374-22-000052:mdna:80]
[same as prior period, unchanged from 0000866374-22-000016:mdna:77]

[0000866374-22-000052:mdna:81]
Interest and other, net was $40 million during the three-month period ended July 1, 2022 compared to $22 million during the three-month period ended July 2, 2021, primarily driven by a lower gain from equity in earnings recognized for certain of our non-core equity method investments, coupled with higher interest expense compared to the prior year period.

[0000866374-22-000052:mdna:82]
[same as prior period, unchanged from 0000866374-22-000016:mdna:80]

[0000866374-22-000052:mdna:83]
Certain of our subsidiaries, at various times, have been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 15, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022 for further discussion.

[0000866374-22-000052:mdna:84]
The consolidated effective tax rate was 16% and 12% for the three-month periods ended July 1, 2022 and July 2, 2021, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, the Netherlands and Israel. The effective tax rate for the three-month period ended July 1, 2022 is higher than the effective tax rate for the three-month period ended July 2, 2021, due to the changing jurisdictional mix of income and the negative foreign exchange impacts on material tax balances.

[0000866374-22-000052:mdna:85]
[same as prior period, unchanged from 0000866374-22-000016:mdna:84]

[0000866374-22-000052:mdna:86]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of July 1, 2022, we had cash and cash equivalents of approximately $2.6 billion and bank and other borrowings of approximately $4.1 billion. As of July 1, 2022, we had a $2.0 billion revolving credit facility that was due to mature in January 2026, under which we had no borrowings outstanding as of July 1, 2022. As of July 1, 2022, we were in compliance with the covenants under all of our credit facilities and indentures. On July 19, 2022, we entered into a new $2.5 billion credit agreement (the "New Credit Facility") which matures in July 2027 and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans and a sub-limit of $175 million available for the issuance of letters of credit. The New Credit Facility replaced the previous $2.0 billion credit facility noted above. Under the New Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

[0000866374-22-000052:mdna:87]
30

[0000866374-22-000052:mdna:88]
Cash provided by operating activities was $38 million during the three-month period ended July 1, 2022, primarily driven by $0.2 billion of net income for the period plus $0.2 billion of non-cash charges such as depreciation, amortization, and stock-based compensation offset by changes in net working capital as discussed below.

[0000866374-22-000052:mdna:89]
We believe net working capital ("NWC") and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, plus inventories and contract assets, less accounts payable. Net working capital increased $0.6 billion to $4.8 billion as of July 1, 2022, from $4.2 billion as of March 31, 2022. This increase is primarily driven by a $0.7 billion increase in inventories due to strong demand, coupled with continued component shortages, clear-to build constraints and logistics challenges driving up buffer stock and inventory pricing, and a $0.4 billion increase in net receivables, offset by a $0.4 billion increase in accounts payable due to increased inventory purchases. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended July 1, 2022, increased to 16.5% from 15.4% of annualized net sales for the quarter ended March 31, 2022 due to component shortages and logistics constraints. We continue to experience component shortages in the supply chain and logistical constraints, and although we are actively managing these impacts, we expect continued working capital pressure in the near future. We expect it will take additional time to adequately drive down our inventory levels to align with the current demand environment. We are proactively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative resetting our load planning. In addition, we are pursuing alternative resources using inclusive hybrid solutions to minimize transit times and implementing operational efficiencies. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future as we are continuing to see increasing supply constraints and costs. We are working diligently with our partners to secure needed parts and fulfill demand. In addition, to the extent possible, we have collaborated with our customers for working capital advances to offset the required investment in inventory. Advances from customers as of July 1, 2022 increased $0.4 billion to $1.8 billion from $1.4 billion as of March 31, 2022.

[0000866374-22-000052:mdna:90]
Cash used in investing activities was $0.1 billion during the three-month period ended July 1, 2022. This was primarily driven by $0.1 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Automotive, Lifestyle, Health Solutions, and Industrial businesses.

[0000866374-22-000052:mdna:91]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment in order to present adjusted cash flows on a consistent basis for investor transparency. Our adjusted free cash flows for the three-month period ended July 1, 2022 and July 2, 2021 was an outflow of $0.1 billion and an inflow of $0.2 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-22-000052:mdna:92]
|  | Three-Month Periods Ended |
|  | July 1, 2022 |  | July 2, 2021 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 38 |  |  | $ | 334 |  |
| Purchases of property and equipment | (107) |  |  | (118) |  |
| Proceeds from the disposition of property and equipment | 16 |  |  | 3 |  |
| Adjusted free cash flow | $ | (53) |  |  | $ | 219 |  |

[0000866374-22-000052:mdna:93]
Cash used by financing activities was $0.2 billion during the three-month period ended July 1, 2022, which was primarily driven by $0.2 billion of cash paid for the repurchase of our ordinary shares.

[0000866374-22-000052:mdna:94]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of July 1, 2022 and March 31, 2022, approximately 32% and 34%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial

[0000866374-22-000052:mdna:95]
statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2022). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-22-000052:mdna:96]
[same as prior period, unchanged from 0000866374-22-000016:mdna:94]

[0000866374-22-000052:mdna:97]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs amounted to approximately $0.4 billion and $0.3 billion for the three-month periods ended July 1, 2022 and July 2, 2021, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-22-000052:mdna:98]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to a commercial paper program, and a revolving sale and repurchase of subordinated notes established under the securitization facility, under which there were no borrowings outstanding as of July 1, 2022.

[0000866374-22-000052:mdna:99]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also have the ability to sell a designated pool of trade receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed.

[0000866374-22-000052:mdna:100]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-22-000052:mdna:101]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 4, 2021. During the three-month period ended July 1, 2022, we paid $0.2 billion to repurchase shares under the current and prior repurchase plans at an average price of $15.99 per share. As of July 1, 2022, shares in the aggregate amount of $0.3 billion were available to be repurchased under the current plan.

[0000866374-22-000052:mdna:102]
[same as prior period, unchanged from 0000866374-22-000016:mdna:101]

[0000866374-22-000052:mdna:103]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2022.

[0000866374-22-000052:mdna:104]
There were no material changes in our contractual obligations and commitments as of July 1, 2022.

[0000866374-22-000052:mdna:105]
On July 19, 2022, we entered into a new $2.5 billion credit facility which matures in July 2027, replacing our previous $2.0 billion credit facility.
