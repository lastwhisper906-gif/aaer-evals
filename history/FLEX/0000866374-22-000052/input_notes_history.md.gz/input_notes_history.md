# FLEX note change history — 0000866374-22-000016 → 0000866374-22-000052


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000866374-22-000052:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.
  (was, 2022-02-04, similarity 0.8589):
[0000866374-22-000016:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or

- changed (2022-07-29):
[0000866374-22-000052:note_history:2]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.
  (was, 2022-02-04, similarity 0.7955):
[0000866374-22-000016:note_history:2]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

- changed (2022-07-29):
[0000866374-22-000052:note_history:3]
From time to time, the Company enters into intellectual property licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.
  (was, 2022-02-04, similarity 0.9921):
[0000866374-22-000016:note_history:3]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

- changed (2022-07-29):
[0000866374-22-000052:note_history:4]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 374 million Brazilian reals (approximately USD $72 million based on the exchange rate as of July 1, 2022). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 61 million Brazilian reals or USD $12 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 34 million Brazilian reals (approximately USD $7 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.
  (was, 2022-02-04, similarity 0.9951):
[0000866374-22-000016:note_history:4]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 373.7 million Brazilian reals (approximately USD $65.8 million based on the exchange rate as of December 31, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 60.6 million Brazilian reals or USD $10.7 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 33.9 million Brazilian reals (approximately USD $6.0 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

- changed (2022-07-29):
[0000866374-22-000052:note_history:5]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018.
  (was, 2022-02-04, similarity 0.6712):
[0000866374-22-000016:note_history:5]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $163.9 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

- added (2022-07-29):
[0000866374-22-000052:note_history:6]
The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

- changed (2022-07-29):
[0000866374-22-000052:note_history:7]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.
  (was, 2022-02-04, similarity 0.9836):
[0000866374-22-000016:note_history:7]
As the final resolutions of the above outstanding tax items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2022-07-29):
[0000866374-22-000016:note_history:8]
unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- removed (2022-07-29):
[0000866374-22-000016:note_history:9]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff, National Elevator Industry Pension Fund, and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. On May 19, 2021, lead plaintiff filed its opening appeal brief, on July 19, 2021, defendants filed their answering brief, and on September 8, 2021, lead plaintiff filed its reply brief. The Court of Appeals heard oral argument on December 8, 2021. On December 21, 2021, the Court of Appeals affirmed the dismissal with prejudice of the case. The Court of Appeals’ decision took effect on January 12, 2022.

- removed (2022-07-29):
[0000866374-22-000016:note_history:10]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- removed (2022-07-29):
[0000866374-22-000016:note_history:11]
A different foreign Tax Authority had issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagreed with the Tax Authority’s assertion but agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount was accrued for during the fourth quarter of fiscal year 2021 and has been fully paid during the current quarter with no additional amounts owed.

- removed (2022-07-29):
[0000866374-22-000016:note_history:12]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for "Credit Habilitation" with the tax authorities in June 2021 to request additional PIS/COFINS credit in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of the Company's credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remained uncertainty regarding the Company’s ability to recognize these credits. The Company considered the recognition of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and did not record a gain for such credits in the three-month period ended July 2, 2021 as it had not resolved all contingencies to conclude a realized or realizable amount. In September 2021, the Credit Habilitation request was approved by the tax authorities and the Company recognized a gain of 809.6 million Brazilian reals (approximately USD $149.3 million based on the exchange rate as of October 1, 2021) included in interest and other, net in the condensed consolidated statements of operations for the three and six-month periods ended October 1, 2021. The total gain recorded included credits from February 2003 to September 2021, net of additional taxes, as the Credit Habilitation received covering the period from February 2003 to December 2019 resolved any uncertainty regarding the Company's ability to claim such credits. This gain is non-cash and can only be used to offset certain current and future tax

- removed (2022-07-29):
[0000866374-22-000016:note_history:13]
obligations. During the three-month period ended December 31, 2021, the Company updated its plan regarding the utilization of these credits and expects to utilize the remaining 598.8 million Brazilian reals (approximately USD $105.4 million based on the exchange rate as of December 31, 2021) of credits in the next twelve months based on the latest tax strategy. Accordingly the remaining balance is included in other current assets as of December 31, 2021.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-07-29):
[0000866374-22-000052:note_history:14]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers advanced manufacturing solutions and operates one of the most trusted global supply chains, supporting the entire product lifecycle with fulfillment, after-market, and circular economy solutions for diverse industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. Flex's three operating and reportable segments are:

- changed (2022-07-29):
[0000866374-22-000052:note_history:15]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure;
  (was, 2022-02-04, similarity 0.9688):
[0000866374-22-000016:note_history:15]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure;

- changed (2022-07-29):
[0000866374-22-000052:note_history:16]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies;
  (was, 2022-02-04, similarity 0.8725):
[0000866374-22-000016:note_history:16]
◦Automotive, including autonomous, connectivity, electrification, and smart technologies;

- changed (2022-07-29):
[0000866374-22-000052:note_history:17]
◦Industrial, including capital equipment, industrial devices, and renewables and grid edge.
  (was, 2022-02-04, similarity 0.7401):
[0000866374-22-000016:note_history:17]
◦Industrial, including capital equipment, industrial devices, renewable including our Nextracker business, grid edge, and power systems.

- added (2022-07-29):
[0000866374-22-000052:note_history:18]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

- changed (2022-07-29):
[0000866374-22-000052:note_history:19]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers). The Company also provides intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world.
  (was, 2022-02-04, similarity 0.8846):
[0000866374-22-000016:note_history:19]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers).

- added (2022-07-29):
[0000866374-22-000052:note_history:20]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2022 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended July 1, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

- changed (2022-07-29):
[0000866374-22-000052:note_history:21]
The first quarters for fiscal years 2023 and 2022 ended on July 1, 2022, which is comprised of 92 days in the period, and July 2, 2021, which is comprised of 93 days in the period, respectively.
  (was, 2022-02-04, similarity 0.6395):
[0000866374-22-000016:note_history:21]
quarters for fiscal years 2022 and 2021 ended on December 31 of each year, which are comprised of 91 and 97 days, respectively.

- changed (2022-07-29):
[0000866374-22-000052:note_history:22]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. In all cases other than the redeemable noncontrolling interest in Nextracker, the associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations
  (was, 2022-02-04, similarity 0.6934):
[0000866374-22-000016:note_history:22]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

- added (2022-07-29):
[0000866374-22-000052:note_history:23]
for all periods presented, and is classified as a component of Interest and other, net, in the condensed consolidated statements of operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the condensed consolidated statements of operations.

- changed (2022-07-29):
[0000866374-22-000052:note_history:24]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic and geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the COVID-19 pandemic and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2022-02-04, similarity 0.8565):
[0000866374-22-000016:note_history:24]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- changed (2022-07-29):
[0000866374-22-000052:note_history:25]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company adopted the guidance during the first quarter of fiscal year 2023 with an immaterial impact on its condensed consolidated financial statements.
  (was, 2022-02-04, similarity 0.7955):
[0000866374-22-000016:note_history:25]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2023.

- removed (2022-07-29):
[0000866374-22-000016:note_history:26]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In order to drive efficiency and productivity, the Company is organized around two focused and complementary delivery models, which also represent its operating and reportable segments:

- removed (2022-07-29):
[0000866374-22-000016:note_history:27]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2021 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation. Beginning in the second quarter of fiscal year 2022, the Company elected to include operating income as a subtotal in the condensed consolidated statements of operations. In addition, deferred revenue and customer working capital advances, previously included within other current liabilities, have been separately presented as deferred revenue and customer working capital advances in the current liabilities section of the condensed consolidated balance sheets. Further, certain unbilled receivables previously presented as part of accounts receivable, net of allowance for doubtful accounts are now being presented as contract assets on the condensed consolidated balance sheets as billing is to occur subsequent to revenue recognition and is conditional upon other than the passage of time. The Company reclassified $146.8 million of unbilled receivables from account receivable, net of allowance for doubtful accounts to contract assets for the period ended March 31, 2021 in order to align with the current year presentation. These presentation changes were applied to all periods presented in the condensed consolidated statements of operations and balance sheets. The foregoing changes in presentation had no impact on the Company's results of operations or cash flows.

- removed (2022-07-29):
[0000866374-22-000016:note_history:28]
The first quarters for fiscal years 2022 and 2021 ended on July 2, 2021, which is comprised of 93 days in the period, and June 26, 2020, which is comprised of 87 days in the period, respectively. The second quarters for fiscal years 2022 and 2021 ended on October 1, 2021 and September 25, 2020, which are comprised of 91 days in both periods. The Company's third

- removed (2022-07-29):
[0000866374-22-000016:note_history:29]
In October 2021, the FASB issued ASU 2021-08 "Business Combinations (Topic 805) — Accounting for Contract Assets and Contract Liabilities From Contracts With Customers", which requires an acquirer to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with FASB Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers. The guidance is effective prospectively for the Company beginning in the first quarter of fiscal year 2024 with early adoption permitted. The Company early adopted the guidance during the third quarter of fiscal year 2022 with an immaterial impact to its condensed consolidated financial statements.

- removed (2022-07-29):
[0000866374-22-000016:note_history:30]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

- removed (2022-07-29):
[0000866374-22-000016:note_history:31]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force", which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

- removed (2022-07-29):
[0000866374-22-000016:note_history:32]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its condensed consolidated financial statements.

- removed (2022-07-29):
[0000866374-22-000016:note_history:33]
Recently Issued Accounting Pronouncements

- removed (2022-07-29):
[0000866374-22-000016:note_history:34]
In November 2021, the FASB issued ASU 2021-10 "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance," which aims to provide increased transparency by requiring business entities to disclose information about certain types of government assistance they receive in the notes to the annual financial statements. The guidance is effective for the Company beginning in fiscal year 2023 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in fiscal year 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000866374-22-000052:note_history:35]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of July 1, 2022 are as follows:
  (was, 2022-02-04, similarity 0.9412):
[0000866374-22-000016:note_history:35]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2021 are as follows:

- added (2022-07-29):
[0000866374-22-000052:note_history:36]
|  | As of July 1, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.430% | 245 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 689 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 689 |  |  | 690 |  |
| Euro Term Loans | 367 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 266 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (17) |  |  | (18) |  |
|  | 4,075 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (946) |  |  | (949) |  |
| Non-current portion | $ | 3,129 |  |  | $ | 3,248 |  |

- changed (2022-07-29):
[0000866374-22-000052:note_history:37]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.0% as of July 1, 2022 and March 31, 2022.
  (was, 2022-02-04, similarity 0.9464):
[0000866374-22-000016:note_history:37]
The weighted-average interest rate for the Company's long-term debt was 3.5% and 4.3% as of December 31, 2021 and March 31, 2021.

- changed (2022-07-29):
[0000866374-22-000052:note_history:38]
Scheduled repayments of the Company's bank borrowings and long-term debt as of July 1, 2022 are as follows:
  (was, 2022-02-04, similarity 0.9429):
[0000866374-22-000016:note_history:38]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2021 are as follows:

- changed (2022-07-29):
[0000866374-22-000052:note_history:39]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 893 |  |
| 2024 |  | 53 |  |
| 2025 |  | 245 |  |
| 2026 |  | 1,288 |  |
| 2027 |  | — |  |
| Thereafter |  | 1,613 |  |
| Total |  | $ | 4,092 |  |
  (was, 2022-02-04, similarity 0.9946):
[0000866374-22-000016:note_history:39]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2022 (1) |  | $ | 246 |  |
| 2023 |  | 928 |  |
| 2024 |  | 53 |  |
| 2025 |  | 292 |  |
| 2026 |  | 1,289 |  |
| Thereafter |  | 1,657 |  |
| Total |  | $ | 4,465 |  |

- changed (2022-07-29):
[0000866374-22-000052:note_history:40]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2023.
  (was, 2022-02-04, similarity 0.963):
[0000866374-22-000016:note_history:40]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2022.

- removed (2022-07-29):
[0000866374-22-000016:note_history:41]
|  | As of December 31, 2021 |  | As of March 31, 2021 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 292 |  |  | 305 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 691 |  |  | 694 |  |
| 4.875% Notes due June 2029 | 660 |  |  | 661 |  |
| 4.875% Notes due May 2030 | 691 |  |  | 694 |  |
| 3.600% HUF Bonds due December 2031 | 306 |  |  | — |  |
| India Facilities | 117 |  |  | 133 |  |
| Other | 610 |  |  | 219 |  |
| Debt issuance costs | (19) |  |  | (21) |  |
|  | 4,446 |  |  | 3,783 |  |
| Current portion | (648) |  |  | (268) |  |
| Non-current portion | $ | 3,798 |  |  | $ | 3,515 |  |

- removed (2022-07-29):
[0000866374-22-000016:note_history:42]
HUF Bonds due December 2031

- removed (2022-07-29):
[0000866374-22-000016:note_history:43]
In December 2021, the Company issued HUF 100 billion (approximately $306.3 million as of December 31, 2021) in aggregate principal amount of bonds under the National Bank of Hungary’s Bond Funding for Growth Scheme. The bonds mature in December 2031 and amortize in an amount equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity. The outstanding principal amount of the bonds bear interest at 3.60% per annum. Interest is due and payable annually in arrears commencing on December 6, 2022. The proceeds of the bonds were used for general corporate purposes. As the bonds are denominated in Hungarian forint, the debt balance is remeasured to USD at the end of each reporting period. Foreign currency swap contracts have been entered into with respect to this Hungarian forint denominated liability.

- removed (2022-07-29):
[0000866374-22-000016:note_history:44]
The bonds are unsecured and unsubordinated obligations of the Company and rank equally with all of the Company’s other existing and future unsecured and unsubordinated obligations.

- removed (2022-07-29):
[0000866374-22-000016:note_history:45]
The bonds contain a customary negative pledge covenant restricting the ability of the Company to incur liens to secure indebtedness without ratably and equally securing the bonds. This covenant is subject to a number of exceptions and limitations. The bonds also provide for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company. Except in limited circumstances resulting from adverse changes in applicable tax laws, the bonds are not voluntarily redeemable. The Company is in the process of listing the bonds for trading on the XBond multilateral trading facility operated by the Budapest Stock Exchange.

- removed (2022-07-29):
[0000866374-22-000016:note_history:46]
Other Borrowings

- removed (2022-07-29):
[0000866374-22-000016:note_history:47]
Euro Term Loan due December 2022

- removed (2022-07-29):
[0000866374-22-000016:note_history:48]
In December 2021, the Company borrowed €350 million (approximately $397.3 million as of December 31, 2021), under a 1-year term-loan agreement. Of this amount, €250 million is due December 9, 2022 and €100 million is due December 30, 2022. The proceeds of the term loan will be used to refinance certain other outstanding debt and for other general corporate purposes. Borrowings under this term loan bear interest at (0.18)% per annum, which is payable in full at maturity. The term loan is repayable upon maturity, and the borrowings have been included as bank borrowings and current portion of long-term debt under the condensed consolidated balance sheet.

- removed (2022-07-29):
[0000866374-22-000016:note_history:49]
The term loan is unsecured. The term loan agreement contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA, and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2021, the Company was in compliance with the covenants under the term loan agreement.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000866374-22-000052:note_history:50]
|  | As of July 1, 2022 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 504 |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.430% | 245 |  |  | 245 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 601 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 689 |  |  | 659 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 659 |  |  | 636 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 689 |  |  | 659 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | 367 |  |  | 367 |  |  | 389 |  |  | 389 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 266 |  |  | 266 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | 79 |  |  | 79 |  |  | 84 |  |  | 84 |  |  | Level 2 |
  (was, 2022-02-04, similarity 0.9779):
[0000866374-22-000016:note_history:50]
|  | As of December 31, 2021 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 521 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 292 |  |  | 292 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 651 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 691 |  |  | 738 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 660 |  |  | 747 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 691 |  |  | 785 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 560 |  |  | 560 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 306 |  |  | 306 |  |  | — |  |  | — |  |  | Level 2 |
| India Facilities | 117 |  |  | 117 |  |  | 133 |  |  | 133 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000866374-22-000052:note_history:51]
Bank borrowings and long-term debt as of July 1, 2022 are as follows:
  (was, 2022-02-04, similarity 0.9104):
[0000866374-22-000016:note_history:51]
Bank borrowings and long-term debt as of December 31, 2021 are as follows:

- added (2022-07-29):
[0000866374-22-000052:note_history:52]
|  | As of July 1, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.430% | 245 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 689 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 689 |  |  | 690 |  |
| Euro Term Loans | 367 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 266 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (17) |  |  | (18) |  |
|  | 4,075 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (946) |  |  | (949) |  |
| Non-current portion | $ | 3,129 |  |  | $ | 3,248 |  |

- removed (2022-07-29):
[0000866374-22-000016:note_history:53]
|  | As of December 31, 2021 |  | As of March 31, 2021 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 292 |  |  | 305 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 691 |  |  | 694 |  |
| 4.875% Notes due June 2029 | 660 |  |  | 661 |  |
| 4.875% Notes due May 2030 | 691 |  |  | 694 |  |
| 3.600% HUF Bonds due December 2031 | 306 |  |  | — |  |
| India Facilities | 117 |  |  | 133 |  |
| Other | 610 |  |  | 219 |  |
| Debt issuance costs | (19) |  |  | (21) |  |
|  | 4,446 |  |  | 3,783 |  |
| Current portion | (648) |  |  | (268) |  |
| Non-current portion | $ | 3,798 |  |  | $ | 3,515 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000866374-22-000052:note_history:54]
Scheduled repayments of the Company's bank borrowings and long-term debt as of July 1, 2022 are as follows:
  (was, 2022-02-04, similarity 0.9429):
[0000866374-22-000016:note_history:54]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2021 are as follows:

- changed (2022-07-29):
[0000866374-22-000052:note_history:55]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 893 |  |
| 2024 |  | 53 |  |
| 2025 |  | 245 |  |
| 2026 |  | 1,288 |  |
| 2027 |  | — |  |
| Thereafter |  | 1,613 |  |
| Total |  | $ | 4,092 |  |
  (was, 2022-02-04, similarity 0.9946):
[0000866374-22-000016:note_history:55]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2022 (1) |  | $ | 246 |  |
| 2023 |  | 928 |  |
| 2024 |  | 53 |  |
| 2025 |  | 292 |  |
| 2026 |  | 1,289 |  |
| Thereafter |  | 1,657 |  |
| Total |  | $ | 4,465 |  |

- changed (2022-07-29):
[0000866374-22-000052:note_history:56]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2023.
  (was, 2022-02-04, similarity 0.963):
[0000866374-22-000016:note_history:56]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2022.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-07-29):
[0000866374-22-000052:note_history:57]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended July 1, 2022 and July 2, 2021, respectively. Historical information for the first quarter of fiscal year ended March 31, 2022 has been recast to reflect the new operating and reportable segments in the table below.

- added (2022-07-29):
[0000866374-22-000052:note_history:58]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,779 |  |  | $ | 3,248 |  |  |  |  |  |
| Over time | 212 |  |  | 184 |  |  |  |  |  |
| Total | 3,991 |  |  | 3,432 |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,790 |  |  | 2,407 |  |  |  |  |  |
| Over time | 179 |  |  | 175 |  |  |  |  |  |
| Total | 2,969 |  |  | 2,582 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 23 |  |  | 9 |  |  |  |  |  |
| Over time | 372 |  |  | 332 |  |  |  |  |  |
| Total | 395 |  |  | 341 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (8) |  |  | (13) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (8) |  |  | (13) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,584 |  |  | 5,651 |  |  |  |  |  |
| Over time | 763 |  |  | 691 |  |  |  |  |  |
| Total | $ | 7,347 |  |  | $ | 6,342 |  |  |  |  |  |

- removed (2022-07-29):
[0000866374-22-000016:note_history:59]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2021 and December 31, 2020, respectively.

- removed (2022-07-29):
[0000866374-22-000016:note_history:60]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,389 |  |  | $ | 3,544 |  |  | $ | 9,887 |  |  | $ | 8,813 |  |
| Over time | 192 |  |  | 290 |  |  | 563 |  |  | 1,250 |  |
| Total | 3,581 |  |  | 3,834 |  |  | 10,450 |  |  | 10,063 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,559 |  |  | 2,189 |  |  | 7,270 |  |  | 5,292 |  |
| Over time | 479 |  |  | 697 |  |  | 1,470 |  |  | 2,503 |  |
| Total | 3,038 |  |  | 2,886 |  |  | 8,740 |  |  | 7,795 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,948 |  |  | 5,733 |  |  | 17,157 |  |  | 14,105 |  |
| Over time | 671 |  |  | 987 |  |  | 2,033 |  |  | 3,753 |  |
| Total | $ | 6,619 |  |  | $ | 6,720 |  |  | $ | 19,190 |  |  | $ | 17,858 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-07-29):
[0000866374-22-000052:note_history:61]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and

- changed (2022-07-29):
[0000866374-22-000052:note_history:62]
can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.
  (was, 2022-02-04, similarity 0.8231):
[0000866374-22-000016:note_history:62]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

- changed (2022-07-29):
[0000866374-22-000052:note_history:63]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.
  (was, 2022-02-04, similarity 0.7857):
[0000866374-22-000016:note_history:63]
required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- changed (2022-07-29):
[0000866374-22-000052:note_history:64]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the condensed consolidated balance sheet and disclosed as part of customer-related accruals in note 2.
  (was, 2022-02-04, similarity 0.9672):
[0000866374-22-000016:note_history:64]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet.

- added (2022-07-29):
[0000866374-22-000052:note_history:65]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is,

- changed (2022-07-29):
[0000866374-22-000052:note_history:66]
therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.
  (was, 2022-02-04, similarity 0.7562):
[0000866374-22-000016:note_history:66]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

- changed (2022-07-29):
[0000866374-22-000052:note_history:67]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $741 million and $704 million as of July 1, 2022 and March 31, 2022, respectively, of which $645 million and $615 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.
  (was, 2022-02-04, similarity 0.6797):
[0000866374-22-000016:note_history:67]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $608.5 million and $435.4 million as of December 31, 2021 and

- added (2022-07-29):
[0000866374-22-000052:note_history:68]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended July 1, 2022 and July 2, 2021, respectively. Historical information for the first quarter of fiscal year ended March 31, 2022 has been recast to reflect the new operating and reportable segments in the table below.

- added (2022-07-29):
[0000866374-22-000052:note_history:69]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,779 |  |  | $ | 3,248 |  |  |  |  |  |
| Over time | 212 |  |  | 184 |  |  |  |  |  |
| Total | 3,991 |  |  | 3,432 |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,790 |  |  | 2,407 |  |  |  |  |  |
| Over time | 179 |  |  | 175 |  |  |  |  |  |
| Total | 2,969 |  |  | 2,582 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 23 |  |  | 9 |  |  |  |  |  |
| Over time | 372 |  |  | 332 |  |  |  |  |  |
| Total | 395 |  |  | 341 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (8) |  |  | (13) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (8) |  |  | (13) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,584 |  |  | 5,651 |  |  |  |  |  |
| Over time | 763 |  |  | 691 |  |  |  |  |  |
| Total | $ | 7,347 |  |  | $ | 6,342 |  |  |  |  |  |

- removed (2022-07-29):
[0000866374-22-000016:note_history:70]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first

- removed (2022-07-29):
[0000866374-22-000016:note_history:71]
March 31, 2021, respectively, of which $541.2 million and $376.5 million, respectively, is included in deferred revenue and customer working capital advances.

- removed (2022-07-29):
[0000866374-22-000016:note_history:72]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2021 and December 31, 2020, respectively.

- removed (2022-07-29):
[0000866374-22-000016:note_history:73]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2021 |  | December 31, 2020 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,389 |  |  | $ | 3,544 |  |  | $ | 9,887 |  |  | $ | 8,813 |  |
| Over time | 192 |  |  | 290 |  |  | 563 |  |  | 1,250 |  |
| Total | 3,581 |  |  | 3,834 |  |  | 10,450 |  |  | 10,063 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,559 |  |  | 2,189 |  |  | 7,270 |  |  | 5,292 |  |
| Over time | 479 |  |  | 697 |  |  | 1,470 |  |  | 2,503 |  |
| Total | 3,038 |  |  | 2,886 |  |  | 8,740 |  |  | 7,795 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,948 |  |  | 5,733 |  |  | 17,157 |  |  | 14,105 |  |
| Over time | 671 |  |  | 987 |  |  | 2,033 |  |  | 3,753 |  |
| Total | $ | 6,619 |  |  | $ | 6,720 |  |  | $ | 19,190 |  |  | $ | 17,858 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-07-29):
[0000866374-22-000052:note_history:74]
SUBSEQUENT EVENTSOn July 19, 2022, the Company entered into a new $2.5 billion credit agreement (the "New Credit Facility") which matures in July 2027 and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans and a sub-limit of $175 million available for the issuance of letters of credit. The New Credit Facility replaced the previous $2.0 billion credit facility. Under the New Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

- removed (2022-07-29):
[0000866374-22-000016:note_history:75]
SUBSEQUENT EVENTS
Issuance and Sale of Series A Preferred Units of Nextracker

- removed (2022-07-29):
[0000866374-22-000016:note_history:76]
On February 1, 2022, affiliates of the Company entered into a purchase agreement (the “Purchase Agreement”) with TPG Rise Flash, L.P., a Delaware limited partnership, which is managed or advised by TPG Rise Climate, TPG, Inc.’s dedicated renewables and climate investing fund (“TPG Rise”), for the sale of 500,000 Series A Preferred Units (the “Preferred Units”) in Nextracker LLC (“Nextracker LLC” or “Nextracker”) for an aggregate purchase price of $500 million (the “Preferred Sale”). TPG Rise’s investment in approximately 16.7% of Nextracker LLC reflects an implied value for Nextracker LLC as of the date of the investment of $3.0 billion.

- removed (2022-07-29):
[0000866374-22-000016:note_history:77]
Dividends.  The Preferred Units have a dividend rate of 5% per annum, payable semi-annually, up to 100% of which (less an amount necessary to fund TPG Rise’s tax obligations) may be payable in kind during the first two years following the closing of the Preferred Sale, and 50% of which may be payable in kind thereafter.

- removed (2022-07-29):
[0000866374-22-000016:note_history:78]
Conversion Ratio.  The Preferred Units will be automatically converted into common units of Nextracker LLC upon a qualified initial public offering (a “Qualified Public Offering”) and TPG Rise may elect to convert the Preferred Units into common units of Nextracker LLC at any time after March 31, 2023. Subject to certain exceptions, for any mandatory or optional conversion, the conversion ratio for each Preferred Unit will be based on a deemed value of Nextracker LLC equal to the lesser of $3.0 billion and the implied equity valuation of Nextracker LLC determined by the underwriters engaged in connection with a Qualified Public Offering. If a Qualified Public Offering occurs by March 31, 2023 with an implied equity valuation greater than $3.75 billion, then the conversion ratio will be adjusted upwards based on a deemed value of Nextracker LLC equal to $3.2 billion. If a Qualified Public Offering occurs after March 31, 2023 with an implied equity valuation between $2.7 billion and $3.0 billion, then the conversion ratio will be based on a deemed value of Nextracker LLC equal to $3.0 billion. If a Qualified Public Offering occurs after March 31, 2023 with an implied equity valuation of less than $2.7 billion, then the conversion ratio will be based on a deemed value equal to the implied equity valuation of Nextracker LLC in the Qualified Public Offering divided by 90%. If TPG Rise elects to convert the Preferred Units prior to an initial public offering, the conversion ratio shall be based on a deemed value of Nextracker LLC equal to $3.0 billion.

- removed (2022-07-29):
[0000866374-22-000016:note_history:79]
Repurchase.  At TPG Rise’s election, the Company is required to repurchase all of the outstanding Preferred Units at their liquidation preference, which shall include all contributed but unreturned capital plus accrued but unpaid dividends, at the earlier of certain change in control events and February 2, 2028. Additionally, if Nextracker has not completed a Qualified Public Offering prior to February 2, 2027, then TPG Rise may cause the Company to repurchase all of the outstanding Preferred Units at their fair market value (determined by a mutually agreeable third-party appraiser).

- removed (2022-07-29):
[0000866374-22-000016:note_history:80]
Voting Rights.  The Preferred Units will vote together with the common units of Nextracker as a single class in all matters that are subject to a vote by common unitholders. In connection with the Preferred Sale, TPG Rise has the right to designate two members of the Board of Nextracker LLC; if, however, TPG Rise owns Preferred Units or common units of Nextracker LLC with a fully diluted ownership percentage of less than 10% but more than 5%, the number of Board members that TPG Rise will be entitled to designate will be reduced to one. So long as at least 51% of the Preferred Units remain outstanding, the consent of the holders of the Preferred Units must be obtained prior to taking certain actions regarding Nextracker LLC, including, but not limited to, changes to the terms of the Preferred Units that adversely affect the rights of holders of the Preferred Units, certain incurrences of indebtedness by Nextracker, certain capital expenditures, acquisitions or dispositions by Nextracker, and changes to the Board and management of Nextracker.

- removed (2022-07-29):
[0000866374-22-000016:note_history:81]
Conversion to Limited Liability Company.  In connection with the Preferred Sale, Nextracker Inc. (the predecessor to Nextracker LLC) was converted to a limited liability company and will remain a subsidiary of the Company until the disposition of a majority of the securities of Nextracker LLC, in an initial public offering and/or other corporate transaction. The conversion of Nextracker Inc. is intended to facilitate an initial public offering in the future through what is commonly referred to as an umbrella partnership-C Corporation or an “Up-C” structure.

- removed (2022-07-29):
[0000866374-22-000016:note_history:82]
Separation and Transition Services Agreements.  At the closing of the Preferred Sale, the Company, Flextronics International USA, Inc. and Nextracker LLC entered into a separation agreement and a transition services agreement to formally separate the operations of the businesses. The Company will report the Nextracker business as a separate operating and reportable segment for the fiscal year ending March 31, 2022.
