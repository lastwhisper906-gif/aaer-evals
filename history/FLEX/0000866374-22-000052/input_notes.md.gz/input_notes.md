# FLEX notes — 0000866374-22-000052


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-22-000052:notes:1]
[same as prior period, unchanged from 0000866374-22-000016:notes:1]

[0000866374-22-000052:notes:2]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers advanced manufacturing solutions and operates one of the most trusted global supply chains, supporting the entire product lifecycle with fulfillment, after-market, and circular economy solutions for diverse industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. Flex's three operating and reportable segments are:

[0000866374-22-000052:notes:3]
[same as prior period, unchanged from 0000866374-22-000016:notes:3]

[0000866374-22-000052:notes:4]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-22-000052:notes:5]
[same as prior period, unchanged from 0000866374-22-000016:notes:5]

[0000866374-22-000052:notes:6]
[same as prior period, unchanged from 0000866374-22-000016:notes:6]

[0000866374-22-000052:notes:7]
[same as prior period, unchanged from 0000866374-22-000016:notes:7]

[0000866374-22-000052:notes:8]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies;

[0000866374-22-000052:notes:9]
[same as prior period, unchanged from 0000866374-22-000016:notes:9]

[0000866374-22-000052:notes:10]
◦Industrial, including capital equipment, industrial devices, and renewables and grid edge.

[0000866374-22-000052:notes:11]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

[0000866374-22-000052:notes:12]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers). The Company also provides intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world.

[0000866374-22-000052:notes:13]
[same as prior period, unchanged from 0000866374-22-000016:notes:12]

[0000866374-22-000052:notes:14]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2022 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended July 1, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

[0000866374-22-000052:notes:15]
The first quarters for fiscal years 2023 and 2022 ended on July 1, 2022, which is comprised of 92 days in the period, and July 2, 2021, which is comprised of 93 days in the period, respectively.

[0000866374-22-000052:notes:16]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. In all cases other than the redeemable noncontrolling interest in Nextracker, the associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations

[0000866374-22-000052:notes:17]
for all periods presented, and is classified as a component of Interest and other, net, in the condensed consolidated statements of operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the condensed consolidated statements of operations.

[0000866374-22-000052:notes:18]
[same as prior period, unchanged from 0000866374-22-000016:notes:17]

[0000866374-22-000052:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic and geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the COVID-19 pandemic and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-22-000052:notes:20]
Recently Adopted Accounting Pronouncement

[0000866374-22-000052:notes:21]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company adopted the guidance during the first quarter of fiscal year 2023 with an immaterial impact on its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-22-000052:notes:22]
[same as prior period, unchanged from 0000866374-22-000016:notes:27]

[0000866374-22-000052:notes:23]
[same as prior period, unchanged from 0000866374-22-000016:notes:28]

[0000866374-22-000052:notes:24]
|  | As of July 1, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| Raw materials | $ | 5,863 |  |  | $ | 5,290 |  |
| Work-in-progress | 658 |  |  | 602 |  |
| Finished goods | 722 |  |  | 688 |  |
|  | $ | 7,243 |  |  | $ | 6,580 |  |

[0000866374-22-000052:notes:25]
[same as prior period, unchanged from 0000866374-22-000016:notes:30]

[0000866374-22-000052:notes:26]
During the three-month period ended July 1, 2022, there was no material activity in the Company's goodwill account for each of its reportable segments, other than foreign currency translation adjustments of $6 million, which primarily impacted its FRS segment.

[0000866374-22-000052:notes:27]
[same as prior period, unchanged from 0000866374-22-000016:notes:34]

[0000866374-22-000052:notes:28]
|  | As of July 1, 2022 |  | As of March 31, 2022 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 370 |  |  | $ | (164) |  |  | $ | 206 |  |  | $ | 385 |  |  | $ | (157) |  |  | $ | 228 |  |
| Licenses and other intangibles | 304 |  |  | (138) |  |  | 166 |  |  | 319 |  |  | (136) |  |  | 183 |  |
| Total | $ | 674 |  |  | $ | (302) |  |  | $ | 372 |  |  | $ | 704 |  |  | $ | (293) |  |  | $ | 411 |  |

[0000866374-22-000052:notes:29]
The gross carrying amounts of intangible assets are removed when fully amortized.

[0000866374-22-000052:notes:30]
[same as prior period, unchanged from 0000866374-22-000016:notes:37]

[0000866374-22-000052:notes:31]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 62 |  |
| 2024 |  | 69 |  |
| 2025 |  | 62 |  |
| 2026 |  | 42 |  |
| 2027 |  | 35 |  |
| Thereafter |  | 102 |  |
| Total amortization expense |  | $ | 372 |  |

[0000866374-22-000052:notes:32]
[same as prior period, unchanged from 0000866374-22-000016:notes:39]

[0000866374-22-000052:notes:33]
(1)Represents estimated amortization for the remaining fiscal nine-month period ending March 31, 2023.

[0000866374-22-000052:notes:34]
[same as prior period, unchanged from 0000866374-22-000016:notes:41]

[0000866374-22-000052:notes:35]
Customer working capital advances were $1.8 billion and $1.4 billion, as of July 1, 2022 and March 31, 2022, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.

[0000866374-22-000052:notes:36]
Other Current Liabilities

[0000866374-22-000052:notes:37]
Other current liabilities include customer-related accruals of $264 million and $227 million as of July 1, 2022 and March 31, 2022, respectively.

[0000866374-22-000052:notes:38]
Redeemable Noncontrolling Interest

[0000866374-22-000052:notes:39]
As a result of the Company's sale of redeemable preferred units (“Series A Preferred Units”), representing a 16.67% interest in its subsidiary Nextracker LLC ("Nextracker"), to TPG Rise Flash, L.P. ("TPG Rise") on February 1, 2022, the Company recognized $6 million of a payable-in-kind dividend due to TPG Rise during the three-month period ended July 1, 2022, based on a dividend rate of 5% per annum.

[0000866374-22-000052:notes:40]
At TPG Rise’s election, the Company is required to repurchase all of the outstanding Series A Preferred Units at their liquidation preference, which shall include all contributed but unreturned capital plus accrued but unpaid dividends, at the earlier of certain change in control events and February 2, 2028. Additionally, if Nextracker has not completed a qualified initial public offering (a "Qualified Public Offering") prior to February 2, 2027, then TPG Rise may cause the Company to repurchase all of the outstanding Series A Preferred Units at their fair market value. The Company has determined that a Qualified Public Offering is likely and that the change in control is not probable as of July 1, 2022 and as such, it is not probable that the noncontrolling interest will become redeemable.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-22-000052:notes:41]
[same as prior period, unchanged from 0000866374-22-000016:notes:43]

[0000866374-22-000052:notes:42]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and

[0000866374-22-000052:notes:43]
can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-22-000052:notes:44]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-22-000052:notes:45]
[same as prior period, unchanged from 0000866374-22-000016:notes:47]

[0000866374-22-000052:notes:46]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the condensed consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-22-000052:notes:47]
[same as prior period, unchanged from 0000866374-22-000016:notes:49]

[0000866374-22-000052:notes:48]
[same as prior period, unchanged from 0000866374-22-000016:notes:50]

[0000866374-22-000052:notes:49]
[same as prior period, unchanged from 0000866374-22-000016:notes:51]

[0000866374-22-000052:notes:50]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is,

[0000866374-22-000052:notes:51]
therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-22-000052:notes:52]
[same as prior period, unchanged from 0000866374-22-000016:notes:53]

[0000866374-22-000052:notes:53]
[same as prior period, unchanged from 0000866374-22-000016:notes:54]

[0000866374-22-000052:notes:54]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $741 million and $704 million as of July 1, 2022 and March 31, 2022, respectively, of which $645 million and $615 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-22-000052:notes:55]
[same as prior period, unchanged from 0000866374-22-000016:notes:57]

[0000866374-22-000052:notes:56]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended July 1, 2022 and July 2, 2021, respectively. Historical information for the first quarter of fiscal year ended March 31, 2022 has been recast to reflect the new operating and reportable segments in the table below.

[0000866374-22-000052:notes:57]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,779 |  |  | $ | 3,248 |  |  |  |  |  |
| Over time | 212 |  |  | 184 |  |  |  |  |  |
| Total | 3,991 |  |  | 3,432 |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,790 |  |  | 2,407 |  |  |  |  |  |
| Over time | 179 |  |  | 175 |  |  |  |  |  |
| Total | 2,969 |  |  | 2,582 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 23 |  |  | 9 |  |  |  |  |  |
| Over time | 372 |  |  | 332 |  |  |  |  |  |
| Total | 395 |  |  | 341 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (8) |  |  | (13) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (8) |  |  | (13) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,584 |  |  | 5,651 |  |  |  |  |  |
| Over time | 763 |  |  | 691 |  |  |  |  |  |
| Total | $ | 7,347 |  |  | $ | 6,342 |  |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-22-000052:notes:58]
SHARE-BASED COMPENSATIONThe Company's primary plan used for granting equity compensation awards is the 2017 Equity Incentive Plan (the "2017 Plan").
The following table summarizes the Company’s share-based compensation expense:

[0000866374-22-000052:notes:59]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
|  | (In millions) |
| Cost of sales | $ | 7 |  |  | $ | 5 |  |  |  |  |  |
| Selling, general and administrative expenses | 19 |  |  | 15 |  |  |  |  |  |
| Total share-based compensation expense | $ | 26 |  |  | $ | 20 |  |  |  |  |  |

[0000866374-22-000052:notes:60]
Total number of options outstanding and exercisable were immaterial as of July 1, 2022. All options have been fully expensed as of July 1, 2022.

[0000866374-22-000052:notes:61]
During the three-month period ended July 1, 2022, the Company granted 5.6 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 4.5 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, and with an average grant date price of $16.44 per award. In addition, approximately 0.5 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $16.66 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of approximately 1.0 million based on a measurement of the Company's adjusted earnings per share growth over certain specified periods, and will cliff vest after a period of three years, to the extent such performance conditions have been met. Further, approximately 0.5 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $23.46 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 1.0 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-22-000052:notes:62]
As of July 1, 2022, approximately 15.4 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 2.2 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of 0.9 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to 4.4 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to 1.8 million based on the achievement levels. During the three-month period ended July 1, 2022, 2.4 million shares vested in connection with the awards with market conditions granted in fiscal year 2020.

[0000866374-22-000052:notes:63]
As of July 1, 2022, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $217 million, and will be recognized over a weighted-average remaining vesting period of 2.4 years.

[0000866374-22-000052:notes:64]
In April 2022, Nextracker granted 11.2 million equity-based compensation awards to its employees under the 2022 Nextracker LLC Equity Incentive Plan (the “2022 Nextracker Plan”). Vesting for the awards granted under the 2022 Nextracker Plan is contingent upon continued employee service and certain performance conditions, including a liquidity event such as the occurrence of an initial public offering or the sale of Nextracker. No expense was recognized for equity-based compensation awards granted under the 2022 Nextracker Plan for the three-month period ended July 1, 2022 as there was no occurrence of a liquidity event.


## us-gaap:EarningsPerShareTextBlock

[0000866374-22-000052:notes:65]
[same as prior period, unchanged from 0000866374-22-000016:notes:67]

[0000866374-22-000052:notes:66]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
|  | (In millions, except per share amounts) |
| Basic earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 195 |  |  | $ | 206 |  |  |  |  |  |
| Net income attributable to redeemable noncontrolling interest | 6 |  |  | — |  |  |  |  |  |
| Net income attributable to Flex Ltd. | $ | 189 |  |  | $ | 206 |  |  |  |  |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 458 |  |  | 491 |  |  |  |  |  |
| Basic earnings per share | $ | 0.41 |  |  | $ | 0.42 |  |  |  |  |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 195 |  |  | $ | 206 |  |  |  |  |  |
| Net income attributable to redeemable noncontrolling interest | 6 |  |  | — |  |  |  |  |  |
| Net income attributable to Flex Ltd. | $ | 189 |  |  | $ | 206 |  |  |  |  |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 458 |  |  | 491 |  |  |  |  |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 10 |  |  | 8 |  |  |  |  |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 468 |  |  | 499 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.40 |  |  | $ | 0.41 |  |  |  |  |  |

[0000866374-22-000052:notes:67]
(1)5.2 million and 1.1 million RSU awards for the three-month periods ended July 1, 2022 and July 2, 2021, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-22-000052:notes:68]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of July 1, 2022 are as follows:

[0000866374-22-000052:notes:69]
|  | As of July 1, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.430% | 245 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 689 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 689 |  |  | 690 |  |
| Euro Term Loans | 367 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 266 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (17) |  |  | (18) |  |
|  | 4,075 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (946) |  |  | (949) |  |
| Non-current portion | $ | 3,129 |  |  | $ | 3,248 |  |

[0000866374-22-000052:notes:70]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.0% as of July 1, 2022 and March 31, 2022.

[0000866374-22-000052:notes:71]
Scheduled repayments of the Company's bank borrowings and long-term debt as of July 1, 2022 are as follows:

[0000866374-22-000052:notes:72]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 893 |  |
| 2024 |  | 53 |  |
| 2025 |  | 245 |  |
| 2026 |  | 1,288 |  |
| 2027 |  | — |  |
| Thereafter |  | 1,613 |  |
| Total |  | $ | 4,092 |  |

[0000866374-22-000052:notes:73]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2023.


## flex:InterestAndOtherNetTextBlock

[0000866374-22-000052:notes:74]
INTEREST AND OTHER, NET 
Interest and other, net for the three-month periods ended July 1, 2022 and July 2, 2021 are primarily composed of the following:

[0000866374-22-000052:notes:75]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 43 |  |  | $ | 39 |  |  |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-22-000052:notes:76]
[same as prior period, unchanged from 0000866374-22-000016:notes:87]

[0000866374-22-000052:notes:77]
The Company enters into short-term and long-term foreign currency derivatives contracts, including forward, swap, and options contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable, accounts payable, debt, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-22-000052:notes:78]
As of July 1, 2022, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $11.8 billion as summarized below:

[0000866374-22-000052:notes:79]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| CNY |  | 3,038 |  |  | — |  |  | $ | 454 |  |  | $ | — |  |
| HUF |  | 138,710 |  |  | — |  |  | 415 |  |  | — |  |
| ILS |  | 352 |  |  | — |  |  | 102 |  |  | — |  |
| JPY |  | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN |  | 6,829 |  |  | — |  |  | 339 |  |  | — |  |
| MYR |  | 540 |  |  | 94 |  |  | 123 |  |  | 21 |  |
| Other |  | N/A |  | N/A |  | 176 |  |  | 120 |  |
|  |  |  |  |  |  | 1,909 |  |  | 141 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |
| BRL |  | 9 |  |  | 867 |  |  | 2 |  |  | 166 |  |
| CAD |  | 115 |  |  | 68 |  |  | 89 |  |  | 53 |  |
| CNY |  | 4,598 |  |  | 688 |  |  | 688 |  |  | 102 |  |
| EUR |  | 3,003 |  |  | 2,838 |  |  | 3,165 |  |  | 2,984 |  |
| GBP |  | 165 |  |  | 201 |  |  | 201 |  |  | 244 |  |
| HUF |  | 78,890 |  |  | 67,113 |  |  | 209 |  |  | 178 |  |
| ILS |  | 376 |  |  | 166 |  |  | 109 |  |  | 48 |  |
| INR |  | 10,003 |  |  | — |  |  | 126 |  |  | — |  |
| MXN |  | 8,137 |  |  | 5,983 |  |  | 404 |  |  | 297 |  |
| MYR |  | 1,003 |  |  | 343 |  |  | 228 |  |  | 78 |  |
| SGD |  | 102 |  |  | 55 |  |  | 73 |  |  | 39 |  |
| Other |  | N/A |  | N/A |  | 149 |  |  | 146 |  |
|  |  |  |  |  |  | 5,443 |  |  | 4,335 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 7,352 |  |  | $ | 4,476 |  |

[0000866374-22-000052:notes:80]
As of July 1, 2022, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of July 1, 2022 and March 31, 2022, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred loss was $45 million as of July 1, 2022, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, and the USD HUF cross currency swaps, which are further discussed below.

[0000866374-22-000052:notes:81]
The Company entered into a USD JPY cross currency swap in April 2019 to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other current liabilities and other liabilities as of July 1, 2022. Additionally, the Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other current liabilities and other liabilities as of July 1, 2022. The changes in fair value of both the USD JPY cross currency swap and the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal and HUF bond principal, which also impact the same line.

[0000866374-22-000052:notes:82]
[same as prior period, unchanged from 0000866374-22-000016:notes:93]

[0000866374-22-000052:notes:83]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | July 1,2022 |  | March 31,2022 |  | Balance SheetLocation |  | July 1,2022 |  | March 31,2022 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 18 |  |  | $ | 22 |  |  | Other current liabilities |  | $ | 49 |  |  | $ | 35 |  |
| Foreign currency contracts | Other assets |  | $ | — |  |  | $ | — |  |  | Other liabilities |  | $ | 116 |  |  | $ | 61 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 26 |  |  | $ | 21 |  |  | Other current liabilities |  | $ | 41 |  |  | $ | 26 |  |

[0000866374-22-000052:notes:84]
[same as prior period, unchanged from 0000866374-22-000016:notes:95]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-22-000052:notes:85]
[same as prior period, unchanged from 0000866374-22-000016:notes:96]

[0000866374-22-000052:notes:86]
|  | Three-Month Periods Ended |
|  | July 1, 2022 |  | July 2, 2021 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |  | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |
| Other comprehensive gain (loss) before reclassifications | (79) |  |  | (68) |  |  | (147) |  |  | 12 |  |  | 6 |  |  | 18 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 78 |  |  | (3) |  |  | 75 |  |  | (9) |  |  | (1) |  |  | (10) |  |
| Net current-period other comprehensive gain (loss) | (1) |  |  | (71) |  |  | (72) |  |  | 3 |  |  | 5 |  |  | 8 |  |
| Ending balance | $ | (67) |  |  | $ | (187) |  |  | $ | (254) |  |  | $ | (39) |  |  | $ | (72) |  |  | $ | (111) |  |

[0000866374-22-000052:notes:87]
Substantially all unrealized losses and gains relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended July 1, 2022 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-22-000052:notes:88]
[same as prior period, unchanged from 0000866374-22-000016:notes:100]

[0000866374-22-000052:notes:89]
[same as prior period, unchanged from 0000866374-22-000016:notes:101]

[0000866374-22-000052:notes:90]
The Company sells designated pools of trade receivables under its asset-backed securitization programs (the “ABS Programs”) to affiliated special purpose entities, each of which may in turn sell a fraction of the receivables to unaffiliated

[0000866374-22-000052:notes:91]
financial institutions, based on the Company's requirements. Under these programs, the entire purchase price of sold receivables is paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The accounts receivable balances sold under the ABS Programs are removed from the condensed consolidated balance sheets and the cash proceeds received by the Company are included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-22-000052:notes:92]
During the three-month periods ended July 1, 2022 and July 2, 2021, no accounts receivable were sold under the ABS Programs.

[0000866374-22-000052:notes:93]
Trade Accounts Receivable Sale Programs
The Company also sells accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.7 billion and $0.6 billion as of July 1, 2022 and March 31, 2022, respectively. For the three-month periods ended July 1, 2022 and July 2, 2021, total accounts receivable sold to certain third-party banking institutions was approximately $0.8 billion and $0.2 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-22-000052:notes:94]
[same as prior period, unchanged from 0000866374-22-000016:notes:107]

[0000866374-22-000052:notes:95]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of July 1, 2022 and March 31, 2022.

[0000866374-22-000052:notes:96]
[same as prior period, unchanged from 0000866374-22-000016:notes:109]

[0000866374-22-000052:notes:97]
[same as prior period, unchanged from 0000866374-22-000016:notes:110]

[0000866374-22-000052:notes:98]
[same as prior period, unchanged from 0000866374-22-000016:notes:111]

[0000866374-22-000052:notes:99]
[same as prior period, unchanged from 0000866374-22-000016:notes:112]

[0000866374-22-000052:notes:100]
[same as prior period, unchanged from 0000866374-22-000016:notes:113]

[0000866374-22-000052:notes:101]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of July 1, 2022 and March 31, 2022.

[0000866374-22-000052:notes:102]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended July 1, 2022 and July 2, 2021.

[0000866374-22-000052:notes:103]
[same as prior period, unchanged from 0000866374-22-000016:notes:116]

[0000866374-22-000052:notes:104]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of July 1, 2022 and March 31, 2022:

[0000866374-22-000052:notes:105]
|  | Fair Value Measurements as of July 1, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 2,142 |  |  | $ | — |  |  | $ | 2,142 |  |
| Foreign currency contracts (Note 8) | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (206) |  |  | $ | — |  |  | $ | (206) |  |
|  | Fair Value Measurements as of March 31, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 2,285 |  |  | $ | — |  |  | $ | 2,285 |  |
| Foreign currency contracts (Note 8) | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (122) |  |  | $ | — |  |  | $ | (122) |  |

[0000866374-22-000052:notes:106]
[same as prior period, unchanged from 0000866374-22-000016:notes:119]

[0000866374-22-000052:notes:107]
[same as prior period, unchanged from 0000866374-22-000016:notes:120]

[0000866374-22-000052:notes:108]
|  | As of July 1, 2022 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 504 |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.430% | 245 |  |  | 245 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 601 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 689 |  |  | 659 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 659 |  |  | 636 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 689 |  |  | 659 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | 367 |  |  | 367 |  |  | 389 |  |  | 389 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 266 |  |  | 266 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | 79 |  |  | 79 |  |  | 84 |  |  | 84 |  |  | Level 2 |

[0000866374-22-000052:notes:109]
[same as prior period, unchanged from 0000866374-22-000016:notes:122]

[0000866374-22-000052:notes:110]
The Company values its Term Loan due April 2024, India Facilities, Euro Term Loans, and HUF Bonds based on the current market rate, and as of July 1, 2022, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-22-000052:notes:111]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-22-000052:notes:112]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-22-000052:notes:113]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-22-000052:notes:114]
From time to time, the Company enters into intellectual property licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

[0000866374-22-000052:notes:115]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 374 million Brazilian reals (approximately USD $72 million based on the exchange rate as of July 1, 2022). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 61 million Brazilian reals or USD $12 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 34 million Brazilian reals (approximately USD $7 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

[0000866374-22-000052:notes:116]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-22-000052:notes:117]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018.

[0000866374-22-000052:notes:118]
The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-22-000052:notes:119]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-22-000052:notes:120]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-22-000052:notes:121]
SHARE REPURCHASES 
During the three-month period ended July 1, 2022, the Company repurchased 11.3 million shares at an aggregate purchase price of $181 million, and retired all of these shares.

[0000866374-22-000052:notes:122]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 4, 2021. As of July 1, 2022, shares in the aggregate amount of $314 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-22-000052:notes:123]
SEGMENT REPORTING
The Company reports its financial performance based on three operating and reportable segments, Flex Agility Solutions, Flex Reliability Solutions and Nextracker and analyzes operating income as the measure of segment profitability. The determination of these segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-22-000052:notes:124]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, and legal and other. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-22-000052:notes:125]
Selected financial information by segment is in the table below. Historical information for the first quarter of fiscal year ended March 31, 2022 has been recast to reflect the new operating and reportable segments in the table below and in Item 2, "Management's Discussion and Analysis of Financial Condition and Results of Operations."

[0000866374-22-000052:notes:126]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,991 |  |  | $ | 3,432 |  |  |  |  |  |
| Flex Reliability Solutions | 2,969 |  |  | 2,582 |  |  |  |  |  |
| Nextracker | 395 |  |  | 341 |  |  |  |  |  |
| Intersegment eliminations | (8) |  |  | (13) |  |  |  |  |  |
|  | $ | 7,347 |  |  | $ | 6,342 |  |  |  |  |  |
| Segment income and reconciliation of operating income: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 171 |  |  | $ | 137 |  |  |  |  |  |
| Flex Reliability Solutions | 147 |  |  | 144 |  |  |  |  |  |
| Nextracker | 30 |  |  | 25 |  |  |  |  |  |
| Corporate and Other | (18) |  |  | (16) |  |  |  |  |  |
| Total segment income | 330 |  |  | 290 |  |  |  |  |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 22 |  |  | 15 |  |  |  |  |  |
| Stock-based compensation | 26 |  |  | 20 |  |  |  |  |  |
| Legal and other (1) | 10 |  |  | — |  |  |  |  |  |
| Operating income | $ | 272 |  |  | $ | 255 |  |  |  |  |  |

[0000866374-22-000052:notes:127]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During the first quarter of fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-22-000052:notes:128]
Corporate and other primarily includes corporate services costs that are not included in the chief operating decision maker's ("CODM") assessment of the performance of each of the identified reportable segments.

[0000866374-22-000052:notes:129]
[same as prior period, unchanged from 0000866374-22-000016:notes:154]


## us-gaap:SubsequentEventsTextBlock

[0000866374-22-000052:notes:130]
SUBSEQUENT EVENTSOn July 19, 2022, the Company entered into a new $2.5 billion credit agreement (the "New Credit Facility") which matures in July 2027 and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans and a sub-limit of $175 million available for the issuance of letters of credit. The New Credit Facility replaced the previous $2.0 billion credit facility. Under the New Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.
