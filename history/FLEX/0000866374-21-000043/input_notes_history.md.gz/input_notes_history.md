# FLEX note change history — 0000866374-21-000019 → 0000866374-21-000043


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000866374-21-000043:note_history:1]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.
  (was, 2021-01-29, similarity 0.9006):
[0000866374-21-000019:note_history:1]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor agreed to an immaterial settlement.

- changed (2021-07-30):
[0000866374-21-000043:note_history:2]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. On May 19, 2021, lead plaintiff filed its opening appeal brief, and on July 19, 2021, defendants filed their answering brief. Lead plaintiff’s reply brief is due September 8, 2021. The Company believes that the claims are without merit and intends to vigorously defend this case.
  (was, 2021-01-29, similarity 0.8858):
[0000866374-21-000019:note_history:2]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. Lead plaintiff’s opening appeal brief is due April 19, 2021, and defendants’ answering brief is due May 19, 2021. The Company believes that the claims are without merit and intends to vigorously defend this case.

- changed (2021-07-30):
[0000866374-21-000043:note_history:3]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.
  (was, 2021-01-29, similarity 0.7737):
[0000866374-21-000019:note_history:3]
transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- changed (2021-07-30):
[0000866374-21-000043:note_history:4]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 387.5 million Brazilian reals (approximately USD $77.2 million based on the exchange rate as of July 2, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 61.7 million Brazilian reals or USD $12.3 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 37.6 million Brazilian reals (approximately USD $7.5 million). The Company believes there is no legal basis for any of these assessments and that is has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.
  (was, 2021-01-29, similarity 0.7935):
[0000866374-21-000019:note_history:4]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling 373.7 million Brazilian reals (approximately USD $72.0 million based on the exchange rate as of December 31, 2020). Four of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately 60.5 million Brazilian reals or USD $11.7 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Sao Paolo, Brazil on March 23, 2020; the value of that assessment is 33.9 million Brazilian reals (approximately USD $6.5 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

- added (2021-07-30):
[0000866374-21-000043:note_history:5]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company is currently reviewing those transactions and expects to submit an update to its submission to OFAC once that review is complete. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2021-07-30):
[0000866374-21-000043:note_history:6]
A different foreign Tax Authority had issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagreed with the Tax Authority’s assertion but agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount was accrued for during the fourth quarter of fiscal year 2021 and is expected to be paid during the first half of fiscal year 2022.
  (was, 2021-01-29, similarity 0.6711):
[0000866374-21-000019:note_history:6]
A different foreign Tax Authority has issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for the periods fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagrees with the Tax Authority’s assertion and is actively contesting through administrative processes and will defend through judicial processes if necessary.

- added (2021-07-30):
[0000866374-21-000043:note_history:7]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for Credit Habilitation with the tax authorities in June 2021 to request additional PIS/COFINS credit recovery in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of our credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remains uncertainty regarding the Company’s ability to recover these credits. The Company considers the recovery of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and has not recorded a gain for the recovery in the three-month period ended July 2, 2021 as it has not resolved all contingencies to conclude a realized or realizable amount. The amount and timing of recognition of the gain recovery is dependent upon the decision from the relevant tax authorities in regards to our application for Credit Habilitation and may have a material impact to our consolidated financial statements. We expect that this contingency could be resolved as early as the second quarter of fiscal year 2022. Additional taxes may also result from the credit recovery we receive subsequently.

- removed (2021-07-30):
[0000866374-21-000019:note_history:8]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash

- removed (2021-07-30):
[0000866374-21-000019:note_history:9]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000866374-21-000043:note_history:10]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In order to drive efficiency and productivity the Company is organized around two focused and complementary delivery models, which also represent its operating and reportable segments:
  (was, 2021-01-29, similarity 0.7459):
[0000866374-21-000019:note_history:10]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In the first quarter of fiscal year 2021, the Company made certain changes in its organizational structure as part of its strategy to further drive growth and productivity with two focused delivery models. As a result, beginning in the first quarter of fiscal year 2021, the Company reports its financial performance based on two operating and reportable segments:

- changed (2021-07-30):
[0000866374-21-000043:note_history:11]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure;
  (was, 2021-01-29, similarity 0.9962):
[0000866374-21-000019:note_history:11]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communication infrastructure;

- changed (2021-07-30):
[0000866374-21-000043:note_history:12]
◦Industrial, including capital equipment, industrial devices, renewable including our Nextracker business, grid edge, and power systems.
  (was, 2021-01-29, similarity 0.8631):
[0000866374-21-000019:note_history:12]
◦Industrial, including capital equipment, industrial devices, renewable and grid edge, and power systems.

- changed (2021-07-30):
[0000866374-21-000043:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2021 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended July 2, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022. Beginning in the second quarter of fiscal year 2021, the Company began reporting all dollar amounts in millions. In certain circumstances, this change in rounding resulted in line items being removed within prior year disclosures. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.
  (was, 2021-01-29, similarity 0.9868):
[0000866374-21-000019:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2020 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021. Beginning in the second quarter of fiscal year 2021, the Company began reporting all dollar amounts in millions. In certain circumstances, this change in rounding resulted in line items being removed within prior year disclosures. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

- added (2021-07-30):
[0000866374-21-000043:note_history:14]
The first quarters for fiscal years 2022 and 2021 ended on July 2, 2021, which is comprised of 93 days in the period, and June 26, 2020, which is comprised of 87 days in the period, respectively.

- changed (2021-07-30):
[0000866374-21-000043:note_history:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.
  (was, 2021-01-29, similarity 0.7533):
[0000866374-21-000019:note_history:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership

- changed (2021-07-30):
[0000866374-21-000043:note_history:16]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2021-01-29, similarity 0.9901):
[0000866374-21-000019:note_history:16]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, including highly liquid investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- changed (2021-07-30):
[0000866374-21-000043:note_history:17]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.
  (was, 2021-01-29, similarity 0.6917):
[0000866374-21-000019:note_history:17]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

- changed (2021-07-30):
[0000866374-21-000043:note_history:18]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force," which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.
  (was, 2021-01-29, similarity 0.7658):
[0000866374-21-000019:note_history:18]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force," which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

- changed (2021-07-30):
[0000866374-21-000043:note_history:19]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.
  (was, 2021-01-29, similarity 0.7362):
[0000866374-21-000019:note_history:19]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The guidance is effective for the Company beginning in the first quarter of fiscal year 2022 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2022.

- removed (2021-07-30):
[0000866374-21-000019:note_history:20]
The first quarters for fiscal years 2021 and 2020 ended on June 26, 2020, which is comprised of 87 days in the period, and June 28, 2019, which is comprised of 89 days in the period, respectively. The second quarters for fiscal years 2021 and 2020 ended on September 25, 2020 and September 27, 2019, which are comprised of 91 days in both periods. The Company's third quarters for fiscal years 2021 and 2020 ended on December 31 of each year, which are comprised of 97 days and 95 days, respectively.

- removed (2021-07-30):
[0000866374-21-000019:note_history:21]
of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

- removed (2021-07-30):
[0000866374-21-000019:note_history:22]
The changes to the Company’s organizational structure noted above had no impact on the condensed consolidated financial statements. For comparability purposes, segment reporting for prior periods have been restated to conform to the current presentation. Refer to note 14, “Segment Reporting,” for additional information on the changes in operating and reportable segments.

- removed (2021-07-30):
[0000866374-21-000019:note_history:23]
In March 2020, the FASB issued ASU 2020-04 "Facilitation of the Effects of Reference Rate Reform on Financial Reporting", which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

- removed (2021-07-30):
[0000866374-21-000019:note_history:24]
In June 2016, the FASB issued ASU 2016-13 “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” and also issued subsequent amendments to the initial guidance: ASU 2018-19, ASU 2019-04,  ASU 2019-05, ASU 2019-10, and ASU 2019-11, which replace the existing incurred loss impairment model with an expected credit loss model and require a financial asset measured at amortized cost to be presented at the net amount expected to be collected. The Company adopted the guidance during the first quarter of fiscal year 2021 with an immaterial impact on its consolidated financial statements.

- removed (2021-07-30):
[0000866374-21-000019:note_history:25]
Recently Issued Accounting Pronouncements

- removed (2021-07-30):
[0000866374-21-000019:note_history:26]
In October 2020, the FASB issued ASU 2020-09 "Debt (Topic 470): Amendments to SEC Paragraphs Pursuant to SEC Release No. 33-10762." which amends and supersedes SEC paragraphs in the Accounting Standards Codification to reflect the issuance of SEC Release No. 33-10762 related to financial disclosure requirements for subsidiary issuers and guarantors of registered debt securities and affiliates whose securities are pledged as collateral for registered securities. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance when it becomes effective in the fourth quarter of fiscal year 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2021-07-30):
[0000866374-21-000019:note_history:27]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2020 are as follows:

- removed (2021-07-30):
[0000866374-21-000019:note_history:28]
|  | As of December 31, 2020 |  | As of March 31, 2020 |
|  | (In millions) |
| Term Loan, including current portion, due in installments through June 2022 | $ | — |  |  | $ | 433 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 324 |  |  | 310 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 597 |  |
| 3.750% Notes due February 2026 | 695 |  |  | — |  |
| 4.875% Notes due June 2029 | 661 |  |  | 662 |  |
| 4.875% Notes due May 2030 | 696 |  |  | — |  |
| India Facilities | 136 |  |  | 138 |  |
| Other | 225 |  |  | 211 |  |
| Debt issuance costs | (23) |  |  | (13) |  |
|  | 3,812 |  |  | 2,838 |  |
| Current portion, net of debt issuance costs | (72) |  |  | (149) |  |
| Non-current portion | $ | 3,740 |  |  | $ | 2,689 |  |

- removed (2021-07-30):
[0000866374-21-000019:note_history:29]
The weighted-average interest rate for the Company's long-term debt was 4.0% as of December 31, 2020 and March 31, 2020, respectively.

- removed (2021-07-30):
[0000866374-21-000019:note_history:30]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2020 are as follows:

- removed (2021-07-30):
[0000866374-21-000019:note_history:31]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2021 (1) |  | $ | 56 |  |
| 2022 |  | 222 |  |
| 2023 |  | 531 |  |
| 2024 |  | 53 |  |
| 2025 |  | 324 |  |
| Thereafter |  | 2,649 |  |
| Total |  | $ | 3,835 |  |

- removed (2021-07-30):
[0000866374-21-000019:note_history:32]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2021.

- removed (2021-07-30):
[0000866374-21-000019:note_history:33]
Notes due February 2026 and May 2030

- removed (2021-07-30):
[0000866374-21-000019:note_history:34]
In May 2020, the Company issued $425 million aggregate principal amount of 3.750% Notes due February 2026 (the "Existing 2026 Notes"), at 99.617% of face value and $325 million aggregate principal amount of 4.875% Notes due May 2030 (the "Existing 2030 Notes" and, together with the Existing 2026 Notes, the "Existing Notes"), at 99.562% of face value. In August 2020, as a further issuance of the Existing Notes, the Company issued under the same terms (other than the initial interest accrual date and first interest payment date for the additional 2026 Notes, and the initial offering price and the issue date for the additional 2026 and 2030 Notes), an additional $250 million of 3.750% Notes due February 2026 (together with the Existing 2026 Notes, the "2026 Notes"), at 109.294% of face value, and $325 million of 4.875% Notes due May 2030 (together with the Existing 2030 Notes, the "2030 Notes"), at 114.863% of face value. Immediately after the issuance of the additional notes issued in August 2020, the Company has $675 million aggregate principal amount of 3.750% Notes due 2026 outstanding and $650 million aggregate principal amount of 4.875% Notes due 2030 outstanding. The Company received in aggregate, proceeds of approximately $1.4 billion, net of discounts and after premiums, from the issuances, which have been used for working capital and other general corporate purposes, in addition to repaying the term loan due June 2022. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet approximately $12.8 million of costs in conjunction with the issuance of the Notes.

- removed (2021-07-30):
[0000866374-21-000019:note_history:35]
Interest on the 2026 Notes and the 2030 Notes is payable semi-annually, commencing on August 1, 2020 and November 12, 2020, respectively, except that interest on the additional 2026 Notes is payable commencing February 1, 2021. The Notes are senior unsecured obligations of the Company and rank equally with all of the Company's other existing and future senior and unsecured debt obligations.
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2026 Notes or 2030 Notes may declare all of such series of Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of such series of Notes. As of December 31, 2020, the Company was in compliance with the covenants in the indenture governing the Notes.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000866374-21-000043:note_history:36]
|  | As of July 2, 2021 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 534 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 302 |  |  | 302 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 669 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 693 |  |  | 758 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 660 |  |  | 764 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 693 |  |  | 806 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 170 |  |  | 170 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| India Facilities | 133 |  |  | 133 |  |  | 133 |  |  | 133 |  |  | Level 2 |
  (was, 2021-01-29, similarity 0.8495):
[0000866374-21-000019:note_history:36]
|  | As of December 31, 2020 |  | As of March 31, 2020 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| Term Loan, including current portion, due in installments through June 2022 | $ | — |  |  | $ | — |  |  | $ | 433 |  |  | $ | 414 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500 |  |  | 541 |  |  | 500 |  |  | 500 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 324 |  |  | 324 |  |  | 310 |  |  | 310 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 680 |  |  | 597 |  |  | 613 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 695 |  |  | 771 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 661 |  |  | 786 |  |  | 662 |  |  | 628 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 696 |  |  | 826 |  |  | — |  |  | — |  |  | Level 1 |
| Euro Term Loans | 175 |  |  | 175 |  |  | 208 |  |  | 208 |  |  | Level 2 |
| India Facilities | 136 |  |  | 136 |  |  | 138 |  |  | 138 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2021-07-30):
[0000866374-21-000019:note_history:37]
Bank borrowings and long-term debt as of December 31, 2020 are as follows:

- removed (2021-07-30):
[0000866374-21-000019:note_history:38]
|  | As of December 31, 2020 |  | As of March 31, 2020 |
|  | (In millions) |
| Term Loan, including current portion, due in installments through June 2022 | $ | — |  |  | $ | 433 |  |
| 5.000% Notes due February 2023 | 500 |  |  | 500 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 324 |  |  | 310 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 597 |  |
| 3.750% Notes due February 2026 | 695 |  |  | — |  |
| 4.875% Notes due June 2029 | 661 |  |  | 662 |  |
| 4.875% Notes due May 2030 | 696 |  |  | — |  |
| India Facilities | 136 |  |  | 138 |  |
| Other | 225 |  |  | 211 |  |
| Debt issuance costs | (23) |  |  | (13) |  |
|  | 3,812 |  |  | 2,838 |  |
| Current portion, net of debt issuance costs | (72) |  |  | (149) |  |
| Non-current portion | $ | 3,740 |  |  | $ | 2,689 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2021-07-30):
[0000866374-21-000019:note_history:39]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2020 are as follows:

- removed (2021-07-30):
[0000866374-21-000019:note_history:40]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2021 (1) |  | $ | 56 |  |
| 2022 |  | 222 |  |
| 2023 |  | 531 |  |
| 2024 |  | 53 |  |
| 2025 |  | 324 |  |
| Thereafter |  | 2,649 |  |
| Total |  | $ | 3,835 |  |

- removed (2021-07-30):
[0000866374-21-000019:note_history:41]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2021.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000866374-21-000043:note_history:42]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended July 2, 2021 and June 26, 2020, respectively.
  (was, 2021-01-29, similarity 0.8741):
[0000866374-21-000019:note_history:42]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2020 and December 31, 2019, respectively.

- changed (2021-07-30):
[0000866374-21-000043:note_history:43]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
| Timing of Transfer | (In millions) |  |  |  |  |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,248 |  |  | $ | 2,446 |  |  |  |  |  |
| Over time | 184 |  |  | 466 |  |  |  |  |  |
| Total | 3,432 |  |  | 2,912 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,403 |  |  | 1,323 |  |  |  |  |  |
| Over time | 507 |  |  | 918 |  |  |  |  |  |
| Total | 2,910 |  |  | 2,241 |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,651 |  |  | 3,769 |  |  |  |  |  |
| Over time | 691 |  |  | 1,384 |  |  |  |  |  |
| Total | $ | 6,342 |  |  | $ | 5,153 |  |  |  |  |  |
  (was, 2021-01-29, similarity 0.7889):
[0000866374-21-000019:note_history:43]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,544 |  |  | $ | 3,104 |  |  | $ | 8,813 |  |  | $ | 9,060 |  |
| Over time | 290 |  |  | 527 |  |  | 1,250 |  |  | 2,062 |  |
| Total | 3,834 |  |  | 3,631 |  |  | 10,063 |  |  | 11,122 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,189 |  |  | 2,050 |  |  | 5,292 |  |  | 5,101 |  |
| Over time | 697 |  |  | 780 |  |  | 2,503 |  |  | 2,502 |  |
| Total | 2,886 |  |  | 2,830 |  |  | 7,795 |  |  | 7,603 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,733 |  |  | 5,154 |  |  | 14,105 |  |  | 14,161 |  |
| Over time | 987 |  |  | 1,307 |  |  | 3,753 |  |  | 4,564 |  |
| Total | $ | 6,720 |  |  | $ | 6,461 |  |  | $ | 17,858 |  |  | $ | 18,725 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-07-30):
[0000866374-21-000043:note_history:44]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

- changed (2021-07-30):
[0000866374-21-000043:note_history:45]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result,
  (was, 2021-01-29, similarity 0.761):
[0000866374-21-000019:note_history:45]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- added (2021-07-30):
[0000866374-21-000043:note_history:46]
revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- changed (2021-07-30):
[0000866374-21-000043:note_history:47]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.
  (was, 2021-01-29, similarity 0.8855):
[0000866374-21-000019:note_history:47]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on

- changed (2021-07-30):
[0000866374-21-000043:note_history:48]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $489.9 million and $435.4 million as of July 2, 2021 and March 31, 2021, respectively, of which $425.2 million and $376.5 million, respectively, is included in other current liabilities.
  (was, 2021-01-29, similarity 0.788):
[0000866374-21-000019:note_history:48]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $483.4 million and $361.5 million as of December 31, 2020 and March 31, 2020, respectively.

- changed (2021-07-30):
[0000866374-21-000043:note_history:49]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended July 2, 2021 and June 26, 2020, respectively.
  (was, 2021-01-29, similarity 0.8741):
[0000866374-21-000019:note_history:49]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three and nine-month periods ended December 31, 2020 and December 31, 2019, respectively.

- changed (2021-07-30):
[0000866374-21-000043:note_history:50]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
| Timing of Transfer | (In millions) |  |  |  |  |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,248 |  |  | $ | 2,446 |  |  |  |  |  |
| Over time | 184 |  |  | 466 |  |  |  |  |  |
| Total | 3,432 |  |  | 2,912 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,403 |  |  | 1,323 |  |  |  |  |  |
| Over time | 507 |  |  | 918 |  |  |  |  |  |
| Total | 2,910 |  |  | 2,241 |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,651 |  |  | 3,769 |  |  |  |  |  |
| Over time | 691 |  |  | 1,384 |  |  |  |  |  |
| Total | $ | 6,342 |  |  | $ | 5,153 |  |  |  |  |  |
  (was, 2021-01-29, similarity 0.7889):
[0000866374-21-000019:note_history:50]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2020 |  | December 31, 2019 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,544 |  |  | $ | 3,104 |  |  | $ | 8,813 |  |  | $ | 9,060 |  |
| Over time | 290 |  |  | 527 |  |  | 1,250 |  |  | 2,062 |  |
| Total | 3,834 |  |  | 3,631 |  |  | 10,063 |  |  | 11,122 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,189 |  |  | 2,050 |  |  | 5,292 |  |  | 5,101 |  |
| Over time | 697 |  |  | 780 |  |  | 2,503 |  |  | 2,502 |  |
| Total | 2,886 |  |  | 2,830 |  |  | 7,795 |  |  | 7,603 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,733 |  |  | 5,154 |  |  | 14,105 |  |  | 14,161 |  |
| Over time | 987 |  |  | 1,307 |  |  | 3,753 |  |  | 4,564 |  |
| Total | $ | 6,720 |  |  | $ | 6,461 |  |  | $ | 17,858 |  |  | $ | 18,725 |  |

- removed (2021-07-30):
[0000866374-21-000019:note_history:51]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers

- removed (2021-07-30):
[0000866374-21-000019:note_history:52]
that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

- removed (2021-07-30):
[0000866374-21-000019:note_history:53]
the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.
