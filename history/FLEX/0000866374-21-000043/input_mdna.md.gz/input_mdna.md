# FLEX MD&A — 0000866374-21-000043


## mdna

[0000866374-21-000043:mdna:1]
[same as prior period, unchanged from 0000866374-21-000019:mdna:1]

[0000866374-21-000043:mdna:2]
[same as prior period, unchanged from 0000866374-21-000019:mdna:2]

[0000866374-21-000043:mdna:3]
22

[0000866374-21-000043:mdna:4]
[same as prior period, unchanged from 0000866374-21-000019:mdna:3]

[0000866374-21-000043:mdna:5]
We are the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, we deliver technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company reports its financial performance based on two reportable segments:

[0000866374-21-000043:mdna:6]
[same as prior period, unchanged from 0000866374-21-000019:mdna:5]

[0000866374-21-000043:mdna:7]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-21-000043:mdna:8]
[same as prior period, unchanged from 0000866374-21-000019:mdna:7]

[0000866374-21-000043:mdna:9]
[same as prior period, unchanged from 0000866374-21-000019:mdna:8]

[0000866374-21-000043:mdna:10]
[same as prior period, unchanged from 0000866374-21-000019:mdna:9]

[0000866374-21-000043:mdna:11]
[same as prior period, unchanged from 0000866374-21-000019:mdna:10]

[0000866374-21-000043:mdna:12]
[same as prior period, unchanged from 0000866374-21-000019:mdna:11]

[0000866374-21-000043:mdna:13]
◦Industrial, including capital equipment, industrial devices, renewable including our Nextracker business, grid edge, and power systems.

[0000866374-21-000043:mdna:14]
[same as prior period, unchanged from 0000866374-21-000019:mdna:14]

[0000866374-21-000043:mdna:15]
[same as prior period, unchanged from 0000866374-21-000019:mdna:15]

[0000866374-21-000043:mdna:16]
[same as prior period, unchanged from 0000866374-21-000019:mdna:16]

[0000866374-21-000043:mdna:17]
[same as prior period, unchanged from 0000866374-21-000019:mdna:18]

[0000866374-21-000043:mdna:18]
[same as prior period, unchanged from 0000866374-21-000019:mdna:19]

[0000866374-21-000043:mdna:19]
With the second wave of the pandemic including follow-on variants of COVID-19, we continue to experience plant closures and/or restrictions at certain manufacturing facilities in Malaysia, Brazil, and India. There have been renewed disease control measures being taken to limit the spread including movement bans and shelter-in-place orders. We continue to closely monitor the situation in all the locations where we operate. Our priority remains the welfare of our employees. We expect persistent waves of COVID-19 to remain a headwind into the near future. Refer to “Risk Factors - The ongoing COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material,” as disclosed in Part II, “Item 1A. Risk Factors.”

[0000866374-21-000043:mdna:20]
[same as prior period, unchanged from 0000866374-21-000019:mdna:24]

[0000866374-21-000043:mdna:21]
23

[0000866374-21-000043:mdna:22]
[same as prior period, unchanged from 0000866374-21-000019:mdna:25]

[0000866374-21-000043:mdna:23]
We are continuing to evaluate alternatives for our Nextracker business. We are considering options that may include, among others, a full or partial separation of the business through an initial public offering, sale, spin-off, or other transaction. On April 28, 2021, we announced that we confidentially submitted a draft registration statement on Form S-1 with the U.S. Securities and Exchange Commission relating to the proposed initial public offering of Nextracker's Class A common stock. The initial public offering and its timing are subject to market and other conditions and the SEC’s review process, and there can be no assurance that we will proceed with such offering or any alternative transaction. Refer to "Risk Factors - We are pursuing alternatives for our Nextracker business, including a full or partial separation of the business, through an initial public offering of Nextracker or otherwise, which may not be consummated as or when planned or at all, and may not achieve the intended benefits." in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0000866374-21-000043:mdna:24]
This Quarterly Report on Form 10-Q for the fiscal quarter ended July 2, 2021 does not constitute an offer to sell or a solicitation of an offer to buy securities, and shall not constitute an offer, solicitation or sale in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of that jurisdiction.

[0000866374-21-000043:mdna:25]
24

[0000866374-21-000043:mdna:26]
[same as prior period, unchanged from 0000866374-21-000019:mdna:27]

[0000866374-21-000043:mdna:27]
We are one of the world's largest providers of global supply chain solutions, with revenues of $6.3 billion for the three-month period ended July 2, 2021 and $24.1 billion in fiscal year 2021. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-21-000043:mdna:28]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |  |  |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 2,579 |  |  | 41 | % |  | $ | 2,104 |  |  | 41 | % |  |  |  |  |  |  |  |  |
| Asia | 2,365 |  |  | 37 | % |  | 2,013 |  |  | 39 | % |  |  |  |  |  |  |  |  |
| Europe | 1,398 |  |  | 22 | % |  | 1,036 |  |  | 20 | % |  |  |  |  |  |  |  |  |
|  | $ | 6,342 |  |  |  |  | $ | 5,153 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 1,531 |  |  | 24 | % |  | $ | 1,417 |  |  | 27 | % |  |  |  |  |  |  |  |  |
| Mexico | 1,221 |  |  | 19 | % |  | 907 |  |  | 18 | % |  |  |  |  |  |  |  |  |
| U.S. | 876 |  |  | 14 | % |  | 869 |  |  | 17 | % |  |  |  |  |  |  |  |  |
| Brazil | 464 |  |  | 7 | % |  | 322 |  |  | 6 | % |  |  |  |  |  |  |  |  |
| Malaysia | 411 |  |  | 6 | % |  | 299 |  |  | 6 | % |  |  |  |  |  |  |  |  |
| Hungary | 352 |  |  | 6 | % |  | 250 |  |  | 5 | % |  |  |  |  |  |  |  |  |
| Other | 1,487 |  |  | 24 | % |  | 1,089 |  |  | 21 | % |  |  |  |  |  |  |  |  |
|  | $ | 6,342 |  |  |  |  | $ | 5,153 |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-21-000043:mdna:29]
|  | As of |  | As of |
| Property and equipment, net: | July 2, 2021 |  | March 31, 2021 |
|  | (In millions) |
| Mexico | $ | 555 |  |  | 27 | % |  | $ | 553 |  |  | 26 | % |
| U.S. | 360 |  |  | 17 | % |  | 361 |  |  | 17 | % |
| China | 323 |  |  | 15 | % |  | 331 |  |  | 16 | % |
| India | 155 |  |  | 7 | % |  | 166 |  |  | 8 | % |
| Hungary | 109 |  |  | 5 | % |  | 105 |  |  | 5 | % |
| Malaysia | 105 |  |  | 5 | % |  | 106 |  |  | 5 | % |
| Other | 480 |  |  | 24 | % |  | 475 |  |  | 23 | % |
|  | $ | 2,087 |  |  |  |  | $ | 2,097 |  |  |  |

[0000866374-21-000043:mdna:30]
[same as prior period, unchanged from 0000866374-21-000019:mdna:31]

[0000866374-21-000043:mdna:31]
[same as prior period, unchanged from 0000866374-21-000019:mdna:32]

[0000866374-21-000043:mdna:32]
•the impacts on our business due to component shortages, disruptions in transportation or other supply chain related constraints including as a result of the COVID-19 pandemic;

[0000866374-21-000043:mdna:33]
[same as prior period, unchanged from 0000866374-21-000019:mdna:34]

[0000866374-21-000043:mdna:34]
[same as prior period, unchanged from 0000866374-21-000019:mdna:35]

[0000866374-21-000043:mdna:35]
•the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, and other factors;

[0000866374-21-000043:mdna:36]
[same as prior period, unchanged from 0000866374-21-000019:mdna:38]

[0000866374-21-000043:mdna:37]
[same as prior period, unchanged from 0000866374-21-000019:mdna:39]

[0000866374-21-000043:mdna:38]
[same as prior period, unchanged from 0000866374-21-000019:mdna:40]

[0000866374-21-000043:mdna:39]
[same as prior period, unchanged from 0000866374-21-000019:mdna:41]

[0000866374-21-000043:mdna:40]
[same as prior period, unchanged from 0000866374-21-000019:mdna:42]

[0000866374-21-000043:mdna:41]
[same as prior period, unchanged from 0000866374-21-000019:mdna:43]

[0000866374-21-000043:mdna:42]
[same as prior period, unchanged from 0000866374-21-000019:mdna:44]

[0000866374-21-000043:mdna:43]
[same as prior period, unchanged from 0000866374-21-000019:mdna:45]

[0000866374-21-000043:mdna:44]
[same as prior period, unchanged from 0000866374-21-000019:mdna:46]

[0000866374-21-000043:mdna:45]
[same as prior period, unchanged from 0000866374-21-000019:mdna:47]

[0000866374-21-000043:mdna:46]
We are also subject to other risks as outlined in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended March 31, 2021 and in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0000866374-21-000043:mdna:47]
[same as prior period, unchanged from 0000866374-21-000019:mdna:49]

[0000866374-21-000043:mdna:48]
[same as prior period, unchanged from 0000866374-21-000019:mdna:50]

[0000866374-21-000043:mdna:49]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0000866374-21-000043:mdna:50]
[same as prior period, unchanged from 0000866374-21-000019:mdna:52]

[0000866374-21-000043:mdna:51]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0000866374-21-000043:mdna:52]
26

[0000866374-21-000043:mdna:53]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of sales | 92.6 |  |  | 94.1 |  |  |  |  |  |
| Gross profit | 7.4 |  |  | 5.9 |  |  |  |  |  |
| Selling, general and administrative expenses | 3.2 |  |  | 3.7 |  |  |  |  |  |
| Intangible amortization | 0.2 |  |  | 0.3 |  |  |  |  |  |
| Interest and other, net | 0.3 |  |  | 0.6 |  |  |  |  |  |
| Income before income taxes | 3.7 |  |  | 1.3 |  |  |  |  |  |
| Provision for income taxes | 0.4 |  |  | 0.3 |  |  |  |  |  |
| Net income | 3.3 | % |  | 1.0 | % |  |  |  |  |

[0000866374-21-000043:mdna:54]
[same as prior period, unchanged from 0000866374-21-000019:mdna:55]

[0000866374-21-000043:mdna:55]
The following table sets forth our net sales by segment, and their relative percentages:

[0000866374-21-000043:mdna:56]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |  |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,432 |  |  | 54 | % |  | $ | 2,912 |  |  | 57 | % |  |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 2,910 |  |  | 46 | % |  | 2,241 |  |  | 43 | % |  |  |  |  |  |  |  |  |
|  | $ | 6,342 |  |  |  |  | $ | 5,153 |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-21-000043:mdna:57]
Net sales during the three-month period ended July 2, 2021 totaled $6.3 billion, representing an increase of approximately $1.1 billion, or 21% from $5.2 billion during the three-month period ended June 26, 2020. Net sales for our FAS segment increased $0.5 billion, or 18%, driven by increases across all of its end markets, led by an over 40% increase in sales by our Consumer Devices business from $0.5 billion during the three-month period ended June 26, 2020 to $0.7 billion during the three-month period ended July 2, 2021, and an over 25% increase in sales by our Lifestyle business from $0.8 billion during the three-month period ended June 26, 2020 to $1.0 billion during the three-month period ended July 2, 2021. The increases were due to a lesser impact from COVID-19 production pressure during the current quarter, coupled with new ramps, customer expansions and continued recoveries in consumer spending.  Net sales for our FRS segment increased approximately $0.7 billion, or 30%, primarily due to an increase of approximately 100% in sales by our Automotive business from approximately $0.4 billion during the three-month period ended June 26, 2020 to $0.7 billion during the three-month period ended July 2, 2021, as our automotive facilities were closed for nearly half of the prior year quarter due to shutdowns by our automotive customers. The increase in our Automotive business was partially constrained by component shortages during the three-month period ended July 2, 2021. In addition, our Industrial business increased approximately 23% from $1.3 billion during the three-month period ended June 26, 2020 to $1.6 billion during the three-month period ended July 2, 2021 as a result of customer ramps and strong demand in core industrial and renewables. Net sales increased across all regions with a $0.5 billion increase to $2.6 billion in the Americas, a $0.4 billion increase to $1.4 billion in Europe, and a $0.4 billion increase to $2.4 billion in Asia.

[0000866374-21-000043:mdna:58]
Our ten largest customers during the three-month periods ended July 2, 2021 and June 26, 2020 accounted for approximately 35% and 39% of net sales, respectively.  No customer accounted for more than 10% of net sales during the three-month periods ended July 2, 2021 or June 26, 2020.

[0000866374-21-000043:mdna:59]
[same as prior period, unchanged from 0000866374-21-000019:mdna:62]

[0000866374-21-000043:mdna:60]
[same as prior period, unchanged from 0000866374-21-000019:mdna:63]

[0000866374-21-000043:mdna:61]
Cost of sales during the three-month period ended July 2, 2021 totaled $5.9 billion, representing an increase of approximately $1.1 billion, or 23% from $4.8 billion during the three-month period ended June 26, 2020. The increase in cost of sales for the three-month period ended July 2, 2021 was primarily driven by the increased consolidated sales of over $1.1 billion. Cost of sales in FAS for the three-month period ended July 2, 2021 increased 16%, or $0.4 billion from the three-month period ended June 26, 2020, which is in line with the overall 18% increase in FAS revenue during the same period primarily as a result of higher revenue in our Consumer Devices and Lifestyle businesses coupled with better fixed cost absorption, disciplined cost management as well as our continued push for new business wins and renewals at accretive margins. Cost of

[0000866374-21-000043:mdna:62]
27

[0000866374-21-000043:mdna:63]
sales in FRS for the three-month period ended July 2, 2021 increased 29%, or $0.6 billion from the three-month period ended June 26, 2020, which is in line with the overall 30% increase in FRS revenue during the same period as our Automotive and Industrial businesses benefited from stronger demand and lesser COVID-19 pressures during the current period, as discussed above.

[0000866374-21-000043:mdna:64]
[same as prior period, unchanged from 0000866374-21-000019:mdna:66]

[0000866374-21-000043:mdna:65]
Gross profit is affected by a fluctuation in cost of sales elements as outlined above and further by a number of factors, including product life cycles, unit volumes, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from both segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-21-000043:mdna:66]
Gross profit during the three-month period ended July 2, 2021 increased $0.2 billion to $0.5 billion, or 7.4% of net sales, from $0.3 billion, or 5.9% of net sales, during the three-month period ended June 26, 2020. Gross margin improved 150 basis points during the same period despite certain COVID-19 disruptions, industry-wide component shortages and cost pressures on logistics in the three-month period ended July 2, 2021. The increase in gross profit and gross margin during the current period resulted primarily from the overall stronger demand across all of our end markets which allowed for improved fixed cost absorption, coupled with continued improvement in the mix of our business and less direct and incremental unfavorable impact from COVID-19 compared to the prior year period.

[0000866374-21-000043:mdna:67]
[same as prior period, unchanged from 0000866374-21-000019:mdna:70]

[0000866374-21-000043:mdna:68]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment (recoveries), legal and other, and interest and other, net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-21-000043:mdna:69]
The following table sets forth segment income and margins:

[0000866374-21-000043:mdna:70]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |  |  |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 137 |  |  | 4.0 | % |  | $ | 72 |  |  | 2.5 | % |  |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 170 |  |  | 5.8 | % |  | 115 |  |  | 5.1 | % |  |  |  |  |  |  |  |  |

[0000866374-21-000043:mdna:71]
FAS segment margin increased 150 basis points, to 4.0% for the three-month period ended July 2, 2021, from 2.5% for the three-month period ended June 26, 2020. The margin increase was driven by an increase in demand across all of its end markets, more notably in our Consumer Devices and Lifestyle end markets due to new business wins and renewals at accretive margins, strong demand recovery from COVID-19, disciplined cost management and improved efficiencies as noted above, partially offset by the elevated costs due to component shortages and logistics constraints we faced during the three-month period ended July 2, 2021.

[0000866374-21-000043:mdna:72]
FRS segment margin increased 70 basis points, to 5.8% for the three-month period ended July 2, 2021, from 5.1% for the three-month period ended June 26, 2020. The margin increase in FRS was driven by strong demand across all of its end markets coupled with better fixed cost absorption partially offset by increased costs due to components constraints and logistics challenges in the three-month period ended July 2, 2021.

[0000866374-21-000043:mdna:73]
[same as prior period, unchanged from 0000866374-21-000019:mdna:85]

[0000866374-21-000043:mdna:74]
Selling, general and administrative expenses (“SG&A”) was $0.2 billion, or 3.2% of net sales, during the three-month period ended July 2, 2021, increasing $10 million from $0.2 billion, or 3.7% of net sales, during the three-month period ended June 26, 2020, which reflects our enhanced cost control efforts to support higher revenue growth while keeping our SG&A expenses relatively flat.

[0000866374-21-000043:mdna:75]
[same as prior period, unchanged from 0000866374-21-000019:mdna:89]

[0000866374-21-000043:mdna:76]
Amortization of intangible assets remains consistent at $15 million during the three-month periods ended July 2, 2021 and June 26, 2020.

[0000866374-21-000043:mdna:77]
[same as prior period, unchanged from 0000866374-21-000019:mdna:91]

[0000866374-21-000043:mdna:78]
Interest and other, net was $22 million during the three-month period ended July 2, 2021 compared to $31 million during the three-month period ended June 26, 2020, primarily driven by $4 million of lower expenses from our asset-backed securitization programs as we reduced outstanding balances for these programs coupled with a $4 million gain in net foreign exchanges during the first quarter of fiscal year 2022.

[0000866374-21-000043:mdna:79]
[same as prior period, unchanged from 0000866374-21-000019:mdna:94]

[0000866374-21-000043:mdna:80]
Certain of our subsidiaries, at various times, have been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 14, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021 for further discussion.

[0000866374-21-000043:mdna:81]
The consolidated effective tax rate was 12% and 23% for the three-month periods ended July 2, 2021 and June 26, 2020, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, the Netherlands and Israel. The effective tax rate for the three-month period ended July 2, 2021 is lower than the effective tax rate for the three-month periods ended June 26, 2020, primarily due to a changing jurisdictional mix of incomes and a significant amount of restructuring charges for the three-month period ended June 26, 2020 which resulted in very minimal tax benefit.

[0000866374-21-000043:mdna:82]
[same as prior period, unchanged from 0000866374-21-000019:mdna:97]

[0000866374-21-000043:mdna:83]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of July 2, 2021, we had cash and cash equivalents of approximately $2.7 billion and bank and other borrowings of approximately $3.8 billion. We have a $2.0 billion revolving credit facility that is due to mature in January 2026 (the "2026 Credit Facility"), under which we had no borrowings outstanding as of July 2, 2021. As of July 2, 2021, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-21-000043:mdna:84]
Cash provided by operating activities was $0.3 billion during the three-month period ended July 2, 2021, primarily driven by $0.2 billion of net income for the period plus $0.2 billion of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation.

[0000866374-21-000043:mdna:85]
We believe net working capital ("NWC") and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, plus inventories and contract assets, less accounts payable. Net working capital increased $0.1 billion to $3.0 billion as of July 2, 2021, from $2.9 billion as of March 31, 2021. This increase is primarily driven by a $0.5 billion increase in inventories due to component shortages and logistics constraints driving up buffer stock and inventory pricing, partially offset by a $0.3 billion decrease in net receivables and a $0.2 billion increase in accounts payable. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended July 2, 2021, increased to 11.8% from 11.5% of annualized net sales for the quarter ended March 31, 2021. We expect to operate in this range going forward. We continue to see component shortages in the supply chain, and although we are actively managing these impacts, we expect continued working capital pressure in the near future. We expect it will take additional time to adequately drive down our inventory levels to align with the current demand environment. We are proactively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative resetting our load planning. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future as we are continuing to see increasing supply constraints and costs. We are working diligently with our partners to secure needed parts and fulfill demand.

[0000866374-21-000043:mdna:86]
Cash used in investing activities was $0.1 billion during the three-month period ended July 2, 2021. This was primarily driven by $0.1 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Health Solutions and Industrial businesses.

[0000866374-21-000043:mdna:87]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. During fiscal year 2021, we proactively and strategically reduced the outstanding balance of our ABS programs. As this decrease in cash flow reflected the change of our capital strategy, we added this back for our adjusted free cash flow calculation and also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation for fiscal year 2021. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” (Adjusted Free Cash Flow subsection) of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2021 for further discussion. Our adjusted free cash flows for the three-month period ended July 2, 2021 was an inflow of $0.2 billion compared to an outflow of $74 million for the three-month period ended June 26, 2020. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-21-000043:mdna:88]
|  | Three-Month Periods Ended |
|  | July 2, 2021 |  | June 26, 2020 |
|  | (In millions) |
| Net cash used in operating activities | $ | 334 |  |  | $ | (629) |  |
| Reduction in ABS levels and other | — |  |  | 657 |  |
| Purchases of property and equipment | (118) |  |  | (110) |  |
| Proceeds from the disposition of property and equipment | 3 |  |  | 8 |  |
| Adjusted free cash flow | $ | 219 |  |  | $ | (74) |  |

[0000866374-21-000043:mdna:89]
Cash used in financing activities was $0.2 billion during the three-month period ended July 2, 2021, which was primarily driven by $0.2 billion of cash paid for the repurchase of our ordinary shares.

[0000866374-21-000043:mdna:90]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of July 2, 2021, and March 31, 2021, approximately half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.5 billion as of March 31, 2021). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-21-000043:mdna:91]
[same as prior period, unchanged from 0000866374-21-000019:mdna:109]

[0000866374-21-000043:mdna:92]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs amounted to approximately $0.3 billion and $0.2 billion for the three-month periods ended July 2, 2021 and June 26, 2020, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-21-000043:mdna:93]
30

[0000866374-21-000043:mdna:94]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to commercial paper program, and revolving sale and repurchase of subordinated note established under the securitization facility, under which there were no borrowings outstanding as of July 2, 2021.

[0000866374-21-000043:mdna:95]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also have the ability to sell a designated pool of trade receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed.

[0000866374-21-000043:mdna:96]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-21-000043:mdna:97]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $0.5 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 7, 2020. During the three-month period ended July 2, 2021, we paid $0.2 billion to repurchase shares under the current repurchase plans at an average price of $17.97 per share. As of July 2, 2021, shares in the aggregate amount of $0.2 billion were available to be repurchased under the current plan.

[0000866374-21-000043:mdna:98]
[same as prior period, unchanged from 0000866374-21-000019:mdna:116]

[0000866374-21-000043:mdna:99]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2021.

[0000866374-21-000043:mdna:100]
There were no material changes in our contractual obligations and commitments since March 31, 2021.

[0000866374-21-000043:mdna:101]
[same as prior period, unchanged from 0000866374-21-000019:mdna:120]

[0000866374-21-000043:mdna:102]
As of July 2, 2021, and March 31, 2021, the outstanding balance on receivables sold for cash was $0.2 billion, respectively, under our accounts receivable factoring program, which were removed from accounts receivable balances in our condensed consolidated balance sheets. There were no outstanding balance of receivables sold under our ABS programs as of each of the period presented. For further information, see note 9 to the condensed consolidated financial statements.
