# FLEX notes — 0000866374-21-000043


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-21-000043:notes:1]
[same as prior period, unchanged from 0000866374-21-000019:notes:1]

[0000866374-21-000043:notes:2]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across approximately 30 countries and responsible, sustainable operations, the Company delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. In order to drive efficiency and productivity the Company is organized around two focused and complementary delivery models, which also represent its operating and reportable segments:

[0000866374-21-000043:notes:3]
[same as prior period, unchanged from 0000866374-21-000019:notes:3]

[0000866374-21-000043:notes:4]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure;

[0000866374-21-000043:notes:5]
[same as prior period, unchanged from 0000866374-21-000019:notes:5]

[0000866374-21-000043:notes:6]
[same as prior period, unchanged from 0000866374-21-000019:notes:6]

[0000866374-21-000043:notes:7]
[same as prior period, unchanged from 0000866374-21-000019:notes:7]

[0000866374-21-000043:notes:8]
[same as prior period, unchanged from 0000866374-21-000019:notes:8]

[0000866374-21-000043:notes:9]
[same as prior period, unchanged from 0000866374-21-000019:notes:9]

[0000866374-21-000043:notes:10]
◦Industrial, including capital equipment, industrial devices, renewable including our Nextracker business, grid edge, and power systems.

[0000866374-21-000043:notes:11]
[same as prior period, unchanged from 0000866374-21-000019:notes:11]

[0000866374-21-000043:notes:12]
[same as prior period, unchanged from 0000866374-21-000019:notes:12]

[0000866374-21-000043:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2021 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended July 2, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022. Beginning in the second quarter of fiscal year 2021, the Company began reporting all dollar amounts in millions. In certain circumstances, this change in rounding resulted in line items being removed within prior year disclosures. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

[0000866374-21-000043:notes:14]
The first quarters for fiscal years 2022 and 2021 ended on July 2, 2021, which is comprised of 93 days in the period, and June 26, 2020, which is comprised of 87 days in the period, respectively.

[0000866374-21-000043:notes:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

[0000866374-21-000043:notes:16]
[same as prior period, unchanged from 0000866374-21-000019:notes:18]

[0000866374-21-000043:notes:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic, there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to COVID-19. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-21-000043:notes:18]
Recently Adopted Accounting Pronouncement

[0000866374-21-000043:notes:19]
In October 2020, the FASB issued ASU 2020-10 "Codification Improvements", which improves consistency by amending the Codification to include all disclosure guidance in the appropriate disclosure sections and clarifies application of various provisions in the Codification by amending and adding new headings, cross referencing to other guidance, and refining or correcting terminology. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.

[0000866374-21-000043:notes:20]
In January 2020, the FASB issued ASU 2020-01 "Investments - Equity Securities (Topic 321), Investments - Equity Method and Joint Ventures (Topic 323), and Derivatives and Hedging (Topic 815): Clarifying the Interactions Between Topic 321, Topic 323, and Topic 815 — a consensus of the FASB Emerging Issues Task Force," which makes improvements related to the following two topics: (1) accounting for certain equity securities when the equity method of accounting is applied or discontinued, and (2) scope considerations related to forward contracts and purchased options on certain securities. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.

[0000866374-21-000043:notes:21]
In December 2019, the FASB issued ASU 2019-12 "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes," which removes certain exceptions for recognizing deferred taxes for investments, performing intra-period allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted the guidance during the first quarter of fiscal year 2022 with an immaterial impact on its consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-21-000043:notes:22]
[same as prior period, unchanged from 0000866374-21-000019:notes:28]

[0000866374-21-000043:notes:23]
[same as prior period, unchanged from 0000866374-21-000019:notes:29]

[0000866374-21-000043:notes:24]
|  | As of July 2, 2021 |  | As of March 31, 2021 |
|  | (In millions) |
| Raw materials | $ | 3,344 |  |  | $ | 2,831 |  |
| Work-in-progress | 454 |  |  | 459 |  |
| Finished goods | 646 |  |  | 605 |  |
|  | $ | 4,444 |  |  | $ | 3,895 |  |

[0000866374-21-000043:notes:25]
[same as prior period, unchanged from 0000866374-21-000019:notes:31]

[0000866374-21-000043:notes:26]
During the three-month period ended July 2, 2021, there was no activity in the Company's goodwill account for each of its reporting units, other than foreign currency translation adjustments of $3.0 million and $1.0 million, which impacted its Automotive and Health Solutions reporting units, respectively.

[0000866374-21-000043:notes:27]
[same as prior period, unchanged from 0000866374-21-000019:notes:35]

[0000866374-21-000043:notes:28]
|  | As of July 2, 2021 |  | As of March 31, 2021 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 278 |  |  | $ | (163) |  |  | $ | 115 |  |  | $ | 276 |  |  | $ | (154) |  |  | $ | 122 |  |
| Licenses and other intangibles | 250 |  |  | (166) |  |  | 84 |  |  | 250 |  |  | (159) |  |  | 91 |  |
| Total | $ | 528 |  |  | $ | (329) |  |  | $ | 199 |  |  | $ | 526 |  |  | $ | (313) |  |  | $ | 213 |  |

[0000866374-21-000043:notes:29]
[same as prior period, unchanged from 0000866374-21-000019:notes:37]

[0000866374-21-000043:notes:30]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2022 (1) |  | $ | 39 |  |
| 2023 |  | 46 |  |
| 2024 |  | 45 |  |
| 2025 |  | 40 |  |
| 2026 |  | 18 |  |
| Thereafter |  | 11 |  |
| Total amortization expense |  | $ | 199 |  |

[0000866374-21-000043:notes:31]
[same as prior period, unchanged from 0000866374-21-000019:notes:39]

[0000866374-21-000043:notes:32]
(1)Represents estimated amortization for the remaining fiscal nine-month period ending March 31, 2022.

[0000866374-21-000043:notes:33]
Other Current Liabilities
Other current liabilities include customer working capital advances of $564.9 million and $471.5 million, customer-related accruals of $245.4 million and $242.0 million, and current operating lease liabilities of $129.6 million and $127.6 million as of July 2, 2021 and March 31, 2021, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-21-000043:notes:34]
[same as prior period, unchanged from 0000866374-21-000019:notes:42]

[0000866374-21-000043:notes:35]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-21-000043:notes:36]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result,

[0000866374-21-000043:notes:37]
revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-21-000043:notes:38]
[same as prior period, unchanged from 0000866374-21-000019:notes:46]

[0000866374-21-000043:notes:39]
[same as prior period, unchanged from 0000866374-21-000019:notes:47]

[0000866374-21-000043:notes:40]
[same as prior period, unchanged from 0000866374-21-000019:notes:48]

[0000866374-21-000043:notes:41]
[same as prior period, unchanged from 0000866374-21-000019:notes:49]

[0000866374-21-000043:notes:42]
[same as prior period, unchanged from 0000866374-21-000019:notes:50]

[0000866374-21-000043:notes:43]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-21-000043:notes:44]
[same as prior period, unchanged from 0000866374-21-000019:notes:53]

[0000866374-21-000043:notes:45]
[same as prior period, unchanged from 0000866374-21-000019:notes:54]

[0000866374-21-000043:notes:46]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities, identified as deferred revenue, were $489.9 million and $435.4 million as of July 2, 2021 and March 31, 2021, respectively, of which $425.2 million and $376.5 million, respectively, is included in other current liabilities.

[0000866374-21-000043:notes:47]
[same as prior period, unchanged from 0000866374-21-000019:notes:56]

[0000866374-21-000043:notes:48]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended July 2, 2021 and June 26, 2020, respectively.

[0000866374-21-000043:notes:49]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
| Timing of Transfer | (In millions) |  |  |  |  |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,248 |  |  | $ | 2,446 |  |  |  |  |  |
| Over time | 184 |  |  | 466 |  |  |  |  |  |
| Total | 3,432 |  |  | 2,912 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,403 |  |  | 1,323 |  |  |  |  |  |
| Over time | 507 |  |  | 918 |  |  |  |  |  |
| Total | 2,910 |  |  | 2,241 |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,651 |  |  | 3,769 |  |  |  |  |  |
| Over time | 691 |  |  | 1,384 |  |  |  |  |  |
| Total | $ | 6,342 |  |  | $ | 5,153 |  |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-21-000043:notes:50]
[same as prior period, unchanged from 0000866374-21-000019:notes:59]

[0000866374-21-000043:notes:51]
[same as prior period, unchanged from 0000866374-21-000019:notes:60]

[0000866374-21-000043:notes:52]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
|  | (In millions) |  |  |  |  |
| Cost of sales | $ | 5 |  |  | $ | 4 |  |  |  |  |  |
| Selling, general and administrative expenses | 15 |  |  | 9 |  |  |  |  |  |
| Total share-based compensation expense | $ | 20 |  |  | $ | 13 |  |  |  |  |  |

[0000866374-21-000043:notes:53]
Total number of options outstanding and exercisable were immaterial as of July 2, 2021. All options have been fully expensed as of July2, 2021.

[0000866374-21-000043:notes:54]
During the three-month period ended July 2, 2021, the Company granted 5.2 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 4.4 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, and with an average grant date price of $18.26 per award. In addition, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $18.24 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of 0.8 million based on a measurement of the Company's earnings per shares growth over a certain specified period, and will cliff vest after a period of three years, to the extent such performance conditions have been met. Further, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $25.86 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 0.8 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-21-000043:notes:55]
As of July 2, 2021, approximately 16.4 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 3.1 million shares is contingent on meeting certain market conditions and of which vesting for a targeted amount of 0.4 million shares is contingent on meeting certain performance conditions. The number of shares tied to market condition that will ultimately be issued can range from zero to 6.2 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to 0.8 million based on the achievement

[0000866374-21-000043:notes:56]
levels. During the three-month period ended July 2, 2021, no shares vested in connection with the awards with market conditions granted in fiscal year 2019.

[0000866374-21-000043:notes:57]
As of July 2, 2021, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $199.4 million, and will be recognized over a weighted-average remaining vesting period of 2.2 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-21-000043:notes:58]
[same as prior period, unchanged from 0000866374-21-000019:notes:67]

[0000866374-21-000043:notes:59]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
|  | (In millions, except per share amounts) |  |  |  |  |
| Basic earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 206 |  |  | $ | 52 |  |  |  |  |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 491 |  |  | 498 |  |  |  |  |  |
| Basic earnings per share | $ | 0.42 |  |  | $ | 0.10 |  |  |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |
| Net income | $ | 206 |  |  | $ | 52 |  |  |  |  |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 491 |  |  | 498 |  |  |  |  |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 8 |  |  | 4 |  |  |  |  |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 499 |  |  | 502 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.41 |  |  | $ | 0.10 |  |  |  |  |  |

[0000866374-21-000043:notes:60]
(1)1.1 million and 3.2 million RSU awards for the three-month periods ended July 2, 2021 and June 26, 2020, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## flex:InterestAndOtherNetTextBlock

[0000866374-21-000043:notes:61]
INTEREST AND OTHER, NET 
Interest and other, net for the three-month periods ended July 2, 2021 and June 26, 2020 are primarily composed of the following:

[0000866374-21-000043:notes:62]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 39 |  |  | $ | 33 |  |  |  |  |  |
| Interest income | (4) |  |  | (3) |  |  |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-21-000043:notes:63]
[same as prior period, unchanged from 0000866374-21-000019:notes:85]

[0000866374-21-000043:notes:64]
[same as prior period, unchanged from 0000866374-21-000019:notes:86]

[0000866374-21-000043:notes:65]
As of July 2, 2021, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $9.1 billion as summarized below:

[0000866374-21-000043:notes:66]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| CNY |  | 3,886 |  |  | — |  |  | $ | 601 |  |  | $ | — |  |
| EUR |  | 34 |  |  | 60 |  |  | 41 |  |  | 71 |  |
| HUF |  | 36,601 |  |  | — |  |  | 124 |  |  | — |  |
| JPY |  | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN |  | 6,191 |  |  | — |  |  | 311 |  |  | — |  |
| MYR |  | 428 |  |  | 102 |  |  | 103 |  |  | 24 |  |
| Other |  | N/A |  | N/A |  | 176 |  |  | 37 |  |
|  |  |  |  |  |  | 1,656 |  |  | 132 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |
| BRL |  | 16 |  |  | 496 |  |  | 3 |  |  | 99 |  |
| CAD |  | 110 |  |  | 65 |  |  | 89 |  |  | 52 |  |
| CNY |  | 4,236 |  |  | 706 |  |  | 655 |  |  | 109 |  |
| EUR |  | 1,675 |  |  | 1,812 |  |  | 1,989 |  |  | 2,158 |  |
| GBP |  | 55 |  |  | 77 |  |  | 76 |  |  | 106 |  |
| HUF |  | 59,137 |  |  | 54,761 |  |  | 200 |  |  | 185 |  |
| ILS |  | 473 |  |  | — |  |  | 145 |  |  | — |  |
| MXN |  | 6,470 |  |  | 5,032 |  |  | 325 |  |  | 253 |  |
| MYR |  | 738 |  |  | 277 |  |  | 177 |  |  | 66 |  |
| SEK |  | 497 |  |  | 584 |  |  | 59 |  |  | 68 |  |
| SGD |  | 91 |  |  | 49 |  |  | 68 |  |  | 37 |  |
| Other |  | N/A |  | N/A |  | 233 |  |  | 111 |  |
|  |  |  |  |  |  | 4,019 |  |  | 3,244 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 5,675 |  |  | $ | 3,376 |  |

[0000866374-21-000043:notes:67]
As of July 2, 2021, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of July 2, 2021 and March 31, 2021, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were immaterial as of July 2, 2021, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-21-000043:notes:68]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of July 2, 2021. The changes in fair value of the USD JPY cross currency swap are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also impacts the same line.

[0000866374-21-000043:notes:69]
[same as prior period, unchanged from 0000866374-21-000019:notes:91]

[0000866374-21-000043:notes:70]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | July 2,2021 |  | March 31,2021 |  | Balance SheetLocation |  | July 2,2021 |  | March 31,2021 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 23 |  |  | $ | 23 |  |  | Other current liabilities |  | $ | 12 |  |  | $ | 16 |  |
| Foreign currency contracts | Other assets |  | $ | 1 |  |  | $ | 5 |  |  | Other liabilities |  | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 28 |  |  | $ | 31 |  |  | Other current liabilities |  | $ | 30 |  |  | $ | 32 |  |

[0000866374-21-000043:notes:71]
[same as prior period, unchanged from 0000866374-21-000019:notes:93]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-21-000043:notes:72]
[same as prior period, unchanged from 0000866374-21-000019:notes:94]

[0000866374-21-000043:notes:73]
|  | Three-Month Periods Ended |
|  | July 2, 2021 |  | June 26, 2020 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |  | $ | (82) |  |  | $ | (133) |  |  | $ | (215) |  |
| Other comprehensive gain before reclassifications | 12 |  |  | 6 |  |  | 18 |  |  | 18 |  |  | 14 |  |  | 32 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (9) |  |  | (1) |  |  | (10) |  |  | 12 |  |  | — |  |  | 12 |  |
| Net current-period other comprehensive gain | 3 |  |  | 5 |  |  | 8 |  |  | 30 |  |  | 14 |  |  | 44 |  |
| Ending balance | $ | (39) |  |  | $ | (72) |  |  | $ | (111) |  |  | $ | (52) |  |  | $ | (119) |  |  | $ | (171) |  |

[0000866374-21-000043:notes:74]
Substantially all unrealized losses and gains relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended July 2, 2021were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-21-000043:notes:75]
[same as prior period, unchanged from 0000866374-21-000019:notes:98]

[0000866374-21-000043:notes:76]
[same as prior period, unchanged from 0000866374-21-000019:notes:99]

[0000866374-21-000043:notes:77]
The Company sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” and together with the Global Program, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells a fraction of the receivables to unaffiliated financial institutions, based on the Company's requirements. Under these programs, the entire purchase price of sold receivables are paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The fair value of the guarantee obligation was immaterial as of July 2, 2021 and March 31, 2020, respectively. The accounts receivable balances sold under the ABS Programs were removed from the condensed consolidated balance sheets and the cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-21-000043:notes:78]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are legally isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which have the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are uncommitted and amount to $500 million for the Global Program and $250 million for the North American Program.

[0000866374-21-000043:notes:79]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month periods ended July 2, 2021 and June 26, 2020 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-21-000043:notes:80]
As of July 2, 2021 and March 31, 2021, no accounts receivable had been sold under the ABS programs.

[0000866374-21-000043:notes:81]
For the three-month period ended June 26, 2020, cash flows from sales of receivables from the special purpose entities to unaffiliated financial institutions, consisted of approximately $0.5 billion for transfer of receivables. The Company's cash flows from transfers of receivables in fiscal year 2021 consisted primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-21-000043:notes:82]
Trade Accounts Receivable Sale Programs
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.2 billion as of July 2, 2021 and March 31, 2021. For the three-month periods ended July 2, 2021 and June 26, 2020, total accounts receivable sold to certain third-party banking institutions was approximately $0.2 billion and $0.3 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-21-000043:notes:83]
[same as prior period, unchanged from 0000866374-21-000019:notes:107]

[0000866374-21-000043:notes:84]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of July 2, 2021 and March 31, 2021.

[0000866374-21-000043:notes:85]
[same as prior period, unchanged from 0000866374-21-000019:notes:110]

[0000866374-21-000043:notes:86]
[same as prior period, unchanged from 0000866374-21-000019:notes:111]

[0000866374-21-000043:notes:87]
[same as prior period, unchanged from 0000866374-21-000019:notes:112]

[0000866374-21-000043:notes:88]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other noncurrent assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-21-000043:notes:89]
[same as prior period, unchanged from 0000866374-21-000019:notes:114]

[0000866374-21-000043:notes:90]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of July 2, 2021 and March 31, 2021.

[0000866374-21-000043:notes:91]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended July 2, 2021 and June 26, 2020.

[0000866374-21-000043:notes:92]
[same as prior period, unchanged from 0000866374-21-000019:notes:117]

[0000866374-21-000043:notes:93]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of July 2, 2021 and March 31, 2021:

[0000866374-21-000043:notes:94]
|  | Fair Value Measurements as of July 2, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,759 |  |  | $ | — |  |  | $ | 1,759 |  |
| Foreign currency contracts (Note 7) | — |  |  | 52 |  |  | — |  |  | 52 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 7) | $ | — |  |  | $ | (42) |  |  | $ | — |  |  | $ | (42) |  |
|  | Fair Value Measurements as of March 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,507 |  |  | $ | — |  |  | $ | 1,507 |  |
| Foreign currency contracts (Note 7) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 7) | $ | — |  |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |

[0000866374-21-000043:notes:95]
[same as prior period, unchanged from 0000866374-21-000019:notes:120]

[0000866374-21-000043:notes:96]
[same as prior period, unchanged from 0000866374-21-000019:notes:121]

[0000866374-21-000043:notes:97]
|  | As of July 2, 2021 |  | As of March 31, 2021 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 534 |  |  | $ | 500 |  |  | $ | 537 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.500% | 302 |  |  | 302 |  |  | 305 |  |  | 305 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 669 |  |  | 598 |  |  | 670 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 693 |  |  | 758 |  |  | 694 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 660 |  |  | 764 |  |  | 661 |  |  | 756 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 693 |  |  | 806 |  |  | 694 |  |  | 800 |  |  | Level 1 |
| Euro Term Loans | 170 |  |  | 170 |  |  | 168 |  |  | 168 |  |  | Level 2 |
| India Facilities | 133 |  |  | 133 |  |  | 133 |  |  | 133 |  |  | Level 2 |

[0000866374-21-000043:notes:98]
The Notes due February 2023, June 2025, February 2026, June 2029 and May 2030 are valued based on broker trading prices in active markets.

[0000866374-21-000043:notes:99]
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans based on the current market rate, and as of July 2, 2021, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-21-000043:notes:100]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-21-000043:notes:101]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued for any individual matter are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-21-000043:notes:102]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-21-000043:notes:103]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements, may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

[0000866374-21-000043:notes:104]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process. On September 26, 2019, the Court appointed a new lead plaintiff and lead plaintiff’s counsel in the case. On November 8, 2019, lead plaintiff filed a further amended complaint. On December 4, 2019, defendants filed a motion to dismiss the amended complaint. On May 29, 2020, the Court granted defendants’ motion to dismiss without prejudice and gave lead plaintiff 30 days to amend. On June 29, 2020, lead plaintiff filed a further amended complaint. On July 27, 2020, defendants filed a motion to dismiss the amended complaint. On December 10, 2020, the Court granted defendants’ motion to dismiss with prejudice and entered judgment in favor of defendants. On January 7, 2021, lead plaintiff filed a notice of appeal to the Ninth Circuit Court of Appeals. On May 19, 2021, lead plaintiff filed its opening appeal brief, and on July 19, 2021, defendants filed their answering brief. Lead plaintiff’s reply brief is due September 8, 2021. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-21-000043:notes:105]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-21-000043:notes:106]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 387.5 million Brazilian reals (approximately USD $77.2 million based on the exchange rate as of July 2, 2021). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 61.7 million Brazilian reals or USD $12.3 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 37.6 million Brazilian reals (approximately USD $7.5 million). The Company believes there is no legal basis for any of these assessments and that is has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

[0000866374-21-000043:notes:107]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company is currently reviewing those transactions and expects to submit an update to its submission to OFAC once that review is complete. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-21-000043:notes:108]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $163.9 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-21-000043:notes:109]
A different foreign Tax Authority had issued a letter against one of the Company’s legal entities asserting that the entity did not meet the qualification criteria for tax holiday status for fiscal year 2006 through fiscal year 2013. The asserted additional tax and penalty is approximately $80.0 million. The Company disagreed with the Tax Authority’s assertion but agreed with the Tax Authority to settle the issue for an immaterial amount. This immaterial amount was accrued for during the fourth quarter of fiscal year 2021 and is expected to be paid during the first half of fiscal year 2022.

[0000866374-21-000043:notes:110]
As the final resolutions of the above tax items remain uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-21-000043:notes:111]
In November 2019, the Company received a favorable ruling from the Brazilian Supreme Court in a case against the Brazilian tax authorities regarding the right to exclude the value of a state tax referred to as ICMS from the calculation of a federal operational tax basis referred to as PIS/COFINS. The ruling allowed the Company the right to recover amounts unduly paid from February 2003 to December 2019. As a result, the Company recorded an immaterial gain in fiscal year 2020 for the recovery of taxes. The Receita Federal, a tax authority in Brazil, filed a Motion of Clarification on a leading case with the Brazilian Supreme Court previously in 2017 and in May 2021, the Brazilian Supreme Court ruled in favor of the taxpayers and specifically clarified that the ICMS taxes to be excluded from the PIS/COFINS tax basis are to be based on the amount stated on the sales invoice irrespective of any further discounts received from the state. As a result of this ruling, which further reinforced the favorable ruling received in November 2019, the Company initiated the request for Credit Habilitation with the tax authorities in June 2021 to request additional PIS/COFINS credit recovery in the amount of 776.7 million Brazilian reals (approximately USD $154.8 million based on the exchange rate as of July 2, 2021). However, the nature of our credits requested for Habilitation were not specifically addressed by the May 2021 ruling, and accordingly there remains uncertainty regarding the Company’s ability to recover these credits. The Company considers the recovery of these credits to be a contingent gain in accordance with ASC 450, Contingencies, and has not recorded a gain for the recovery in the three-month period ended July 2, 2021 as it has not resolved all contingencies to conclude a realized or realizable amount. The amount and timing of recognition of the gain recovery is dependent upon the decision from the relevant tax authorities in regards to our application for Credit Habilitation and may have a material impact to our consolidated financial statements. We expect that this contingency could be resolved as early as the second quarter of fiscal year 2022. Additional taxes may also result from the credit recovery we receive subsequently.

[0000866374-21-000043:notes:112]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-21-000043:notes:113]
SHARE REPURCHASES 
During the three-month period ended July 2, 2021, the Company repurchased 9.0 million shares at an aggregate purchase price of $162.2 million, and retired all of these shares.

[0000866374-21-000043:notes:114]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500.0 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of Annual General Meeting held on August 7, 2020. As of July 2, 2021, shares in the aggregate amount of $154.3 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-21-000043:notes:115]
SEGMENT REPORTING
The Company reports its financial performance based on two operating and reportable segments, Flex Agility Solutions (“FAS”) and Flex Reliability Solutions (“FRS”) and analyzes operating income as the measure of segment profitability. The determination of these segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-21-000043:notes:116]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairment (recoveries), legal and other, and interest and other, net. A portion of depreciation is allocated to the respective segment, together with other general corporate research and development and administrative expenses.

[0000866374-21-000043:notes:117]
Selected financial information by segment is in the table below.

[0000866374-21-000043:notes:118]
|  | Three-Month Periods Ended |  |  |
|  | July 2, 2021 |  | June 26, 2020 |  |  |  |  |
|  | (In millions) |  |  |  |  |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,432 |  |  | $ | 2,912 |  |  |  |  |  |
| Flex Reliability Solutions | 2,910 |  |  | 2,241 |  |  |  |  |  |
|  | $ | 6,342 |  |  | $ | 5,153 |  |  |  |  |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 137 |  |  | $ | 72 |  |  |  |  |  |
| Flex Reliability Solutions | 170 |  |  | 115 |  |  |  |  |  |
| Corporate and Other | (17) |  |  | (24) |  |  |  |  |  |
| Total segment income | 290 |  |  | 163 |  |  |  |  |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 15 |  |  | 15 |  |  |  |  |  |
| Stock-based compensation | 20 |  |  | 13 |  |  |  |  |  |
| Restructuring charges | — |  |  | 10 |  |  |  |  |  |
| Legal and other (1) | — |  |  | 27 |  |  |  |  |  |
| Interest and other, net | 22 |  |  | 31 |  |  |  |  |  |
| Income before income taxes | $ | 233 |  |  | $ | 67 |  |  |  |  |  |

[0000866374-21-000043:notes:119]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as customer related asset recoveries. During the first quarter of fiscal year 2021, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-21-000043:notes:120]
[same as prior period, unchanged from 0000866374-21-000019:notes:156]

[0000866374-21-000043:notes:121]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled in the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segment nor reported by segment to the Company's CODM.
