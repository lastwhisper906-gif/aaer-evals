# FLEX 8-K — 0001104659-17-026949 filed 2017-04-27

## item codes, every 8-K on or before 2017-05-16

- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2017-05-16

- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-17-026949:8k_2_02:1]
EX-99.1
2
a17-11912_1ex99d1.htm
EX-99.1

[0001104659-17-026949:8k_2_02:2]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:3]
| Renee Brotherton | Kevin Kessel |
| Corporate Communications | Investor Relations |
| (408) 576-7189 | (408) 576-7985 |
| renee.brotherton@flex.com | kevin.kessel@flex.com |

[0001104659-17-026949:8k_2_02:4]
FLEX REPORTS FOURTH QUARTER AND FISCAL 2017 RESULTS

[0001104659-17-026949:8k_2_02:5]
·                  Portfolio evolution continues to drive shift to higher margin businesses

[0001104659-17-026949:8k_2_02:6]
·                  Quarterly revenue of $5.9 billion, increasing 2% year-over-year and at high end of revenue guidance

[0001104659-17-026949:8k_2_02:7]
·                  GAAP diluted EPS of $0.16, Non-GAAP diluted EPS of $0.29

[0001104659-17-026949:8k_2_02:8]
·                  Fiscal year cash flow from operations of $1.1 billion and free cash flow of $660 million

[0001104659-17-026949:8k_2_02:9]
·                  Maintains commitment to return value to shareholders

[0001104659-17-026949:8k_2_02:10]
San Jose, CA, April 27, 2017 — Flex (NASDAQ: FLEX), the Sketch-to-Scale™ solutions provider that designs and builds intelligent products for a connected world, today announced results for its fourth quarter and fiscal year ended March 31, 2017.

[0001104659-17-026949:8k_2_02:11]
“We remain committed to our Sketch-to-Scale strategy and are thrilled to have delivered 14 straight quarters of year-over-year operating margin expansion,” said Mike McNamara, CEO at Flex. “We have built a business model that generates outstanding cash flow consistently year after year. We have generated positive operating cash flow in 23 of our past 24 quarters. For the year, cash flow from operations totaled $1.15 billion and free cash flow was $660 million.”

[0001104659-17-026949:8k_2_02:12]
|  |  | Three-Month Periods Ended |  | Twelve Month Periods Ended |  |
| (US$ in millions, except EPS) |  | March 31, 2017 |  | March 31, 2016 |  | March 31, 2017 |  | March 31, 2016 |  |
| Net sales |  | $ | 5,863 |  | $ | 5,773 |  | $ | 23,863 |  | $ | 24,419 |  |
| GAAP income before income taxes |  | $ | 99 |  | $ | 69 |  | $ | 371 |  | $ | 455 |  |
| Adjusted operating income |  | $ | 205 |  | $ | 200 |  | $ | 815 |  | $ | 792 |  |
| GAAP net income |  | $ | 87 |  | $ | 61 |  | $ | 320 |  | $ | 444 |  |
| Adjusted net income |  | $ | 156 |  | $ | 161 |  | $ | 640 |  | $ | 645 |  |
| GAAP EPS |  | $ | 0.16 |  | $ | 0.11 |  | $ | 0.59 |  | $ | 0.79 |  |
| Adjusted EPS |  | $ | 0.29 |  | $ | 0.29 |  | $ | 1.17 |  | $ | 1.14 |  |

[0001104659-17-026949:8k_2_02:13]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:14]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release.

[0001104659-17-026949:8k_2_02:15]
Fourth Quarter Fiscal 2017 Results of Operations

[0001104659-17-026949:8k_2_02:16]
Net sales for the fourth quarter ended March 31, 2017 were approximately $5.9 billion, which was at the high end of our guidance range of $5.5 to $5.9 billion.

[0001104659-17-026949:8k_2_02:17]
GAAP income before income taxes was $99 million for the quarter and adjusted operating income was $205 million, above the mid-point of the guidance range of $185 million to $215 million.

[0001104659-17-026949:8k_2_02:18]
Net income on a GAAP basis was approximately $87 million and adjusted net income for the quarter was $156 million. GAAP EPS was $0.16 for the quarter and non-GAAP EPS was $0.29 for the quarter.

[0001104659-17-026949:8k_2_02:19]
Fiscal Year 2017 Results of Operations

[0001104659-17-026949:8k_2_02:20]
Net sales for the fiscal year ended March 31, 2017 were $23.9 billion. Fiscal year 2017 GAAP income before income tax was $371 million and fiscal year 2017 adjusted operating income was $815 million. GAAP EPS was $0.59 and adjusted earnings per diluted share was $1.17 for fiscal year 2017.

[0001104659-17-026949:8k_2_02:21]
Flex’s fiscal year 2017 performance illustrates its portfolio evolution to higher margin businesses. The Company’s two higher margin business groups, High Reliability Solutions (HRS) and Industrial & Emerging Industries (IEI), combined were $9.1 billion or 38% of net sales in the fiscal year ended March 31, 2017, a $537 million increase from a year ago.

[0001104659-17-026949:8k_2_02:22]
Cash Flow and Balance Sheet

[0001104659-17-026949:8k_2_02:23]
For the twelve-month period ended March 31, 2017, Flex generated net cash from operations of $1.1 billion and free cash flow of $660 million.  Strong cash flow generation has funded share repurchases of approximately $90 million and $350 million for the three and twelve-month periods ended March 31, 2017, respectively.  The Company remains committed to return over 50% of annual free cash flow to its shareholders.  Flex ended the quarter with $1.8 billion of cash on hand and total debt of $3.0 billion.  The balance sheet remains strong and is well-positioned to support the business over the long term.

[0001104659-17-026949:8k_2_02:24]
Q1 Fiscal Year 2018 Guidance & Business Outlook

[0001104659-17-026949:8k_2_02:25]
For the first quarter ending June 30, 2017, revenue is expected to be in the range of $5.7 to $6.1 billion, GAAP EPS is expected to be in the range of $0.16 to $0.20 and includes stock-based compensation expense ($0.04), and intangible amortization ($0.04).  The Company expects some increased levels of investment in the next couple of quarters to support its long-term vision and growth, while maintaining its commitment to return value to shareholders.  Adjusted EPS is expected to be in the range of $0.24 to $0.28 per diluted share and reflects the increased level of investment.

[0001104659-17-026949:8k_2_02:26]
Conference Calls and Web Casts

[0001104659-17-026949:8k_2_02:27]
A conference call hosted by the Flex management team will be held today at 2:00 PM (PT) / 5:00 PM (ET) to discuss the Company’s financial results for the fourth quarter ended March 31, 2017. The conference call will be broadcast via the Internet and may be accessed by logging on to the Company’s website at www.flex.com. Additional information in the form of a slide presentation may also be found on the Company’s site. A replay of the broadcast will remain available on the Company’s website afterwards.

[0001104659-17-026949:8k_2_02:28]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:29]
About Flex

[0001104659-17-026949:8k_2_02:30]
Flex Ltd. (Reg. No. 199002645H) is the Sketch-to-Scale™ solutions provider that designs and builds intelligent products for a connected world. With approximately 200,000 professionals across 30 countries, Flex provides innovative design, engineering, manufacturing, real-time supply chain insight and logistics services to companies of all sizes in various industries and end-markets. For more information, visit flex.com or follow us on Twitter @Flexintl. Flex — Live Smarter™

[0001104659-17-026949:8k_2_02:31]
# # #

[0001104659-17-026949:8k_2_02:32]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:33]
SCHEDULE I

[0001104659-17-026949:8k_2_02:34]
FLEX

[0001104659-17-026949:8k_2_02:35]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-17-026949:8k_2_02:36]
(In thousands, except per share amounts)

[0001104659-17-026949:8k_2_02:37]
|  |  | Three-Month Periods Ended |  |
|  |  | March 31, 2017 |  | March 31, 2016 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 5,862,597 |  | $ | 5,772,698 |  |
| Cost of sales |  | 5,460,827 |  | 5,366,361 |  |
| Restructuring charges |  | 16,966 |  | — |  |
| Gross profit |  | 384,804 |  | 406,337 |  |
| Selling, general and administrative expenses |  | 229,467 |  | 288,092 |  |
| Restructuring charges |  | 3,469 |  | — |  |
| Intangible amortization |  | 19,078 |  | 22,848 |  |
| Interest and other, net |  | 27,663 |  | 24,687 |  |
| Other charges, net |  | 6,186 |  | 1,481 |  |
| Income before income taxes |  | 98,941 |  | 69,229 |  |
| Provision for income taxes |  | 12,067 |  | 7,885 |  |
| Net income |  | $ | 86,874 |  | $ | 61,344 |  |
| Earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.16 |  | $ | 0.11 |  |
| Non-GAAP |  | $ | 0.29 |  | $ | 0.29 |  |
| Diluted shares used in computing per share amounts |  | 540,782 |  | 552,828 |  |

[0001104659-17-026949:8k_2_02:38]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release.

[0001104659-17-026949:8k_2_02:39]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:40]
FLEX

[0001104659-17-026949:8k_2_02:41]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-17-026949:8k_2_02:42]
(In thousands, except per share amounts)

[0001104659-17-026949:8k_2_02:43]
|  |  | Twelve-Month Periods Ended |  |
|  |  | March 31, 2017 |  | March 31, 2016 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 23,862,934 |  | $ | 24,418,885 |  |
| Cost of sales |  | 22,303,231 |  | 22,810,824 |  |
| Restructuring charges |  | 38,758 |  | — |  |
| Gross profit |  | 1,520,945 |  | 1,608,061 |  |
| Selling, general and administrative expenses |  | 937,339 |  | 954,890 |  |
| Restructuring charges |  | 10,637 |  | — |  |
| Intangible amortization |  | 81,396 |  | 65,965 |  |
| Interest and other, net |  | 99,532 |  | 84,793 |  |
| Other charges, net |  | 21,193 |  | 47,738 |  |
| Income before income taxes |  | 370,848 |  | 454,675 |  |
| Provision for income taxes |  | 51,284 |  | 10,594 |  |
| Net income |  | $ | 319,564 |  | $ | 444,081 |  |
| Earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.59 |  | $ | 0.79 |  |
| Non-GAAP |  | $ | 1.17 |  | $ | 1.14 |  |
| Diluted shares used in computing per share amounts |  | 546,220 |  | 564,869 |  |

[0001104659-17-026949:8k_2_02:44]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release.

[0001104659-17-026949:8k_2_02:45]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:46]
SCHEDULE II

[0001104659-17-026949:8k_2_02:47]
FLEX

[0001104659-17-026949:8k_2_02:48]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-17-026949:8k_2_02:49]
(In thousands, except per share amounts)

[0001104659-17-026949:8k_2_02:50]
|  |  | Three-Month Periods Ended |  |
|  |  | March 31, 2017 |  | March 31, 2016 |  |
| GAAP gross profit |  | $ | 384,804 |  | $ | 406,337 |  |
| Stock-based compensation expense |  | 2,517 |  | 2,546 |  |
| Restructuring and other (2) |  | 31,735 |  | — |  |
| Non-GAAP gross profit |  | $ | 419,056 |  | $ | 408,883 |  |
| GAAP income before income taxes |  | $ | 98,941 |  | $ | 69,229 |  |
| Stock-based compensation expense |  | 14,956 |  | 21,021 |  |
| Restructuring and other (2) |  | 38,138 |  | — |  |
| Intangible amortization |  | 19,078 |  | 22,848 |  |
| Interest and other, net |  | 27,663 |  | 24,687 |  |
| Other charges, net |  | 6,186 |  | 1,481 |  |
| SunEdison bankruptcy (3) |  | — |  | 61,006 |  |
| Non-GAAP operating income |  | $ | 204,962 |  | $ | 200,272 |  |
| GAAP provision for income taxes |  | $ | 12,067 |  | $ | 7,885 |  |
| Intangible amortization benefit |  | 1,725 |  | 1,660 |  |
| Tax benefit on intangible assets |  | — |  | 3,705 |  |
| Tax benefit on restructuring and other |  | 1,132 |  | — |  |
| Non-GAAP provision for income taxes |  | $ | 14,924 |  | $ | 13,250 |  |
| GAAP net income |  | $ | 86,874 |  | $ | 61,344 |  |
| Stock-based compensation expense |  | 14,956 |  | 21,021 |  |
| Restructuring and other (2) |  | 38,138 |  | — |  |
| Intangible amortization |  | 19,078 |  | 22,848 |  |
| Adjustments for taxes |  | (2,857 | ) | (5,365 | ) |
| SunEdison bankruptcy (3) |  | — |  | 61,006 |  |
| Non-GAAP net income |  | $ | 156,189 |  | $ | 160,854 |  |
| Diluted earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.16 |  | $ | 0.11 |  |
| Non-GAAP |  | $ | 0.29 |  | $ | 0.29 |  |

[0001104659-17-026949:8k_2_02:51]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:52]
FLEX

[0001104659-17-026949:8k_2_02:53]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-17-026949:8k_2_02:54]
(In thousands, except per share amounts)

[0001104659-17-026949:8k_2_02:55]
|  |  | Twelve-Month Periods Ended |  |
|  |  | March 31, 2017 |  | March 31, 2016 |  |
| GAAP gross profit |  | $ | 1,520,945 |  | $ | 1,608,061 |  |
| Stock-based compensation expense |  | 10,023 |  | 8,986 |  |
| SunEdison bankruptcy (3) |  | 92,915 |  | — |  |
| Restructuring and other (2) |  | 53,527 |  | — |  |
| Non-GAAP gross profit |  | $ | 1,677,410 |  | $ | 1,617,047 |  |
| GAAP income before income taxes |  | $ | 370,848 |  | $ | 454,675 |  |
| Stock-based compensation expense |  | 82,266 |  | 77,580 |  |
| Restructuring and other (2) |  | 67,099 |  | — |  |
| Intangible amortization |  | 81,396 |  | 65,965 |  |
| Interest and other, net |  | 99,532 |  | 84,793 |  |
| Other charges, net (4) |  | 21,193 |  | 47,738 |  |
| SunEdison bankruptcy (3) |  | 92,915 |  | 61,006 |  |
| Non-GAAP operating income |  | $ | 815,249 |  | $ | 791,757 |  |
| GAAP provision for income taxes |  | $ | 51,284 |  | $ | 10,594 |  |
| Intangible amortization benefit |  | 7,176 |  | 5,404 |  |
| Tax benefit on intangible assets (5) |  | 638 |  | 43,029 |  |
| Tax benefit on restructuring and other |  | 3,012 |  | — |  |
| Non-GAAP provision for income taxes |  | $ | 62,110 |  | $ | 59,027 |  |
| GAAP net income |  | $ | 319,564 |  | $ | 444,081 |  |
| Stock-based compensation expense |  | 82,266 |  | 77,580 |  |
| Restructuring and other (2) |  | 67,099 |  | — |  |
| Intangible amortization |  | 81,396 |  | 65,965 |  |
| SunEdison bankruptcy (3) |  | 92,915 |  | 61,006 |  |
| Other charges, net (4) |  | 7,388 |  | 44,415 |  |
| Adjustments for taxes (5) |  | (10,826 | ) | (48,433 | ) |
| Non-GAAP net income |  | $ | 639,802 |  | $ | 644,614 |  |
| Diluted earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.59 |  | $ | 0.79 |  |
| Non-GAAP |  | $ | 1.17 |  | $ | 1.14 |  |

[0001104659-17-026949:8k_2_02:56]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:57]
SCHEDULE III

[0001104659-17-026949:8k_2_02:58]
FLEX

[0001104659-17-026949:8k_2_02:59]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-17-026949:8k_2_02:60]
(In thousands)

[0001104659-17-026949:8k_2_02:61]
|  |  | As of March 31, 2017 |  | As of March 31, 2016 |  |
| ASSETS |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,830,675 |  | $ | 1,607,570 |  |
| Accounts receivable, net of allowance for doubtful accounts |  | 2,192,704 |  | 2,044,757 |  |
| Inventories |  | 3,396,462 |  | 3,491,656 |  |
| Other current assets |  | 967,935 |  | 1,171,143 |  |
| Total current assets |  | 8,387,776 |  | 8,315,126 |  |
| Property and equipment, net |  | 2,317,026 |  | 2,257,633 |  |
| Goodwill and other intangible assets, net |  | 1,347,048 |  | 1,345,820 |  |
| Other assets |  | 541,513 |  | 466,402 |  |
| Total assets |  | $ | 12,593,363 |  | $ | 12,384,981 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 61,534 |  | $ | 65,166 |  |
| Accounts payable |  | 4,484,908 |  | 4,248,292 |  |
| Accrued payroll |  | 344,245 |  | 353,547 |  |
| Other current liabilities |  | 1,613,940 |  | 1,905,200 |  |
| Total current liabilities |  | 6,504,627 |  | 6,572,205 |  |
| Long-term debt, net of current portion |  | 2,890,609 |  | 2,709,389 |  |
| Other liabilities |  | 519,851 |  | 497,857 |  |
| Total shareholders’ equity |  | 2,678,276 |  | 2,605,530 |  |
| Total liabilities and shareholders’ equity |  | $ | 12,593,363 |  | $ | 12,384,981 |  |

[0001104659-17-026949:8k_2_02:62]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:63]
SCHEDULE IV

[0001104659-17-026949:8k_2_02:64]
FLEX

[0001104659-17-026949:8k_2_02:65]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-17-026949:8k_2_02:66]
(In thousands)

[0001104659-17-026949:8k_2_02:67]
|  |  | Twelve-Months Periods Ended |  |
|  |  | March 31, 2017 |  | March 31, 2016 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income |  | $ | 319,564 |  | $ | 444,081 |  |
| Depreciation, amortization and other impairment charges |  | 609,660 |  | 515,367 |  |
| Changes in working capital and other |  | 220,685 |  | 176,997 |  |
| Net cash provided by operating activities |  | 1,149,909 |  | 1,136,445 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property and equipment |  | (525,111 | ) | (510,634 | ) |
| Proceeds from the disposition of property and equipment |  | 35,606 |  | 13,676 |  |
| Acquisition of businesses, net of cash acquired |  | (189,084 | ) | (916,527 | ) |
| Proceeds from divestiture of business, net of cash held in divested business |  | 36,731 |  | 5,740 |  |
| Other investing activities, net |  | (60,329 | ) | 11,369 |  |
| Net cash used in investing activities |  | (702,187 | ) | (1,396,376 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 312,741 |  | 884,702 |  |
| Repayments of bank borrowings and long-term debt |  | (141,730 | ) | (190,221 | ) |
| Payments for repurchases of ordinary shares |  | (349,532 | ) | (420,317 | ) |
| Net proceeds from issuance of ordinary shares |  | 12,438 |  | 61,278 |  |
| Other financing activities, net |  | (76,024 | ) | (85,800 | ) |
| Net cash (used in) provided by financing activities |  | (242,107 | ) | 249,642 |  |
| Effect of exchange rates on cash and cash equivalents |  | 17,490 |  | (10,549 | ) |
| Net increase in cash and cash equivalents |  | 223,105 |  | (20,838 | ) |
| Cash and cash equivalents, beginning of period |  | 1,607,570 |  | 1,628,408 |  |
| Cash and cash equivalents, end of period |  | $ | 1,830,675 |  | $ | 1,607,570 |  |

[0001104659-17-026949:8k_2_02:68]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:69]
SCHEDULE V

[0001104659-17-026949:8k_2_02:70]
FLEX AND SUBSIDIARIES

[0001104659-17-026949:8k_2_02:71]
NOTES TO SCHEDULES I, II, III, & IV

[0001104659-17-026949:8k_2_02:72]
(1)   To supplement Flex’s unaudited selected financial data presented on a basis consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude stock-based compensation expense, restructuring charges, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies.  We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-17-026949:8k_2_02:73]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-17-026949:8k_2_02:74]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-17-026949:8k_2_02:75]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-17-026949:8k_2_02:76]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-17-026949:8k_2_02:77]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-17-026949:8k_2_02:78]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-17-026949:8k_2_02:79]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types.  In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-17-026949:8k_2_02:80]
Restructuring and other primarily includes severance for rationalization at existing sites and corporate SG&A functions as well as non-cash impairment of certain assets. These costs may vary in size based on the Company’s initiatives, and are not directly related to ongoing or core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends, and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-17-026949:8k_2_02:81]
Inventory impairment and other consists primarily of non-cash impairment of certain solar panel inventory on hand to net realizable value. These costs are excluded by the Company’s management in

[0001104659-17-026949:8k_2_02:82]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:83]
assessing current operating performance and forecasting its earnings trends, and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-17-026949:8k_2_02:84]
Bad debt expense is comprised of additional provisions for doubtful accounts receivable for customers that are experiencing significant financial difficulties.  These costs are excluded by the Company’s management in assessing its current operating performance and forecasting its earnings trends, and accordingly, are excluded by the Company from its non-GAAP measures.

[0001104659-17-026949:8k_2_02:85]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions.  The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-17-026949:8k_2_02:86]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies when applicable.

[0001104659-17-026949:8k_2_02:87]
Other charges, net consists of various other types of items that are not directly related to ongoing or core business results, such as the non-cash foreign currency impact from certain divestitures and impairment charges associated with non-core investments.  We exclude these items because they are not related to the Company’s ongoing operating performance or do not affect core operations.  Excluding these amounts provide investors with a basis to compare Company performance against the performance of other companies without this variability.

[0001104659-17-026949:8k_2_02:88]
For the twelve-month period ended March 31, 2017, Free Cash Flow was $660 million consisting of GAAP net cash flows from operating activities of $1.1 billion less purchases of property and equipment net of proceeds from dispositions of $490 million. We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash flows provided by operating activities.”

[0001104659-17-026949:8k_2_02:89]
(2)         During fiscal year 2017, the Company initiated a restructuring plan to accelerate its ability to support more Sketch-to-ScaleTM efforts across the Company and reposition away from historical legacy programs and structures through rationalizing its current footprint at existing sites and at corporate SG&A functions. In addition, certain asset impairments were also recorded in three-month period ended March 31, 2017. Approximately $38.1 million was recognized in the quarter ended March 31, 2017 and $67.1 million was recognized for the twelve-month period ending March 31, 2017.

[0001104659-17-026949:8k_2_02:90]
(3)         On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, “SunEdison”), filed a petition for reorganization under bankruptcy law. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million according to the amount the Company originally invoiced. During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory previously designated for SunEdison on hand at the end of the second quarter of fiscal year 2017 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market during fiscal year 2017. The Company also recognized a $16.0 million impairment charge for solar module equipment and $16.9 million primarily related to negative margin sales and other associated solar panel direct costs incurred during the same period. The total charge of $92.9 million for fiscal year 2017 is included in cost of sales.

[0001104659-17-026949:8k_2_02:91]
(4)         The twelve months ended March 31, 2017 includes a $7.4 million loss attributable to a non-strategic facility sold during the second quarter of fiscal 2017.

[0001104659-17-026949:8k_2_02:92]
The twelve months ended March 31, 2016 includes $25 million of non-cash foreign currency translation loss attributable to the sale of a non-strategic Western European manufacturing facility and a $22 million impairment of a non-core investment.

[0001104659-17-026949:8k_2_02:93]
P R E S S   R E L E A S E

[0001104659-17-026949:8k_2_02:94]
(5)         The twelve months ended March 31, 2017 includes a $0.6 million benefit for the release of valuation allowance on certain of our deferred tax assets resulting from an immaterial acquisition.

[0001104659-17-026949:8k_2_02:95]
The twelve months ended March 31, 2016 includes a $42 million benefit for the release of valuation allowances on certain of our deferred tax assets resulting from our acquisition of the NEXTracker business in September 2015.
