# FLEX notes — 0000866374-17-000005


## flex:BasisOfPresentationAndPrinciplesOfConsolidationPolicyTextBlock

[0000866374-17-000005:notes:1]
Basis of Presentation and Principles of Consolidation

[0000866374-17-000005:notes:2]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of March 31, 2017, the noncontrolling interest has been included on the consolidated balance sheets as a component of total shareholders' equity. The associated noncontrolling owners' interest in the income or losses of these companies is classified as a component of interest and other, net, in the consolidated statements of operations.

[0000866374-17-000005:notes:3]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has an ownership percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.


## flex:InterestAndOtherNetTextBlock

[0000866374-17-000005:notes:4]
INTEREST AND OTHER, NET

[0000866374-17-000005:notes:5]
For the fiscal years ended March 31, 2017, 2016 and 2015, the Company recognized interest income of $12.1 million, $12.3 million and $18.7 million.

[0000866374-17-000005:notes:6]
For the fiscal years ended March 31, 2017, 2016 and 2015, the Company recognized interest expense of $108.0 million, $98.0 million and $76.4 million, respectively, on its debt obligations outstanding during the period.

[0000866374-17-000005:notes:7]
For the fiscal years ended March 31, 2017, 2016 and 2015, the Company recognized gains on foreign exchange transactions of $16.5 million, $24.4 million and $19.7 million, respectively.

[0000866374-17-000005:notes:8]
For the fiscal years ended March 31, 2017, 2016 and 2015, the Company recognized $15.3 million, $11.0 million and $9.9 million of expense related to its ABS and AR Sales Programs.


## flex:ScheduleOfShareBonusAwardsWithMarketConditionsTableTextBlock

[0000866374-17-000005:notes:9]
Of the 15.7 million unvested share bonus awards outstanding under the 2010 Plan as of the fiscal year ended 2017, approximately 2.1 million of unvested share bonus awards under the 2010 Plan represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-17-000005:notes:10]
|  |  | Targetednumber ofawards as ofMarch 31, 2017(in shares) |  |  |  |  |  | Range of sharesthat may be issued |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment dates |
| Year of grant |  | Market condition |  | Minimum |  | Maximum |  |
| Fiscal 2017 |  | 722,213 |  |  | $ | 17.57 |  |  | Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against both the Standard and Poor's ("S&P") 500 Composite Index and an Extended Electronics Manufacturing Services ("EMS") Group Index. |  | — |  |  | 1,444,426 |  |  | May 2019 |
| Fiscal 2016 |  | 712,977 |  |  | $ | 14.96 |  |  | Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against both the S&P 500 Composite Index and an EMS Group Index. |  | — |  |  | 1,425,954 |  |  | May 2018 |
| Fiscal 2015 |  | 686,520 |  |  | $ | 14.77 |  |  | Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against both the S&P 500 Composite Index and an EMS Group Index. |  | — |  |  | 1,373,040 |  |  | May 2017 |
| Totals |  | 2,121,710 |  |  |  |  |  |  |  |  |  |  | 4,243,420 |  |  |  |


## flex:ScheduleOfTaxLossesAndOtherCarryforwardsTableTextBlock

[0000866374-17-000005:notes:11]
These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-17-000005:notes:12]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
|  | (In thousands) |
| 2018 - 2023 | $ | 682,705 |  |
| 2024 - 2029 | 925,092 |  |
| 2030 and post | 378,047 |  |
| Indefinite | 404,763 |  |
|  | $ | 2,390,607 |  |


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0000866374-17-000005:notes:13]
The following table summarizes the activity in the deferred purchase price receivables account during the fiscal years ended March 31, 2017 and 2016:

[0000866374-17-000005:notes:14]
|  | As of March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Beginning balance | $ | 501,097 |  |  | $ | 600,672 |  |
| Transfers of receivables | 3,254,849 |  |  | 3,475,400 |  |
| Collections | (3,249,424 | ) |  | (3,574,975 | ) |
| Ending balance | $ | 506,522 |  |  | $ | 501,097 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0000866374-17-000005:notes:15]
SUPPLEMENTAL GUARANTOR AND NON-GUARANTOR CONSOLIDATED FINANCIAL STATEMENTS

[0000866374-17-000005:notes:16]
Flex Ltd. ("Parent") has three tranches of Notes of $500 million, $500 million and $600 million, respectively, each outstanding, which mature on February 15, 2020, February 15, 2023 and June 15, 2025, respectively. These notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade, provided that each rating agency confirms that the Notes will continue to be rated investment grade after the Note Guaranties are terminated.

[0000866374-17-000005:notes:17]
In lieu of providing separate financial statements for the guarantor subsidiaries, the Company has included the accompanying condensed consolidating financial statements, which are presented using the equity method of accounting. The principal elimination entries relate to investment in subsidiaries and intercompany balances and transactions, including transactions with the Company's non-guarantor subsidiaries.

[0000866374-17-000005:notes:18]
Condensed Consolidating Balance Sheets as of March 31, 2017

[0000866374-17-000005:notes:19]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 561,555 |  |  | $ | 169,083 |  |  | $ | 1,100,037 |  |  | $ | — |  |  | $ | 1,830,675 |  |
| Accounts receivable | — |  |  | 875,842 |  |  | 1,316,862 |  |  | — |  |  | 2,192,704 |  |
| Inventories | — |  |  | 1,523,578 |  |  | 1,872,884 |  |  | — |  |  | 3,396,462 |  |
| Inter company receivable | 10,951,993 |  |  | 7,527,058 |  |  | 14,575,412 |  |  | (33,054,463 | ) |  | — |  |
| Other current assets | 683 |  |  | 181,602 |  |  | 785,650 |  |  | — |  |  | 967,935 |  |
| Total current assets | 11,514,231 |  |  | 10,277,163 |  |  | 19,650,845 |  |  | (33,054,463 | ) |  | 8,387,776 |  |
| Property and equipment, net | — |  |  | 601,918 |  |  | 1,715,108 |  |  | — |  |  | 2,317,026 |  |
| Goodwill and other intangible assets, net | 1,214 |  |  | 119,255 |  |  | 1,226,579 |  |  | — |  |  | 1,347,048 |  |
| Other assets | 2,218,599 |  |  | 228,343 |  |  | 2,041,373 |  |  | (3,946,802 | ) |  | 541,513 |  |
| Investment in subsidiaries | 3,071,296 |  |  | 3,543,990 |  |  | 16,029,346 |  |  | (22,644,632 | ) |  | — |  |
| Total assets | $ | 16,805,340 |  |  | $ | 14,770,669 |  |  | $ | 40,663,251 |  |  | $ | (59,645,897 | ) |  | $ | 12,593,363 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 56,177 |  |  | $ | 977 |  |  | $ | 4,380 |  |  | $ | — |  |  | $ | 61,534 |  |
| Accounts payable | — |  |  | 1,758,660 |  |  | 2,726,248 |  |  | — |  |  | 4,484,908 |  |
| Accrued payroll | — |  |  | 101,206 |  |  | 243,039 |  |  | — |  |  | 344,245 |  |
| Inter company payable | 11,282,477 |  |  | 9,882,088 |  |  | 11,889,898 |  |  | (33,054,463 | ) |  | — |  |
| Other current liabilities | 23,851 |  |  | 776,280 |  |  | 813,809 |  |  | — |  |  | 1,613,940 |  |
| Total current liabilities | 11,362,505 |  |  | 12,519,211 |  |  | 15,677,374 |  |  | (33,054,463 | ) |  | 6,504,627 |  |
| Long term liabilities | 2,798,302 |  |  | 2,156,994 |  |  | 2,401,966 |  |  | (3,946,802 | ) |  | 3,410,460 |  |
| Flex Ltd. shareholders' equity | 2,644,533 |  |  | 94,464 |  |  | 22,550,168 |  |  | (22,644,632 | ) |  | 2,644,533 |  |
| Noncontrolling interests | — |  |  | — |  |  | 33,743 |  |  | — |  |  | 33,743 |  |
| Total shareholders' equity | 2,644,533 |  |  | 94,464 |  |  | 22,583,911 |  |  | (22,644,632 | ) |  | 2,678,276 |  |
| Total liabilities and shareholders' equity | $ | 16,805,340 |  |  | $ | 14,770,669 |  |  | $ | 40,663,251 |  |  | $ | (59,645,897 | ) |  | $ | 12,593,363 |  |

[0000866374-17-000005:notes:20]
Condensed Consolidating Balance Sheets as of March 31, 2016

[0000866374-17-000005:notes:21]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 734,869 |  |  | $ | 148,201 |  |  | $ | 724,500 |  |  | $ | — |  |  | $ | 1,607,570 |  |
| Accounts receivable | — |  |  | 729,331 |  |  | 1,315,426 |  |  | — |  |  | 2,044,757 |  |
| Inventories | — |  |  | 1,482,410 |  |  | 2,009,246 |  |  | — |  |  | 3,491,656 |  |
| Inter company receivable | 9,105,728 |  |  | 5,568,392 |  |  | 12,404,722 |  |  | (27,078,842 | ) |  | — |  |
| Other current assets | 2,951 |  |  | 180,842 |  |  | 987,350 |  |  | — |  |  | 1,171,143 |  |
| Total current assets | 9,843,548 |  |  | 8,109,176 |  |  | 17,441,244 |  |  | (27,078,842 | ) |  | 8,315,126 |  |
| Property and equipment, net | — |  |  | 553,072 |  |  | 1,704,561 |  |  | — |  |  | 2,257,633 |  |
| Goodwill and other intangible assets, net | 175 |  |  | 60,895 |  |  | 1,284,750 |  |  | — |  |  | 1,345,820 |  |
| Other assets | 2,249,145 |  |  | 267,034 |  |  | 2,004,437 |  |  | (4,054,214 | ) |  | 466,402 |  |
| Investment in subsidiaries | 2,815,426 |  |  | 2,987,909 |  |  | 18,175,348 |  |  | (23,978,683 | ) |  | — |  |
| Total assets | $ | 14,908,294 |  |  | $ | 11,978,086 |  |  | $ | 40,610,340 |  |  | $ | (55,111,739 | ) |  | $ | 12,384,981 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 58,836 |  |  | $ | 946 |  |  | $ | 5,384 |  |  | $ | — |  |  | $ | 65,166 |  |
| Accounts payable | — |  |  | 1,401,835 |  |  | 2,846,457 |  |  | — |  |  | 4,248,292 |  |
| Accrued payroll | — |  |  | 114,509 |  |  | 239,038 |  |  | — |  |  | 353,547 |  |
| Inter company payable | 9,562,405 |  |  | 7,999,335 |  |  | 9,517,102 |  |  | (27,078,842 | ) |  | — |  |
| Other current liabilities | 33,008 |  |  | 869,470 |  |  | 1,002,722 |  |  | — |  |  | 1,905,200 |  |
| Total current liabilities | 9,654,249 |  |  | 10,386,095 |  |  | 13,610,703 |  |  | (27,078,842 | ) |  | 6,572,205 |  |
| Long term liabilities | 2,683,173 |  |  | 2,063,988 |  |  | 2,514,299 |  |  | (4,054,214 | ) |  | 3,207,246 |  |
| Flex Ltd. shareholders' equity | 2,570,872 |  |  | (471,997 | ) |  | 24,450,680 |  |  | (23,978,683 | ) |  | 2,570,872 |  |
| Noncontrolling interests | — |  |  | — |  |  | 34,658 |  |  | — |  |  | 34,658 |  |
| Total shareholders' equity | 2,570,872 |  |  | (471,997 | ) |  | 24,485,338 |  |  | (23,978,683 | ) |  | 2,605,530 |  |
| Total liabilities and shareholders' equity | $ | 14,908,294 |  |  | $ | 11,978,086 |  |  | $ | 40,610,340 |  |  | $ | (55,111,739 | ) |  | $ | 12,384,981 |  |

[0000866374-17-000005:notes:22]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2017

[0000866374-17-000005:notes:23]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 15,909,037 |  |  | $ | 17,841,003 |  |  | $ | (9,887,106 | ) |  | $ | 23,862,934 |  |
| Cost of sales | — |  |  | 14,375,249 |  |  | 17,815,088 |  |  | (9,887,106 | ) |  | 22,303,231 |  |
| Restructuring charges | — |  |  | 16,908 |  |  | 21,850 |  |  | — |  |  | 38,758 |  |
| Gross profit | — |  |  | 1,516,880 |  |  | 4,065 |  |  | — |  |  | 1,520,945 |  |
| Selling, general and administrative expenses | — |  |  | 282,821 |  |  | 654,518 |  |  | — |  |  | 937,339 |  |
| Intangible amortization | 175 |  |  | 5,967 |  |  | 75,254 |  |  | — |  |  | 81,396 |  |
| Restructuring charges | — |  |  | 8,716 |  |  | 1,921 |  |  | — |  |  | 10,637 |  |
| Interest and other, net | (195,848 | ) |  | 1,102,341 |  |  | (785,768 | ) |  | — |  |  | 120,725 |  |
| Income before income taxes | 195,673 |  |  | 117,035 |  |  | 58,140 |  |  | — |  |  | 370,848 |  |
| Provision for income taxes | 11 |  |  | 23,629 |  |  | 27,644 |  |  | — |  |  | 51,284 |  |
| Equity in earnings in subsidiaries | 123,902 |  |  | (244,696 | ) |  | 233,325 |  |  | (112,531 | ) |  | — |  |
| Net income (loss) | $ | 319,564 |  |  | $ | (151,290 | ) |  | $ | 263,821 |  |  | $ | (112,531 | ) |  | $ | 319,564 |  |

[0000866374-17-000005:notes:24]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2016

[0000866374-17-000005:notes:25]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 16,841,405 |  |  | $ | 19,286,221 |  |  | $ | (11,708,741 | ) |  | $ | 24,418,885 |  |
| Cost of sales | — |  |  | 15,278,265 |  |  | 19,241,300 |  |  | (11,708,741 | ) |  | 22,810,824 |  |
| Gross profit | — |  |  | 1,563,140 |  |  | 44,921 |  |  | — |  |  | 1,608,061 |  |
| Selling, general and administrative expenses | — |  |  | 330,194 |  |  | 624,696 |  |  | — |  |  | 954,890 |  |
| Intangible amortization | 300 |  |  | 3,598 |  |  | 62,067 |  |  | — |  |  | 65,965 |  |
| Interest and other, net | (191,859 | ) |  | 1,016,302 |  |  | (691,912 | ) |  | — |  |  | 132,531 |  |
| Income before income taxes | 191,559 |  |  | 213,046 |  |  | 50,070 |  |  | — |  |  | 454,675 |  |
| Provision for income taxes | 26 |  |  | (41,584 | ) |  | 52,152 |  |  | — |  |  | 10,594 |  |
| Equity in earnings in subsidiaries | 252,548 |  |  | (173,846 | ) |  | 397,831 |  |  | (476,533 | ) |  | — |  |
| Net income | $ | 444,081 |  |  | $ | 80,784 |  |  | $ | 395,749 |  |  | $ | (476,533 | ) |  | $ | 444,081 |  |

[0000866374-17-000005:notes:26]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2015

[0000866374-17-000005:notes:27]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 19,016,750 |  |  | $ | 19,543,163 |  |  | $ | (12,411,997 | ) |  | $ | 26,147,916 |  |
| Cost of sales | — |  |  | 17,502,863 |  |  | 19,511,710 |  |  | (12,411,997 | ) |  | 24,602,576 |  |
| Gross profit | — |  |  | 1,513,887 |  |  | 31,453 |  |  | — |  |  | 1,545,340 |  |
| Selling, general and administrative expenses | — |  |  | 258,212 |  |  | 586,261 |  |  | — |  |  | 844,473 |  |
| Intangible amortization | 300 |  |  | 3,808 |  |  | 27,927 |  |  | — |  |  | 32,035 |  |
| Interest and other, net | 10,086 |  |  | 901,059 |  |  | (912,968 | ) |  | — |  |  | (1,823 | ) |
| Income (loss) before income taxes | (10,386 | ) |  | 350,808 |  |  | 330,233 |  |  | — |  |  | 670,655 |  |
| Provision for income taxes | — |  |  | 14,143 |  |  | 55,711 |  |  | — |  |  | 69,854 |  |
| Equity in earnings in subsidiaries | 611,187 |  |  | 564,105 |  |  | 471,575 |  |  | (1,646,867 | ) |  | — |  |
| Net income | $ | 600,801 |  |  | $ | 900,770 |  |  | $ | 746,097 |  |  | $ | (1,646,867 | ) |  | $ | 600,801 |  |

[0000866374-17-000005:notes:28]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2017

[0000866374-17-000005:notes:29]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 319,564 |  |  | $ | (151,290 | ) |  | $ | 263,821 |  |  | $ | (112,531 | ) |  | $ | 319,564 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (1,324 | ) |  | 103,335 |  |  | 44,421 |  |  | (147,756 | ) |  | (1,324 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax | 9,096 |  |  | 4,819 |  |  | 9,096 |  |  | (13,915 | ) |  | 9,096 |  |
| Comprehensive income (loss) | $ | 327,336 |  |  | $ | (43,136 | ) |  | $ | 317,338 |  |  | $ | (274,202 | ) |  | $ | 327,336 |  |

[0000866374-17-000005:notes:30]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2016

[0000866374-17-000005:notes:31]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income | $ | 444,081 |  |  | $ | 80,784 |  |  | $ | 395,749 |  |  | $ | (476,533 | ) |  | $ | 444,081 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 17,846 |  |  | (21,972 | ) |  | (15,735 | ) |  | 37,707 |  |  | 17,846 |  |
| Unrealized gain on derivative instruments and other, net of zero tax | 26,744 |  |  | 15,188 |  |  | 26,744 |  |  | (41,932 | ) |  | 26,744 |  |
| Comprehensive income | $ | 488,671 |  |  | $ | 74,000 |  |  | $ | 406,758 |  |  | $ | (480,758 | ) |  | $ | 488,671 |  |

[0000866374-17-000005:notes:32]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2015

[0000866374-17-000005:notes:33]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income | $ | 600,801 |  |  | $ | 900,770 |  |  | $ | 746,097 |  |  | $ | (1,646,867 | ) |  | $ | 600,801 |  |
| Other comprehensive loss: |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (18,932 | ) |  | 177,046 |  |  | 221,418 |  |  | (398,464 | ) |  | (18,932 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax | (35,417 | ) |  | (33,769 | ) |  | (35,417 | ) |  | 69,186 |  |  | (35,417 | ) |
| Comprehensive income | $ | 546,452 |  |  | $ | 1,044,047 |  |  | $ | 932,098 |  |  | $ | (1,976,145 | ) |  | $ | 546,452 |  |

[0000866374-17-000005:notes:34]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2017

[0000866374-17-000005:notes:35]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 144,580 |  |  | $ | 47,905 |  |  | $ | 957,424 |  |  | $ | — |  |  | $ | 1,149,909 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (182,132 | ) |  | (307,388 | ) |  | 15 |  |  | (489,505 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | (69,998 | ) |  | (119,086 | ) |  | — |  |  | (189,084 | ) |
| Proceeds from divestitures of business, net of cash held in divested business | — |  |  | 30,655 |  |  | 6,076 |  |  | — |  |  | 36,731 |  |
| Investing cash flows from (to) affiliates | (1,142,988 | ) |  | (3,440,099 | ) |  | 159,426 |  |  | 4,423,661 |  |  | — |  |
| Other investing activities, net | (61,212 | ) |  | (12,429 | ) |  | 13,312 |  |  | — |  |  | (60,329 | ) |
| Net cash used in investing activities | (1,204,200 | ) |  | (3,674,003 | ) |  | (247,660 | ) |  | 4,423,676 |  |  | (702,187 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 204,879 |  |  | 107,502 |  |  | 360 |  |  | — |  |  | 312,741 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations | (128,967 | ) |  | (6,695 | ) |  | (6,068 | ) |  | — |  |  | (141,730 | ) |
| Payments for repurchases of ordinary shares | (349,532 | ) |  | — |  |  | — |  |  | — |  |  | (349,532 | ) |
| Proceeds from exercise of stock options | 12,438 |  |  | — |  |  | — |  |  | — |  |  | 12,438 |  |
| Financing cash flows from (to) affiliates | 1,164,543 |  |  | 3,606,993 |  |  | (347,860 | ) |  | (4,423,676 | ) |  | — |  |
| Other financing activities, net | 30,000 |  |  | (51,902 | ) |  | (54,122 | ) |  | — |  |  | (76,024 | ) |
| Net cash provided by financing activities | 933,361 |  |  | 3,655,898 |  |  | (407,690 | ) |  | (4,423,676 | ) |  | (242,107 | ) |
| Effect of exchange rates on cash and cash equivalents | (47,055 | ) |  | (8,918 | ) |  | 73,463 |  |  | — |  |  | 17,490 |  |
| Net increase (decrease) in cash and cash equivalents | (173,314 | ) |  | 20,882 |  |  | 375,537 |  |  | — |  |  | 223,105 |  |
| Cash and cash equivalents, beginning of period | 734,869 |  |  | 148,201 |  |  | 724,500 |  |  | — |  |  | 1,607,570 |  |
| Cash and cash equivalents, end of period | $ | 561,555 |  |  | $ | 169,083 |  |  | $ | 1,100,037 |  |  | $ | — |  |  | $ | 1,830,675 |  |

[0000866374-17-000005:notes:36]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2016

[0000866374-17-000005:notes:37]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 162,275 |  |  | $ | 426,639 |  |  | $ | 547,531 |  |  | $ | — |  |  | $ | 1,136,445 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (151,383 | ) |  | (345,584 | ) |  | 9 |  |  | (496,958 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | (809,272 | ) |  | (107,255 | ) |  | — |  |  | (916,527 | ) |
| Proceeds from divestitures of business, net of cash held in divested business | — |  |  | — |  |  | 5,740 |  |  | — |  |  | 5,740 |  |
| Investing cash flows to affiliates | (1,596,210 | ) |  | (1,587,365 | ) |  | (1,509,352 | ) |  | 4,692,927 |  |  | — |  |
| Other investing activities, net | (500 | ) |  | (31,011 | ) |  | 42,880 |  |  | — |  |  | 11,369 |  |
| Net cash used in investing activities | (1,596,710 | ) |  | (2,579,031 | ) |  | (1,913,571 | ) |  | 4,692,936 |  |  | (1,396,376 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 824,618 |  |  | — |  |  | 60,084 |  |  | — |  |  | 884,702 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations | (179,920 | ) |  | (3,059 | ) |  | (7,242 | ) |  | — |  |  | (190,221 | ) |
| Payments for repurchases of ordinary shares | (420,317 | ) |  | — |  |  | — |  |  | — |  |  | (420,317 | ) |
| Proceeds from exercise of stock options | 61,278 |  |  | — |  |  | — |  |  | — |  |  | 61,278 |  |
| Financing cash flows from affiliates | 1,240,145 |  |  | 2,143,568 |  |  | 1,309,223 |  |  | (4,692,936 | ) |  | — |  |
| Other financing activities, net | — |  |  | (8,800 | ) |  | (77,000 | ) |  | — |  |  | (85,800 | ) |
| Net cash provided by financing activities | 1,525,804 |  |  | 2,131,709 |  |  | 1,285,065 |  |  | (4,692,936 | ) |  | 249,642 |  |
| Effect of exchange rates on cash and cash equivalents | 34,529 |  |  | 612 |  |  | (45,690 | ) |  | — |  |  | (10,549 | ) |
| Net increase (decrease) in cash and cash equivalents | 125,898 |  |  | (20,071 | ) |  | (126,665 | ) |  | — |  |  | (20,838 | ) |
| Cash and cash equivalents, beginning of period | 608,971 |  |  | 168,272 |  |  | 851,165 |  |  | — |  |  | 1,628,408 |  |
| Cash and cash equivalents, end of period | $ | 734,869 |  |  | $ | 148,201 |  |  | $ | 724,500 |  |  | $ | — |  |  | $ | 1,607,570 |  |

[0000866374-17-000005:notes:38]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2015

[0000866374-17-000005:notes:39]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | (73,356 | ) |  | $ | 75,775 |  |  | $ | 791,615 |  |  | $ | — |  |  | $ | 794,034 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (85,876 | ) |  | (153,833 | ) |  | (15 | ) |  | (239,724 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | (20,589 | ) |  | (46,265 | ) |  | — |  |  | (66,854 | ) |
| Investing cash flows from (to) affiliates | (1,703,983 | ) |  | (1,900,810 | ) |  | 796,493 |  |  | 2,808,300 |  |  | — |  |
| Other investing activities, net | (1,500 | ) |  | (13,821 | ) |  | 79,683 |  |  | — |  |  | 64,362 |  |
| Net cash provided by (used in) investing activities | (1,705,483 | ) |  | (2,021,096 | ) |  | 676,078 |  |  | 2,808,285 |  |  | (242,216 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 303,000 |  |  | 4,737 |  |  | 11,805 |  |  | — |  |  | 319,542 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations | (335,500 | ) |  | (3,127 | ) |  | (5,529 | ) |  | — |  |  | (344,156 | ) |
| Payments for early repurchase of long-term debt | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Payments for repurchases of ordinary shares | (415,945 | ) |  | — |  |  | — |  |  | — |  |  | (415,945 | ) |
| Proceeds from exercise of stock options | 23,497 |  |  | — |  |  | 11 |  |  | — |  |  | 23,508 |  |
| Financing cash flows from (to) affiliates | 2,420,952 |  |  | 1,904,164 |  |  | (1,516,831 | ) |  | (2,808,285 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | (98,966 | ) |  | — |  |  | (98,966 | ) |
| Net cash provided by (used in) financing activities | 1,996,004 |  |  | 1,905,774 |  |  | (1,609,510 | ) |  | (2,808,285 | ) |  | (516,017 | ) |
| Effect of exchange rates on cash and cash equivalents | (246,908 | ) |  | (2,643 | ) |  | 248,430 |  |  | — |  |  | (1,121 | ) |
| Net increase (decrease) in cash and cash equivalents | (29,743 | ) |  | (42,190 | ) |  | 106,613 |  |  | — |  |  | 34,680 |  |
| Cash and cash equivalents, beginning of period | 638,714 |  |  | 210,462 |  |  | 744,552 |  |  | — |  |  | 1,593,728 |  |
| Cash and cash equivalents, end of period | $ | 608,971 |  |  | $ | 168,272 |  |  | $ | 851,165 |  |  | $ | — |  |  | $ | 1,628,408 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-17-000005:notes:40]
SUMMARY OF ACCOUNTING POLICIES

[0000866374-17-000005:notes:41]
Use of Estimates

[0000866374-17-000005:notes:42]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; asset impairments; fair values of financial instruments including investments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; fair values of assets obtained and liabilities assumed in business combinations and the fair values of stock options and share bonus awards granted under the Company's stock-based compensation plans. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-17-000005:notes:43]
Translation of Foreign Currencies

[0000866374-17-000005:notes:44]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive loss, a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for any of the periods presented, and have been classified as a component of interest and other, net in the consolidated statements of operations.

[0000866374-17-000005:notes:45]
Revenue Recognition

[0000866374-17-000005:notes:46]
The Company recognizes manufacturing revenue when it ships goods or the goods are received by its customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then the Company recognizes the related revenues at the time when such requirements are completed and the obligations are fulfilled. Some of the Company's customer contracts allow the recovery of certain costs related to manufacturing services that are over and above the prices charged for the related products. The Company determines the amount of costs that are recoverable based on historical experiences and agreements with those customers. Also, certain customer contracts may contain certain commitments and obligations that may result in additional expenses or decrease in revenue. The Company accrues for these commitments and obligations based on facts and circumstances and contractual terms. The Company also makes provisions for estimated sales returns and other adjustments at the time revenue is recognized based upon contractual terms and an analysis of historical returns. Provisions for sales returns and other adjustments were not material to the consolidated financial statements for any of the periods presented.

[0000866374-17-000005:notes:47]
The Company also recognizes revenue in accordance with multiple-element arrangements accounting codified under U.S. GAAP for arrangements that contain multiple deliverables. The Company determined that its multiple-element arrangements are generally comprised of arrangements where multiple product components are sold together as part of a complete system. Depending on the contractual provisions of the respective contracts, the Company has concluded that the units of accounting for such arrangements are, in most cases, comprised of an aggregation of product components, however, may also be established at the product component level. For multiple-element arrangements, revenue is allocated to each unit of accounting based on their relative selling prices. Relative selling prices are based first on vendor specific objective evidence of fair value (“VSOE”), then on third-party evidence of selling price (“TPE”) when VSOE does not exist, and then on management's best estimate of the selling price (“BESP”) when VSOE and TPE do not exist. The Company bases the allocation of revenue on BESP, because the Company does not have either VSOE or TPE for the respective deliverables.

[0000866374-17-000005:notes:48]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The Company recognizes service revenue when the services have been performed, and the related costs are expensed as incurred. Sales for services were less than 10% of the Company's total sales for all periods presented, and accordingly, are included in net sales in the consolidated statements of operations. The Company recognized research and development costs primarily related to its design and innovations businesses of $65.6 million, $61.0 million, and $26.3 million for the fiscal years ended March 31, 2017, 2016 and 2015, respectively. Research and development costs for prior years have been recast to conform to fiscal year 2017 presentation.

[0000866374-17-000005:notes:49]
Concentration of Credit Risk

[0000866374-17-000005:notes:50]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, cash and cash equivalents, and derivative instruments.

[0000866374-17-000005:notes:51]
Customer Credit Risk

[0000866374-17-000005:notes:52]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-17-000005:notes:53]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison"), filed a petition for reorganization under bankruptcy law. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory previously designated for SunEdison on hand at the end of the second quarter of fiscal year 2017 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market during fiscal year 2017. In addition, the Company recognized a $16.0 million impairment charge for solar module equipment and incurred $16.9 million of incremental costs primarily related to negative margin sales and other associated solar panel direct costs. The total charge for fiscal year 2017 of $92.9 million is included in cost of sales

[0000866374-17-000005:notes:54]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2017, 2016 and 2015:

[0000866374-17-000005:notes:55]
|  | Balance atBeginningof Year |  | Charged toCosts andExpenses |  | Deductions/Write-Offs |  | Balance atEnd ofYear |
|  | (In thousands) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2015 | $ | 5,529 |  |  | $ | 650 |  |  | $ | (1,645 | ) |  | $ | 4,534 |  |
| Year ended March 31, 2016 | $ | 4,534 |  |  | $ | 72,295 |  |  | $ | (12,221 | ) |  | $ | 64,608 |  |
| Year ended March 31, 2017 | $ | 64,608 |  |  | $ | (184 | ) |  | $ | (7,122 | ) |  | $ | 57,302 |  |

[0000866374-17-000005:notes:56]
For the fiscal year ended March 31, 2016, the Company recognized a bad debt charge of $61.0 million associated with its outstanding SunEdison receivables as explained above, and another charge of $10.5 million relating to a separate distressed customer which was also written-off during the year.

[0000866374-17-000005:notes:57]
One customer (including net sales from its current and former parent companies, through the dates of their respective ownership), which is within the Company's CTG segment, accounted for approximately 11% and 17% of the Company's net sales in fiscal years 2016 and 2015, respectively, and approximately 17% and 11% of the Company's total accounts receivable balances in fiscal years 2017 and 2016, respectively. Another customer included in the Company's CEC segment, accounted for approximately 11% of the Company's total accounts receivable balance in fiscal years 2016.

[0000866374-17-000005:notes:58]
The Company's ten largest customers accounted for approximately 43%, 46% and 50%, of its net sales in fiscal years 2017, 2016 and 2015, respectively.

[0000866374-17-000005:notes:59]
Derivative Instruments

[0000866374-17-000005:notes:60]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 8.

[0000866374-17-000005:notes:61]
Cash and Cash Equivalents

[0000866374-17-000005:notes:62]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-17-000005:notes:63]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-17-000005:notes:64]
Cash and cash equivalents consisted of the following:

[0000866374-17-000005:notes:65]
|  | As of March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Cash and bank balances | $ | 763,834 |  |  | $ | 533,438 |  |
| Money market funds and time deposits | 1,066,841 |  |  | 1,074,132 |  |
|  | $ | 1,830,675 |  |  | $ | 1,607,570 |  |

[0000866374-17-000005:notes:66]
Inventories

[0000866374-17-000005:notes:67]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or market value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of lower of cost or market write-downs, were as follows:

[0000866374-17-000005:notes:68]
|  | As of March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Raw materials | $ | 2,537,623 |  |  | $ | 2,234,512 |  |
| Work-in-progress | 279,493 |  |  | 561,282 |  |
| Finished goods | 579,346 |  |  | 695,862 |  |
|  | $ | 3,396,462 |  |  | $ | 3,491,656 |  |

[0000866374-17-000005:notes:69]
Property and Equipment, Net

[0000866374-17-000005:notes:70]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are amortized over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment was comprised of the following:

[0000866374-17-000005:notes:71]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2017 |  | 2016 |
|  |  |  | (In thousands) |
| Machinery and equipment | 3 - 10 |  | $ | 3,233,392 |  |  | $ | 3,187,590 |  |
| Buildings | 30 |  | 1,237,739 |  |  | 1,144,798 |  |
| Leasehold improvements | up to 30 |  | 395,663 |  |  | 397,340 |  |
| Furniture, fixtures, computer equipment and software | 3 - 7 |  | 502,223 |  |  | 477,203 |  |
| Land | — |  | 145,663 |  |  | 127,927 |  |
| Construction-in-progress | — |  | 212,326 |  |  | 178,851 |  |
|  |  |  | 5,727,006 |  |  | 5,513,709 |  |
| Accumulated depreciation and amortization |  |  | (3,409,980 | ) |  | (3,256,076 | ) |
| Property and equipment, net |  |  | $ | 2,317,026 |  |  | $ | 2,257,633 |  |

[0000866374-17-000005:notes:72]
Total depreciation expense associated with property and equipment amounted to approximately $432.2 million, $425.7 million and $496.8 million in fiscal years 2017, 2016 and 2015, respectively.

[0000866374-17-000005:notes:73]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-17-000005:notes:74]
Deferred Income Taxes

[0000866374-17-000005:notes:75]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-17-000005:notes:76]
Accounting for Business and Asset Acquisitions

[0000866374-17-000005:notes:77]
The Company has actively pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0000866374-17-000005:notes:78]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-17-000005:notes:79]
Goodwill

[0000866374-17-000005:notes:80]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. If the recorded value of the assets, including goodwill, and liabilities ("net book value") of each reporting unit exceeds its fair value, an impairment loss may be required to be recognized. Further, to the extent the net book value of the Company as a whole is greater than its fair value in the aggregate, all, or a significant portion of its goodwill may be considered impaired.

[0000866374-17-000005:notes:81]
The Company has four reporting units, which correspond to its four reportable operating segments: HRS, CTG, IEI and CEC. The Company concluded that there was no change to its reporting units in fiscal year 2017 and performed its goodwill impairment assessment on January 1, 2017. In lieu of the qualitative "Step Zero" assessment, the Company performed a quantitative assessment of its goodwill and determined that no impairment existed as of the date of the impairment test because the fair value of each reporting unit exceeded its carrying value.

[0000866374-17-000005:notes:82]
The following table summarizes the activity in the Company's goodwill during fiscal years 2017 and 2016 (in thousands):

[0000866374-17-000005:notes:83]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Balance, as of March 31, 2015 | 93,138 |  |  | 68,234 |  |  | 64,221 |  |  | 108,038 |  |  | 333,631 |  |
| Additions (1) | 340,610 |  |  | — |  |  | 258,582 |  |  | 3,655 |  |  | 602,847 |  |
| Purchase accounting adjustments (3) | 125 |  |  | — |  |  | — |  |  | — |  |  | 125 |  |
| Foreign currency translation adjustments (4) | 5,463 |  |  | — |  |  | — |  |  | — |  |  | 5,463 |  |
| Balance, as of March 31, 2016 | $ | 439,336 |  |  | $ | 68,234 |  |  | $ | 322,803 |  |  | $ | 111,693 |  |  | $ | 942,066 |  |
| Additions (1) | — |  |  | 42,989 |  |  | 17,544 |  |  | 3,309 |  |  | 63,842 |  |
| Divestitures (2) | (1,787 | ) |  | — |  |  | (2,640 | ) |  | — |  |  | (4,427 | ) |
| Purchase accounting adjustments (3) | 794 |  |  | — |  |  | — |  |  | — |  |  | 794 |  |
| Foreign currency translation adjustments (4) | (17,408 | ) |  | — |  |  | — |  |  | — |  |  | (17,408 | ) |
| Balance, as of March 31, 2017 | $ | 420,935 |  |  | $ | 111,223 |  |  | $ | 337,707 |  |  | $ | 115,002 |  |  | $ | 984,867 |  |

[0000866374-17-000005:notes:84]
_______________________________________________________________________________

[0000866374-17-000005:notes:85]
| (1) | The goodwill generated from the Company's business combinations completed during the fiscal years 2017 and 2016 are primarily related to value placed on the employee workforce, service offerings and capabilities and expected synergies. The goodwill is not deductible for income tax purposes. Refer to the discussion of the Company's business acquisitions in note 17. |

[0000866374-17-000005:notes:86]
| (2) | During the fiscal year ended March 31, 2017, the Company disposed of two non-strategic businesses within the IEI and HRS segments, and recorded an aggregate reduction of goodwill of $4.4 million accordingly, which is included in the loss on sale recorded in other charges, net on the consolidated statement of operations. |

[0000866374-17-000005:notes:87]
| (3) | Includes adjustments based on management's estimates resulting from their review and finalization of the valuation of assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition. These adjustments were not individually, nor in the aggregate, significant to the Company. |

[0000866374-17-000005:notes:88]
| (4) | During the fiscal years ended March 31, 2017 and 2016, the Company recorded $17.4 million and $5.5 million, respectively, of foreign currency translation adjustments primarily related to the goodwill associated with the acquisition of Mirror Controls International ("MCi") in fiscal year 2016, as the U.S. Dollar fluctuated against the Euro. |

[0000866374-17-000005:notes:89]
Other Intangible Assets

[0000866374-17-000005:notes:90]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2017 and concluded that such amounts continued to be recoverable.

[0000866374-17-000005:notes:91]
Intangible assets are comprised of customer-related intangible assets, that include contractual agreements and customer relationships; and licenses and other intangible assets, that are primarily comprised of licenses and also includes patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability. The components of acquired intangible assets are as follows:

[0000866374-17-000005:notes:92]
|  | As of March 31, 2017 |  | As of March 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 260,704 |  |  | $ | (105,912 | ) |  | $ | 154,792 |  |  | $ | 223,046 |  |  | $ | (66,473 | ) |  | $ | 156,573 |  |
| Licenses and other intangibles | 283,897 |  |  | (76,508 | ) |  | 207,389 |  |  | 285,053 |  |  | (37,872 | ) |  | 247,181 |  |
| Total | $ | 544,601 |  |  | $ | (182,420 | ) |  | $ | 362,181 |  |  | $ | 508,099 |  |  | $ | (104,345 | ) |  | $ | 403,754 |  |

[0000866374-17-000005:notes:93]
The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2017, the gross carrying amounts of fully amortized intangible assets totaled $14.2 million. During fiscal year 2017, the gross carrying amount of intangible assets increased primarily in connection with the Company's acquisitions during the year. Total intangible asset amortization expense recognized in operations during fiscal years 2017, 2016 and 2015 was $81.4 million, $66.0 million and $32.0 million, respectively. As of March 31, 2017, the weighted-average remaining useful lives of the Company's intangible assets were approximately 6.6 years for both customer-related intangibles and licenses and other intangible assets. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-17-000005:notes:94]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 | $ | 68,472 |  |
| 2019 | 61,582 |  |
| 2020 | 52,439 |  |
| 2021 | 48,266 |  |
| 2022 | 39,714 |  |
| Thereafter | 91,708 |  |
| Total amortization expense | $ | 362,181 |  |

[0000866374-17-000005:notes:95]
Derivative Instruments and Hedging Activities

[0000866374-17-000005:notes:96]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Additional information is included in note 8.

[0000866374-17-000005:notes:97]
Other Current Assets

[0000866374-17-000005:notes:98]
Other current assets include approximately $506.5 million and $501.1 million as of March 31, 2017 and 2016, respectively for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0000866374-17-000005:notes:99]
In connection with a prior acquisition, the Company entered into an agreement with a customer and a third party banking institution to procure certain manufacturing equipment that was financed by the third party banking institution, acting as an agent of the customer. The manufacturing equipment was used exclusively for the benefit of this customer. During fiscal year 2015, the Company ceased manufacturing of the product related to the financed equipment. As a result, pursuant to an agreement with the customer the Company as an agent on behalf of the customer dispositioned the equipment via sales to third parties and used the proceeds to reduce the obligation to the third party banking institution. Accordingly, the residual value due from the customer related to the equipment financed by the third party banking institution was $83.6 million as of March 31, 2016, and was included in other current assets. During fiscal year 2017, the Company entered into an agreement with the third party banking institution and the customer granted a waiver of any amounts owed under the financing arrangement which allowed for a net settlement of the related asset and liability.

[0000866374-17-000005:notes:100]
Investments

[0000866374-17-000005:notes:101]
The Company has certain equity investments in, and notes receivable from, non-publicly traded companies which are included within other assets. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer; otherwise the cost method is used. Non-majority-owned investments in corporations are accounted for using the equity method when the Company has an ownership percentage equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required. Fair values of these investments, when required, are estimated using unobservable inputs, primarily comparable company multiples and discounted cash flow projections.

[0000866374-17-000005:notes:102]
As of March 31, 2017 and 2016, the Company's equity investments in non-majority owned companies totaled $200.1 million and $122.9 million, respectively. The equity in the earnings or losses of the Company's equity method investments was not material to the consolidated results of operations for any period presented and is included in interest and other, net.

[0000866374-17-000005:notes:103]
During fiscal year 2017, the Company formed a joint venture with RIB Software AG, a provider of technology for the construction industry. This joint venture will offer a fully integrated enterprise software platform for building and housing projects. The Company contributed $60.0 million for a non-controlling interest in this joint venture. This contribution, net of the Company's equity in losses, which is immaterial, is included in other assets on the condensed consolidated balance sheet. The cash outflows to pay for this investment have been included in cash flows from other investing activities during the fiscal year ended March 31, 2017.

[0000866374-17-000005:notes:104]
Other Current Liabilities

[0000866374-17-000005:notes:105]
Other current liabilities include customer working capital advances of $231.3 million and $253.7 million, customer-related accruals of $501.9 million and $479.5 million, and deferred revenue of $280.7 million and $332.3 million as of March 31, 2017 and 2016, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.

[0000866374-17-000005:notes:106]
As of March 31, 2016, other current liabilities also included the outstanding balances due to the third party banking institution related to the financed equipment discussed above of $122.0 million. As discussed above, during fiscal year 2017, the Company entered into an agreement with the third party banking institution and the customer granted a waiver of any amounts owed under the financing arrangement which provided for a net settlement of the outstanding balance of approximately $90.6 million with the related asset.

[0000866374-17-000005:notes:107]
Restructuring Charges

[0000866374-17-000005:notes:108]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and rationalize administrative functions. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-17-000005:notes:109]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed exit plans. See note 14 for additional information regarding restructuring charges.

[0000866374-17-000005:notes:110]
Recently Adopted Accounting Pronouncements

[0000866374-17-000005:notes:111]
In March 2016, the Financial Accounting Standards Board ("FASB") issued new guidance intended to reduce the cost and complexity of the accounting for share-based payments. The new guidance simplifies various aspects of the accounting for share-based payments including income tax effects, withholding requirements and forfeitures. The Company elected to early adopt this new guidance beginning in the first quarter of fiscal year 2017. The guidance eliminates additional paid in capital ("APIC") pools and requires companies to recognize all excess tax benefits and tax deficiencies in the income statement when the awards vest or are settled. It also addresses the presentation of excess tax benefits and employee taxes paid on the statement of cash flows. Prior to adoption, the Company elected to not deduct tax benefits for stock-based compensation awards on its tax returns, and accordingly, did not have any excess tax benefits or tax deficiencies upon adoption. The Company therefore determined that adoption of the new guidance had no impact on the condensed consolidated statement of operations and the condensed consolidated statement of cash flows. Further, the new guidance eliminates the requirement to estimate forfeitures and reduce stock compensation expense during the vesting period. Instead, companies can elect to account for actual forfeitures as they occur and record any previously unrecognized compensation expense for estimated forfeitures up to the period of adoption as a retrospective adjustment to beginning retained earnings. The Company has made the election to account for actual forfeitures as they occur starting in fiscal year 2017. After assessment, it was determined that the cumulative effect adjustment required under the new guidance was immaterial and therefore the Company did not record a retrospective adjustment. The Company finally determined that the adoption of this guidance did not have a significant impact on the consolidated financial position, results of operations and cash flows of the Company.

[0000866374-17-000005:notes:112]
Recently Issued Accounting Pronouncements

[0000866374-17-000005:notes:113]
In January 2017, the FASB issued new guidance to simplify the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. This guidance requires that the change be applied on a prospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2021, with early application permitted. The Company is currently assessing the impact of the new guidance and the timing of adoption.

[0000866374-17-000005:notes:114]
In January 2017, the FASB issued new guidance that changes the definition of a business to assist entities with evaluating when a set of transferred assets and activities is a business. This guidance requires that the amendments be applied on a prospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2019, with early application permitted. The guidance may result in more asset acquisitions being accounted for as purchases of assets in lieu of business combinations. The Company intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2019.

[0000866374-17-000005:notes:115]
In October 2016, the FASB issued new guidance to amend the consolidation guidance on how a reporting entity that is the single decision maker of a variable interest entity ("VIE") should treat indirect interests in the entity held through related parties that are under common control with the reporting entity when determining whether it is the primary beneficiary of that VIE. This guidance requires that the amendments be applied on a retrospective or modified retrospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2018, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2018.

[0000866374-17-000005:notes:116]
In August 2016, the FASB issued new guidance intended to address specific cash flow issues with the objective of reducing the existing diversity in practice. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early application permitted. The new guidance allows for two transition methods in application - (i) retrospective to each period presented, or (ii) if it is impracticable to apply the amendments retrospectively for some of the issues, then the amendments for those issues would be applied  prospective as of the earliest date practicable. The Company expects an immaterial impact on its consolidated financial statements. The Company is currently assessing the timing of adoption.

[0000866374-17-000005:notes:117]
In February 2016, the FASB issued new guidance intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. The Company will be required to adopt the new lease guidance beginning with the first quarter of fiscal year 2020 using a modified retrospective approach, with early adoption permitted. Upon initial evaluation, the Company believes the new guidance will have a material impact on its consolidated balance sheets when adopted. The Company is currently assessing the timing of adoption.

[0000866374-17-000005:notes:118]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018, and should be applied prospectively with early application permitted as of the beginning of an interim or annual reporting period. The Company is currently assessing the impact of this update and the timing of adoption.

[0000866374-17-000005:notes:119]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. The guidance is effective for the Company beginning in the first quarter of fiscal year 2019. The Company has assessed that the impact of the new guidance will result in a change of the Company's revenue recognition model for electronics manufacturing services from "point in time" upon physical delivery to an "over time" model and believes this transition will have a material impact on the Company's consolidated financial statements upon adoption primarily as it recognizes an increase in contract assets for unbilled receivables with a corresponding reduction in finished goods and work-in-progress inventory. The Company has commenced implementation in accordance with the planned effective date. The new guidance allows for two transition methods in application - (i) retrospective to each prior reporting period presented, or (ii) prospective with the cumulative effect of adoption recognized on April 1, 2018, the first day of the Company's fiscal year 2019. The Company has not yet concluded upon its selection of the transition method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-17-000005:notes:120]
BUSINESS AND ASSET ACQUISITIONS & DIVESTITURES

[0000866374-17-000005:notes:121]
Business Acquisitions

[0000866374-17-000005:notes:122]
The business and asset acquisitions described below were accounted for using the purchase method of accounting, and accordingly, the fair value of the net assets acquired and the results of the acquired businesses were included in the Company's consolidated financial statements from the acquisition dates forward. The Company has not finalized the allocation of the consideration for certain of its recently completed acquisitions and completes these allocations in less than one year of the respective acquisition dates.

[0000866374-17-000005:notes:123]
Fiscal year 2017 business acquisitions and divestitures

[0000866374-17-000005:notes:124]
Acquisitions

[0000866374-17-000005:notes:125]
During the fiscal year ended March 31, 2017, the Company completed four acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. Most notable is the Company’s acquisition of two manufacturing and development facilities from Bose Corporation (“Bose”), a global leader in audio systems. The acquisition expanded the Company’s capabilities in the audio market and is included in the CTG segment. The other acquired businesses strengthen the Company's capabilities in the communications market and energy market within the CEC and IEI segment, respectively. At the acquisition dates, the Company paid a total of $189.1 million, net of cash acquired, of which $161.7 million, net of $18.0 million of cash acquired is related to the Bose acquisition which is included in cash from investing activities in the consolidated statements of cash flows. The Company acquired primarily $73.1 million of inventory, $60.8 million of property and equipment, and recorded goodwill of $63.8 million and intangible assets of $47.4 million substantially related to Bose. The intangibles will amortize over a weighted-average estimated useful life of 6.5 years. In connection with these acquisitions, the Company assumed $63.3 million in other liabilities including additional consideration of $28.0 million which was paid in the fourth quarter of fiscal year 2017 and included in other financing activities in the consolidated statements of cash flows. Further, the equity incentive plan of one of the acquirees was assumed as part of the acquisition.

[0000866374-17-000005:notes:126]
The results of operations for each of the acquisitions completed in fiscal year 2017, including the Bose acquisition, were included in the Company’s consolidated financial results beginning on the date of each acquisition, and the total amount of net income and revenue of the acquisitions, collectively, were immaterial to the Company's consolidated financial results for the fiscal year ended March 31, 2017. Pro-forma results of operations for the acquisitions completed in fiscal year 2017 have not been presented because the effects, individually and in the aggregate, were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-17-000005:notes:127]
In April 2017, the Company completed the acquisition of AGM Automotive for approximately $220 million, which expanded its capabilities in the automotive market, and is included within the HRS segment. The initial purchase price allocation for this acquisition is not yet complete.

[0000866374-17-000005:notes:128]
Divestitures

[0000866374-17-000005:notes:129]
During the fiscal year ended March 31, 2017, the Company disposed of two non-strategic businesses within the HRS and IEI segments. The Company received $30.7 million of proceeds, net of an immaterial amount of cash held in one of the divested businesses. The property and equipment and various other assets sold, and liabilities transferred were not material to the Company's consolidated financial results. The loss on disposition was not material to the Company’s consolidated financial results, and is included in other charges, net in the condensed consolidated statements of operations for the fiscal year.

[0000866374-17-000005:notes:130]
Fiscal year 2016 business acquisitions

[0000866374-17-000005:notes:131]
Acquisition of Mirror Controls International

[0000866374-17-000005:notes:132]
In June 2015, the Company completed its acquisition of 100% of the outstanding share capital of MCi, and paid approximately $555.2 million, net of $27.7 million of cash acquired. This acquisition expanded the Company's capabilities in the automotive market, and was included in the HRS segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0000866374-17-000005:notes:133]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities of MCi (in thousands):

[0000866374-17-000005:notes:134]
| Current assets: |  |
| Accounts receivable | $ | 41,559 |  |
| Inventories | 19,897 |  |
| Other current assets | 2,856 |  |
| Total current assets | 64,312 |  |
| Property and equipment, net | 38,832 |  |
| Other assets | 2,463 |  |
| Intangibles | 236,800 |  |
| Goodwill | 323,357 |  |
| Total assets | $ | 665,764 |  |
| Current liabilities: |  |
| Accounts payable | $ | 28,002 |  |
| Accrued liabilities & other current liabilities | 21,113 |  |
| Total current liabilities | 49,115 |  |
| Other liabilities | 61,492 |  |
| Total aggregate purchase price | $ | 555,157 |  |

[0000866374-17-000005:notes:135]
The intangible assets of $236.8 million is comprised of customer relationships of $75.5 million and licenses and other intangible assets of $161.3 million. Customer relationships and licenses and other intangibles are each amortized over a weighted-average estimated useful life of 10 years. In addition to net working capital, the Company acquired $38.8 million of machinery and equipment and assumed $61.5 million of other liabilities primarily comprised of deferred tax liabilities. The Company incurred $6.6 million in acquisition-related costs related to the acquisition of MCi during fiscal year 2016.

[0000866374-17-000005:notes:136]
Acquisition of a facility from Alcatel-Lucent

[0000866374-17-000005:notes:137]
In July 2015, the Company acquired an optical transport facility from Alcatel-Lucent for approximately $67.5 million, which expanded its capabilities in the telecom market and was included in the CEC segment. The Company acquired primarily $55.1 million of inventory, $10.0 million of property and equipment primarily comprised of a building and land, and recorded goodwill and intangible assets for a customer relationship of $3.6 million and $2.1 million, respectively, and assumed $3.3 million in other net liabilities in connection with this acquisition. The customer relationship intangible will amortize over a weighted-average estimated useful life of 5 years.

[0000866374-17-000005:notes:138]
Acquisition of Nextracker

[0000866374-17-000005:notes:139]
In September 2015, the Company acquired 100% of the outstanding share capital of NEXTracker, a provider of smart solar tracking solutions. The initial cash consideration was approximately $240.8 million, net of $13.2 million of cash acquired, with an additional $81.0 million of estimated potential contingent consideration, for a total purchase consideration of $321.8 million. At the date of the acquisition, the maximum possible consideration under the agreement was $97.2 million upon achievement of future revenue performance targets. The Company also acquired NEXTracker’s equity incentive plan. The financial results of NEXTracker were included in the IEI segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0000866374-17-000005:notes:140]
The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of NEXTracker (in thousands):

[0000866374-17-000005:notes:141]
| Current assets: |  |
| Accounts receivable | $ | 60,298 |  |
| Inventories | 3,235 |  |
| Other current assets | 19,272 |  |
| Total current assets | 82,805 |  |
| Property and equipment, net | 1,382 |  |
| Other assets | 70 |  |
| Intangibles | 108,700 |  |
| Goodwill | 255,601 |  |
| Total assets | $ | 448,558 |  |
| Current liabilities: |  |
| Accounts payable | $ | 17,226 |  |
| Other current liabilities | 63,870 |  |
| Total current liabilities | 81,096 |  |
| Other liabilities | 45,712 |  |
| Total aggregate purchase price | $ | 321,750 |  |

[0000866374-17-000005:notes:142]
The intangible assets of $108.7 million is comprised of customer-related intangibles of $47.3 million and licenses and other intangible assets of $61.4 million. Customer-related intangibles are amortized over a weighted-average estimated useful life of 4 years while licenses and other intangibles are amortized over a weighted-average estimated useful life of 6 years.

[0000866374-17-000005:notes:143]
Other business acquisitions

[0000866374-17-000005:notes:144]
Additionally, during fiscal year 2016, the Company completed eight acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. Four of the acquired businesses expanded the Company’s capabilities in the medical devices market, particularly precision plastics and molding within the HRS segment, two of them strengthened capabilities in the consumer electronics market within the CTG segment, one strengthened the capabilities in the communications market within the CEC segment, and the last one strengthened capabilities in the household industrial and lifestyle market within the IEI segment. The Company paid $53.3 million, net of $3.7 million of cash held by the targets. The Company acquired $14.4 million of property and equipment, assumed liabilities of $17.7 million and recorded goodwill and intangibles of $57.4 million. These intangibles will amortize over a weighted-average estimated useful life of 4 years.

[0000866374-17-000005:notes:145]
The results of operations for all of the acquisitions completed in fiscal year 2016 were included in the Company’s consolidated financial results beginning on the date of each acquisition.  The total amount of net income for all of the acquisitions completed in fiscal year 2016, collectively, was $41.4 million. The total amount of revenue of these acquisitions, collectively, was not material to the Company’s consolidated financial results for the fiscal year 2016.

[0000866374-17-000005:notes:146]
On a pro-forma basis, and assuming the fiscal year 2016 acquisitions occurred on the first day of the prior period, or April 1, 2014, the Company's net income would have been estimated to be $410.1 million and $586.4 million for the fiscal years 2016 and 2015, respectively. The estimated pro-forma net income for both years does not include the $43.0 million tax benefit for the release of the valuation allowance on deferred tax assets primarily relating to the NEXTracker acquisition, recognized in fiscal year 2016, to promote comparability. Pro-forma revenue for the acquisitions in fiscal years 2016 and 2015 have not been presented because the effect, collectively, was not material to the Company’s consolidated revenues for fiscal years 2016 and 2015.

[0000866374-17-000005:notes:147]
Fiscal year 2015 business acquisitions

[0000866374-17-000005:notes:148]
During the fiscal year 2015, the Company completed four acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. All of the acquired businesses expanded the Company's capabilities in the medical devices market, particularly precision plastics, within the HRS segment. The Company paid $52.7 million net of $5.9 million of cash held by the acquired businesses, and recorded an accrual of $4.5 million for contingent consideration relating to one of the acquisitions. The Company primarily acquired $29.4 million of current assets, $9.0 million of property and equipment, recorded goodwill of $35.8 million and intangibles of $16.1 million, and assumed certain liabilities relating to payables and debt in connection with these acquisitions. The results of operations were included in the Company's consolidated financial results beginning on the date of these acquisitions. Pro-forma results of operations for these acquisitions have not been presented because the effects of the acquisitions were immaterial to the Company's consolidated financial results for all periods presented. The Company also paid $7.5 million as a deposit to acquire a certain business that closed in fiscal year 2016 and that strengthened capabilities in the household industrial market within the IEI segment. This deposit was included in other assets during fiscal year 2015.

[0000866374-17-000005:notes:149]
The Company continues to evaluate certain assets and liabilities related to business combinations completed during recent periods. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Changes to amounts recorded as assets or liabilities, as a result of such additional information, may result in a corresponding adjustment to goodwill.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-17-000005:notes:150]
SUPPLEMENTAL CASH FLOW DISCLOSURES

[0000866374-17-000005:notes:151]
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-17-000005:notes:152]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 127,346 |  |  | $ | 114,578 |  |  | $ | 87,179 |  |
| Income taxes | $ | 86,651 |  |  | $ | 105,453 |  |  | $ | 70,621 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 84,375 |  |  | $ | 93,310 |  |  | $ | 115,757 |  |
| Customer-related third party banking institution equipment financing net settlement | $ | 90,576 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-17-000005:notes:153]
COMMITMENTS AND CONTINGENCIES

[0000866374-17-000005:notes:154]
Commitments

[0000866374-17-000005:notes:155]
Capital lease obligations of $19.1 million and $25.0 million, consisting of short-term obligations of $4.7 million and $6.6 million and long term obligations of $14.4 million and $18.4 million are included in current and non-current liabilities on the Company's balance sheets as of March 31, 2017 and 2016, respectively.

[0000866374-17-000005:notes:156]
As of March 31, 2017 and 2016, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under capital leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2035 and require the following minimum lease payments:

[0000866374-17-000005:notes:157]
| Fiscal Year Ending March 31, | Operating Lease |
|  | (In thousands) |
| 2018 | $ | 117,217 |  |
| 2019 | 92,542 |  |
| 2020 | 74,895 |  |
| 2021 | 51,493 |  |
| 2022 | 43,032 |  |
| Thereafter | 173,969 |  |
| Total minimum lease payments | $ | 553,148 |  |

[0000866374-17-000005:notes:158]
Total rent expense amounted to $124.7 million, $124.2 million and $133.1 million in fiscal years 2017, 2016 and 2015, respectively.

[0000866374-17-000005:notes:159]
Litigation and other legal matters

[0000866374-17-000005:notes:160]
As discussed in note 2, on April 21, 2016, SunEdison, Inc. filed for protection under Chapter 11 of the U.S. Bankruptcy Code, no preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known to the Company. The Company is unable to reasonably estimate a loss or any range of possible loss. Further, the Company believes that it continues to have a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted. An unfavorable resolution of this matter could be material to the Company’s results of operations, financial condition, or cash flows.

[0000866374-17-000005:notes:161]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. The first two tax assessments were received in fiscal year 2014 and fiscal year 2016 relating to calendar year 2010 for an alleged total amount of 109 million Brazilian reals (approximately USD $35 million based on the exchange rate as of March 31, 2017). These two assessments are in various stages of the review process at the administrative level. During the third quarter of fiscal year 2017, the same Brazilian subsidiary received a third assessment related to calendar year 2011 taxes of an additional 181 million Brazilian reals (approximately USD $58 million based on the exchange rate as of March 31, 2017). The Company plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company believes there is no legal basis for the alleged liabilities; however, due to the complexities and uncertainty surrounding the administrative review and judicial processes in Brazil and the nature of the claims, an adverse determination is reasonably possible.  Due to the same considerations, it is not possible to estimate a loss or range of loss for these assessments or any future assessments that are reasonably possible.  The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-17-000005:notes:162]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately USD $100 million related to income and social contribution taxes, interest and penalties. During the first quarter of fiscal year 2017, the Company received a final favorable judgment in the judicial process reversing the assessment and the case is now closed. As the Company had previously determined there was no legal basis for the assessment, no adjustment was required to be recorded during fiscal year 2017.

[0000866374-17-000005:notes:163]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-17-000005:notes:164]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0000866374-17-000005:notes:165]
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2017, 2016 and 2015 are as follows:

[0000866374-17-000005:notes:166]
|  | Fiscal Year Ended March 31, 2017 |
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |
| Other comprehensive gain (loss) before reclassifications | 6,925 |  |  | (1,198 | ) |  | 5,727 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 2,171 |  |  | (126 | ) |  | 2,045 |  |
| Net current-period other comprehensive (gain) loss | 9,096 |  |  | (1,324 | ) |  | 7,772 |  |
| Ending balance | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |

[0000866374-17-000005:notes:167]
|  | Fiscal Year Ended March 31, 2016 |
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |
| Other comprehensive loss before reclassifications | (2,199 | ) |  | (3,145 | ) |  | (5,344 | ) |
| Net losses reclassified from accumulated other comprehensive loss | 28,943 |  |  | 20,991 |  |  | 49,934 |  |
| Net current-period other comprehensive gain | 26,744 |  |  | 17,846 |  |  | 44,590 |  |
| Ending balance | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |

[0000866374-17-000005:notes:168]
|  | Fiscal Year Ended March 31, 2015 |
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (32,849 | ) |  | $ | (93,307 | ) |  | $ | (126,156 | ) |
| Other comprehensive loss before reclassifications | (76,470 | ) |  | (9,318 | ) |  | (85,788 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 41,053 |  |  | (9,614 | ) |  | 31,439 |  |
| Net current-period other comprehensive loss | (35,417 | ) |  | (18,932 | ) |  | (54,349 | ) |
| Ending balance | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |

[0000866374-17-000005:notes:169]
Net (gains) losses reclassified from accumulated other comprehensive loss were immaterial during fiscal year 2017.

[0000866374-17-000005:notes:170]
During fiscal year 2016, the Company recognized a loss of $26.8 million in connection with the disposition of a non-strategic Western European manufacturing facility, which included a $25.3 million cumulative foreign currency translation loss. This loss was offset by the release of certain cumulative foreign currency translation gains of $4.2 million, which has been reclassified from accumulated other comprehensive loss during the period and is included in other charges (income), net in consolidated statement of operations.

[0000866374-17-000005:notes:171]
During fiscal year 2015, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. This loss includes the settlement of unrealized losses of $4.2 million on an insignificant defined benefit plan associated with the disposed facility offset by the release of cumulative foreign currency translation gains of $9.3 million, both of which have been reclassified from accumulated other comprehensive loss during the period. The loss on sale is included in other charges (income), net in the consolidated statement of operations.


## us-gaap:DebtDisclosureTextBlock

[0000866374-17-000005:notes:172]
BANK BORROWINGS AND LONG-TERM DEBT

[0000866374-17-000005:notes:173]
Bank borrowings and long-term debt are as follows:

[0000866374-17-000005:notes:174]
|  | As of March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | $ | 502,500 |  |  | $ | 547,500 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 577,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,979 |  |  | 595,589 |  |
| Other credit lines | 169,671 |  |  | 71,317 |  |
| Debt issuance costs | (16,007 | ) |  | (17,351 | ) |
|  | 2,952,143 |  |  | 2,774,555 |  |
| Current portion, net of debt issuance costs | (61,534 | ) |  | (65,166 | ) |
| Non-current portion | $ | 2,890,609 |  |  | $ | 2,709,389 |  |

[0000866374-17-000005:notes:175]
The weighted-average interest rates for the Company's long-term debt were 3.5% as of March 31, 2017 and 2016.

[0000866374-17-000005:notes:176]
Repayments of the Company's long-term debt are as follows:

[0000866374-17-000005:notes:177]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 | $ | 63,887 |  |
| 2019 | 475,092 |  |
| 2020 | 517,592 |  |
| 2021 | 65,232 |  |
| 2022 | 746,420 |  |
| Thereafter | 1,099,927 |  |
| Total | $ | 2,968,150 |  |

[0000866374-17-000005:notes:178]
Term Loan due November 2021

[0000866374-17-000005:notes:179]
In August 2013, the Company entered into a $600 million term loan agreement due August 2018. In November 2016, the Company entered into a new arrangement to extend the maturity date of the agreement from August 30, 2018 to November 30, 2021, and borrowed an incremental amount of $130 million under this term loan, thereby increasing the total amount under the term loan to $700 million. This loan is repayable in quarterly installments of $4.1 million, which will commence October 31, 2017 and continue through September 30, 2021, with the remaining amount due at maturity.

[0000866374-17-000005:notes:180]
Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the prime rate in effect on each day as published in The Wall Street Journal, the federal funds rate plus 0.5% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating.

[0000866374-17-000005:notes:181]
This term loan is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term; provided that the requirement to maintain the minimum interest coverage ratio may be suspended in certain circumstances. As of March 31, 2017, the Company was in compliance with the covenants under this term loan agreement.

[0000866374-17-000005:notes:182]
Term Loan Agreement due March 2019 and Revolving Line of Credit

[0000866374-17-000005:notes:183]
As of March 31, 2017, the Company has a $2.1 billion credit facility ("Credit Facility") consisting of a $1.5 billion revolving credit facility and a $600.0 million term loan, which is due to expire in March 2019. Quarterly repayments of principal under this term loan are $11.3 million with the remainder due upon maturity.

[0000866374-17-000005:notes:184]
Borrowings under this facility bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the agent's prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating. The Company is required to pay a quarterly commitment fee ranging between 0.15% and 0.40% per annum on the daily unused amount of the $1.5 billion Revolving Credit Facility based on the Company's credit rating.

[0000866374-17-000005:notes:185]
This Credit Facility is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2017, the Company was in compliance with the covenants under this loan agreement.

[0000866374-17-000005:notes:186]
Notes due February 2020 and February 2023

[0000866374-17-000005:notes:187]
In February 2013, the Company issued $500.0 million of 4.625% Notes due February 15, 2020 and $500.0 million of 5.000% Notes due February 15, 2023 (collectively the "Notes") in a private offering pursuant to Rule 144A and Regulation S under the Securities Act. In July 2013, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission. The Company received net proceeds of approximately $990.6 million from the issuance and used those proceeds, together with $9.4 million of cash on hand, to repay $1.0 billion of outstanding borrowings under its previous term loan that was due October 2014.

[0000866374-17-000005:notes:188]
Interest on the Notes is payable semi-annually, which commenced on August 15, 2013. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Credit Facility or the Company's Term Loan due 2018.

[0000866374-17-000005:notes:189]
At any time prior to maturity, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0000866374-17-000005:notes:190]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately. As of March 31, 2017, the Company was in compliance with the covenants in the indenture governing the Notes.

[0000866374-17-000005:notes:191]
Notes due June 2025

[0000866374-17-000005:notes:192]
In June 2015, the Company issued $600 million of 4.750% Notes ("2025 Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at 99.213% of face value, and an effective yield of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which was used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.

[0000866374-17-000005:notes:193]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the 2025 Notes. The issuance costs were capitalized and presented on the balance sheet as a direct deduction from the carrying amount of the Notes.

[0000866374-17-000005:notes:194]
Interest on the 2025 Notes is payable semi-annually, commencing on December 15, 2015. The 2025 Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Term Loan Agreement and Revolving Line of Credit.

[0000866374-17-000005:notes:195]
At any time prior to March 15, 2025, the Company may redeem some or all of the 2025 Notes at a redemption price equal to 100% of the principal amount of the 2025 Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the 2025 Notes indenture), the Company must offer to repurchase the 2025 Notes at a repurchase price equal to 101% of the principal amount of the 2025 Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0000866374-17-000005:notes:196]
The indenture governing the 2025 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2025 Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2025 Notes may declare all of the 2025 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2025 Notes. As of March 31, 2017, the Company was in compliance with the covenants in the indenture governing the 2025 Notes.

[0000866374-17-000005:notes:197]
Other Credit Lines

[0000866374-17-000005:notes:198]
In January 2017, the Company borrowed €100 million (approximately $107.4 million as of March 31, 2017), under a 5-year, term-loan agreement due January 2, 2022. Borrowings under this term loan bear interest at EURIBOR plus the applicable margin ranging between 0.40% and 1.35%, based on the Company's credit ratings. The loan is repayable upon maturity.

[0000866374-17-000005:notes:199]
In October 2015, the Company borrowed €50 million (approximately $53.7 million as of March 31, 2017), under a 5-year, term-loan agreement due September 30, 2020. Borrowings under this term loan bear interest at EURIBOR plus the applicable margin ranging between 0.80% and 2.00%, based on the Company’s credit ratings. The loan is repayable beginning December 30, 2016 in quarterly payments of €312,500 through June 30, 2020 with the remainder due upon maturity.

[0000866374-17-000005:notes:200]
These term loans are unsecured, and are guaranteed by the Company. These term loan agreements contain customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. These term loan agreements also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during their terms. As of March 31, 2017, the Company was in compliance with the covenants under these term loan agreements.

[0000866374-17-000005:notes:201]
As of March 31, 2017, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities in the amount of $162.6 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2017 and 2016. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin, and generally have maturities that expire on various dates in future fiscal years.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-17-000005:notes:202]
FINANCIAL INSTRUMENTS

[0000866374-17-000005:notes:203]
Foreign Currency Contracts

[0000866374-17-000005:notes:204]
The Company transacts business in various foreign countries and is therefore, exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency unit of the operating entity. The Company enters into short-term foreign currency forward and swap contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains and losses on the Company's forward and swap contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these forward and swap contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-17-000005:notes:205]
As of March 31, 2017, the aggregate notional amount of the Company's outstanding foreign currency forward and swap contracts was $4.1 billion as summarized below:

[0000866374-17-000005:notes:206]
|  | Foreign CurrencyAmount |  | Notional ContractValue in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| CNY | 1,309,000 |  |  | — |  |  | $ | 189,974 |  |  | $ | — |  |
| EUR | 27,830 |  |  | 64,132 |  |  | 29,915 |  |  | 71,796 |  |
| HUF | 13,800,000 |  |  | — |  |  | 47,935 |  |  | — |  |
| ILS | 70,481 |  |  | — |  |  | 19,438 |  |  | — |  |
| INR | 1,389,587 |  |  | — |  |  | 20,300 |  |  | — |  |
| MXN | 2,133,500 |  |  | — |  |  | 113,198 |  |  | — |  |
| MYR | 167,000 |  |  | 11,300 |  |  | 37,791 |  |  | 2,557 |  |
| RON | 114,780 |  |  | — |  |  | 27,083 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 32,735 |  |  | 8,915 |  |
|  |  |  |  |  | 518,369 |  |  | 83,268 |  |
| Other Forward/Swap Contracts |  |  |  |  |  |  |  |
| BRL | — |  |  | 543,000 |  |  | — |  |  | 174,078 |  |
| CHF | 9,446 |  |  | 33,920 |  |  | 9,472 |  |  | 34,015 |  |
| CNY | 1,877,296 |  |  | — |  |  | 271,571 |  |  | — |  |
| DKK | 179,400 |  |  | 157,200 |  |  | 25,917 |  |  | 22,710 |  |
| EUR | 909,291 |  |  | 1,058,540 |  |  | 976,028 |  |  | 1,136,862 |  |
| GBP | 36,129 |  |  | 65,154 |  |  | 44,835 |  |  | 80,808 |  |
| HUF | 18,026,924 |  |  | 15,105,152 |  |  | 62,617 |  |  | 52,468 |  |
| ILS | 105,100 |  |  | 91,660 |  |  | 28,985 |  |  | 25,279 |  |
| INR | 5,200,000 |  |  | 19,528 |  |  | 80,160 |  |  | 300 |  |
| MXN | 2,166,702 |  |  | 686,447 |  |  | 114,930 |  |  | 36,421 |  |
| MYR | 331,628 |  |  | 44,500 |  |  | 75,046 |  |  | 10,070 |  |
| PLN | 118,139 |  |  | 62,613 |  |  | 30,044 |  |  | 15,923 |  |
| RON | 73,252 |  |  | 61,526 |  |  | 17,284 |  |  | 14,517 |  |
| SEK | 159,766 |  |  | 190,198 |  |  | 17,929 |  |  | 21,402 |  |
| SGD | 42,147 |  |  | 3,019 |  |  | 30,206 |  |  | 2,164 |  |
| Other | N/A |  |  | N/A |  |  | 30,361 |  |  | 39,390 |  |
|  |  |  |  |  | 1,815,385 |  |  | 1,666,407 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 2,333,754 |  |  | $ | 1,749,675 |  |

[0000866374-17-000005:notes:207]
As of March 31, 2017 and 2016, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in non-functional currencies and are not accounted for as hedges under the accounting standards. Accordingly, changes in fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the consolidated statements of operations. As of March 31, 2017 and 2016, the Company also has included net deferred gains and losses, in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains totaled $10.6 million as of March 31, 2017, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal years presented and are included as a component of interest and other, net in the consolidated statements of operations.

[0000866374-17-000005:notes:208]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2017 and 2016:

[0000866374-17-000005:notes:209]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31, 2017 |  | March 31, 2016 |  | Balance SheetLocation |  | March 31, 2017 |  | March 31, 2016 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 11,936 |  |  | $ | 5,510 |  |  | Other current liabilities |  | $ | 1,814 |  |  | $ | 2,446 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 10,086 |  |  | $ | 17,138 |  |  | Other current liabilities |  | $ | 9,928 |  |  | $ | 18,645 |  |

[0000866374-17-000005:notes:210]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with the counterparty upon maturity. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-17-000005:notes:211]
SHARE-BASED COMPENSATION

[0000866374-17-000005:notes:212]
Equity Compensation Plans

[0000866374-17-000005:notes:213]
The Company's primary plan used for granting equity compensation awards is the 2010 Equity Incentive Plan (the "2010 Plan").

[0000866374-17-000005:notes:214]
During fiscal year 2016, in conjunction with the acquisition of NEXTracker, the Company assumed all of the outstanding, unvested share bonus awards and outstanding, unvested options to purchase shares of common stock of NEXTracker, and converted all these shares into Flex awards. As a result, the Company now offers the 2014 NEXTracker Equity Incentive Plan (the "NEXTracker Plan").

[0000866374-17-000005:notes:215]
Additionally, during fiscal year 2017, in conjunction with an immaterial acquisition, the Company assumed all of the outstanding, unvested options to purchase shares of common stock of the acquiree, and converted all of these shares into Flex awards. As a result, the Company now offers an additional equity compensation plan, the BrightBox Technologies 2013 Plan (the "BrightBox Plan").

[0000866374-17-000005:notes:216]
Further, during fiscal year 2017, the Company granted equity compensation awards under a fourth plan, the 2013 Elementum Plan (the "Elementum Plan"), which is administered by Elementum SCM (Cayman) Limited ("Elementum"), a majority owned subsidiary of the Company.

[0000866374-17-000005:notes:217]
Share-Based Compensation Expense

[0000866374-17-000005:notes:218]
The Company early adopted new guidance intended to reduce cost and complexity of the accounting for share-based payments, as discussed further in note 2.

[0000866374-17-000005:notes:219]
The following table summarizes the Company's share-based compensation expense for all Equity Incentive Plans:

[0000866374-17-000005:notes:220]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Cost of sales | $ | 10,023 |  |  | $ | 8,986 |  |  | $ | 7,503 |  |
| Selling, general and administrative expenses | 72,243 |  |  | 68,594 |  |  | 42,767 |  |
| Total share-based compensation expense | $ | 82,266 |  |  | $ | 77,580 |  |  | $ | 50,270 |  |

[0000866374-17-000005:notes:221]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as operating cash flows. During fiscal years 2017, 2016 and 2015, the Company did not recognize any excess tax benefits as an operating cash inflow.

[0000866374-17-000005:notes:222]
The 2010 Equity Incentive Plan

[0000866374-17-000005:notes:223]
As of March 31, 2017, the Company had approximately 18.1 million shares available for grant under the 2010 Plan. Options issued to employees under the 2010 Plan generally vest over four years and expire seven years from the date of grant. Options granted to non-employee directors expire five years from the date of grant.

[0000866374-17-000005:notes:224]
The exercise price of options granted to employees is determined by the Company's Board of Directors or the Compensation Committee and may not be less than the closing price of the Company's ordinary shares on the date of grant.

[0000866374-17-000005:notes:225]
As of March 31, 2017, the total unrecognized compensation cost related to unvested share options granted to employees under the 2010 Plan was not significant and will be amortized on a straight-line basis over a weighted-average period of approximately 1.5 years.

[0000866374-17-000005:notes:226]
The Company also grants share bonus awards under its equity compensation plan. Share bonus awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. Share bonus awards generally vest in installments over a three to five-year period and unvested share bonus awards are forfeited upon termination of employment.

[0000866374-17-000005:notes:227]
Vesting for certain share bonus awards is contingent upon both service and market conditions. Further, vesting for certain share bonus awards granted to certain executive officers is contingent upon meeting certain free cash flow targets.

[0000866374-17-000005:notes:228]
As of March 31, 2017, the total unrecognized compensation cost related to unvested share bonus awards granted to employees was approximately $130.0 million under the 2010 Plan. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.5 years. Approximately $14.4 million of the unrecognized compensation cost related to the 2010 Plan is related to share bonus awards granted to certain key employees whereby vesting is contingent on meeting a certain market condition.

[0000866374-17-000005:notes:229]
Determining Fair Value - Options and share bonus awards

[0000866374-17-000005:notes:230]
Valuation and Amortization Method—The Company estimates the fair value of share options granted under the 2010 Plan using the Black-Scholes valuation method and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period. The fair market value of share bonus awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-17-000005:notes:231]
Expected Term—The Company's expected term used in the Black-Scholes valuation method represents the period that the Company's share options are expected to be outstanding and is determined based on historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share options.

[0000866374-17-000005:notes:232]
Expected Volatility—The Company's expected volatility used in the Black-Scholes valuation method is derived from a combination of implied volatility related to publicly traded options to purchase Flex ordinary shares and historical variability in the Company's periodic share price.

[0000866374-17-000005:notes:233]
Expected Dividend—The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-17-000005:notes:234]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0000866374-17-000005:notes:235]
There were no options granted under the 2010 Plan during fiscal years 2017 and 2016. The fair value of the Company's share options granted to employees for fiscal year 2015 was estimated using the following weighted-average assumptions:

[0000866374-17-000005:notes:236]
|  | Fiscal Year EndedMarch 31, |
|  | 2015 |
| Expected term | 6.3 years |
| Expected volatility | 46.9% |
| Expected dividends | 0.0% |
| Risk-free interest rate | 2.3% |
| Weighted-average fair value | $4.85 |

[0000866374-17-000005:notes:237]
Determining Fair Value - Share bonus awards with service and market conditions

[0000866374-17-000005:notes:238]
Valuation and Amortization Method—The Company estimates the fair value of share bonus awards granted under the 2010 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-17-000005:notes:239]
Expected volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the share bonus awards granted. The service period is three years for those share bonus awards granted in fiscal years 2017, 2016 and 2015.

[0000866374-17-000005:notes:240]
Average peer volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of both the Standard and Poor's ("S&P") 500 index and components of an extended Electronics Manufacturing Services ("EMS") group, comprised of global competitors of the Company within the same industry, for the share bonus awards granted in fiscal years 2017, 2016 and 2015.

[0000866374-17-000005:notes:241]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to both the S&P 500 index and peers in the extended EMS group for the share bonus awards granted in fiscal years 2017, 2016 and 2015.

[0000866374-17-000005:notes:242]
Expected Dividend and Risk-Free Interest Rate assumptions—Same methodology as discussed above.

[0000866374-17-000005:notes:243]
The fair value of the Company's share-bonus awards under the 2010 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2017, 2016 and 2015 was estimated using the following weighted-average assumptions:

[0000866374-17-000005:notes:244]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Expected volatility | 25.8 | % |  | 26.0 | % |  | 29.4 | % |
| Average peer volatility | 25.1 | % |  | 23.0 | % |  | 25.9 | % |
| Average peer correlation | 0.6 |  |  | 0.6 |  |  | 0.6 |  |
| Expected dividends | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate | 0.9 | % |  | 1.2 | % |  | 0.9 | % |

[0000866374-17-000005:notes:245]
Share-Based Awards Activity

[0000866374-17-000005:notes:246]
The following is a summary of option activity for the Company's 2010 Plan ("Price" reflects the weighted-average exercise price):

[0000866374-17-000005:notes:247]
|  | Fiscal Year Ended March 31, |
|  | 2017 | 2016 | 2015 |
|  | Options |  | Price |  | Options |  | Price |  | Options |  | Price |
| Outstanding, beginning of fiscal year | 2,369,636 |  |  | $ | 8.31 |  |  | 15,992,894 |  |  | $ | 7.81 |  |  | 23,612,872 |  |  | $ | 8.57 |  |
| Granted | — |  |  | — |  |  | — |  |  | — |  |  | 15,000 |  |  | 11.11 |  |
| Exercised | (1,573,356 | ) |  | 6.89 |  |  | (10,006,774 | ) |  | 6.10 |  |  | (3,600,900 | ) |  | 6.53 |  |
| Forfeited | (653,953 | ) |  | 12.39 |  |  | (3,616,484 | ) |  | 12.23 |  |  | (4,034,078 | ) |  | 13.17 |  |
| Outstanding, end of fiscal year | 142,327 |  |  | $ | 8.97 |  |  | 2,369,636 |  |  | $ | 8.31 |  |  | 15,992,894 |  |  | $ | 7.81 |  |
| Options exercisable, end of fiscal year | 138,950 |  |  | $ | 8.93 |  |  | 2,359,527 |  |  | $ | 8.30 |  |  | 15,959,173 |  |  | $ | 7.81 |  |

[0000866374-17-000005:notes:248]
The aggregate intrinsic value of options exercised under the Company's 2010 Plan (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise for options exercised in-the-money) was $9.3 million, $55.3 million and $16.3 million during fiscal years 2017, 2016 and 2015, respectively.

[0000866374-17-000005:notes:249]
Cash received from option exercises under the 2010 Plan was $10.9 million, $61.1 million and $23.5 million for fiscal years 2017, 2016 and 2015, respectively.

[0000866374-17-000005:notes:250]
The following table presents the composition of options outstanding and exercisable under the 2010 Plan as of March 31, 2017:

[0000866374-17-000005:notes:251]
|  |  | Options Outstanding | Options Exercisable |
| Range of Exercise Prices |  | Number ofSharesOutstanding |  | WeightedAverageRemainingContractualLife(In Years) |  | WeightedAverageExercisePrice |  | Number ofSharesExercisable |  | WeightedAverageRemainingContractualLife(In Years) |  | WeightedAverageExercisePrice |
| $3.39 - $5.75 |  | 15,759 |  |  | 0.42 |  | $ | 5.03 |  |  | 15,759 |  |  | 0.42 |  | $ | 5.03 |  |
| $5.87 - $7.07 |  | 11,003 |  |  | 1.43 |  | 6.63 |  |  | 11,003 |  |  | 1.43 |  | 6.63 |  |
| $7.08 - $10.59 |  | 62,564 |  |  | 0.97 |  | 8.16 |  |  | 62,564 |  |  | 0.97 |  | 8.16 |  |
| $10.67 - $11.41 |  | 45,501 |  |  | 1.14 |  | 11.16 |  |  | 42,124 |  |  | 0.91 |  | 11.16 |  |
| $11.53 - $13.98 |  | 7,500 |  |  | 0.61 |  | 12.47 |  |  | 7,500 |  |  | 0.61 |  | 12.47 |  |
| $3.39 - $13.98 |  | 142,327 |  |  | 0.99 |  | $ | 8.97 |  |  | 138,950 |  |  | 0.91 |  | $ | 8.93 |  |
| Options vested and expected to vest |  | 142,014 |  |  | 0.98 |  | $ | 8.97 |  |  |  |  |  |  |  |  |

[0000866374-17-000005:notes:252]
As of March 31, 2017 the aggregate intrinsic value for options outstanding, options vested and expected to vest, and options exercisable under the Company's 2010 Plan, was $1.2 million, respectively. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2017 for the approximately 0.2 million options that were in-the-money at March 31, 2017.

[0000866374-17-000005:notes:253]
The following table summarizes the Company's share bonus award activity under the 2010 Plan ("Price" reflects the weighted-average grant-date fair value):

[0000866374-17-000005:notes:254]
|  | Fiscal Year Ended March 31, |
|  | 2017 | 2016 | 2015 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested share bonus awards outstanding, beginning of fiscal year | 17,000,076 |  |  | $ | 10.77 |  |  | 18,993,252 |  |  | $ | 9.01 |  |  | 21,848,120 |  |  | $ | 7.32 |  |
| Granted (1) | 6,578,366 |  |  | 13.46 |  |  | 7,619,722 |  |  | 12.23 |  |  | 6,963,125 |  |  | 11.75 |  |
| Vested (1) | (6,922,946 | ) |  | 9.44 |  |  | (8,529,378 | ) |  | 7.93 |  |  | (7,246,056 | ) |  | 6.97 |  |
| Forfeited | (956,914 | ) |  | 11.20 |  |  | (1,083,520 | ) |  | 9.67 |  |  | (2,571,937 | ) |  | 7.70 |  |
| Unvested share bonus awards outstanding, end of fiscal year | 15,698,582 |  |  | $ | 12.44 |  |  | 17,000,076 |  |  | $ | 10.77 |  |  | 18,993,252 |  |  | $ | 9.01 |  |

[0000866374-17-000005:notes:255]
(1) Excluded from the fiscal year 2017 amounts are 1.7 million of share bonus awards representing the number of awards achieved above target levels based on the achievement of certain market conditions, as further described in the table below. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-17-000005:notes:256]
Of the 6.6 million unvested share bonus awards granted under the 2010 Plan in fiscal year 2017, approximately 5.7 million unvested share bonus awards have an average grant date price of $13.09 per share. Further, approximately 0.2 million of these unvested share bonus awards have an average grant date price of $12.82 per share and represents the target amount of grants made to certain executive officers whereby vesting is contingent on meeting certain free cash flow targets. These awards cliff vest after three years and will ultimately pay out over a range from zero up to a maximum of 0.4 million of the target payment based on a measurement of cumulative three-year increase of free cash flow from operations of the Company.

[0000866374-17-000005:notes:257]
Further, 0.7 million of these unvested share bonus awards granted in fiscal year 2017 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $17.57 per award and was calculated using a Monte Carlo simulation. Vesting information of these shares are further detailed in the table below.

[0000866374-17-000005:notes:258]
The Company will recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2017, 3.5 million shares vested in connection with the share bonus awards with market conditions granted in fiscal year 2014.

[0000866374-17-000005:notes:259]
The total intrinsic value of share bonus awards vested under the Company's 2010 Plan was $109.5 million, $103.2 million and $79.0 million during fiscal years 2017, 2016 and 2015, respectively, based on the closing price of the Company's ordinary shares on the date vested.

[0000866374-17-000005:notes:260]
The 2014 NEXTracker Equity Incentive Plan

[0000866374-17-000005:notes:261]
All shares previously granted under the NEXTracker plan are the result of the Company's conversion of all outstanding, unvested shares of NEXTracker into unvested shares of the Company, as part of the acquisition. Therefore, no additional share options or share bonus awards were granted by the Company during fiscal year 2017.

[0000866374-17-000005:notes:262]
Options issued to employees under the NEXTracker Plan generally have a vesting period of two to four years from vesting commencement date and expire ten years from the date of grant.

[0000866374-17-000005:notes:263]
The exercise price of options granted to employees was determined by the Company based on a conversion rate agreed upon in the purchase agreement of NEXTracker.

[0000866374-17-000005:notes:264]
As of March 31, 2017, the total unrecognized compensation cost related to unvested share options granted to employees under the NEXTracker Plan was $8.7 million and will be amortized on a straight-line basis over a weighted-average period of approximately 1.8 years.

[0000866374-17-000005:notes:265]
Share bonus awards issued to employees under the NEXTracker Plan vest in installments over a three to five-year period from vesting commencement date, and unvested share bonus awards are forfeited upon termination of employment. Vesting for certain of these share bonus awards is contingent on meeting certain performance targets over a three-year period commencing October 1, 2015.

[0000866374-17-000005:notes:266]
As of March 31, 2017, the total unrecognized compensation cost related to unvested share bonus awards granted to employees under the NEXTracker Plan was approximately $11.0 million and will be amortized generally on a straight-line basis over a weighted-average period of approximately 1.5 years.

[0000866374-17-000005:notes:267]
Determining Fair Value

[0000866374-17-000005:notes:268]
As noted above, there were no options granted under the NEXTracker Plan during fiscal year 2017. The fair value of the Company's share options granted to employees under the NEXTracker Plan for fiscal year 2016 was estimated using the following weighted-average assumptions:

[0000866374-17-000005:notes:269]
|  | Fiscal Year EndedMarch 31, 2016 |
| Expected term | 2.9 years |
| Expected volatility | 28.8% |
| Expected dividends | 0.0% |
| Risk-free interest rate | 0.9% |
| Weighted-average fair value | $7.76 |

[0000866374-17-000005:notes:270]
The following is a summary of option activity for the NEXTracker Plan ("Price" reflects the weighted-average exercise price):

[0000866374-17-000005:notes:271]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |
|  | Options |  | Price |  | Options |  | Price |
| Outstanding, beginning of fiscal year | 2,741,854 |  |  | $ | 3.44 |  |  | — |  |  | $ | — |  |
| Granted | — |  |  | — |  |  | 3,205,806 |  |  | 3.28 |  |
| Exercised | (709,845 | ) |  | 2.24 |  |  | (237,380 | ) |  | 0.99 |  |
| Forfeited | (395,993 | ) |  | 4.64 |  |  | (226,572 | ) |  | 3.75 |  |
| Outstanding, end of fiscal year | 1,636,016 |  |  | $ | 3.61 |  |  | 2,741,854 |  |  | $ | 3.44 |  |
| Options exercisable, end of fiscal year | 369,015 |  |  | $ | 5.00 |  |  | 223,869 |  |  | $ | 4.95 |  |

[0000866374-17-000005:notes:272]
The aggregate intrinsic value of options exercised under the NEXTracker plan (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise for options exercised in-the-money) was $8.0 million and $2.3 million as of March 31, 2017 and 2016, respectively.

[0000866374-17-000005:notes:273]
Cash received from option exercises under the NEXTracker Plan was $1.6 million and $0.2 million for fiscal year 2017 and 2016, respectively.

[0000866374-17-000005:notes:274]
The following table presents the composition of options outstanding and exercisable under the NEXTracker Plan as of March 31, 2017:

[0000866374-17-000005:notes:275]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | Number ofSharesOutstanding |  | WeightedAverageRemainingContractualLife(In Years) |  | WeightedAverageExercisePrice |  | Number ofSharesExercisable |  | WeightedAverageRemainingContractualLife(In Years) |  | WeightedAverageExercisePrice |
| $0.08 - $5.24 |  | 1,223,059 |  |  | 8.50 |  | $ | 1.30 |  |  | 229,584 |  |  | 8.50 |  | $ | 1.70 |  |
| $5.25 - $10.65 |  | 412,957 |  |  | 8.50 |  | 10.65 |  |  | 139,431 |  |  | 8.50 |  | 10.65 |  |
| $0.08 - $10.65 |  | 1,636,016 |  |  | 8.50 |  | $ | 3.61 |  |  | 369,015 |  |  | 8.50 |  | $ | 5.00 |  |
| Options vested and expected to vest |  | 1,636,016 |  |  | 8.50 |  | $ | 3.61 |  |  |  |  |  |  |  |  |  |

[0000866374-17-000005:notes:276]
As of March 31, 2017 the aggregate intrinsic value for options outstanding, options vested and expected to vest, and options exercisable under the Company's NEXTracker Plan, were $22.2 million, $22.2 million, and $4.5 million, respectively. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2017 for the approximately 1.6 million options under the NEXTracker Plan that were in-the-money at March 31, 2017.

[0000866374-17-000005:notes:277]
The following table summarizes the Company's share bonus award activity under the NEXTracker Plan ("Price" reflects the weighted-average grant-date fair value):

[0000866374-17-000005:notes:278]
|  | Fiscal Year Ended March 31, |
|  | 2017 | 2016 |
|  | Shares |  | Price | Shares |  | Price |
| Unvested share bonus awards outstanding, beginning of fiscal year | 2,309,096 |  |  | $ | 10.27 |  | — |  |  | $ | — |  |
| Granted | — |  |  | — |  | 2,393,195 |  |  | 10.27 |  |
| Vested | (705,738 | ) |  | 10.19 |  | (31,925 | ) |  | 10.27 |  |
| Forfeited | (59,921 | ) |  | 10.27 |  | (52,174 | ) |  | 10.27 |  |
| Unvested share bonus awards outstanding, end of fiscal year | 1,543,437 |  |  | $ | 10.23 |  | 2,309,096 |  |  | $ | 10.27 |  |

[0000866374-17-000005:notes:279]
The total intrinsic value of share bonus awards vested under the Company's NEXTracker Plan was $9.6 million during fiscal year 2017, based on the closing price of the Company's ordinary shares on the date vested.

[0000866374-17-000005:notes:280]
The BrightBox Technologies 2013 Plan

[0000866374-17-000005:notes:281]
During fiscal year 2017, the Company granted 0.2 million share options under the BrightBox Plan, at an average grant date fair value price of $11.99 per share, and with a vesting period of three years from the vesting commencement date. All shares granted under the BrightBox plan are the result of the Company's conversion of all outstanding, unvested shares of BrightBox into unvested shares of the Company, as part of the acquisition. No additional grants will be made out of this plan in the future.

[0000866374-17-000005:notes:282]
As of March 31, 2017, total unrecognized compensation expense related to share options under the BrightBox Plan is $1.4 million, and will be recognized over a weighted-average remaining vesting period of 2.1 years. As of March 31, 2017, the number of options outstanding was 0.2 million, at a weighted-average exercise price of $0.51 per share. No options under this plan were exercisable as of March 31, 2017.

[0000866374-17-000005:notes:283]
The 2013 Equity Incentive Plan of Elementum SCM (Cayman) Ltd.

[0000866374-17-000005:notes:284]
As of March 31, 2017 Elementum had approximately 0.1 million shares available for future grants under the 2013 Elementum Plan. Options to purchase shares in Elementum issued to employees under the Elementum Plan have a vesting period of two to four years and expire ten years from the grant date. As of March 31, 2017 there were 33.6 million of options outstanding at a weighted average exercise price of $0.39 per option. Cash received from option exercises under the Elementum Plan was $0.6 million for fiscal year 2017. Total unrecognized compensation expenses relating to stock options granted to certain employees under the Elementum Plan as of March 31, 2017 is $5.7 million, and will be recognized over a weighted average period of 2.6 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-17-000005:notes:285]
EARNINGS PER SHARE

[0000866374-17-000005:notes:286]
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-17-000005:notes:287]
Diluted earnings per share reflects the potential dilution from stock options and share bonus awards. The potential dilution from stock options exercisable into ordinary share equivalents and share bonus awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-17-000005:notes:288]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income per share:

[0000866374-17-000005:notes:289]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands, exceptper share amounts) |
| Basic earnings per share: |  |  |  |  |  |
| Net income | $ | 319,564 |  |  | $ | 444,081 |  |  | $ | 600,801 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 540,503 |  |  | 557,667 |  |  | 579,981 |  |
| Basic earnings per share | $ | 0.59 |  |  | $ | 0.80 |  |  | $ | 1.04 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 319,564 |  |  | $ | 444,081 |  |  | $ | 600,801 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 540,503 |  |  | 557,667 |  |  | 579,981 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) | 5,717 |  |  | 7,202 |  |  | 11,575 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 546,220 |  |  | 564,869 |  |  | 591,556 |  |
| Diluted earnings per share | $ | 0.59 |  |  | $ | 0.79 |  |  | $ | 1.02 |  |

[0000866374-17-000005:notes:290]
_________________________________________________________________________

[0000866374-17-000005:notes:291]
| (1) | Options to purchase ordinary shares of 0.5 million, 2.0 million and 6.2 million during fiscal years 2017, 2016 and 2015, respectively, and share bonus awards of less than 0.1 million during fiscal year 2017 and 2015, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. There were no anti-dilutive share bonus awards in fiscal year 2016. |


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-17-000005:notes:292]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES

[0000866374-17-000005:notes:293]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-17-000005:notes:294]
Level 1—Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000866374-17-000005:notes:295]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other noncurrent assets on the consolidated balance sheets and include investments in equity securities that are valued using active market prices.

[0000866374-17-000005:notes:296]
Level 2—Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-17-000005:notes:297]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-17-000005:notes:298]
The Company's cash equivalents are comprised of bank deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-17-000005:notes:299]
The Company's deferred compensation plan assets also include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-17-000005:notes:300]
Level 3—Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-17-000005:notes:301]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs.

[0000866374-17-000005:notes:302]
During fiscal year 2016, the Company accrued $84.3 million of contingent consideration, of which $81.0 million related to the acquisition of NEXTracker on the date of acquisition. The Company reduced the accrual by $19.0 million for a contractual release from the obligation executed subsequent to the acquisition during fiscal year 2016. Upon achievement of targets established in the NEXTracker purchase agreement, the Company paid $40.6 million of the total contingent consideration during fiscal year 2017. This payment is included in other financing activities, net, in the condensed consolidated statements of cash flows.

[0000866374-17-000005:notes:303]
The fair value of the liability was estimated using a simulation-based measurement technique with significant inputs that are not observable in the market and thus represents a level 3 fair value measurement. The significant inputs in the fair value measurement not supported by market activity included the Company's probability assessments of expected future revenue during the earn-out period and associated volatility, appropriately discounted considering the uncertainties associated with the obligation, and calculated in accordance with the terms of the merger agreement. Significant decreases in expected revenue during the earn-out period, or significant increases in the discount rate or volatility in isolation would result in lower fair value estimates. The interrelationship between these inputs is not considered significant.

[0000866374-17-000005:notes:304]
The following table summarizes the activities related to contingent consideration:

[0000866374-17-000005:notes:305]
|  | As of March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Beginning balance | $ | 73,423 |  |  | $ | 4,500 |  |
| Additions to accrual | — |  |  | 84,261 |  |
| Payments and settlements | (44,912 | ) |  | (19,008 | ) |
| Fair value adjustments | (6,085 | ) |  | 3,670 |  |
| Ending balance | $ | 22,426 |  |  | $ | 73,423 |  |

[0000866374-17-000005:notes:306]
The Company values deferred purchase price receivables relating to its Asset-Backed Securitization Program based on a discounted cash flow analysis using unobservable inputs (i.e. level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, their fair value approximates carrying value. Significant increases in either of the significant unobservable inputs (credit spread or risk free interest rate) in isolation would result in lower fair value estimates, however the impact is insignificant. The interrelationship between these inputs is also insignificant. Refer to note 10 for a reconciliation of the change in the deferred purchase price receivable.

[0000866374-17-000005:notes:307]
There were no transfers between levels in the fair value hierarchy during fiscal years 2017 and 2016.

[0000866374-17-000005:notes:308]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-17-000005:notes:309]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2017 and 2016:

[0000866374-17-000005:notes:310]
|  | Fair Value Measurements as of March 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 1,066,841 |  |  | $ | — |  |  | $ | 1,066,841 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 506,522 |  |  | 506,522 |  |
| Foreign exchange forward contracts (Note 8) | — |  |  | 22,022 |  |  | — |  |  | 22,022 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 7,062 |  |  | 52,680 |  |  | — |  |  | 59,742 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) | $ | — |  |  | $ | (11,742 | ) |  | $ | — |  |  | $ | (11,742 | ) |
| Contingent consideration in connection with acquisitions | — |  |  | — |  |  | (22,426 | ) |  | (22,426 | ) |

[0000866374-17-000005:notes:311]
|  | Fair Value Measurements as of March 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 1,074,132 |  |  | $ | — |  |  | $ | 1,074,132 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 501,097 |  |  | 501,097 |  |
| Foreign exchange forward contracts (Note 8) | — |  |  | 22,648 |  |  | — |  |  | 22,648 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 9,228 |  |  | 40,556 |  |  | — |  |  | 49,784 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) | $ | — |  |  | $ | (21,091 | ) |  | $ | — |  |  | $ | (21,091 | ) |
| Contingent consideration in connection with acquisitions | — |  |  | — |  |  | (73,423 | ) |  | (73,423 | ) |

[0000866374-17-000005:notes:312]
Other financial instruments

[0000866374-17-000005:notes:313]
The following table presents the Company's liabilities not carried at fair value as of March 31, 2017 and 2016:

[0000866374-17-000005:notes:314]
|  | As of March 31, 2017 |  | As of March 31, 2016 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In thousands) |  | (In thousands) |  |  |
| Term Loan, including current portion, due in installments through March 2019 | $ | 502,500 |  |  | $ | 503,756 |  |  | $ | 547,500 |  |  | $ | 542,709 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 526,255 |  |  | 500,000 |  |  | 524,735 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 699,566 |  |  | 577,500 |  |  | 573,533 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 534,820 |  |  | 500,000 |  |  | 507,500 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,979 |  |  | 633,114 |  |  | 595,589 |  |  | 604,926 |  |  | Level 1 |
| Total | $ | 2,798,479 |  |  | $ | 2,897,511 |  |  | $ | 2,720,589 |  |  | $ | 2,753,403 |  |  |  |

[0000866374-17-000005:notes:315]
All Term Loans and Notes presented in the table above are valued based on broker trading prices in active markets.

[0000866374-17-000005:notes:316]
The Company values its outstanding €100 million and €49.4 million (approximately $107.4 million and $53.0 million as of March 31, 2017), 5-year, unsecured, term-loans due January 2, 2022 and September 30, 2020, respectively, based on the current market rate, and as of March 31, 2017, the carrying amounts for each loan approximate fair value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-17-000005:notes:317]
INCOME TAXES

[0000866374-17-000005:notes:318]
The domestic (Singapore) and foreign components of income before income taxes were comprised of the following:

[0000866374-17-000005:notes:319]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Domestic | $ | 435,709 |  |  | $ | 199,283 |  |  | $ | 67,482 |  |
| Foreign | (64,861 | ) |  | 255,392 |  |  | 603,173 |  |
| Total | $ | 370,848 |  |  | $ | 454,675 |  |  | $ | 670,655 |  |

[0000866374-17-000005:notes:320]
The provision for income taxes consisted of the following:

[0000866374-17-000005:notes:321]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Domestic | $ | 1,037 |  |  | $ | 56 |  |  | $ | 87 |  |
| Foreign | 71,773 |  |  | 74,706 |  |  | 129,863 |  |
|  | 72,810 |  |  | 74,762 |  |  | 129,950 |  |
| Deferred: |  |  |  |  |  |
| Domestic | 350 |  |  | 3,779 |  |  | (4,734 | ) |
| Foreign | (21,876 | ) |  | (67,947 | ) |  | (55,362 | ) |
|  | (21,526 | ) |  | (64,168 | ) |  | (60,096 | ) |
| Provision for income taxes | $ | 51,284 |  |  | $ | 10,594 |  |  | $ | 69,854 |  |

[0000866374-17-000005:notes:322]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2017, 2016 and 2015. The reconciliation of the income tax expense expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0000866374-17-000005:notes:323]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Income taxes based on domestic statutory rates | $ | 63,044 |  |  | $ | 77,295 |  |  | $ | 114,011 |  |
| Effect of tax rate differential | (85,132 | ) |  | (62,072 | ) |  | (75,699 | ) |
| Change in liability for uncertain tax positions | 684 |  |  | (13,724 | ) |  | 29,729 |  |
| Change in valuation allowance | 78,728 |  |  | 1,049 |  |  | 2,495 |  |
| Other | (6,040 | ) |  | 8,046 |  |  | (682 | ) |
| Provision for income taxes | $ | 51,284 |  |  | $ | 10,594 |  |  | $ | 69,854 |  |

[0000866374-17-000005:notes:324]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2017, 2016 and 2015 was $15.5 million, $6.6 million and $9.8 million, respectively. For fiscal year ended March 31, 2017, the effect on basic and diluted earnings per share was $0.03 and $0.03, respectively, and the effect on basic and diluted earnings per share were $0.01 and $0.01 during fiscal year 2016, and $0.02 and $0.02 during fiscal year 2015, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in the fiscal year ending March 31, 2018 through fiscal year 2022.

[0000866374-17-000005:notes:325]
For fiscal years ended March 31, 2017, 2016 and 2015, the Company released valuation allowances totaling $39.6 million, $63.3 million and $55.0 million, respectively. For the fiscal year ended March 31, 2017, these valuation allowance releases were primarily related to our operations in Austria, China, Ireland and Canada that were deemed to be more likely than not to realize the respective deferred tax assets due to sustained profitability during the prior three fiscal years as well as continued forecasted profitability of those subsidiaries. However, these valuation allowance eliminations were offset by other current period valuation allowance movements primarily related to current period valuation allowance additions due to increased deferred tax assets related to current period losses in legal entities with existing full valuation allowance positions. In addition, due to increased negative evidence during the fiscal year ended March 31, 2017, the Company added a valuation allowance of $14.4 million for a Chinese subsidiary which did not previously have a valuation allowance recorded. For fiscal years ended March 31, 2017, 2016 and 2015, the offsetting amounts totaled $103.9 million, $64.3 million and $57.5 million, respectively.

[0000866374-17-000005:notes:326]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years 2017, 2016 and 2015 were $67.9 million, $36.6 million and $0.0 million, respectively.

[0000866374-17-000005:notes:327]
The components of deferred income taxes are as follows:

[0000866374-17-000005:notes:328]
|  | As of March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (40,324 | ) |  | $ | (74,316 | ) |
| Intangible assets | (76,432 | ) |  | (88,760 | ) |
| Others | (20,702 | ) |  | (29,472 | ) |
| Total deferred tax liabilities | (137,458 | ) |  | (192,548 | ) |
| Deferred tax assets: |  |  |  |
| Fixed assets | 57,869 |  |  | 65,004 |  |
| Intangible assets | 3,153 |  |  | 3,795 |  |
| Deferred compensation | 19,335 |  |  | 15,892 |  |
| Inventory valuation | 8,489 |  |  | 10,124 |  |
| Provision for doubtful accounts | 2,911 |  |  | 1,300 |  |
| Net operating loss and other carryforwards | 2,369,405 |  |  | 2,332,894 |  |
| Others | 266,367 |  |  | 271,272 |  |
|  | 2,727,529 |  |  | 2,700,281 |  |
| Valuation allowances | (2,442,105 | ) |  | (2,385,489 | ) |
| Net deferred tax assets | 285,424 |  |  | 314,792 |  |
| Net deferred tax asset | $ | 147,966 |  |  | $ | 122,244 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Current asset (classified as other current assets) | $ | — |  |  | $ | — |  |
| Long-term asset | 223,285 |  |  | 222,772 |  |
| Long-term liability | (75,319 | ) |  | (100,528 | ) |
| Total | $ | 147,966 |  |  | $ | 122,244 |  |

[0000866374-17-000005:notes:329]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-17-000005:notes:330]
The Company has recorded deferred tax assets of approximately $2.4 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $128.5 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-17-000005:notes:331]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-17-000005:notes:332]
The Company does not provide for income taxes on approximately $1.2 billion of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. Determination of the amount of the unrecognized deferred tax liability on these undistributed earnings is not practicable. As of March 31, 2017, we have provided for applicable foreign withholding taxes on $70.6 million of undistributed foreign earnings related to certain Chinese subsidiaries whose earnings are not intended to be permanently reinvested, and recorded an associate deferred tax liability of approximately $7.1 million.

[0000866374-17-000005:notes:333]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-17-000005:notes:334]
|  | Fiscal Year EndedMarch 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Balance, beginning of fiscal year | $ | 212,326 |  |  | $ | 222,373 |  |
| Additions based on tax position related to the current year | 29,007 |  |  | 21,273 |  |
| Additions for tax positions of prior years | 9,728 |  |  | 20,453 |  |
| Reductions for tax positions of prior years | (22,065 | ) |  | (9,578 | ) |
| Reductions related to lapse of applicable statute of limitations | (13,390 | ) |  | (22,312 | ) |
| Settlements | (3,684 | ) |  | (12,797 | ) |
| Impact from foreign exchange rates fluctuation | (8,599 | ) |  | (7,086 | ) |
| Balance, end of fiscal year | $ | 203,323 |  |  | $ | 212,326 |  |

[0000866374-17-000005:notes:335]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an estimated range of an additional $9 million to $12 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-17-000005:notes:336]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2007.

[0000866374-17-000005:notes:337]
Of the $203.3 million of unrecognized tax benefits at March 31, 2017, $185.4 million will affect the annual effective tax rate ("ETR") if the benefits are eventually recognized. The amount that doesn’t impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-17-000005:notes:338]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company's tax expense. During the fiscal years ended March 31, 2017, 2016 and 2015, the Company recognized interest and penalties of approximately ($1.6) million and ($2.4) million and $2.5 million, respectively. The Company had approximately $12.9 million, $14.6 million and $17.0 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2017, 2016 and 2015, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000866374-17-000005:notes:339]
NONCONTROLLING INTERESTS

[0000866374-17-000005:notes:340]
During fiscal year 2014, a previously wholly-owned subsidiary of the Company issued a noncontrolling equity interest to certain third party investors for an ownership interest of less than 20% of the outstanding shares in the subsidiary. During fiscal year 2017, this subsidiary received $9.3 million in exchange for an additional noncontrolling equity interest from certain third party investors. The outstanding shares held by the third party investors in this subsidiary remained below 20%. The Company continues to own a majority of the subsidiary's outstanding equity and controls its board of directors. Accordingly, the consolidated financial statements include the financial position and results of operations of this subsidiary as of March 31, 2017 and for the year then ended.

[0000866374-17-000005:notes:341]
The Company has recognized the carrying value of the noncontrolling interest as a component of total shareholders' equity. The noncontrolling interest in the operating losses of the subsidiary were $8.5 million, $6.7 million, and $4.3 million for fiscal years 2017, 2016 and 2015, respectively, and were classified as a component of interest and other, net, in the Company's consolidated statements of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-17-000005:notes:342]
ORGANIZATION OF THE COMPANY

[0000866374-17-000005:notes:343]
Flex Ltd., formerly Flextronics International Ltd., ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and industrial products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments: Communications & Enterprise Compute ("CEC"), which includes telecom business of radio access base stations, remote radio heads, and small cells for wireless infrastructure; networking business which includes optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions; Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion, and mobile devices; and including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG is expanding its business relationships to include supply chain optimization for non-electronics products such as footwear and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of energy and metering, semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, and lighting; and High Reliability Solutions ("HRS"), which is comprised of medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military.

[0000866374-17-000005:notes:344]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-17-000005:notes:345]
OTHER CHARGES (INCOME), NET

[0000866374-17-000005:notes:346]
The fiscal year ended March 31, 2017 includes a $7.4 million loss attributable to a non-strategic facility sold during the second quarter of fiscal year 2017. No other components of other charges and income, net incurred during fiscal year 2017 were material.

[0000866374-17-000005:notes:347]
During fiscal year 2016, the Company incurred net losses of $47.7 million primarily due to $26.8 million loss on disposition of a non-strategic Western European manufacturing facility, which included a non-cash foreign currency translation loss of $25.3 million, and $21.8 million from the impairment of a non-core investment. These were offset by currency translation gains of $4.2 million.

[0000866374-17-000005:notes:348]
During fiscal year 2015, an amendment to a customer contract to reimburse a customer for certain performance provisions was executed which included the removal of a $55.0 million contractual obligation recognized during fiscal year 2014. Accordingly, the Company reversed this charge with a corresponding credit to other charges (income), net in the consolidated statement of operations. Additionally, during fiscal year 2015, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. The Company received $11.5 million in cash for the sale of $27.2 million in net assets of the facility. The loss also includes $4.6 million of estimated transaction costs, partially offset by a gain of $9.3 million for the release of cumulative foreign currency translation gains triggered by the disposition.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000866374-17-000005:notes:349]
QUARTERLY FINANCIAL DATA (UNAUDITED)

[0000866374-17-000005:notes:350]
The Company's third fiscal quarter ends on December 31, which are comprised of 92 days and 97 days for fiscal years 2017 and 2016, respectively. The fourth fiscal quarter and year ends on March 31 of each year, which is comprised of 90 days and 91 days for fiscal years 2017 and 2016, respectively. The first fiscal quarter ended on July 1, 2016, which is comprised of 92 days in the period, and June 26, 2015, which is comprised of 87 days in the period, respectively. The second fiscal quarter ended on September 30, 2016 and September 25, 2015, which are comprised of 91 days in both periods, respectively.

[0000866374-17-000005:notes:351]
The following table contains unaudited quarterly financial data for fiscal years 2017 and 2016.

[0000866374-17-000005:notes:352]
|  | Fiscal Year Ended March 31, 2017 |  | Fiscal Year Ended March 31, 2016 |
|  | First |  | Second |  | Third |  | Fourth |  | First |  | Second |  | Third |  | Fourth |
| Net sales | $ | 5,876,813 |  |  | $ | 6,008,525 |  |  | $ | 6,114,999 |  |  | $ | 5,862,597 |  |  | $ | 5,566,248 |  |  | $ | 6,316,762 |  |  | $ | 6,763,177 |  |  | $ | 5,772,698 |  |
| Gross profit (1) | 405,995 |  |  | 313,691 |  |  | 416,455 |  |  | 384,804 |  |  | 352,341 |  |  | 396,916 |  |  | 452,467 |  |  | 406,337 |  |
| Net income (loss) (2) | 105,729 |  |  | (2,508 | ) |  | 129,469 |  |  | 86,874 |  |  | 110,850 |  |  | 122,977 |  |  | 148,910 |  |  | 61,344 |  |
| Earnings per share (3): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.19 |  |  | $ | 0.00 |  |  | $ | 0.24 |  |  | $ | 0.16 |  |  | $ | 0.20 |  |  | $ | 0.22 |  |  | $ | 0.27 |  |  | $ | 0.11 |  |
| Diluted | $ | 0.19 |  |  | $ | 0.00 |  |  | $ | 0.24 |  |  | $ | 0.16 |  |  | $ | 0.19 |  |  | $ | 0.22 |  |  | $ | 0.27 |  |  | $ | 0.11 |  |

[0000866374-17-000005:notes:353]
| (1) | Gross profit for the second quarter of fiscal year 2017 was affected by $92.9 million of SunEdison bankruptcy related charges, as further described in Note 2. |

[0000866374-17-000005:notes:354]
| (2) | Net income for the second quarter of fiscal year 2017 was affected by $92.9 million of SunEdison bankruptcy related charges, as further described in Note 2. Net income for the fourth quarter of fiscal year 2016 was affected by $61.0 million of bad debt reserve charges, also related to the SunEdison bankruptcy. |

[0000866374-17-000005:notes:355]
| (3) | Earnings per share are computed independently for each quarter presented; therefore, the sum of the quarterly earnings per share may not equal the total earnings per share amounts for the fiscal year. |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-17-000005:notes:356]
RESTRUCTURING CHARGES

[0000866374-17-000005:notes:357]
During fiscal year 2017, the Company initiated a restructuring plan to accelerate its ability to support more Sketch-to-Scaletm efforts across the Company and reposition away from historical legacy programs and structures through rationalizing its current footprint at existing sites and at corporate SG&A functions. There were no material restructuring activities during fiscal years 2016 and 2015. Restructuring charges are recorded based upon employee termination dates, site closure and consolidation plans generally in conjunction with an overall corporate initiative to drive cost reduction and realign the Company's global footprint.

[0000866374-17-000005:notes:358]
During the fiscal year ended March 31, 2017, the Company recognized restructuring charges of approximately $49.4 million primarily for employee termination costs under the above plan. Of these total charges, approximately $38.8 million was recognized in cost of sales. Employee severance costs were associated with the terminations of 4,311 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 2,229, 1,988 and 94 for Asia, the Americas and Europe, respectively. All fiscal year 2017 restructuring activities were completed as of March 31, 2017.

[0000866374-17-000005:notes:359]
The components of the restructuring charges by geographic region incurred in fiscal year 2017 are as follows:

[0000866374-17-000005:notes:360]
|  | Second Quarter |  | Third Quarter |  | Fourth Quarter |  | Total |
|  | (In thousands) |
| Americas: |  |  |  |  |  |  |  |
| Severance | $ | 10,822 |  |  | $ | 6,263 |  |  | $ | 7,623 |  |  | $ | 24,708 |  |
| Contractual obligations | — |  |  | 489 |  |  | 3,353 |  |  | 3,842 |  |
| Total | 10,822 |  |  | 6,752 |  |  | 10,976 |  |  | 28,550 |  |
| Asia: |  |  |  |  |  |  |  |
| Severance | 263 |  |  | 9,701 |  |  | 5,110 |  |  | 15,074 |  |
| Contractual obligations | — |  |  | — |  |  | — |  |  | — |  |
| Total | 263 |  |  | 9,701 |  |  | 5,110 |  |  | 15,074 |  |
| Europe: |  |  |  |  |  |  |  |
| Severance | 454 |  |  | 968 |  |  | 1,049 |  |  | 2,471 |  |
| Contractual obligations | — |  |  | — |  |  | 3,300 |  |  | 3,300 |  |
| Total | 454 |  |  | 968 |  |  | 4,349 |  |  | 5,771 |  |
| Total |  |  |  |  |  |  |  |
| Severance | 11,539 |  |  | 16,932 |  |  | 13,782 |  |  | 42,253 |  |
| Contractual obligations | — |  |  | 489 |  |  | 6,653 |  |  | 7,142 |  |
| Total restructuring charges | $ | 11,539 |  |  | $ | 17,421 |  |  | $ | 20,435 |  |  | $ | 49,395 |  |

[0000866374-17-000005:notes:361]
Of the $49.4 million total restructuring charges incurred in fiscal year 2017, $15.2 million was associated with CEC, $8.1 million was associated with CTG, $5.4 million was associated with IEI, $16.1 million was associated with HRS, and the remaining $4.6 million was associated with general corporate activities. Restructuring charges are not included in segment income, as disclosed further in note 19.

[0000866374-17-000005:notes:362]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of March 31, 2017 for charges incurred in fiscal years 2017, 2016 and 2015 and prior periods:

[0000866374-17-000005:notes:363]
|  | Severance |  | OtherExit Costs |  | Total |
| Balance as of March 31, 2014 | $ | 36,493 |  |  | $ | 5,903 |  |  | $ | 42,396 |  |
| Cash payments for charges incurred in fiscal year 2014 and prior | (23,130 | ) |  | (4,209 | ) |  | (27,339 | ) |
| Balance as of March 31, 2015 | 13,363 |  |  | 1,694 |  |  | 15,057 |  |
| Cash payments for charges incurred in fiscal year 2014 and prior | (1,458 | ) |  | (359 | ) |  | (1,817 | ) |
| Balance as of March 31, 2016 | 11,905 |  |  | 1,335 |  |  | 13,240 |  |
| Provision for charges incurred in fiscal year 2017 | 42,253 |  |  | 7,142 |  |  | 49,395 |  |
| Cash payments for charges incurred in fiscal year 2017 | (25,894 | ) |  | — |  |  | (25,894 | ) |
| Cash payments for charges incurred in fiscal year 2014 and prior | (11,905 | ) |  | (1,335 | ) |  | (13,240 | ) |
| Balance as of March 31, 2017 | 16,359 |  |  | 7,142 |  |  | 23,501 |  |
| Less: Current portion (classified as other current liabilities) | 16,359 |  |  | 7,142 |  |  | 23,501 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0000866374-17-000005:notes:364]
|  | As of March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Asia | $ | 960,290 |  |  | 41 | % |  | $ | 1,013,317 |  |  | 45 | % |
| Americas | 939,888 |  |  | 41 | % |  | 886,305 |  |  | 39 | % |
| Europe | 416,848 |  |  | 18 | % |  | 358,011 |  |  | 16 | % |
|  | $ | 2,317,026 |  |  |  |  | $ | 2,257,633 |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000866374-17-000005:notes:365]
Geographic information is as follows:

[0000866374-17-000005:notes:366]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 10,962,075 |  |  | 46 | % |  | $ | 11,788,992 |  |  | 48 | % |  | $ | 12,953,004 |  |  | 50 | % |
| Americas | 8,582,849 |  |  | 36 | % |  | 8,347,514 |  |  | 34 | % |  | 8,897,868 |  |  | 34 | % |
| Europe | 4,318,010 |  |  | 18 | % |  | 4,282,379 |  |  | 18 | % |  | 4,297,044 |  |  | 16 | % |
|  | $ | 23,862,934 |  |  |  |  | $ | 24,418,885 |  |  |  |  | $ | 26,147,916 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-17-000005:notes:367]
During fiscal year 2017, 2016 and 2015, depreciation expense included in the segment's measure of operating performance above is as follows:

[0000866374-17-000005:notes:368]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Depreciation expense |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 133,057 |  |  | $ | 117,710 |  |  | $ | 130,311 |  |
| Consumer Technologies Group | 110,379 |  |  | 123,139 |  |  | 203,808 |  |
| Industrial & Emerging Industries | 70,814 |  |  | 72,415 |  |  | 64,541 |  |
| High Reliability Solutions | 88,604 |  |  | 80,935 |  |  | 62,831 |  |
| Corporate and Other | 29,384 |  |  | 31,530 |  |  | 35,334 |  |
| Total depreciation expense | $ | 432,238 |  |  | $ | 425,729 |  |  | $ | 496,825 |  |

[0000866374-17-000005:notes:369]
Selected financial information by segment is as follows:

[0000866374-17-000005:notes:370]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 8,383,420 |  |  | $ | 8,841,642 |  |  | $ | 9,191,211 |  |
| Consumer Technologies Group | 6,362,338 |  |  | 6,997,526 |  |  | 8,940,043 |  |
| Industrial & Emerging Industries | 4,967,738 |  |  | 4,680,718 |  |  | 4,459,351 |  |
| High Reliability Solutions | 4,149,438 |  |  | 3,898,999 |  |  | 3,557,311 |  |
|  | $ | 23,862,934 |  |  | $ | 24,418,885 |  |  | $ | 26,147,916 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 229,332 |  |  | $ | 265,076 |  |  | $ | 257,323 |  |
| Consumer Technologies Group | 179,910 |  |  | 163,677 |  |  | 218,251 |  |
| Industrial & Emerging Industries | 179,749 |  |  | 157,588 |  |  | 131,956 |  |
| High Reliability Solutions | 334,108 |  |  | 294,635 |  |  | 227,595 |  |
| Corporate and Other | (107,850 | ) |  | (89,219 | ) |  | (83,988 | ) |
| Total income | 815,249 |  |  | 791,757 |  |  | 751,137 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 81,396 |  |  | 65,965 |  |  | 32,035 |  |
| Stock-based compensation | 82,266 |  |  | 77,580 |  |  | 50,270 |  |
| SunEdison bankruptcy related (Note 2) | 92,915 |  |  | 61,006 |  |  | — |  |
| Restructuring and other (1) | 67,099 |  |  | — |  |  | — |  |
| Other charges (income), net | 21,193 |  |  | 47,738 |  |  | (53,233 | ) |
| Interest and other, net | 99,532 |  |  | 84,793 |  |  | 51,410 |  |
| Income before income taxes | $ | 370,848 |  |  | $ | 454,675 |  |  | $ | 670,655 |  |

[0000866374-17-000005:notes:371]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-17-000005:notes:372]
| (1) | During the fiscal year ended March 31, 2017, the Company initiated a restructuring plan to accelerate its ability to support more Sketch-to-Scaletm efforts across the Company and reposition away from historical legacy programs and structures through rationalizing its current footprint at existing sites and at corporate SG&A functions. This charge is primarily for employee terminations costs, as described in note 14, as well as other asset impairments, and is split between cost of sales and selling, general and administration expenses on the Company's consolidated statement of operations. This charge is excluded from the measurement of the Company's operating segment's performance. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-17-000005:notes:373]
SEGMENT REPORTING

[0000866374-17-000005:notes:374]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the Chief Operating Decision Maker ("CODM"), or a decision making group, in deciding how to allocate resources and in assessing performance. Resource allocation decisions and the Company's performance are assessed by its Chief Executive Officer ("CEO"), with support from his direct staff who oversee certain operations of the business, collectively identified as the CODM or the decision making group.

[0000866374-17-000005:notes:375]
The Company has four reportable segments: HRS, CTG, IEI, and CEC. These segments represent components of the Company for which separate financial information is available that is utilized on a regular basis by the CODM. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 to the financial statements for a description of the various product categories manufactured under each of these segments.

[0000866374-17-000005:notes:376]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges and other, distressed customer charges, other charges (income), net and interest and other, net.

[0000866374-17-000005:notes:377]
Property and equipment on a segment basis is not disclosed as it is not separately identified and is not internally reported by segment to the Company's CODM. During fiscal year 2017, 2016 and 2015, depreciation expense included in the segment's measure of operating performance above is as follows:

[0000866374-17-000005:notes:378]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0000866374-17-000005:notes:379]
During fiscal years 2017, 2016 and 2015, net sales generated from Singapore, the principal country of domicile, were approximately $595.3 million, $519.1 million and $553.4 million, respectively.

[0000866374-17-000005:notes:380]
During fiscal year 2017, China, Mexico, the United States and Malaysia accounted for approximately 30%, 17%, 11% and 10% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2017.

[0000866374-17-000005:notes:381]
During fiscal year 2016, China, Mexico, and the United States accounted for approximately 35%, 15%, and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2016.

[0000866374-17-000005:notes:382]
During fiscal year 2015, China, Mexico, and the United States accounted for approximately 37%, 13% and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2015.

[0000866374-17-000005:notes:383]
As of March 31, 2017 and 2016, property and equipment, net held in Singapore were approximately $13.2 million and $13.4 million, respectively.

[0000866374-17-000005:notes:384]
As of March 31, 2017, China, Mexico and the United States accounted for approximately 31%, 23% and 13%, respectively, of property and equipment, net. No other country accounted for more than 10% of property and equipment, net as of March 31, 2017.

[0000866374-17-000005:notes:385]
As of March 31, 2016, China, Mexico and the United States accounted for approximately 35%, 19% and 15%, respectively, of property and equipment, net. No other country accounted for more than 10% of property and equipment, net as of March 31, 2016.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-17-000005:notes:386]
TRADE RECEIVABLES SECURITIZATION

[0000866374-17-000005:notes:387]
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-17-000005:notes:388]
Asset-Backed Securitization Programs

[0000866374-17-000005:notes:389]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the "Global Program") and its North American Asset-Backed Securitization Agreement (the "North American Program," collectively, the "ABS Programs") to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $850.0 million for the Global Program, of which $750.0 million is committed and $100.0 million is uncommitted, and $250.0 million for the North American Program, of which $210.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0000866374-17-000005:notes:390]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the fiscal years ended March 31, 2017, 2016 and 2015 were not material and are included in interest and other, net within the consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-17-000005:notes:391]
As of March 31, 2017 and 2016, the accounts receivable balances that were sold under the ABS Programs were removed from the consolidated balance sheets and the net cash proceeds received by the Company during fiscal years ended March 31, 2017, 2016 and 2015 were included as cash provided by operating activities in the consolidated statements of cash flows.

[0000866374-17-000005:notes:392]
As of March 31, 2017, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of $1.0 billion and deferred purchase price receivables of $506.5 million. As of March 31, 2016, approximately $1.4 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $880.8 million and deferred purchase price receivables of $501.1 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of March 31, 2017 and 2016, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the consolidated statements of operations. Refer to note 16 for more details.

[0000866374-17-000005:notes:393]
For the fiscal years ended March 31, 2017, 2016 and 2015, cash flows from sales of receivables under the ABS Programs consisted of approximately $5.7 billion, $5.2 billion and $4.3 billion, respectively, for transfers of receivables (of which approximately $0.4 billion for both fiscal years 2017 and 2016, and $0.3 billion for fiscal year 2015, represented new transfers and the remainder proceeds from collections reinvested in revolving period transfers).

[0000866374-17-000005:notes:394]
Trade Accounts Receivable Sale Programs

[0000866374-17-000005:notes:395]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $225.2 million and $339.4 million as of March 31, 2017 and 2016, respectively. For the years ended March 31, 2017, 2016 and 2015, total accounts receivables sold to certain third party banking institutions was approximately $1.3 billion, $2.3 billion and $4.2 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and were reflected as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-17-000005:notes:396]
SHARE REPURCHASE PLAN

[0000866374-17-000005:notes:397]
During fiscal year 2017, the Company repurchased approximately 25.1 million shares for an aggregate purchase value of approximately $345.8 million under two separate repurchase plans as further discussed below.

[0000866374-17-000005:notes:398]
During the first and second quarters of fiscal year 2017, the Company repurchased the entire remaining amount under a share repurchase plan that was approved by the Company's Board of Directors on August 20, 2015 and the Company's shareholders at the 2015 Extraordinary General Meeting. The Company repurchased approximately 10.4 million shares for an aggregate purchase value of approximately $131.1 million, and retired all of these shares.

[0000866374-17-000005:notes:399]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 24, 2016. During fiscal year 2017, the Company repurchased approximately 14.7 million shares for an aggregate purchase value of approximately $214.7 million under this plan, and retired all of these shares. As of March 31, 2017, shares in the aggregate amount of $285.3 million were available to be repurchased under the current plan.
