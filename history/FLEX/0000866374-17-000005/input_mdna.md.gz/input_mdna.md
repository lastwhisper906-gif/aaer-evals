# FLEX MD&A — 0000866374-17-000005


## mdna

[0000866374-17-000005:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-17-000005:mdna:2]
OVERVIEW

[0000866374-17-000005:mdna:3]
We are a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer and industrial products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through our activities in the following segments: Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads, and small cells for wireless infrastructure; our networking business which includes optical, routing, broadcasting, and switching products for the data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions; Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion, and mobile devices; and including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG is expanding its business relationships to include supply

[0000866374-17-000005:mdna:4]
31

[0000866374-17-000005:mdna:5]
chain optimization for non-electronics products such as footwear and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of energy and metering, semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, and lighting; and High Reliability Solutions ("HRS"), which is comprised of our medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; our automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies; and our defense and aerospace businesses, focused on commercial aviation, defense and military.

[0000866374-17-000005:mdna:6]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-17-000005:mdna:7]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0000866374-17-000005:mdna:8]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we are able to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customer's supply chain solutions needs across all of the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-17-000005:mdna:9]
During the past few years, we have made significant efforts to evolve our long-term portfolio towards a higher mix of businesses which possess longer product life cycles and higher segment operating margins such as reflected in our IEI and HRS businesses. During the last two fiscal years, we launched several programs broadly across our portfolio of services and in some instances we deployed certain new technologies. Some of these programs have started to yield better results, as demonstrated by our segment operating margin improvement while our sales decreased compared to the prior year. We continue to invest in innovation and we have expanded our design and engineering relationships through our product innovation centers.

[0000866374-17-000005:mdna:10]
We believe that our business transformation has strategically positioned us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services, which remain strong.

[0000866374-17-000005:mdna:11]
We are one of the world's largest providers of global supply chain solutions, with revenues of $23.9 billion in fiscal year 2017. We have established an extensive network of manufacturing facilities in the world's major consumer electronics and industrial markets (Asia, the Americas, and Europe) in order to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer electronics and industrial products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. As of March 31, 2017, our total manufacturing capacity was approximately 27 million square feet. In fiscal year 2017, our net sales in Asia, the Americas and Europe represented approximately 46%, 36% and 18%, respectively, of our total net sales, based on the location of the manufacturing site. The following tables set forth net sales and net property and equipment, by country, based on the location of our manufacturing sites and the relative percentages:

[0000866374-17-000005:mdna:12]
|  | Fiscal Year Ended March 31, |
| Net sales: | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| China | $ | 7,213,614 |  |  | 30 | % |  | $ | 8,471,036 |  |  | 35 | % |  | $ | 9,550,837 |  |  | 37 | % |
| Mexico | 4,075,616 |  |  | 17 | % |  | 3,645,432 |  |  | 15 | % |  | 3,512,767 |  |  | 13 | % |
| U.S. | 2,560,300 |  |  | 11 | % |  | 2,767,641 |  |  | 11 | % |  | 2,876,359 |  |  | 11 | % |
| Malaysia | 2,267,578 |  |  | 10 | % |  | 2,241,645 |  |  | 9 | % |  | 2,300,579 |  |  | 9 | % |
| Brazil | 1,907,591 |  |  | 8 | % |  | 1,839,395 |  |  | 8 | % |  | 2,474,291 |  |  | 9 | % |
| Other | 5,838,235 |  |  | 24 | % |  | 5,453,736 |  |  | 22 | % |  | 5,433,083 |  |  | 21 | % |
|  | $ | 23,862,934 |  |  |  |  | $ | 24,418,885 |  |  |  |  |  | $ | 26,147,916 |  |  |  |  |

[0000866374-17-000005:mdna:13]
|  | Fiscal Year Ended March 31, |
| Property and equipment, net: | 2017 |  | 2016 |
|  | (In thousands) |
| China | $ | 719,972 |  |  | 31 | % |  | $ | 789,571 |  |  | 35 | % |
| Mexico | 525,282 |  |  | 23 | % |  | 429,989 |  |  | 19 | % |
| U.S. | 290,463 |  |  | 13 | % |  | 330,778 |  |  | 15 | % |
| Malaysia | 173,410 |  |  | 7 | % |  | 159,787 |  |  | 7 | % |
| Hungary | 132,527 |  |  | 6 | % |  | 107,492 |  |  | 5 | % |
| Other | 475,372 |  |  | 21 | % |  | 425,559 |  |  | 19 | % |
|  | $ | 2,317,026 |  |  |  |  | $ | 2,243,176 |  |  |  |

[0000866374-17-000005:mdna:14]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and industrial campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer electronics and industrial products for leading multinational and regional customers. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-17-000005:mdna:15]
Our operating results are affected by a number of factors, including the following:

[0000866374-17-000005:mdna:16]
| • | changes in the macro-economic environment and related changes in consumer demand; |

[0000866374-17-000005:mdna:17]
| • | the mix of the manufacturing services we are providing, the number and size of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors; |

[0000866374-17-000005:mdna:18]
| • | the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance; |

[0000866374-17-000005:mdna:19]
| • | our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers; |

[0000866374-17-000005:mdna:20]
| • | the effects on our business due to our customers' products having short product life cycles; |

[0000866374-17-000005:mdna:21]
| • | our customers' ability to cancel or delay orders or change production quantities; |

[0000866374-17-000005:mdna:22]
| • | our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements; |

[0000866374-17-000005:mdna:23]
| • | our exposure to financially troubled customers; |

[0000866374-17-000005:mdna:24]
| • | integration of acquired businesses and facilities; |

[0000866374-17-000005:mdna:25]
| • | increased labor costs due to adverse labor conditions in the markets we operate; |

[0000866374-17-000005:mdna:26]
| • | changes in tax legislation; and |

[0000866374-17-000005:mdna:27]
| • | changes in trade regulations and treaties. |

[0000866374-17-000005:mdna:28]
We also are subject to other risks as outlined in Item 1A, "Risk Factors".

[0000866374-17-000005:mdna:29]
Net sales for fiscal year 2017 declined from the prior year, decreasing by 2.3% or $0.6 billion to $23.9 billion. The decrease was primarily due to a $0.6 billion decrease in our CTG segment as well as a $0.5 billion decrease in our CEC segment, partially offset by a $0.3 billion increase in our IEI segment, and a $0.2 billion increase in our HRS segment. Our fiscal year 2017 gross profit totaled $1.5 billion, representing a decrease of $87.1 million, or 5.4%, from the prior year, which is primarily driven by a $92.9 million charge following the significant decline in prices for solar modules coupled with the restructuring charges of $49.4 million, of which $38.8 million impacted gross margin, incurred during fiscal year 2017 in a plan

[0000866374-17-000005:mdna:30]
33

[0000866374-17-000005:mdna:31]
to accelerate our ability to support more Sketch-to-Scaletm efforts across the Company and reposition away from historical legacy programs and structures. Our net income totaled $319.6 million, representing a decrease of $124.5 million, or 28.0%, compared to fiscal year 2016. The decrease in net income during fiscal year 2017 is primarily due to the same factors explained above.

[0000866374-17-000005:mdna:32]
Cash provided by operations remained consistent at $1.1 billion for the fiscal years 2017 and 2016. Cash used in investing activities decreased by approximately $0.7 billion to a total amount of $0.7 billion for fiscal year 2017 compared with $1.4 billion for fiscal year 2016 primarily due to a decrease in the amount of cash paid for acquired businesses during fiscal year 2017. Our average net working capital, defined as accounts receivable, including deferred purchase price receivable from our asset-backed securitization programs plus inventory less accounts payable, as a percentage of annualized sales decreased by 0.8% to 6.9%. Our free cash flow, which we define as cash from operating activities less net purchases of property and equipment, was $660.4 million for fiscal year 2017 compared to $639.5 million for fiscal year 2016. The increase in free cash flow is primarily due to higher cash flows from operations. Refer to the Liquidity and Capital Resources section for the free cash flows reconciliation to our most directly comparable GAAP financial measure of cash flows from operations. Cash used in financing activities amounted to $242.1 million during fiscal year 2017, which changed $491.7 million from a cash inflow of $249.6 million in the prior year primarily due to lower net proceeds from bank borrowings and long-term debt.

[0000866374-17-000005:mdna:33]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000866374-17-000005:mdna:34]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results may differ from those estimates and assumptions.

[0000866374-17-000005:mdna:35]
We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-17-000005:mdna:36]
Revenue Recognition

[0000866374-17-000005:mdna:37]
We recognize manufacturing revenue when we ship goods or the goods are received by our customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then we recognize the related revenues at the time when such requirements are completed and the obligations are fulfilled. Some of our customer contracts allow us to recover certain costs related to manufacturing services that are over and above the prices we charge for the related products. We determine the amount of costs that are recoverable based on historical experiences and agreements with those customers. Also, certain customer contracts may contain certain commitments and obligations that may result in additional expenses or decrease in revenue. We accrue for these commitments and obligations based on facts and circumstances and contractual terms. We also make provisions for estimated sales returns and other adjustments at the time revenue is recognized based upon contractual terms and an analysis of historical returns. Provisions for sales returns and other adjustments were not material to our consolidated financial statements for any of the periods presented.

[0000866374-17-000005:mdna:38]
We also recognize revenue in accordance with multiple-element arrangements accounting codified under U.S. GAAP for arrangements that contain multiple deliverables. We determined that our multiple-element arrangements are generally comprised of arrangements where multiple product components are sold together as part of a complete system. Depending on the contractual provisions of the respective contracts, we have concluded that the units of accounting for such arrangements are, in most cases, comprised of an aggregation of product components, however, may also be established at the product component level. For multiple-element arrangements, revenue is allocated to each unit of accounting based on their relative selling prices. Relative selling prices are based first on vendor specific objective evidence of fair value (“VSOE”), then on third-party evidence of selling price (“TPE”) when VSOE does not exist, and then on management's best estimate of the selling price (“BESP”) when VSOE and TPE do not exist. We base the allocation of revenue on BESP, because we do not have either VSOE or TPE for the respective deliverables.

[0000866374-17-000005:mdna:39]
We provide a comprehensive suite of services for our customers that range from advanced product design to manufacturing and logistics to after-sales services. We recognize service revenue when the services have been performed, and the related costs are expensed as incurred. Our net sales for services were less than 10% of our total sales for all periods presented, and accordingly, are included in net sales in the consolidated statements of operations.

[0000866374-17-000005:mdna:40]
34

[0000866374-17-000005:mdna:41]
Customer Credit Risk

[0000866374-17-000005:mdna:42]
We have an established customer credit policy through which we manage customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. We perform ongoing credit evaluations of our customers' financial condition and make provisions for doubtful accounts based on the outcome of those credit evaluations. We evaluate the collectability of accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent we identify exposures as a result of credit or customer evaluations, we also review other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-17-000005:mdna:43]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison"), filed a petition for reorganization under bankruptcy law. During the fiscal year ended March 31, 2016, we recognized a bad debt reserve charge of $61.0 million associated with our outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. We determined that certain solar panel inventory previously designated for SunEdison on hand at the end of the second quarter of fiscal year 2017 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market during fiscal year 2017. In addition, we recognized a $16.0 million impairment charge for solar module equipment and incurred $16.9 million of incremental costs primarily related to negative margin sales and other associated solar panel direct costs. The total charge of $92.9 million is included in cost of sales for fiscal year 2017.

[0000866374-17-000005:mdna:44]
Restructuring Charges

[0000866374-17-000005:mdna:45]
We recognize restructuring charges related to our plans to close or consolidate excess manufacturing facilities and rationalize administrative functions and to realign our corporate cost structure. In connection with these activities, we recognize restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-17-000005:mdna:46]
The recognition of these restructuring charges requires that we make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent our actual results differ from our estimates and assumptions, we may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, we evaluate the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed exit plans.

[0000866374-17-000005:mdna:47]
Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-17-000005:mdna:48]
Inventory Valuation

[0000866374-17-000005:mdna:49]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regard to inventory procured to fulfill customer demand.

[0000866374-17-000005:mdna:50]
Carrying Value of Long-Lived Assets

[0000866374-17-000005:mdna:51]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset may not be recoverable. An impairment loss is recognized when the carrying amount of these long-lived assets exceeds their fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such assets are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, general business environment and other factors. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize additional impairment charges in the future.

[0000866374-17-000005:mdna:52]
35

[0000866374-17-000005:mdna:53]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. The Company performed its goodwill impairment assessment on January 1, 2017 and determined that no impairment existed as of the date of the impairment test because the fair value of each reporting unit exceeded its carrying value.

[0000866374-17-000005:mdna:54]
Contingent Liabilities

[0000866374-17-000005:mdna:55]
We may be exposed to certain liabilities relating to our business operations, acquisitions of businesses and assets and other activities. We make provisions for such liabilities when it is probable that the settlement of the liability will result in an outflow of economic resources or the impairment of an asset. We make these assessments based on facts and circumstances that may change in the future resulting in additional expenses.

[0000866374-17-000005:mdna:56]
Income Taxes

[0000866374-17-000005:mdna:57]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-17-000005:mdna:58]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 13 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-17-000005:mdna:59]
Translation of Foreign Currencies

[0000866374-17-000005:mdna:60]
The financial position and results of operations for certain of our subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive loss, a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results.

[0000866374-17-000005:mdna:61]
36

[0000866374-17-000005:mdna:62]
RESULTS OF OPERATIONS

[0000866374-17-000005:mdna:63]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data." The data below, and discussion that follows, represents our results from operations.

[0000866374-17-000005:mdna:64]
|  | Fiscal Year EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.5 |  |  | 93.4 |  |  | 94.1 |  |
| Restructuring charges | 0.2 |  |  | — |  |  | — |  |
| Gross profit | 6.3 |  |  | 6.6 |  |  | 5.9 |  |
| Selling, general and administrative expenses | 3.9 |  |  | 3.9 |  |  | 3.2 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.1 |  |
| Restructuring charges | — |  |  | — |  |  | — |  |
| Other charges (income), net | 0.1 |  |  | 0.2 |  |  | (0.2 | ) |
| Interest and other, net | 0.4 |  |  | 0.3 |  |  | 0.2 |  |
| Income before income taxes | 1.6 |  |  | 1.9 |  |  | 2.6 |  |
| Provision for income taxes | 0.2 |  |  | — |  |  | 0.3 |  |
| Net Income | 1.4 | % |  | 1.9 | % |  | 2.3 | % |

[0000866374-17-000005:mdna:65]
Net sales

[0000866374-17-000005:mdna:66]
Net sales during fiscal year 2017 totaled $23.9 billion, representing a decrease of $0.6 billion, or 2.3%, from $24.4 billion during fiscal year 2016, largely attributable to the closure of our Lenovo/Motorola dedicated China operations. During fiscal year 2017, net sales decreased $0.8 billion in Asia, while increasing $0.2 billion in the Americas, and $35.6 million in Europe.

[0000866374-17-000005:mdna:67]
Net sales during fiscal year 2016 totaled $24.4 billion, representing a decrease of $1.7 billion, or 6.6%, from $26.1 billion during fiscal year 2015. During fiscal year 2016, net sales decreased $1.2 billion in Asia, $0.6 billion in the Americas, and $14.7 million in Europe.

[0000866374-17-000005:mdna:68]
The following table sets forth net sales by segments and their relative percentages. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0000866374-17-000005:mdna:69]
|  | Fiscal Year Ended March 31, |
| Segments: | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Communications & Enterprise Compute | $ | 8,383,420 |  |  | 35 | % |  | $ | 8,841,642 |  |  | 36 | % |  | $ | 9,191,211 |  |  | 35 | % |
| Consumer Technologies Group | 6,362,338 |  |  | 27 | % |  | 6,997,526 |  |  | 29 | % |  | 8,940,043 |  |  | 34 | % |
| Industrial & Emerging Industries | 4,967,738 |  |  | 21 | % |  | 4,680,718 |  |  | 19 | % |  | 4,459,351 |  |  | 17 | % |
| High Reliability Solutions | 4,149,438 |  |  | 17 | % |  | 3,898,999 |  |  | 16 | % |  | 3,557,311 |  |  | 14 | % |
|  | $ | 23,862,934 |  |  |  |  |  | $ | 24,418,885 |  |  |  |  |  | $ | 26,147,916 |  |  |  |  |

[0000866374-17-000005:mdna:70]
Net sales during fiscal year 2017 decreased $0.6 billion or 9% in the CTG segment and $0.5 billion or 5% in the CEC segment. The decline in sales for CTG was primarily due to a decline in demand from our largest smartphone customer Lenovo/Motorola in connection with our exit of a China operation dedicated to them, partially offset by revenues from our Bose acquisition as well as ramping of a broad mix of customers. The decrease in CEC is largely attributable to lower sales within our legacy server and storage business. These decreases were partially offset by a $287.0 million or 6% increase in sales from our IEI segment driven by contribution from our NEXTracker Inc. ("NEXTracker") acquisition and expansion within our capital equipment business, and by a $250.4 million or 6% increase in sales from our HRS segment primarily driven by automotive business.

[0000866374-17-000005:mdna:71]
37

[0000866374-17-000005:mdna:72]
Net sales during fiscal year 2016 decreased $1.9 billion or 22% in the CTG segment and $349.6 million or 4% in the CEC segment. The drop in CTG was due to a decline in demand from our largest customer in our mobile business offset by expansion across wearables, connected home and gaming markets. The decrease in CEC is primarily attributable to lower sales within our server and storage business. These decreases were partially offset by a $341.7 million or 10% increase in sales from our HRS segment, and by a $221.4 million or 5% increase in sales from our IEI segment. These increases in HRS and IEI were attributable to an increase across multiple product categories and customers, most notably in our household, energy, automotive, and medical businesses primarily as a result of our strategic acquisitions in both segments referred to below.

[0000866374-17-000005:mdna:73]
Our ten largest customers during fiscal years 2017, 2016 and 2015 accounted for approximately 43%, 46% and 50% of net sales, respectively. We have made substantial efforts toward the diversification of our portfolio which allow us to operate at scale in so many different industries, as a result no customer accounted for greater than 10% of net sales in fiscal year 2017. During fiscal years 2016 and 2015, only Lenovo/Motorola (including net sales from its former parent, Google, up to the point in time when Motorola Mobility was acquired by Lenovo and including net sales from Lenovo thereafter), which is reflected in our CTG segment, accounted for greater than 10% of net sales. Going forward, we do not expect Motorola Mobility to account for greater than 10% of our net sales.

[0000866374-17-000005:mdna:74]
Gross profit

[0000866374-17-000005:mdna:75]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion and consolidation of manufacturing facilities. The flexible design of our manufacturing processes allows us to build a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-17-000005:mdna:76]
Gross profit during fiscal year 2017 decreased $87.1 million to $1.5 billion from $1.6 billion during fiscal year 2016 primarily as a result of the $92.9 million, or 40 basis points, of charges recognized related to the significant decline in prices for solar modules and the slowdown in demand as previously discussed under our customer credit risk section, coupled with the restructuring charges incurred during fiscal year 2017, to accelerate our ability to support more Sketch-to-Scaletm efforts across the Company. A portion of this decrease was offset by our strategic evolution and structural mix shift to higher margin end markets in our IEI and HRS segments while also providing greater levels of innovation, design and engineering services. Gross margin decreased 30 basis points, to 6.3% of net sales in fiscal year 2017, from 6.6% of net sales in fiscal year 2016, mainly attributable to the same factors previously described.

[0000866374-17-000005:mdna:77]
Gross profit during fiscal year 2016 increased $62.7 million to $1.6 billion from $1.5 billion during fiscal year 2015 reflecting a richer mix of business and improved operational execution while ramping new customers and programs during fiscal year 2016. Gross margin increased to 6.6% of net sales in fiscal year 2016 as compared with 5.9% of net sales in fiscal year 2015. Gross margins improved 70 basis points in fiscal year 2016 compared to that of fiscal year 2015 due to proportionate increased share of our total revenue attributable to our HRS and IEI segments coupled with their increased profitability primarily driven by our acquisitions of Mirror Controls International ("MCi") and NEXTracker.

[0000866374-17-000005:mdna:78]
Segment income

[0000866374-17-000005:mdna:79]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges and other, distressed customer charges, other charges (income), net and interest and other, net. A portion of depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-17-000005:mdna:80]
The following table sets forth segment income and margins:

[0000866374-17-000005:mdna:81]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |
| CEC | $ | 229,332 |  |  | 2.7 | % |  | $ | 265,076 |  |  | 3.0 | % |  | $ | 257,323 |  |  | 2.8 | % |
| CTG | 179,910 |  |  | 2.8 | % |  | 163,677 |  |  | 2.3 | % |  | 218,251 |  |  | 2.4 | % |
| IEI | 179,749 |  |  | 3.6 | % |  | 157,588 |  |  | 3.4 | % |  | 131,956 |  |  | 3.0 | % |
| HRS | 334,108 |  |  | 8.1 | % |  | 294,635 |  |  | 7.6 | % |  | 227,595 |  |  | 6.4 | % |
| Corporate and Other | (107,850 | ) |  |  |  | (89,219 | ) |  |  |  | (83,988 | ) |  |  |
| Total segment income | 815,249 |  |  | 3.4 | % |  | 791,757 |  |  | 3.2 | % |  | 751,137 |  |  | 2.9 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 81,396 |  |  |  |  | 65,965 |  |  |  |  | 32,035 |  |  |  |
| Stock-based compensation | 82,266 |  |  |  |  | 77,580 |  |  |  |  | 50,270 |  |  |  |
| SunEdison bankruptcy related (Note 2) | 92,915 |  |  |  |  | 61,006 |  |  |  |  | — |  |  |  |
| Restructuring and other (1) | 67,099 |  |  |  |  | — |  |  |  |  | — |  |  |  |
| Other charges (income), net | 21,193 |  |  |  |  | 47,738 |  |  |  |  | (53,233 | ) |  |  |
| Interest and other, net | 99,532 |  |  |  |  | 84,793 |  |  |  |  | 51,410 |  |  |  |
| Income before income taxes | $ | 370,848 |  |  |  |  | $ | 454,675 |  |  |  |  | $ | 670,655 |  |  |  |

[0000866374-17-000005:mdna:82]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-17-000005:mdna:83]
| (1) | During the fiscal year ended March 31, 2017, we initiated a restructuring plan to accelerate its ability to support more Sketch-to-Scaletm efforts across the Company and reposition away from historical legacy programs and structures through rationalizing its current footprint at existing sites and at corporate SG&A functions. This charge is primarily for employee terminations costs, as described in note 14 to the consolidated financial statements, as well as other asset impairments, and is split between cost of sales and selling, general and administration expenses on our consolidated statement of operations. This charge is excluded from the measurement of our operating segment's performance. |

[0000866374-17-000005:mdna:84]
CEC segment margin decreased 30 basis points to 2.7%, for fiscal year 2017, from 3.0% during fiscal year 2016. The decrease was driven by lower capacity utilization causing reduced overhead absorption, pricing pressures coupled with incremental costs for proactive repositioning of certain programs and actions to better align CEC's operating structure. CEC segment margin increased 20 basis points, for fiscal year 2016, from 2.8% during fiscal year 2015. The improvements were driven by a favorable product mix changes from new program offerings, higher utilization levels and strong operational execution across multiple customers and facilities, offset by incremental engineering spend as we continue to invest in expanding our capabilities in converged infrastructure.

[0000866374-17-000005:mdna:85]
CTG segment margin increased 50 basis points to 2.8% for fiscal year 2017, from 2.3% during fiscal year 2016, primarily driven by a portfolio shift within the CTG product mix with a greater concentration of higher margin products where we provide greater levels of design and engineering value-added content, as well as exiting of lower margin businesses and the benefit from a better-than-expected execution on certain products which were going end of life. CTG segment margin slightly decreased 10 basis points for fiscal year 2016, from 2.4% during fiscal year 2015, due primarily to the soft macro economy, notably in Brazil, which impacted consumer business, partially offset by a portfolio shift within the CTG product mix focusing on higher margin consumer electronics products.

[0000866374-17-000005:mdna:86]
IEI segment margin increased 20 basis points to 3.6% for fiscal year 2017, from 3.4% during fiscal year 2016. This is primarily driven by new program ramps and demand increase in capital equipment and household industrial and lifestyle, partially offset by underperformance from the loss of SunEdison, which was formerly our largest IEI customer and relatedly, from sales of solar panel inventory acquired from SunEdison in 2016. IEI segment margin increased 40 basis points to 3.4% for fiscal year 2016, from 3.0% during fiscal year 2015. This is primarily due to strong operational execution and higher utilization levels coupled with additional margin enhancement from our NEXTracker acquisition that contributed higher margins for the second half of fiscal year 2016.

[0000866374-17-000005:mdna:87]
39

[0000866374-17-000005:mdna:88]
HRS segment margin increased 50 basis points to 8.1% for fiscal year 2017, from 7.6% during fiscal year 2016. The improvements are primarily the result of new program launches and richer mix with greater value-added business engagements as a result of greater design and engineering solutions as part of our Sketch-to-Scaletm offering. HRS segment margin increased 120 basis points to 7.6% for fiscal year 2016, from 6.4% for fiscal year 2015 primarily due to additional flow through from the increase in revenue from new programs and contribution from our MCi acquisition starting in our second quarter of fiscal year 2016. Additional margin was related to greater value-added business engagements resulting from an increase in design and engineering solutions as part of our Sketch-to-Scaletm offering.

[0000866374-17-000005:mdna:89]
Restructuring charges

[0000866374-17-000005:mdna:90]
During fiscal year 2017, we initiated a restructuring plan to accelerate our ability to support more Sketch-to-Scaletm efforts across the Company and reposition away from historical legacy programs and structures through rationalizing our current footprint at existing sites including certain corporate SG&A functions. We recognized $49.4 million of pre-tax restructuring charges predominantly for employee termination costs. The restructuring charges by geographic region were $28.5 million in the Americas, $15.1 million in Asia and $5.8 million in Europe. We classified $38.8 million of these charges as a component of cost of sales and $10.6 million as a component of selling, general and administrative expenses. There were no material restructuring activities during fiscal years 2016 and 2015.

[0000866374-17-000005:mdna:91]
As of March 31, 2017 the plan had been completed and the accrued costs relating to the restructuring charges were $23.5 million of which $23.5 million was classified as a current obligation.

[0000866374-17-000005:mdna:92]
Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-17-000005:mdna:93]
Selling, general and administrative expenses

[0000866374-17-000005:mdna:94]
Selling, general and administrative expenses ("SG&A") totaled $937.3 million or 3.9% of net sales, during fiscal year 2017, compared to $954.9 million, or 3.9% of net sales, during fiscal year 2016, decreasing by $17.6 million or 2%. The decrease in SG&A in dollars is primarily the result of the nonrecurring $61.0 million bad debt reserve charge recognized in the prior year as explained below, offset by further investments in design and engineering resources by us to support our increased Sketch-to-Scaletm initiatives. We also incurred incremental costs associated with our targeted acquisitions and restructuring activities in fiscal year 2017.

[0000866374-17-000005:mdna:95]
SG&A totaled $954.9 million or 3.9% of net sales, during fiscal year 2016, compared to $844.5 million, or 3.2% of net sales, during fiscal year 2015, increasing by $110.4 million or 13%. The increase in SG&A in dollars and as a percentage of net sales is primarily the result of an increase in costs associated with research, development and design activities, as we continued to deploy resources to meet the needs of our customers and explore new product innovations, increases in stock-based compensation expense, incremental costs associated with our acquisitions of MCi and NEXTracker both of which drive a higher proportional SG&A level, and a bad debt reserve charge associated with our outstanding SunEdison receivables of $61.0 million as a result of SunEdison's bankruptcy filing.

[0000866374-17-000005:mdna:96]
Intangible amortization

[0000866374-17-000005:mdna:97]
Amortization of intangible assets in fiscal year 2017 increased by $15.4 million to $81.4 million from $66.0 million in fiscal year 2016, primarily as a result of incremental amortization expense on intangibles assets relating to our acquisitions completed during fiscal year 2017 as well as those completed in the second half of fiscal year 2016.

[0000866374-17-000005:mdna:98]
Amortization of intangible assets in fiscal year 2016 increased by $33.9 million to $66.0 million from $32.0 million in fiscal year 2015, primarily as a result of incremental amortization expense on intangibles assets relating to our acquisitions completed during the fiscal year 2016.

[0000866374-17-000005:mdna:99]
Other charges (income), net

[0000866374-17-000005:mdna:100]
The fiscal year ended March 31, 2017 includes a $7.4 million loss attributable to a non-strategic facility sold during the second quarter of fiscal year 2017. No other components of other charges and income, net incurred during fiscal year 2017 were material.

[0000866374-17-000005:mdna:101]
During fiscal year 2016, we recognized other charges of $47.7 million primarily due to a $26.8 million loss on the disposition of a non-strategic Western European manufacturing facility which included a non cash foreign currency translation loss of $25.3 million, and $21.8 million from the impairment of a non-core investment. These were offset by a non-cash foreign currency translation gain of $4.2 million.

[0000866374-17-000005:mdna:102]
During fiscal year 2015, we recognized other income of $53.2 million principally as a result of the reversal of a contractual obligation with a certain customer recognized during the fiscal year 2014 in the amount of $55.0 million. We executed an amendment to the customer contract during fiscal year 2015 which relieved us of the performance commitment as was defined in an existing customer manufacturing agreement. We also recognized an $11.0 million loss in connection with the disposition of a manufacturing facility in Western Europe. Further, we recognized a net gain for the sale of a certain investment, which primarily comprises the balance for other income in fiscal year 2015 net of the above items.

[0000866374-17-000005:mdna:103]
Interest and other, net

[0000866374-17-000005:mdna:104]
Interest and other, net was $99.5 million during fiscal year 2017 compared to $84.8 million during fiscal year 2016. The increase in interest and other, net of $14.7 million was primarily due to a $10.0 million increase of interest expense from the 4.750% Note due June 15, 2025 and the Term Loan due November 2021, as further discussed in note 7 to the consolidated financial statements, and a $7.9 million decrease in foreign exchange gains, offset by $8.0 million of acquisition-related costs incurred during fiscal year 2016 as described below.

[0000866374-17-000005:mdna:105]
Interest and other, net was $84.8 million during fiscal year 2016 compared to $51.4 million during fiscal year 2015. The increase in interest and other, net of $33.4 million was primarily due to a $23.5 million increase of interest expense from the 4.750% Notes issued during the fiscal year 2016 as further discussed in note 7 to the consolidated financial statements, as well as $8.0 million of acquisition-related costs incurred during fiscal year 2016, primarily for our acquisition of MCi.

[0000866374-17-000005:mdna:106]
Interest and other, net was $51.4 million during fiscal year 2015 compared to $61.9 million during fiscal year 2014. The decrease in interest and other, net was primarily due to a gain associated with minority interest from an investment, an increase in foreign currency gains relating to the Chinese RMB, and a decrease in interest expense as a result of refinancing of certain debt facilities during the latter part of fiscal year 2014.

[0000866374-17-000005:mdna:107]
Income taxes

[0000866374-17-000005:mdna:108]
The Company works to ensure it accrues and pays the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which it operates. Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were 13.8%, 2.3% and 10.4% for the fiscal years 2017, 2016 and 2015, respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0000866374-17-000005:mdna:109]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  | 17.0 | % |
| Effect of tax rate differential | (23.0 | ) |  | (13.7 | ) |  | (11.3 | ) |
| Change in liability for uncertain tax positions | 0.2 |  |  | (3.0 | ) |  | 4.4 |  |
| Change in valuation allowance | 21.2 |  |  | 0.2 |  |  | 0.4 |  |
| Other | (1.6 | ) |  | 1.8 |  |  | (0.1 | ) |
| Provision for income taxes | 13.8 | % |  | 2.3 | % |  | 10.4 | % |

[0000866374-17-000005:mdna:110]
The variation in our effective tax rate each year is primarily a result of recognition of earnings in foreign jurisdictions which are taxed at rates lower than the Singapore statutory rate including the effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia and Israel of $15.5 million, $6.6 million and $9.8 million in fiscal years 2017, 2016 and 2015, respectively.  Additionally, our effective tax rate is impacted by changes in our liabilities for uncertain tax positions of $0.7 million, $(13.7) million, and $29.7 million and changes in our valuation allowances on deferred tax assets of $78.7 million, $1.0 million and $2.5 million in fiscal years 2017, 2016 and 2015, respectively. We generate most of our revenues and profits from operations outside of Singapore.

[0000866374-17-000005:mdna:111]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examinations, there could be a material adverse effect on our tax position, operating results, financial position and cash flows.

[0000866374-17-000005:mdna:112]
We provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized. During fiscal year 2017, we released valuation allowances totaling $39.6 million primarily related to our operations in Austria, China, Ireland and Canada as these amounts were deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those subsidiaries. However, these

[0000866374-17-000005:mdna:113]
valuation allowance eliminations were offset by other current period valuation allowance movements primarily related to current period valuation allowance additions due to increased deferred tax assets related to current period losses in legal entities with existing full valuation allowance positions. In addition, due to increased negative evidence during the fiscal year ended March 31, 2017, the Company added a valuation allowance of $14.4 million for a Chinese subsidiary which did not previously have a valuation allowance recorded.

[0000866374-17-000005:mdna:114]
See note 13, "Income Taxes," to the consolidated financial statements included in Item 8, "Financial Statements and Supplementary Data" for further discussion.

[0000866374-17-000005:mdna:115]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-17-000005:mdna:116]
As of March 31, 2017, we had cash and cash equivalents of $1.8 billion and bank and other borrowings of $3.0 billion. We have a $1.5 billion revolving credit facility, under which we had no borrowings outstanding as of March 31, 2017.

[0000866374-17-000005:mdna:117]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2017, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.2 billion as of March 31, 2017). Repatriation could result in an additional income tax payment; however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-17-000005:mdna:118]
Fiscal Year 2017

[0000866374-17-000005:mdna:119]
Cash provided by operating activities was $1.1 billion during fiscal year 2017. This resulted primarily from $319.6 million of net income for the period plus $673.6 million of non-cash charges such as depreciation, amortization, other impairment charges, provision for doubtful accounts and stock-based compensation expense that are included in the determination of net income. Depreciation expense comprised $432.2 million of those non-cash charges, which was relatively consistent with our normal annual run rate of approximately $425 million. We generated $156.7 million in cash as a result of changes in our operating assets and liabilities, driven primarily by a $268.7 million increase in accounts payable, offset by a $184.0 million increase in accounts receivable. Net working capital ("NWC"), defined as net accounts receivable, including deferred purchase price receivables, plus inventory less accounts payable decreased by $189.5 million primarily due to an increase in accounts payables and reduction in our inventory.

[0000866374-17-000005:mdna:120]
Cash used in investing activities was $0.7 billion during fiscal year 2017. This resulted primarily from $489.5 million of net capital expenditures for property and equipment to expand capability and capacity in support of our automotive and medical businesses and further investments in both automation and expanding technologies to support our innovation services. We also paid $189.1 million for the acquisition of four businesses, net of cash acquired, including $161.7 million, net of $18.0 million of cash acquired related to the acquisition of manufacturing facilities from Bose. Further, $60.0 million was paid for a non-controlling interest in a joint venture with RIB Software AG as our partner. Offsetting this was proceeds from various other investing activities of $63.5 million, most notably the receipt of $36.7 million for the sale of two non-strategic businesses.

[0000866374-17-000005:mdna:121]
Cash used in financing activities was $242.1 million during fiscal year 2017. This was primarily for the repurchase of ordinary shares in the amount $349.5 million, and $31.4 million of cash paid to a third party banking institution for certain assets that were financed by the third party banking institution on behalf of a customer, which is included in other financing activities, as further discussed in note 2 to the consolidated financial statements. These cash outflows were partially offset by $171.0 million of net proceeds from bank borrowings and long-term debt, of which $130.0 million is the incremental amount borrowed extending the maturity date of one of our loan agreements from August 30, 2018 to November 30, 2021, and $107.4 million is the amount of proceeds from the €100 million term loan, discussed further in note 7 to the consolidated financial statements.

[0000866374-17-000005:mdna:122]
Fiscal Year 2016

[0000866374-17-000005:mdna:123]
Cash provided by operating activities was $1.1 billion during fiscal year 2016. This resulted primarily from $444.1 million of net income for the period plus $625.4 million of non-cash charges such as depreciation, amortization, other impairment charges, provision for doubtful accounts and stock-based compensation expense that are included in the determination of net income. Depreciation expense comprised $425.7 million of those non-cash charges, which was relatively consistent with our normal annual run rate of approximately $425.0 million. We generated $66.9 million in cash as a result of

[0000866374-17-000005:mdna:124]
changes in our operating assets and liabilities, driven primarily by a $423.6 million reduction in accounts receivable due to improved collection efforts and lower business levels, offset by a $365.1 million reduction in accounts payable. Net working capital, defined as net accounts receivable, including deferred purchase price receivables, plus inventory less accounts payable decreased by $37.7 million primarily due to lower business levels during the fourth quarter of fiscal year 2016 as compared to the same quarter of fiscal year 2015, which resulted in slightly lower levels of investments in NWC.

[0000866374-17-000005:mdna:125]
Cash used in investing activities was $1.4 billion during fiscal year 2016. This resulted primarily from $916.5 million for the acquisition of eleven businesses completed during fiscal year 2016, including approximately $555.2 million, net of cash acquired, related to the acquisition of MCi, $240.8 million, net of cash acquired, related to the acquisition of NEXTracker, and approximately $67.5 million to acquire an optical transport facility from Alcatel-Lucent. We also paid $510.6 million in gross capital expenditures for property and equipment to support certain programs, offset by $13.7 million of proceeds from the sale of certain buildings and machinery and equipment. Other investing activities also includes $44.7 million paid for the purchase of certain investments, offset by $54.3 million of proceeds from the sale of certain assets that were purchased on behalf of a customer and financed by a third party banking institution, as further discussed in note 17 to the consolidated financial statements.

[0000866374-17-000005:mdna:126]
Cash provided by financing activities was $249.6 million during fiscal year 2016, which was primarily the result of net proceeds from bank borrowings and long-term debt of $694.5 million mainly resulting from our new debt issuance discussed further in note 7 to the consolidated financial statements, and $61.3 million from the issuance of our shares for option exercises. These cash inflows were partially offset by $420.3 million of cash paid for the repurchase of our ordinary shares, and $75.8 million of cash paid to a third party banking institution for certain assets that were financed by the third party banking institution on behalf of a customer, which is included in other financing activities.

[0000866374-17-000005:mdna:127]
Fiscal Year 2015

[0000866374-17-000005:mdna:128]
Cash provided by operating activities was $794.0 million during fiscal year 2015. This resulted primarily from $600.8 million of net income for the period plus $510.9 million of non-cash charges such as depreciation, amortization, other impairment charges and stock-based compensation expense that are included in the determination of net income. Depreciation expense comprised $496.8 million of those non-cash charges, which was higher than our normal annual run rate of approximately $425.0 million due to accelerated depreciation recognized for fixed assets directly associated with certain product exits during the year. These were offset by $317.6 million from changes in our operating assets and liabilities, driven primarily by a $565.1 million reduction in customer deposits that were received in prior periods to support increased working capital requirements in those periods. NWC decreased by $212.5 million primarily due to lower business levels during the fourth quarter of fiscal year 2015 as compared to the same quarter of fiscal year 2014, which resulted in lower levels of investments in NWC.

[0000866374-17-000005:mdna:129]
Cash used in investing activities amounted to $242.2 million during fiscal year 2015. This resulted primarily from $347.4 million in gross capital expenditures for property and equipment to support certain programs, offset by $107.7 million of proceeds from the sale of certain buildings and machinery and equipment. We also paid $52.7 million for the acquisition of four businesses completed during fiscal year 2015. Other investing activities also includes $79.7 million of proceeds from the sale of manufacturing equipment originally purchased on behalf of a customer and financed by a third party banking institution, partially offset by $15.7 million paid for the purchase of certain technology rights.

[0000866374-17-000005:mdna:130]
Cash used in financing activities was $516.0 million during fiscal year 2015, which was primarily the result of cash paid for the repurchase of our ordinary shares in the amount of $415.9 million and net repayment of debt in the amount of $24.6 million. Included in other financing activities is $88.8 million of cash paid to a third party banking institution for certain manufacturing equipment that was financed by the third party banking institution on behalf of a customer and $11.3 million of cash paid for contingent consideration related to our acquisition of Saturn Electronics and Engineering Inc. The aforementioned cash outflows were partially offset by proceeds from the issuance of our shares for option exercises amounting to $23.5 million.

[0000866374-17-000005:mdna:131]
Key Liquidity Metrics

[0000866374-17-000005:mdna:132]
Free Cash flow

[0000866374-17-000005:mdna:133]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repurchase company shares, fund acquisitions, make investments, repay debt obligations, and for certain other activities. Our free cash flow, which is calculated as cash provided by operations less net purchases of property and equipment, was $660.4 million, $639.5 million and $554.3 million for fiscal years 2017, 2016 and 2015, respectively.

[0000866374-17-000005:mdna:134]
Free cash flow is not a measure of liquidity under generally accepted accounting principles in the United States, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or

[0000866374-17-000005:mdna:135]
as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-17-000005:mdna:136]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 1,149,909 |  |  | $ | 1,136,445 |  |  | $ | 794,034 |  |
| Purchases of property and equipment | (525,111 | ) |  | (510,634 | ) |  | (347,413 | ) |
| Proceeds from the disposition of property and equipment | 35,606 |  |  | 13,676 |  |  | 107,689 |  |
| Free cash flow | $ | 660,404 |  |  | $ | 639,487 |  |  | $ | 554,310 |  |

[0000866374-17-000005:mdna:137]
Cash Conversion Cycle

[0000866374-17-000005:mdna:138]
|  | Fiscal Year Ended March 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Days in trade accounts receivable | 43 days |  | 45 days |  | 46 days |
| Days in inventory | 58 days |  | 59 days |  | 58 days |
| Days in accounts payable | 77 days |  | 77 days |  | 77 days |
| Cash conversion cycle | 24 days |  | 27 days |  | 27 days |

[0000866374-17-000005:mdna:139]
Days in trade accounts receivable was calculated as average accounts receivable for the current and prior quarter, adding back the reduction in accounts receivable for the deferred purchase price received in exchange for sales of accounts receivable under our global asset backed securitization programs, divided by annualized sales for the current quarter by day. During the fiscal year ended March 31, 2017, days in trade accounts receivable decreased by 2 days to 43 days compared to the fiscal year ended March 31, 2016 primarily due to better experience in collections. Deferred purchase price receivables included for the purposes of the calculation were $506.5 million, $501.1 million and $600.7 million for the years ended March 31, 2017, 2016 and 2015, respectively, and are recorded in other current assets in the consolidated balance sheets.

[0000866374-17-000005:mdna:140]
Days in inventory was calculated as average inventory for the current and prior quarter divided by annualized cost of sales for the current quarter by day. During the fiscal year ended March 31, 2017, days in inventory decreased by 1 day to 58 days as compared to the fiscal year ended March 31, 2016. The decrease was primarily the result of improved inventory management.

[0000866374-17-000005:mdna:141]
Days in accounts payable was calculated as average accounts payable for the current and prior quarter divided by annualized cost of sales for the current quarter by day. During the fiscal year ended March 31, 2017, days in accounts payable remained consistent at 77 days compared to the fiscal year ended March 31, 2016.

[0000866374-17-000005:mdna:142]
Our cash conversion cycle was calculated as days in trade receivables plus days in inventory, minus days in accounts payable and is a measure of how efficient we are at managing our working capital. Our cash conversion cycle decreased by 3 days for the fiscal year ended March 31, 2017 compared to that of fiscal year 2016 due to the factors affecting each of the components in the calculation discussed above.

[0000866374-17-000005:mdna:143]
Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Cash balances are generated and held in many locations throughout the world. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months.

[0000866374-17-000005:mdna:144]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volumes of customer orders. We are also consciously elevating the levels of spend to support our new business models and investing across all aspects of our platform as we continue our shift to a Sketch-to-Scaletm portfolio.

[0000866374-17-000005:mdna:145]
In April 2017, the Company completed the acquisition of AGM Automotive for approximately $220 million, which expanded its capabilities in the automotive market, and is included within the HRS segment.

[0000866374-17-000005:mdna:146]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. During fiscal years 2017, 2016 and 2015 we received approximately $5.7 billion, $5.2 billion and $4.3 billion, respectively from sales of receivables under our ABS programs, and $1.3 billion, $2.3 billion and $4.2 billion, respectively from other sales of receivables. As of March 31, 2017 and 2016, the outstanding balance on receivables sold for cash was $1.2 billion, for each year, under all our accounts receivable sales programs, which are removed from accounts receivable balances in our consolidated balance sheets.

[0000866374-17-000005:mdna:147]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth.

[0000866374-17-000005:mdna:148]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-17-000005:mdna:149]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In November 2016, we entered into a new arrangement to extend the maturity date of a term loan agreement from August 2018 to November 2021, and borrowed an incremental amount of $130 million under the term loan, thereby increasing the total amount under the term loan to $700 million. In January 2017, we borrowed €100 million (approximately $107.4 million as of March 31, 2017), under a 5-year, term-loan agreement due January 2022. Refer to our Contractual Obligations and Commitments section for further description on these arrangements.

[0000866374-17-000005:mdna:150]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 24, 2016. During fiscal year 2017, we paid $349.5 million to repurchase shares (under the current and prior repurchase plans) at an average price of $13.74 per share. As of March 31, 2017, shares in the aggregate amount of $285.3 million were available to be repurchased under the current plan.

[0000866374-17-000005:mdna:151]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-17-000005:mdna:152]
Bank borrowings and long-term debt are as follows:

[0000866374-17-000005:mdna:153]
|  | As of March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | $ | 502,500 |  |  | $ | 547,500 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 577,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,979 |  |  | 595,589 |  |
| Other credit lines | 169,671 |  |  | 71,317 |  |
| Debt issuance costs | (16,007 | ) |  | (17,351 | ) |
|  | 2,952,143 |  |  | 2,774,555 |  |
| Current portion, net of debt issuance costs | (61,534 | ) |  | (65,166 | ) |
| Non-current portion | $ | 2,890,609 |  |  | $ | 2,709,389 |  |

[0000866374-17-000005:mdna:154]
Refer to the discussion in note 7, "Bank Borrowings and Long-Term Debt" to the consolidated financial statements for further details of our debt obligations.

[0000866374-17-000005:mdna:155]
We have purchase obligations that arise in the normal course of business, primarily consisting of binding purchase orders for inventory related items and capital expenditures. Additionally, we have leased certain of our property and equipment under capital lease commitments, and certain of our facilities and equipment under operating lease commitments.

[0000866374-17-000005:mdna:156]
Future payments due under our purchase obligations, debt including capital leases and related interest obligations and operating lease:

[0000866374-17-000005:mdna:157]
|  | Total |  | Less Than1 Year |  | 1 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In thousands) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase obligations | $ | 2,598,059 |  |  | $ | 2,598,059 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Long-term debt and capital lease obligations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt | 2,968,150 |  |  | 63,887 |  |  | 992,684 |  |  | 811,652 |  |  | 1,099,927 |  |
| Capital lease | 19,135 |  |  | 4,715 |  |  | 10,327 |  |  | 4,093 |  |  | — |  |
| Interest on long-term debt obligations | 700,386 |  |  | 110,196 |  |  | 233,586 |  |  | 238,979 |  |  | 117,625 |  |
| Operating leases, net of subleases | 553,148 |  |  | 117,217 |  |  | 167,437 |  |  | 94,525 |  |  | 173,969 |  |
| Restructuring costs | 23,501 |  |  | 23,501 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 6,862,379 |  |  | $ | 2,917,575 |  |  | $ | 1,404,034 |  |  | $ | 1,149,249 |  |  | $ | 1,391,521 |  |

[0000866374-17-000005:mdna:158]
We have excluded $203.3 million of liabilities for unrecognized tax benefits from the contractual obligations table as we cannot make a reasonably reliable estimate of the periodic settlements with the respective taxing authorities. See note 13, "Income Taxes" to the consolidated financial statements for further details.

[0000866374-17-000005:mdna:159]
Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-17-000005:mdna:160]
OFF-BALANCE SHEET ARRANGEMENTS

[0000866374-17-000005:mdna:161]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of March 31, 2017 and 2016, the fair value of our deferred purchase price receivable was approximately $506.5 million and $501.1 million, respectively. As of March 31, 2017 and 2016, the outstanding balance on receivables sold for cash was $1.2 billion for each period, under all our accounts receivable sales programs, which were removed from accounts receivable balances in our consolidated balance sheets. For further information, see note 10 to the consolidated financial statements.

[0000866374-17-000005:mdna:162]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-17-000005:mdna:163]
Refer to note 2 to the consolidated financial statements for recent accounting pronouncements.
