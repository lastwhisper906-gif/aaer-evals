# FLEX notes — 0000866374-18-000010


## flex:InterestAndOtherNetTextBlock

[0000866374-18-000010:notes:1]
[same as prior period, unchanged from 0000866374-18-000003:notes:1]

[0000866374-18-000010:notes:2]
During the three-month periods ended June 29, 2018 and June 30, 2017, the Company recognized interest expense of $33.5 million and $29.0 million, respectively, on its debt obligations outstanding during the periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-18-000010:notes:3]
BUSINESS AND ASSET DIVESTITURES

[0000866374-18-000010:notes:4]
In March 2018, the Company entered into an agreement with a certain Chinese manufacturing company, to divest its China-based Multek operations, for proceeds of approximately $273 million, net of cash. The planned divestiture does not qualify as discontinued operations, but certain Multek assets and liabilities meet the definition of held for sale as of June 29, 2018 and March 31, 2018. Accordingly, approximately $341.5 million of assets, primarily property and equipment and accounts receivable, were classified as held for sale and included in other current assets, and approximately $131.1 million of liabilities, primarily accounts payables, were classified as held for sale and included in other current liabilities as of June 29, 2018 in the consolidated balance sheet.

[0000866374-18-000010:notes:5]
The sale transaction closed in July 2016, and the Company expects to recognize an immaterial gain or loss on the divestiture, in the second quarter of fiscal year 2019, depending on the net working capital levels.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-18-000010:notes:6]
COMMITMENTS AND CONTINGENCIES

[0000866374-18-000010:notes:7]
Litigation and other legal matters

[0000866374-18-000010:notes:8]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The Company does not believe that the amounts accrued are material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-18-000010:notes:9]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conduct it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-18-000010:notes:10]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable our use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g. base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing a patent license agreement, and requesting information relating to royalties for products that it assembles for a customer in China. If any of these inquiries result in a claim, the Company intends to contest and defend against any such claim vigorously. If a claim is asserted and the Company is unsuccessful in its defense, a material loss is reasonably possible. The Company cannot predict or estimate an amount or reasonable range of outcomes with respect to the matter.

[0000866374-18-000010:notes:11]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. The deadline for applications for appointment as lead plaintiff was July 9, 2018. There are two pending motions for appointment as lead plaintiff, which are scheduled to be heard by the Court on October 11, 2018.  The Court has extended the time for Defendants to respond to the complaint until after a lead plaintiff is appointed and an amended complaint is filed by the lead plaintiff.

[0000866374-18-000010:notes:12]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-18-000010:notes:13]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 346 million Brazilian reals (approximately USD $90 million based on the exchange rate as of June 29, 2018). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-18-000010:notes:14]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-18-000010:notes:15]
[same as prior period, unchanged from 0000866374-18-000003:notes:18]

[0000866374-18-000010:notes:16]
[same as prior period, unchanged from 0000866374-18-000003:notes:19]

[0000866374-18-000010:notes:17]
|  | Three-Month Periods Ended |
|  | June 29, 2018 |  | June 30, 2017 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (35,746 | ) |  | $ | (50,099 | ) |  | $ | (85,845 | ) |  | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |
| Other comprehensive gain (loss) before reclassifications | (41,659 | ) |  | (44,086 | ) |  | (85,745 | ) |  | 3,020 |  |  | 10,836 |  |  | 13,856 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 756 |  |  | — |  |  | 756 |  |  | (5,189 | ) |  | — |  |  | (5,189 | ) |
| Net current-period other comprehensive gain (loss) | (40,903 | ) |  | (44,086 | ) |  | (84,989 | ) |  | (2,169 | ) |  | 10,836 |  |  | 8,667 |  |
| Ending balance | $ | (76,649 | ) |  | $ | (94,185 | ) |  | $ | (170,834 | ) |  | $ | (34,595 | ) |  | $ | (84,881 | ) |  | $ | (119,476 | ) |

[0000866374-18-000010:notes:18]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended June 29, 2018 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:ConsolidationPolicyTextBlock

[0000866374-18-000010:notes:19]
[same as prior period, unchanged from 0000866374-18-000003:notes:23]

[0000866374-18-000010:notes:20]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and enterprise products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

[0000866374-18-000010:notes:21]
[same as prior period, unchanged from 0000866374-18-000003:notes:25]

[0000866374-18-000010:notes:22]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion and apparel, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

[0000866374-18-000010:notes:23]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, electric vehicle infrastructure, smart solar energy, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation, and kiosks; and |

[0000866374-18-000010:notes:24]
| • | High Reliability Solutions ("HRS"), which is comprised of health solutions business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies. |

[0000866374-18-000010:notes:25]
[same as prior period, unchanged from 0000866374-18-000003:notes:29]

[0000866374-18-000010:notes:26]
[same as prior period, unchanged from 0000866374-18-000003:notes:30]

[0000866374-18-000010:notes:27]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2018 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 29, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019.

[0000866374-18-000010:notes:28]
The first quarters for fiscal year 2019 and fiscal year 2018 ended on June 29, 2018, which is comprised of 90 days in the period, and June 30, 2017, which is comprised of 91 days in the period, respectively.

[0000866374-18-000010:notes:29]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

[0000866374-18-000010:notes:30]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000866374-18-000010:notes:31]
The following table summarizes the activity in the Company's contract assets during the three-month period ended June 29, 2018 (in thousands):

[0000866374-18-000010:notes:32]
|  | Contract Assets |
| Beginning balance, April 1, 2018 | $ | — |  |
| Cumulative effect adjustment at April 1, 2018 | 412,787 |  |
| Revenue recognized | 1,560,734 |  |
| Amounts collected or invoiced | (1,649,922 | ) |
| Ending balance, June 29, 2018 | $ | 323,599 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-18-000010:notes:33]
[same as prior period, unchanged from 0000866374-18-000003:notes:47]

[0000866374-18-000010:notes:34]
[same as prior period, unchanged from 0000866374-18-000003:notes:48]

[0000866374-18-000010:notes:35]
The Company enters into short-term foreign currency derivatives contracts, including forward, swap, and options contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-18-000010:notes:36]
As of June 29, 2018, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $8.0 billion as summarized below:

[0000866374-18-000010:notes:37]
|  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |
| CNY | 2,861,000 |  |  | — |  |  | $ | 433,268 |  |  | $ | — |  |
| EUR | 69,596 |  |  | 71,597 |  |  | 81,596 |  |  | 83,601 |  |
| HUF | 26,081,080 |  |  | — |  |  | 92,453 |  |  | — |  |
| ILS | 180,070 |  |  | 10,500 |  |  | 49,447 |  |  | 2,883 |  |
| MXN | 4,842,800 |  |  | — |  |  | 241,956 |  |  | — |  |
| MYR | 396,800 |  |  | 39,000 |  |  | 98,876 |  |  | 9,718 |  |
| RON | 163,150 |  |  | — |  |  | 40,664 |  |  | — |  |
| SGD | 45,950 |  |  | — |  |  | 33,688 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 44,590 |  |  | 7,994 |  |
|  |  |  |  |  |  |  | 1,116,538 |  |  | 104,196 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |
| BRL | — |  |  | 596,000 |  |  | — |  |  | 155,172 |  |
| CAD | 378,908 |  |  | 389,644 |  |  | 285,129 |  |  | 293,208 |  |
| CNY | 2,879,061 |  |  | 1,365,680 |  |  | 438,131 |  |  | 206,927 |  |
| EUR | 1,657,947 |  |  | 1,855,760 |  |  | 1,923,257 |  |  | 2,153,525 |  |
| GBP | 35,446 |  |  | 63,881 |  |  | 46,615 |  |  | 84,113 |  |
| HUF | 29,643,799 |  |  | 31,298,908 |  |  | 105,083 |  |  | 110,950 |  |
| INR | 3,767,477 |  |  | 1,353,258 |  |  | 55,634 |  |  | 19,751 |  |
| MXN | 2,403,304 |  |  | 2,017,270 |  |  | 120,074 |  |  | 100,787 |  |
| MYR | 541,260 |  |  | 287,330 |  |  | 134,873 |  |  | 71,598 |  |
| SGD | 86,283 |  |  | 48,930 |  |  | 63,257 |  |  | 35,872 |  |
| Other | N/A |  |  | N/A |  |  | 182,696 |  |  | 151,951 |  |
|  |  |  |  |  |  |  | 3,354,749 |  |  | 3,383,854 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  | $ | 4,471,287 |  |  | $ | 3,488,050 |  |

[0000866374-18-000010:notes:38]
As of June 29, 2018, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of June 29, 2018, and March 31, 2018, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred losses were $33.3 million as of June 29, 2018, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0000866374-18-000010:notes:39]
[same as prior period, unchanged from 0000866374-18-000003:notes:52]

[0000866374-18-000010:notes:40]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | June 29, 2018 |  | March 31, 2018 |  | Balance SheetLocation |  | June 29, 2018 |  | March 31, 2018 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 3,539 |  |  | $ | 19,422 |  |  | Other current liabilities |  | $ | 37,996 |  |  | $ | 7,065 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 12,110 |  |  | $ | 23,912 |  |  | Other current liabilities |  | $ | 20,252 |  |  | $ | 18,246 |  |

[0000866374-18-000010:notes:41]
[same as prior period, unchanged from 0000866374-18-000003:notes:54]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000866374-18-000010:notes:42]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and overtime - for the three-month period ended June 29, 2018 (in thousands):

[0000866374-18-000010:notes:43]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,300,637 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 4,863,222 |  |
| Over time | 210,245 |  |  | 507,297 |  |  | 382,413 |  |  | 460,779 |  |  | 1,560,734 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,807,934 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 6,423,956 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-18-000010:notes:44]
[same as prior period, unchanged from 0000866374-18-000003:notes:55]

[0000866374-18-000010:notes:45]
The Company's primary plan used for granting equity compensation awards is the 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-18-000010:notes:46]
[same as prior period, unchanged from 0000866374-18-000003:notes:57]

[0000866374-18-000010:notes:47]
|  | Three-Month Periods Ended |
|  | June 29, 2018 |  | June 30, 2017 |
|  | (In thousands) |
| Cost of sales | $ | 5,404 |  |  | $ | 3,319 |  |
| Selling, general and administrative expenses | 15,549 |  |  | 18,477 |  |
| Total share-based compensation expense | $ | 20,953 |  |  | $ | 21,796 |  |

[0000866374-18-000010:notes:48]
Total unrecognized compensation expense related to share options under all plans was $5.7 million, and will be recognized over a weighted-average remaining vesting period of 1.9 years. As of June 29, 2018, the number of options outstanding and exercisable under all plans was 1.1 million and 0.5 million, respectively, at a weighted-average exercise price of $3.38 per share and $4.83 per share, respectively.

[0000866374-18-000010:notes:49]
During the three-month period ended June 29, 2018, the Company granted 5.1 million unvested restricted share unit awards. Of this amount, approximately 3.9 million are plain-vanilla unvested restricted share unit awards with no performance or market conditions with an average grant date price of $14.05 per share and will vest over four years. Further, approximately 1.2 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The expense for these awards contingent on certain market conditions is immaterial for the three-month period ended June 29, 2018 as the awards were granted close to the quarter end. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 2.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met.

[0000866374-18-000010:notes:50]
As of June 29, 2018, approximately 14.9 million unvested restricted share unit awards under all plans were outstanding, of which vesting for a targeted amount of 2.6 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 5.2 million based on the achievement levels of the respective conditions. During the three-month period ended June 29, 2018, 0.6 million shares vested in connection with the restricted share unit awards with market conditions granted in fiscal year 2016.

[0000866374-18-000010:notes:51]
As of June 29, 2018, total unrecognized compensation expense related to unvested restricted share unit awards under all plans was approximately $194.5 million, and will be recognized over a weighted-average remaining vesting period of 2.8 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-18-000010:notes:52]
[same as prior period, unchanged from 0000866374-18-000003:notes:63]

[0000866374-18-000010:notes:53]
[same as prior period, unchanged from 0000866374-18-000003:notes:64]

[0000866374-18-000010:notes:54]
|  | Three-Month Periods Ended |
|  | June 29, 2018 |  | June 30, 2017 |
|  | (In thousands, except per share amounts) |
| Net income | $ | 116,035 |  |  | $ | 124,710 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 529,380 |  |  | 530,268 |  |
| Basic earnings per share | $ | 0.22 |  |  | $ | 0.24 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 116,035 |  |  | $ | 124,710 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 529,380 |  |  | 530,268 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) | 6,074 |  |  | 8,365 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 535,454 |  |  | 538,633 |  |
| Diluted earnings per share | $ | 0.22 |  |  | $ | 0.23 |  |

[0000866374-18-000010:notes:55]
[same as prior period, unchanged from 0000866374-18-000003:notes:66]

[0000866374-18-000010:notes:56]
(1)    An immaterial amount of options to purchase ordinary shares were excluded from the computation of diluted earnings per share during the three-month periods ended June 29, 2018, and  June 30, 2017 due to their anti-dilutive impact on the weighted-average ordinary share equivalents.

[0000866374-18-000010:notes:57]
(2)    Restricted share unit awards of 3.3 million and 0.1 million for the three-month periods ended June 29, 2018 and June 30, 2017, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-18-000010:notes:58]
[same as prior period, unchanged from 0000866374-18-000003:notes:69]

[0000866374-18-000010:notes:59]
[same as prior period, unchanged from 0000866374-18-000003:notes:70]

[0000866374-18-000010:notes:60]
[same as prior period, unchanged from 0000866374-18-000003:notes:71]

[0000866374-18-000010:notes:61]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager. The Company’s deferred compensation plan assets are    for the most part included in other noncurrent assets on the condensed consolidated balance sheets and primarily include investments in equity securities that are valued using active market prices.

[0000866374-18-000010:notes:62]
[same as prior period, unchanged from 0000866374-18-000003:notes:73]

[0000866374-18-000010:notes:63]
[same as prior period, unchanged from 0000866374-18-000003:notes:74]

[0000866374-18-000010:notes:64]
[same as prior period, unchanged from 0000866374-18-000003:notes:75]

[0000866374-18-000010:notes:65]
[same as prior period, unchanged from 0000866374-18-000003:notes:76]

[0000866374-18-000010:notes:66]
[same as prior period, unchanged from 0000866374-18-000003:notes:77]

[0000866374-18-000010:notes:67]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. All contingent considerations have been paid as of March 31, 2018.

[0000866374-18-000010:notes:68]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended June 29, 2018 and June 30, 2017.

[0000866374-18-000010:notes:69]
[same as prior period, unchanged from 0000866374-18-000003:notes:84]

[0000866374-18-000010:notes:70]
[same as prior period, unchanged from 0000866374-18-000003:notes:85]

[0000866374-18-000010:notes:71]
|  | Fair Value Measurements as of June 29, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 464,671 |  |  | $ | — |  |  | $ | 464,671 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 15,649 |  |  | — |  |  | 15,649 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,210 |  |  | 69,038 |  |  | — |  |  | 76,248 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (58,248 | ) |  | $ | — |  |  | $ | (58,248 | ) |
|  | Fair Value Measurements as of March 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 452,622 |  |  | $ | — |  |  | $ | 452,622 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 43,334 |  |  | — |  |  | 43,334 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,196 |  |  | 67,532 |  |  | — |  |  | 74,728 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (25,311 | ) |  | $ | — |  |  | $ | (25,311 | ) |

[0000866374-18-000010:notes:72]
[same as prior period, unchanged from 0000866374-18-000003:notes:87]

[0000866374-18-000010:notes:73]
[same as prior period, unchanged from 0000866374-18-000003:notes:88]

[0000866374-18-000010:notes:74]
|  | As of June 29, 2018 |  | As of March 31, 2018 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 499,950 |  |  | $ | 500,000 |  |  | $ | 513,596 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 683,750 |  |  | 686,314 |  |  | 687,813 |  |  | 689,966 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 477,375 |  |  | 477,375 |  |  | 483,656 |  |  | 485,470 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 499,950 |  |  | 500,000 |  |  | 525,292 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,492 |  |  | 599,940 |  |  | 596,387 |  |  | 627,407 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 55,797 |  |  | 55,797 |  |  | 59,443 |  |  | 59,443 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 115,942 |  |  | 115,942 |  |  | 123,518 |  |  | 123,518 |  |  | Level 1 |
| Total | $ | 2,929,356 |  |  | $ | 2,935,268 |  |  | $ | 2,950,817 |  |  | $ | 3,024,692 |  |  |  |

[0000866374-18-000010:notes:75]
The Company values its Euro Term Loans due September 2020 and January 2022 based on the current market rate, and as of June 29, 2018, the carrying amounts approximate fair values.

[0000866374-18-000010:notes:76]
[same as prior period, unchanged from 0000866374-18-000003:notes:92]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000866374-18-000010:notes:77]
Recently Adopted Accounting Pronouncement

[0000866374-18-000010:notes:78]
In January 2017, the FASB issued Accounting Standard Update (ASU) No. 2017-01 “Business Combinations (Topic 805): Clarifying the Definition of a Business” to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The Company adopted the guidance on a prospective basis during the first quarter of fiscal year 2019, which did not have a material impact to its financial position as there were no acquisitions during the period.

[0000866374-18-000010:notes:79]
In August 2016, the FASB issued ASU 2016-15, "Statement of Cash Flows (Topic 2030): Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force)." The ASU is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 is consistent with our current cash flow classification. However, cash receipts on the deferred purchase price from the Company's asset-backed securitization programs described in note 10 will be classified as cash flows from investing activities instead of the Company's former presentation as cash flows from operations. The Company adopted the guidance during the first quarter of fiscal year 2019 and retrospectively adjusted cash flows from operating and investing activities for three-month period ended June 30, 2017. Upon adoption of the standard, the Company recorded $0.7 billion of cash receipts on the deferred purchase price from the Company's asset-backed securitization programs for the three-month period ended June 29, 2018 and reclassified $0.8 billion of cash receipts on the deferred purchase price for the three-month period ended June 30, 2017, from cash flows from operating activities to cash flows from investing activities and the Company’s condensed consolidated statement of cash flows for the three-months ended June 30, 2017 has been restated to reflect this adjustment.

[0000866374-18-000010:notes:80]
The Company adopted this new guidance using a method which allocates cash flows between operating and investing activities based on monthly receivables sales and collection data.  Commencing with the quarter ending September 28, 2018, the Company will change to a method based on daily activity, and will apply this new method retrospectively.  Management expects this change to result in a decrease in cash flows from operating activities and a corresponding increase in cash flows from investing activities, and that the amount of such change could be material, though no amounts have yet been quantified for any period presented.

[0000866374-18-000010:notes:81]
In January 2016, the FASB issued ASU 2016-01 "Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This guidance generally requires equity investments, except those accounted for under the equity method of accounting or those that result in consolidation of the investee, to be measured at fair value with changes in fair value recognized in net income. This guidance also requires the separate presentation of financial assets and financial liabilities by measurement category and form of financial asset on the balance sheet or in the accompanying notes to the financial statements. The Company adopted this guidance on April 1, 2018 with an insignificant impact on the Company's financial position, results of operations or cash flows.

[0000866374-18-000010:notes:82]
In May 2014, the FASB issued ASU 2014-09 "Revenue from Contracts with Customers (Topic 606)" (also referred to as Accounting Standard Codification 606 ("ASC 606")) which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract.

[0000866374-18-000010:notes:83]
The Company adopted the standard on April 1, 2018 using the modified retrospective approach by applying the guidance to all open contracts at the adoption date and has implemented revised accounting policies, new  operational and financial reporting processes, enhanced systems capabilities and relevant internal controls.

[0000866374-18-000010:notes:84]
As part of adopting ASC 606, revenue for certain customer contracts where the Company is manufacturing products for which there is no alternative use and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory will be recognized over time (i.e. as we manufacture the product) instead of upon shipment of products.  In addition to the following disclosures, note 3 provides further disclosures required by the new standard.

[0000866374-18-000010:notes:85]
The cumulative effect of change made to our April 1, 2018 consolidated balance sheet for the adoption of ASC 606 was as follows:

[0000866374-18-000010:notes:86]
| Condensed Consolidated Balance Sheet |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | Balance at March 31, 2018 | Adjustments | Balance at April 1, 2018 |
| ASSETS |  |  |  |
| Contract assets | — |  | 412,787 |  | 412,787 |  |
| Inventories | 3,799,829 |  | (409,252 | ) | 3,390,577 |  |
| Other current assets | 1,380,466 |  | (51,479 | ) | 1,328,987 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,719,418 |  | (87,897 | ) | 1,631,521 |  |
| Other liabilities | 531,587 |  | 2,098 |  | 533,685 |  |
| Accumulated deficit | (3,144,114 | ) | (37,855 | ) | (3,181,969 | ) |

[0000866374-18-000010:notes:87]
The adoption of ASC 606 resulted in the establishment of contract asset and contract liability balance sheet accounts and in the reclassification to these new accounts from certain asset and liability accounts, primarily inventories. The increase in accumulated deficit in the table above reflects $37.9 million of net adjustments to the balance sheet as of April 1, 2018, resulting from the adoption of ASC 606 primarily related to certain customer contracts requiring an over-time method of revenue recognition. The declines in inventories and other current asset reflect reclassifications to contract assets due to the earlier recognition of certain costs of products sold for over-time contracts. The decline in other current liabilities is primarily due to the reclassification of payments from customers in advance of work performed to contract assets to reflect the net position of the related over-time contracts.

[0000866374-18-000010:notes:88]
The following tables summarize the impacts of ASC 606 adoption on the Company’s condensed consolidated balance sheets and condensed consolidated statements of operations:

[0000866374-18-000010:notes:89]
| Condensed Consolidated Balance Sheet |  |  |  |
| As of June 29, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| ASSETS |  |  |  |
| Contract assets | 323,599 |  | (323,599 | ) | — |  |
| Inventories | 3,984,571 |  | 321,710 |  | 4,306,281 |  |
| Other current assets | 1,231,773 |  | 39,184 |  | 1,270,957 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,665,432 |  | 70,317 |  | 1,735,749 |  |
| Accumulated deficit | (2,989,377 | ) | (33,022 | ) | (3,022,399 | ) |

[0000866374-18-000010:notes:90]
| Condensed Consolidated Statement of Operations |  |  |  |
| Three-months ended June 29, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| Net sales | $ | 6,423,956 |  | $ | 101,974 |  | $ | 6,525,930 |  |
| Cost of sales | 6,046,102 |  | 97,141 |  | 6,143,243 |  |
| Gross profit | 377,854 |  | 4,833 |  | 382,687 |  |
| Net income | $ | 116,035 |  | $ | 4,833 |  | $ | 120,868 |  |

[0000866374-18-000010:notes:91]
The as reported revenue and gross profit for the period ended June 29, 2018 were approximately $102.0 million, and $4.8 million less than they would have been without ASC 606 adoption primarily due to certain contract amendments for a portion of the Company's customers executed in the quarter. To align contractual terms across the vast majority of customers to allow the Company to efficiently and accurately manage its contracts, the Company waived certain contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. These modifications will result in revenue from these customers being recognized upon shipment of products, rather than over time (i.e. as we manufacture products) as further explained in note 3. The result of the amendments was to reduce revenue and gross profit by approximately $132.7 million and $9.3 million, respectively, compared to amounts that would have been reported both (i) under ASC 606 had we not amended the contracts, and (ii) had we not adopted ASC 606.  Offsetting the impact of the one-time contract amendments noted above was approximately $30.7 million of additional revenue and $4.5 million of gross profit recognized in the "as reported" amounts due to the accelerated timing of recognition of revenue for contracts which meet the criteria for over-time recognition (see note 3). There was no material tax impact for the three months period ended June 29, 2018 from adopting ASC 606.

[0000866374-18-000010:notes:92]
The Company applies the following practical expedients:

[0000866374-18-000010:notes:93]
| • | The Company elected to not disclose information about remaining performance obligations as its performance obligations generally have an expected durations of one year or less. |

[0000866374-18-000010:notes:94]
| • | In accordance with ASC 606-10-25-18B the Company will account for certain shipping and handling as activities to fulfill the promise to transfer the good, instead of a promised service to its customer. |

[0000866374-18-000010:notes:95]
| • | In accordance with ASC 606-10-32-18 the Company elected to not adjust the promised amount of consideration for the effects of a significant financing component as the Company expects, at contract inception, that the period between when the entity transfers a promised good or service to a customer and when the customer pays for that good or service will generally be one year or less. |

[0000866374-18-000010:notes:96]
Recently Issued Accounting Pronouncements

[0000866374-18-000010:notes:97]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-18-000010:notes:98]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-18-000010:notes:99]
In February 2018, the FASB issued ASU 2018-03 "Technical Corrections and Improvements to Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This standard comes as an addition to ASU 2016-01which the Company adopted in the first quarter of fiscal year 2019.  This update includes amendments to clarify certain aspects of the guidance issued in Update 2016-01. The Company will adopt the guidance during the second quarter of fiscal year 2019, and expects it will have an immaterial impact on its consolidated financial statements.

[0000866374-18-000010:notes:100]
In January 2017, the FASB issued ASU 2017-04 "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment" to simplify the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. This guidance requires that the change be applied on a prospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2021, with early application permitted. The Company is currently assessing the impact of the new guidance and the timing of adoption.

[0000866374-18-000010:notes:101]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach. The Company believes the new guidance will have a material impact on its consolidated balance sheets upon adoption.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-18-000010:notes:102]
[same as prior period, unchanged from 0000866374-18-000003:notes:107]


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-18-000010:notes:103]
OTHER INCOME, NET

[0000866374-18-000010:notes:104]
During the three-month period ended June 29, 2018, the Company recognized other income of $86.9 million, primarily driven by a $91.8 million gain on the deconsolidation of AutoLab. Refer to note 2 for further details of the deconsolidation.

[0000866374-18-000010:notes:105]
During the three-month period ended June 30, 2017, the Company sold Wink to an unrelated third-party venture backed company in exchange for contingent consideration. The Company recognized a non-cash gain on sale of $38.7 million, which was recorded in other income, net on the condensed consolidated statement of operations during the period.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-18-000010:notes:106]
REVENUE

[0000866374-18-000010:notes:107]
Revenue Recognition

[0000866374-18-000010:notes:108]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that create enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc, and the level of business under those agreements may not be guaranteed. In those instances, we bid on a program-by-program basis and typically receive customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

[0000866374-18-000010:notes:109]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-18-000010:notes:110]
Customer Contracts and Related Obligations

[0000866374-18-000010:notes:111]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refund required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer related accruals in note 2.

[0000866374-18-000010:notes:112]
Performance Obligations

[0000866374-18-000010:notes:113]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

[0000866374-18-000010:notes:114]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises).  The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g.: procurement of materials and standard workmanship warranty).

[0000866374-18-000010:notes:115]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of our contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that Flex would sell similar goods or services separately.

[0000866374-18-000010:notes:116]
Contract Balances

[0000866374-18-000010:notes:117]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheet and transferred to receivables when rights to payment become unconditional. The following table summarizes the activity in the Company's contract assets during the three-month period ended June 29, 2018 (in thousands):

[0000866374-18-000010:notes:118]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and are included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $270.6 million and $265.3 million as of June 29, 2018 and April 1, 2018, respectively.

[0000866374-18-000010:notes:119]
Disaggregation of Revenue


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000866374-18-000010:notes:120]
[same as prior period, unchanged from 0000866374-18-000003:notes:108]

[0000866374-18-000010:notes:121]
|  | As of June 29, 2018 |  | As of March 31, 2018 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 303,790 |  |  | $ | (88,667 | ) |  | $ | 215,123 |  |  | $ | 306,943 |  |  | $ | (79,051 | ) |  | $ | 227,892 |  |
| Licenses and other intangibles | 286,177 |  |  | (110,473 | ) |  | 175,704 |  |  | 304,007 |  |  | (107,466 | ) |  | 196,541 |  |
| Total | $ | 589,967 |  |  | $ | (199,140 | ) |  | $ | 390,827 |  |  | $ | 610,950 |  |  | $ | (186,517 | ) |  | $ | 424,433 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000866374-18-000010:notes:122]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the three-month period ended June 29, 2018:

[0000866374-18-000010:notes:123]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year | $ | 550,983 |  |  | $ | 107,748 |  |  | $ | 337,707 |  |  | $ | 124,732 |  |  | $ | 1,121,170 |  |
| Foreign currency translation adjustments (1) | (26,394 | ) |  | — |  |  | — |  |  | — |  |  | (26,394 | ) |
| Balance, end of the period | $ | 524,589 |  |  | $ | 107,748 |  |  | $ | 337,707 |  |  | $ | 124,732 |  |  | $ | 1,094,776 |  |

[0000866374-18-000010:notes:124]
| (1) | During the three-month period ended June 29, 2018, the Company recorded $26.4 million of foreign currency translation adjustments primarily related to the goodwill associated with the acquisition of Mirror Controls International ("MCi") and AGM Automotive ("AGM"), as the U.S. Dollar fluctuated against foreign currencies. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000866374-18-000010:notes:125]
[same as prior period, unchanged from 0000866374-18-000003:notes:115]

[0000866374-18-000010:notes:126]
|  | As of June 29, 2018 |  | As of March 31, 2018 |
|  | (In thousands) |
| Raw materials | $ | 3,096,814 |  |  | $ | 2,760,410 |  |
| Work-in-progress | 403,625 |  |  | 450,569 |  |
| Finished goods | 484,132 |  |  | 588,850 |  |
|  | $ | 3,984,571 |  |  | $ | 3,799,829 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-18-000010:notes:127]
Selected financial information by segment is in the table below. For the three-month period ended June 29, 2018, we recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings, as further described in note 1 to the condensed consolidated financial statements. The comparative information for the three-month period ended June 30, 2017 has not been restated and continues to be reported under the accounting standards in effect at the time:

[0000866374-18-000010:notes:128]
|  | Three-Month Periods Ended |
|  | June 29, 2018 |  | June 30, 2017 |
|  | (In thousands) |
| Net sales: |  |  |  |
| Communications & Enterprise Compute | $ | 1,954,286 |  |  | $ | 1,973,333 |  |
| Consumer Technologies Group | 1,807,934 |  |  | 1,511,969 |  |
| Industrial & Emerging Industries | 1,446,311 |  |  | 1,390,599 |  |
| High Reliability Solutions | 1,215,425 |  |  | 1,132,371 |  |
|  | $ | 6,423,956 |  |  | $ | 6,008,272 |  |
| Segment income and reconciliation of income before tax: |  |  |  |
| Communications & Enterprise Compute | $ | 46,017 |  |  | $ | 48,603 |  |
| Consumer Technologies Group | 26,557 |  |  | 18,004 |  |
| Industrial & Emerging Industries | 51,361 |  |  | 55,376 |  |
| High Reliability Solutions | 93,534 |  |  | 90,212 |  |
| Corporate and Other | (29,761 | ) |  | (34,278 | ) |
| Total segment income | 187,708 |  |  | 177,917 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 18,517 |  |  | 19,901 |  |
| Stock-based compensation | 20,953 |  |  | 21,796 |  |
| Distressed customers asset impairments (1) | 17,364 |  |  | — |  |
| Restructuring charges | 8,817 |  |  | — |  |
| New revenue standard adoption impact (Note 1 & Note 3) | 9,291 |  |  | — |  |
| Legal and other (2) | 16,311 |  |  | — |  |
| Other income, net (Note 7) | (86,924 | ) |  | (36,165 | ) |
| Interest and other, net | 41,742 |  |  | 26,876 |  |
| Income before income taxes | $ | 141,637 |  |  | $ | 145,509 |  |

[0000866374-18-000010:notes:129]
| 1. | Distressed customers asset impairments for the three-month period ended June 29, 2018 relate to additional provision for doubtful accounts receivable, inventory and other assets for certain customers experiencing significant financial difficulties. |

[0000866374-18-000010:notes:130]
| 2. | Legal and other during the three-month period ended June 29, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018 and certain charges of the China based Multek operation that was divested in the second quarter of fiscal year 2019. |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0000866374-18-000010:notes:131]
[same as prior period, unchanged from 0000866374-18-000003:notes:123]

[0000866374-18-000010:notes:132]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2019 (1) | $ | 54,200 |  |
| 2020 | 66,514 |  |
| 2021 | 62,135 |  |
| 2022 | 53,323 |  |
| 2023 | 45,089 |  |
| Thereafter | 109,566 |  |
| Total amortization expense | $ | 390,827 |  |

[0000866374-18-000010:notes:133]
| (1) | Represents estimated amortization for the remaining nine-month period ending March 31, 2019. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-18-000010:notes:134]
[same as prior period, unchanged from 0000866374-18-000003:notes:126]

[0000866374-18-000010:notes:135]
[same as prior period, unchanged from 0000866374-18-000003:notes:127]

[0000866374-18-000010:notes:136]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, distressed customer charges, legal and other, the new revenue standard adoption impact, restructuring charges, other income, net and interest and other, net.

[0000866374-18-000010:notes:137]
[same as prior period, unchanged from 0000866374-18-000003:notes:129]

[0000866374-18-000010:notes:138]
[same as prior period, unchanged from 0000866374-18-000003:notes:130]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-18-000010:notes:139]
[same as prior period, unchanged from 0000866374-18-000003:notes:131]

[0000866374-18-000010:notes:140]
[same as prior period, unchanged from 0000866374-18-000003:notes:132]

[0000866374-18-000010:notes:141]
Due to the adoption of ASC 606, amounts that would have been reported as inventory under prior guidance are now included in contract assets or liabilities, depending on the net position of the contract, as disclosed in note 1.  As a result of this accounting change, inventories as of June 29, 2018 are $321.7 million less than they would have been, had we not adopted ASC 606. The comparative information as of March 31, 2018, has not been restated and continues to be reported under the accounting standards in effect at that time.

[0000866374-18-000010:notes:142]
[same as prior period, unchanged from 0000866374-18-000003:notes:133]

[0000866374-18-000010:notes:143]
The gross carrying amounts of intangible assets are removed when fully amortized. The estimated future annual amortization expense for intangible assets is as follows:

[0000866374-18-000010:notes:144]
[same as prior period, unchanged from 0000866374-18-000003:notes:135]

[0000866374-18-000010:notes:145]
Other current assets include approximately $287.7 million and $445.4 million as of June 29, 2018 and March 31, 2018, respectively, for the deferred purchase price receivable from the Company's Asset-Backed Securitization programs. See note 10 for additional information. Further, the Company recorded approximately $341.5 million and $321.1 million, as of June 29, 2018 and March 31, 2018, respectively, of asset held for sale primarily consisting of property and equipment and accounts receivable, in other current assets. See note 12 for additional information.

[0000866374-18-000010:notes:146]
[same as prior period, unchanged from 0000866374-18-000003:notes:137]

[0000866374-18-000010:notes:147]
The Company has certain equity investments in, and notes receivable from, non-publicly traded companies which are included within other assets. The equity method of accounting is used for investments in common stock or in-substance common stock when the Company has the ability to significantly influence the operating decisions of the investee; otherwise the cost method is used. Non-majority-owned investments in entities are accounted for using the equity method when the Company has a voting percentage equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, primarily comparable company multiples and discounted cash flow projections. For investments accounted for under cost method that do not have readily determinable fair values, the Company has elected, per ASU 2016-01, to measure them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-18-000010:notes:148]
AutoLab AI

[0000866374-18-000010:notes:149]
During the first quarter of fiscal year 2019, the Company transferred existing employees and equipment with a net book value of approximately $40 million along with certain related software and Intellectual Property ("IP"), into the newly created AutoLab AI (“AutoLab”), in exchange for shares of preferred stock and a controlling financial interest in AutoLab. AutoLab is a privately held software-as-a service (SaaS) and hardware company focused on developing and deploying an automation solution worldwide. The Company has concluded that AutoLab does not qualify as a variable interest entity for purposes of evaluating whether it has a controlling financial interest.

[0000866374-18-000010:notes:150]
Subsequent to the initial formation and prior to June 29, 2018, AutoLab received equity funding from third party investors and expanded the board of directors, resulting in dilution of the Company's voting interest below 50%. As a result, the Company concluded it no longer holds a controlling financial interest in AutoLab and accordingly, deconsolidated the entity.

[0000866374-18-000010:notes:151]
The fair value of the Company’s non-controlling interest in AutoLab upon deconsolidation was approximately $132.1 million as of the date of deconsolidation. The Company accounts for its investment in AutoLab under the equity method, with the carrying amount included in other assets on the condensed consolidated balance sheet. The value of the Company’s interest on the date of deconsolidation was based on management’s estimate of the fair value of AutoLab at that time. Management relied on a multi-stage process which involved calculating the enterprise and equity value of AutoLab, then allocating the equity value of the entity to the Company’s securities. The enterprise value of AutoLab was estimated based on the value implied by the equity funding AutoLab received from third parties in the same period (i.e.: level 2 inputs). The Company recognized a gain on deconsolidation of approximately $91.8 million with no material tax impact, which is included in other income, net on the condensed consolidated statement of operations.

[0000866374-18-000010:notes:152]
In addition, during the first quarter of fiscal year 2019, the Company leased approximately $76.5 million of fixed assets to AutoLab under a five-year lease term based on an interest rate of 0.35% per month. The leases were concluded to be sales-type leases and as such, the Company derecognized the associated assets from property and equipment, net and recorded a total net investment in the lease of $88.2 million in other current assets and non-current assets, based on the present value of lease receivables. The Company recorded an immaterial gain related to this leasing transaction, which is included in cost of sales on the condensed consolidated statement of operations.

[0000866374-18-000010:notes:153]
Pro-forma financials have not been presented because the effects were not material to the Company’s condensed consolidated financial position and results of operation for all periods presented. AutoLab became a related party to the Company starting on the date of deconsolidation. The Company has engaged AutoLab as a strategic partner to develop and deploy automation solution for Flex and has entered into a 5-year subscription agreement. Subscription fees under the AutoLab agreement were immaterial for the three-month period ended June 29, 2018.

[0000866374-18-000010:notes:154]
As of June 29, 2018 and March 31, 2018, the Company's investments in non-majority owned companies totaled $554.3 million and $411.1 million, respectively. The equity in the earnings or losses of the Company's equity method investments, including AutoLab, was not material to the consolidated results of operations for any period presented and is included in interest and other, net.

[0000866374-18-000010:notes:155]
[same as prior period, unchanged from 0000866374-18-000003:notes:140]

[0000866374-18-000010:notes:156]
Other current liabilities include customer working capital advances of $174.0 million and $153.6 million, customer-related accruals of $414.6 million and $439.0 million, and deferred revenue of $270.6 million and $329.0 million as of June 29, 2018 and March 31, 2018, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-18-000010:notes:157]
[same as prior period, unchanged from 0000866374-18-000003:notes:142]

[0000866374-18-000010:notes:158]
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-18-000010:notes:159]
[same as prior period, unchanged from 0000866374-18-000003:notes:144]

[0000866374-18-000010:notes:160]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of June 29, 2018 and March 31, 2018, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-18-000010:notes:161]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $950.0 million for the Global Program, of which $775.0 million is committed and $175.0 million is uncommitted, and $250.0 million for the North American Program, of which $210.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0000866374-18-000010:notes:162]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month periods ended June 29, 2018, and June 30, 2017 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0000866374-18-000010:notes:163]
The Company's deferred purchase price receivables relating to its asset-backed securitization program are recorded initially at fair value based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk-free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short-term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not material. The interrelationship between these inputs is also insignificant.

[0000866374-18-000010:notes:164]
As of June 29, 2018 and March 31, 2018, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company during the three-month periods ended June 29, 2018 and June 30, 2017 were included as cash provided by operating activities in the condensed consolidated statements of cash flows. We recognize these proceeds net of the deferred purchase price, consisting of a receivable from the purchasers that entitles us to certain collections on the receivable. We recognize the collection of the deferred purchase price in net cash provided by investing activities in the condensed consolidated statements of cash flows as cash collections of deferred purchase price.

[0000866374-18-000010:notes:165]
As of June 29, 2018, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $0.9 billion and deferred purchase price receivables of $287.7 million. As of March 31, 2018, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $1.1 billion and deferred purchase price receivables of $445.4 million. The deferred purchase price balances as of June 29, 2018 and March 31, 2018, also represent the non-cash beneficial interest obtained in exchange for securitized receivables.

[0000866374-18-000010:notes:166]
For the three-month periods ended June 29, 2018 and June 30, 2017, cash flows from sales of receivables under the ABS Programs consisted of approximately $2.1 billion and $2.4 billion, respectively, for transfers of receivables, and approximately $0.7 billion and $0.8 billion, respectively, for collection on deferred purchase price receivables. The Company's cash flows from transfer of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-18-000010:notes:167]
Trade Accounts Receivable Sale Program

[0000866374-18-000010:notes:168]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $469.8 million and $286.4 million as of June 29, 2018 and March 31, 2018, respectively. For the three-month periods ended June 29, 2018 and June 30, 2017, total accounts receivable sold to certain third-party banking institutions was approximately $610.1 million and $229.5 million, respectively, primarily due to certain customers transferring from the ABS Programs to the Trade Account Receivable Sale Program. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-18-000010:notes:169]
[same as prior period, unchanged from 0000866374-18-000003:notes:153]

[0000866374-18-000010:notes:170]
During the three-month period ended June 29, 2018, the Company made no repurchases of shares.

[0000866374-18-000010:notes:171]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 15, 2017. As of June 29, 2018, shares in the aggregate amount of $410.1 million were available to be repurchased under the current plan.
