# FLEX MD&A — 0000866374-18-000010


## mdna

[0000866374-18-000010:mdna:1]
[same as prior period, unchanged from 0000866374-18-000003:mdna:1]

[0000866374-18-000010:mdna:2]
[same as prior period, unchanged from 0000866374-18-000003:mdna:2]

[0000866374-18-000010:mdna:3]
[same as prior period, unchanged from 0000866374-18-000003:mdna:3]

[0000866374-18-000010:mdna:4]
We are a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer and enterprise products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through our activities in the following segments:

[0000866374-18-000010:mdna:5]
[same as prior period, unchanged from 0000866374-18-000003:mdna:5]

[0000866374-18-000010:mdna:6]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion and apparel, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

[0000866374-18-000010:mdna:7]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, electric vehicle infrastructure, smart solar energy, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation, and kiosks; and |

[0000866374-18-000010:mdna:8]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; our automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies. |

[0000866374-18-000010:mdna:9]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables

[0000866374-18-000010:mdna:10]
[same as prior period, unchanged from 0000866374-18-000003:mdna:34]

[0000866374-18-000010:mdna:11]
our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-18-000010:mdna:12]
[same as prior period, unchanged from 0000866374-18-000003:mdna:10]

[0000866374-18-000010:mdna:13]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customer's supply chain solutions needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-18-000010:mdna:14]
During the past several years, we have evolved our long-term portfolio towards a mix of businesses which possess longer product life cycles and higher segment operating margins such as reflected in our IEI and HRS businesses. Since the beginning of fiscal year 2016, we have launched several programs broadly across our portfolio of services and in some instances, we have deployed certain new technologies. We continue to invest in innovation and we have expanded our design and engineering relationships through our product innovation centers.

[0000866374-18-000010:mdna:15]
[same as prior period, unchanged from 0000866374-18-000003:mdna:13]

[0000866374-18-000010:mdna:16]
We are one of the world's largest providers of global supply chain solutions, with revenues of $6.4 billion for the three-month period ended June 29, 2018 and $25.4 billion in fiscal year 2018. On April 1, 2018, the Company adopted the new revenue standard and as a result we recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings, as further described in note 1 to the condensed consolidated financial statements. The comparative information has not been restated and continues to be reported under the accounting standards in effect at the time. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-18-000010:mdna:17]
|  | Three-Month Periods Ended |
| Net sales: | June 29, 2018 |  | June 30, 2017 |
|  | (In millions) |
| China | $ | 1,669 |  |  | 26 | % |  | $ | 1,745 |  |  | 29 | % |
| Mexico | 1,123 |  |  | 17 | % |  | 1,040 |  |  | 17 | % |
| U.S. | 635 |  |  | 10 | % |  | 694 |  |  | 12 | % |
| Brazil | 587 |  |  | 9 | % |  | 598 |  |  | 10 | % |
| Malaysia | 477 |  |  | 7 | % |  | 505 |  |  | 8 | % |
| India | 468 |  |  | 7 | % |  | 110 |  |  | 2 | % |
| Other | 1,467 |  |  | 24 | % |  | 1,316 |  |  | 22 | % |
|  | $ | 6,424 |  |  |  |  |  | $ | 6,008 |  |  |  |  |

[0000866374-18-000010:mdna:18]
[same as prior period, unchanged from 0000866374-18-000003:mdna:43]

[0000866374-18-000010:mdna:19]
|  | As of |  | As of |
| Property and equipment, net: | June 29, 2018 |  | March 31, 2018 |
|  | (In millions) |
| Mexico | $ | 547 |  |  | 25 | % |  | $ | 587 |  |  | 26 | % |
| China | 475 |  |  | 22 | % |  | 492 |  |  | 22 | % |
| U.S. | 308 |  |  | 14 | % |  | 305 |  |  | 14 | % |
| Malaysia | 150 |  |  | 7 | % |  | 153 |  |  | 7 | % |
| Hungary | 133 |  |  | 6 | % |  | 150 |  |  | 7 | % |
| India | 120 |  |  | 5 | % |  | 78 |  |  | 3 | % |
| Other | 456 |  |  | 21 | % |  | 475 |  |  | 21 | % |
|  | $ | 2,190 |  |  |  |  |  | $ | 2,240 |  |  |  |  |

[0000866374-18-000010:mdna:20]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-18-000010:mdna:21]
[same as prior period, unchanged from 0000866374-18-000003:mdna:19]

[0000866374-18-000010:mdna:22]
[same as prior period, unchanged from 0000866374-18-000003:mdna:20]

[0000866374-18-000010:mdna:23]
| • | the mix of the manufacturing services we are providing, the number and size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors; |

[0000866374-18-000010:mdna:24]
[same as prior period, unchanged from 0000866374-18-000003:mdna:22]

[0000866374-18-000010:mdna:25]
[same as prior period, unchanged from 0000866374-18-000003:mdna:23]

[0000866374-18-000010:mdna:26]
[same as prior period, unchanged from 0000866374-18-000003:mdna:24]

[0000866374-18-000010:mdna:27]
[same as prior period, unchanged from 0000866374-18-000003:mdna:25]

[0000866374-18-000010:mdna:28]
[same as prior period, unchanged from 0000866374-18-000003:mdna:26]

[0000866374-18-000010:mdna:29]
[same as prior period, unchanged from 0000866374-18-000003:mdna:27]

[0000866374-18-000010:mdna:30]
[same as prior period, unchanged from 0000866374-18-000003:mdna:28]

[0000866374-18-000010:mdna:31]
[same as prior period, unchanged from 0000866374-18-000003:mdna:29]

[0000866374-18-000010:mdna:32]
[same as prior period, unchanged from 0000866374-18-000003:mdna:30]

[0000866374-18-000010:mdna:33]
[same as prior period, unchanged from 0000866374-18-000003:mdna:31]

[0000866374-18-000010:mdna:34]
[same as prior period, unchanged from 0000866374-18-000003:mdna:32]

[0000866374-18-000010:mdna:35]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) requires management to make estimates and assumptions that affect the reported amounts

[0000866374-18-000010:mdna:36]
[same as prior period, unchanged from 0000866374-18-000003:mdna:53]

[0000866374-18-000010:mdna:37]
of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results may differ from those estimates and assumptions.

[0000866374-18-000010:mdna:38]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2018, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There were no changes to our accounting policies other than the adoption of ASC 606 as follows.

[0000866374-18-000010:mdna:39]
Revenue Recognition

[0000866374-18-000010:mdna:40]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to notes 1 and 3 to the condensed consolidated financial statements for further details.

[0000866374-18-000010:mdna:41]
[same as prior period, unchanged from 0000866374-18-000003:mdna:36]

[0000866374-18-000010:mdna:42]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our 2018 Annual Report on Form 10-K.

[0000866374-18-000010:mdna:43]
|  | Three-Month Periods Ended |
|  | June 29, 2018 |  | June 30, 2017 |
| Net sales | 100.0 | % |  | 100.0 | % |
| Cost of sales | 94.1 |  |  | 93.2 |  |
| Gross profit | 5.9 |  |  | 6.8 |  |
| Selling, general and administrative expenses | 4.1 |  |  | 4.2 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |
| Interest and other, net | 0.6 |  |  | 0.4 |  |
| Other income, net | (1.4 | ) |  | (0.6 | ) |
| Income before income taxes | 2.3 |  |  | 2.5 |  |
| Provision for income taxes | 0.4 |  |  | 0.3 |  |
| Net income | 1.9 | % |  | 2.2 | % |

[0000866374-18-000010:mdna:44]
[same as prior period, unchanged from 0000866374-18-000003:mdna:39]

[0000866374-18-000010:mdna:45]
[same as prior period, unchanged from 0000866374-18-000003:mdna:40]

[0000866374-18-000010:mdna:46]
|  | Three-Month Periods Ended |
| Segments: | June 29, 2018 |  | June 30, 2017 |
|  | (In millions) |
| Communications & Enterprise Compute | $ | 1,954 |  |  | 30 | % |  | $ | 1,973 |  |  | 33 | % |
| Consumer Technologies Group | 1,808 |  |  | 28 | % |  | 1,512 |  |  | 25 | % |
| Industrial & Emerging Industries | 1,446 |  |  | 23 | % |  | 1,391 |  |  | 23 | % |
| High Reliability Solutions | 1,215 |  |  | 19 | % |  | 1,132 |  |  | 19 | % |
|  | $ | 6,423 |  |  |  |  |  | $ | 6,008 |  |  |  |  |

[0000866374-18-000010:mdna:47]
Net sales during the three-month period ended June 29, 2018 totaled $6.4 billion, representing an increase of approximately $0.4 billion, or 7% from $6.0 billion during the three-month period ended June 30, 2017. The overall increase in sales was driven by increases in three of our segments offset by a slight decline in sales in our CEC segment. Our CTG segment increased $296 million, primarily because of stronger sales in consumer products from high growth emerging markets such as India, offset by a decrease in our connected living business. Our HRS segment increased $83 million from higher sales in our automotive and medical businesses. Our IEI segment increased $56 million, mainly driven by our industrial, home and lifestyle business, offset by decreases in our solar energy and capital equipment businesses. Sales in our CEC segment remained flat only declining $19 million or approximately 1%, primarily due to lower sales within our traditional telecom and networking businesses offset by increased sales in our cloud and data center business. Net sales increased across all our regions with increases of $251 million to $2.9 billion in Asia, $158 million to $1.2 billion in Europe, and $7 million to $2.4 billion in the Americas.

[0000866374-18-000010:mdna:48]
Our ten largest customers, during the three-month periods ended June 29, 2018 and June 30, 2017, accounted for approximately 44% and 43% of net sales, respectively. No customer accounted for more than 10% of net sales during the three-month periods ended June 29, 2018 and June 30, 2017

[0000866374-18-000010:mdna:49]
[same as prior period, unchanged from 0000866374-18-000003:mdna:48]

[0000866374-18-000010:mdna:50]
[same as prior period, unchanged from 0000866374-18-000003:mdna:49]

[0000866374-18-000010:mdna:51]
Gross profit during the three-month period ended June 29, 2018 decreased $29 million to $378 million, or 5.9% of net sales, from $407 million, or 6.8% of net sales, during the three-month period ended June 30, 2017. Gross margin declined 90 basis points during the same period. These declines in both gross profit and gross margin are primarily due to higher levels of start-up costs, operational inefficiencies and under-absorbed overhead costs for new ramps during the period along with a greater portion of lower margin consumer products in the mix of business for the current quarter.

[0000866374-18-000010:mdna:52]
[same as prior period, unchanged from 0000866374-18-000003:mdna:51]

[0000866374-18-000010:mdna:53]
An operating segment’s performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, distressed customer charges, legal and other, the new revenue standard adoption impact, restructuring charges, other income, net and interest and other, net. A portion of depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-18-000010:mdna:54]
[same as prior period, unchanged from 0000866374-18-000003:mdna:54]

[0000866374-18-000010:mdna:55]
|  | Three-Month Periods Ended |
|  | June 29, 2018 |  | June 30, 2017 |
|  | (In millions) |
| Segment income & margin: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 46 |  |  | 2.4 | % |  | $ | 49 |  |  | 2.5 | % |
| Consumer Technologies Group | 27 |  |  | 1.5 | % |  | 18 |  |  | 1.2 | % |
| Industrial & Emerging Industries | 51 |  |  | 3.6 | % |  | 55 |  |  | 4.0 | % |
| High Reliability Solutions | 94 |  |  | 7.7 | % |  | 90 |  |  | 8.0 | % |
| Corporate and Other | (30 | ) |  |  |  | (34 | ) |  |  |
| Total segment income | 188 |  |  | 2.9 | % |  | 178 |  |  | 3.0 | % |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 19 |  |  |  |  | 20 |  |  |  |
| Stock-based compensation | 21 |  |  |  |  | 22 |  |  |  |
| Distressed customers asset impairments (1) | 17 |  |  |  |  | — |  |  |  |
| Restructuring charges | 9 |  |  |  |  | — |  |  |  |
| New revenue standard adoption impact (Note 1 & Note 3) | 9 |  |  |  |  | — |  |  |  |
| Legal and other (2) | 16 |  |  |  |  | — |  |  |  |
| Other income, net (Note 7) | (87 | ) |  |  |  | (36 | ) |  |  |
| Interest and other, net | 42 |  |  |  |  | 27 |  |  |  |
| Income before income taxes | $ | 142 |  |  |  |  | $ | 146 |  |  |  |

[0000866374-18-000010:mdna:56]
| 1. | Distressed customers asset impairments for the three-month period ended June 29, 2018 relate to additional provision for doubtful accounts receivable, inventory and other assets for certain customers experiencing significant financial difficulties. |

[0000866374-18-000010:mdna:57]
| 2. | Legal and other during the three-month period ended June 29, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018 and certain charges of the China based Multek operation that was divested in the second quarter of fiscal year 2019. |

[0000866374-18-000010:mdna:58]
CEC segment margin decreased 10 basis points, to 2.4% for the three-month period ended June 29, 2018, from 2.5% during the three-month period ended June 30, 2017. The decrease in CEC's margin during the period is due to lower capacity utilization causing reduced overhead absorption, coupled with modest increased investments to expand its cloud data center engineering capabilities.

[0000866374-18-000010:mdna:59]
CTG segment margin increased 30 basis points to 1.5% for the three-month period ended June 29, 2018, from 1.2% during the three-month period ended June 30, 2017. The increase in CTG's margins during the period, primarily reflected lesser losses from our strategic partnership with a certain customer compared to the three-month period ended June 30, 2017.

[0000866374-18-000010:mdna:60]
IEI segment margin decreased 40 basis points, to 3.6% for the three-month period ended June 29, 2018, from 4.0% during the three-month period ended June 30, 2017. The decrease in IEI's margin during the period is primarily due to pressure from demand softness for new customers in our industrial home and lifestyle business and reduced demand in our semiconductor capital equipment business. In addition, we saw declines in our Energy business due to a temporary impact from reduced shipments of our Nextracker solar tracking solutions and certain other customer declines.

[0000866374-18-000010:mdna:61]
HRS segment margin decreased 30 basis points, to 7.7% for the three-month period ended June 29, 2018, from 8.0% during the three-month period ended June 30, 2017 primarily as a result of ramping up of several new customers and programs, coupled with our continuous investment to expand our design and engineering capabilities focused on autonomous vehicle and connectivity platforms.

[0000866374-18-000010:mdna:62]
[same as prior period, unchanged from 0000866374-18-000003:mdna:67]

[0000866374-18-000010:mdna:63]
33

[0000866374-18-000010:mdna:64]
Selling, general and administrative expenses (“SG&A”) was $263 million, or 4.1% of net sales, during the three-month period ended June 29, 2018, increasing $12 million from $251 million, or 4.2% of net sales, during the three-month period ended June 30, 2017. This increase was primarily due to incremental costs of $9 million incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors, and to a lesser extent, for an immaterial amount of additional restructuring charges incurred during the three-month period ended June 29, 2018.

[0000866374-18-000010:mdna:65]
[same as prior period, unchanged from 0000866374-18-000003:mdna:69]

[0000866374-18-000010:mdna:66]
Amortization of intangible assets marginally declined during the three-month period ended June 29, 2018 to $19 million, from $20 million for the three-month period ended June 30, 2017 primarily due to certain intangibles now being fully amortized.

[0000866374-18-000010:mdna:67]
[same as prior period, unchanged from 0000866374-18-000003:mdna:71]

[0000866374-18-000010:mdna:68]
Interest and other, net was $42 million during the three-month period ended June 29, 2018 compared to $27 million during the three-month period ended June 30, 2017. The increase in interest and other, net was primarily a result of higher interest expense due to higher interest rates and a higher average borrowing level, coupled with increases in foreign exchange losses.

[0000866374-18-000010:mdna:69]
Other income, net

[0000866374-18-000010:mdna:70]
Other income, net was $87 million of income during the three-month period ended June 29, 2018 compared to $36 million of income during the three-month period ended June 30, 2017. The increase is primarily due to a $92 million non-cash gain as a result of the deconsolidation of AutoLab AI (“AutoLab”), as further described in note 2 of the condensed consolidated financial statements.

[0000866374-18-000010:mdna:71]
[same as prior period, unchanged from 0000866374-18-000003:mdna:75]

[0000866374-18-000010:mdna:72]
Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 14, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2018 for further discussion.

[0000866374-18-000010:mdna:73]
[same as prior period, unchanged from 0000866374-18-000003:mdna:77]

[0000866374-18-000010:mdna:74]
The consolidated effective tax rate was 18.1% and 14.3% for the three-month periods ended June 29, 2018 and June 30, 2017, respectively. The effective rate varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, the Netherlands and Israel. The effective tax rate for the three-month period ended June 29, 2018 is higher than the effective tax rate for the three-month period ended June 30, 2017, due to a changing jurisdictional mix of income and increased unfavorable foreign exchange rate impacts on tax-related balances during the three-month period ended June 29, 2018.

[0000866374-18-000010:mdna:75]
[same as prior period, unchanged from 0000866374-18-000003:mdna:81]

[0000866374-18-000010:mdna:76]
As of June 29, 2018, we had cash and cash equivalents of approximately $1.3 billion and bank and other borrowings of approximately $2.9 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. As of June 29, 2018, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0000866374-18-000010:mdna:77]
Cash used in operating activities was $672 million during the three-month period ended June 29, 2018. This resulted from a $842 million net increase in our operating assets and liabilities driven primarily by a significant increase in accounts receivable netted by the new requirement to present inflows from deferred purchase price as cash flows from investing activities, as further described below, coupled with an increase in inventory, all of which were not fully offset by the increase in accounts payable, reflecting our increased level of operations. This was partially offset by $116 million of net income for the period plus $146 million of non-cash charges such as depreciation, amortization, and stock-based compensation, net of a $92 million gain from the deconsolidation of AutoLab, which is included in the determination of net income.

[0000866374-18-000010:mdna:78]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure the Company’s liquidity. Net working capital position was calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories, less accounts payable as of March 31, 2018. As part of the adoption of ASC 606 as further described in note 1 to the condensed consolidated financial statements, we expanded net working capital to include contract asset on a going forward basis. Net working capital increased $136 million to $1.7 billion as of June 29, 2018, from $1.6 billion as of March 31, 2018. This increase is primarily driven by (i) a $185 million increase in our inventory levels from March 31, 2018, as we are carrying elevated levels to support our revenue growth and positioning for multiple large ramps, (ii) an increase of $324 million in contract assets upon adoption of ASC 606, (iii) a $215 million increase in accounts receivable adding back reduction from non-cash accounts receivable sales, offset by approximately $588 million increase in accounts payable. Despite the increase in net working capital position from March 31, 2018, current quarter net working capital as a percentage of annualized net sales for the quarter then ended remained relatively consistent at 6.9% as compared to 7.0% of annualized net sales for the quarter ended June 30, 2017. The Company generally operates in a net working capital targeted range between 6%-8% of annualized revenue for the quarter.

[0000866374-18-000010:mdna:79]
Cash provided by investing activities was $472 million during the three-month period ended June 29, 2018. This was primarily driven by the impact of our adoption of ASU 2016-15 during the current fiscal year, which requires us to classify cash collections on deferred purchase price that were previously classified as operating cash inflows as cash flows from investing activities. Refer to note 1 to the condensed consolidated financial statements for further description of the ASU. During the three-month period ended June 29, 2018, we also invested $170 million of net capital expenditures for property and equipment to expand capabilities and capacity in support of our automotive, medical, footwear and IEI businesses. In addition, other investing activities includes $132 million of non-cash outflow representing our investment in AutoLab following the deconsolidation.

[0000866374-18-000010:mdna:80]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Upon adoption of ASU 2016-15 in the current quarter, our free cash flow is redefined as cash from operations, plus cash collections of deferred purchase price, less net purchases of property and equipment to present cash flows on a consistent basis for investor transparency. Our free cash flows for the three-month period ended June 29, 2018 was a use of $185 million compared to an inflow of $19 million for the three-month period ended June 30, 2017. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-18-000010:mdna:81]
|  | Three-Month Periods Ended |
|  | June 29, 2018 |  | June 30, 2017 |
|  | (In millions) |
| Net cash provided by operating activities | $ | (672 | ) |  | $ | (696 | ) |
| Cash collection of deferred purchase price | 657 |  |  | 834 |  |
| Purchases of property and equipment | (172 | ) |  | (125 | ) |
| Proceeds from the disposition of property and equipment | 2 |  |  | 6 |  |
| Free cash flow | $ | (185 | ) |  | $ | 19 |  |

[0000866374-18-000010:mdna:82]
Cash used in financing activities was immaterial during the three-month period ended June 29, 2018.

[0000866374-18-000010:mdna:83]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of June 29, 2018, and March 31, 2018, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of

[0000866374-18-000010:mdna:84]
35

[0000866374-18-000010:mdna:85]
our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2018). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-18-000010:mdna:86]
[same as prior period, unchanged from 0000866374-18-000003:mdna:92]

[0000866374-18-000010:mdna:87]
[same as prior period, unchanged from 0000866374-18-000003:mdna:93]

[0000866374-18-000010:mdna:88]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-18-000010:mdna:89]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 15, 2017. During the three-month period ended June 29, 2018, the Company made no repurchases of shares. As of June 29, 2018, shares in the aggregate amount of $410 million were available to be repurchased under the current plan.

[0000866374-18-000010:mdna:90]
[same as prior period, unchanged from 0000866374-18-000003:mdna:96]

[0000866374-18-000010:mdna:91]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2018. There have been no material changes in our contractual obligations and commitments since March 31, 2018 except for the following changes to our debt obligations.

[0000866374-18-000010:mdna:92]
[same as prior period, unchanged from 0000866374-18-000003:mdna:101]

[0000866374-18-000010:mdna:93]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of June 29, 2018, and March 31, 2018, the fair values of our deferred purchase price receivable were approximately $288 million and $445 million, respectively. As of June 29, 2018, and March 31, 2018, the outstanding balance on receivables sold for cash was $1.4 billion and $1.3 billion under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information, see note 10 to the condensed consolidated financial statements.
