# FLEX note change history — 0000866374-18-000003 → 0000866374-18-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-02):
[0000866374-18-000010:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The Company does not believe that the amounts accrued are material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.
  (was, 2018-01-29, similarity 0.9978):
[0000866374-18-000003:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The Company does not believe that the amounts accrued are material.  Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented.  Any such excess could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- added (2018-08-02):
[0000866374-18-000010:note_history:2]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conduct it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

- added (2018-08-02):
[0000866374-18-000010:note_history:3]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable our use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g. base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing a patent license agreement, and requesting information relating to royalties for products that it assembles for a customer in China. If any of these inquiries result in a claim, the Company intends to contest and defend against any such claim vigorously. If a claim is asserted and the Company is unsuccessful in its defense, a material loss is reasonably possible. The Company cannot predict or estimate an amount or reasonable range of outcomes with respect to the matter.

- added (2018-08-02):
[0000866374-18-000010:note_history:4]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. The deadline for applications for appointment as lead plaintiff was July 9, 2018. There are two pending motions for appointment as lead plaintiff, which are scheduled to be heard by the Court on October 11, 2018.  The Court has extended the time for Defendants to respond to the complaint until after a lead plaintiff is appointed and an amended complaint is filed by the lead plaintiff.

- added (2018-08-02):
[0000866374-18-000010:note_history:5]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- added (2018-08-02):
[0000866374-18-000010:note_history:6]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 346 million Brazilian reals (approximately USD $90 million based on the exchange rate as of June 29, 2018). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

- removed (2018-08-02):
[0000866374-18-000003:note_history:7]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible loss. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

- removed (2018-08-02):
[0000866374-18-000003:note_history:8]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 291 million Brazilian reals (approximately USD $88 million based on the exchange rate as of December 31, 2017). The assessments are in various stages of the review process at the administrative level. The Company has meritorious defenses and plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-02):
[0000866374-18-000010:note_history:9]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and enterprise products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:
  (was, 2018-01-29, similarity 0.9851):
[0000866374-18-000003:note_history:9]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and industrial products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

- changed (2018-08-02):
[0000866374-18-000010:note_history:10]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion and apparel, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |
  (was, 2018-01-29, similarity 0.769):
[0000866374-18-000003:note_history:10]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, wearables, gaming, augmented and virtual reality, fashion, and mobile devices; and including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG is expanding its business relationships to include supply chain optimization for non-electronics products such as footwear and clothing; |

- added (2018-08-02):
[0000866374-18-000010:note_history:11]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, electric vehicle infrastructure, smart solar energy, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation, and kiosks; and |

- changed (2018-08-02):
[0000866374-18-000010:note_history:12]
| • | High Reliability Solutions ("HRS"), which is comprised of health solutions business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies. |
  (was, 2018-01-29, similarity 0.9665):
[0000866374-18-000003:note_history:12]
| • | High Reliability Solutions ("HRS"), which is comprised of medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies. |

- changed (2018-08-02):
[0000866374-18-000010:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2018 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month period ended June 29, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019.
  (was, 2018-01-29, similarity 0.9813):
[0000866374-18-000003:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2017 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018.

- added (2018-08-02):
[0000866374-18-000010:note_history:14]
The first quarters for fiscal year 2019 and fiscal year 2018 ended on June 29, 2018, which is comprised of 90 days in the period, and June 30, 2017, which is comprised of 91 days in the period, respectively.

- changed (2018-08-02):
[0000866374-18-000010:note_history:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.
  (was, 2018-01-29, similarity 0.851):
[0000866374-18-000003:note_history:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. Noncontrolling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- changed (2018-08-02):
[0000866374-18-000010:note_history:16]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.
  (was, 2018-01-29, similarity 0.8319):
[0000866374-18-000003:note_history:16]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has a voting percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

- added (2018-08-02):
[0000866374-18-000010:note_history:17]
In January 2017, the FASB issued Accounting Standard Update (ASU) No. 2017-01 “Business Combinations (Topic 805): Clarifying the Definition of a Business” to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The Company adopted the guidance on a prospective basis during the first quarter of fiscal year 2019, which did not have a material impact to its financial position as there were no acquisitions during the period.

- added (2018-08-02):
[0000866374-18-000010:note_history:18]
In August 2016, the FASB issued ASU 2016-15, "Statement of Cash Flows (Topic 2030): Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force)." The ASU is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 is consistent with our current cash flow classification. However, cash receipts on the deferred purchase price from the Company's asset-backed securitization programs described in note 10 will be classified as cash flows from investing activities instead of the Company's former presentation as cash flows from operations. The Company adopted the guidance during the first quarter of fiscal year 2019 and retrospectively adjusted cash flows from operating and investing activities for three-month period ended June 30, 2017. Upon adoption of the standard, the Company recorded $0.7 billion of cash receipts on the deferred purchase price from the Company's asset-backed securitization programs for the three-month period ended June 29, 2018 and reclassified $0.8 billion of cash receipts on the deferred purchase price for the three-month period ended June 30, 2017, from cash flows from operating activities to cash flows from investing activities and the Company’s condensed consolidated statement of cash flows for the three-months ended June 30, 2017 has been restated to reflect this adjustment.

- added (2018-08-02):
[0000866374-18-000010:note_history:19]
The Company adopted this new guidance using a method which allocates cash flows between operating and investing activities based on monthly receivables sales and collection data.  Commencing with the quarter ending September 28, 2018, the Company will change to a method based on daily activity, and will apply this new method retrospectively.  Management expects this change to result in a decrease in cash flows from operating activities and a corresponding increase in cash flows from investing activities, and that the amount of such change could be material, though no amounts have yet been quantified for any period presented.

- added (2018-08-02):
[0000866374-18-000010:note_history:20]
In January 2016, the FASB issued ASU 2016-01 "Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This guidance generally requires equity investments, except those accounted for under the equity method of accounting or those that result in consolidation of the investee, to be measured at fair value with changes in fair value recognized in net income. This guidance also requires the separate presentation of financial assets and financial liabilities by measurement category and form of financial asset on the balance sheet or in the accompanying notes to the financial statements. The Company adopted this guidance on April 1, 2018 with an insignificant impact on the Company's financial position, results of operations or cash flows.

- changed (2018-08-02):
[0000866374-18-000010:note_history:21]
In May 2014, the FASB issued ASU 2014-09 "Revenue from Contracts with Customers (Topic 606)" (also referred to as Accounting Standard Codification 606 ("ASC 606")) which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract.
  (was, 2018-01-29, similarity 0.8923):
[0000866374-18-000003:note_history:21]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. The guidance is effective for the Company beginning in the first quarter of fiscal year 2019.

- added (2018-08-02):
[0000866374-18-000010:note_history:22]
The Company adopted the standard on April 1, 2018 using the modified retrospective approach by applying the guidance to all open contracts at the adoption date and has implemented revised accounting policies, new  operational and financial reporting processes, enhanced systems capabilities and relevant internal controls.

- added (2018-08-02):
[0000866374-18-000010:note_history:23]
As part of adopting ASC 606, revenue for certain customer contracts where the Company is manufacturing products for which there is no alternative use and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory will be recognized over time (i.e. as we manufacture the product) instead of upon shipment of products.  In addition to the following disclosures, note 3 provides further disclosures required by the new standard.

- added (2018-08-02):
[0000866374-18-000010:note_history:24]
The cumulative effect of change made to our April 1, 2018 consolidated balance sheet for the adoption of ASC 606 was as follows:

- added (2018-08-02):
[0000866374-18-000010:note_history:25]
| Condensed Consolidated Balance Sheet |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | Balance at March 31, 2018 | Adjustments | Balance at April 1, 2018 |
| ASSETS |  |  |  |
| Contract assets | — |  | 412,787 |  | 412,787 |  |
| Inventories | 3,799,829 |  | (409,252 | ) | 3,390,577 |  |
| Other current assets | 1,380,466 |  | (51,479 | ) | 1,328,987 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,719,418 |  | (87,897 | ) | 1,631,521 |  |
| Other liabilities | 531,587 |  | 2,098 |  | 533,685 |  |
| Accumulated deficit | (3,144,114 | ) | (37,855 | ) | (3,181,969 | ) |

- added (2018-08-02):
[0000866374-18-000010:note_history:26]
The adoption of ASC 606 resulted in the establishment of contract asset and contract liability balance sheet accounts and in the reclassification to these new accounts from certain asset and liability accounts, primarily inventories. The increase in accumulated deficit in the table above reflects $37.9 million of net adjustments to the balance sheet as of April 1, 2018, resulting from the adoption of ASC 606 primarily related to certain customer contracts requiring an over-time method of revenue recognition. The declines in inventories and other current asset reflect reclassifications to contract assets due to the earlier recognition of certain costs of products sold for over-time contracts. The decline in other current liabilities is primarily due to the reclassification of payments from customers in advance of work performed to contract assets to reflect the net position of the related over-time contracts.

- added (2018-08-02):
[0000866374-18-000010:note_history:27]
The following tables summarize the impacts of ASC 606 adoption on the Company’s condensed consolidated balance sheets and condensed consolidated statements of operations:

- added (2018-08-02):
[0000866374-18-000010:note_history:28]
| Condensed Consolidated Balance Sheet |  |  |  |
| As of June 29, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| ASSETS |  |  |  |
| Contract assets | 323,599 |  | (323,599 | ) | — |  |
| Inventories | 3,984,571 |  | 321,710 |  | 4,306,281 |  |
| Other current assets | 1,231,773 |  | 39,184 |  | 1,270,957 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,665,432 |  | 70,317 |  | 1,735,749 |  |
| Accumulated deficit | (2,989,377 | ) | (33,022 | ) | (3,022,399 | ) |

- added (2018-08-02):
[0000866374-18-000010:note_history:29]
| Condensed Consolidated Statement of Operations |  |  |  |
| Three-months ended June 29, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| Net sales | $ | 6,423,956 |  | $ | 101,974 |  | $ | 6,525,930 |  |
| Cost of sales | 6,046,102 |  | 97,141 |  | 6,143,243 |  |
| Gross profit | 377,854 |  | 4,833 |  | 382,687 |  |
| Net income | $ | 116,035 |  | $ | 4,833 |  | $ | 120,868 |  |

- added (2018-08-02):
[0000866374-18-000010:note_history:30]
The as reported revenue and gross profit for the period ended June 29, 2018 were approximately $102.0 million, and $4.8 million less than they would have been without ASC 606 adoption primarily due to certain contract amendments for a portion of the Company's customers executed in the quarter. To align contractual terms across the vast majority of customers to allow the Company to efficiently and accurately manage its contracts, the Company waived certain contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. These modifications will result in revenue from these customers being recognized upon shipment of products, rather than over time (i.e. as we manufacture products) as further explained in note 3. The result of the amendments was to reduce revenue and gross profit by approximately $132.7 million and $9.3 million, respectively, compared to amounts that would have been reported both (i) under ASC 606 had we not amended the contracts, and (ii) had we not adopted ASC 606.  Offsetting the impact of the one-time contract amendments noted above was approximately $30.7 million of additional revenue and $4.5 million of gross profit recognized in the "as reported" amounts due to the accelerated timing of recognition of revenue for contracts which meet the criteria for over-time recognition (see note 3). There was no material tax impact for the three months period ended June 29, 2018 from adopting ASC 606.

- added (2018-08-02):
[0000866374-18-000010:note_history:31]
The Company applies the following practical expedients:

- added (2018-08-02):
[0000866374-18-000010:note_history:32]
| • | The Company elected to not disclose information about remaining performance obligations as its performance obligations generally have an expected durations of one year or less. |

- added (2018-08-02):
[0000866374-18-000010:note_history:33]
| • | In accordance with ASC 606-10-25-18B the Company will account for certain shipping and handling as activities to fulfill the promise to transfer the good, instead of a promised service to its customer. |

- added (2018-08-02):
[0000866374-18-000010:note_history:34]
| • | In accordance with ASC 606-10-32-18 the Company elected to not adjust the promised amount of consideration for the effects of a significant financing component as the Company expects, at contract inception, that the period between when the entity transfers a promised good or service to a customer and when the customer pays for that good or service will generally be one year or less. |

- added (2018-08-02):
[0000866374-18-000010:note_history:35]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- changed (2018-08-02):
[0000866374-18-000010:note_history:36]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.
  (was, 2018-01-29, similarity 0.9009):
[0000866374-18-000003:note_history:36]
In August 2017, the FASB issued new guidance with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- added (2018-08-02):
[0000866374-18-000010:note_history:37]
In February 2018, the FASB issued ASU 2018-03 "Technical Corrections and Improvements to Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This standard comes as an addition to ASU 2016-01which the Company adopted in the first quarter of fiscal year 2019.  This update includes amendments to clarify certain aspects of the guidance issued in Update 2016-01. The Company will adopt the guidance during the second quarter of fiscal year 2019, and expects it will have an immaterial impact on its consolidated financial statements.

- added (2018-08-02):
[0000866374-18-000010:note_history:38]
In January 2017, the FASB issued ASU 2017-04 "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment" to simplify the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. This guidance requires that the change be applied on a prospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2021, with early application permitted. The Company is currently assessing the impact of the new guidance and the timing of adoption.

- added (2018-08-02):
[0000866374-18-000010:note_history:39]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach. The Company believes the new guidance will have a material impact on its consolidated balance sheets upon adoption.

- removed (2018-08-02):
[0000866374-18-000003:note_history:40]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy and metering, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation and kiosks, and lighting; and |

- removed (2018-08-02):
[0000866374-18-000003:note_history:41]
The first quarters for fiscal year 2018 and fiscal year 2017 ended on June 30, 2017, which is comprised of 91 days in the period, and July 1, 2016, which is comprised of 92 days in the period, respectively. The second quarters for fiscal year 2018 and fiscal year 2017 ended on September 29, 2017 and September 30, 2016, which are comprised of 91 days in both periods. The Company's third quarters end on December 31 of each year, which are comprised of 93 days and 92 days for fiscal years 2018 and 2017, respectively.

- removed (2018-08-02):
[0000866374-18-000003:note_history:42]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.

- removed (2018-08-02):
[0000866374-18-000003:note_history:43]
In October 2016, the FASB issued new guidance intended to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early adoption permitted in the first interim period of fiscal year 2018. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.

- removed (2018-08-02):
[0000866374-18-000003:note_history:44]
In August 2016, the FASB issued Accounting Standard Update (ASU) No. 2016-15, "Statement of Cash Flows (Topic 2030): Classification of Certain Cash Receipts and Cash Payments." The standard is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 is consistent with our current cash flow classification. However, cash receipts on the deferred purchase price as described in Note 10 will be classified as cash flow from investing activities instead of the Company's current presentation as cash flows from operations. The Company intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2019 and retrospectively report cash flows from operating and investing activities for all periods presented. While the Company is still quantifying the impact of adoption of this standard, it does expect the standard to result in a material increase in cash flows from investing activities and corresponding reduction in cash flows from operating activities for all periods presented.

- removed (2018-08-02):
[0000866374-18-000003:note_history:45]
In February 2016, the FASB issued new guidance intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach. Upon initial evaluation, the Company believes the new guidance will have a material impact on its consolidated balance sheets when adopted.

- removed (2018-08-02):
[0000866374-18-000003:note_history:46]
The Company is in the process of implementation activities in accordance with the planned effective date. These activities are focused on the review of significant customer contracts, identification and development of additional systems capabilities to enable the Company to make reasonable estimates of revenue as products are manufactured, and the design and implementation of relevant internal controls. The Company has determined that the new standard will change the timing of revenue recognition for a significant portion of its business. Under the new standard, revenue for a significant majority of the manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery). This change will also have material impacts to the Company’s balance sheet, primarily related to a reduction in finished goods and work-in-process inventories and an increase in unbilled receivables.

- removed (2018-08-02):
[0000866374-18-000003:note_history:47]
The new guidance allows for two transition methods in application - (i) retrospective to each prior reporting period presented, or (ii) prospective with the cumulative effect of adoption recognized on April 1, 2018, the first day of the Company's fiscal year 2019 (also known as the modified retrospective approach). The Company will adopt the standard using the modified retrospective approach, which will result in an adjustment to accumulated deficit for the cumulative effect of applying this guidance to contracts in process as of the adoption date. Under this approach, prior financial statements presented will not be restated. This guidance requires additional disclosures of the amount by which each financial statement line item affected in the current reporting period during fiscal year 2019 as compared to the guidance that was in effect before the change, and an explanation of the reasons for the significant changes.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2018-08-02):
[0000866374-18-000003:note_history:48]
BANK BORROWINGS AND LONG TERM DEBT

- removed (2018-08-02):
[0000866374-18-000003:note_history:49]
Bank borrowings and long-term debt are as follows:

- removed (2018-08-02):
[0000866374-18-000003:note_history:50]
|  | As of December 31, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 691,875 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 489,938 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,282 |  |  | 595,979 |  |
| Other | 181,175 |  |  | 169,671 |  |
| Debt issuance costs | (14,596 | ) |  | (16,007 | ) |
| Total | $ | 2,944,674 |  |  | $ | 2,952,143 |  |

- removed (2018-08-02):
[0000866374-18-000003:note_history:51]
The weighted-average interest rates for the Company’s long-term debt were 3.7% and 3.5% as of December 31, 2017 and March 31, 2017, respectively.

- removed (2018-08-02):
[0000866374-18-000003:note_history:52]
On June 30, 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature in March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualified as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the term of the 2022 Credit Facility.

- removed (2018-08-02):
[0000866374-18-000003:note_history:53]
Borrowings under the 2022 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate that would be calculated as of each day in respect of a proposed LIBOR loan with a one-month interest period, plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 1.875% per annum, based on the Company’s credit ratings.

- removed (2018-08-02):
[0000866374-18-000003:note_history:54]
The 2022 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of December 31, 2017, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.

- removed (2018-08-02):
[0000866374-18-000003:note_history:55]
The Company has three tranches of Notes, the 4.625% Notes due 2020, the 5.000% Notes due 2023 and the 4.75% Notes due 2025. These Notes are senior unsecured obligations, and prior to June 30, 2017, were guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). Upon the termination of the $2.1 billion credit facility, all guarantor subsidiaries were released from their guarantees under each indenture for each Note. As a result, the Company will no longer be providing supplemental guarantor and non-guarantor condensed consolidating financial statements.

- removed (2018-08-02):
[0000866374-18-000003:note_history:56]
Repayment of the Company’s long term debt outstanding as of December 31, 2017 is as follows:

- removed (2018-08-02):
[0000866374-18-000003:note_history:57]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 (1) | $ | 10,739 |  |
| 2019 | 42,934 |  |
| 2020 | 542,872 |  |
| 2021 | 115,247 |  |
| 2022 | 809,103 |  |
| Thereafter | 1,438,375 |  |
| Total | $ | 2,959,270 |  |

- removed (2018-08-02):
[0000866374-18-000003:note_history:58]
_________________________________________________________

- removed (2018-08-02):
[0000866374-18-000003:note_history:59]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2018. |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-02):
[0000866374-18-000010:note_history:60]
|  | As of June 29, 2018 |  | As of March 31, 2018 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 499,950 |  |  | $ | 500,000 |  |  | $ | 513,596 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 683,750 |  |  | 686,314 |  |  | 687,813 |  |  | 689,966 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 477,375 |  |  | 477,375 |  |  | 483,656 |  |  | 485,470 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 499,950 |  |  | 500,000 |  |  | 525,292 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,492 |  |  | 599,940 |  |  | 596,387 |  |  | 627,407 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 55,797 |  |  | 55,797 |  |  | 59,443 |  |  | 59,443 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 115,942 |  |  | 115,942 |  |  | 123,518 |  |  | 123,518 |  |  | Level 1 |
| Total | $ | 2,929,356 |  |  | $ | 2,935,268 |  |  | $ | 2,950,817 |  |  | $ | 3,024,692 |  |  |  |
  (was, 2018-01-29, similarity 0.9905):
[0000866374-18-000003:note_history:60]
|  | As of December 31, 2017 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 516,925 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 691,875 |  |  | 693,605 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 489,938 |  |  | 491,163 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 536,515 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,282 |  |  | 643,440 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 58,021 |  |  | 58,021 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 119,786 |  |  | 119,786 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,955,902 |  |  | $ | 3,059,455 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |

- removed (2018-08-02):
[0000866374-18-000003:note_history:61]
(1)    On June 30, 2017, the Company entered into a new agreement that effectively extended the maturity date of the loan from March 31, 2019 to June 30, 2022. Refer to note 6 for further details of the arrangement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2018-08-02):
[0000866374-18-000003:note_history:62]
Bank borrowings and long-term debt are as follows:

- removed (2018-08-02):
[0000866374-18-000003:note_history:63]
|  | As of December 31, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 691,875 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 489,938 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,282 |  |  | 595,979 |  |
| Other | 181,175 |  |  | 169,671 |  |
| Debt issuance costs | (14,596 | ) |  | (16,007 | ) |
| Total | $ | 2,944,674 |  |  | $ | 2,952,143 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2018-08-02):
[0000866374-18-000003:note_history:64]
Repayment of the Company’s long term debt outstanding as of December 31, 2017 is as follows:

- removed (2018-08-02):
[0000866374-18-000003:note_history:65]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 (1) | $ | 10,739 |  |
| 2019 | 42,934 |  |
| 2020 | 542,872 |  |
| 2021 | 115,247 |  |
| 2022 | 809,103 |  |
| Thereafter | 1,438,375 |  |
| Total | $ | 2,959,270 |  |

- removed (2018-08-02):
[0000866374-18-000003:note_history:66]
_________________________________________________________

- removed (2018-08-02):
[0000866374-18-000003:note_history:67]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2018. |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-08-02):
[0000866374-18-000010:note_history:68]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and overtime - for the three-month period ended June 29, 2018 (in thousands):

- added (2018-08-02):
[0000866374-18-000010:note_history:69]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,300,637 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 4,863,222 |  |
| Over time | 210,245 |  |  | 507,297 |  |  | 382,413 |  |  | 460,779 |  |  | 1,560,734 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,807,934 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 6,423,956 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-08-02):
[0000866374-18-000010:note_history:70]
REVENUE

- added (2018-08-02):
[0000866374-18-000010:note_history:71]
Revenue Recognition

- added (2018-08-02):
[0000866374-18-000010:note_history:72]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that create enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc, and the level of business under those agreements may not be guaranteed. In those instances, we bid on a program-by-program basis and typically receive customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

- added (2018-08-02):
[0000866374-18-000010:note_history:73]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and IP restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- added (2018-08-02):
[0000866374-18-000010:note_history:74]
Customer Contracts and Related Obligations

- added (2018-08-02):
[0000866374-18-000010:note_history:75]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refund required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer related accruals in note 2.

- added (2018-08-02):
[0000866374-18-000010:note_history:76]
Performance Obligations

- added (2018-08-02):
[0000866374-18-000010:note_history:77]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

- added (2018-08-02):
[0000866374-18-000010:note_history:78]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises).  The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g.: procurement of materials and standard workmanship warranty).

- added (2018-08-02):
[0000866374-18-000010:note_history:79]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of our contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that Flex would sell similar goods or services separately.

- added (2018-08-02):
[0000866374-18-000010:note_history:80]
Contract Balances

- added (2018-08-02):
[0000866374-18-000010:note_history:81]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheet and transferred to receivables when rights to payment become unconditional. The following table summarizes the activity in the Company's contract assets during the three-month period ended June 29, 2018 (in thousands):

- added (2018-08-02):
[0000866374-18-000010:note_history:82]
|  | Contract Assets |
| Beginning balance, April 1, 2018 | $ | — |  |
| Cumulative effect adjustment at April 1, 2018 | 412,787 |  |
| Revenue recognized | 1,560,734 |  |
| Amounts collected or invoiced | (1,649,922 | ) |
| Ending balance, June 29, 2018 | $ | 323,599 |  |

- added (2018-08-02):
[0000866374-18-000010:note_history:83]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and are included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $270.6 million and $265.3 million as of June 29, 2018 and April 1, 2018, respectively.

- added (2018-08-02):
[0000866374-18-000010:note_history:84]
Disaggregation of Revenue

- added (2018-08-02):
[0000866374-18-000010:note_history:85]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and overtime - for the three-month period ended June 29, 2018 (in thousands):

- added (2018-08-02):
[0000866374-18-000010:note_history:86]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,300,637 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 4,863,222 |  |
| Over time | 210,245 |  |  | 507,297 |  |  | 382,413 |  |  | 460,779 |  |  | 1,560,734 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,807,934 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 6,423,956 |  |
