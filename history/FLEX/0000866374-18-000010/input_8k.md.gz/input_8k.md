# FLEX 8-K — 0001104659-18-047422 filed 2018-07-26

## item codes, every 8-K on or before 2018-08-02

- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2018-08-02

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-18-047422:8k_2_02:1]
EX-99.1
2
a18-17727_1ex99d1.htm
EX-99.1

[0001104659-18-047422:8k_2_02:2]
Exhibit 99.1

[0001104659-18-047422:8k_2_02:3]
FLEX REPORTS FIRST QUARTER FISCAL 2019 RESULTS

[0001104659-18-047422:8k_2_02:4]
·      Quarterly revenue of $6.4 billion, increased 7% year-over-year

[0001104659-18-047422:8k_2_02:5]
·      GAAP diluted EPS of $0.22, Non-GAAP diluted EPS of $0.24

[0001104659-18-047422:8k_2_02:6]
San Jose, CA, July 26, 2018 — Flex (NASDAQ: FLEX), the Sketch-to-Scale® solutions provider that designs and builds Intelligent Products for a Connected World®, today announced results for its first quarter ended June 29, 2018.

[0001104659-18-047422:8k_2_02:7]
|  |  | Three-Month Periods Ended |  |
| US$ in millions, except earnings per share |  | June 29, 2018 |  | June 30, 2017 |  |
| Net sales |  | $ | 6,424 |  | $ | 6,008 |  |
| GAAP income before income taxes |  | 142 |  | 146 |  |
| Adjusted operating income |  | 188 |  | 178 |  |
| GAAP net income |  | 116 |  | 125 |  |
| Adjusted net income |  | 128 |  | 128 |  |
| GAAP EPS |  | 0.22 |  | 0.23 |  |
| Adjusted EPS |  | 0.24 |  | 0.24 |  |

[0001104659-18-047422:8k_2_02:8]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release.

[0001104659-18-047422:8k_2_02:9]
“This marked the sixth straight quarter of year-over-year revenue growth reflecting a balanced and diversified service offering that enables integrated industry solutions,” said Mike McNamara, CEO at Flex.

[0001104659-18-047422:8k_2_02:10]
First Quarter Fiscal 2019 Results of Operations

[0001104659-18-047422:8k_2_02:11]
Net sales for the first quarter ended June 29, 2018 were $6.4 billion, growing 7% year-over-year. We adopted the new revenue recognition standard, ASU 2014-09 “Revenue from Contracts with Customers (Topic 606)” starting April 1, 2018. Our net sales for Q1 fiscal year 2019 without the adoption impact were $6.5 billion and within the guidance range of $6.3 to $6.7 billion which also excluded the impact from adoption of the new revenue recognition standard. GAAP income before income taxes was $142 million for the quarter and adjusted operating income was $188 million, above the midpoint of the guidance range of $170 million to $200 million. GAAP net income was $116 million and adjusted net income for the quarter was $128 million. GAAP net income per share was $0.22 for the quarter and adjusted EPS was $0.24 for the quarter.

[0001104659-18-047422:8k_2_02:12]
Balance Sheet and Cash Flow Highlights

[0001104659-18-047422:8k_2_02:13]
Flex ended the quarter with over $1.25 billion of cash on hand and total debt of approximately $2.9 billion. The balance sheet remains well-positioned to support the business over the long-term.

[0001104659-18-047422:8k_2_02:14]
In the first quarter of fiscal year 2019, we adopted the new cash flow accounting standard (ASU 2016-15) which resulted in a reclassification of cash inflows related to the deferred purchase price from securitization transactions from operating activities to investing activities. For the three-month period ended June 29, 2018, Flex’s cash from operations was negative $672 million or negative $15 million adjusted for the impact due to cash collections of deferred purchase price of $657 million during the

[0001104659-18-047422:8k_2_02:15]
period. Free cash flow was negative $185 million excluding the impact of the new standard as the Company has increased its investments into capital expenditures and net working capital to support its revenue growth.

[0001104659-18-047422:8k_2_02:16]
Second Quarter Fiscal Year 2019 Guidance

[0001104659-18-047422:8k_2_02:17]
For the second quarter ending September 28, 2018, revenue is expected to be in the range of $6.6 to $7.0 billion. Adjusted EPS is expected to be in the range of $0.26 to $0.30 per diluted share. GAAP EPS is expected to be in the range of $0.18 to $0.22 and includes stock-based compensation expense and intangible amortization.

[0001104659-18-047422:8k_2_02:18]
Other Items

[0001104659-18-047422:8k_2_02:19]
The Company has undertaken, and will continue to undertake, measures to improve our internal control over financial reporting to address and remediate the material weaknesses described further in Item 9A “Controls and Procedures” of our fiscal 2018 Form 10-K. Many of our remediation efforts have been implemented already or are in the process of implementation and we will be finalizing our plans over the coming months. Our initiatives are focused on enhancing site level controls, designing and implementing centralized reporting controls and enhancing the quality and frequency of training. While our remediation plan is being executed, we also have engaged and will continue to engage additional resources to support and supplement the Company’s existing internal resources. We are working to have the material weaknesses remediated as soon as possible.

[0001104659-18-047422:8k_2_02:20]
Webcast and Conference Call

[0001104659-18-047422:8k_2_02:21]
Flex management team will host a conference call today at 2:00 PM (PT) / 5:00 PM (ET), to review first quarter fiscal 2019 results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com. An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0001104659-18-047422:8k_2_02:22]
About Flex

[0001104659-18-047422:8k_2_02:23]
Flex Ltd. (Reg. No. 199002645H) is the Sketch-to-Scale® solutions provider that designs and builds Intelligent Products for a Connected World®. With approximately 200,000 professionals across 30 countries, Flex provides innovative design, engineering, manufacturing, real-time supply chain insight and logistics services to companies of all sizes in various industries and end-markets. For more information, visit flex.com or follow us on Twitter @Flexintl. Flex — Live Smarter®

[0001104659-18-047422:8k_2_02:24]
Contacts

[0001104659-18-047422:8k_2_02:25]
Investors & Analysts

[0001104659-18-047422:8k_2_02:26]
Kevin Kessel, CFA

[0001104659-18-047422:8k_2_02:27]
(408) 576-7985

[0001104659-18-047422:8k_2_02:28]
kevin.kessel@flex.com

[0001104659-18-047422:8k_2_02:29]
Media & Press

[0001104659-18-047422:8k_2_02:30]
Paul Brunato

[0001104659-18-047422:8k_2_02:31]
(408) 576-7534

[0001104659-18-047422:8k_2_02:32]
paul.brunato@flex.com

[0001104659-18-047422:8k_2_02:33]
Forward-Looking Statements

[0001104659-18-047422:8k_2_02:34]
Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our reports on Forms 10-K and 10-Q that we file with the U.S. Securities and Exchange Commission. The forward-looking statements in this press release are based on current expectations and Flex assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0001104659-18-047422:8k_2_02:35]
SCHEDULE I

[0001104659-18-047422:8k_2_02:36]
FLEX

[0001104659-18-047422:8k_2_02:37]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-18-047422:8k_2_02:38]
(In thousands, except per share amounts)

[0001104659-18-047422:8k_2_02:39]
|  |  | Three-Month Periods Ended |  |
|  |  | June 29, 2018 |  | June 30, 2017 |  |
| GAAP: |  |  |  |  |  |
| Net sales (2) |  | $ | 6,423,956 |  | $ | 6,008,272 |  |
| Cost of sales (2) |  | 6,046,102 |  | 5,601,340 |  |
| Gross profit |  | 377,854 |  | 406,932 |  |
| Selling, general and administrative expenses |  | 262,882 |  | 250,811 |  |
| Intangible amortization |  | 18,517 |  | 19,901 |  |
| Interest and other, net |  | 41,742 |  | 26,876 |  |
| Other income, net |  | (86,924 | ) | (36,165 | ) |
| Income before income taxes |  | 141,637 |  | 145,509 |  |
| Provision for income taxes |  | 25,602 |  | 20,799 |  |
| Net income |  | $ | 116,035 |  | $ | 124,710 |  |
| Earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.22 |  | $ | 0.23 |  |
| Non-GAAP |  | $ | 0.24 |  | $ | 0.24 |  |
| Diluted shares used in computing per share amounts |  | 535,454 |  | 538,633 |  |

[0001104659-18-047422:8k_2_02:40]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release.

[0001104659-18-047422:8k_2_02:41]
SCHEDULE II

[0001104659-18-047422:8k_2_02:42]
FLEX

[0001104659-18-047422:8k_2_02:43]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-18-047422:8k_2_02:44]
(In thousands, except per share amounts)

[0001104659-18-047422:8k_2_02:45]
|  |  | Three-Month Periods Ended |  |
|  |  | June 29, 2018 |  | June 30, 2017 |  |
| GAAP gross profit |  | $ | 377,854 |  | $ | 406,932 |  |
| Stock-based compensation expense |  | 5,404 |  | 3,319 |  |
| Distressed customers asset impairments (3) |  | 12,352 |  | — |  |
| Restructuring charges |  | 2,310 |  | — |  |
| New revenue standard adoption impact (4) |  | 9,291 |  | — |  |
| Legal and other (5) |  | 5,581 |  | — |  |
| Non-GAAP gross profit |  | $ | 412,792 |  | $ | 410,251 |  |
| GAAP income before income taxes |  | $ | 141,637 |  | $ | 145,509 |  |
| Intangible amortization |  | 18,517 |  | 19,901 |  |
| Stock-based compensation expense |  | 20,953 |  | 21,796 |  |
| Distressed customers asset impairments (3) |  | 17,364 |  | — |  |
| Restructuring charges |  | 8,817 |  | — |  |
| New revenue standard adoption impact (4) |  | 9,291 |  | — |  |
| Legal and other (5) |  | 16,311 |  | — |  |
| Other income, net (6) |  | (86,924 | ) | (36,165 | ) |
| Interest and other, net |  | 41,742 |  | 26,876 |  |
| Non-GAAP operating income |  | $ | 187,708 |  | $ | 177,917 |  |
| GAAP provision for income taxes |  | $ | 25,602 |  | $ | 20,799 |  |
| Intangible amortization benefit |  | 2,292 |  | 1,766 |  |
| Valuation allowance and tax receivable, net (7) |  | (8,404 | ) | — |  |
| Tax benefit on restructuring and other |  | (692 | ) | — |  |
| Non-GAAP provision for income taxes |  | $ | 18,798 |  | $ | 22,565 |  |
| GAAP net income |  | $ | 116,035 |  | $ | 124,710 |  |
| Intangible amortization |  | 18,517 |  | 19,901 |  |
| Stock-based compensation expense |  | 20,953 |  | 21,796 |  |
| Restructuring charges |  | 8,817 |  | — |  |
| Distressed customers asset impairments (3) |  | 17,364 |  | — |  |
| New revenue standard adoption impact (4) |  | 9,291 |  | — |  |
| Legal and other (5) |  | 16,311 |  | — |  |
| Other income, net (6) |  | (86,121 | ) | (36,165 | ) |
| Adjustments for taxes (7) |  | 6,804 |  | (1,766 | ) |
| Non-GAAP net income |  | $ | 127,971 |  | $ | 128,476 |  |
| Diluted earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.22 |  | $ | 0.23 |  |
| Non-GAAP |  | $ | 0.24 |  | $ | 0.24 |  |

[0001104659-18-047422:8k_2_02:46]
SCHEDULE III

[0001104659-18-047422:8k_2_02:47]
FLEX

[0001104659-18-047422:8k_2_02:48]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-18-047422:8k_2_02:49]
(In thousands)

[0001104659-18-047422:8k_2_02:50]
|  |  | As of June 29, 2018 |  | As of March 31, 2018 |  |
| ASSETS |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,254,639 |  | $ | 1,472,424 |  |
| Accounts receivable, net of allowance for doubtful accounts |  | 2,890,227 |  | 2,517,695 |  |
| Contract assets (2) |  | 323,599 |  | — |  |
| Inventories |  | 3,984,571 |  | 3,799,829 |  |
| Other current assets |  | 1,231,773 |  | 1,380,466 |  |
| Total current assets |  | 9,684,809 |  | 9,170,414 |  |
| Property and equipment, net |  | 2,190,080 |  | 2,239,506 |  |
| Goodwill |  | 1,094,776 |  | 1,121,170 |  |
| Other intangible assets, net |  | 390,827 |  | 424,433 |  |
| Other assets |  | 949,196 |  | 760,332 |  |
| Total assets |  | $ | 14,309,688 |  | $ | 13,715,855 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 42,903 |  | $ | 43,011 |  |
| Accounts payable |  | 5,709,079 |  | 5,122,303 |  |
| Accrued payroll |  | 377,461 |  | 383,332 |  |
| Other current liabilities |  | 1,665,432 |  | 1,719,418 |  |
| Total current liabilities |  | 7,794,875 |  | 7,268,064 |  |
| Long-term debt, net of current portion |  | 2,877,089 |  | 2,897,631 |  |
| Other liabilities |  | 528,405 |  | 531,587 |  |
| Total shareholders’ equity |  | 3,109,319 |  | 3,018,573 |  |
| Total liabilities and shareholders’ equity |  | $ | 14,309,688 |  | $ | 13,715,855 |  |

[0001104659-18-047422:8k_2_02:51]
SCHEDULE IV

[0001104659-18-047422:8k_2_02:52]
FLEX

[0001104659-18-047422:8k_2_02:53]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-18-047422:8k_2_02:54]
(In thousands)

[0001104659-18-047422:8k_2_02:55]
|  |  | Three-Month Periods Ended |  |
|  |  | June 29, 2018 |  | June 30, 2017 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income |  | $ | 116,035 |  | $ | 124,710 |  |
| Depreciation, amortization and other impairment charges |  | 121,763 |  | 131,396 |  |
| Gain from deconsolidation of a subsidiary entity |  | (91,025 | ) | — |  |
| Changes in working capital and other |  | (818,581 | ) | (951,862 | ) |
| Net cash used in operating activities |  | (671,808 | ) | (695,756 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property and equipment |  | (172,247 | ) | (124,851 | ) |
| Proceeds from the disposition of property and equipment |  | 2,336 |  | 5,476 |  |
| Acquisition of businesses, net of cash acquired |  | — |  | (213,718 | ) |
| Proceeds from divestiture of businesses, net of cash held in divested businesses |  | — |  | (616 | ) |
| Cash collections of deferred purchase price |  | 656,766 |  | 834,272 |  |
| Other investing activities, net |  | (15,218 | ) | (18,549 | ) |
| Net cash provided by investing activities |  | 471,637 |  | 482,014 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 150,313 |  | — |  |
| Repayments of bank borrowings and long-term debt |  | (150,344 | ) | (7,554 | ) |
| Payments for repurchases of ordinary shares |  | — |  | (73,864 | ) |
| Net proceeds from issuance of ordinary shares |  | 45 |  | 696 |  |
| Other financing activities, net |  | — |  | 57,628 |  |
| Net cash provided by (used in) financing activities |  | 14 |  | (23,094 | ) |
| Effect of exchange rates on cash and cash equivalents |  | (17,628 | ) | (11,642 | ) |
| Net change in cash and cash equivalents |  | (217,785 | ) | (248,478 | ) |
| Cash and cash equivalents, beginning of period |  | 1,472,424 |  | 1,830,675 |  |
| Cash and cash equivalents, end of period |  | $ | 1,254,639 |  | $ | 1,582,197 |  |
| Reconciliation of GAAP to Non-GAAP Financial Measures (1) |  |  |  |  |  |
| Net cash used in operating activities |  | $ | (671,808 | ) | $ | (695,756 | ) |
| Cash collections of deferred purchase price |  | 656,766 |  | 834,272 |  |
| Adjusted net cash provided by (used in) operating activities |  | (15,042 | ) | 138,516 |  |
| Net Capital Expenditures |  | (169,911 | ) | (119,375 | ) |
| Free Cash Flow |  | $ | (184,953 | ) | $ | 19,141 |  |

[0001104659-18-047422:8k_2_02:56]
SCHEDULE V

[0001104659-18-047422:8k_2_02:57]
FLEX AND SUBSIDIARIES

[0001104659-18-047422:8k_2_02:58]
NOTES TO SCHEDULES I, II, III, & IV

[0001104659-18-047422:8k_2_02:59]
(1)   To supplement Flex’s unaudited selected financial data presented consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude restructuring charges, stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies.  We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-18-047422:8k_2_02:60]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-18-047422:8k_2_02:61]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-18-047422:8k_2_02:62]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-18-047422:8k_2_02:63]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-18-047422:8k_2_02:64]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-18-047422:8k_2_02:65]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-18-047422:8k_2_02:66]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types.  In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-18-047422:8k_2_02:67]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions.  The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-18-047422:8k_2_02:68]
Distressed customers asset impairments consist primarily of non-cash impairments of certain inventory on hand to net realizable value as well as additional provisions for doubtful accounts receivable for customers that are experiencing significant financial difficulties. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-18-047422:8k_2_02:69]
Legal and other consists primarily of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors completed in June 2018. It also includes certain charges not directly related to ongoing or core business results primarily related to Multek China that was divested in the second quarter of fiscal year 2019. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-18-047422:8k_2_02:70]
New revenue standard adoption impact relates to the amendment of its existing contracts for certain smaller customers which removed the consideration of over-time recognition under ASC 606. This impact is excluded by the Company’s management in assessing current operating performance and is not expected to be recurring and therefore excluded by the Company from its non-GAAP measures.

[0001104659-18-047422:8k_2_02:71]
Restructuring charges include severance for rationalization at existing sites and corporate functions as well as asset impairment, lease termination, and other charges related to the closures and consolidations of certain operating sites. These costs may vary in size based on the Company’s initiatives and are not directly related to ongoing or core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-18-047422:8k_2_02:72]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies or other non-recurring tax charges, when applicable.

[0001104659-18-047422:8k_2_02:73]
Adjustment for operating cash flows and free cash flow metrics due to recently issued accounting standards.   In Q1 fiscal year 2019, the adoption of the new cash flow accounting standard resulted in a reclassification of cash flows related to the collection of certain receivables sold through the Company’s asset-backed receivable securitization program from operating activities to investing activities. The Company utilizes net cash flow from its various A/R sales programs as a low-cost source to fund operations and as a critical net working capital management tool.  Cash flow from operations is also a critical metric that investors use to evaluate a company’s earnings power. The Company views and manages all collections under the program similarly without bifurcation and accordingly provides the adjustment to reflect cash flows from operations inclusive of all collections of receivables sold through the programs.

[0001104659-18-047422:8k_2_02:74]
In addition, we redefined our free cash flow metric to be GAAP net cash flows from operating activities, plus cash collection of deferred purchase price, less purchases of property and equipment net of proceeds from dispositions to reflect this change and present cash flows on a consistent basis for investor transparency.  We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash flows used in operating activities.”

[0001104659-18-047422:8k_2_02:75]
(2) The below table reflects the three-months ended June 29, 2018 impact from ASU 2014-09 “Revenue from Contracts with Customers (Topic 606)”. For further detail, please refer to the Flex 10-Q.

[0001104659-18-047422:8k_2_02:76]
| (In thousands) |  | As Reported |  | Adjustments |  | Balance Without ASC 606 Adoption |  |
| ASSETS |  |  |  |  |  |  |  |
| Contract assets |  | $ | 323,599 |  | $ | (323,599 | ) | $ | — |  |
| Inventories |  | 3,984,571 |  | 321,710 |  | 4,306,281 |  |
| Other current assets |  | 1,231,773 |  | 39,184 |  | 1,270,957 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 1,665,432 |  | $ | 70,317 |  | $ | 1,735,749 |  |
| Total shareholders’ equity |  | 3,109,319 |  | (33,022 | ) | 3,076,297 |  |

[0001104659-18-047422:8k_2_02:77]
| (In thousands) |  | As Reported |  | Adjustments |  | Balance Without ASC 606 Adoption |  |
| GAAP: |  |  |  |  |  |  |  |
| Net sales |  | $ | 6,423,956 |  | $ | 101,974 |  | $ | 6,525,930 |  |
| Cost of sales |  | 6,046,102 |  | 97,141 |  | 6,143,243 |  |
| Gross profit |  | 377,854 |  | 4,833 |  | 382,687 |  |
| Net income |  | $ | 116,035 |  | $ | 4,833 |  | $ | 120,868 |  |

[0001104659-18-047422:8k_2_02:78]
(3) Distressed customers asset impairments for the three-month period ended June 29, 2018 relate to additional provision for doubtful accounts receivable, inventory and other assets for certain customers experiencing significant financial difficulties.

[0001104659-18-047422:8k_2_02:79]
(4) During the quarter, the Company amended certain non-substantive terms of its existing contracts for its smaller customers. The amendments removed the consideration regarding over-time recognition under ASC 606. Accordingly, these customer contracts are now accounted for consistent with prior accounting and revenue is recognized upon shipment of product.

[0001104659-18-047422:8k_2_02:80]
(5) Legal and other during the three-month period ended June 29, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018 and certain charges of the China based Multek that was divested in the second quarter of fiscal year 2019.

[0001104659-18-047422:8k_2_02:81]
(6) During the three-month period ended June 29, 2018, the company transferred employees and equipment along with certain related software and IP, into AutoLab AI which later received additional equity funding from third party investors and changed the composition of the Board of directors removing Flex’s control.  As such, we deconsolidated the entity and recognized a gain of approximately $92 million in other income, net for the quarter ended June 29, 2018.

[0001104659-18-047422:8k_2_02:82]
The company sold its Wink business during first quarter of fiscal year 2018 to an unrelated third-party venture backed company in exchange for contingent consideration fair valued at $59 million and recognized a gain on sale of $38.7 million, which is recorded in other income, net for the quarter ended June 30, 2017.

[0001104659-18-047422:8k_2_02:83]
(7) Adjustment for exchange rate fluctuation on income tax receivable position of an operating subsidiary recognized in a prior period.
