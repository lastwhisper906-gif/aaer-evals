# FLEX MD&A — 0001104659-15-005354


## mdna

[0001104659-15-005354:mdna:1]
[same as prior period, unchanged from 0001104659-14-075227:mdna:1]

[0001104659-15-005354:mdna:2]
[same as prior period, unchanged from 0001104659-14-075227:mdna:2]

[0001104659-15-005354:mdna:3]
[same as prior period, unchanged from 0001104659-14-075227:mdna:3]

[0001104659-15-005354:mdna:4]
[same as prior period, unchanged from 0001104659-14-075227:mdna:4]

[0001104659-15-005354:mdna:5]
[same as prior period, unchanged from 0001104659-14-075227:mdna:5]

[0001104659-15-005354:mdna:6]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized, more demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0001104659-15-005354:mdna:7]
[same as prior period, unchanged from 0001104659-14-075227:mdna:7]

[0001104659-15-005354:mdna:8]
[same as prior period, unchanged from 0001104659-14-075227:mdna:8]

[0001104659-15-005354:mdna:9]
We are one of the world’s largest providers of global supply chain solutions, with revenues of $20.2 billion for the nine-month period ended December 31, 2014 and $26.1 billion in fiscal year 2014.  We have established an extensive network of manufacturing facilities in the world’s major electronics markets (Asia, the Americas and Europe) in order to serve the growing outsourcing needs of both multinational and regional OEMs. We design, build, ship and service electronics products for our customers through a network of facilities in approximately 30 countries across four continents.  As of December 31, 2014, our total manufacturing capacity was approximately 25.0 million square feet.  The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0001104659-15-005354:mdna:10]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |  |
| Net sales: |  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |  |
|  |  | (In thousands) |  | (In thousands) |  |
| China |  | $ | 2,636,663 |  | 38 | % | $ | 3,130,580 |  | 44 | % | $ | 7,663,630 |  | 38 | % | $ | 7,779,161 |  | 40 | % |
| Mexico |  | 909,767 |  | 13 | % | 914,283 |  | 13 | % | 2,635,704 |  | 13 | % | 2,691,508 |  | 14 | % |
| U.S. |  | 779,607 |  | 11 | % | 773,772 |  | 11 | % | 2,224,063 |  | 11 | % | 2,120,904 |  | 11 | % |
| Brazil |  | 749,261 |  | 11 | % | 460,736 |  | 6 | % | 1,891,292 |  | 9 | % | 1,180,285 |  | 6 | % |
| Malaysia |  | 624,239 |  | 9 | % | 542,877 |  | 8 | % | 1,726,200 |  | 9 | % | 1,640,567 |  | 8 | % |
| Other |  | 1,325,517 |  | 18 | % | 1,361,194 |  | 18 | % | 4,055,427 |  | 20 | % | 3,972,248 |  | 21 | % |
|  |  | $ | 7,025,054 |  |  |  | $ | 7,183,442 |  |  |  | $ | 20,196,316 |  |  |  | $ | 19,384,673 |  |  |  |

[0001104659-15-005354:mdna:11]
|  |  | As of |  | As of |  |
| Property and equipment, net: |  | December 31, 2014 |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| China |  | $ | 785,650 |  | 37 | % | $ | 941,850 |  | 41 | % |
| U.S. |  | 323,041 |  | 15 | % | 362,199 |  | 16 | % |
| Mexico |  | 292,353 |  | 14 | % | 326,287 |  | 14 | % |
| Malaysia |  | 158,629 |  | 8 | % | 153,194 |  | 7 | % |
| Brazil |  | 102,632 |  | 5 | % | 88,867 |  | 4 | % |
| Other |  | 452,376 |  | 21 | % | 416,259 |  | 18 | % |
|  |  | $ | 2,114,681 |  |  |  | $ | 2,288,656 |  |  |  |

[0001104659-15-005354:mdna:12]
[same as prior period, unchanged from 0001104659-14-075227:mdna:12]

[0001104659-15-005354:mdna:13]
[same as prior period, unchanged from 0001104659-14-075227:mdna:13]

[0001104659-15-005354:mdna:14]
[same as prior period, unchanged from 0001104659-14-075227:mdna:14]

[0001104659-15-005354:mdna:15]
[same as prior period, unchanged from 0001104659-14-075227:mdna:15]

[0001104659-15-005354:mdna:16]
[same as prior period, unchanged from 0001104659-14-075227:mdna:16]

[0001104659-15-005354:mdna:17]
[same as prior period, unchanged from 0001104659-14-075227:mdna:17]

[0001104659-15-005354:mdna:18]
[same as prior period, unchanged from 0001104659-14-075227:mdna:18]

[0001104659-15-005354:mdna:19]
[same as prior period, unchanged from 0001104659-14-075227:mdna:19]

[0001104659-15-005354:mdna:20]
[same as prior period, unchanged from 0001104659-14-075227:mdna:20]

[0001104659-15-005354:mdna:21]
[same as prior period, unchanged from 0001104659-14-075227:mdna:21]

[0001104659-15-005354:mdna:22]
[same as prior period, unchanged from 0001104659-14-075227:mdna:22]

[0001104659-15-005354:mdna:23]
[same as prior period, unchanged from 0001104659-14-075227:mdna:23]

[0001104659-15-005354:mdna:24]
[same as prior period, unchanged from 0001104659-14-075227:mdna:24]

[0001104659-15-005354:mdna:25]
[same as prior period, unchanged from 0001104659-14-075227:mdna:25]

[0001104659-15-005354:mdna:26]
[same as prior period, unchanged from 0001104659-14-075227:mdna:26]

[0001104659-15-005354:mdna:27]
[same as prior period, unchanged from 0001104659-14-075227:mdna:27]

[0001104659-15-005354:mdna:28]
[same as prior period, unchanged from 0001104659-14-075227:mdna:28]

[0001104659-15-005354:mdna:29]
[same as prior period, unchanged from 0001104659-14-075227:mdna:29]

[0001104659-15-005354:mdna:30]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |  |
| Net sales |  | 100.0 | % | 100.0 | % | 100.0 | % | 100.0 | % |
| Cost of sales |  | 94.2 |  | 94.5 |  | 94.2 |  | 94.4 |  |
| Gross profit |  | 5.8 |  | 5.5 |  | 5.8 |  | 5.6 |  |
| Selling, general and administrative expenses |  | 3.1 |  | 3.1 |  | 3.1 |  | 3.4 |  |
| Intangible amortization |  | 0.1 |  | 0.1 |  | 0.1 |  | 0.1 |  |
| Interest and other, net |  | 0.1 |  | 0.3 |  | 0.2 |  | 0.2 |  |
| Other charges (income), net |  | 0.1 |  | (0.1 | ) | (0.2 | ) | — |  |
| Income before income taxes |  | 2.4 |  | 2.1 |  | 2.6 |  | 1.9 |  |
| Provision for income taxes |  | 0.3 |  | 0.1 |  | 0.2 |  | 0.1 |  |
| Net income |  | 2.1 | % | 2.0 | % | 2.4 | % | 1.8 | % |

[0001104659-15-005354:mdna:31]
[same as prior period, unchanged from 0001104659-14-075227:mdna:31]

[0001104659-15-005354:mdna:32]
[same as prior period, unchanged from 0001104659-14-075227:mdna:32]

[0001104659-15-005354:mdna:33]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |  |
| Business groups: |  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |  |
|  |  | (In thousands) |  | (In thousands) |  |
| Integrated Network Solutions |  | $ | 2,435,008 |  | 35 | % | $ | 2,597,727 |  | 36 | % | $ | 7,346,402 |  | 36 | % | $ | 7,717,400 |  | 40 | % |
| Consumer Technology Group |  | 2,570,419 |  | 37 | % | 2,829,520 |  | 39 | % | 6,871,997 |  | 34 | % | 6,473,499 |  | 33 | % |
| Industrial & Emerging Industries |  | 1,112,666 |  | 16 | % | 933,020 |  | 13 | % | 3,349,885 |  | 17 | % | 2,779,226 |  | 14 | % |
| High Reliability Solutions |  | 906,961 |  | 12 | % | 823,175 |  | 12 | % | 2,628,032 |  | 13 | % | 2,414,548 |  | 13 | % |
|  |  | $ | 7,025,054 |  |  |  | $ | 7,183,442 |  |  |  | $ | 20,196,316 |  |  |  | $ | 19,384,673 |  |  |  |

[0001104659-15-005354:mdna:34]
Net sales during the three-month period ended December 31, 2014 totaled $7.0 billion, representing a decrease of approximately $0.2 billion, or 2.2% from $7.2 billion during the three-month period ended December 31, 2013. The modest decline in net sales was primarily due to $0.3 billion and $0.2 billion decreases in our CTG and INS business groups, respectively due to broad softness in our computing and mobile devices business as well as our telecom businesses and certain targeted exits with customers in our connected home business. These decreases were offset by a $0.2 billion increase in our IEI business group, mainly attributable to an increase in our household appliances and our energy businesses, and a $0.1 billion increase in our HRS business group, attributable to higher sales to our automotive and medical customers.  Net sales decreased by $0.5 billion to $3.5 billion in Asia, offset by an increase of $0.2 billion to $2.4 billion in the Americas and an increase of $0.1 billion to $1.2 billion in Europe.

[0001104659-15-005354:mdna:35]
Net sales during the nine-month period ended December 31, 2014 totaled $20.2 billion, representing an increase of approximately $0.8 billion, or 4.2% from $19.4 billion during the nine month period ended December 31, 2013.  Revenue increased across all of our business groups, except for INS, which experienced a marginal decrease.  The increase in revenue from our IEI business group is primarily attributable to a broad increase across product categories, most notably in our energy and our household appliances businesses. The increased revenue from our HRS business group is primarily due to a higher demand from our medical customers, and higher sales to our automotive customers as a result of an increased use of electronics throughout vehicles in areas such as in-car connectivity, LED lighting, and power management.  The increased revenue from our CTG business group is primarily as a result of our acquisition of certain manufacturing operations from Google’s Motorola Mobility LLC (Motorola) during the first quarter of fiscal 2014 and the business ramping up during the mid to latter part of fiscal 2014. These increases were offset by a decrease in revenue in our INS business group amounting to $0.4 billion for the nine-month period ended December 31, 2014 primarily attributable to broad softness in our telecom businesses coupled with certain targeted exits with customers in our connected home business. Net sales increased $0.7 billion to $6.7 billion in the Americas and $0.2 billion to $3.3 billion in Europe, respectively. These increases were offset by a decrease of $0.1 billion to $10.1 billion in Asia.

[0001104659-15-005354:mdna:36]
Our ten largest customers accounted for approximately 51% of net sales for both the three month and the nine-month periods ended December 31, 2014, respectively. Motorola (including its parent Google up to when Motorola was acquired by Lenovo and including net sales from Lenovo thereafter) accounted for more than 10% of net sales during the three-month and nine-month periods ended December 31, 2014. Our ten largest customers during the three-month and nine-month periods ended December 31, 2013 accounted for approximately 54% and 52% of net sales, respectively. Motorola (including its parent Google) accounted for more than 10% of net sales during the three-month and nine-month periods ended December 31, 2013.

[0001104659-15-005354:mdna:37]
[same as prior period, unchanged from 0001104659-14-075227:mdna:39]

[0001104659-15-005354:mdna:38]
[same as prior period, unchanged from 0001104659-14-075227:mdna:40]

[0001104659-15-005354:mdna:39]
Gross profit during the three-month period ended December 31, 2014 increased $10.0 million to $408.7 million, or 5.8% of net sales from $398.6 million, or 5.5% of net sales, during the three-month period ended December 31, 2013. Gross profit during the nine-month period ended December 31, 2014 increased $88.4 million to $1.2 billion, or 5.8% of net sales from $1.1 billion, or 5.6% of net sales, during the nine-month period ended December 31, 2013.  Gross margins improved 30 basis points and 20 basis points in the three-month and nine-month periods ended December 31, 2014 compared to that of the three-month and nine-month periods ended December 31, 2013 primarily as a result of an improved cost structure following our restructuring activities completed in fiscal year 2014 coupled with increased revenues and favorable product mix from our higher margin business groups such as IEI and HRS.

[0001104659-15-005354:mdna:40]
[same as prior period, unchanged from 0001104659-14-075227:mdna:42]

[0001104659-15-005354:mdna:41]
Selling, general and administrative expenses (“SG&A”) amounted to $216.0 million during the three-month period ended December 31, 2014, decreasing $8.6 million from $224.6 million during the three-month period ended December 31, 2013, however staying consistent at 3.1% of net sales. SG&A was $629.9 million, or 3.1% of net sales, during the nine-month period ended December 31, 2014, decreasing $36.8 million from $666.7 million, or 3.4% of net sales, during the nine-month period ended December 31, 2013.  Our SG&A expenses decreased in the current year periods, both in dollars and as a percentage of revenue, primarily as a result of certain cost reduction and rationalization measures that we undertook in the prior fiscal year.

[0001104659-15-005354:mdna:42]
[same as prior period, unchanged from 0001104659-14-075227:mdna:44]

[0001104659-15-005354:mdna:43]
Amortization of intangible assets increased by $2.5 million during the three-month period ended December 31, 2014 to $8.0 million from $5.6 million for the three-month period ended December 31, 2013. It also increased by $1.7 million during the nine-month period ended December 31, 2014 to $23.2 million from $21.5 million for the nine-month period ended December 31, 2013. The increase is primarily due to incremental amortization expenses on intangible assets relating to our acquisitions completed during the latter part of fiscal 2014 and during fiscal 2015, as well as the purchase of certain technology rights during fiscal 2015 as further discussed in note 2 to the condensed consolidated financial statements.

[0001104659-15-005354:mdna:44]
[same as prior period, unchanged from 0001104659-14-075227:mdna:47]

[0001104659-15-005354:mdna:45]
Interest and other, net was $9.0 million during the three-month period ended December 31, 2014 compared to $18.3 million during the three-month period ended December 31, 2013. The decrease in interest and other, net of $9.3 million was primarily due to an increase in foreign currency gains in the current period relating to the Chinese renminbi (“RMB”) and favorable impact from certain balance sheet positions that are denominated in currencies other than the functional currency of the underlying entity.

[0001104659-15-005354:mdna:46]
Interest and other, net was $40.2 million during the nine-month period ended December 31, 2014 compared to $45.5 million during the nine-month period ended December 31, 2013. The decrease in interest and other, net of $5.3 million was primarily due to a gain associated with an equity method investment as described above, foreign currency gains relating to the Chinese RMB, and a decrease in interest expense as a result of refinancing of certain debt facilities during the latter part of last year.

[0001104659-15-005354:mdna:47]
[same as prior period, unchanged from 0001104659-14-075227:mdna:50]

[0001104659-15-005354:mdna:48]
[same as prior period, unchanged from 0001104659-14-075227:mdna:51]

[0001104659-15-005354:mdna:49]
Other income, net was $41.5 million during the nine-month period ended December 31, 2014 principally as a result of the reversal of a contractual obligation with a certain customer recognized during the fourth quarter of fiscal 2014 in the amount of $55.0 million.  We executed an amendment to the customer contract during the first quarter of fiscal year 2015 which relieved us of this contractual commitment.  This was partially offset by an $11.0 million loss in connection with the disposition of a manufacturing facility in Western Europe and the write-off the notes receivable discussed above.

[0001104659-15-005354:mdna:50]
During the nine-month period ended December 31, 2013, we recognized a loss of $7.1 million relating to the exercise of a warrant to purchase shares of a certain supplier and sale of the underlying shares for total proceeds of $67.3 million, which was partially off-set by the gain on sale of certain investments discussed above.

[0001104659-15-005354:mdna:51]
[same as prior period, unchanged from 0001104659-14-075227:mdna:55]

[0001104659-15-005354:mdna:52]
[same as prior period, unchanged from 0001104659-14-075227:mdna:56]

[0001104659-15-005354:mdna:53]
[same as prior period, unchanged from 0001104659-14-075227:mdna:57]

[0001104659-15-005354:mdna:54]
The consolidated effective tax rate was 10.3% and 9.5% for the three and nine-month periods ended December 31, 2014, respectively, and 5.6% for both the three and nine-month periods ended December 31, 2013, respectively.  The consolidated effective tax rate varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions, operating loss carryforwards, income tax credits, previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. We generate most of our revenues and profits from operations outside of Singapore. The effective tax rate for the nine-month period ended December 31, 2014 is higher than the effective tax rate for the nine-month period ended December 31, 2013 primarily due to higher relative earnings in different jurisdictions with higher effective tax rates.

[0001104659-15-005354:mdna:55]
[same as prior period, unchanged from 0001104659-14-075227:mdna:59]

[0001104659-15-005354:mdna:56]
As of December 31, 2014, we had cash and cash equivalents of approximately $1.7 billion and bank and other borrowings of approximately $2.1 billion. We also have a $1.5 billion revolving credit facility that expires in March 2019, under which there were no borrowings outstanding as of the end of the quarter.  As of December 31, 2014, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0001104659-15-005354:mdna:57]
Cash provided by operating activities was $669.4 million during the nine-month period ended December 31, 2014. This resulted primarily from $465.7 million of net income for the period plus $404.3 million of non-cash charges such as depreciation, amortization, and other impairment charges, offset by $200.5 million from changes in our operating assets and liabilities, which was mainly related to reductions in customer deposits that were received in prior periods to support increased working capital requirements in those periods.

[0001104659-15-005354:mdna:58]
[same as prior period, unchanged from 0001104659-14-075227:mdna:63]

[0001104659-15-005354:mdna:59]
|  |  | Three-Month Periods Ended |  |
|  |  | December 31, 2014 |  | September 26, 2014 |  | June 27, 2014 |  | March 31, 2014 |  | December 31, 2013 |  |
| Days in trade accounts receivable |  | 39 days |  | 44 days |  | 45 days |  | 42 days |  | 38 days |  |
| Days in inventory |  | 50 days |  | 53 days |  | 52 days |  | 54 days |  | 53 days |  |
| Days in accounts payable |  | 66 days |  | 70 days |  | 69 days |  | 70 days |  | 68 days |  |
| Cash conversion cycle |  | 23 days |  | 27 days |  | 28 days |  | 26 days |  | 23 days |  |

[0001104659-15-005354:mdna:60]
Days in trade accounts receivable was calculated as average accounts receivable for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended December 31, 2014, days in trade accounts receivable increased by 1 day compared to the three-month period ended December 31, 2013 largely due to timing of invoicing customers during the current period.  Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $674.6 million, $426.1 million, $463.1 million, $470.9 million and $528.8 million for the quarters ended December 31, 2014, September 26, 2014, June 27, 2014, March 31, 2014 and December 31, 2013, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 9 to the condensed consolidated financial statements.

[0001104659-15-005354:mdna:61]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day.  Days in inventory decreased by 3 days compared to the three-month period ended December 31, 2013 primarily as a result of a decrease in inventory due to higher-than-expected seasonal demand.

[0001104659-15-005354:mdna:62]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable decreased by 2 days during the three-month period ended December 31, 2014, compared to the three-month period ended December 31, 2013 primarily due to timing of payments.

[0001104659-15-005354:mdna:63]
Our cash conversion cycle was calculated as the sum of days of inventory and days of accounts receivables outstanding less days payable outstanding.  Our cash conversion cycle remained constant at 23 days for both three-month periods ended December 31 2014 and December 31, 2013, respectively, due to the factors for each of the components in the calculation discussed above.

[0001104659-15-005354:mdna:64]
Cash used in investing activities amounted to $234.0 million during the nine-month period ended December 31, 2014.  This resulted primarily from $255.0 million in gross capital expenditures for property and equipment to support certain programs, offset by $90.6 million of proceeds from the sale of certain buildings and machinery and equipment.  We also paid $52.6 million for the acquisition of four businesses completed during the nine-month period ended December 31, 2014.  Other investing activities also includes an additional $18.4 million from the sale of assets originally purchased on behalf of a customer and financed by a third party banking institution as well as $15.7 million paid for the purchase of certain technology rights as further discussed in note 2 to the condensed consolidated financial statements.

[0001104659-15-005354:mdna:65]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the nine-month period ended December 31, 2014 was $505.0 million compared to $657.2 million for the nine-month period ended December 31, 2013. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities.  Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0001104659-15-005354:mdna:66]
|  |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2014 |  | December 31, 2013 |  |
|  |  | (In thousands) |  |
| Net cash provided by operating activities |  | $ | 669,424 |  | $ | 1,118,307 |  |
| Purchases of property and equipment |  | (254,970 | ) | (526,026 | ) |
| Proceeds from the disposition of property and equipment |  | 90,576 |  | 64,873 |  |
| Free cash flow |  | $ | 505,030 |  | $ | 657,154 |  |

[0001104659-15-005354:mdna:67]
Cash used in financing activities was $324.4 million during the nine-month period ended December 31, 2014, which was primarily the result of cash paid for the repurchase of our ordinary shares in the amount of $290.8 million, $22.8 million of cash paid to a third party banking institution for certain assets sold on behalf of a customer, net repayment of debt in the amount of $16.8 million and $7.4 million of cash paid for contingent consideration related to our acquisition of Saturn Electronics and Engineering Inc. The aforementioned cash outflows were partially offset by proceeds from the issuance of our shares for option exercises amounting to $12.3 million.

[0001104659-15-005354:mdna:68]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of December 31, 2014 and March 31, 2014, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore.  Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $779.0 million as of March 31, 2014). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0001104659-15-005354:mdna:69]
[same as prior period, unchanged from 0001104659-14-075227:mdna:74]

[0001104659-15-005354:mdna:70]
[same as prior period, unchanged from 0001104659-14-075227:mdna:75]

[0001104659-15-005354:mdna:71]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0001104659-15-005354:mdna:72]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 28, 2014.  During the nine-month period ended December 31, 2014, we paid $290.8 million to repurchase shares (under the current and prior repurchase plans) at an average price of $10.34 per share.  As of December 31, 2014, shares in the aggregate amount of $373.4 million were available to be repurchased under the current plan.

[0001104659-15-005354:mdna:73]
[same as prior period, unchanged from 0001104659-14-075227:mdna:78]

[0001104659-15-005354:mdna:74]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2014.  There have been no material changes in our contractual obligations and commitments since March 31, 2014, except for the reversal of a contractual obligation during the first quarter of fiscal 2015 with a certain customer that was recognized during the fourth quarter of fiscal 2014 in the amount of $55.0 million discussed in note 6 to the condensed consolidated financial statements.

[0001104659-15-005354:mdna:75]
[same as prior period, unchanged from 0001104659-14-075227:mdna:82]

[0001104659-15-005354:mdna:76]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of December 31, 2014 and March 31, 2014, the fair values of our deferred purchase price receivable were approximately $674.6 million and $470.9 million, respectively. As of December 31, 2014 and March 31, 2014, the outstanding balances on receivables sold for cash were $1.2 billion and $1.1 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information see note 9 of our notes to the condensed consolidated financial statements.
