# FLEX notes — 0001104659-15-005354


## flex:InterestAndOtherNetTextBlock

[0001104659-15-005354:notes:1]
5.  INTEREST AND OTHER, NET

[0001104659-15-005354:notes:2]
During the three-month and nine-month periods ended December 31, 2014, the Company recognized interest expense of $19.9 million and $57.5 million, respectively, on its debt obligations outstanding during the period.  During the three-month and nine-month periods ended December 31, 2013, the Company recognized interest expense of $19.9 million and $60.4 million, respectively.

[0001104659-15-005354:notes:3]
The weighted average interest rates for the Company’s long-term debt was 3.2% for both nine-month periods ended December 31, 2014 and December 31, 2013, respectively.

[0001104659-15-005354:notes:4]
During the three-month and nine-month periods ended December 31, 2014, the Company recognized interest income of $4.7 million and $14.7 million, respectively.  During the three-month and nine-month periods ended December 31, 2013, the Company recognized interest income of $4.7 million and $11.9 million, respectively.

[0001104659-15-005354:notes:5]
During the three-month and nine-month periods ended December 31, 2014, the Company recognized gains on foreign exchange transactions of $8.5 million and $13.9 million, respectively.  During the three-month and nine-month periods ended December 31, 2013, the Company recognized gains on foreign exchange transactions of $3.3 million and $11.3 million, respectively.


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0001104659-15-005354:notes:6]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2014 |  | December 31,2013 |  | December 31, 2014 |  | December 31, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 426,057 |  | $ | 558,311 |  | $ | 470,908 |  | $ | 412,357 |  |
| Transfers of receivables |  | 1,139,744 |  | 1,066,512 |  | 2,639,526 |  | 2,933,053 |  |
| Collections |  | (891,159 | ) | (1,095,993 | ) | (2,435,792 | ) | (2,816,580 | ) |
| Ending balance |  | $ | 674,642 |  | $ | 528,830 |  | $ | 674,642 |  | $ | 528,830 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001104659-15-005354:notes:7]
[same as prior period, unchanged from 0001104659-14-075227:notes:118]

[0001104659-15-005354:notes:8]
Flextronics International Ltd. (“Parent”) has two tranches of Notes of $500 million each outstanding, which mature on February 15, 2020 and February 15, 2023, respectively. These Notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company’s 100% owned subsidiaries (the “guarantor subsidiaries”). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade.

[0001104659-15-005354:notes:9]
[same as prior period, unchanged from 0001104659-14-075227:notes:120]

[0001104659-15-005354:notes:10]
Condensed Consolidating Balance Sheets as of December 31, 2014

[0001104659-15-005354:notes:11]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 606,521 |  | $ | 190,162 |  | $ | 910,538 |  | $ | — |  | $ | 1,707,221 |  |
| Accounts receivable |  | — |  | 1,234,620 |  | 1,215,153 |  | — |  | 2,449,773 |  |
| Inventories |  | — |  | 1,723,649 |  | 1,835,991 |  | — |  | 3,559,640 |  |
| Inter company receivable |  | 10,447,323 |  | 9,136,582 |  | 10,145,241 |  | (29,729,146 | ) | — |  |
| Other current assets |  | 3,966 |  | 179,289 |  | 1,233,331 |  | — |  | 1,416,586 |  |
| Total current assets |  | 11,057,810 |  | 12,464,302 |  | 15,340,254 |  | (29,729,146 | ) | 9,133,220 |  |
| Property and equipment, net |  | — |  | 476,467 |  | 1,638,214 |  | — |  | 2,114,681 |  |
| Goodwill and other intangible assets, net |  | 550 |  | 60,375 |  | 356,607 |  | — |  | 417,532 |  |
| Other assets |  | 2,205,450 |  | 115,622 |  | 2,179,574 |  | (4,075,606 | ) | 425,040 |  |
| Investment in subsidiaries |  | 1,435,834 |  | 1,470,104 |  | 16,170,993 |  | (19,076,931 | ) | — |  |
| Total assets |  | $ | 14,699,644 |  | $ | 14,586,870 |  | $ | 35,685,642 |  | $ | (52,881,683 | ) | $ | 12,090,473 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 40,000 |  | $ | 8 |  | $ | 5,166 |  | $ | — |  | $ | 45,174 |  |
| Accounts payable |  | — |  | 1,835,874 |  | 3,014,641 |  | — |  | 4,850,515 |  |
| Accrued payroll |  | — |  | 102,492 |  | 243,047 |  | — |  | 345,539 |  |
| Inter company payable |  | 10,194,546 |  | 11,824,715 |  | 7,709,885 |  | (29,729,146 | ) | — |  |
| Other current liabilities |  | 37,346 |  | 819,820 |  | 1,110,328 |  | — |  | 1,967,494 |  |
| Total current liabilities |  | 10,271,892 |  | 14,582,909 |  | 12,083,067 |  | (29,729,146 | ) | 7,208,722 |  |
| Long term liabilities |  | 2,076,660 |  | 2,090,365 |  | 2,401,487 |  | (4,075,606 | ) | 2,492,906 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) |  | 2,351,092 |  | (2,086,404 | ) | 21,163,335 |  | (19,076,931 | ) | 2,351,092 |  |
| Noncontrolling interests |  | — |  | — |  | 37,753 |  | — |  | 37,753 |  |
| Total shareholders’ equity (deficit) |  | 2,351,092 |  | (2,086,404 | ) | 21,201,088 |  | (19,076,931 | ) | 2,388,845 |  |
| Total liabilities and shareholders’ equity |  | $ | 14,699,644 |  | $ | 14,586,870 |  | $ | 35,685,642 |  | $ | (52,881,683 | ) | $ | 12,090,473 |  |

[0001104659-15-005354:notes:12]
[same as prior period, unchanged from 0001104659-14-075227:notes:123]

[0001104659-15-005354:notes:13]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 638,714 |  | $ | 210,462 |  | $ | 744,552 |  | $ | — |  | $ | 1,593,728 |  |
| Accounts receivable |  | — |  | 1,229,243 |  | 1,468,742 |  | — |  | 2,697,985 |  |
| Inventories |  | — |  | 1,705,872 |  | 1,893,136 |  | — |  | 3,599,008 |  |
| Inter company receivable |  | 8,867,520 |  | 6,963,002 |  | 9,528,158 |  | (25,358,680 | ) | — |  |
| Other current assets |  | 246 |  | 383,590 |  | 1,125,769 |  | — |  | 1,509,605 |  |
| Total current assets |  | 9,506,480 |  | 10,492,169 |  | 14,760,357 |  | (25,358,680 | ) | 9,400,326 |  |
| Property and equipment, net |  | — |  | 487,166 |  | 1,801,490 |  | — |  | 2,288,656 |  |
| Goodwill and other intangible assets, net |  | 775 |  | 46,916 |  | 329,527 |  | — |  | 377,218 |  |
| Other assets |  | 2,585,169 |  | 120,739 |  | 4,692,156 |  | (6,964,114 | ) | 433,950 |  |
| Investment in subsidiaries |  | 3,350,690 |  | 763,780 |  | 15,994,981 |  | (20,109,451 | ) | — |  |
| Total assets |  | $ | 15,443,114 |  | $ | 11,910,770 |  | $ | 37,578,511 |  | $ | (52,432,245 | ) | $ | 12,500,150 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 32,500 |  | $ | 60 |  | $ | 15 |  | $ | — |  | $ | 32,575 |  |
| Accounts payable |  | — |  | 1,614,384 |  | 3,133,395 |  | — |  | 4,747,779 |  |
| Accrued payroll |  | — |  | 106,046 |  | 248,843 |  | — |  | 354,889 |  |
| Inter company payable |  | 8,607,486 |  | 10,126,691 |  | 6,624,503 |  | (25,358,680 | ) | — |  |
| Other current liabilities |  | 24,868 |  | 756,767 |  | 1,739,809 |  | — |  | 2,521,444 |  |
| Total current liabilities |  | 8,664,854 |  | 12,603,948 |  | 11,746,565 |  | (25,358,680 | ) | 7,656,687 |  |
| Long term liabilities |  | 4,615,210 |  | 2,140,985 |  | 2,849,703 |  | (6,964,114 | ) | 2,641,784 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) |  | 2,163,050 |  | (2,834,163 | ) | 22,943,614 |  | (20,109,451 | ) | 2,163,050 |  |
| Noncontrolling interest |  | — |  | — |  | 38,629 |  | — |  | 38,629 |  |
| Total shareholders’ equity (deficit) |  | 2,163,050 |  | (2,834,163 | ) | 22,982,243 |  | (20,109,451 | ) | 2,201,679 |  |
| Total liabilities and shareholders’ equity |  | $ | 15,443,114 |  | $ | 11,910,770 |  | $ | 37,578,511 |  | $ | (52,432,245 | ) | $ | 12,500,150 |  |

[0001104659-15-005354:notes:14]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended December 31, 2014

[0001104659-15-005354:notes:15]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 4,710,233 |  | $ | 5,484,088 |  | $ | (3,169,267 | ) | $ | 7,025,054 |  |
| Cost of sales |  | — |  | 4,317,463 |  | 5,468,201 |  | (3,169,267 | ) | 6,616,397 |  |
| Gross profit |  | — |  | 392,770 |  | 15,887 |  | — |  | 408,657 |  |
| Selling, general and administrative expenses |  | — |  | 57,644 |  | 158,349 |  | — |  | 215,993 |  |
| Intangible amortization |  | 75 |  | 708 |  | 7,262 |  | — |  | 8,045 |  |
| Interest and other, net |  | 27,876 |  | 224,280 |  | (238,054 | ) | — |  | 14,102 |  |
| Income (loss) from continuing operations before income taxes |  | (27,951 | ) | 110,138 |  | 88,330 |  | — |  | 170,517 |  |
| Provision for income taxes |  | — |  | (5,737 | ) | 23,355 |  | — |  | 17,618 |  |
| Equity in earnings in subsidiaries |  | 180,850 |  | (58,855 | ) | 60,603 |  | (182,598 | ) | — |  |
| Net income (loss) |  | $ | 152,899 |  | $ | 57,020 |  | $ | 125,578 |  | $ | (182,598 | ) | $ | 152,899 |  |

[0001104659-15-005354:notes:16]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended December 31, 2013

[0001104659-15-005354:notes:17]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 5,023,965 |  | $ | 6,735,557 |  | $ | (4,576,080 | ) | $ | 7,183,442 |  |
| Cost of sales |  | — |  | 4,661,230 |  | 6,699,673 |  | (4,576,080 | ) | 6,784,823 |  |
| Gross profit |  | — |  | 362,735 |  | 35,884 |  | — |  | 398,619 |  |
| Selling, general and administrative expenses |  | — |  | 52,963 |  | 171,613 |  | — |  | 224,576 |  |
| Intangible amortization |  | 75 |  | 1,018 |  | 4,482 |  | — |  | 5,575 |  |
| Interest and other, net |  | (277,297 | ) | 353,773 |  | (61,733 | ) | — |  | 14,743 |  |
| Income (loss) from continuing operations before income taxes |  | 277,222 |  | (45,019 | ) | (78,478 | ) | — |  | 153,725 |  |
| Provision for income taxes |  | 26 |  | 3,355 |  | 5,187 |  | — |  | 8,568 |  |
| Equity in earnings in subsidiaries |  | (132,039 | ) | 20,728 |  | 53,320 |  | 57,991 |  | — |  |
| Net income (loss) |  | $ | 145,157 |  | $ | (27,646 | ) | $ | (30,345 | ) | $ | 57,991 |  | $ | 145,157 |  |

[0001104659-15-005354:notes:18]
Condensed Consolidating Statements of Operations for the Nine-Month Period Ended December 31, 2014

[0001104659-15-005354:notes:19]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 13,678,457 |  | $ | 15,509,537 |  | $ | (8,991,678 | ) | $ | 20,196,316 |  |
| Cost of sales |  | — |  | 12,615,600 |  | 15,405,871 |  | (8,991,678 | ) | 19,029,793 |  |
| Gross profit |  | — |  | 1,062,857 |  | 103,666 |  | — |  | 1,166,523 |  |
| Selling, general and administrative expenses |  | — |  | 169,663 |  | 460,197 |  | — |  | 629,860 |  |
| Intangible amortization |  | 225 |  | 1,936 |  | 21,067 |  | — |  | 23,228 |  |
| Interest and other, net |  | (24,933 | ) | 761,224 |  | (737,639 | ) | — |  | (1,348 | ) |
| Income from continuing operations before income taxes |  | 24,708 |  | 130,034 |  | 360,041 |  | — |  | 514,783 |  |
| Provision for income taxes |  | — |  | 9,053 |  | 40,041 |  | — |  | 49,094 |  |
| Equity in earnings in subsidiaries |  | 440,981 |  | (47,994 | ) | 147,182 |  | (540,169 | ) | — |  |
| Net income (loss) |  | $ | 465,689 |  | $ | 72,987 |  | $ | 467,182 |  | $ | (540,169 | ) | $ | 465,689 |  |

[0001104659-15-005354:notes:20]
Condensed Consolidating Statements of Operations for the Nine-Month Period Ended December 31, 2013

[0001104659-15-005354:notes:21]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net sales |  | $ | — |  | $ | 13,090,309 |  | $ | 16,317,600 |  | $ | (10,023,236 | ) | $ | 19,384,673 |  |
| Cost of sales |  | — |  | 12,025,135 |  | 16,304,697 |  | (10,023,236 | ) | 18,306,596 |  |
| Gross profit (loss) |  | — |  | 1,065,174 |  | 12,903 |  | — |  | 1,078,077 |  |
| Selling, general and administrative expenses |  | 800 |  | 171,411 |  | 494,484 |  | — |  | 666,695 |  |
| Intangible amortization |  | 225 |  | 3,055 |  | 18,215 |  | — |  | 21,495 |  |
| Interest and other, net |  | (489,834 | ) | 904,524 |  | (366,662 | ) | — |  | 48,028 |  |
| Income (loss) from continuing operations before income taxes |  | 488,809 |  | (13,816 | ) | (133,134 | ) | — |  | 341,859 |  |
| Provision for income taxes |  | 37 |  | 9,937 |  | 9,266 |  | — |  | 19,240 |  |
| Equity in earnings in subsidiaries |  | (166,153 | ) | (76,225 | ) | 84,402 |  | 157,976 |  | — |  |
| Net income (loss) |  | $ | 322,619 |  | $ | (99,978 | ) | $ | (57,998 | ) | $ | 157,976 |  | $ | 322,619 |  |

[0001104659-15-005354:notes:22]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended December 31, 2014

[0001104659-15-005354:notes:23]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 152,899 |  | $ | 57,020 |  | $ | 125,578 |  | $ | (182,598 | ) | $ | 152,899 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (15,154 | ) | 42,655 |  | 37,167 |  | (79,822 | ) | (15,154 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | (22,797 | ) | (5,936 | ) | (22,797 | ) | 28,733 |  | (22,797 | ) |
| Comprehensive income (loss) |  | $ | 114,948 |  | $ | 93,739 |  | $ | 139,948 |  | $ | (233,687 | ) | $ | 114,948 |  |

[0001104659-15-005354:notes:24]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended December 31, 2013

[0001104659-15-005354:notes:25]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 145,157 |  | $ | (27,646 | ) | $ | (30,345 | ) | $ | 57,991 |  | $ | 145,157 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (13,960 | ) | (23,210 | ) | (28,137 | ) | 51,347 |  | (13,960 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | 1,097 |  | 1 |  | 1,097 |  | (1,098 | ) | 1,097 |  |
| Comprehensive income (loss) |  | $ | 132,294 |  | $ | (50,855 | ) | $ | (57,385 | ) | $ | 108,240 |  | $ | 132,294 |  |

[0001104659-15-005354:notes:26]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Nine-Month Period Ended December 31, 2014

[0001104659-15-005354:notes:27]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 465,689 |  | $ | 72,987 |  | $ | 467,182 |  | $ | (540,169 | ) | $ | 465,689 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (24,982 | ) | 134,273 |  | 108,504 |  | (242,777 | ) | (24,982 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | (14,505 | ) | (6,164 | ) | (14,505 | ) | 20,669 |  | (14,505 | ) |
| Comprehensive income (loss) |  | $ | 426,202 |  | $ | 201,096 |  | $ | 561,181 |  | $ | (762,277 | ) | $ | 426,202 |  |

[0001104659-15-005354:notes:28]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Nine-Month Period Ended December 31, 2013

[0001104659-15-005354:notes:29]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (in thousands) |  |
| Net income (loss) |  | $ | 322,619 |  | $ | (99,978 | ) | $ | (57,998 | ) | $ | 157,976 |  | $ | 322,619 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax |  | (43,457 | ) | (87,375 | ) | (94,550 | ) | 181,925 |  | (43,457 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax |  | 516 |  | 3,425 |  | 515 |  | (3,940 | ) | 516 |  |
| Comprehensive income (loss) |  | $ | 279,678 |  | $ | (183,928 | ) | $ | (152,033 | ) | $ | 335,961 |  | $ | 279,678 |  |

[0001104659-15-005354:notes:30]
Condensed Consolidating Statements of Cash Flows for the Nine-Month Period Ended December 31, 2014

[0001104659-15-005354:notes:31]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | (4,319 | ) | $ | 369,594 |  | $ | 304,149 |  | $ | — |  | 669,424 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  | — |  | (76,042 | ) | (88,340 | ) | (12 | ) | (164,394 | ) |
| Acquisition of businesses, net of cash acquired |  | — |  | (20,092 | ) | (32,547 | ) | — |  | (52,639 | ) |
| Proceeds from divesture of business, net of cash held in divested business |  | — |  | — |  | (5,493 | ) | — |  | (5,493 | ) |
| Investing cash flows from (to) affiliates |  | (1,163,617 | ) | (2,455,910 | ) | 805,143 |  | 2,814,384 |  | — |  |
| Other investing activities, net |  | (1,500 | ) | (10,597 | ) | 580 |  | — |  | (11,517 | ) |
| Net cash provided by (used in) investing activities |  | (1,165,117 | ) | (2,562,641 | ) | 679,343 |  | 2,814,372 |  | (234,043 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 223,000 |  | — |  | 11,523 |  | — |  | 234,523 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations |  | (245,500 | ) | (1,686 | ) | (4,151 | ) | — |  | (251,337 | ) |
| Payments for repurchases of ordinary shares |  | (290,752 | ) | — |  | — |  | — |  | (290,752 | ) |
| Net proceeds from issuance of ordinary shares |  | 12,341 |  | — |  | — |  | — |  | 12,341 |  |
| Financing cash flows from (to) affiliates |  | 1,575,271 |  | 2,180,326 |  | (941,225 | ) | (2,814,372 | ) | — |  |
| Other financing activities, net |  | — |  | — |  | (29,135 | ) | — |  | (29,135 | ) |
| Net cash provided by (used in) financing activities |  | 1,274,360 |  | 2,178,640 |  | (962,988 | ) | (2,814,372 | ) | (324,360 | ) |
| Effect of exchange rates on cash and cash equivalents |  | (137,117 | ) | (5,893 | ) | 145,482 |  | — |  | 2,472 |  |
| Net increase (decrease) in cash and cash equivalents |  | (32,193 | ) | (20,300 | ) | 165,986 |  | — |  | 113,493 |  |
| Cash and cash equivalents, beginning of period |  | 638,714 |  | 210,462 |  | 744,552 |  | — |  | 1,593,728 |  |
| Cash and cash equivalents, end of period |  | $ | 606,521 |  | $ | 190,162 |  | $ | 910,538 |  | $ | — |  | $ | 1,707,221 |  |

[0001104659-15-005354:notes:32]
Condensed Consolidating Statements of Cash Flows for the Nine-Month Period Ended December 31, 2013

[0001104659-15-005354:notes:33]
|  |  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | 477,036 |  | $ | (1,062,723 | ) | $ | 1,704,001 |  | $ | (7 | ) | $ | 1,118,307 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal |  | — |  | (184,907 | ) | (276,246 | ) | — |  | (461,153 | ) |
| Acquisition of businesses, net of cash acquired |  | — |  | (61,587 | ) | (176,444 | ) | — |  | (238,031 | ) |
| Proceeds from divestiture of business, net of cash held in divested business |  | — |  | — |  | 4,599 |  | — |  | 4,599 |  |
| Investing cash flows from (to) affiliates |  | (306,254 | ) | (307,423 | ) | (3,512,640 | ) | 4,126,317 |  | — |  |
| Other investing activities, net |  | — |  | (832 | ) | (11,235 | ) | — |  | (12,067 | ) |
| Net cash provided by (used in) investing activities |  | (306,254 | ) | (554,749 | ) | (3,971,966 | ) | 4,126,317 |  | (706,652 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 1,003,000 |  | 277 |  | 17 |  | — |  | 1,003,294 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations |  | (489,365 | ) | (1,068 | ) | (28,116 | ) | — |  | (518,549 | ) |
| Payments for early retirement of long-term debt |  | (503,423 | ) | (41,417 | ) | — |  | — |  | (544,840 | ) |
| Payments for repurchases of ordinary shares |  | (362,693 | ) | — |  | — |  | — |  | (362,693 | ) |
| Net proceeds from issuance of ordinary shares |  | 21,106 |  | — |  | — |  | — |  | 21,106 |  |
| Financing cash flows from (to) affiliates |  | (29,135 | ) | 1,537,804 |  | 2,617,641 |  | (4,126,310 | ) | — |  |
| Other financing activities, net |  | — |  | — |  | 46,298 |  | — |  | 46,298 |  |
| Net cash provided by (used in) financing activities |  | (360,510 | ) | 1,495,596 |  | 2,635,840 |  | (4,126,310 | ) | (355,384 | ) |
| Effect of exchange rates on cash and cash equivalents |  | 53,341 |  | 546 |  | (80,000 | ) | — |  | (26,113 | ) |
| Net decrease (increase) in cash and cash equivalents |  | (136,387 | ) | (121,330 | ) | 287,875 |  | — |  | 30,158 |  |
| Cash and cash equivalents, beginning of period |  | 740,515 |  | 226,372 |  | 620,200 |  | — |  | 1,587,087 |  |
| Cash and cash equivalents, end of period |  | $ | 604,128 |  | $ | 105,042 |  | $ | 908,075 |  | $ | — |  | $ | 1,617,245 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-15-005354:notes:34]
[same as prior period, unchanged from 0001104659-14-075227:notes:145]

[0001104659-15-005354:notes:35]
During the nine-month period ended December 31, 2014, the Company completed four acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company.  All of the acquired businesses expanded the Company’s capabilities in the medical devices market, particularly precision plastics.  The Company paid $51.4 million net of $5.9 million of cash held by the acquirees, and recorded an accrual of $4.5 million for contingent consideration relating to one of them.  The Company primarily acquired $28.9 million of current assets, $14.5 million of property and equipment, recorded goodwill and intangibles of $45.0 million, and assumed certain liabilities relating to payables and debt in connection with these acquisitions.  The results of operations were included in the Company’s consolidated financial results beginning on the date of these acquisitions. Pro-forma results of operations for these acquisitions have not been presented because the effects of the acquisitions were immaterial to the Company’s consolidated financial results for all periods presented.

[0001104659-15-005354:notes:36]
The Company is in the process of evaluating the fair value of the assets and liabilities related to business combinations completed during the recent periods. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisition.  Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the respective measurement periods.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001104659-15-005354:notes:37]
13.  COMMITMENTS AND CONTINGENCIES

[0001104659-15-005354:notes:38]
Litigation and other legal matters

[0001104659-15-005354:notes:39]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International, Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431).  The complaint asserts various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products.  The plaintiff seeks an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys’ fees and costs.  The plaintiff also seeks a jury trial.  On June 25, 2014, we filed motions for Demurrer and to Strike asking the court to dismiss the claims against us.  The court has scheduled a hearing on the motions for January 30, 2015.  Although the outcome of this matter is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of this matter, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements.

[0001104659-15-005354:notes:40]
During the nine-month period ended December 31, 2014, one of our non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties.  The Company believes there is no legal basis for the assessment and expects that any losses are remote.  The Company plans to vigorously defend itself through the administrative and judicial processes.

[0001104659-15-005354:notes:41]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001104659-15-005354:notes:42]
8.  ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001104659-15-005354:notes:43]
[same as prior period, unchanged from 0001104659-14-075227:notes:59]

[0001104659-15-005354:notes:44]
|  |  | Three-Month Periods Ended |  |
|  |  | December 31, 2014 |  | December 31, 2013 |  |
|  |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | (24,557 | ) | $ | (103,135 | ) | $ | (127,692 | ) | $ | (19,438 | ) | $ | (88,121 | ) | $ | (107,559 | ) |
| Other comprehensive gain (loss) before reclassifications |  | (29,287 | ) | (15,154 | ) | (44,441 | ) | 471 |  | (13,960 | ) | (13,489 | ) |
| Net losses reclassified from accumulated other comprehensive loss |  | 6,490 |  | — |  | 6,490 |  | 626 |  | — |  | 626 |  |
| Net current-period other comprehensive gain (loss) |  | (22,797 | ) | (15,154 | ) | (37,951 | ) | 1,097 |  | (13,960 | ) | (12,863 | ) |
| Ending balance |  | $ | (47,354 | ) | $ | (118,289 | ) | $ | (165,643 | ) | $ | (18,341 | ) | $ | (102,081 | ) | $ | (120,422 | ) |

[0001104659-15-005354:notes:45]
|  |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2014 |  | December 31, 2013 |  |
|  |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | (32,849 | ) | $ | (93,307 | ) | $ | (126,156 | ) | $ | (18,857 | ) | $ | (58,624 | ) | $ | (77,481 | ) |
| Other comprehensive gain (loss) before reclassifications |  | (31,252 | ) | (13,146 | ) | (44,398 | ) | 163 |  | (43,457 | ) | (43,294 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss |  | 16,747 |  | (11,836 | ) | 4,911 |  | 353 |  | — |  | 353 |  |
| Net current-period other comprehensive gain (loss) |  | (14,505 | ) | (24,982 | ) | (39,487 | ) | 516 |  | (43,457 | ) | (42,941 | ) |
| Ending balance |  | $ | (47,354 | ) | $ | (118,289 | ) | $ | (165,643 | ) | $ | (18,341 | ) | $ | (102,081 | ) | $ | (120,422 | ) |

[0001104659-15-005354:notes:46]
Net losses reclassified from accumulated other comprehensive loss during the nine-month period ended December 31, 2014 relating to derivative instruments and other includes $12.1 million attributable to the Company’s cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations.

[0001104659-15-005354:notes:47]
During the nine-month period ended December 31, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe.  This loss includes the settlement of unrealized losses of $4.2 million on an insignificant defined benefit plan associated with the disposed facility offset by the release of cumulative foreign currency translation gains of $9.3 million, both of which have been reclassified from accumulated other comprehensive loss during the period.  The loss on sale is included in other charges (income), net in the condensed consolidated statement of operations.

[0001104659-15-005354:notes:48]
Additionally, net gains reclassified from accumulated other comprehensive loss during the nine-month period ended December 31, 2014 includes $2.6 million in connection with cumulative translation gains related to the liquidation of a foreign entity, which is included in other charges (income), net in the condensed consolidated statement of operations.

[0001104659-15-005354:notes:49]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month and nine-month periods ended December 31, 2013, was recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-15-005354:notes:50]
7.  FINANCIAL INSTRUMENTS

[0001104659-15-005354:notes:51]
[same as prior period, unchanged from 0001104659-14-075227:notes:51]

[0001104659-15-005354:notes:52]
The Company enters into forward contracts and foreign currency swap contracts to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions.  The Company hedges committed exposures and does not engage in speculative transactions.  As of December 31, 2014, the aggregate notional amount of the Company’s outstanding foreign currency forward and swap contracts was $5.4 billion as summarized below:

[0001104659-15-005354:notes:53]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |  |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |  |
|  |  | (In thousands) |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |
| CNY |  | 2,846,000 |  | — |  | $ | 457,372 |  | $ | — |  |
| HUF |  | 23,490,000 |  | — |  | 90,807 |  | — |  |
| MXN |  | 1,938,100 |  | — |  | 131,212 |  | — |  |
| MYR |  | 344,000 |  | — |  | 98,370 |  | — |  |
| Other |  | N/A |  | N/A |  | 128,625 |  | 8,530 |  |
|  |  |  |  |  |  | 906,386 |  | 8,530 |  |
| Other Forward/Swap Contracts |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  | 387,000 |  | — |  | 143,063 |  |
| CAD |  | 135,658 |  | 127,418 |  | 117,920 |  | 110,280 |  |
| CNY |  | 5,859,756 |  | 4,407,044 |  | 941,239 |  | 709,000 |  |
| EUR |  | 460,333 |  | 678,456 |  | 561,141 |  | 826,032 |  |
| GBP |  | 28,934 |  | 55,793 |  | 44,912 |  | 86,654 |  |
| HUF |  | 19,827,300 |  | 22,002,600 |  | 76,648 |  | 85,057 |  |
| JPY |  | 6,629,077 |  | 1,295,871 |  | 54,910 |  | 11,045 |  |
| MXN |  | 1,737,840 |  | 1,387,270 |  | 117,655 |  | 93,920 |  |
| MYR |  | 217,476 |  | 34,740 |  | 62,189 |  | 9,934 |  |
| SEK |  | 321,736 |  | 637,249 |  | 41,328 |  | 82,524 |  |
| Other |  | N/A |  | N/A |  | 167,369 |  | 134,384 |  |
|  |  |  |  |  |  | 2,185,311 |  | 2,291,893 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 3,091,697 |  | $ | 2,300,423 |  |

[0001104659-15-005354:notes:54]
As of December 31, 2014, the fair value of the Company’s short-term foreign currency contracts was not material and is included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards.  Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of December 31, 2014 and March 31, 2014, the Company also has included net deferred losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to the effective portion of changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses totaled $28.0 million as of December 31, 2014, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0001104659-15-005354:notes:55]
[same as prior period, unchanged from 0001104659-14-075227:notes:55]

[0001104659-15-005354:notes:56]
|  |  | Fair Values of Derivative Instruments |  |
|  |  | Asset Derivatives |  | Liability Derivatives |  |
|  |  |  |  | Fair Value |  |  |  | Fair Value |  |
|  |  | Balance SheetLocation |  | December 31,2014 |  | March 31,2014 |  | Balance SheetLocation |  | December31,2014 |  | March 31,2014 |  |
|  |  | (In thousands) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 469 |  | $ | 3,464 |  | Other current liabilities |  | $ | 28,677 |  | $ | 10,457 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | Other current assets |  | $ | 19,087 |  | $ | 4,722 |  | Other current liabilities |  | $ | 15,717 |  | $ | 6,949 |  |

[0001104659-15-005354:notes:57]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with a single counterparty.  The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets.  The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any period presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-15-005354:notes:58]
3.  SHARE-BASED COMPENSATION

[0001104659-15-005354:notes:59]
[same as prior period, unchanged from 0001104659-14-075227:notes:30]

[0001104659-15-005354:notes:60]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |  |
|  |  | (In thousands) |  |
| Cost of sales |  | $ | 2,083 |  | $ | 1,800 |  | $ | 5,562 |  | $ | 5,018 |  |
| Selling, general and administrative expenses |  | 12,136 |  | 11,311 |  | 31,259 |  | 25,399 |  |
| Total share-based compensation expense |  | $ | 14,219 |  | $ | 13,111 |  | $ | 36,821 |  | $ | 30,417 |  |

[0001104659-15-005354:notes:61]
Total unrecognized compensation expense related to share options is $0.2 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of 1.5 years. As of December 31, 2014, the number of options outstanding and exercisable was 17.3 million, respectively, both at a weighted-average exercise price of $7.87 per share.

[0001104659-15-005354:notes:62]
During the nine-month period ended December 31, 2014, the Company granted 6.4 million unvested share bonus awards at an average grant date price of $11.71 per share, under its 2010 Equity Incentive Plan.  Of this amount, approximately 1.0 million represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions.  The number of shares that ultimately will vest range from zero up to a maximum of 2.0 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met.  The average grant-date fair value of these awards was estimated to be $15.81 per share and was calculated using a Monte Carlo simulation.

[0001104659-15-005354:notes:63]
As of December 31, 2014, approximately 19.1 million unvested share bonus awards were outstanding, of which vesting for a targeted amount of 5.0 million is contingent primarily on meeting certain market conditions.  The number of shares that will ultimately be issued can range from zero to 9.7 million based on the achievement levels of the respective conditions.  During the nine-month period ended December 31, 2014, 0.3 million shares vested in connection with the remaining number of share bonus awards with market conditions granted in fiscal 2011, and 0.4 million shares vested in connection with half of the share bonus awards with market conditions granted in fiscal 2012.

[0001104659-15-005354:notes:64]
As of December 31, 2014, total unrecognized compensation expense related to unvested share bonus awards is $98.0 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of 2.6 years. Approximately $18.2 million of the total unrecognized compensation cost, net of estimated forfeitures, is related to awards whereby vesting is contingent on meeting certain market conditions.


## us-gaap:EarningsPerShareTextBlock

[0001104659-15-005354:notes:65]
4.  EARNINGS PER SHARE

[0001104659-15-005354:notes:66]
[same as prior period, unchanged from 0001104659-14-075227:notes:37]

[0001104659-15-005354:notes:67]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings per share: |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 152,899 |  | $ | 145,157 |  | $ | 465,689 |  | $ | 322,619 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  | 577,157 |  | 606,724 |  | 583,383 |  | 614,539 |  |
| Basic earnings per share |  | $ | 0.26 |  | $ | 0.24 |  | $ | 0.80 |  | $ | 0.52 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 152,899 |  | $ | 145,157 |  | $ | 465,689 |  | $ | 322,619 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding |  | 577,157 |  | 606,724 |  | 583,383 |  | 614,539 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) |  | 10,044 |  | 11,953 |  | 11,408 |  | 12,860 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding |  | 587,201 |  | 618,677 |  | 594,791 |  | 627,399 |  |
| Diluted earnings per share |  | $ | 0.26 |  | $ | 0.23 |  | $ | 0.78 |  | $ | 0.51 |  |

[0001104659-15-005354:notes:68]
|  | (1) |  | Options to purchase ordinary shares of 9.4 million and 16.5 million during the three-month periods ended December 31, 2014 and December 31, 2013, respectively, and share bonus awards of 0.2 million for both three-month periods ended December 31, 2014 and December 31, 2013, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary share equivalents. |

[0001104659-15-005354:notes:69]
|  | (2) |  | Options to purchase ordinary shares of 11.2 million and 16.5 million during the nine-month periods ended December 31, 2014 and December 31, 2013, respectively, and share bonus awards of 0.1 million for both nine-month periods ended December 31, 2014 and December 31, 2013, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary share equivalents. |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-15-005354:notes:70]
10.  FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES

[0001104659-15-005354:notes:71]
[same as prior period, unchanged from 0001104659-14-075227:notes:79]

[0001104659-15-005354:notes:72]
[same as prior period, unchanged from 0001104659-14-075227:notes:80]

[0001104659-15-005354:notes:73]
The Company has deferred compensation plans for its officers and certain other employees.  Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager.  The Company’s deferred compensation plan assets are for the most part included in other noncurrent assets on the condensed consolidated balance sheets and primarily include investments in equity securities that are valued using active market prices.

[0001104659-15-005354:notes:74]
[same as prior period, unchanged from 0001104659-14-075227:notes:82]

[0001104659-15-005354:notes:75]
[same as prior period, unchanged from 0001104659-14-075227:notes:83]

[0001104659-15-005354:notes:76]
[same as prior period, unchanged from 0001104659-14-075227:notes:84]

[0001104659-15-005354:notes:77]
The Company’s deferred compensation plan assets also include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources.  These sources price these investments using certain market indices and the performance of these investments in relation to these indices.  As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0001104659-15-005354:notes:78]
[same as prior period, unchanged from 0001104659-14-075227:notes:86]

[0001104659-15-005354:notes:79]
The Company has accrued for certain contingent consideration in connection with its business acquisitions, which is measured at fair value based on internal cash flow models and other inputs. During the three-month period ended December 31, 2014, the Company paid $7.4 million of contingent consideration related to our acquisition of Saturn Electronics and Engineering Inc., included as other financing activities in the statement of cash flows for the nine-month period ended December 31, 2014. The following table summarizes the activities related to contingent consideration:

[0001104659-15-005354:notes:80]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2014 |  | December 31,2013 |  | December 31, 2014 |  | December 31, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 15,800 |  | $ | 16,000 |  | $ | 11,300 |  | $ | 25,000 |  |
| Additions to accrual |  | — |  | — |  | 4,500 |  | — |  |
| Payments |  | (7,398 | ) | — |  | (7,398 | ) | — |  |
| Fair value adjustments |  | — |  | (3,700 | ) | — |  | (12,700 | ) |
| Ending balance |  | $ | 8,402 |  | $ | 12,300 |  | $ | 8,402 |  | $ | 12,300 |  |

[0001104659-15-005354:notes:81]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor.  Due to its high credit quality and short term maturity the fair value approximates carrying value.  Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not meaningful.  The interrelationship between these inputs is also insignificant.  Refer to note 9 to the condensed consolidated financial statements for a reconciliation of the change in the deferred purchase price receivable during the three-month and nine-month periods ended December 31, 2014 and December 31, 2013.

[0001104659-15-005354:notes:82]
There were no transfers between levels in the fair value hierarchy during the three-month and nine-month periods ended December 31, 2014 and December 31, 2013.

[0001104659-15-005354:notes:83]
[same as prior period, unchanged from 0001104659-14-075227:notes:91]

[0001104659-15-005354:notes:84]
[same as prior period, unchanged from 0001104659-14-075227:notes:92]

[0001104659-15-005354:notes:85]
|  |  | Fair Value Measurements as of December 31, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
|  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) |  | $ | — |  | $ | 561,002 |  | $ | — |  | $ | 561,002 |  |
| Deferred purchase price receivable (Note 9) |  | — |  | — |  | 674,642 |  | 674,642 |  |
| Foreign exchange forward contracts (Note 7) |  | — |  | 19,556 |  | — |  | 19,556 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities |  | 8,981 |  | 35,866 |  | — |  | 44,847 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 7) |  | $ | — |  | $ | (44,394 | ) | $ | — |  | $ | (44,394 | ) |
| Contingent consideration in connection with business acquisitions |  | — |  | — |  | (8,402 | ) | (8,402 | ) |

[0001104659-15-005354:notes:86]
[same as prior period, unchanged from 0001104659-14-075227:notes:94]

[0001104659-15-005354:notes:87]
[same as prior period, unchanged from 0001104659-14-075227:notes:95]

[0001104659-15-005354:notes:88]
Assets held for sale are recorded at the lesser of the carrying value or fair value, which is based on comparable sales from prevailing market data (level 2 inputs).  As of December 31, 2014 and March 31, 2014, the fair value of assets that were no longer in use and held for sale totaled approximately $13.5 million and $43.5 million, respectively. These assets primarily represent manufacturing facilities that have been closed as part of the Company’s historical facility consolidations and that met the criteria to be classified as held for sale. During the nine-month period ended December 31, 2014, the Company sold $39.9 million of assets held for sale.

[0001104659-15-005354:notes:89]
There were no transfers between levels in the fair value hierarchy for assets held-for-sale during the three-month and nine-month periods ended December 31, 2014 and December 31, 2013.

[0001104659-15-005354:notes:90]
[same as prior period, unchanged from 0001104659-14-075227:notes:98]

[0001104659-15-005354:notes:91]
[same as prior period, unchanged from 0001104659-14-075227:notes:99]

[0001104659-15-005354:notes:92]
|  |  | As of December 31, 2014 |  | As of March 31, 2014 |  |  |  |
|  |  | Carrying |  | Fair |  | Carrying |  | Fair |  | Fair Value |  |
|  |  | Amount |  | Value |  | Amount |  | Value |  | Hierarchy |  |
|  |  | (In thousands) |  |
| Term Loan, including current portion, due in installments through August 2018 |  | $ | 596,250 |  | $ | 584,701 |  | $ | 600,000 |  | $ | 591,750 |  | Level 1 |  |
| Term Loan, including current portion, due in installments through March 2019 |  | 481,250 |  | 472,828 |  | 500,000 |  | 497,190 |  | Level 1 |  |
| 4.625% Notes due February 2020 |  | 500,000 |  | 511,560 |  | 500,000 |  | 504,688 |  | Level 1 |  |
| 5.000% Notes due February 2023 |  | 500,000 |  | 526,880 |  | 500,000 |  | 517,650 |  | Level 1 |  |
| Total |  | $ | 2,077,500 |  | $ | 2,095,969 |  | $ | 2,100,000 |  | $ | 2,111,278 |  |  |  |

[0001104659-15-005354:notes:93]
[same as prior period, unchanged from 0001104659-14-075227:notes:101]


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-15-005354:notes:94]
[same as prior period, unchanged from 0001104659-14-075227:notes:1]

[0001104659-15-005354:notes:95]
[same as prior period, unchanged from 0001104659-14-075227:notes:2]

[0001104659-15-005354:notes:96]
[same as prior period, unchanged from 0001104659-14-075227:notes:3]

[0001104659-15-005354:notes:97]
The Company’s service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement,  inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).

[0001104659-15-005354:notes:98]
[same as prior period, unchanged from 0001104659-14-075227:notes:5]

[0001104659-15-005354:notes:99]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2014 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015.

[0001104659-15-005354:notes:100]
The first quarters for fiscal year 2015 and fiscal year 2014 ended on June 27, 2014, which is comprised of 88 days in the period, and June 28, 2013, which is comprised of 89 days in the period, respectively. The second quarter for fiscal year 2015 and fiscal year 2014 ended on September 26, 2014 and September 27, 2013, which are comprised of 91 days in both periods, respectively. The Company’s third quarter ends on December 31 of each year, which is comprised of 96 days and 95 days in the respective periods for fiscal years 2015 and 2014.

[0001104659-15-005354:notes:101]
The accompanying unaudited condensed consolidated financial statements include the financial position and results of operations of a majority owned subsidiary of the Company.  Non-controlling interests are presented as a separate component of total shareholders’ equity in the condensed consolidated balance sheets.  The operating results of the subsidiary attributable to the non-controlling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

[0001104659-15-005354:notes:102]
[same as prior period, unchanged from 0001104659-14-075227:notes:9]

[0001104659-15-005354:notes:103]
In April 2014, the Financial Accounting Standards Board (“FASB”) issued guidance which requires an entity to report a disposal of a component of an entity in discontinued operations if the disposal represents a strategic shift that has a major effect on an entity’s operations and financial results when the component of an entity meets certain criteria to be classified as held for sale, or when the component of an entity is disposed of by a sale or disposed of other than by a sale. Further, additional disclosures about discontinued operations should include the following for the periods in which the results of operations of the discontinued operations are presented in the statement of operations: the major classes of line items constituting pretax profit or loss of discontinued operations; total operating and investing cash flows of discontinued operations; depreciation, amortization, capital expenditures, and significant operating and investing noncash items of discontinued operations; pretax profit or loss attributable to the parent if a discontinued operation includes a non-controlling interest; a reconciliation of major classes of assets and liabilities of the discontinued operation classified as held for sale; and a reconciliation of major classes of line items constituting the pretax profit or loss of the discontinued operation. The Company early adopted this accounting standard update in the first quarter of fiscal year 2015.  During the first quarter of fiscal 2015, the Company disposed of a manufacturing facility in Western Europe which did not meet the criteria of discontinued operations under this accounting standard, as further discussed in note 6 to the condensed consolidated financial statements.

[0001104659-15-005354:notes:104]
In May 2014, the FASB issued new guidance related to revenue recognition which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services.  In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018 and the Company is in the process of assessing the impact on its consolidated financial statements.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001104659-15-005354:notes:105]
6.  OTHER CHARGES (INCOME), NET

[0001104659-15-005354:notes:106]
During the nine-month period ended December 31, 2014, an amendment to a customer contract to reimburse a customer for certain performance provisions was executed which included the removal of a $55.0 million contractual obligation recognized during fiscal year 2014. Accordingly, the Company reversed this charge with a corresponding credit to other charges (income), net in the condensed consolidated statement of operations.

[0001104659-15-005354:notes:107]
Further, during the nine-month period ended December 31, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe.  The Company received $11.5 million in cash for the sale of $27.2 million in net assets of the facility.  The loss also includes $4.6 million of estimated transaction costs, partially offset by a gain of $9.3 million for the release of cumulative foreign currency translation gains triggered by the disposition.

[0001104659-15-005354:notes:108]
During the nine-month period ended December 31, 2013, the Company recognized a loss of $7.1 million relating to the exercise of a warrant to purchase shares of a certain supplier and sale of the underlying shares for total proceeds of $67.3 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001104659-15-005354:notes:109]
11.  RESTRUCTURING CHARGES

[0001104659-15-005354:notes:110]
[same as prior period, unchanged from 0001104659-14-075227:notes:103]

[0001104659-15-005354:notes:111]
During the nine-month period ended December 31, 2013, the Company recognized restructuring charges of approximately $40.8 million, of which $35.1 million were recorded as a component of cost of sales and $5.6 million were recorded as a component of selling, general and administrative expenses.  Of the total restructuring charges, $32.2 million was associated with the terminations of 5,106 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 3,947 in Asia, 1,105 in the Americas and 54 in Europe. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on equipment no longer in use and to be disposed of, and other exit related costs due to facility closures or rationalizations.  Of the total restructuring charges, $1.9 million were non-cash charges related to the impairment of long-lived assets, and were classified as a component of cost of sales.

[0001104659-15-005354:notes:112]
The components of the restructuring charges by geographic region incurred during the nine-month period ended December 31, 2013 were as follows:

[0001104659-15-005354:notes:113]
[same as prior period, unchanged from 0001104659-14-075227:notes:106]

[0001104659-15-005354:notes:114]
[same as prior period, unchanged from 0001104659-14-075227:notes:107]

[0001104659-15-005354:notes:115]
During the nine-month period ended December 31, 2013, the Company recognized approximately $6.7 million of other exit costs, which was primarily comprised of $3.8 million related to personnel costs and $2.9 million of contractual obligations that resulted from facility closures. The majority of these costs were classified as a component of cost of sales.

[0001104659-15-005354:notes:116]
During the nine-month period ended December 31, 2014, the Company paid approximately $29.4 million for restructuring charges.  Total restructuring charges accrued as of December 31, 2014 were approximately $13.0 million, of which the majority was classified as a short-term obligation.


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001104659-15-005354:notes:117]
| Fiscal Year Ending March 31, |  | Amount |  |
|  |  | (In thousands) |  |
| 2015 (1) |  | $ | 7,496 |  |
| 2016 |  | 26,582 |  |
| 2017 |  | 18,404 |  |
| 2018 |  | 12,564 |  |
| 2019 |  | 8,326 |  |
| Thereafter |  | 9,677 |  |
| Total amortization expense |  | $ | 83,049 |  |

[0001104659-15-005354:notes:118]
|  | (1) |  | Represents estimated amortization for the remaining three-month period ending March 31, 2015. |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001104659-15-005354:notes:119]
|  |  | As of December 31, 2014 |  | As of March 31, 2014 |  |
|  |  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |
|  |  | Carrying |  | Accumulated |  | Carrying |  | Carrying |  | Accumulated |  | Carrying |  |
|  |  | Amount |  | Amortization |  | Amount |  | Amount |  | Amortization |  | Amount |  |
|  |  | (In thousands) |  |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles |  | $ | 126,712 |  | $ | (73,867 | ) | $ | 52,845 |  | $ | 204,369 |  | $ | (140,713 | ) | $ | 63,656 |  |
| Licenses and other intangibles |  | 39,793 |  | (9,589 | ) | 30,204 |  | 32,564 |  | (11,760 | ) | 20,804 |  |
| Total |  | $ | 166,505 |  | $ | (83,456 | ) | $ | 83,049 |  | $ | 236,933 |  | $ | (152,473 | ) | $ | 84,460 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001104659-15-005354:notes:120]
The following table summarizes the activity in the Company’s goodwill account during the nine-month period ended December 31, 2014:

[0001104659-15-005354:notes:121]
|  |  | Amount |  |
|  |  | (In thousands) |  |
| Balance, beginning of the year |  | $ | 292,758 |  |
| Additions (1) |  | 36,467 |  |
| Purchase accounting adjustments (2) |  | 8,651 |  |
| Foreign currency translation adjustments |  | (3,393 | ) |
| Balance, end of the period |  | $ | 334,483 |  |

[0001104659-15-005354:notes:122]
|  | (1) |  | The goodwill generated from the Company’s business combinations completed during the nine-month period ended December 31, 2014 is primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired businesses and expected synergies. The goodwill is not deductible for income tax purposes. See note 12 to the condensed consolidated financial statements for additional information. |

[0001104659-15-005354:notes:123]
|  | (2) |  | Fair value adjustment made to certain assets acquired in connection with the Company’s acquisition of Riwisa AG during the three-month ended December 31, 2013. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001104659-15-005354:notes:124]
|  |  | As of |  | As of |  |
|  |  | December 31, 2014 |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Raw materials |  | $ | 2,336,860 |  | $ | 2,349,278 |  |
| Work-in-progress |  | 549,732 |  | 608,284 |  |
| Finished goods |  | 673,048 |  | 641,446 |  |
|  |  | $ | 3,559,640 |  | $ | 3,599,008 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-15-005354:notes:125]
2.  BALANCE SHEET ITEMS

[0001104659-15-005354:notes:126]
[same as prior period, unchanged from 0001104659-14-075227:notes:13]

[0001104659-15-005354:notes:127]
[same as prior period, unchanged from 0001104659-14-075227:notes:14]

[0001104659-15-005354:notes:128]
[same as prior period, unchanged from 0001104659-14-075227:notes:16]

[0001104659-15-005354:notes:129]
[same as prior period, unchanged from 0001104659-14-075227:notes:21]

[0001104659-15-005354:notes:130]
The gross carrying amounts of intangible assets are removed when the recorded amounts have been fully amortized.  During the nine-month period ended December 31, 2014, the value of customer-related intangible assets increased by $8.5 million in connection with the Company’s acquisitions, and licenses and other intangibles increased by $15.7 million primarily as a result of the purchase of certain technology rights.  The estimated future annual amortization expense for intangible assets is as follows:

[0001104659-15-005354:notes:131]
[same as prior period, unchanged from 0001104659-14-075227:notes:26]

[0001104659-15-005354:notes:132]
In connection with a prior year acquisition, the Company entered into an agreement with a customer and a third party banking institution to procure certain manufacturing equipment that was financed by the third party banking institution, acting as an agent of the customer.  The manufacturing equipment was used exclusively for the benefit of this customer.  The Company has the ability to settle the obligation related to these financed assets by returning the equipment to the customer and cannot be required to pay cash by either the customer or the third party banking institution.  During the current fiscal year, the Company ceased manufacturing of the product related to the financed equipment.  As a result, the Company as an agent on behalf of the customer is in the process of dispositioning the equipment and forwarding the proceeds to the third party banking institution reducing the outstanding obligation.  The value of the equipment financed by the third party was $272.0 million and $267.5 million as of December 31, 2014 and March 31, 2014, respectively and is included in other current assets.  The outstanding balance due to the third party banking institution related to the financed equipment was $263.7 million and $286.5 million as of December 31, 2014 and March 31, 2014, respectively and is included in other current liabilities.

[0001104659-15-005354:notes:133]
Other current liabilities also includes deferred revenue of $287.0 million and $296.3 million, and customer working capital advances of $213.0 million and $754.7 million as of December 31, 2014 and March 31, 2014, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001104659-15-005354:notes:134]
[same as prior period, unchanged from 0001104659-14-075227:notes:66]

[0001104659-15-005354:notes:135]
[same as prior period, unchanged from 0001104659-14-075227:notes:67]

[0001104659-15-005354:notes:136]
[same as prior period, unchanged from 0001104659-14-075227:notes:68]

[0001104659-15-005354:notes:137]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables.  Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $500.0 million for the Global Program and $225.0 million for the North American Program. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001104659-15-005354:notes:138]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum.  Servicing fees recognized during the three-month and nine-month periods ended December 31, 2014 and December 31, 2013 were not material and are included in interest and other, net within the condensed consolidated statements of operations.  As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0001104659-15-005354:notes:139]
As of December 31, 2014, approximately $1.4 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $714.6 million and deferred purchase price receivables of approximately $674.6 million.  As of March 31, 2014, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $729.3 million and deferred purchase price receivables of approximately $470.9 million.  The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction.  The deferred purchase price receivables are included in other current assets as of December 31, 2014 and March 31, 2014, and were carried at the expected recovery amount of the related receivables.  The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0001104659-15-005354:notes:140]
As of December 31, 2014 and March 31, 2014, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0001104659-15-005354:notes:141]
For the nine-month periods ended December 31, 2014 and December 31, 2013, cash flows from sales of receivables under the ABS Programs consisted of approximately $3.3 billion and $3.0 billion for transfers of receivables, respectively (of which approximately $204.6 million and $256.3 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0001104659-15-005354:notes:142]
[same as prior period, unchanged from 0001104659-14-075227:notes:74]

[0001104659-15-005354:notes:143]
[same as prior period, unchanged from 0001104659-14-075227:notes:76]

[0001104659-15-005354:notes:144]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $518.9 million and $341.8 million as of December 31, 2014 and March 31, 2014, respectively. For the nine-month periods ended December 31, 2014 and December 31, 2013, total accounts receivable sold to certain third party banking institutions was approximately $3.4 billion and $2.7 billion, respectively.  The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0001104659-15-005354:notes:145]
14.  SHARE REPURCHASES

[0001104659-15-005354:notes:146]
During the three-month and nine-month periods ended December 31, 2014 the Company repurchased 7.8 million shares at an aggregate purchase price of $83.3 million and 27.6 million shares at an aggregate purchase price of $286.7 million, respectively, and retired all of these shares.

[0001104659-15-005354:notes:147]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Extraordinary General Meeting held on August 28, 2014. As of December 31, 2014, shares in the aggregate amount of $373.4 million were available to be repurchased under the current plan.
