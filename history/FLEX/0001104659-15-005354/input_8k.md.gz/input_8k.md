# FLEX 8-K — 0001104659-15-005046 filed 2015-01-28

## item codes, every 8-K on or before 2015-01-29

- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2015-01-29

- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-15-005046:8k_2_02:1]
EX-99.1
2
a15-3177_1ex99d1.htm
EX-99.1

[0001104659-15-005046:8k_2_02:2]
Exhibit 99.1

[0001104659-15-005046:8k_2_02:3]
P R E S S   R E L E A S E

[0001104659-15-005046:8k_2_02:4]
| Renee Brotherton |  | Kevin Kessel |
| Corporate Communications |  | Investor Relations |
| (408) 576-7189 |  | (408) 576-7985 |
| renee.brotherton@flextronics.com |  | kevin.kessel@flextronics.com |

[0001104659-15-005046:8k_2_02:5]
FLEXTRONICS REPORTS THIRD QUARTER FISCAL 2015 RESULTS

[0001104659-15-005046:8k_2_02:6]
·     Adjusted EPS at $0.30, an increase of 15% Year-over-Year

[0001104659-15-005046:8k_2_02:7]
·     Adjusted Operating Profit Increased 11% Year-over-Year

[0001104659-15-005046:8k_2_02:8]
·     Free cash flow generation of $337 million

[0001104659-15-005046:8k_2_02:9]
San Jose, CA, January 28, 2015 — Flextronics (NASDAQ: FLEX), a leading end-to-end supply chain solutions company, today announced results for its third quarter ended December 31, 2014:

[0001104659-15-005046:8k_2_02:10]
|  |  | Three Month Periods Ended |  |
|  |  | December 31, |  | September 26, |  | December 31, |  |
| (US$ in millions, except EPS) |  | 2014 |  | 2014 |  | 2013 |  |
| Net sales |  | $ | 7,025 |  | $ | 6,529 |  | $ | 7,183 |  |
| Adjusted operating income |  |  | 207 |  |  | 183 |  |  | 187 |  |
| GAAP operating income |  |  | 193 |  |  | 172 |  |  | 174 |  |
| Adjusted net income |  |  | 175 |  |  | 157 |  |  | 164 |  |
| GAAP net income |  |  | 153 |  |  | 139 |  |  | 145 |  |
| Adjusted EPS |  |  | 0.30 |  |  | 0.26 |  |  | 0.26 |  |
| GAAP EPS |  |  | 0.26 |  |  | 0.23 |  |  | 0.23 |  |

[0001104659-15-005046:8k_2_02:11]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release.

[0001104659-15-005046:8k_2_02:12]
Third Quarter Results of Operations

[0001104659-15-005046:8k_2_02:13]
Net sales for the third quarter ended December 31, 2014 were $7.0 billion, exceeding the Company’s previously provided revenue guidance of $6.4 billion to $6.8 billion.  The Company’s adjusted earnings per diluted share of $0.30 for the third quarter ended December 31, 2014 also exceeded the Company’s previously provided guidance of $0.24 to $0.28.

[0001104659-15-005046:8k_2_02:14]
The Company’s third quarter adjusted operating income increased 11% year-over-year to $207 million which exceeded its guidance range of $175 million to $205 million.

[0001104659-15-005046:8k_2_02:15]
“The Flextronics team continues to deliver on our core innovation strategies and initiatives, allowing us to achieve our financial targets,” said Mike McNamara, chief executive officer at Flextronics. “We reported solid results across our business groups which is evidenced by our 15% year-over-year growth in earnings per share.” He added, “We will continue to provide the most innovative end-to-end supply chain solutions going from sketch to scale, increasing our customer’s competitive advantage in the marketplace.”

[0001104659-15-005046:8k_2_02:16]
“Our commitment to return shareholder value was further demonstrated by repurchasing approximately 8 million shares during the quarter for $84 million,” said Chris Collier, chief financial officer at Flextronics. “We continue to operate with discipline and delivered another strong quarter of free cash flow generation of $337 million.”

[0001104659-15-005046:8k_2_02:17]
Guidance

[0001104659-15-005046:8k_2_02:18]
For the fourth quarter ending March 31, 2015, revenue is expected to be in the range of $6.0 to $6.4 billion and adjusted EPS is expected to be in the range of $0.23 to $0.27 per diluted share.

[0001104659-15-005046:8k_2_02:19]
GAAP earnings per share is expected to be lower than the guidance provided herein by approximately $0.04 per diluted share for intangible amortization and stock-based compensation expense.

[0001104659-15-005046:8k_2_02:20]
Conference Calls and Web Casts

[0001104659-15-005046:8k_2_02:21]
A conference call hosted by Flextronics’s management team will be held today at 2:00 PM (PT) / 5:00 PM (ET) to discuss the Company’s financial results for the third quarter ended December 31, 2014.  The conference call will be broadcast via the Internet and may be accessed by logging on to the Company’s website at www.flextronics.com. Additional information in the form of a slide presentation may also be found on the Company’s site.  A replay of the broadcast will remain available on the Company’s website afterwards.

[0001104659-15-005046:8k_2_02:22]
About Flextronics

[0001104659-15-005046:8k_2_02:23]
Flextronics International Ltd. (Reg. No. 199002645H) is a leading end-to-end supply chain solutions company that delivers innovative design, engineering, manufacturing and logistics services to a range of industries and end-markets, including data networking, telecom, enterprise computing and storage, industrial, capital equipment, appliances, automation, medical, automotive, aerospace and defense, energy, mobile, computing and other electronic product categories. Flextronics is an industry leader with $26 billion in sales, generated from helping customers design, build, ship, and service their products through an unparalleled network of facilities and innovations centers in approximately 30 countries and across four continents. Flextronics service offerings and vertically integrated component technologies optimize customer supply chains by lowering costs, increasing flexibility, and reducing time-to-market. For more information, visit www.flextronics.com or follow us on Twitter @flextronics.

[0001104659-15-005046:8k_2_02:24]
# # #

[0001104659-15-005046:8k_2_02:25]
manage changes in our operations; compliance with legal and regulatory requirements; the possibility that benefits of the Company’s restructuring actions may not materialize as expected; that the expected revenue and margins from recently launched programs may not be realized; that recently proposed changes in tax laws in certain jurisdictions where we operate may materially impact our tax expense, and the effects that the current macroeconomic environment could have on our business and demand for our products as well as the effects that current credit and market conditions could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations. Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our reports on Form 10-K and 10-Q that we file with the U.S. Securities and Exchange Commission. The forward-looking statements in this press release are based on current expectations and Flextronics assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0001104659-15-005046:8k_2_02:26]
SCHEDULE I

[0001104659-15-005046:8k_2_02:27]
FLEXTRONICS INTERNATIONAL LTD.

[0001104659-15-005046:8k_2_02:28]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-15-005046:8k_2_02:29]
(In thousands, except per share amounts)

[0001104659-15-005046:8k_2_02:30]
|  |  | Three Month Periods Ended |  |
|  |  | December 31, 2014 |  | September 26, 2014 |  | December 31, 2013 |  |
| GAAP: |  |  |  |  |  |  |  |
| Net sales |  | $ | 7,025,054 |  | $ | 6,528,517 |  | $ | 7,183,442 |  |
| Cost of sales |  | 6,616,397 |  | 6,151,436 |  | 6,784,823 |  |
| Gross profit |  | 408,657 |  | 377,081 |  | 398,619 |  |
| Selling, general and administrative expenses |  | 215,993 |  | 204,590 |  | 224,576 |  |
| Operating income |  | 192,664 |  | 172,491 |  | 174,043 |  |
| Intangible amortization |  | 8,045 |  | 8,232 |  | 5,575 |  |
| Interest and other, net |  | 9,035 |  | 12,506 |  | 18,342 |  |
| Other charges (income), net |  | 5,067 |  | (2,584 | ) | (3,599 | ) |
| Income before income taxes |  | 170,517 |  | 154,337 |  | 153,725 |  |
| Provision for income taxes |  | 17,618 |  | 15,434 |  | 8,568 |  |
| Net income |  | $ | 152,899 |  | $ | 138,903 |  | $ | 145,157 |  |
| EPS: |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.26 |  | $ | 0.23 |  | $ | 0.23 |  |
| Non-GAAP |  | $ | 0.30 |  | $ | 0.26 |  | $ | 0.26 |  |
| Diluted shares used in computing per share amounts |  | 587,201 |  | 595,871 |  | 618,677 |  |

[0001104659-15-005046:8k_2_02:31]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule IV attached to this press release.

[0001104659-15-005046:8k_2_02:32]
SCHEDULE II

[0001104659-15-005046:8k_2_02:33]
FLEXTRONICS INTERNATIONAL LTD.

[0001104659-15-005046:8k_2_02:34]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-15-005046:8k_2_02:35]
(In thousands, except per share amounts)

[0001104659-15-005046:8k_2_02:36]
|  |  | Three Month Periods Ended |  |
|  |  | December 31, 2014 |  | September 26, 2014 |  | December 31, 2013 |  |
| GAAP gross profit |  | $ | 408,657 |  | $ | 377,081 |  | $ | 398,619 |  |
| Stock-based compensation expense |  | 2,083 |  | 1,868 |  | 1,800 |  |
| Non-GAAP gross profit |  | $ | 410,740 |  | $ | 378,949 |  | $ | 400,419 |  |
| GAAP SG&A Expenses |  | $ | 215,993 |  | $ | 204,590 |  | $ | 224,576 |  |
| Stock-based compensation expense |  | 12,136 |  | 9,051 |  | 11,311 |  |
| Non-GAAP SG&A Expenses |  | $ | 203,857 |  | $ | 195,539 |  | $ | 213,265 |  |
| GAAP operating income |  | $ | 192,664 |  | $ | 172,491 |  | $ | 174,043 |  |
| Stock-based compensation expense |  | 14,219 |  | 10,919 |  | 13,111 |  |
| Non-GAAP operating income |  | $ | 206,883 |  | $ | 183,410 |  | $ | 187,154 |  |
| GAAP provision for income taxes |  | $ | 17,618 |  | $ | 15,434 |  | $ | 8,568 |  |
| Intangible amortization benefit |  | 224 |  | 1,177 |  | — |  |
| Non-GAAP provision for income taxes |  | $ | 17,842 |  | $ | 16,611 |  | $ | 8,568 |  |
| GAAP net income |  | $ | 152,899 |  | $ | 138,903 |  | $ | 145,157 |  |
| Stock-based compensation expense |  | 14,219 |  | 10,919 |  | 13,111 |  |
| Intangible amortization |  | 8,045 |  | 8,232 |  | 5,575 |  |
| Adjustments for taxes |  | (224 | ) | (1,177 | ) | — |  |
| Non-GAAP net income |  | $ | 174,939 |  | $ | 156,877 |  | $ | 163,843 |  |
| EPS: |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.26 |  | $ | 0.23 |  | $ | 0.23 |  |
| Non-GAAP |  | $ | 0.30 |  | $ | 0.26 |  | $ | 0.26 |  |

[0001104659-15-005046:8k_2_02:37]
SCHEDULE III

[0001104659-15-005046:8k_2_02:38]
FLEXTRONICS INTERNATIONAL LTD.

[0001104659-15-005046:8k_2_02:39]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-15-005046:8k_2_02:40]
(In thousands)

[0001104659-15-005046:8k_2_02:41]
|  |  | December 31, 2014 |  | March 31, 2014 |  |
| ASSETS |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,707,221 |  | $ | 1,593,728 |  |
| Accounts receivable, net |  | 2,449,773 |  | 2,697,985 |  |
| Inventories |  | 3,559,640 |  | 3,599,008 |  |
| Other current assets |  | 1,416,586 |  | 1,509,605 |  |
| Total current assets |  | 9,133,220 |  | 9,400,326 |  |
| Property and equipment, net |  | 2,114,681 |  | 2,288,656 |  |
| Goodwill and other intangible assets, net |  | 417,532 |  | 377,218 |  |
| Other assets |  | 425,040 |  | 433,950 |  |
| Total assets |  | $ | 12,090,473 |  | $ | 12,500,150 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 45,174 |  | $ | 32,575 |  |
| Accounts payable |  | 4,850,515 |  | 4,747,779 |  |
| Other current liabilities |  | 2,313,033 |  | 2,876,333 |  |
| Total current liabilities |  | 7,208,722 |  | 7,656,687 |  |
| Long-term debt, net of current portion: |  |  |  |  |  |
| Revolving credit facility |  | — |  | — |  |
| 4.625% Notes (due 2020) |  | 500,000 |  | 500,000 |  |
| 5.000% Notes (due 2023) |  | 500,000 |  | 500,000 |  |
| Term Loans |  | 1,037,500 |  | 1,067,500 |  |
| Other long-term debt |  | 8,069 |  | 2,520 |  |
| Other liabilities |  | 447,337 |  | 571,764 |  |
| Total shareholders’ equity |  | 2,388,845 |  | 2,201,679 |  |
| Total liabilities and shareholders’ equity |  | $ | 12,090,473 |  | $ | 12,500,150 |  |

[0001104659-15-005046:8k_2_02:42]
SCHEDULE IV

[0001104659-15-005046:8k_2_02:43]
FLEXTRONICS INTERNATIONAL LTD. AND SUBSIDIARIES

[0001104659-15-005046:8k_2_02:44]
NOTES TO SCHEDULES I, II, & III

[0001104659-15-005046:8k_2_02:45]
(1)   To supplement Flextronics’s unaudited selected financial data presented on a basis consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP selling, general and administrative expenses, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude stock-based compensation expense, restructuring charges, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies.  We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flextronics’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flextronics’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-15-005046:8k_2_02:46]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance.  We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors.  In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-15-005046:8k_2_02:47]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-15-005046:8k_2_02:48]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-15-005046:8k_2_02:49]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-15-005046:8k_2_02:50]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-15-005046:8k_2_02:51]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-15-005046:8k_2_02:52]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types.  In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-15-005046:8k_2_02:53]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions.  The Company considers its operating results without

[0001104659-15-005046:8k_2_02:54]
these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-15-005046:8k_2_02:55]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies.

[0001104659-15-005046:8k_2_02:56]
For the three-month period ended December 31, 2014, Free Cash Flow was $337 million consisting of GAAP net cash flows from operating activities of $363 million less purchases of property and equipment net of dispositions of $26 million. We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash flows provided by operating activities.”
