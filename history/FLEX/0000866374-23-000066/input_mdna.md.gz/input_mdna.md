# FLEX MD&A — 0000866374-23-000066


## mdna

[0000866374-23-000066:mdna:1]
[same as prior period, unchanged from 0000866374-23-000058:mdna:1]

[0000866374-23-000066:mdna:2]
[same as prior period, unchanged from 0000866374-23-000058:mdna:2]

[0000866374-23-000066:mdna:3]
[same as prior period, unchanged from 0000866374-23-000058:mdna:3]

[0000866374-23-000066:mdna:4]
We are the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we support the entire product lifecycle with advanced manufacturing solutions and operate one of the most trusted global supply chains. We also provide additional value to customers through a broad array of services, including design engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. We support a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of September 29, 2023, our three operating and reportable segments were as follows:

[0000866374-23-000066:mdna:5]
[same as prior period, unchanged from 0000866374-23-000058:mdna:5]

[0000866374-23-000066:mdna:6]
[same as prior period, unchanged from 0000866374-23-000058:mdna:6]

[0000866374-23-000066:mdna:7]
[same as prior period, unchanged from 0000866374-23-000058:mdna:7]

[0000866374-23-000066:mdna:8]
[same as prior period, unchanged from 0000866374-23-000058:mdna:8]

[0000866374-23-000066:mdna:9]
[same as prior period, unchanged from 0000866374-23-000058:mdna:9]

[0000866374-23-000066:mdna:10]
[same as prior period, unchanged from 0000866374-23-000058:mdna:10]

[0000866374-23-000066:mdna:11]
[same as prior period, unchanged from 0000866374-23-000058:mdna:11]

[0000866374-23-000066:mdna:12]
[same as prior period, unchanged from 0000866374-23-000058:mdna:12]

[0000866374-23-000066:mdna:13]
[same as prior period, unchanged from 0000866374-23-000058:mdna:13]

[0000866374-23-000066:mdna:14]
[same as prior period, unchanged from 0000866374-23-000058:mdna:14]

[0000866374-23-000066:mdna:15]
[same as prior period, unchanged from 0000866374-23-000058:mdna:15]

[0000866374-23-000066:mdna:16]
[same as prior period, unchanged from 0000866374-23-000058:mdna:16]

[0000866374-23-000066:mdna:17]
[same as prior period, unchanged from 0000866374-23-000058:mdna:17]

[0000866374-23-000066:mdna:18]
[same as prior period, unchanged from 0000866374-23-000058:mdna:18]

[0000866374-23-000066:mdna:19]
Component shortages and logistical constraints improved as the year progressed. We continue to monitor potential supply chain disruptions. Refer to “Risk Factors - “Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, have in the past affected, and may in the future, affect our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory. We have been and continue to be adversely affected by supply chain issues, including shortages of required electronic components.” as disclosed in Part I, “Item 1A. Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0000866374-23-000066:mdna:20]
[same as prior period, unchanged from 0000866374-23-000058:mdna:20]

[0000866374-23-000066:mdna:21]
Russian Invasion of Ukraine and Israel-Hamas War

[0000866374-23-000066:mdna:22]
We continue to monitor and respond to the escalating conflict in Ukraine and the associated sanctions and other restrictions. We also are monitoring and responding to the Israel-Hamas war. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine and Israel. The full impact of the conflicts on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflicts and its impact on regional and global economic conditions. We will continue to monitor the conflicts and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-23-000066:mdna:23]
[same as prior period, unchanged from 0000866374-23-000058:mdna:23]

[0000866374-23-000066:mdna:24]
On July 3, 2023, our subsidiary Nextracker Inc. ("Nextracker") completed a follow-on offering to its initial public offering, which was completed on February 13, 2023, and issued 15,631,562 shares of Class A common stock and received net proceeds of $551 million. The entire net proceeds were used by Nextracker to acquire 14,025,000 Nextracker LLC common units from Yuma, Inc., our indirect wholly-owned subsidiary, and 1,606,562 Nextracker LLC common units from TPG Rise Flash, L.P., an affiliate of the global alternative asset management firm TPG. As a result of the repurchase of Nextracker LLC common units by Nextracker, 15,631,562 shares of Nextracker Class B common stock were cancelled. Subsequent to the follow-on offering, we owned 74,432,619 shares of Class B common stock, representing 51.5% of the total outstanding shares of Nextracker common stock and, accordingly, still control Nextracker. We received approximately $495 million from the follow-on offering, after distribution of net proceeds to TPG and expenses.

[0000866374-23-000066:mdna:25]
On October 25, 2023, we announced our plan to effect a spin-off of all of our remaining interests in Nextracker to our shareholders on a pro rata basis pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023 (the “Merger Agreement”). The spin-off is subject to a number of conditions as set forth in the Merger Agreement, including the approval of our shareholders in accordance with Singapore law, and there is no assurance that any such conditions will be satisfied or waived. The spin-off is currently expected to be completed in our fourth quarter ending March 31, 2024.

[0000866374-23-000066:mdna:26]
[same as prior period, unchanged from 0000866374-23-000058:mdna:25]

[0000866374-23-000066:mdna:27]
We are one of the world's largest providers of global supply chain solutions, with revenues of $14.8 billion for the six-month period ended September 29, 2023 and $30.3 billion in the fiscal year ended March 31, 2023. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. We also provide intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites:

[0000866374-23-000066:mdna:28]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 3,684 |  |  | 49 | % |  | $ | 3,459 |  |  | 45 | % |  | $ | 7,166 |  |  | 48 | % |  | $ | 6,774 |  |  | 45 | % |
| Asia | 2,372 |  |  | 32 | % |  | 2,751 |  |  | 35 | % |  | 4,689 |  |  | 32 | % |  | 5,268 |  |  | 35 | % |
| Europe | 1,415 |  |  | 19 | % |  | 1,556 |  |  | 20 | % |  | 2,952 |  |  | 20 | % |  | 3,071 |  |  | 20 | % |
|  | $ | 7,471 |  |  |  |  | $ | 7,766 |  |  |  |  | $ | 14,807 |  |  |  |  | $ | 15,113 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 1,799 |  |  | 24 | % |  | $ | 1,601 |  |  | 21 | % |  | $ | 3,530 |  |  | 24 | % |  | $ | 3,156 |  |  | 21 | % |
| U.S. | 1,459 |  |  | 20 | % |  | 1,294 |  |  | 17 | % |  | 2,784 |  |  | 19 | % |  | 2,511 |  |  | 17 | % |
| China | 1,370 |  |  | 18 | % |  | 1,770 |  |  | 23 | % |  | 2,784 |  |  | 19 | % |  | 3,354 |  |  | 22 | % |
| Malaysia | 555 |  |  | 7 | % |  | 633 |  |  | 8 | % |  | 1,101 |  |  | 7 | % |  | 1,204 |  |  | 8 | % |
| Brazil | 416 |  |  | 6 | % |  | 547 |  |  | 7 | % |  | 818 |  |  | 6 | % |  | 1,074 |  |  | 7 | % |
| Hungary | 363 |  |  | 5 | % |  | 330 |  |  | 4 | % |  | 714 |  |  | 5 | % |  | 616 |  |  | 4 | % |
| Other | 1,509 |  |  | 20 | % |  | 1,591 |  |  | 20 | % |  | 3,076 |  |  | 20 | % |  | 3,198 |  |  | 21 | % |
|  | $ | 7,471 |  |  |  |  | $ | 7,766 |  |  |  |  | $ | 14,807 |  |  |  |  | $ | 15,113 |  |  |  |

[0000866374-23-000066:mdna:29]
|  | As of |  | As of |
| Property and equipment, net: | September 29, 2023 |  | March 31, 2023 |
|  | (In millions) |
| Mexico | $ | 788 |  |  | 34 | % |  | $ | 763 |  |  | 32 | % |
| U.S. | 360 |  |  | 15 | % |  | 365 |  |  | 16 | % |
| China | 332 |  |  | 14 | % |  | 338 |  |  | 14 | % |
| Malaysia | 149 |  |  | 6 | % |  | 152 |  |  | 6 | % |
| Hungary | 130 |  |  | 6 | % |  | 140 |  |  | 6 | % |
| Brazil | 89 |  |  | 4 | % |  | 89 |  |  | 4 | % |
| Other | 480 |  |  | 21 | % |  | 502 |  |  | 22 | % |
|  | $ | 2,328 |  |  |  |  | $ | 2,349 |  |  |  |

[0000866374-23-000066:mdna:30]
[same as prior period, unchanged from 0000866374-23-000058:mdna:29]

[0000866374-23-000066:mdna:31]
[same as prior period, unchanged from 0000866374-23-000058:mdna:30]

[0000866374-23-000066:mdna:32]
•global economic conditions, including inflationary pressures, currency volatility, slower growth or recession, higher interest rates, and geopolitical uncertainty (including as a result of the ongoing conflict between Russia and Ukraine and the Israel-Hamas war);

[0000866374-23-000066:mdna:33]
29

[0000866374-23-000066:mdna:34]
[same as prior period, unchanged from 0000866374-23-000058:mdna:33]

[0000866374-23-000066:mdna:35]
[same as prior period, unchanged from 0000866374-23-000058:mdna:34]

[0000866374-23-000066:mdna:36]
[same as prior period, unchanged from 0000866374-23-000058:mdna:35]

[0000866374-23-000066:mdna:37]
•the effects that current credit and market conditions (including as a result of the ongoing conflict between Russia and Ukraine and the Israel-Hamas war) could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-23-000066:mdna:38]
[same as prior period, unchanged from 0000866374-23-000058:mdna:37]

[0000866374-23-000066:mdna:39]
•exposure to infectious disease, epidemics and pandemics on our business operations in geographic locations impacted by an outbreak and on the business operations of our customers and suppliers;

[0000866374-23-000066:mdna:40]
[same as prior period, unchanged from 0000866374-23-000058:mdna:39]

[0000866374-23-000066:mdna:41]
[same as prior period, unchanged from 0000866374-23-000058:mdna:40]

[0000866374-23-000066:mdna:42]
[same as prior period, unchanged from 0000866374-23-000058:mdna:41]

[0000866374-23-000066:mdna:43]
[same as prior period, unchanged from 0000866374-23-000058:mdna:42]

[0000866374-23-000066:mdna:44]
[same as prior period, unchanged from 0000866374-23-000058:mdna:43]

[0000866374-23-000066:mdna:45]
[same as prior period, unchanged from 0000866374-23-000058:mdna:44]

[0000866374-23-000066:mdna:46]
[same as prior period, unchanged from 0000866374-23-000058:mdna:45]

[0000866374-23-000066:mdna:47]
[same as prior period, unchanged from 0000866374-23-000058:mdna:46]

[0000866374-23-000066:mdna:48]
[same as prior period, unchanged from 0000866374-23-000058:mdna:47]

[0000866374-23-000066:mdna:49]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to the ongoing conflict between Russia and Ukraine and the Israel-Hamas war, there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from those estimates and assumptions.

[0000866374-23-000066:mdna:50]
[same as prior period, unchanged from 0000866374-23-000058:mdna:49]

[0000866374-23-000066:mdna:51]
[same as prior period, unchanged from 0000866374-23-000058:mdna:50]

[0000866374-23-000066:mdna:52]
[same as prior period, unchanged from 0000866374-23-000058:mdna:51]

[0000866374-23-000066:mdna:53]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 91.1 |  |  | 92.4 |  |  | 91.4 |  |  | 92.5 |  |
| Restructuring charges | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Gross profit | 8.9 |  |  | 7.6 |  |  | 8.5 |  |  | 7.5 |  |
| Selling, general and administrative expenses | 3.6 |  |  | 3.2 |  |  | 3.7 |  |  | 3.2 |  |
| Restructuring charges | — |  |  | — |  |  | — |  |  | — |  |
| Intangible amortization | 0.3 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Operating income | 5.0 |  |  | 4.2 |  |  | 4.5 |  |  | 4.0 |  |
| Interest, net | 0.5 |  |  | 0.6 |  |  | 0.5 |  |  | 0.7 |  |
| Other charges (income), net | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.0 |  |
| Income before income taxes | 4.4 |  |  | 3.5 |  |  | 3.8 |  |  | 3.3 |  |
| Provision for (benefit from) income taxes | (1.0) |  |  | 0.4 |  |  | (0.4) |  |  | 0.4 |  |
| Net income | 5.4 |  |  | 3.1 |  |  | 4.2 |  |  | 2.9 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 2.3 |  |  | 0.1 |  |  | 1.4 |  |  | 0.1 |  |
| Net income attributable to Flex Ltd. | 3.1 | % |  | 3.0 | % |  | 2.8 | % |  | 2.8 | % |

[0000866374-23-000066:mdna:54]
[same as prior period, unchanged from 0000866374-23-000058:mdna:53]

[0000866374-23-000066:mdna:55]
[same as prior period, unchanged from 0000866374-23-000058:mdna:54]

[0000866374-23-000066:mdna:56]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,618 |  |  | 48 | % |  | $ | 4,004 |  |  | 52 | % |  | $ | 7,219 |  |  | 49 | % |  | $ | 7,995 |  |  | 53 | % |
| Flex Reliability Solutions | 3,314 |  |  | 44 | % |  | 3,299 |  |  | 42 | % |  | 6,605 |  |  | 45 | % |  | 6,268 |  |  | 41 | % |
| Nextracker | 573 |  |  | 8 | % |  | 473 |  |  | 6 | % |  | 1,053 |  |  | 7 | % |  | 868 |  |  | 6 | % |
| Intersegment eliminations | (34) |  |  | — | % |  | (10) |  |  | — | % |  | (70) |  |  | — | % |  | (18) |  |  | — | % |
|  | $ | 7,471 |  |  |  |  | $ | 7,766 |  |  |  |  | $ | 14,807 |  |  |  |  | $ | 15,113 |  |  |  |

[0000866374-23-000066:mdna:57]
Net sales during the three-month period ended September 29, 2023 totaled $7.5 billion, representing a decrease of approximately $0.3 billion, or 4% from $7.8 billion during the three-month period ended September 30, 2022. Net sales for our FAS segment decreased approximately $0.4 billion, or 10% from the three-month period ended September 30, 2022, primarily driven by a significant decrease in our Consumer Devices business, a low double-digit percentage decrease in our Lifestyle business, and a mid single-digit percentage decrease in our Communications, Enterprise and Cloud ("CEC") due to difficult year-over year comparisons in CEC, along with softer market demand in certain markets, and weakness in consumer end markets. Net sales for our FRS segment remained relatively flat and increased approximately $15 million, from the three-month period ended September 30, 2022, primarily driven by a high single-digit percentage increase in our Automotive business due to higher customer demand and ramps across various end markets, offset by a low single-digit percentage decrease in Industrial due to difficult year-over year comparisons and lower customer demand. Net sales for our Health Solutions business remained relatively flat due to customer ramps offset by lower customer demand. Net sales for our Nextracker segment increased approximately $0.1 billion, or 21% from the three-month period ended September 30, 2022, primarily driven by an increase in

[0000866374-23-000066:mdna:58]
31

[0000866374-23-000066:mdna:59]
gigawatts delivered. Net sales increased $0.2 billion to $3.7 billion in the Americas, decreased $0.4 billion to $2.4 billion in Asia, and decreased $0.1 billion to $1.4 billion in Europe.

[0000866374-23-000066:mdna:60]
Net sales during the six-month period ended September 29, 2023 totaled $14.8 billion, representing a decrease of approximately $0.3 billion, or 2% from $15.1 billion during the six-month period ended September 30, 2022. Net sales for our FAS segment decreased approximately $0.8 billion, or 10% from the six-month period ended September 30, 2022, primarily driven by a significant decrease in our Consumer Devices business, a low double-digit percentage decrease in our Lifestyle business and a low single-digit percentage decrease in our CEC business due to the same factors as noted in the three-month period discussion above. Net sales for our FRS segment increased approximately $0.3 billion, or 5% from the six-month period ended September 30, 2022, primarily driven by a low double-digit percentage increase in our Automotive business, a mid single-digit percentage increase in our Health Solutions business and a low single-digit percentage increase in our Industrial business due to strong customer demand and ramps across various end markets. Net sales for our Nextracker segment increased approximately $0.2 billion, or 21% from the six-month period ended September 30, 2022, primarily driven by the same factors as noted in the three-month period discussion above. Net sales increased $0.4 billion to $7.2 billion in the Americas, decreased $0.6 billion to $4.7 billion in Asia, and decreased $0.1 billion to $3.0 billion in Europe.

[0000866374-23-000066:mdna:61]
Our ten largest customers during the three and six-month periods ended September 29, 2023 accounted for approximately 33% of net sales. Our ten largest customers during the three and six-month periods ended September 30, 2022 accounted for approximately 35% of net sales. No customer accounted for more than 10% of net sales during the three and six-month periods ended September 29, 2023 or September 30, 2022.

[0000866374-23-000066:mdna:62]
[same as prior period, unchanged from 0000866374-23-000058:mdna:59]

[0000866374-23-000066:mdna:63]
[same as prior period, unchanged from 0000866374-23-000058:mdna:60]

[0000866374-23-000066:mdna:64]
Cost of sales during the three-month period ended September 29, 2023 totaled $6.8 billion, representing a decrease of approximately $0.4 billion, or 5% from $7.2 billion during the three-month period ended September 30, 2022. The lower cost of sales for the three-month period ended September 29, 2023 was primarily driven by decreased consolidated sales of $0.3 billion or 4%. Cost of sales in FAS for the three-month period ended September 29, 2023 decreased approximately $0.4 billion, or 10% from the three-month period ended September 30, 2022, which is relatively in line with the overall 10% decrease in FAS revenue during the same period primarily as a result of lower revenue in our Consumer Devices, Lifestyle, and CEC businesses. Cost of sales in FRS for the three-month period ended September 29, 2023 increased approximately $14 million, or 0.5% from the three-month period ended September 30, 2022, which is in line with the overall modest increase in FRS revenue during the same period, primarily as a result of higher revenue in our Automotive business. Cost of sales in our Nextracker segment for the three-month period ended September 29, 2023 increased approximately $11 million, or 3% from the three-month period ended September 30, 2022, primarily due to the 21% increase in Nextracker revenue during the same period, offset by improved profitability resulting from a decline in freight and logistics cost increases and overall better execution on our contracts.

[0000866374-23-000066:mdna:65]
Cost of sales during the six-month period ended September 29, 2023 totaled $13.5 billion, representing a decrease of approximately $0.5 billion, or 3% from $14.0 billion during the six-month period ended September 30, 2022. The lower cost of sales for the six-month period ended September 29, 2023 was primarily driven by decreased consolidated sales of $0.3 billion or 2%. Cost of sales in FAS for the six-month period ended September 29, 2023 decreased approximately $0.7 billion, or 10% from the six-month period ended September 30, 2022, which is aligned with the overall 10% decrease in FAS revenue during the same period primarily due to the drivers noted in the discussion above for the three-month period. Cost of sales in FRS for the six-month period ended September 29, 2023 increased approximately $0.3 billion, or 5% from the six-month period ended September 30, 2022, which is in line with the overall 5% increase in FRS revenue during the same period, primarily due to the drivers noted in the discussion above for the three-month period. Cost of sales in our Nextracker segment for the six-month period ended September 29, 2023 increased approximately $28 million, or 4% from the six-month period ended September 30, 2022, primarily driven by the same factors noted above in the three-month period discussion.

[0000866374-23-000066:mdna:66]
[same as prior period, unchanged from 0000866374-23-000058:mdna:62]

[0000866374-23-000066:mdna:67]
Gross profit is affected by a fluctuation in cost of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves

[0000866374-23-000066:mdna:68]
[same as prior period, unchanged from 0000866374-23-000058:mdna:88]

[0000866374-23-000066:mdna:69]
over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-23-000066:mdna:70]
Gross profit during the three-month period ended September 29, 2023 increased $0.1 billion to $0.7 billion, or 8.9% of net sales, from $0.6 billion, or 7.6% of net sales, during the three-month period ended September 30, 2022. Gross margin improved 130 basis points during the three-month period ended September 29, 2023 primarily due to favorable mix with growth in our higher-margin FRS and Nextracker segments, partially offset by unfavorable mix in our CEC business.

[0000866374-23-000066:mdna:71]
Gross profit during the six-month period ended September 29, 2023 increased $0.1 billion to $1.3 billion, or 8.5% of net sales, from $1.1 billion, or 7.5% of net sales, during the six-month period ended September 30, 2022. Gross margin improved 100 basis points during the same period due to the same factors noted above in the three-month period discussion.

[0000866374-23-000066:mdna:72]
[same as prior period, unchanged from 0000866374-23-000058:mdna:65]

[0000866374-23-000066:mdna:73]
[same as prior period, unchanged from 0000866374-23-000058:mdna:66]

[0000866374-23-000066:mdna:74]
[same as prior period, unchanged from 0000866374-23-000058:mdna:67]

[0000866374-23-000066:mdna:75]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 168 |  |  | 4.6 | % |  | $ | 170 |  |  | 4.3 | % |  | $ | 314 |  |  | 4.3 | % |  | $ | 342 |  |  | 4.3 | % |
| Flex Reliability Solutions | 171 |  |  | 5.2 | % |  | 175 |  |  | 5.3 | % |  | 336 |  |  | 5.1 | % |  | 322 |  |  | 5.1 | % |
| Nextracker | 112 |  |  | 19.5 | % |  | 43 |  |  | 9.1 | % |  | 194 |  |  | 18.4 | % |  | 73 |  |  | 8.4 | % |

[0000866374-23-000066:mdna:76]
FAS segment margin increased approximately 30 basis points, to 4.6%, for the three-month period ended September 29, 2023, from 4.3% for the three-month period ended September 30, 2022. The margin increase was primarily due to strong execution against new project ramps and product mix. The FAS segment margin remained relatively flat at 4.3% for the six-month period ended September 29, 2023 and September 30, 2022. This was primarily due to strong execution against new project ramps and product mix offset by unfavorable mix and ramp costs in CEC.

[0000866374-23-000066:mdna:77]
FRS segment margin decreased approximately 10 basis points, to 5.2% for the three-month period ended September 29, 2023, from 5.3% for the three-month period ended September 30, 2022. The decrease in FRS segment margin was primarily driven by unabsorbed costs associated with lower sales in our Industrial business. FRS segment margin remained relatively flat at 5.1% for the six-month period ended September 29, 2023 and September 30, 2022. This was driven by improving margins in our Health Solutions business due to increased productivity offset by continued project ramps and unabsorbed costs associated with lower sales in our Industrial business.

[0000866374-23-000066:mdna:78]
Nextracker segment margin increased approximately 1,040 basis points, to 19.5% for the three-month period ended September 29, 2023, from 9.1% for the three-month period ended September 30, 2022. The margin increase was driven by improved pricing, freight savings, and favorable cost absorption with increased revenue. Nextracker segment margin increased approximately 1,000 basis points, to 18.4% for the six-month period ended September 29, 2023, from 8.4% for the six-month period ended September 30, 2022. The increase in Nextracker segment margin during the six-month period is due to the same factors noted in the discussion above for the three-month period.

[0000866374-23-000066:mdna:79]
[same as prior period, unchanged from 0000866374-23-000058:mdna:72]

[0000866374-23-000066:mdna:80]
During the three and six-month periods ended September 29, 2023, we recognized approximately $3 million and $26 million of restructuring charges, respectively, primarily related to employee severance.

[0000866374-23-000066:mdna:81]
[same as prior period, unchanged from 0000866374-23-000058:mdna:74]

[0000866374-23-000066:mdna:82]
Selling, general and administrative expenses (“SG&A”) was approximately $0.3 billion, or 3.6% of net sales, during the three-month period ended September 29, 2023, increasing $27 million from approximately $0.2 billion or 3.2% of net sales, during the three-month period ended September 30, 2022. SG&A was $0.5 billion, or 3.7% of net sales, during the six-month period ended September 29, 2023, increasing $56 million from $0.5 billion or 3.2% of net sales, during the six-month period

[0000866374-23-000066:mdna:83]
ended September 30, 2022. The increase was primarily due to elevated SG&A costs to support higher revenue growth in our Nextracker business and higher labor costs.

[0000866374-23-000066:mdna:84]
[same as prior period, unchanged from 0000866374-23-000058:mdna:76]

[0000866374-23-000066:mdna:85]
Amortization of intangible assets decreased to $17 million during the three-month period ended September 29, 2023, from $21 million for the three-month period ended September 30, 2022, and decreased to $37 million during the six-month period ended September 29, 2023, from $43 million for the six-month period ended September 30, 2022, primarily due to certain intangibles now being fully amortized.

[0000866374-23-000066:mdna:86]
[same as prior period, unchanged from 0000866374-23-000058:mdna:78]

[0000866374-23-000066:mdna:87]
Interest, net was an expense of $35 million during the three-month period ended September 29, 2023 compared to an expense of $47 million during the three-month period ended September 30, 2022, primarily due to higher interest income, and lower interest expense compared to the prior year period.

[0000866374-23-000066:mdna:88]
Interest, net was an expense of $76 million during the six-month period ended September 29, 2023 compared to an expense of $96 million during the six-month period ended September 30, 2022, primarily due to higher interest income, offset by higher variable interest expense compared to the prior year period.

[0000866374-23-000066:mdna:89]
[same as prior period, unchanged from 0000866374-23-000058:mdna:80]

[0000866374-23-000066:mdna:90]
Other charges (income), net was an expense of $16 million during the three-month period ended September 29, 2023 compared to an expense of $6 million during the three-month period ended September 30, 2022, primarily due to a higher foreign exchange transaction loss recognized compared to the prior year period.

[0000866374-23-000066:mdna:91]
Other charges (income), net was an expense of $27 million during the six-month period ended September 29, 2023 compared to an income of $3 million during the six-month period ended September 30, 2022, primarily due to the same drivers noted in the discussion above.

[0000866374-23-000066:mdna:92]
[same as prior period, unchanged from 0000866374-23-000058:mdna:82]

[0000866374-23-000066:mdna:93]
[same as prior period, unchanged from 0000866374-23-000058:mdna:83]

[0000866374-23-000066:mdna:94]
The consolidated effective tax rate was (25)% and (9)% for the three and six-month periods ended September 29, 2023, and 13% and 14% for the three and six-month periods ended September 30, 2022, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, the Netherlands and Israel. The effective tax rate for the three and six-month periods ended September 29, 2023 were significantly lower than the effective tax rates for the three-month and six-month periods ended September 30, 2022 primarily due to the recording of a $140 million deferred tax asset, with an offsetting entry to income tax benefit fully attributable to noncontrolling interest in connection with Nextracker's follow-on public offering whereby Nextracker purchased additional Nextracker LLC units from a related Flex U.S. subsidiary.

[0000866374-23-000066:mdna:95]
[same as prior period, unchanged from 0000866374-23-000058:mdna:85]

[0000866374-23-000066:mdna:96]
[same as prior period, unchanged from 0000866374-23-000058:mdna:86]

[0000866374-23-000066:mdna:97]
In response to the challenging economic environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of September 29, 2023, we had cash and cash equivalents of approximately $2.9 billion and bank and other borrowings of approximately $3.4 billion. As of September 29, 2023, we had a $2.5 billion revolving credit facility that is due to mature in July 2027, and a $0.5 billion Nextracker revolving credit facility that is due to mature in February 2028, under which we had no borrowings outstanding. As of September 29, 2023, we were in

[0000866374-23-000066:mdna:98]
34

[0000866374-23-000066:mdna:99]
compliance with the covenants under all of our credit facilities and indentures; we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-23-000066:mdna:100]
In fiscal year 2024, we implemented a 10b5-1 bond buyback program, aiming to repurchase certain outstanding bonds issued by us. During the six-month period ended September 29, 2023, we repurchased approximately $8 million of the 4.750% Notes due 2025, resulting in an immaterial gain on our condensed consolidated statement of operations.

[0000866374-23-000066:mdna:101]
Cash provided by operating activities was $0.4 billion during the six-month period ended September 29, 2023, primarily driven by $0.6 billion of net income for the period plus $0.3 billion of non-cash charges such as depreciation, amortization, and stock-based compensation offset by certain changes in net working capital as discussed below.

[0000866374-23-000066:mdna:102]
We believe net working capital ("NWC") is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital increased approximately $0.2 billion to $5.4 billion as of September 29, 2023, from $5.2 billion as of March 31, 2023. The increase was primarily the result of the effect of a decrease in working capital advances of $0.3 billion and accounts payable of $0.2 billion partially offset by a reduction in inventory of $0.4 billion.

[0000866374-23-000066:mdna:103]
Cash used in investing activities was $0.3 billion during the six-month period ended September 29, 2023. This was primarily driven by $0.3 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding CEC, Automotive, Industrial, Health Solutions, and Lifestyle businesses.

[0000866374-23-000066:mdna:104]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investors. Our adjusted free cash flow for the six-month periods ended September 29, 2023 and September 30, 2022 was an inflow of $0.1 billion and an outflow of $0.1 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-23-000066:mdna:105]
|  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 363 |  |  | $ | 141 |  |
| Purchases of property and equipment | (319) |  |  | (296) |  |
| Proceeds from the disposition of property and equipment | 19 |  |  | 18 |  |
| Adjusted free cash flow | $ | 63 |  |  | $ | (137) |  |

[0000866374-23-000066:mdna:106]
Cash used by financing activities was $0.5 billion during the six-month period ended September 29, 2023, which was primarily driven by $0.5 billion of cash paid for the repurchase of our ordinary shares and $0.4 billion in repayments of bank borrowings and long-term debt, offset by $0.5 billion of net proceeds from the issuance of Nextracker shares, after the distribution to TPG and expenses.

[0000866374-23-000066:mdna:107]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of September 29, 2023 and March 31, 2023, approximately 33% and 27%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.9 billion as of March 31, 2023). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-23-000066:mdna:108]
35

[0000866374-23-000066:mdna:109]
[same as prior period, unchanged from 0000866374-23-000058:mdna:100]

[0000866374-23-000066:mdna:110]
We maintain various uncommitted short-term financing facilities including but not limited to a commercial paper program, and a revolving sale and repurchase of subordinated notes established under the asset-backed securitization ("ABS") programs, under which there were no borrowings outstanding as of September 29, 2023.

[0000866374-23-000066:mdna:111]
[same as prior period, unchanged from 0000866374-23-000058:mdna:102]

[0000866374-23-000066:mdna:112]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-23-000066:mdna:113]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $2.0 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 2, 2023. During the six-month period ended September 29, 2023, we paid $506 million to repurchase shares under the current and prior repurchase plans at an average price of $25.11 per share. As of September 29, 2023, shares in the aggregate amount of $1.8 billion were available to be repurchased under the current plan.

[0000866374-23-000066:mdna:114]
[same as prior period, unchanged from 0000866374-23-000058:mdna:105]

[0000866374-23-000066:mdna:115]
[same as prior period, unchanged from 0000866374-23-000058:mdna:106]

[0000866374-23-000066:mdna:116]
There were no material changes in our contractual obligations and commitments as of September 29, 2023.
