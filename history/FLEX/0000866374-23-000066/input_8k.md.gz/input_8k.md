# FLEX 8-K — 0000866374-23-000063 filed 2023-10-25

## item codes, every 8-K on or before 2023-10-30

- 2023-10-25 0000866374-23-000063 — 2.02, 7.01, 8.01, 9.01
- 2023-08-07 0000866374-23-000060 — 5.02, 5.07, 8.01
- 2023-07-26 0000866374-23-000054 — 2.02, 9.01
- 2023-06-30 0000866374-23-000048 — 8.01, 9.01
- 2023-06-29 0000866374-23-000043 — 8.01, 9.01
- 2023-06-26 0000866374-23-000038 — 8.01, 9.01
- 2023-06-16 0000866374-23-000035 — 5.02
- 2023-05-10 0000866374-23-000023 — 2.02, 9.01
- 2023-02-13 0001193125-23-035922 — 1.01, 9.01
- 2023-02-10 0000866374-23-000016 — 8.01, 9.01
- 2023-02-09 0000866374-23-000014 — 8.01, 9.01
- 2023-02-01 0000866374-23-000011 — 7.01, 8.01, 9.01
- 2023-01-25 0000866374-23-000004 — 2.02, 9.01
- 2022-12-07 0001104659-22-125181 — 1.01, 9.01
- 2022-12-01 0001104659-22-123665 — 8.01, 9.01
- 2022-11-17 0000866374-22-000078 — 8.01
- 2022-10-26 0000866374-22-000070 — 2.02, 9.01
- 2022-09-27 0000866374-22-000066 — 5.02, 9.01
- 2022-08-26 0000866374-22-000063 — 5.07, 8.01
- 2022-07-27 0000866374-22-000048 — 2.02, 9.01
- 2022-07-22 0000866374-22-000045 — 1.01, 1.02, 2.03, 9.01
- 2022-06-03 0000866374-22-000041 — 5.02
- 2022-05-04 0000866374-22-000030 — 2.02, 9.01
- 2022-03-30 0000866374-22-000026 — 7.01, 9.01
- 2022-03-25 0000866374-22-000022 — 5.02
- 2022-02-17 0000866374-22-000019 — 5.02
- 2022-02-02 0000866374-22-000014 — 8.01, 9.01
- 2022-01-27 0000866374-22-000010 — 5.02, 9.01
- 2022-01-26 0000866374-22-000005 — 2.02, 9.01
- 2021-12-01 0000866374-21-000065 — 7.01, 9.01
- 2021-10-27 0000866374-21-000059 — 2.02, 9.01
- 2021-10-18 0000866374-21-000054 — 7.01, 9.01
- 2021-08-05 0000866374-21-000050 — 5.07, 8.01
- 2021-07-29 0000866374-21-000040 — 2.02, 9.01
- 2021-06-15 0000866374-21-000036 — 5.02
- 2021-05-05 0000866374-21-000027 — 2.02, 9.01
- 2021-02-26 0000866374-21-000021 — 5.02
- 2021-01-28 0000866374-21-000016 — 2.02, 9.01
- 2021-01-22 0000866374-21-000012 — 5.02 — amendment of 0000866374-20-000037
- 2021-01-13 0000866374-21-000006 — 1.01, 1.02, 2.03, 9.01
- 2020-11-24 0000866374-20-000037 — 5.02, 9.01
- 2020-11-23 0000866374-20-000034 — 5.02, 7.01, 9.01
- 2020-10-29 0000866374-20-000028 — 2.02, 9.01
- 2020-09-21 0000866374-20-000021 — 5.02, 9.01
- 2020-09-18 0000866374-20-000017 — 5.02
- 2020-08-17 0001104659-20-096092 — 1.01, 8.01, 9.01
- 2020-08-11 0001104659-20-093288 — 5.02, 5.07, 9.01
- 2020-08-07 0001104659-20-092018 — 5.02, 7.01, 9.01
- 2020-07-30 0001104659-20-088503 — 2.02, 9.01
- 2020-06-09 0001104659-20-071371 — 5.02, 9.01
- 2020-06-03 0001104659-20-069435 — 5.02, 9.01
- 2020-05-12 0001104659-20-060179 — 1.01, 8.01, 9.01
- 2020-05-07 0001104659-20-058102 — 2.02, 8.01, 9.01
- 2020-04-20 0000866374-20-000005 — 5.02, 9.01 — amendment of 0001104659-20-044212
- 2020-04-07 0001104659-20-044212 — 5.02, 7.01, 9.01
- 2020-04-02 0001104659-20-042445 — 5.02, 8.01, 9.01
- 2020-03-09 0001104659-20-030489 — 7.01, 9.01
- 2020-01-30 0001104659-20-008704 — 2.02, 9.01
- 2019-11-07 0001104659-19-061133 — 8.01, 9.01
- 2019-10-24 0001104659-19-056135 — 2.02, 9.01
- 2019-08-23 0001410578-19-000891 — 3.03, 5.07, 8.01, 9.01
- 2019-08-08 0001410578-19-000722 — 8.01
- 2019-07-25 0001104659-19-041852 — 2.02, 2.05, 9.01
- 2019-06-10 0001410578-19-000371 — 5.02
- 2019-06-06 0001104659-19-034315 — 1.01, 8.01, 9.01
- 2019-05-31 0001104659-19-032835 — 8.01, 9.01
- 2019-05-30 0001104659-19-032818 — 8.01, 9.01
- 2019-05-30 0001104659-19-032593 — 8.01, 9.01
- 2019-04-30 0001104659-19-025293 — 2.02, 9.01
- 2019-03-07 0001104659-19-013420 — 5.02
- 2019-02-11 0001104659-19-006978 — 5.02, 7.01, 9.01
- 2019-02-06 0001104659-19-005884 — 5.02
- 2019-01-30 0001104659-19-004485 — 2.02, 9.01
- 2019-01-18 0001104659-19-002495 — 5.02
- 2018-12-28 0001104659-18-075143 — 5.02
- 2018-12-11 0001104659-18-072382 — 5.02
- 2018-11-15 0001104659-18-068678 — 5.02, 9.01
- 2018-10-25 0001104659-18-063948 — 2.02, 9.01
- 2018-10-25 0001104659-18-063944 — 5.02, 9.01
- 2018-08-21 0001104659-18-053031 — 5.07, 8.01, 9.01
- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2023-10-30

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0000866374-23-000063:8k_2_02:1]
EX-99.1
2
flexex991-10252023.htm
EX-99.1

[0000866374-23-000063:8k_2_02:2]
Document

[0000866374-23-000063:8k_2_02:3]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:4]
EXHIBIT 99.1

[0000866374-23-000063:8k_2_02:5]
FLEX REPORTS SECOND QUARTER FISCAL 2024 RESULTS; ANNOUNCES PLAN TO SPIN-OFF REMAINING INTEREST IN NEXTRACKER TO FLEX SHAREHOLDERS

[0000866374-23-000063:8k_2_02:6]
Austin, Texas, October 25, 2023 – Flex (NASDAQ: FLEX) today announced results for its second quarter ended September 29, 2023.

[0000866374-23-000063:8k_2_02:7]
Second Quarter Fiscal Year 2024 Highlights:

[0000866374-23-000063:8k_2_02:8]
•Net Sales: $7.5 billion

[0000866374-23-000063:8k_2_02:9]
•GAAP Operating Income: $376 million

[0000866374-23-000063:8k_2_02:10]
•Adjusted Operating Income: $439 million

[0000866374-23-000063:8k_2_02:11]
•GAAP Net Income attributable to Flex Ltd: $228 million

[0000866374-23-000063:8k_2_02:12]
•Adjusted Net Income attributable to Flex Ltd: $303 million

[0000866374-23-000063:8k_2_02:13]
•GAAP Earnings Per Share: $0.51

[0000866374-23-000063:8k_2_02:14]
•Adjusted Earnings Per Share: $0.68

[0000866374-23-000063:8k_2_02:15]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedules II and V attached to this press release.

[0000866374-23-000063:8k_2_02:16]
"Our focus on the right portfolio and margin expansion has enabled the team to deliver another strong quarter and make solid progress on our financial framework," said Revathi Advaithi, CEO of Flex. "With the announcement of our plan to spin-off our remaining interest in Nextracker, we come to the final stage of unlocking its full value. Our strategic focus remains on driving growth in targeted markets, expanding margins, and executing our capital allocation strategy.”

[0000866374-23-000063:8k_2_02:17]
Third Quarter Fiscal 2024 Guidance

[0000866374-23-000063:8k_2_02:18]
•Revenue: $6.5 billion to $6.9 billion

[0000866374-23-000063:8k_2_02:19]
•GAAP Operating Income: $210 million to $260 million

[0000866374-23-000063:8k_2_02:20]
•Adjusted Operating Income: $375 million to $425 million

[0000866374-23-000063:8k_2_02:21]
•GAAP EPS: $0.25 to $0.34

[0000866374-23-000063:8k_2_02:22]
•Adjusted EPS: $0.57 to $0.65 which excludes $0.20 for net restructuring charges, $0.09 for stock-based compensation expense, $0.03 for net intangible amortization, and ($0.01) for noncontrolling interest share of subsidiary’s non-GAAP adjustments.

[0000866374-23-000063:8k_2_02:23]
Fiscal Year 2024 Guidance Updated - Total Flex

[0000866374-23-000063:8k_2_02:24]
•Revenue: $28.1 billion to $28.8 billion

[0000866374-23-000063:8k_2_02:25]
•GAAP EPS: $1.71 to $1.89

[0000866374-23-000063:8k_2_02:26]
•Adjusted EPS: $2.49 to $2.66 which excludes $0.39 for stock-based compensation expense, $0.27 for net restructuring charges, $0.13 for net intangible amortization, and ($0.01) net of tax impact for noncontrolling interest share of subsidiary's non-GAAP adjustment.

[0000866374-23-000063:8k_2_02:27]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:28]
In addition, we are providing fiscal year 2024 guidance for Core Flex to provide further transparency in our core business trends. Core Flex represents Flex, excluding Flex’s 51.47% economic interest in Nextracker, which is currently consolidated within Flex, and which is expected to be distributed to Flex shareholders in a tax-free spin-off in Flex’s fourth quarter ending March 31, 2024. Core Flex is a non-GAAP measure that does not reflect discontinued operations presentation under GAAP.

[0000866374-23-000063:8k_2_02:29]
Fiscal Year 2024 Guidance – Core Flex

[0000866374-23-000063:8k_2_02:30]
•Revenue: $25.9 billion to $26.5 billion

[0000866374-23-000063:8k_2_02:31]
•GAAP EPS: $1.38 to $1.51

[0000866374-23-000063:8k_2_02:32]
•Adjusted EPS: $2.05 to $2.18 which excludes $0.27 for stock-based compensation expense, $0.27 for net restructuring charges and $0.13 for net intangible amortization.

[0000866374-23-000063:8k_2_02:33]
Plan to Spin-off Remaining Interest in Nextracker to Flex Shareholders

[0000866374-23-000063:8k_2_02:34]
Flex today also announced its plan to effect a spin-off of all of its remaining interest in Nextracker Inc. (“Nextracker”) to Flex shareholders on a pro rata basis.

[0000866374-23-000063:8k_2_02:35]
Flex expects that completion of the spin-off will unlock meaningful value, giving Flex shareholders direct ownership of Nextracker in a tax-free manner for U.S. federal income tax purposes and provides Flex with increased strategic flexibility.

[0000866374-23-000063:8k_2_02:36]
The spin-off will be effected pursuant to that certain Agreement and Plan of Merger (the “Merger Agreement”), entered into by Flex and Nextracker on February 7, 2023, and disclosed in connection with Nextracker’s previously completed initial public offering.  Earlier today, pursuant to the terms of the Merger Agreement, Flex delivered to Nextracker a written notice exercising Flex’s right to effect the transactions contemplated by the Merger Agreement (the “Transactions”).

[0000866374-23-000063:8k_2_02:37]
Later today, Nextracker will be filing a registration statement on Form S-4, that includes a preliminary proxy statement of Flex, which will include additional information regarding the Transactions.

[0000866374-23-000063:8k_2_02:38]
Flex currently beneficially owns approximately 51.47% of the economic interests in the business of Nextracker. As a result of the Transactions, Flex shareholders’ indirect economic interest in the business of Nextracker will become an equivalent pro rata direct ownership interest in Nextracker Class A common stock listed on the Nasdaq Global Select Market. The number of shares of Nextracker Class A common stock to be received by each Flex shareholder will be determined in accordance with the Merger Agreement. Based on applicable share counts as of Flex’s second quarter ended September 29, 2023, upon completion of the Transactions, a Flex shareholder as of the applicable record date would be expected to receive approximately 0.17 shares of Nextracker Class A common stock per Flex ordinary share held (with cash payments in lieu of any fractional shares of Nextracker Class A common stock). Following completion of the Transactions, Flex will no longer directly or indirectly hold any of the issued and outstanding shares of Nextracker or any common units of Nextracker LLC.

[0000866374-23-000063:8k_2_02:39]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:40]
The Transactions are subject to a number of conditions as set forth in the Merger Agreement, including the approval of Flex shareholders in accordance with Singapore law, and there is no assurance that any such conditions will be satisfied or waived. Accordingly, no assurance can be given that the Transactions will in fact be completed. The Transactions are currently expected to be completed in Flex's fourth quarter ending March 31, 2024.

[0000866374-23-000063:8k_2_02:41]
Advisors

[0000866374-23-000063:8k_2_02:42]
J.P. Morgan Securities LLC is serving as Flex’s financial advisor and Sidley Austin LLP is serving as Flex’s legal advisor in connection with the Transactions.

[0000866374-23-000063:8k_2_02:43]
Webcast and Conference Call

[0000866374-23-000063:8k_2_02:44]
The Flex management team will host a conference call today at 1:30 PM (PT) / 4:30 PM (ET), to review second quarter fiscal 2024 results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com. An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0000866374-23-000063:8k_2_02:45]
About Flex

[0000866374-23-000063:8k_2_02:46]
Flex (Reg. No. 199002645H) is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across 30 countries and responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets.

[0000866374-23-000063:8k_2_02:47]
Contacts

[0000866374-23-000063:8k_2_02:48]
Investors & Analysts

[0000866374-23-000063:8k_2_02:49]
David Rubin

[0000866374-23-000063:8k_2_02:50]
Vice President, Investor Relations

[0000866374-23-000063:8k_2_02:51]
(408) 577-4632

[0000866374-23-000063:8k_2_02:52]
David.Rubin@flex.com

[0000866374-23-000063:8k_2_02:53]
Media & Press

[0000866374-23-000063:8k_2_02:54]
Mark Plungy

[0000866374-23-000063:8k_2_02:55]
Director, Corporate Integrated Communications

[0000866374-23-000063:8k_2_02:56]
(408) 442-1691

[0000866374-23-000063:8k_2_02:57]
Mark.Plungy@flex.com

[0000866374-23-000063:8k_2_02:58]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:59]
Forward-Looking Statements

[0000866374-23-000063:8k_2_02:60]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:61]
customers or suppliers; the success of certain of our activities depends on our ability to protect our intellectual property rights and we may be exposed to claims of infringement or breach of license agreements; a breach of our IT or physical security systems, or violation of data privacy laws, may cause us to incur significant legal and financial exposure and disrupt our operations; physical and operational risks from natural disasters, severe weather events, or climate change; our ability to meet environmental, social and governance expectations or standards or achieve sustainability goals; we may be exposed to product liability and product warranty liability; that recently proposed changes or future changes in tax laws in certain jurisdictions where we operate could materially impact our tax expense; and the impact and effects on our business, results of operations and financial condition of a public health issue, including a pandemic, or catastrophic event.

[0000866374-23-000063:8k_2_02:62]
Additional information concerning these, and other risks is described under "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our annual report on Form 10-K for the fiscal year ended March 31, 2023 and in subsequent quarterly reports on Form 10-Q, as well as the registration statement, including the proxy statement/prospectus, and other documents filed by Flex or Nextracker, as applicable, with the U.S. Securities and Exchange Commission (the "SEC") in connection with the Transactions referred to above. The forward-looking statements in this press release are based on current expectations and Flex assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0000866374-23-000063:8k_2_02:63]
No Offer or Solicitation

[0000866374-23-000063:8k_2_02:64]
This communication is neither an offer to purchase, nor a solicitation of an offer to sell, subscribe for or buy any securities or the solicitation of any vote in any jurisdiction, nor shall there be any sale, issuance or transfer of securities in any jurisdiction in contravention of applicable law. No offer of securities shall be made except by means of a prospectus meeting the requirements of Section 10 of the Securities Act of 1933, as amended, or an exemption therefrom, and otherwise in accordance with applicable law.

[0000866374-23-000063:8k_2_02:65]
Important Additional Information

[0000866374-23-000063:8k_2_02:66]
Flex and Nextracker have prepared, and Nextracker intends to file, a registration statement on Form S-4, that includes a preliminary proxy statement of Flex and also constitutes a preliminary prospectus of Nextracker. Flex and Nextracker will also file other documents with the SEC regarding the Transactions, including the definitive proxy statement/prospectus. The information in the preliminary proxy statement/prospectus is not complete and may be changed. When available, Flex will mail the definitive proxy statement/prospectus and other relevant documents to its shareholders as of a record date to be established for voting on the Transactions. This communication is not a substitute for the definitive proxy statement/prospectus or any other document that Flex will send to its shareholders in connection with the Transactions. INVESTORS AND SECURITY HOLDERS OF FLEX ARE URGED TO

[0000866374-23-000063:8k_2_02:67]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:68]
READ THE REGISTRATION STATEMENT, THE PRELIMINARY PROXY STATEMENT/PROSPECTUS, THE DEFINITIVE PROXY STATEMENT/PROSPECTUS WHEN IT BECOMES AVAILABLE, AND ALL OTHER RELEVANT DOCUMENTS THAT ARE FILED OR WILL BE FILED WITH THE SEC, AS WELL AS ANY AMENDMENTS OR SUPPLEMENTS TO THESE DOCUMENTS, CAREFULLY AND IN THEIR ENTIRETY BECAUSE THEY CONTAIN OR WILL CONTAIN IMPORTANT INFORMATION ABOUT THE TRANSACTIONS AND RELATED MATTERS.

[0000866374-23-000063:8k_2_02:69]
Copies of the registration statement, the preliminary proxy statement/prospectus, the definitive proxy statement/prospectus and other documents filed by Flex or Nextracker with the SEC may be obtained, once available, free of charge at the SEC’s website at www.sec.gov.

[0000866374-23-000063:8k_2_02:70]
Participants in the Solicitation

[0000866374-23-000063:8k_2_02:71]
Flex, Nextracker and their respective directors, executive officers, other members of management, and employees, under SEC rules, may be deemed to be participants in the solicitation of proxies of Flex’s shareholders in connection with the Transactions. Information regarding the persons who may, under SEC rules, be deemed participants in the solicitation of Flex’s shareholders in connection with the Transactions will be in the registration statement, including the proxy statement/prospectus, when it is filed with the SEC. Investors and security holders may obtain more detailed information regarding the names and interests in the Transactions of Flex’s and Nextracker’s directors and officers in Flex’s and Nextracker’s filings with the SEC and such information will also be in the registration statement, including the proxy statement/prospectus, when it is filed with the SEC. These documents can be obtained free of charge at the SEC’s website at www.sec.gov.

[0000866374-23-000063:8k_2_02:72]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:73]
SCHEDULE I

[0000866374-23-000063:8k_2_02:74]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (2) |
| (In millions, except per share amounts) |
|  |  | Three-Month Periods Ended |
|  |  | September 29, 2023 |  | September 30, 2022 |
| GAAP: |  |  |  |
|  | Net sales | $ | 7,471 |  |  | $ | 7,766 |  |
|  | Cost of sales | 6,803 |  |  | 7,175 |  |
|  | Restructuring charges | 3 |  |  | — |  |
|  | Gross profit | 665 |  |  | 591 |  |
|  | Selling, general and administrative expenses | 272 |  |  | 245 |  |
|  | Intangible amortization | 17 |  |  | 21 |  |
|  | Operating income | 376 |  |  | 325 |  |
|  | Interest, net | 35 |  |  | 47 |  |
|  | Other charges, net | 16 |  |  | 6 |  |
|  | Income before income taxes | 325 |  |  | 272 |  |
|  | Provision for (benefit from) income taxes | (81) |  |  | 34 |  |
|  | Net income | 406 |  |  | 238 |  |
|  | Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 178 |  |  | 6 |  |
|  | Net income attributable to Flex Ltd. | $ | 228 |  |  | $ | 232 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd: |
|  | GAAP | $ | 0.51 |  |  | $ | 0.50 |  |
|  | Non-GAAP | $ | 0.68 |  |  | $ | 0.63 |  |
|  | Diluted shares used in computing per share amounts | 448 |  |  | 460 |  |
|  | See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |

[0000866374-23-000063:8k_2_02:75]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:76]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (2) |
| (In millions, except per share amounts) |
|  |  | Six-Month Periods Ended |
|  |  | September 29, 2023 |  | September 30, 2022 |
| GAAP: |  |  |  |
|  | Net sales | $ | 14,807 |  |  | $ | 15,113 |  |
|  | Cost of sales | 13,535 |  |  | 13,987 |  |
|  | Restructuring charges | 20 |  |  | — |  |
|  | Gross profit | 1,252 |  |  | 1,126 |  |
|  | Selling, general and administrative expenses | 542 |  |  | 486 |  |
|  | Restructuring charges | 6 |  |  | — |  |
|  | Intangible amortization | 37 |  |  | 43 |  |
|  | Operating income | 667 |  |  | 597 |  |
|  | Interest, net | 76 |  |  | 96 |  |
|  | Other charges (income), net | 27 |  |  | (3) |  |
|  | Income before income taxes | 564 |  |  | 504 |  |
|  | Provision for (benefit from) income taxes | (53) |  |  | 71 |  |
|  | Net income | 617 |  |  | 433 |  |
|  | Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 203 |  |  | 12 |  |
|  | Net income attributable to Flex Ltd. | $ | 414 |  |  | $ | 421 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd: |
|  | GAAP | $ | 0.92 |  |  | $ | 0.91 |  |
|  | Non-GAAP | $ | 1.24 |  |  | $ | 1.17 |  |
|  | Diluted shares used in computing per share amounts | 452 |  |  | 464 |  |
|  | See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |

[0000866374-23-000063:8k_2_02:77]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:78]
SCHEDULE II

[0000866374-23-000063:8k_2_02:79]
| FLEX |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)(2) |
| (In millions, except per share amounts) |
|  |  | Three-Month Periods Ended |
|  |  | September 29, 2023 |  | September 30, 2022 |
| GAAP operating income | $ | 376 |  |  | $ | 325 |  |
|  | Intangible amortization | 17 |  |  | 21 |  |
|  | Stock-based compensation expense | 45 |  |  | 27 |  |
|  | Restructuring charges | 1 |  |  | — |  |
|  | Legal and other | — |  |  | 2 |  |
| Non-GAAP operating income | $ | 439 |  |  | $ | 375 |  |
| GAAP provision for income taxes | $ | (81) |  |  | $ | 34 |  |
|  | Intangible amortization benefit | 3 |  |  | 3 |  |
|  | Other tax related adjustments | 136 |  |  | (1) |  |
| Non-GAAP provision for income taxes | $ | 58 |  |  | $ | 36 |  |
| GAAP net income attributable to Flex Ltd. | $ | 228 |  |  | $ | 232 |  |
|  | Intangible amortization | 17 |  |  | 21 |  |
|  | Stock-based compensation expense | 45 |  |  | 27 |  |
|  | Restructuring charges | 1 |  |  | — |  |
|  | Legal and other | — |  |  | 2 |  |
|  | Interest and other, net | 8 |  |  | 3 |  |
|  | Paid-in-kind and pre-IPO dividends paid to redeemable noncontrolling interest | — |  |  | 6 |  |
|  | Noncontrolling interest share of subsidiary's non-GAAP adjustments | 143 |  |  | — |  |
|  | Adjustments for taxes | (139) |  |  | (2) |  |
| Non-GAAP net income | $ | 303 |  |  | $ | 289 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd: |
|  | GAAP | $ | 0.51 |  |  | $ | 0.50 |  |
|  | Non-GAAP | $ | 0.68 |  |  | $ | 0.63 |  |
|  | See the accompanying notes on Schedule V attached to this press release. |

[0000866374-23-000063:8k_2_02:80]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:81]
| FLEX |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)(2) |
| (In millions, except per share amounts) * |
|  |  | Six-Month Periods Ended |
|  |  | September 29, 2023 |  | September 30, 2022 |
| GAAP operating income | $ | 667 |  |  | $ | 597 |  |
|  | Intangible amortization | 37 |  |  | 43 |  |
|  | Stock-based compensation expense | 86 |  |  | 53 |  |
|  | Restructuring charges | 24 |  |  | — |  |
|  | Legal and other | 2 |  |  | 12 |  |
| Non-GAAP operating income | $ | 816 |  |  | $ | 706 |  |
| GAAP provision for income taxes | $ | (53) |  |  | $ | 71 |  |
|  | Intangible amortization benefit | 6 |  |  | 6 |  |
|  | Other tax related adjustments | 146 |  |  | (5) |  |
| Non-GAAP provision for income taxes | $ | 99 |  |  | $ | 73 |  |
| GAAP net income attributable to Flex Ltd. | $ | 414 |  |  | $ | 421 |  |
|  | Intangible amortization | 37 |  |  | 43 |  |
|  | Stock-based compensation expense | 86 |  |  | 53 |  |
|  | Restructuring charges | 24 |  |  | — |  |
|  | Legal and other | 2 |  |  | 12 |  |
|  | Interest and other, net | 9 |  |  | 4 |  |
|  | Paid-in-kind and pre-IPO dividends paid to redeemable noncontrolling interest | — |  |  | 12 |  |
|  | Noncontrolling interest share of subsidiary's non-GAAP adjustments | 141 |  |  | — |  |
|  | Adjustments for taxes | (152) |  |  | (1) |  |
| Non-GAAP net income | $ | 561 |  |  | $ | 544 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd: |
|  | GAAP | $ | 0.92 |  |  | $ | 0.91 |  |
|  | Non-GAAP | $ | 1.24 |  |  | $ | 1.17 |  |
|  | See the accompanying notes on Schedule V attached to this press release. |
|  | *Amounts may not sum due to rounding |  |  |  |

[0000866374-23-000063:8k_2_02:82]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:83]
SCHEDULE III

[0000866374-23-000063:8k_2_02:84]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS (2) |
| (In millions) |
|  |  | As of September 29, 2023 |  | As of March 31, 2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
|  | Cash and cash equivalents | $ | 2,900 |  |  | $ | 3,294 |  |
|  | Accounts receivable, net of allowance for doubtful accounts | 3,801 |  |  | 3,739 |  |
|  | Contract assets | 577 |  |  | 541 |  |
|  | Inventories | 7,166 |  |  | 7,530 |  |
|  | Other current assets | 1,019 |  |  | 917 |  |
| Total current assets | 15,463 |  |  | 16,021 |  |
| Property and equipment, net | 2,328 |  |  | 2,349 |  |
| Operating lease right-of-use assets, net | 609 |  |  | 608 |  |
| Goodwill | 1,337 |  |  | 1,343 |  |
| Other intangible assets, net | 275 |  |  | 316 |  |
| Other assets | 956 |  |  | 758 |  |
| Total assets | $ | 20,968 |  |  | $ | 21,395 |  |
| LIABILITIES, NONCONTROLLING INTEREST AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |
|  | Bank borrowings and current portion of long-term debt | $ | — |  |  | $ | 150 |  |
|  | Accounts payable | 5,728 |  |  | 5,930 |  |
|  | Accrued payroll and benefits | 500 |  |  | 522 |  |
|  | Deferred revenue and customer working capital advances | 2,795 |  |  | 3,143 |  |
|  | Other current liabilities | 1,083 |  |  | 1,110 |  |
| Total current liabilities | 10,106 |  |  | 10,855 |  |
| Long-term debt, net of current portion | 3,412 |  |  | 3,691 |  |
| Operating lease liabilities, non-current | 497 |  |  | 506 |  |
| Other liabilities | 597 |  |  | 637 |  |
| Total liabilities | 14,612 |  |  | 15,689 |  |
| Total Flex Ltd. shareholders’ equity | 5,906 |  |  | 5,351 |  |
| Noncontrolling interest | 450 |  |  | 355 |  |
| Total shareholders’ equity | 6,356 |  |  | 5,706 |  |
| Total liabilities, noncontrolling interest, and shareholders' equity | $ | 20,968 |  |  | $ | 21,395 |  |
|  | See the accompanying notes on Schedule V attached to this press release. |  |  |

[0000866374-23-000063:8k_2_02:85]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:86]
SCHEDULE IV

[0000866374-23-000063:8k_2_02:87]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
|  |  | Six-Month Periods Ended |
|  |  | September 29, 2023 |  | September 30, 2022 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
|  | Net income | $ | 617 |  |  | $ | 433 |  |
|  | Depreciation, amortization and other impairment charges | 260 |  |  | 247 |  |
|  | Changes in working capital and other, net | (514) |  |  | (539) |  |
|  | Net cash provided by operating activities | 363 |  |  | 141 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
|  | Purchases of property and equipment | (319) |  |  | (296) |  |
|  | Proceeds from the disposition of property and equipment | 19 |  |  | 18 |  |
|  | Acquisition of businesses, net of cash acquired | — |  |  | 4 |  |
|  | Other investing activities, net | 3 |  |  | 3 |  |
|  | Net cash used in investing activities | (297) |  |  | (271) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
|  | Proceeds from bank borrowings and long-term debt | 2 |  |  | — |  |
|  | Repayments of bank borrowings and long-term debt | (398) |  |  | (39) |  |
|  | Payments for repurchases of ordinary shares | (506) |  |  | (253) |  |
|  | Proceeds from issuances of Nextracker shares | 552 |  |  | — |  |
|  | Payment for purchase of Nextracker LLC units from TPG | (57) |  |  | — |  |
|  | Other financing activities, net | (53) |  |  | (4) |  |
|  | Net cash used in financing activities | (460) |  |  | (296) |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | (85) |  |
|  | Net decrease in cash and cash equivalents | (394) |  |  | (511) |  |
|  | Cash and cash equivalents, beginning of period | 3,294 |  |  | 2,964 |  |
|  | Cash and cash equivalents, end of period | $ | 2,900 |  |  | $ | 2,453 |  |

[0000866374-23-000063:8k_2_02:88]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:89]
SCHEDULE V

[0000866374-23-000063:8k_2_02:90]
FLEX AND SUBSIDIARIES

[0000866374-23-000063:8k_2_02:91]
NOTES TO SCHEDULES I, II, and III

[0000866374-23-000063:8k_2_02:92]
(1) To supplement Flex’s unaudited selected financial data presented consistent with U.S. Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges and gains, including non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share. These supplemental measures exclude certain legal and other charges, restructuring charges, customer-related asset impairments (recoveries), stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP and may be different from non-GAAP measures used by other companies. We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures. The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures. We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0000866374-23-000063:8k_2_02:93]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures. Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation. Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results. We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0000866374-23-000063:8k_2_02:94]
•the ability to make more meaningful period-to-period comparisons of the Company’s ongoing operating results;

[0000866374-23-000063:8k_2_02:95]
•the ability to better identify trends in the Company’s underlying business and perform related trend analysis;

[0000866374-23-000063:8k_2_02:96]
•a better understanding of how management plans and measures the Company’s underlying business; and

[0000866374-23-000063:8k_2_02:97]
•an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0000866374-23-000063:8k_2_02:98]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0000866374-23-000063:8k_2_02:99]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of unvested restricted share unit and stock option awards granted to employees and assumed in business acquisitions. The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types. In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0000866374-23-000063:8k_2_02:100]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:101]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions. The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures. The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0000866374-23-000063:8k_2_02:102]
Restructuring charges include severance charges at existing sites and corporate SG&A functions as well as asset impairment, and other charges related to the closures and consolidations of certain operating sites and targeted activities to restructure the business. These costs may vary in size based on the Company’s initiatives, are not directly related to ongoing or core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0000866374-23-000063:8k_2_02:103]
During the three and six-month periods ended September 29, 2023, the Company recognized approximately $1 million and $24 million of restructuring charges respectively, most of which related to employee severance. No such charges were recognized for the three and six-month periods ended September 30, 2022.

[0000866374-23-000063:8k_2_02:104]
Legal and other consist primarily of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset impairments (recoveries). During the first half of fiscal year 2024 and 2023, the Company accrued for certain loss contingencies where losses were considered probable and estimable. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0000866374-23-000063:8k_2_02:105]
Interest and other, net consist of various other types of items that are not directly related to ongoing or core business results, such as the gain or losses related to certain divestitures, currency translation reserve write-offs upon liquidation of certain legal entities, debt extinguishment costs and impairment charges or gains associated with certain non-core investments. The Company excludes these items because they are not related to the Company’s ongoing operating performance or do not affect core operations. Excluding these amounts provides investors with a basis to compare Company performance against the performance of other companies without this variability.

[0000866374-23-000063:8k_2_02:106]
Paid-in-kind and pre-IPO dividends paid to redeemable noncontrolling interest relates to dividends paid to TPG Rise Flash, L.P. ("TPG Rise"). Prior to the Nextracker IPO, pro-rated 5% annual preferred dividends were paid-in-kind to TPG Rise totaling $12 million for the first half of fiscal year 2023. No such charges were recorded in fiscal year 2024.

[0000866374-23-000063:8k_2_02:107]
Noncontrolling interest share of subsidiary’s non-GAAP adjustments represents the share of non-GAAP adjustments attributable to noncontrolling interest. During the three and six-month periods ended September 29, 2023, $143 million and $141 million were recorded as noncontrolling interest; of which ($2) million was related to after-tax Nextracker stock base compensation expense during first quarter of fiscal year 2024, and $143 million net in the second quarter, primarily relating to tax benefits on the Nextracker follow-on offering.

[0000866374-23-000063:8k_2_02:108]
P R E S S   R E L E A S E

[0000866374-23-000063:8k_2_02:109]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies or other non-recurring tax charges, when applicable. During the three and six-month periods ended September 29, 2023, the Company recognized a ($139) million and ($152) million net tax benefit respectively, of which ($6) million and ($19) million are related to tax effects of various adjustments that are incorporated into Non-GAAP measures on restructuring and other for three and six-month periods ended September 29, 2023, respectively, ($128) million related to tax adjustments on Nextracker follow-on offering, and ($5) million related to other discrete tax items.

[0000866374-23-000063:8k_2_02:110]
(2)    Noncontrolling interests have been included on the consolidated balance sheets as components of redeemable noncontrolling interest and total shareholders' equity. As a result of the Nextracker’s February 13, 2023 IPO, the redeemable noncontrolling interest are not applicable for the period ending September 29, 2023. The amount of consolidated net income attributable to Flex Ltd. and to the noncontrolling interest and redeemable noncontrolling interest are presented in the consolidated statements of operations. In the fourth quarter of fiscal year 2023, Nextracker Inc. completed the Nextracker IPO through a series of reorganization transactions that resulted in Nextracker Inc. having an umbrella partnership C corporation ("Up-C") structure and the conversion of redeemable noncontrolling interest to noncontrolling interest.

[0000866374-23-000063:8k_2_02:111]
Upon the IPO, Flex recorded a noncontrolling interest within shareholders equity, reflecting the portion of Nextracker that is not owned by Flex. On a subsequent measurement basis, the carrying value of this noncontrolling interest is adjusted for earnings attributable to the noncontrolling interest.

[0000866374-23-000063:8k_2_02:112]
As of September 29, 2023 and March 31, 2023, the carrying value of noncontrolling interest were $450 million and $355 million, respectively. Net Income attributable to noncontrolling interest and redeemable noncontrolling interest was $203 million and $12 million for the first half of fiscal year 2024 and 2023, respectively.
