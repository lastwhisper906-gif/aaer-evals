# FLEX note change history — 0000866374-23-000058 → 0000866374-23-000066


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-10-30):
[0000866374-23-000066:note_history:1]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $83 million based on the exchange rate as of September 29, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $12 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $52 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes that it has meritorious defenses to each of these assessments and will continue to vigorously oppose all of them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.
  (was, 2023-07-31, similarity 0.9312):
[0000866374-23-000058:note_history:1]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $86 million based on the exchange rate as of June 30, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $13 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $54 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-10-30):
[0000866374-23-000066:note_history:2]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of September 29, 2023, Flex's three operating and reportable segments were as follows:
  (was, 2023-07-31, similarity 0.9929):
[0000866374-23-000058:note_history:2]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of June 30, 2023, Flex's three operating and reportable segments were as follows:

- changed (2023-10-30):
[0000866374-23-000066:note_history:3]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 29, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.
  (was, 2023-07-31, similarity 0.7733):
[0000866374-23-000058:note_history:3]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

- changed (2023-10-30):
[0000866374-23-000066:note_history:4]
The first quarters for fiscal years 2024 and 2023 ended on June 30, 2023, which is comprised of 91 days in the period, and July 1, 2022, which is comprised of 92 days in the period, respectively. The second quarters for fiscal years 2024 and 2023 ended on September 29, 2023 and September 30, 2022, respectively, which are comprised of 91 days in both periods.
  (was, 2023-07-31, similarity 0.668):
[0000866374-23-000058:note_history:4]
The first quarters for fiscal years 2024 and 2023 ended on June 30, 2023, which is comprised of 91 days in the period, and July 1, 2022, which is comprised of 92 days, respectively.

- changed (2023-10-30):
[0000866374-23-000066:note_history:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest. A controlling financial interest may exist in variable interest entities (“VIEs”),
  (was, 2023-07-31, similarity 0.8686):
[0000866374-23-000058:note_history:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest.  A controlling financial interest may also exist in variable interest entities (“VIEs”), through governance provisions and arrangements to provide services to VIEs.

- changed (2023-10-30):
[0000866374-23-000066:note_history:6]
through governance provisions and arrangements to provide services to VIEs. The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The condensed consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of September 29, 2023, we presented noncontrolling interest as permanent equity in the condensed balance sheets, reflecting the equity held by other parties. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the condensed consolidated statements of operations.
  (was, 2023-07-31, similarity 0.9586):
[0000866374-23-000058:note_history:6]
The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The condensed consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of June 30, 2023, we presented noncontrolling interest as permanent equity in the condensed balance sheets, reflecting the equity held by other parties. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the condensed consolidated statements of operations.

- changed (2023-10-30):
[0000866374-23-000066:note_history:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas war), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2023-07-31, similarity 0.9862):
[0000866374-23-000058:note_history:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- changed (2023-10-30):
[0000866374-23-000066:note_history:8]
Recently Adopted Accounting Pronouncement
  (was, 2023-07-31, similarity 0.988):
[0000866374-23-000058:note_history:8]
Recently Adopted Accounting Pronouncements

- changed (2023-10-30):
[0000866374-23-000066:note_history:9]
rollforward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the six-month period ended September 29, 2023 is as follows.
  (was, 2023-07-31, similarity 0.9426):
[0000866374-23-000058:note_history:9]
rollforward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the three-month period ended June 30, 2023 is as follows.

- changed (2023-10-30):
[0000866374-23-000066:note_history:10]
|  | Six-Month Period Ended |
|  | September 29, 2023 |
|  | (In millions) |
| Confirmed obligations outstanding at the beginning of the period | $ | 275 |  |
| Invoices confirmed during the period | 605 |  |
| Confirmed invoices paid during the period | (556) |  |
| Foreign currency exchange impact | — |  |
| Confirmed obligations outstanding at the end of the period | $ | 324 |  |
  (was, 2023-07-31, similarity 0.9683):
[0000866374-23-000058:note_history:10]
|  | Three-Month Period Ended |
|  | June 30, 2023 |
|  | (In millions) |
| Confirmed obligations outstanding at the beginning of the period | $ | 275 |  |
| Invoices confirmed during the period | 272 |  |
| Confirmed invoices paid during the period | (279) |  |
| Foreign currency exchange impact | 3 |  |
| Confirmed obligations outstanding at the end of the period | $ | 271 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-30):
[0000866374-23-000066:note_history:11]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 29, 2023 and March 31, 2023 are as follows:
  (was, 2023-07-31, similarity 0.9528):
[0000866374-23-000058:note_history:11]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 30, 2023 and March 31, 2023 are as follows:

- changed (2023-10-30):
[0000866374-23-000066:note_history:12]
|  | Maturity Date |  | As of September 29, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 591 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 684 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 683 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 268 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (19) |  |  | (21) |  |
|  |  |  | 3,412 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | — |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,412 |  |  | $ | 3,691 |  |
  (was, 2023-07-31, similarity 0.6237):
[0000866374-23-000058:note_history:12]
|  | Maturity Date |  | As of June 30, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 597 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 685 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 658 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 684 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan | November 2023 |  | 150 |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 294 |  |  | 284 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (20) |  |  | (21) |  |
|  |  |  | 3,595 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (151) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,444 |  |  | $ | 3,691 |  |

- added (2023-10-30):
[0000866374-23-000066:note_history:13]
(3)During the second quarter of fiscal year 2024, the Company repaid the Delayed Draw Term Loan for approximately $150 million.

- changed (2023-10-30):
[0000866374-23-000066:note_history:14]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.7% as of September 29, 2023 and March 31, 2023, respectively.
  (was, 2023-07-31, similarity 0.9565):
[0000866374-23-000058:note_history:14]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.7% as of June 30, 2023 and March 31, 2023, respectively.

- changed (2023-10-30):
[0000866374-23-000066:note_history:15]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 29, 2023 are as follows:
  (was, 2023-07-31, similarity 0.9479):
[0000866374-23-000058:note_history:15]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 30, 2023 are as follows:

- changed (2023-10-30):
[0000866374-23-000066:note_history:16]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | — |  |
| 2026 |  | 1,276 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,608 |  |
| Total |  | $ | 3,431 |  |
  (was, 2023-07-31, similarity 0.9946):
[0000866374-23-000058:note_history:16]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | 151 |  |
| 2025 |  | — |  |
| 2026 |  | 1,282 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,635 |  |
| Total |  | $ | 3,615 |  |

- changed (2023-10-30):
[0000866374-23-000066:note_history:17]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2024.
  (was, 2023-07-31, similarity 0.9733):
[0000866374-23-000058:note_history:17]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2024.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-30):
[0000866374-23-000066:note_history:18]
|  | As of September 29, 2023 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| JPY Term Loan due April 2024 | $ | — |  |  | $ | — |  |  | $ | 253 |  |  | $ | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 591 |  |  | 577 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 684 |  |  | 648 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 394 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 657 |  |  | 613 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 683 |  |  | 637 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan due November 2023 | — |  |  | — |  |  | 150 |  |  | 150 |  |  | Level 2 |
| Nextracker Term Loan due February 2028 | 150 |  |  | 148 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 268 |  |  | 196 |  |  | 284 |  |  | 196 |  |  | Level 2 |
  (was, 2023-07-31, similarity 0.9813):
[0000866374-23-000058:note_history:18]
|  | As of June 30, 2023 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| JPY Term Loan due April 2024 | $ | — |  |  | $ | — |  |  | $ | 253 |  |  | $ | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 597 |  |  | 585 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 685 |  |  | 654 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 404 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 658 |  |  | 630 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 684 |  |  | 663 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan due November 2023 | 150 |  |  | 150 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| Nextracker Term Loan due February 2028 | 150 |  |  | 146 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 294 |  |  | 215 |  |  | 284 |  |  | 196 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-30):
[0000866374-23-000066:note_history:19]
Bank borrowings and long-term debt as of September 29, 2023 and March 31, 2023 are as follows:
  (was, 2023-07-31, similarity 0.9325):
[0000866374-23-000058:note_history:19]
Bank borrowings and long-term debt as of June 30, 2023 and March 31, 2023 are as follows:

- changed (2023-10-30):
[0000866374-23-000066:note_history:20]
|  | Maturity Date |  | As of September 29, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 591 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 684 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 683 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 268 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (19) |  |  | (21) |  |
|  |  |  | 3,412 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | — |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,412 |  |  | $ | 3,691 |  |
  (was, 2023-07-31, similarity 0.6237):
[0000866374-23-000058:note_history:20]
|  | Maturity Date |  | As of June 30, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 597 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 685 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 658 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 684 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan | November 2023 |  | 150 |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 294 |  |  | 284 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (20) |  |  | (21) |  |
|  |  |  | 3,595 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (151) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,444 |  |  | $ | 3,691 |  |

- changed (2023-10-30):
[0000866374-23-000066:note_history:21]
(2)During the first quarter of fiscal year 2024, the Company repaid the JPY Term Loan for approximately $241 million. In addition, the Company also settled the associated USD JPY cross currency swap for approximately $60 million. 
(3)During the second quarter of fiscal year 2024, the Company repaid the Delayed Draw Term Loan for approximately $150 million.
  (was, 2023-07-31, similarity 0.7845):
[0000866374-23-000058:note_history:21]
(2)During the first quarter of fiscal year 2024, the Company repaid the JPY Term Loan for approximately $241 million. In addition, the Company also settled the associated USD JPY cross currency swap for approximately $60 million.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-30):
[0000866374-23-000066:note_history:22]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 29, 2023 are as follows:
  (was, 2023-07-31, similarity 0.9479):
[0000866374-23-000058:note_history:22]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 30, 2023 are as follows:

- changed (2023-10-30):
[0000866374-23-000066:note_history:23]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | — |  |
| 2026 |  | 1,276 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,608 |  |
| Total |  | $ | 3,431 |  |
  (was, 2023-07-31, similarity 0.9946):
[0000866374-23-000058:note_history:23]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | 151 |  |
| 2025 |  | — |  |
| 2026 |  | 1,282 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,635 |  |
| Total |  | $ | 3,615 |  |

- changed (2023-10-30):
[0000866374-23-000066:note_history:24]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2024.
  (was, 2023-07-31, similarity 0.9733):
[0000866374-23-000058:note_history:24]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2024.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-10-30):
[0000866374-23-000066:note_history:25]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 29, 2023 and September 30, 2022, respectively.
  (was, 2023-07-31, similarity 0.92):
[0000866374-23-000058:note_history:25]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 30, 2023 and July 1, 2022, respectively.

- changed (2023-10-30):
[0000866374-23-000066:note_history:26]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,280 |  |  | $ | 3,787 |  |  | $ | 6,716 |  |  | $ | 7,566 |  |
| Over time | 338 |  |  | 217 |  |  | 503 |  |  | 429 |  |
| Total | 3,618 |  |  | 4,004 |  |  | 7,219 |  |  | 7,995 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,144 |  |  | 3,110 |  |  | 6,276 |  |  | 5,900 |  |
| Over time | 170 |  |  | 189 |  |  | 329 |  |  | 368 |  |
| Total | 3,314 |  |  | 3,299 |  |  | 6,605 |  |  | 6,268 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 21 |  |  | 10 |  |  | 27 |  |  | 33 |  |
| Over time | 552 |  |  | 463 |  |  | 1,026 |  |  | 835 |  |
| Total | 573 |  |  | 473 |  |  | 1,053 |  |  | 868 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,411 |  |  | 6,897 |  |  | 12,949 |  |  | 13,481 |  |
| Over time | 1,060 |  |  | 869 |  |  | 1,858 |  |  | 1,632 |  |
| Total | $ | 7,471 |  |  | $ | 7,766 |  |  | $ | 14,807 |  |  | $ | 15,113 |  |
  (was, 2023-07-31, similarity 0.6816):
[0000866374-23-000058:note_history:26]
|  | Three-Month Periods Ended |  |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,436 |  |  | $ | 3,779 |  |  |  |  |  |
| Over time | 165 |  |  | 212 |  |  |  |  |  |
| Total | 3,601 |  |  | 3,991 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,132 |  |  | 2,790 |  |  |  |  |  |
| Over time | 159 |  |  | 179 |  |  |  |  |  |
| Total | 3,291 |  |  | 2,969 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 23 |  |  |  |  |  |
| Over time | 474 |  |  | 372 |  |  |  |  |  |
| Total | 480 |  |  | 395 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (36) |  |  | (8) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (36) |  |  | (8) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,538 |  |  | 6,584 |  |  |  |  |  |
| Over time | 798 |  |  | 763 |  |  |  |  |  |
| Total | $ | 7,336 |  |  | $ | 7,347 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-10-30):
[0000866374-23-000066:note_history:27]
REVENUE 
Contract Balances
  (was, 2023-07-31, similarity 0.8095):
[0000866374-23-000058:note_history:27]
Contract Balances

- changed (2023-10-30):
[0000866374-23-000066:note_history:28]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional and invoiced.
  (was, 2023-07-31, similarity 0.9767):
[0000866374-23-000058:note_history:28]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional.

- added (2023-10-30):
[0000866374-23-000066:note_history:29]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $904 million and $885 million as of September 29, 2023 and March 31, 2023, respectively, of which $796 million and $795 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2023-10-30):
[0000866374-23-000066:note_history:30]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 29, 2023 and September 30, 2022, respectively.
  (was, 2023-07-31, similarity 0.92):
[0000866374-23-000058:note_history:30]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 30, 2023 and July 1, 2022, respectively.

- changed (2023-10-30):
[0000866374-23-000066:note_history:31]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,280 |  |  | $ | 3,787 |  |  | $ | 6,716 |  |  | $ | 7,566 |  |
| Over time | 338 |  |  | 217 |  |  | 503 |  |  | 429 |  |
| Total | 3,618 |  |  | 4,004 |  |  | 7,219 |  |  | 7,995 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,144 |  |  | 3,110 |  |  | 6,276 |  |  | 5,900 |  |
| Over time | 170 |  |  | 189 |  |  | 329 |  |  | 368 |  |
| Total | 3,314 |  |  | 3,299 |  |  | 6,605 |  |  | 6,268 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 21 |  |  | 10 |  |  | 27 |  |  | 33 |  |
| Over time | 552 |  |  | 463 |  |  | 1,026 |  |  | 835 |  |
| Total | 573 |  |  | 473 |  |  | 1,053 |  |  | 868 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,411 |  |  | 6,897 |  |  | 12,949 |  |  | 13,481 |  |
| Over time | 1,060 |  |  | 869 |  |  | 1,858 |  |  | 1,632 |  |
| Total | $ | 7,471 |  |  | $ | 7,766 |  |  | $ | 14,807 |  |  | $ | 15,113 |  |
  (was, 2023-07-31, similarity 0.6816):
[0000866374-23-000058:note_history:31]
|  | Three-Month Periods Ended |  |  |
|  | June 30, 2023 |  | July 1, 2022 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,436 |  |  | $ | 3,779 |  |  |  |  |  |
| Over time | 165 |  |  | 212 |  |  |  |  |  |
| Total | 3,601 |  |  | 3,991 |  |  |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,132 |  |  | 2,790 |  |  |  |  |  |
| Over time | 159 |  |  | 179 |  |  |  |  |  |
| Total | 3,291 |  |  | 2,969 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 23 |  |  |  |  |  |
| Over time | 474 |  |  | 372 |  |  |  |  |  |
| Total | 480 |  |  | 395 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (36) |  |  | (8) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (36) |  |  | (8) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,538 |  |  | 6,584 |  |  |  |  |  |
| Over time | 798 |  |  | 763 |  |  |  |  |  |
| Total | $ | 7,336 |  |  | $ | 7,347 |  |  |  |  |  |

- removed (2023-10-30):
[0000866374-23-000058:note_history:32]
REVENUE 
Revenue Recognition

- removed (2023-10-30):
[0000866374-23-000058:note_history:33]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

- removed (2023-10-30):
[0000866374-23-000058:note_history:34]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract are transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- removed (2023-10-30):
[0000866374-23-000058:note_history:35]
Customer Contracts and Related Obligations

- removed (2023-10-30):
[0000866374-23-000058:note_history:36]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the condensed consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

- removed (2023-10-30):
[0000866374-23-000058:note_history:37]
Performance Obligations

- removed (2023-10-30):
[0000866374-23-000058:note_history:38]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

- removed (2023-10-30):
[0000866374-23-000058:note_history:39]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

- removed (2023-10-30):
[0000866374-23-000058:note_history:40]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

- removed (2023-10-30):
[0000866374-23-000058:note_history:41]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $897 million and $885 million as of June 30, 2023 and March 31, 2023, respectively, of which $802 million and $795 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-10-30):
[0000866374-23-000066:note_history:42]
SUBSEQUENT EVENTS
On October 25, 2023, Flex announced its plan to effect a spin-off of all of its remaining interests in Nextracker to Flex shareholders on a pro rata basis pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023 (the “Merger Agreement”). The spin-off is subject to a number of conditions as set forth in the Merger Agreement, including the approval of Flex shareholders in accordance with Singapore law, and there is no assurance that any such conditions will be satisfied or waived. The spin-off is currently expected to be completed in Flex’s fourth quarter ending March 31, 2024.

- added (2023-10-30):
[0000866374-23-000066:note_history:43]
On October 25, 2023, the Company’s management committed to targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. While a detailed action plan has not been finalized, the Company currently estimates charges of approximately $100 million will be recognized in the third quarter of the fiscal year ending March 31, 2024. The charges are expected to primarily relate to employee termination benefits and are expected to be settled in cash in the fiscal year ending March 31, 2024.

- removed (2023-10-30):
[0000866374-23-000058:note_history:44]
SUBSEQUENT EVENTSOn July 3, 2023, the Company's subsidiary Nextracker completed a follow-on offering to its IPO, which was completed on February 13, 2023, and issued 15,631,562 shares of Class A common stock and received net proceeds of $551 million. The entire net proceeds were used by Nextracker to acquire 14,025,000 Nextracker LLC common units from Yuma, Inc., the Company’s indirect wholly-owned subsidiary, and 1,606,562 Nextracker LLC common units from TPG Rise Flash, L.P., an affiliate of the global alternative asset management firm TPG. As a result of the repurchase of Nextracker LLC common units by Nextracker, 15,631,562 shares of Nextracker Class B common stock were cancelled. Subsequent to the follow-on offering, Flex owned 74,432,619 shares of Class B common stock, representing 51.5% of the total outstanding shares of Nextracker common stock and, accordingly, still controls Nextracker. The Company received approximately $495 million from the follow-on offering, after distribution of net proceeds to TPG and expenses.
