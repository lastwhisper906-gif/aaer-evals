# FLEX notes — 0000866374-23-000066


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-23-000066:notes:1]
[same as prior period, unchanged from 0000866374-23-000058:notes:1]

[0000866374-23-000066:notes:2]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of September 29, 2023, Flex's three operating and reportable segments were as follows:

[0000866374-23-000066:notes:3]
[same as prior period, unchanged from 0000866374-23-000058:notes:3]

[0000866374-23-000066:notes:4]
[same as prior period, unchanged from 0000866374-23-000058:notes:4]

[0000866374-23-000066:notes:5]
[same as prior period, unchanged from 0000866374-23-000058:notes:5]

[0000866374-23-000066:notes:6]
[same as prior period, unchanged from 0000866374-23-000058:notes:6]

[0000866374-23-000066:notes:7]
[same as prior period, unchanged from 0000866374-23-000058:notes:7]

[0000866374-23-000066:notes:8]
[same as prior period, unchanged from 0000866374-23-000058:notes:8]

[0000866374-23-000066:notes:9]
[same as prior period, unchanged from 0000866374-23-000058:notes:9]

[0000866374-23-000066:notes:10]
[same as prior period, unchanged from 0000866374-23-000058:notes:10]

[0000866374-23-000066:notes:11]
[same as prior period, unchanged from 0000866374-23-000058:notes:11]

[0000866374-23-000066:notes:12]
[same as prior period, unchanged from 0000866374-23-000058:notes:12]

[0000866374-23-000066:notes:13]
[same as prior period, unchanged from 0000866374-23-000058:notes:13]

[0000866374-23-000066:notes:14]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 29, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

[0000866374-23-000066:notes:15]
The first quarters for fiscal years 2024 and 2023 ended on June 30, 2023, which is comprised of 91 days in the period, and July 1, 2022, which is comprised of 92 days in the period, respectively. The second quarters for fiscal years 2024 and 2023 ended on September 29, 2023 and September 30, 2022, respectively, which are comprised of 91 days in both periods.

[0000866374-23-000066:notes:16]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest. A controlling financial interest may exist in variable interest entities (“VIEs”),

[0000866374-23-000066:notes:17]
through governance provisions and arrangements to provide services to VIEs. The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The condensed consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of September 29, 2023, we presented noncontrolling interest as permanent equity in the condensed balance sheets, reflecting the equity held by other parties. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the condensed consolidated statements of operations.

[0000866374-23-000066:notes:18]
[same as prior period, unchanged from 0000866374-23-000058:notes:18]

[0000866374-23-000066:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas war), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-23-000066:notes:20]
Recently Adopted Accounting Pronouncement

[0000866374-23-000066:notes:21]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company adopted the guidance retrospectively during the first quarter of fiscal year 2024, including a rollforward of changes in those obligations, with immaterial impacts on its condensed consolidated financial statements.

[0000866374-23-000066:notes:22]
[same as prior period, unchanged from 0000866374-23-000058:notes:22]

[0000866374-23-000066:notes:23]
[same as prior period, unchanged from 0000866374-23-000058:notes:23]

[0000866374-23-000066:notes:24]
rollforward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the six-month period ended September 29, 2023 is as follows.

[0000866374-23-000066:notes:25]
|  | Six-Month Period Ended |
|  | September 29, 2023 |
|  | (In millions) |
| Confirmed obligations outstanding at the beginning of the period | $ | 275 |  |
| Invoices confirmed during the period | 605 |  |
| Confirmed invoices paid during the period | (556) |  |
| Foreign currency exchange impact | — |  |
| Confirmed obligations outstanding at the end of the period | $ | 324 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-23-000066:notes:26]
[same as prior period, unchanged from 0000866374-23-000058:notes:27]

[0000866374-23-000066:notes:27]
[same as prior period, unchanged from 0000866374-23-000058:notes:28]

[0000866374-23-000066:notes:28]
|  | As of September 29, 2023 |  | As of March 31, 2023 |
|  | (In millions) |
| Raw materials | $ | 5,658 |  |  | $ | 6,140 |  |
| Work-in-progress | 707 |  |  | 709 |  |
| Finished goods | 801 |  |  | 681 |  |
|  | $ | 7,166 |  |  | $ | 7,530 |  |

[0000866374-23-000066:notes:29]
[same as prior period, unchanged from 0000866374-23-000058:notes:30]

[0000866374-23-000066:notes:30]
During the six-month period ended September 29, 2023, there was no material activity in the Company's goodwill account for each of its reportable segments, other than foreign currency translation adjustments of $6 million, which primarily impacted the FRS segment.

[0000866374-23-000066:notes:31]
[same as prior period, unchanged from 0000866374-23-000058:notes:32]

[0000866374-23-000066:notes:32]
|  | As of September 29, 2023 |  | As of March 31, 2023 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 345 |  |  | $ | (199) |  |  | $ | 146 |  |  | $ | 373 |  |  | $ | (204) |  |  | $ | 169 |  |
| Licenses and other intangibles | 293 |  |  | (164) |  |  | 129 |  |  | 299 |  |  | (152) |  |  | 147 |  |
| Total | $ | 638 |  |  | $ | (363) |  |  | $ | 275 |  |  | $ | 672 |  |  | $ | (356) |  |  | $ | 316 |  |

[0000866374-23-000066:notes:33]
[same as prior period, unchanged from 0000866374-23-000058:notes:34]

[0000866374-23-000066:notes:34]
[same as prior period, unchanged from 0000866374-23-000058:notes:35]

[0000866374-23-000066:notes:35]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | 33 |  |
| 2025 |  | 62 |  |
| 2026 |  | 42 |  |
| 2027 |  | 35 |  |
| 2028 |  | 27 |  |
| Thereafter |  | 76 |  |
| Total amortization expense |  | $ | 275 |  |

[0000866374-23-000066:notes:36]
[same as prior period, unchanged from 0000866374-23-000058:notes:37]

[0000866374-23-000066:notes:37]
(1)Represents estimated amortization for the remaining fiscal six-month period ending March 31, 2024.

[0000866374-23-000066:notes:38]
[same as prior period, unchanged from 0000866374-23-000058:notes:39]

[0000866374-23-000066:notes:39]
Customer working capital advances were $2.0 billion and $2.3 billion, as of September 29, 2023 and March 31, 2023, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-23-000066:notes:40]
[same as prior period, unchanged from 0000866374-23-000058:notes:41]

[0000866374-23-000066:notes:41]
Other current liabilities include customer-related accruals of $242 million and $313 million as of September 29, 2023 and March 31, 2023, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-23-000066:notes:42]
REVENUE 
Contract Balances

[0000866374-23-000066:notes:43]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional and invoiced.

[0000866374-23-000066:notes:44]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $904 million and $885 million as of September 29, 2023 and March 31, 2023, respectively, of which $796 million and $795 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-23-000066:notes:45]
[same as prior period, unchanged from 0000866374-23-000058:notes:55]

[0000866374-23-000066:notes:46]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 29, 2023 and September 30, 2022, respectively.

[0000866374-23-000066:notes:47]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,280 |  |  | $ | 3,787 |  |  | $ | 6,716 |  |  | $ | 7,566 |  |
| Over time | 338 |  |  | 217 |  |  | 503 |  |  | 429 |  |
| Total | 3,618 |  |  | 4,004 |  |  | 7,219 |  |  | 7,995 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,144 |  |  | 3,110 |  |  | 6,276 |  |  | 5,900 |  |
| Over time | 170 |  |  | 189 |  |  | 329 |  |  | 368 |  |
| Total | 3,314 |  |  | 3,299 |  |  | 6,605 |  |  | 6,268 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 21 |  |  | 10 |  |  | 27 |  |  | 33 |  |
| Over time | 552 |  |  | 463 |  |  | 1,026 |  |  | 835 |  |
| Total | 573 |  |  | 473 |  |  | 1,053 |  |  | 868 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,411 |  |  | 6,897 |  |  | 12,949 |  |  | 13,481 |  |
| Over time | 1,060 |  |  | 869 |  |  | 1,858 |  |  | 1,632 |  |
| Total | $ | 7,471 |  |  | $ | 7,766 |  |  | $ | 14,807 |  |  | $ | 15,113 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-23-000066:notes:48]
[same as prior period, unchanged from 0000866374-23-000058:notes:58]

[0000866374-23-000066:notes:49]
Flex historically maintains stock-based compensation plans at a corporate level. The Company's primary plan used for granting equity compensation awards is the Company's 2017 Equity Incentive Plan (the "2017 Plan"). During the fiscal year 2023, Nextracker granted equity compensation awards to Nextracker employees under the 2022 Nextracker Inc. Equity Incentive Plan (the "2022 Nextracker Plan"), which is administered by Nextracker, a majority-owned subsidiary of the Company.

[0000866374-23-000066:notes:50]
[same as prior period, unchanged from 0000866374-23-000058:notes:60]

[0000866374-23-000066:notes:51]
[same as prior period, unchanged from 0000866374-23-000058:notes:61]

[0000866374-23-000066:notes:52]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
|  | (In millions) |
| Cost of sales | $ | 10 |  |  | $ | 7 |  |  | $ | 19 |  |  | $ | 14 |  |
| Selling, general and administrative expenses | 35 |  |  | 20 |  |  | 67 |  |  | 39 |  |
| Total share-based compensation expense | $ | 45 |  |  | $ | 27 |  |  | $ | 86 |  |  | $ | 53 |  |

[0000866374-23-000066:notes:53]
Total number of options outstanding and exercisable were immaterial as of September 29, 2023. All options have been fully expensed as of September 29, 2023.

[0000866374-23-000066:notes:54]
[same as prior period, unchanged from 0000866374-23-000058:notes:64]

[0000866374-23-000066:notes:55]
During the six-month period ended September 29, 2023, the Company granted 4.9 million restricted share unit ("RSU") awards. Of this amount, approximately 3 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, and with an average grant date price of $26.82 per award. In addition, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $26.72 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of approximately 0.8 million based

[0000866374-23-000066:notes:56]
[same as prior period, unchanged from 0000866374-23-000058:notes:66]

[0000866374-23-000066:notes:57]
As of September 29, 2023, approximately 12 million unvested RSU awards under the 2017 plan were outstanding, of which vesting for a targeted amount of 1.2 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of 1.2 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to 2.4 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to 2.4 million based on the achievement levels. During the six-month period ended September 29, 2023, 2.3 million shares vested in connection with the awards with market conditions granted in fiscal year 2021.

[0000866374-23-000066:notes:58]
As of September 29, 2023, total unrecognized compensation expense related to unvested RSU awards under the 2017 Plan, was approximately $203 million, and will be recognized over a weighted-average remaining vesting period of 2.2 years.

[0000866374-23-000066:notes:59]
[same as prior period, unchanged from 0000866374-23-000058:notes:69]

[0000866374-23-000066:notes:60]
During the six-month period ended September 29, 2023, Nextracker awarded 2.0 million equity-based compensation awards to its employees under the 2022 Nextracker Plan, which included approximately 0.5 million option awards, 1.1 million RSU ("NRSU") awards and 0.4 million performance-based restricted share unit ("NPSU") awards. Vesting for the awards granted under the 2022 Nextracker Plan is contingent upon continued employee service and also may be subject to certain performance conditions.

[0000866374-23-000066:notes:61]
As of September 29, 2023, approximately 6.5 million unvested options awards, NRSU awards, and NPSU awards under the 2022 Nextracker Plan were outstanding, of which vesting for a targeted amount of approximately 4.0 million shares is contingent on meeting certain performance conditions.

[0000866374-23-000066:notes:62]
Total unrecognized compensation expense related to unvested awards under the 2022 Nextracker Plan was approximately $101 million, which is expected to be recognized over a weighted-average period of approximately 2.5 years. Approximately $25 million of expense was recognized for equity-based compensation awards granted under the 2022 Nextracker Plan for the six-month period ended September 29, 2023.


## us-gaap:EarningsPerShareTextBlock

[0000866374-23-000066:notes:63]
[same as prior period, unchanged from 0000866374-23-000058:notes:72]

[0000866374-23-000066:notes:64]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
|  | (In millions, except per share amounts) |
| Basic earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 406 |  |  | $ | 238 |  |  | $ | 617 |  |  | $ | 433 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 178 |  |  | 6 |  |  | 203 |  |  | 12 |  |
| Net income attributable to Flex Ltd. | $ | 228 |  |  | $ | 232 |  |  | $ | 414 |  |  | $ | 421 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 443 |  |  | 455 |  |  | 445 |  |  | 457 |  |
| Basic earnings per share | $ | 0.51 |  |  | $ | 0.51 |  |  | $ | 0.93 |  |  | $ | 0.92 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 406 |  |  | $ | 238 |  |  | $ | 617 |  |  | $ | 433 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 178 |  |  | 6 |  |  | 203 |  |  | 12 |  |
| Net income attributable to Flex Ltd. | $ | 228 |  |  | $ | 232 |  |  | $ | 414 |  |  | $ | 421 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 443 |  |  | 455 |  |  | 445 |  |  | 457 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 5 |  |  | 5 |  |  | 7 |  |  | 7 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 448 |  |  | 460 |  |  | 452 |  |  | 464 |  |
| Diluted earnings per share | $ | 0.51 |  |  | $ | 0.50 |  |  | $ | 0.92 |  |  | $ | 0.91 |  |

[0000866374-23-000066:notes:65]
(1)An immaterial amount of RSU awards and 2.1 million RSU awards for the three and six-month periods ended September 29, 2023, respectively, and an immaterial amount of RSU awards and 3.4 million RSU awards for the three and six-month periods ended September 30, 2022, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-23-000066:notes:66]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 29, 2023 and March 31, 2023 are as follows:

[0000866374-23-000066:notes:67]
|  | Maturity Date |  | As of September 29, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 591 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 684 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 683 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 268 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (19) |  |  | (21) |  |
|  |  |  | 3,412 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | — |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,412 |  |  | $ | 3,691 |  |

[0000866374-23-000066:notes:68]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. These notes represent the Company’s senior unsecured obligations and hold equal ranking with all other existing and future senior unsecured debt obligations.

[0000866374-23-000066:notes:69]
(2)During the first quarter of fiscal year 2024, the Company repaid the JPY Term Loan for approximately $241 million. In addition, the Company also settled the associated USD JPY cross currency swap for approximately $60 million.

[0000866374-23-000066:notes:70]
(3)During the second quarter of fiscal year 2024, the Company repaid the Delayed Draw Term Loan for approximately $150 million.

[0000866374-23-000066:notes:71]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.7% as of September 29, 2023 and March 31, 2023, respectively.

[0000866374-23-000066:notes:72]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 29, 2023 are as follows:

[0000866374-23-000066:notes:73]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | — |  |
| 2026 |  | 1,276 |  |
| 2027 |  | — |  |
| 2028 |  | 547 |  |
| Thereafter |  | 1,608 |  |
| Total |  | $ | 3,431 |  |

[0000866374-23-000066:notes:74]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2024.


## flex:InterestAndOtherNetTextBlock

[0000866374-23-000066:notes:75]
INTEREST, NET 
Interest, net for the three and six-month periods ended September 29, 2023 and September 30, 2022 are primarily composed of the following:

[0000866374-23-000066:notes:76]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 42 |  |  | $ | 44 |  |  | $ | 89 |  |  | $ | 87 |  |
| Interest income | (18) |  |  | (5) |  |  | (36) |  |  | (9) |  |
| AR sale program related expenses | 11 |  |  | 8 |  |  | 23 |  |  | 13 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-23-000066:notes:77]
[same as prior period, unchanged from 0000866374-23-000058:notes:85]

[0000866374-23-000066:notes:78]
[same as prior period, unchanged from 0000866374-23-000058:notes:86]

[0000866374-23-000066:notes:79]
As of September 29, 2023, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $11.3 billion as summarized below:

[0000866374-23-000066:notes:80]
|  |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |
| Cash Flow Hedges |  |  |  |  |
| HUF |  | $ | 439 |  |  | $ | — |  |
| MXN |  | 534 |  |  | — |  |
| Other |  | 577 |  |  | 29 |  |
|  |  | 1,550 |  |  | 29 |  |
| Other Foreign Currency Contracts |  |  |  |  |
| CNY |  | 844 |  |  | 360 |  |
| EUR |  | 2,237 |  |  | 2,475 |  |
| GBP |  | 232 |  |  | 346 |  |
| MXN |  | 643 |  |  | 508 |  |
| MYR |  | 524 |  |  | 355 |  |
| Other |  | 586 |  |  | 630 |  |
|  |  | 5,066 |  |  | 4,674 |  |
| Total Notional Contract Value in USD |  | $ | 6,616 |  |  | $ | 4,703 |  |

[0000866374-23-000066:notes:81]
As of September 29, 2023, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the condensed consolidated statements of operations. As of September 29, 2023 and March 31, 2023, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred loss was $7 million as of September 29, 2023, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations over the next twelve-month period, except

[0000866374-23-000066:notes:82]
for the USD HUF cross currency swaps.

[0000866374-23-000066:notes:83]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in current and long-term other liabilities as of September 29, 2023 and March 31, 2023. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-23-000066:notes:84]
[same as prior period, unchanged from 0000866374-23-000058:notes:91]

[0000866374-23-000066:notes:85]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 29,2023 |  | March 31,2023 |  | Balance SheetLocation |  | September 29,2023 |  | March 31,2023 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 20 |  |  | $ | 46 |  |  | Other current liabilities |  | $ | 33 |  |  | $ | 22 |  |
| Foreign currency contracts | Other assets |  | $ | — |  |  | $ | — |  |  | Other liabilities |  | $ | 31 |  |  | $ | 88 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 46 |  |  | $ | 26 |  |  | Other current liabilities |  | $ | 59 |  |  | $ | 19 |  |

[0000866374-23-000066:notes:86]
[same as prior period, unchanged from 0000866374-23-000058:notes:93]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-23-000066:notes:87]
[same as prior period, unchanged from 0000866374-23-000058:notes:94]

[0000866374-23-000066:notes:88]
|  | Three-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | 20 |  |  | $ | (189) |  |  | $ | (169) |  |  | $ | (67) |  |  | $ | (187) |  |  | $ | (254) |  |
| Other comprehensive loss before reclassifications | (38) |  |  | (38) |  |  | (76) |  |  | (70) |  |  | (92) |  |  | (162) |  |
| Net loss reclassified from accumulated other comprehensive loss | 5 |  |  | — |  |  | 5 |  |  | 64 |  |  | — |  |  | 64 |  |
| Net current-period other comprehensive loss | (33) |  |  | (38) |  |  | (71) |  |  | (6) |  |  | (92) |  |  | (98) |  |
| Ending balance | $ | (13) |  |  | $ | (227) |  |  | $ | (240) |  |  | $ | (73) |  |  | $ | (279) |  |  | $ | (352) |  |

[0000866374-23-000066:notes:89]
|  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |  | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |
| Other comprehensive gain (loss) before reclassifications | 63 |  |  | (47) |  |  | 16 |  |  | (149) |  |  | (163) |  |  | (312) |  |
| Net (gains) loss reclassified from accumulated other comprehensive loss | (62) |  |  | — |  |  | (62) |  |  | 142 |  |  | — |  |  | 142 |  |
| Net current-period other comprehensive gains (loss) | 1 |  |  | (47) |  |  | (46) |  |  | (7) |  |  | (163) |  |  | (170) |  |
| Ending balance | $ | (13) |  |  | $ | (227) |  |  | $ | (240) |  |  | $ | (73) |  |  | $ | (279) |  |  | $ | (352) |  |

[0000866374-23-000066:notes:90]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and six-month periods ended September 29, 2023 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in accumulated other comprehensive loss for the three-month periods ended September 29, 2023 and September 30, 2022 were $11 million and $6 million, respectively. The tax impacts on the changes in accumulated other comprehensive loss for the six-month periods ended September 29, 2023 and September 30, 2022 were $9 million and $10 million, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-23-000066:notes:91]
TRADE RECEIVABLES SECURITIZATION
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-23-000066:notes:92]
Asset-Backed Securitization Programs

[0000866374-23-000066:notes:93]
The Company historically has engaged in asset-backed securitization programs (the “ABS Programs”), selling trade receivables to affiliated special purpose entities and then to unaffiliated financial institutions. Upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, the receivables are derecognized from our consolidated balance sheet as effective control of the transferred receivables is passed to the unaffiliated financial institutions, which have the right to pledge or sell the receivables. Accounts receivable sold under the ABS Programs are included as cash provided by operating activities in the consolidated statement of cash flow. During the six-month periods ended September 29, 2023 and September 30, 2022, no accounts receivable were sold under the ABS Programs.

[0000866374-23-000066:notes:94]
Trade Accounts Receivable Sale Programs
The Company also sells accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.8 billion and $0.8 billion as of September 29, 2023 and March 31, 2023, respectively. For the six-month periods ended September 29, 2023 and September 30, 2022, total accounts receivable sold to certain third-party banking institutions was approximately $1.7 billion and $1.7 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-23-000066:notes:95]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows: 
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of September 29, 2023 and March 31, 2023.

[0000866374-23-000066:notes:96]
[same as prior period, unchanged from 0000866374-23-000058:notes:102]

[0000866374-23-000066:notes:97]
[same as prior period, unchanged from 0000866374-23-000058:notes:103]

[0000866374-23-000066:notes:98]
[same as prior period, unchanged from 0000866374-23-000058:notes:104]

[0000866374-23-000066:notes:99]
[same as prior period, unchanged from 0000866374-23-000058:notes:105]

[0000866374-23-000066:notes:100]
[same as prior period, unchanged from 0000866374-23-000058:notes:106]

[0000866374-23-000066:notes:101]
There were no transfers between levels in the fair value hierarchy during the six-month periods ended September 29, 2023 and September 30, 2022.

[0000866374-23-000066:notes:102]
[same as prior period, unchanged from 0000866374-23-000058:notes:108]

[0000866374-23-000066:notes:103]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of September 29, 2023 and March 31, 2023:

[0000866374-23-000066:notes:104]
|  | Fair Value Measurements as of September 29, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,425 |  |  | $ | — |  |  | $ | 1,425 |  |
| Foreign currency contracts (Note 8) | — |  |  | 66 |  |  | — |  |  | 66 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (123) |  |  | $ | — |  |  | $ | (123) |  |
|  | Fair Value Measurements as of March 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 2,324 |  |  | $ | — |  |  | $ | 2,324 |  |
| Foreign currency contracts (Note 8) | — |  |  | 72 |  |  | — |  |  | 72 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (129) |  |  | $ | — |  |  | $ | (129) |  |

[0000866374-23-000066:notes:105]
[same as prior period, unchanged from 0000866374-23-000058:notes:111]

[0000866374-23-000066:notes:106]
[same as prior period, unchanged from 0000866374-23-000058:notes:112]

[0000866374-23-000066:notes:107]
|  | As of September 29, 2023 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| JPY Term Loan due April 2024 | $ | — |  |  | $ | — |  |  | $ | 253 |  |  | $ | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 591 |  |  | 577 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 684 |  |  | 648 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 394 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 657 |  |  | 613 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 683 |  |  | 637 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan due November 2023 | — |  |  | — |  |  | 150 |  |  | 150 |  |  | Level 2 |
| Nextracker Term Loan due February 2028 | 150 |  |  | 148 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 268 |  |  | 196 |  |  | 284 |  |  | 196 |  |  | Level 2 |

[0000866374-23-000066:notes:108]
The Notes due June 2025, February 2026, January 2028, June 2029, and May 2030 are valued based on broker trading prices in active markets. HUF Bonds and Nextracker Term Loan due February 2028 are valued based on the broker trading prices in an inactive market.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-23-000066:notes:109]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-23-000066:notes:110]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-23-000066:notes:111]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $83 million based on the exchange rate as of September 29, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $12 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $52 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes that it has meritorious defenses to each of these assessments and will continue to vigorously oppose all of them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-23-000066:notes:112]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-23-000066:notes:113]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $221 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-23-000066:notes:114]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-23-000066:notes:115]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-23-000066:notes:116]
SHARE REPURCHASES 
During the three and six-month periods ended September 29, 2023, the Company repurchased 11.5 million and 20.1 million shares at an aggregate purchase price of $309 million and $506 million, respectively, and retired all of these shares. During the three-month period ended September 29, 2023, the Company also retired an additional 50.2 million shares of treasury stock which were repurchased in the prior periods, at an aggregate purchase price of $388 million.

[0000866374-23-000066:notes:117]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $2.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 2, 2023. As of September 29, 2023, shares in the aggregate amount of $1.8 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-23-000066:notes:118]
[same as prior period, unchanged from 0000866374-23-000058:notes:125]

[0000866374-23-000066:notes:119]
[same as prior period, unchanged from 0000866374-23-000058:notes:126]

[0000866374-23-000066:notes:120]
[same as prior period, unchanged from 0000866374-23-000058:notes:127]

[0000866374-23-000066:notes:121]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 29, 2023 |  | September 30, 2022 |  | September 29, 2023 |  | September 30, 2022 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,618 |  |  | $ | 4,004 |  |  | $ | 7,219 |  |  | $ | 7,995 |  |
| Flex Reliability Solutions | 3,314 |  |  | 3,299 |  |  | 6,605 |  |  | 6,268 |  |
| Nextracker | 573 |  |  | 473 |  |  | 1,053 |  |  | 868 |  |
| Intersegment eliminations | (34) |  |  | (10) |  |  | (70) |  |  | (18) |  |
|  | $ | 7,471 |  |  | $ | 7,766 |  |  | $ | 14,807 |  |  | $ | 15,113 |  |
| Segment income and reconciliation of income before income taxes: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 168 |  |  | $ | 170 |  |  | $ | 314 |  |  | $ | 342 |  |
| Flex Reliability Solutions | 171 |  |  | 175 |  |  | 336 |  |  | 322 |  |
| Nextracker | 112 |  |  | 43 |  |  | 194 |  |  | 73 |  |
| Corporate and Other | (12) |  |  | (13) |  |  | (28) |  |  | (31) |  |
| Total segment income | 439 |  |  | 375 |  |  | 816 |  |  | 706 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 17 |  |  | 21 |  |  | 37 |  |  | 43 |  |
| Stock-based compensation | 45 |  |  | 27 |  |  | 86 |  |  | 53 |  |
| Restructuring charges | 1 |  |  | — |  |  | 24 |  |  | — |  |
| Legal and other (1) | — |  |  | 2 |  |  | 2 |  |  | 13 |  |
| Interest, net | 35 |  |  | 47 |  |  | 76 |  |  | 96 |  |
| Other charges (income), net | 16 |  |  | 6 |  |  | 27 |  |  | (3) |  |
| Income before income taxes | $ | 325 |  |  | $ | 272 |  |  | $ | 564 |  |  | $ | 504 |  |

[0000866374-23-000066:notes:122]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During the first half of fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-23-000066:notes:123]
[same as prior period, unchanged from 0000866374-23-000058:notes:130]

[0000866374-23-000066:notes:124]
[same as prior period, unchanged from 0000866374-23-000058:notes:131]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-23-000066:notes:125]
RESTRUCTURING CHARGESDuring the three and six-month periods ended September 29, 2023, the Company recognized approximately $3 million and $26 million of restructuring charges, most of which related to employee severance.
The following table summarizes the provisions, respective payments, and remaining accrued balance as of September 29, 2023 for charges incurred during the six-month period ended September 29, 2023:

[0000866374-23-000066:notes:126]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2023 | $ | 44 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 50 |  |
| Provision for charges incurred during the six-month period ended September 29, 2023 | 22 |  |  | 3 |  |  | 1 |  |  | 26 |  |
| Cash payments during the six-month period ended September 29, 2023 | (41) |  |  | — |  |  | — |  |  | (41) |  |
| Non-cash reductions during the six-month period ended September 29, 2023 | — |  |  | (3) |  |  | (1) |  |  | (4) |  |
| Balance as of September 29, 2023 | 25 |  |  | — |  |  | 6 |  |  | 31 |  |
| Less: Current portion (classified as other current liabilities) | 25 |  |  | — |  |  | 6 |  |  | 31 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:VariableInterestEntityDisclosureTextBlock

[0000866374-23-000066:notes:127]
VARIABLE INTEREST ENTITIES
The Company controls Nextracker Inc. ("Nextracker") through its holding of Class B common stock that does not participate in the earnings of Nextracker. As such, the shareholders of the equity at risk in Nextracker (the Class A common stock shareholders) do not have the power to direct the key activities of Nextracker and consequently Nextracker is a variable interest entity ("VIE"). The Company has the ability to control Nextracker's activities through its control of 51.5% and 61.4% of the voting rights of Nextracker as of September 29, 2023 and March 31, 2023, respectively. The Company also has the ability to receive significant benefits from the VIE (through its ability to convert its investments in Nextracker and Nextracker LLC into Class A common stock of Nextracker or cash) and as such the Company has been determined to be the primary beneficiary of the VIE. As such, the Company continues to consolidate Nextracker and the interests in Nextracker held by third parties are presented as a noncontrolling interest. Evaluation of the VIE model and identification of the primary beneficiary requires significant judgements to be made regarding which entities can control the activities of a VIE, who can receive benefits or absorb losses from the VIE and the significance of those benefits and losses to the VIE.

[0000866374-23-000066:notes:128]
On July 3, 2023, the Company's subsidiary Nextracker completed a follow-on offering to its initial public offering ("IPO"), which was completed on February 13, 2023, and issued 15,631,562 shares of Class A common stock and received net proceeds of $551 million. The entire net proceeds were used by Nextracker to acquire 14,025,000 Nextracker LLC common units from Yuma, Inc., the Company’s indirect wholly-owned subsidiary, and 1,606,562 Nextracker LLC common units from TPG Rise Flash, L.P., an affiliate of the global alternative asset management firm TPG. As a result of the repurchase of Nextracker LLC common units by Nextracker, 15,631,562 shares of Nextracker Class B common stock were cancelled. The Company received approximately $495 million from the follow-on offering, after distribution of net proceeds to TPG and expenses.

[0000866374-23-000066:notes:129]
As of September 29, 2023 and March 31, 2023, noncontrolling interest was $450 million and $355 million, respectively. Net income attributable to noncontrolling interest was $178 million and $203 million for the three and six-months periods ended September 29, 2023, respectively. Net income attributable to noncontrolling interest was zero for both the three and six-months periods ended September 30, 2022. As a result of Nextracker's February 13, 2023 IPO, the noncontrolling interest previously determined to be redeemable prior to the IPO did not exist as of September 29, 2023. Net income attributable to redeemable noncontrolling interest was zero for both the three and six-months periods ended September 29, 2023. Net income attributable to redeemable noncontrolling interest was $6 million and $12 million for the three and six months ended September 30, 2022, respectively.

[0000866374-23-000066:notes:130]
The carrying amounts and classification of the VIE's external assets and liabilities as of September 29, 2023 and March 31, 2023 are included in the condensed consolidated balance sheets as follows:

[0000866374-23-000066:notes:131]
|  | September 29, 2023 |  | March 31, 2023 |
|  | (In millions) (Unaudited) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash | $ | 373 |  |  | $ | 130 |  |
| Accounts receivable, net | 340 |  |  | 271 |
| Contract assets | 312 |  |  | 298 |
| Inventories | 196 |  |  | 138 |
| Other current assets | 118 |  |  | 35 |
| Total current assets | 1,339 |  |  | 872 |
| Property and equipment, net | 7 |  |  | 7 |
| Goodwill | 265 |  |  | 265 |
| Other intangible assets, net | 1 |  |  | 1 |
| Other assets | 422 |  |  | 275 |
| Total assets | $ | 2,034 |  |  | $ | 1,420 |  |
| Liabilities |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 403 |  |  | $ | 211 |  |
| Accrued expenses | 67 |  |  | 60 |  |
| Deferred revenue | 236 |  |  | 176 |  |
| Other current liabilities | 66 |  |  | 49 |  |
| Total current liabilities | 772 |  |  | 496 |  |
| Long-term debt | 146 |  |  | 147 |  |
| Other liabilities | 440 |  |  | 280 |  |
| Total liabilities | $ | 1,358 |  |  | $ | 923 |  |


## us-gaap:SubsequentEventsTextBlock

[0000866374-23-000066:notes:132]
SUBSEQUENT EVENTS
On October 25, 2023, Flex announced its plan to effect a spin-off of all of its remaining interests in Nextracker to Flex shareholders on a pro rata basis pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023 (the “Merger Agreement”). The spin-off is subject to a number of conditions as set forth in the Merger Agreement, including the approval of Flex shareholders in accordance with Singapore law, and there is no assurance that any such conditions will be satisfied or waived. The spin-off is currently expected to be completed in Flex’s fourth quarter ending March 31, 2024.

[0000866374-23-000066:notes:133]
On October 25, 2023, the Company’s management committed to targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. While a detailed action plan has not been finalized, the Company currently estimates charges of approximately $100 million will be recognized in the third quarter of the fiscal year ending March 31, 2024. The charges are expected to primarily relate to employee termination benefits and are expected to be settled in cash in the fiscal year ending March 31, 2024.
