# FLEX notes — 0000866374-22-000074


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-22-000074:notes:1]
[same as prior period, unchanged from 0000866374-22-000052:notes:1]

[0000866374-22-000074:notes:2]
[same as prior period, unchanged from 0000866374-22-000052:notes:2]

[0000866374-22-000074:notes:3]
[same as prior period, unchanged from 0000866374-22-000052:notes:3]

[0000866374-22-000074:notes:4]
[same as prior period, unchanged from 0000866374-22-000052:notes:4]

[0000866374-22-000074:notes:5]
[same as prior period, unchanged from 0000866374-22-000052:notes:5]

[0000866374-22-000074:notes:6]
[same as prior period, unchanged from 0000866374-22-000052:notes:6]

[0000866374-22-000074:notes:7]
[same as prior period, unchanged from 0000866374-22-000052:notes:7]

[0000866374-22-000074:notes:8]
[same as prior period, unchanged from 0000866374-22-000052:notes:8]

[0000866374-22-000074:notes:9]
[same as prior period, unchanged from 0000866374-22-000052:notes:9]

[0000866374-22-000074:notes:10]
[same as prior period, unchanged from 0000866374-22-000052:notes:10]

[0000866374-22-000074:notes:11]
[same as prior period, unchanged from 0000866374-22-000052:notes:11]

[0000866374-22-000074:notes:12]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers).

[0000866374-22-000074:notes:13]
[same as prior period, unchanged from 0000866374-22-000052:notes:13]

[0000866374-22-000074:notes:14]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2022 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

[0000866374-22-000074:notes:15]
The first quarters for fiscal years 2023 and 2022 ended on July 1, 2022, which is comprised of 92 days in the period, and July 2, 2021, which is comprised of 93 days in the period, respectively. The second quarters for fiscal years 2023 and 2022 ended on September 30, 2022 and October 1, 2021, respectively, which are comprised of 91 days in both periods.

[0000866374-22-000074:notes:16]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. In all cases other than the redeemable noncontrolling interest in Nextracker, the associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of Interest and other, net, in the condensed consolidated statements of

[0000866374-22-000074:notes:17]
operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the condensed consolidated statements of operations.

[0000866374-22-000074:notes:18]
[same as prior period, unchanged from 0000866374-22-000052:notes:18]

[0000866374-22-000074:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic and geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the COVID-19 pandemic and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-22-000074:notes:20]
Recently Adopted Accounting Pronouncement

[0000866374-22-000074:notes:21]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company adopted the guidance during the first quarter of fiscal year 2023 with an immaterial impact on its condensed consolidated financial statements.

[0000866374-22-000074:notes:22]
Recently Issued Accounting Pronouncement

[0000866374-22-000074:notes:23]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2024.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-22-000074:notes:24]
[same as prior period, unchanged from 0000866374-22-000052:notes:22]

[0000866374-22-000074:notes:25]
[same as prior period, unchanged from 0000866374-22-000052:notes:23]

[0000866374-22-000074:notes:26]
|  | As of September 30, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| Raw materials | $ | 6,196 |  |  | $ | 5,290 |  |
| Work-in-progress | 737 |  |  | 602 |  |
| Finished goods | 793 |  |  | 688 |  |
|  | $ | 7,726 |  |  | $ | 6,580 |  |

[0000866374-22-000074:notes:27]
[same as prior period, unchanged from 0000866374-22-000052:notes:25]

[0000866374-22-000074:notes:28]
During the six-month period ended September 30, 2022, there was no material activity in the Company's goodwill account for each of its reportable segments, other than foreign currency translation adjustments of $15 million, which primarily impacted its FRS segment.

[0000866374-22-000074:notes:29]
[same as prior period, unchanged from 0000866374-22-000052:notes:27]

[0000866374-22-000074:notes:30]
|  | As of September 30, 2022 |  | As of March 31, 2022 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 349 |  |  | $ | (168) |  |  | $ | 181 |  |  | $ | 385 |  |  | $ | (157) |  |  | $ | 228 |  |
| Licenses and other intangibles | 270 |  |  | (123) |  |  | 147 |  |  | 319 |  |  | (136) |  |  | 183 |  |
| Total | $ | 619 |  |  | $ | (291) |  |  | $ | 328 |  |  | $ | 704 |  |  | $ | (293) |  |  | $ | 411 |  |

[0000866374-22-000074:notes:31]
[same as prior period, unchanged from 0000866374-22-000052:notes:29]

[0000866374-22-000074:notes:32]
[same as prior period, unchanged from 0000866374-22-000052:notes:30]

[0000866374-22-000074:notes:33]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 38 |  |
| 2024 |  | 64 |  |
| 2025 |  | 58 |  |
| 2026 |  | 39 |  |
| 2027 |  | 33 |  |
| Thereafter |  | 96 |  |
| Total amortization expense |  | $ | 328 |  |

[0000866374-22-000074:notes:34]
[same as prior period, unchanged from 0000866374-22-000052:notes:32]

[0000866374-22-000074:notes:35]
(1)Represents estimated amortization for the remaining fiscal six-month period ending March 31, 2023.

[0000866374-22-000074:notes:36]
[same as prior period, unchanged from 0000866374-22-000052:notes:34]

[0000866374-22-000074:notes:37]
Customer working capital advances were $2.0 billion and $1.4 billion, as of September 30, 2022 and March 31, 2022, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.

[0000866374-22-000074:notes:38]
[same as prior period, unchanged from 0000866374-22-000052:notes:36]

[0000866374-22-000074:notes:39]
Other current liabilities include customer-related accruals of $236 million and $227 million as of September 30, 2022 and March 31, 2022, respectively.

[0000866374-22-000074:notes:40]
[same as prior period, unchanged from 0000866374-22-000052:notes:38]

[0000866374-22-000074:notes:41]
As a result of the sale by a subsidiary of the Company of redeemable preferred units (“Series A Preferred Units”), representing a 16.67% interest in the Company's subsidiary, Nextracker LLC ("Nextracker"), to TPG Rise Flash, L.P. ("TPG Rise") on February 1, 2022, the Company recognized approximately $6 million and $12 million of a payable-in-kind dividend due to TPG Rise during the three and six-month periods ended September 30, 2022, respectively, based on a dividend rate of 5% per annum.

[0000866374-22-000074:notes:42]
At TPG Rise’s election, the Company is required to purchase all of the outstanding Series A Preferred Units at their liquidation preference, which shall include all contributed but unreturned capital plus accrued but unpaid dividends, at the earlier of certain change in control events and February 1, 2028. Additionally, if Nextracker has not completed a qualified initial public offering (a "Qualified Public Offering") prior to February 1, 2027, then TPG Rise may cause the Company to purchase all of the outstanding Series A Preferred Units at their fair market value. The Company has determined that a Qualified Public Offering is likely and that the change in control is not probable as of September 30, 2022 and, as such, it is not probable that the noncontrolling interest will become redeemable.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-22-000074:notes:43]
[same as prior period, unchanged from 0000866374-22-000052:notes:41]

[0000866374-22-000074:notes:44]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-22-000074:notes:45]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-22-000074:notes:46]
[same as prior period, unchanged from 0000866374-22-000052:notes:45]

[0000866374-22-000074:notes:47]
[same as prior period, unchanged from 0000866374-22-000052:notes:46]

[0000866374-22-000074:notes:48]
[same as prior period, unchanged from 0000866374-22-000052:notes:47]

[0000866374-22-000074:notes:49]
[same as prior period, unchanged from 0000866374-22-000052:notes:48]

[0000866374-22-000074:notes:50]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily

[0000866374-22-000074:notes:51]
available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-22-000074:notes:52]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-22-000074:notes:53]
[same as prior period, unchanged from 0000866374-22-000052:notes:52]

[0000866374-22-000074:notes:54]
[same as prior period, unchanged from 0000866374-22-000052:notes:53]

[0000866374-22-000074:notes:55]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $792 million and $704 million as of September 30, 2022 and March 31, 2022, respectively, of which $731 million and $615 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-22-000074:notes:56]
[same as prior period, unchanged from 0000866374-22-000052:notes:55]

[0000866374-22-000074:notes:57]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 30, 2022 and October 1, 2021, respectively. Historical information for the first and second quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.

[0000866374-22-000074:notes:58]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,787 |  |  | $ | 3,250 |  |  | $ | 7,566 |  |  | $ | 6,498 |  |
| Over time | 217 |  |  | 187 |  |  | 429 |  |  | 371 |  |
| Total | 4,004 |  |  | 3,437 |  |  | 7,995 |  |  | 6,869 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,110 |  |  | 2,308 |  |  | 5,900 |  |  | 4,715 |  |
| Over time | 189 |  |  | 157 |  |  | 368 |  |  | 332 |  |
| Total | 3,299 |  |  | 2,465 |  |  | 6,268 |  |  | 5,047 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 10 |  |  | 12 |  |  | 33 |  |  | 21 |  |
| Over time | 463 |  |  | 327 |  |  | 835 |  |  | 659 |  |
| Total | 473 |  |  | 339 |  |  | 868 |  |  | 680 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,897 |  |  | 5,558 |  |  | 13,481 |  |  | 11,209 |  |
| Over time | 869 |  |  | 671 |  |  | 1,632 |  |  | 1,362 |  |
| Total | $ | 7,766 |  |  | $ | 6,229 |  |  | $ | 15,113 |  |  | $ | 12,571 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-22-000074:notes:59]
SHARE-BASED COMPENSATION
The Company's primary plan used for granting equity compensation awards is the 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-22-000074:notes:60]
The following table summarizes the Company’s share-based compensation expense:

[0000866374-22-000074:notes:61]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
|  | (In millions) |
| Cost of sales | $ | 7 |  |  | $ | 6 |  |  | $ | 14 |  |  | $ | 11 |  |
| Selling, general and administrative expenses | 20 |  |  | 18 |  |  | 39 |  |  | 33 |  |
| Total share-based compensation expense | $ | 27 |  |  | $ | 24 |  |  | $ | 53 |  |  | $ | 44 |  |

[0000866374-22-000074:notes:62]
Total number of options outstanding and exercisable were immaterial as of September 30, 2022. All options have been fully expensed as of September 30, 2022.

[0000866374-22-000074:notes:63]
During the six-month period ended September 30, 2022, the Company granted 5.7 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 4.7 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, and with an average grant date price of $16.50 per award. In addition, approximately 0.5 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $16.68 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of approximately 1.0 million based on a measurement of the Company's adjusted earnings per share growth over certain specified periods, and will cliff vest after a period of three years, to the extent such performance conditions have been met. Further, approximately 0.5 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $23.45 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 1.0 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-22-000074:notes:64]
As of September 30, 2022, approximately 14.8 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 2.1 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of 0.9 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to 4.2 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to 1.8 million based on the achievement levels. During the six-month period ended September 30, 2022, 2.4 million shares vested in connection with the awards with market conditions granted in fiscal year 2020.

[0000866374-22-000074:notes:65]
As of September 30, 2022, total unrecognized compensation expense related to unvested RSU awards under all plans, not including the 2022 Nextracker plan below, was approximately $186 million, and will be recognized over a weighted-average remaining vesting period of 2.2 years.

[0000866374-22-000074:notes:66]
During the first half of fiscal year 2023, Nextracker granted 11.8 million equity-based compensation awards, which included approximately 5.9 million unit options, 4.5 million RSU awards and 1.4 million performance-based restricted share unit awards (“PSU”) to its employees under the First Amended and Restated 2022 Nextracker LLC Equity Incentive Plan (the “2022 Nextracker Plan”). Vesting for the awards granted under the 2022 Nextracker Plan is contingent upon continued employee service and certain performance conditions, including a liquidity event such as the occurrence of an initial public offering or the sale of Nextracker.

[0000866374-22-000074:notes:67]
Total unrecognized compensation expense related to unvested awards under the 2022 Nextracker Plan was approximately $55 million, which is expected to be recognized over a weighted-average period of approximately 3 years. No expense was recognized for equity-based compensation awards granted under the 2022 Nextracker Plan for the six-month period ended September 30, 2022 as there was no occurrence of a liquidity event. Nextracker will record cumulative stock-based compensation expense related to these awards in the period when its liquidity event is completed for the portion of the awards for which the relevant service condition has been satisfied with the remaining expense recognized over the remaining service period.


## us-gaap:EarningsPerShareTextBlock

[0000866374-22-000074:notes:68]
[same as prior period, unchanged from 0000866374-22-000052:notes:65]

[0000866374-22-000074:notes:69]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
|  | (In millions, except per share amounts) |
| Basic earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 238 |  |  | $ | 336 |  |  | $ | 433 |  |  | $ | 542 |  |
| Net income attributable to redeemable noncontrolling interest | 6 |  |  | — |  |  | 12 |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 232 |  |  | $ | 336 |  |  | $ | 421 |  |  | $ | 542 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 455 |  |  | 482 |  |  | 457 |  |  | 487 |  |
| Basic earnings per share | $ | 0.51 |  |  | $ | 0.70 |  |  | $ | 0.92 |  |  | $ | 1.11 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 238 |  |  | $ | 336 |  |  | $ | 433 |  |  | $ | 542 |  |
| Net income attributable to redeemable noncontrolling interest | 6 |  |  | — |  |  | 12 |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 232 |  |  | $ | 336 |  |  | $ | 421 |  |  | $ | 542 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 455 |  |  | 482 |  |  | 457 |  |  | 487 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 5 |  |  | 5 |  |  | 7 |  |  | 6 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 460 |  |  | 487 |  |  | 464 |  |  | 493 |  |
| Diluted earnings per share | $ | 0.50 |  |  | $ | 0.69 |  |  | $ | 0.91 |  |  | $ | 1.10 |  |

[0000866374-22-000074:notes:70]
(1)An immaterial amount of RSU awards and 3.4 million RSU awards for the three and six-month periods ended September 30, 2022, respectively, and an immaterial amount of RSU awards for the three and six-month periods ended October 1, 2021, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-22-000074:notes:71]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 30, 2022 are as follows:

[0000866374-22-000074:notes:72]
|  | As of September 30, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.446% | 232 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 688 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 688 |  |  | 690 |  |
| Euro Term Loans | 337 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 232 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (16) |  |  | (18) |  |
|  | 3,997 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (916) |  |  | (949) |  |
| Non-current portion | $ | 3,081 |  |  | $ | 3,248 |  |

[0000866374-22-000074:notes:73]
The weighted-average interest rate for the Company's long-term debt was 4.2% and 4.0% as of September 30, 2022 and March 31, 2022, respectively.

[0000866374-22-000074:notes:74]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 30, 2022 are as follows:

[0000866374-22-000074:notes:75]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2023 (1) |  | $ | 863 |  |
| 2024 |  | 53 |  |
| 2025 |  | 232 |  |
| 2026 |  | 1,287 |  |
| 2027 |  | — |  |
| Thereafter |  | 1,578 |  |
| Total |  | $ | 4,013 |  |

[0000866374-22-000074:notes:76]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2023.

[0000866374-22-000074:notes:77]
The 2027 Credit Facility

[0000866374-22-000074:notes:78]
In July 2022, the Company entered into a new $2.5 billion credit agreement which matures in July 2027 (the "2027 Credit Facility") and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2027 Credit Facility replaced the previous $2.0 billion revolving credit facility, which was due to mature in January 2026.

[0000866374-22-000074:notes:79]
Borrowings under the 2027 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the Term Secured Overnight Financing Rate (Term SOFR) rate plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.750% per annum, based on the Company’s credit ratings or (ii) Term SOFR (or (x) the “Alternative Currency Term Rate”, which is defined as, depending on the applicable currency at issue, either the Euro Interbank Offered Rate, Tokyo Interbank Offer Rate, or such other term rate per annum as designated with respect to such alternative currency or (y) the “Alternative Currency Daily Rate”, which is defined as, in the case of Sterling, the rate per annum equal to Sterling Overnight Index Average, and for any other alternative currency, such other term rate per annum as designated with respect to such alternative currency) plus the applicable margin for Term SOFR rate (or the Alternative Currency Term Rate) loans ranging between 1.125% and 1.750% per annum, based on the Company’s credit ratings, plus an adjustment for Term SOFR loans of 0.10% per annum and an adjustment for Sterling Overnight Index Average loans of 0.0326% per annum. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the

[0000866374-22-000074:notes:80]
last business day of March, June, September and December of each calendar year and the maturity date, (ii) in the case of borrowings at the Term SOFR rate (or the Alternative Currency Term Rate), on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month and the maturity date and (iii) in the case of borrowings at the Alternative Currency Daily Rate, on the last day of each calendar month and the maturity date. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2027 Credit Facility ranging from 0.125% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.125% to 1.750% per annum (based on the Company’s credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

[0000866374-22-000074:notes:81]
Under the 2027 Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

[0000866374-22-000074:notes:82]
Delayed Draw Term Loan

[0000866374-22-000074:notes:83]
In September 2022, the Company entered into a $450 million delayed draw term loan credit agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. The delayed draw term loan is available to be drawn through November 30, 2022. All borrowings under the delayed draw term loan will become due on the date that is 364 days after the initial borrowing. Interest is based on either (a) a Term SOFR-based formula plus a margin of 100.0 basis points to 162.5 basis points, depending on the Company’s credit ratings, or (b) a Base Rate formula plus a margin of 0.0 basis point to 62.5 basis points, depending on the Company's credit ratings.

[0000866374-22-000074:notes:84]
The 2027 Credit Facility and delayed draw term loan are unsecured, and contain customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain acquisitions of other entities, (iii) incur liens, (iv) dispose of assets, and (v) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2027 Credit Facility and delayed draw term loan agreement also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio. As of September 30, 2022, the Company had no borrowings outstanding and was in compliance with the covenants under the 2027 Credit Facility and delayed draw term loan agreement.


## flex:InterestAndOtherNetTextBlock

[0000866374-22-000074:notes:85]
INTEREST AND OTHER, NET 
Interest and other, net for the three and six-month periods ended September 30, 2022 and October 1, 2021 are primarily composed of the following:

[0000866374-22-000074:notes:86]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 44 |  |  | $ | 37 |  |  | $ | 87 |  |  | $ | 75 |  |
| Brazil tax credit (1) | — |  |  | (149) |  |  | — |  |  | (149) |  |

[0000866374-22-000074:notes:87]
(1)In the second quarter of fiscal year 2022, the Company recognized a $149 million gain related to the Brazilian tax authority's approval of certain tax credits (Credit Habilitation).


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-22-000074:notes:88]
[same as prior period, unchanged from 0000866374-22-000052:notes:76]

[0000866374-22-000074:notes:89]
The Company enters into short-term and long-term foreign currency derivative contracts, including forward, swap, and options contracts, to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable, accounts payable, debt, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and, accordingly, fair value adjustments related to the credit risk of the counterparty financial institutions were not material.

[0000866374-22-000074:notes:90]
As of September 30, 2022, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $12.8 billion as summarized below:

[0000866374-22-000074:notes:91]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| CNY |  | 2,414 |  |  | — |  |  | $ | 333 |  |  | $ | — |  |
| HUF |  | 135,400 |  |  | — |  |  | 394 |  |  | — |  |
| JPY |  | 33,525 |  |  | — |  |  | 300 |  |  | — |  |
| MXN |  | 6,949 |  |  | — |  |  | 342 |  |  | — |  |
| MYR |  | 450 |  |  | 146 |  |  | 98 |  |  | 32 |  |
| Other |  | N/A |  | N/A |  | 223 |  |  | 76 |  |
|  |  |  |  |  |  | 1,690 |  |  | 108 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |
| BRL |  | 77 |  |  | 903 |  |  | 14 |  |  | 168 |  |
| CAD |  | 138 |  |  | 80 |  |  | 101 |  |  | 58 |  |
| CNY |  | 10,181 |  |  | 5,876 |  |  | 1,455 |  |  | 855 |  |
| EUR |  | 2,985 |  |  | 2,790 |  |  | 2,919 |  |  | 2,710 |  |
| GBP |  | 187 |  |  | 221 |  |  | 203 |  |  | 239 |  |
| HUF |  | 89,596 |  |  | 81,561 |  |  | 208 |  |  | 189 |  |
| ILS |  | 430 |  |  | 119 |  |  | 122 |  |  | 34 |  |
| INR |  | 17,141 |  |  | — |  |  | 208 |  |  | — |  |
| MXN |  | 8,927 |  |  | 6,707 |  |  | 439 |  |  | 330 |  |
| MYR |  | 1,302 |  |  | 339 |  |  | 283 |  |  | 74 |  |
| SGD |  | 102 |  |  | 55 |  |  | 71 |  |  | 38 |  |
| Other |  | N/A |  | N/A |  | 160 |  |  | 153 |  |
|  |  |  |  |  |  | 6,183 |  |  | 4,848 |  |
| Total Notional Contract Value in USD |  |  |  |  |  | $ | 7,873 |  |  | $ | 4,956 |  |

[0000866374-22-000074:notes:92]
As of September 30, 2022, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of September 30, 2022 and March 31, 2022, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred loss was $53 million as of September 30, 2022, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap and the USD HUF cross currency swaps, which are further discussed below.

[0000866374-22-000074:notes:93]
The Company entered into a USD JPY cross currency swap in April 2019 to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in current and long-term other liabilities as of September 30, 2022. Additionally, the Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in current and long-term other liabilities as of September 30, 2022. The changes in fair value of both the USD JPY cross currency swap and the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal and HUF bond principal, which also impact the same line.

[0000866374-22-000074:notes:94]
[same as prior period, unchanged from 0000866374-22-000052:notes:82]

[0000866374-22-000074:notes:95]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 30,2022 |  | March 31,2022 |  | Balance SheetLocation |  | September 30,2022 |  | March 31,2022 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 15 |  |  | $ | 22 |  |  | Other current liabilities |  | $ | 72 |  |  | $ | 35 |  |
| Foreign currency contracts | Other assets |  | $ | — |  |  | $ | — |  |  | Other liabilities |  | $ | 152 |  |  | $ | 61 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 96 |  |  | $ | 21 |  |  | Other current liabilities |  | $ | 171 |  |  | $ | 26 |  |

[0000866374-22-000074:notes:96]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements and, as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-22-000074:notes:97]
[same as prior period, unchanged from 0000866374-22-000052:notes:85]

[0000866374-22-000074:notes:98]
|  | Three-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (67) |  |  | $ | (187) |  |  | $ | (254) |  |  | $ | (39) |  |  | $ | (72) |  |  | $ | (111) |  |
| Other comprehensive loss before reclassifications | (70) |  |  | (92) |  |  | (162) |  |  | (5) |  |  | (16) |  |  | (21) |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 64 |  |  | — |  |  | 64 |  |  | (5) |  |  | — |  |  | (5) |  |
| Net current-period other comprehensive loss | (6) |  |  | (92) |  |  | (98) |  |  | (10) |  |  | (16) |  |  | (26) |  |
| Ending balance | $ | (73) |  |  | $ | (279) |  |  | $ | (352) |  |  | $ | (49) |  |  | $ | (88) |  |  | $ | (137) |  |

[0000866374-22-000074:notes:99]
|  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |  | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |
| Other comprehensive gain (loss) before reclassifications | (149) |  |  | (163) |  |  | (312) |  |  | 7 |  |  | (10) |  |  | (3) |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 142 |  |  | — |  |  | 142 |  |  | (14) |  |  | (1) |  |  | (15) |  |
| Net current-period other comprehensive loss | (7) |  |  | (163) |  |  | (170) |  |  | (7) |  |  | (11) |  |  | (18) |  |
| Ending balance | $ | (73) |  |  | $ | (279) |  |  | $ | (352) |  |  | $ | (49) |  |  | $ | (88) |  |  | $ | (137) |  |

[0000866374-22-000074:notes:100]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and six-month periods ended September 30, 2022 were reclassified out of accumulated other comprehensive loss to interest and other, net and cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-22-000074:notes:101]
[same as prior period, unchanged from 0000866374-22-000052:notes:88]

[0000866374-22-000074:notes:102]
[same as prior period, unchanged from 0000866374-22-000052:notes:89]

[0000866374-22-000074:notes:103]
The Company sells designated pools of trade receivables under its asset-backed securitization programs (the “ABS Programs”) to affiliated special purpose entities, each of which may in turn sell a fraction of the receivables to unaffiliated financial institutions, based on the Company's requirements. Under these programs, the entire purchase price of sold receivables is paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The accounts receivable balances sold under the ABS Programs are removed from the condensed consolidated balance sheets and the cash proceeds received by the Company are included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-22-000074:notes:104]
During the six-month periods ended September 30, 2022 and October 1, 2021, no accounts receivable were sold under the ABS Programs.

[0000866374-22-000074:notes:105]
Trade Accounts Receivable Sale Programs
The Company also sells accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.8 billion and $0.6 billion as of September 30, 2022 and March 31, 2022, respectively. For the six-month periods ended September 30, 2022 and October 1, 2021, total accounts receivable sold to certain third-party banking institutions was approximately $1.7 billion and $0.6 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-22-000074:notes:106]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence 
surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-22-000074:notes:107]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of September 30, 2022 and March 31, 2022.

[0000866374-22-000074:notes:108]
[same as prior period, unchanged from 0000866374-22-000052:notes:96]

[0000866374-22-000074:notes:109]
[same as prior period, unchanged from 0000866374-22-000052:notes:97]

[0000866374-22-000074:notes:110]
[same as prior period, unchanged from 0000866374-22-000052:notes:98]

[0000866374-22-000074:notes:111]
[same as prior period, unchanged from 0000866374-22-000052:notes:99]

[0000866374-22-000074:notes:112]
[same as prior period, unchanged from 0000866374-22-000052:notes:100]

[0000866374-22-000074:notes:113]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of September 30, 2022 and March 31, 2022.

[0000866374-22-000074:notes:114]
There were no transfers between levels in the fair value hierarchy during the six-month periods ended September 30, 2022 and October 1, 2021.

[0000866374-22-000074:notes:115]
[same as prior period, unchanged from 0000866374-22-000052:notes:103]

[0000866374-22-000074:notes:116]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of September 30, 2022 and March 31, 2022:

[0000866374-22-000074:notes:117]
|  | Fair Value Measurements as of September 30, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,509 |  |  | $ | — |  |  | $ | 1,509 |  |
| Foreign currency contracts (Note 8) | — |  |  | 111 |  |  | — |  |  | 111 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 36 |  |  | — |  |  | 36 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (395) |  |  | $ | — |  |  | $ | (395) |  |
|  | Fair Value Measurements as of March 31, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 2,285 |  |  | $ | — |  |  | $ | 2,285 |  |
| Foreign currency contracts (Note 8) | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (122) |  |  | $ | — |  |  | $ | (122) |  |

[0000866374-22-000074:notes:118]
[same as prior period, unchanged from 0000866374-22-000052:notes:106]

[0000866374-22-000074:notes:119]
[same as prior period, unchanged from 0000866374-22-000052:notes:107]

[0000866374-22-000074:notes:120]
|  | As of September 30, 2022 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 501 |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.446% | 232 |  |  | 232 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 588 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 688 |  |  | 643 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 659 |  |  | 602 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 688 |  |  | 630 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | 337 |  |  | 337 |  |  | 389 |  |  | 389 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 232 |  |  | 232 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | 79 |  |  | 79 |  |  | 84 |  |  | 84 |  |  | Level 2 |

[0000866374-22-000074:notes:121]
[same as prior period, unchanged from 0000866374-22-000052:notes:109]

[0000866374-22-000074:notes:122]
The Company values its Term Loan due April 2024, India Facilities, Euro Term Loans, and HUF Bonds based on the current market rate, and as of September 30, 2022, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-22-000074:notes:123]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-22-000074:notes:124]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-22-000074:notes:125]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third-parties do assert patent infringement claims against the Company or its customers. If and when third-parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-22-000074:notes:126]
From time to time, the Company enters into intellectual property licenses (e.g., patent licenses and software licenses) with third-parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

[0000866374-22-000074:notes:127]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 374 million Brazilian reals (approximately USD $70 million based on the exchange rate as of September 30, 2022). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $11 million). The Company successfully defeated another three of the assessments in September 2022 (totaling approximately 229 million Brazilian reals or USD $43 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 34 million Brazilian reals (approximately USD $6 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

[0000866374-22-000074:notes:128]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-22-000074:notes:129]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018.

[0000866374-22-000074:notes:130]
The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-22-000074:notes:131]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-22-000074:notes:132]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-22-000074:notes:133]
SHARE REPURCHASES 
During the three and six-month periods ended September 30, 2022, the Company repurchased 4.4 million and 15.7 million shares at an aggregate purchase price of $72 million and $253 million, respectively, and retired all of these shares.

[0000866374-22-000074:notes:134]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 25, 2022. As of September 30, 2022, shares in the aggregate amount of $977 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-22-000074:notes:135]
SEGMENT REPORTING
The Company reports its financial performance based on three operating and reportable segments, Flex Agility Solutions, Flex Reliability Solutions and Nextracker, and analyzes operating income as the measure of segment profitability. The determination of these segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-22-000074:notes:136]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, and legal and other. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-22-000074:notes:137]
Selected financial information by segment is in the table below (amounts may not sum due to rounding). Historical information for the first and second quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below and in Item 2, "Management's Discussion and Analysis of Financial Condition and Results of Operations."

[0000866374-22-000074:notes:138]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 4,004 |  |  | $ | 3,437 |  |  | $ | 7,995 |  |  | $ | 6,869 |  |
| Flex Reliability Solutions | 3,299 |  |  | 2,465 |  |  | 6,268 |  |  | 5,047 |  |
| Nextracker | 473 |  |  | 339 |  |  | 868 |  |  | 680 |  |
| Intersegment eliminations | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
|  | $ | 7,766 |  |  | $ | 6,229 |  |  | $ | 15,113 |  |  | $ | 12,571 |  |
| Segment income and reconciliation of operating income: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 170 |  |  | $ | 153 |  |  | $ | 342 |  |  | $ | 290 |  |
| Flex Reliability Solutions | 175 |  |  | 126 |  |  | 322 |  |  | 271 |  |
| Nextracker | 43 |  |  | 25 |  |  | 73 |  |  | 50 |  |
| Corporate and Other | (13) |  |  | (18) |  |  | (31) |  |  | (35) |  |
| Total segment income | 375 |  |  | 286 |  |  | 706 |  |  | 576 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 21 |  |  | 15 |  |  | 43 |  |  | 30 |  |
| Stock-based compensation | 27 |  |  | 24 |  |  | 53 |  |  | 44 |  |
| Restructuring charges | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Legal and other (1) | 2 |  |  | 1 |  |  | 12 |  |  | — |  |
| Operating income | $ | 325 |  |  | $ | 237 |  |  | $ | 597 |  |  | $ | 493 |  |

[0000866374-22-000074:notes:139]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset impairments (recoveries). During the first half of fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-22-000074:notes:140]
Corporate and other primarily includes corporate service costs that are not included in the chief operating decision maker's ("CODM") assessment of the performance of each of the identified reportable segments.

[0000866374-22-000074:notes:141]
[same as prior period, unchanged from 0000866374-22-000052:notes:129]
