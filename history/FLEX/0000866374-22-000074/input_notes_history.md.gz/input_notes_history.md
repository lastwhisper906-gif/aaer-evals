# FLEX note change history — 0000866374-22-000052 → 0000866374-22-000074


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-10-31):
[0000866374-22-000074:note_history:1]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 374 million Brazilian reals (approximately USD $70 million based on the exchange rate as of September 30, 2022). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $11 million). The Company successfully defeated another three of the assessments in September 2022 (totaling approximately 229 million Brazilian reals or USD $43 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 34 million Brazilian reals (approximately USD $6 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.

- removed (2022-10-31):
[0000866374-22-000052:note_history:2]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount of 374 million Brazilian reals (approximately USD $72 million based on the exchange rate as of July 1, 2022). Five of the assessments are in various stages of the review process at the administrative level; the Company successfully defeated one of the six assessments in September 2019 (totaling approximately the updated amount of 61 million Brazilian reals or USD $12 million); that assessment remains subject to appeal and no tax proceeding has been finalized yet. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment is 34 million Brazilian reals (approximately USD $7 million). The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the next four years.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-10-31):
[0000866374-22-000074:note_history:3]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers).
  (was, 2022-07-29, similarity 0.8846):
[0000866374-22-000052:note_history:3]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers). The Company also provides intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world.

- changed (2022-10-31):
[0000866374-22-000074:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2022 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.
  (was, 2022-07-29, similarity 0.7733):
[0000866374-22-000052:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2022 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended July 1, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

- changed (2022-10-31):
[0000866374-22-000074:note_history:5]
The first quarters for fiscal years 2023 and 2022 ended on July 1, 2022, which is comprised of 92 days in the period, and July 2, 2021, which is comprised of 93 days in the period, respectively. The second quarters for fiscal years 2023 and 2022 ended on September 30, 2022 and October 1, 2021, respectively, which are comprised of 91 days in both periods.
  (was, 2022-07-29, similarity 0.7082):
[0000866374-22-000052:note_history:5]
The first quarters for fiscal years 2023 and 2022 ended on July 1, 2022, which is comprised of 92 days in the period, and July 2, 2021, which is comprised of 93 days in the period, respectively.

- changed (2022-10-31):
[0000866374-22-000074:note_history:6]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. In all cases other than the redeemable noncontrolling interest in Nextracker, the associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of Interest and other, net, in the condensed consolidated statements of
  (was, 2022-07-29, similarity 0.9181):
[0000866374-22-000052:note_history:6]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. In all cases other than the redeemable noncontrolling interest in Nextracker, the associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations

- changed (2022-10-31):
[0000866374-22-000074:note_history:7]
operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the condensed consolidated statements of operations.
  (was, 2022-07-29, similarity 0.8497):
[0000866374-22-000052:note_history:7]
for all periods presented, and is classified as a component of Interest and other, net, in the condensed consolidated statements of operations. Noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and to the redeemable noncontrolling interest is presented in the condensed consolidated statements of operations.

- added (2022-10-31):
[0000866374-22-000074:note_history:8]
Recently Issued Accounting Pronouncement

- added (2022-10-31):
[0000866374-22-000074:note_history:9]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-31):
[0000866374-22-000074:note_history:10]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 30, 2022 are as follows:
  (was, 2022-07-29, similarity 0.9366):
[0000866374-22-000052:note_history:10]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of July 1, 2022 are as follows:

- added (2022-10-31):
[0000866374-22-000074:note_history:11]
|  | As of September 30, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.446% | 232 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 688 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 688 |  |  | 690 |  |
| Euro Term Loans | 337 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 232 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (16) |  |  | (18) |  |
|  | 3,997 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (916) |  |  | (949) |  |
| Non-current portion | $ | 3,081 |  |  | $ | 3,248 |  |

- changed (2022-10-31):
[0000866374-22-000074:note_history:12]
The weighted-average interest rate for the Company's long-term debt was 4.2% and 4.0% as of September 30, 2022 and March 31, 2022, respectively.
  (was, 2022-07-29, similarity 0.887):
[0000866374-22-000052:note_history:12]
The weighted-average interest rate for the Company's long-term debt was 4.1% and 4.0% as of July 1, 2022 and March 31, 2022.

- changed (2022-10-31):
[0000866374-22-000074:note_history:13]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 30, 2022 are as follows:
  (was, 2022-07-29, similarity 0.9384):
[0000866374-22-000052:note_history:13]
Scheduled repayments of the Company's bank borrowings and long-term debt as of July 1, 2022 are as follows:

- changed (2022-10-31):
[0000866374-22-000074:note_history:14]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2023.
  (was, 2022-07-29, similarity 0.9733):
[0000866374-22-000052:note_history:14]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2023.

- added (2022-10-31):
[0000866374-22-000074:note_history:15]
The 2027 Credit Facility

- added (2022-10-31):
[0000866374-22-000074:note_history:16]
In July 2022, the Company entered into a new $2.5 billion credit agreement which matures in July 2027 (the "2027 Credit Facility") and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2027 Credit Facility replaced the previous $2.0 billion revolving credit facility, which was due to mature in January 2026.

- added (2022-10-31):
[0000866374-22-000074:note_history:17]
Borrowings under the 2027 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the Term Secured Overnight Financing Rate (Term SOFR) rate plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.750% per annum, based on the Company’s credit ratings or (ii) Term SOFR (or (x) the “Alternative Currency Term Rate”, which is defined as, depending on the applicable currency at issue, either the Euro Interbank Offered Rate, Tokyo Interbank Offer Rate, or such other term rate per annum as designated with respect to such alternative currency or (y) the “Alternative Currency Daily Rate”, which is defined as, in the case of Sterling, the rate per annum equal to Sterling Overnight Index Average, and for any other alternative currency, such other term rate per annum as designated with respect to such alternative currency) plus the applicable margin for Term SOFR rate (or the Alternative Currency Term Rate) loans ranging between 1.125% and 1.750% per annum, based on the Company’s credit ratings, plus an adjustment for Term SOFR loans of 0.10% per annum and an adjustment for Sterling Overnight Index Average loans of 0.0326% per annum. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the

- added (2022-10-31):
[0000866374-22-000074:note_history:18]
last business day of March, June, September and December of each calendar year and the maturity date, (ii) in the case of borrowings at the Term SOFR rate (or the Alternative Currency Term Rate), on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month and the maturity date and (iii) in the case of borrowings at the Alternative Currency Daily Rate, on the last day of each calendar month and the maturity date. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2027 Credit Facility ranging from 0.125% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.125% to 1.750% per annum (based on the Company’s credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

- added (2022-10-31):
[0000866374-22-000074:note_history:19]
Under the 2027 Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

- added (2022-10-31):
[0000866374-22-000074:note_history:20]
Delayed Draw Term Loan

- added (2022-10-31):
[0000866374-22-000074:note_history:21]
In September 2022, the Company entered into a $450 million delayed draw term loan credit agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. The delayed draw term loan is available to be drawn through November 30, 2022. All borrowings under the delayed draw term loan will become due on the date that is 364 days after the initial borrowing. Interest is based on either (a) a Term SOFR-based formula plus a margin of 100.0 basis points to 162.5 basis points, depending on the Company’s credit ratings, or (b) a Base Rate formula plus a margin of 0.0 basis point to 62.5 basis points, depending on the Company's credit ratings.

- added (2022-10-31):
[0000866374-22-000074:note_history:22]
The 2027 Credit Facility and delayed draw term loan are unsecured, and contain customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain acquisitions of other entities, (iii) incur liens, (iv) dispose of assets, and (v) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2027 Credit Facility and delayed draw term loan agreement also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio. As of September 30, 2022, the Company had no borrowings outstanding and was in compliance with the covenants under the 2027 Credit Facility and delayed draw term loan agreement.

- removed (2022-10-31):
[0000866374-22-000052:note_history:23]
|  | As of July 1, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.430% | 245 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 689 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 689 |  |  | 690 |  |
| Euro Term Loans | 367 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 266 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (17) |  |  | (18) |  |
|  | 4,075 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (946) |  |  | (949) |  |
| Non-current portion | $ | 3,129 |  |  | $ | 3,248 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-31):
[0000866374-22-000074:note_history:24]
|  | As of September 30, 2022 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 501 |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.446% | 232 |  |  | 232 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 588 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 688 |  |  | 643 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 659 |  |  | 602 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 688 |  |  | 630 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | 337 |  |  | 337 |  |  | 389 |  |  | 389 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 232 |  |  | 232 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | 79 |  |  | 79 |  |  | 84 |  |  | 84 |  |  | Level 2 |
  (was, 2022-07-29, similarity 0.992):
[0000866374-22-000052:note_history:24]
|  | As of July 1, 2022 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 504 |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| Term Loan due April 2024 - three-month TIBOR plus 0.430% | 245 |  |  | 245 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 598 |  |  | 601 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 689 |  |  | 659 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 659 |  |  | 636 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 689 |  |  | 659 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | 367 |  |  | 367 |  |  | 389 |  |  | 389 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 266 |  |  | 266 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | 79 |  |  | 79 |  |  | 84 |  |  | 84 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-31):
[0000866374-22-000074:note_history:25]
Bank borrowings and long-term debt as of September 30, 2022 are as follows:
  (was, 2022-07-29, similarity 0.9037):
[0000866374-22-000052:note_history:25]
Bank borrowings and long-term debt as of July 1, 2022 are as follows:

- added (2022-10-31):
[0000866374-22-000074:note_history:26]
|  | As of September 30, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.446% | 232 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 688 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 688 |  |  | 690 |  |
| Euro Term Loans | 337 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 232 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (16) |  |  | (18) |  |
|  | 3,997 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (916) |  |  | (949) |  |
| Non-current portion | $ | 3,081 |  |  | $ | 3,248 |  |

- removed (2022-10-31):
[0000866374-22-000052:note_history:27]
|  | As of July 1, 2022 |  | As of March 31, 2022 |
|  | (In millions) |
| 5.000% Notes due February 2023 | $ | 500 |  |  | $ | 500 |  |
| Term Loan due April 2024 - three-month TIBOR plus 0.430% | 245 |  |  | 273 |  |
| 4.750% Notes due June 2025 | 598 |  |  | 598 |  |
| 3.750% Notes due February 2026 | 689 |  |  | 690 |  |
| 4.875% Notes due June 2029 | 659 |  |  | 659 |  |
| 4.875% Notes due May 2030 | 689 |  |  | 690 |  |
| Euro Term Loans | 367 |  |  | 389 |  |
| 3.600% HUF Bonds due December 2031 | 266 |  |  | 301 |  |
| India Facilities | 79 |  |  | 84 |  |
| Other | — |  |  | 31 |  |
| Debt issuance costs | (17) |  |  | (18) |  |
|  | 4,075 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs | (946) |  |  | (949) |  |
| Non-current portion | $ | 3,129 |  |  | $ | 3,248 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-31):
[0000866374-22-000074:note_history:28]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 30, 2022 are as follows:
  (was, 2022-07-29, similarity 0.9384):
[0000866374-22-000052:note_history:28]
Scheduled repayments of the Company's bank borrowings and long-term debt as of July 1, 2022 are as follows:

- changed (2022-10-31):
[0000866374-22-000074:note_history:29]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2023.
  (was, 2022-07-29, similarity 0.9733):
[0000866374-22-000052:note_history:29]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2023.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-10-31):
[0000866374-22-000074:note_history:30]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 30, 2022 and October 1, 2021, respectively. Historical information for the first and second quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.
  (was, 2022-07-29, similarity 0.8161):
[0000866374-22-000052:note_history:30]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended July 1, 2022 and July 2, 2021, respectively. Historical information for the first quarter of fiscal year ended March 31, 2022 has been recast to reflect the new operating and reportable segments in the table below.

- changed (2022-10-31):
[0000866374-22-000074:note_history:31]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,787 |  |  | $ | 3,250 |  |  | $ | 7,566 |  |  | $ | 6,498 |  |
| Over time | 217 |  |  | 187 |  |  | 429 |  |  | 371 |  |
| Total | 4,004 |  |  | 3,437 |  |  | 7,995 |  |  | 6,869 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,110 |  |  | 2,308 |  |  | 5,900 |  |  | 4,715 |  |
| Over time | 189 |  |  | 157 |  |  | 368 |  |  | 332 |  |
| Total | 3,299 |  |  | 2,465 |  |  | 6,268 |  |  | 5,047 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 10 |  |  | 12 |  |  | 33 |  |  | 21 |  |
| Over time | 463 |  |  | 327 |  |  | 835 |  |  | 659 |  |
| Total | 473 |  |  | 339 |  |  | 868 |  |  | 680 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,897 |  |  | 5,558 |  |  | 13,481 |  |  | 11,209 |  |
| Over time | 869 |  |  | 671 |  |  | 1,632 |  |  | 1,362 |  |
| Total | $ | 7,766 |  |  | $ | 6,229 |  |  | $ | 15,113 |  |  | $ | 12,571 |  |
  (was, 2022-07-29, similarity 0.6813):
[0000866374-22-000052:note_history:31]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,779 |  |  | $ | 3,248 |  |  |  |  |  |
| Over time | 212 |  |  | 184 |  |  |  |  |  |
| Total | 3,991 |  |  | 3,432 |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,790 |  |  | 2,407 |  |  |  |  |  |
| Over time | 179 |  |  | 175 |  |  |  |  |  |
| Total | 2,969 |  |  | 2,582 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 23 |  |  | 9 |  |  |  |  |  |
| Over time | 372 |  |  | 332 |  |  |  |  |  |
| Total | 395 |  |  | 341 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (8) |  |  | (13) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (8) |  |  | (13) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,584 |  |  | 5,651 |  |  |  |  |  |
| Over time | 763 |  |  | 691 |  |  |  |  |  |
| Total | $ | 7,347 |  |  | $ | 6,342 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-10-31):
[0000866374-22-000074:note_history:32]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.
  (was, 2022-07-29, similarity 0.8231):
[0000866374-22-000052:note_history:32]
can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

- changed (2022-10-31):
[0000866374-22-000074:note_history:33]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.
  (was, 2022-07-29, similarity 0.9997):
[0000866374-22-000052:note_history:33]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

- changed (2022-10-31):
[0000866374-22-000074:note_history:34]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily
  (was, 2022-07-29, similarity 0.8605):
[0000866374-22-000052:note_history:34]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

- added (2022-10-31):
[0000866374-22-000074:note_history:35]
available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

- changed (2022-10-31):
[0000866374-22-000074:note_history:36]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.
  (was, 2022-07-29, similarity 0.7562):
[0000866374-22-000052:note_history:36]
therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

- added (2022-10-31):
[0000866374-22-000074:note_history:37]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $792 million and $704 million as of September 30, 2022 and March 31, 2022, respectively, of which $731 million and $615 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2022-10-31):
[0000866374-22-000074:note_history:38]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 30, 2022 and October 1, 2021, respectively. Historical information for the first and second quarters of the fiscal year ended March 31, 2022 have been recast to reflect the new operating and reportable segments in the table below.
  (was, 2022-07-29, similarity 0.8161):
[0000866374-22-000052:note_history:38]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended July 1, 2022 and July 2, 2021, respectively. Historical information for the first quarter of fiscal year ended March 31, 2022 has been recast to reflect the new operating and reportable segments in the table below.

- changed (2022-10-31):
[0000866374-22-000074:note_history:39]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,787 |  |  | $ | 3,250 |  |  | $ | 7,566 |  |  | $ | 6,498 |  |
| Over time | 217 |  |  | 187 |  |  | 429 |  |  | 371 |  |
| Total | 4,004 |  |  | 3,437 |  |  | 7,995 |  |  | 6,869 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 3,110 |  |  | 2,308 |  |  | 5,900 |  |  | 4,715 |  |
| Over time | 189 |  |  | 157 |  |  | 368 |  |  | 332 |  |
| Total | 3,299 |  |  | 2,465 |  |  | 6,268 |  |  | 5,047 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 10 |  |  | 12 |  |  | 33 |  |  | 21 |  |
| Over time | 463 |  |  | 327 |  |  | 835 |  |  | 659 |  |
| Total | 473 |  |  | 339 |  |  | 868 |  |  | 680 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (10) |  |  | (12) |  |  | (18) |  |  | (25) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,897 |  |  | 5,558 |  |  | 13,481 |  |  | 11,209 |  |
| Over time | 869 |  |  | 671 |  |  | 1,632 |  |  | 1,362 |  |
| Total | $ | 7,766 |  |  | $ | 6,229 |  |  | $ | 15,113 |  |  | $ | 12,571 |  |
  (was, 2022-07-29, similarity 0.6813):
[0000866374-22-000052:note_history:39]
|  | Three-Month Periods Ended |  |  |
|  | July 1, 2022 |  | July 2, 2021 |  |  |  |  |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,779 |  |  | $ | 3,248 |  |  |  |  |  |
| Over time | 212 |  |  | 184 |  |  |  |  |  |
| Total | 3,991 |  |  | 3,432 |  |  |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,790 |  |  | 2,407 |  |  |  |  |  |
| Over time | 179 |  |  | 175 |  |  |  |  |  |
| Total | 2,969 |  |  | 2,582 |  |  |  |  |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 23 |  |  | 9 |  |  |  |  |  |
| Over time | 372 |  |  | 332 |  |  |  |  |  |
| Total | 395 |  |  | 341 |  |  |  |  |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (8) |  |  | (13) |  |  |  |  |  |
| Over time | — |  |  | — |  |  |  |  |  |
| Total | (8) |  |  | (13) |  |  |  |  |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 6,584 |  |  | 5,651 |  |  |  |  |  |
| Over time | 763 |  |  | 691 |  |  |  |  |  |
| Total | $ | 7,347 |  |  | $ | 6,342 |  |  |  |  |  |

- removed (2022-10-31):
[0000866374-22-000052:note_history:40]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and

- removed (2022-10-31):
[0000866374-22-000052:note_history:41]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is,

- removed (2022-10-31):
[0000866374-22-000052:note_history:42]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $741 million and $704 million as of July 1, 2022 and March 31, 2022, respectively, of which $645 million and $615 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2022-10-31):
[0000866374-22-000052:note_history:43]
SUBSEQUENT EVENTSOn July 19, 2022, the Company entered into a new $2.5 billion credit agreement (the "New Credit Facility") which matures in July 2027 and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans and a sub-limit of $175 million available for the issuance of letters of credit. The New Credit Facility replaced the previous $2.0 billion credit facility. Under the New Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.
