# FLEX MD&A — 0000866374-22-000074


## mdna

[0000866374-22-000074:mdna:1]
[same as prior period, unchanged from 0000866374-22-000052:mdna:1]

[0000866374-22-000074:mdna:2]
Unless otherwise specifically stated, references in this report to “Flex,” “the Company,” “we,” “us,” “our” and similar terms mean Flex Ltd. and its subsidiaries.

[0000866374-22-000074:mdna:3]
[same as prior period, unchanged from 0000866374-22-000052:mdna:3]

[0000866374-22-000074:mdna:4]
[same as prior period, unchanged from 0000866374-22-000052:mdna:4]

[0000866374-22-000074:mdna:5]
[same as prior period, unchanged from 0000866374-22-000052:mdna:5]

[0000866374-22-000074:mdna:6]
[same as prior period, unchanged from 0000866374-22-000052:mdna:6]

[0000866374-22-000074:mdna:7]
[same as prior period, unchanged from 0000866374-22-000052:mdna:7]

[0000866374-22-000074:mdna:8]
[same as prior period, unchanged from 0000866374-22-000052:mdna:8]

[0000866374-22-000074:mdna:9]
[same as prior period, unchanged from 0000866374-22-000052:mdna:9]

[0000866374-22-000074:mdna:10]
[same as prior period, unchanged from 0000866374-22-000052:mdna:10]

[0000866374-22-000074:mdna:11]
[same as prior period, unchanged from 0000866374-22-000052:mdna:11]

[0000866374-22-000074:mdna:12]
[same as prior period, unchanged from 0000866374-22-000052:mdna:12]

[0000866374-22-000074:mdna:13]
[same as prior period, unchanged from 0000866374-22-000052:mdna:13]

[0000866374-22-000074:mdna:14]
[same as prior period, unchanged from 0000866374-22-000052:mdna:14]

[0000866374-22-000074:mdna:15]
[same as prior period, unchanged from 0000866374-22-000052:mdna:15]

[0000866374-22-000074:mdna:16]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and

[0000866374-22-000074:mdna:17]
requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-22-000074:mdna:18]
[same as prior period, unchanged from 0000866374-22-000052:mdna:18]

[0000866374-22-000074:mdna:19]
[same as prior period, unchanged from 0000866374-22-000052:mdna:19]

[0000866374-22-000074:mdna:20]
With the second wave of the global pandemic including follow-on variants of COVID-19, there have been renewed disease control measures being taken to limit the spread including movement bans and shelter-in-place orders. Although not materially impacting our results for the first half of fiscal year 2023, with the lockdowns in China, we experienced temporary plant closures and/or restrictions at certain of our manufacturing facilities in China. We continue to closely monitor the situation in all the locations where we operate. Our priority remains the welfare of our employees. In addition, our end markets continue to be impacted by the global supply chain disruptions. Component shortages and logistical constraints are pervasive across the entire value chain. We expect persistent waves of COVID-19 to remain a headwind into the near future. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future. We continue to carefully monitor potential supply chain disruptions due to ongoing tightness in the overall component environment. Refer to “Risk Factors - The ongoing COVID-19 pandemic has materially and adversely affected our business and results of operations. The duration and extent to which it will continue to adversely impact our business and results of operations remains uncertain and could be material.”  and “-- Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, could affect our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory. We have been and continue to be adversely affected by supply chain issues, including shortages of required electronic components.” as disclosed in Part I, “Item 1A. Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0000866374-22-000074:mdna:21]
[same as prior period, unchanged from 0000866374-22-000052:mdna:21]

[0000866374-22-000074:mdna:22]
[same as prior period, unchanged from 0000866374-22-000052:mdna:22]

[0000866374-22-000074:mdna:23]
We continue to monitor and respond to the escalating conflict in Ukraine and the associated sanctions and other restrictions. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine. The full impact of the conflict on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflict and its impact on regional and global economic conditions. We will continue to monitor the conflict and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-22-000074:mdna:24]
[same as prior period, unchanged from 0000866374-22-000052:mdna:24]

[0000866374-22-000074:mdna:25]
[same as prior period, unchanged from 0000866374-22-000052:mdna:25]

[0000866374-22-000074:mdna:26]
On February 1, 2022, one of our subsidiaries sold Series A Preferred Units representing a 16.7% interest in Nextracker to TPG Rise for an aggregate purchase price of $500 million. The sale of the 16.7% interest in Nextracker reflects an implied value for Nextracker as of the date of the sale of $3.0 billion. See Note 7 to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022 for further information.

[0000866374-22-000074:mdna:27]
This Quarterly Report on Form 10-Q for the fiscal quarter ended September 30, 2022 does not constitute an offer to sell or a solicitation of an offer to buy securities, and shall not constitute an offer, solicitation or sale in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of that jurisdiction.

[0000866374-22-000074:mdna:28]
[same as prior period, unchanged from 0000866374-22-000052:mdna:29]

[0000866374-22-000074:mdna:29]
We are one of the world's largest providers of global supply chain solutions, with revenues of $15.1 billion for the six-month period ended September 30, 2022 and $26.0 billion in the fiscal year ended March 31, 2022. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. We also provide intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-22-000074:mdna:30]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 3,459 |  |  | 45 | % |  | $ | 2,605 |  |  | 42 | % |  | $ | 6,774 |  |  | 45 | % |  | $ | 5,184 |  |  | 41 | % |
| Asia | 2,751 |  |  | 35 | % |  | 2,347 |  |  | 38 | % |  | 5,268 |  |  | 35 | % |  | 4,712 |  |  | 37 | % |
| Europe | 1,556 |  |  | 20 | % |  | 1,277 |  |  | 20 | % |  | 3,071 |  |  | 20 | % |  | 2,675 |  |  | 22 | % |
|  | $ | 7,766 |  |  |  |  | $ | 6,229 |  |  |  |  | $ | 15,113 |  |  |  |  | $ | 12,571 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| China | $ | 1,770 |  |  | 23 | % |  | $ | 1,547 |  |  | 25 | % |  | $ | 3,354 |  |  | 22 | % |  | $ | 3,078 |  |  | 24 | % |
| Mexico | 1,601 |  |  | 21 | % |  | 1,240 |  |  | 20 | % |  | 3,156 |  |  | 21 | % |  | 2,460 |  |  | 20 | % |
| U.S. | 1,294 |  |  | 17 | % |  | 846 |  |  | 14 | % |  | 2,511 |  |  | 17 | % |  | 1,722 |  |  | 14 | % |
| Malaysia | 633 |  |  | 8 | % |  | 412 |  |  | 7 | % |  | 1,204 |  |  | 8 | % |  | 823 |  |  | 7 | % |
| Brazil | 547 |  |  | 7 | % |  | 502 |  |  | 8 | % |  | 1,074 |  |  | 7 | % |  | 966 |  |  | 8 | % |
| Hungary | 330 |  |  | 4 | % |  | 295 |  |  | 5 | % |  | 616 |  |  | 4 | % |  | 647 |  |  | 5 | % |
| Other | 1,591 |  |  | 20 | % |  | 1,387 |  |  | 21 | % |  | 3,198 |  |  | 21 | % |  | 2,875 |  |  | 22 | % |
|  | $ | 7,766 |  |  |  |  | $ | 6,229 |  |  |  |  | $ | 15,113 |  |  |  |  | $ | 12,571 |  |  |  |

[0000866374-22-000074:mdna:31]
|  | As of |  | As of |
| Property and equipment, net: | September 30, 2022 |  | March 31, 2022 |
|  | (In millions) |
| Mexico | $ | 672 |  |  | 31 | % |  | $ | 626 |  |  | 29 | % |
| U.S. | 371 |  |  | 17 | % |  | 354 |  |  | 17 | % |
| China | 323 |  |  | 15 | % |  | 299 |  |  | 14 | % |
| Malaysia | 137 |  |  | 6 | % |  | 110 |  |  | 5 | % |
| Hungary | 113 |  |  | 5 | % |  | 118 |  |  | 6 | % |
| India | 112 |  |  | 5 | % |  | 129 |  |  | 6 | % |
| Other | 473 |  |  | 21 | % |  | 489 |  |  | 23 | % |
|  | $ | 2,201 |  |  |  |  | $ | 2,125 |  |  |  |

[0000866374-22-000074:mdna:32]
[same as prior period, unchanged from 0000866374-22-000052:mdna:33]

[0000866374-22-000074:mdna:33]
[same as prior period, unchanged from 0000866374-22-000052:mdna:34]

[0000866374-22-000074:mdna:34]
[same as prior period, unchanged from 0000866374-22-000052:mdna:35]

[0000866374-22-000074:mdna:35]
[same as prior period, unchanged from 0000866374-22-000052:mdna:36]

[0000866374-22-000074:mdna:36]
[same as prior period, unchanged from 0000866374-22-000052:mdna:73]

[0000866374-22-000074:mdna:37]
[same as prior period, unchanged from 0000866374-22-000052:mdna:37]

[0000866374-22-000074:mdna:38]
[same as prior period, unchanged from 0000866374-22-000052:mdna:38]

[0000866374-22-000074:mdna:39]
[same as prior period, unchanged from 0000866374-22-000052:mdna:39]

[0000866374-22-000074:mdna:40]
[same as prior period, unchanged from 0000866374-22-000052:mdna:40]

[0000866374-22-000074:mdna:41]
[same as prior period, unchanged from 0000866374-22-000052:mdna:41]

[0000866374-22-000074:mdna:42]
[same as prior period, unchanged from 0000866374-22-000052:mdna:42]

[0000866374-22-000074:mdna:43]
[same as prior period, unchanged from 0000866374-22-000052:mdna:43]

[0000866374-22-000074:mdna:44]
[same as prior period, unchanged from 0000866374-22-000052:mdna:44]

[0000866374-22-000074:mdna:45]
[same as prior period, unchanged from 0000866374-22-000052:mdna:45]

[0000866374-22-000074:mdna:46]
[same as prior period, unchanged from 0000866374-22-000052:mdna:46]

[0000866374-22-000074:mdna:47]
[same as prior period, unchanged from 0000866374-22-000052:mdna:47]

[0000866374-22-000074:mdna:48]
[same as prior period, unchanged from 0000866374-22-000052:mdna:48]

[0000866374-22-000074:mdna:49]
[same as prior period, unchanged from 0000866374-22-000052:mdna:49]

[0000866374-22-000074:mdna:50]
[same as prior period, unchanged from 0000866374-22-000052:mdna:50]

[0000866374-22-000074:mdna:51]
[same as prior period, unchanged from 0000866374-22-000052:mdna:51]

[0000866374-22-000074:mdna:52]
[same as prior period, unchanged from 0000866374-22-000052:mdna:52]

[0000866374-22-000074:mdna:53]
[same as prior period, unchanged from 0000866374-22-000052:mdna:53]

[0000866374-22-000074:mdna:54]
[same as prior period, unchanged from 0000866374-22-000052:mdna:54]

[0000866374-22-000074:mdna:55]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 92.4 |  |  | 92.4 |  |  | 92.5 |  |  | 92.5 |  |
| Restructuring charges | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Gross profit | 7.6 |  |  | 7.5 |  |  | 7.5 |  |  | 7.4 |  |
| Selling, general and administrative expenses | 3.2 |  |  | 3.4 |  |  | 3.2 |  |  | 3.3 |  |
| Intangible amortization | 0.2 |  |  | 0.3 |  |  | 0.3 |  |  | 0.2 |  |
| Operating income | 4.2 |  |  | 3.8 |  |  | 4.0 |  |  | 3.9 |  |
| Interest and other, net | 0.7 |  |  | (2.2) |  |  | 0.7 |  |  | (0.9) |  |
| Income before income taxes | 3.5 |  |  | 6.0 |  |  | 3.3 |  |  | 4.8 |  |
| Provision for income taxes | 0.4 |  |  | 0.6 |  |  | 0.4 |  |  | 0.5 |  |
| Net income | 3.1 | % |  | 5.4 | % |  | 2.9 | % |  | 4.3 | % |
| Net income attributable to redeemable noncontrolling interest | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |
| Net income attributable to Flex Ltd. | 3.0 | % |  | 5.4 | % |  | 2.8 | % |  | 4.3 | % |

[0000866374-22-000074:mdna:56]
[same as prior period, unchanged from 0000866374-22-000052:mdna:56]

[0000866374-22-000074:mdna:57]
[same as prior period, unchanged from 0000866374-22-000052:mdna:57]

[0000866374-22-000074:mdna:58]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 4,004 |  |  | 52 | % |  | $ | 3,437 |  |  | 55 | % |  | $ | 7,995 |  |  | 53 | % |  | $ | 6,869 |  |  | 55 | % |
| Flex Reliability Solutions | 3,299 |  |  | 42 | % |  | 2,465 |  |  | 40 | % |  | 6,268 |  |  | 41 | % |  | 5,047 |  |  | 40 | % |
| Nextracker | 473 |  |  | 6 | % |  | 339 |  |  | 5 | % |  | 868 |  |  | 6 | % |  | 680 |  |  | 5 | % |
| Intersegment eliminations | (10) |  |  | — | % |  | (12) |  |  | — | % |  | (18) |  |  | — | % |  | (25) |  |  | — | % |
|  | $ | 7,766 |  |  |  |  | $ | 6,229 |  |  |  |  | $ | 15,113 |  |  |  |  | $ | 12,571 |  |  |  |

[0000866374-22-000074:mdna:59]
Net sales during the three-month period ended September 30, 2022 totaled $7.8 billion, representing an increase of approximately $1.5 billion, or 25% from $6.2 billion during the three-month period ended October 1, 2021. Net sales for our FAS segment increased approximately $0.6 billion, or 16% from the three-month period ended October 1, 2021, primarily driven by strong year-over-year growth in our Communications, Enterprise and Cloud (CEC) business and a low single-digit year-over-year increase in our Lifestyle business due to new program wins, ramps, and clear-to-build improvement. These increases in FAS were offset by a high-teen year-over-year decrease in our Consumer Devices business due to relatively softer market demand and a planned project completion in the fiscal year ended March 31, 2022. Net sales for our FRS segment increased approximately $0.8 billion, or 34% from the three-month period ended October 1, 2021, primarily driven by a strong year-over-year increase in our Industrial and Automotive businesses and a low-teen year-over year increase in our Health Solutions business due to strong customer demand and ramps across various end markets coupled with incremental revenues from our Anord Mardix acquisition, despite continued supply constraints. Net sales for our Nextracker segment increased approximately $0.1 billion, or 40% from the three-month period ended October 1, 2021, primarily driven by an increase in gigawatts delivered and to a lesser extent, an increased average selling price. Net sales increased across all regions with a $0.9 billion increase to $3.5 billion in the Americas, a $0.4 billion increase to $2.8 billion in Asia, and a $0.3 billion increase to $1.6 billion in Europe.

[0000866374-22-000074:mdna:60]
31

[0000866374-22-000074:mdna:61]
Net sales during the six-month period ended September 30, 2022 totaled $15.1 billion, representing an increase of approximately $2.5 billion, or 20% from $12.6 billion during the six-month period ended October 1, 2021. Net sales for our FAS segment increased approximately $1.1 billion, or 16% from the six-month period ended October 1, 2021, primarily driven by strong growth in our CEC business and a mid single-digit increase in our Lifestyle business during the current year due to new ramps, customer expansion, continued recoveries in consumer spending along with some effect from inflation pass-through while overcoming challenges from supply constraints. These increases in FAS were offset by a high-teen decrease in our Consumer Device business during the current year due to the same factors in the three-month periods discussion above. Net sales for our FRS segment increased approximately $1.2 billion, or 24% from the six-month period ended October 1, 2021, primarily driven by strong increases in our Industrial and Automotive businesses, and a mid single-digit year-over year increase in our Health Solutions business during the current year due to strong customer demand and ramps across various end markets coupled with incremental revenues from our Anord Mardix acquisition and the recovery of inflationary costs, despite continued supply constraints noted above. Net sales for our Nextracker segment increased approximately $0.2 billion, or 28% from the six-month period ended October 1, 2021, primarily driven by an increase in gigawatts delivered and to a lesser extent, an increased average selling price which was in part driven by an increase in logistics costs. Net sales increased across all regions with a $1.6 billion increase to $6.8 billion in the Americas, a $0.6 billion increase to $5.3 billion in Asia, and a $0.4 billion increase to $3.1 billion in Europe.

[0000866374-22-000074:mdna:62]
Our ten largest customers during the three and six-month periods ended September 30, 2022 accounted for approximately 35% of net sales. Our ten largest customers during the three and six-month periods ended October 1, 2021 accounted for approximately 36% and 35% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and six-month periods ended September 30, 2022 or October 1, 2021.

[0000866374-22-000074:mdna:63]
[same as prior period, unchanged from 0000866374-22-000052:mdna:62]

[0000866374-22-000074:mdna:64]
[same as prior period, unchanged from 0000866374-22-000052:mdna:63]

[0000866374-22-000074:mdna:65]
Cost of sales during the three-month period ended September 30, 2022 totaled $7.2 billion, representing an increase of approximately $1.4 billion, or 25% from $5.8 billion during the three-month period ended October 1, 2021. The higher cost of sales for the three-month period ended September 30, 2022 was primarily driven by increased consolidated sales of $1.5 billion or 25%. Cost of sales in FAS for the three-month period ended September 30, 2022 increased approximately $0.5 billion, or 17% from the three-month period ended October 1, 2021, which is relatively in line with the overall 16% increase in FAS revenue during the same period primarily as a result of higher revenue in our CEC and Lifestyle businesses. Cost of sales in FRS for the three-month period ended September 30, 2022 increased approximately $0.8 billion, or 34% from the three-month period ended October 1, 2021, which is in line with the overall 34% increase in FRS revenue during the same period, primarily as a result of higher revenue in our Industrial and Automotive businesses. Cost of sales in our Nextracker segment for the three-month period ended September 30, 2022 increased approximately $0.1 billion, or 36% from the three-month period ended October 1, 2021, primarily due to the 40% increase in Nextracker revenue during the same period partially offset by improved recovery on freight and logistics cost increases.

[0000866374-22-000074:mdna:66]
Cost of sales during the six-month period ended September 30, 2022 totaled $14.0 billion, representing an increase of approximately $2.4 billion, or 20% from $11.6 billion during the six-month period ended October 1, 2021. The higher cost of sales for the six-month period ended September 30, 2022 was primarily driven by increased consolidated sales of $2.5 billion or 20%. Cost of sales in FAS for the six-month period ended September 30, 2022 increased approximately $1.1 billion, or 16% from the six-month period ended October 1, 2021, which is aligned with the overall 16% increase in FAS revenue during the same period primarily due to the drivers noted in the discussion above for the three-month period. Cost of sales in FRS for the six-month period ended September 30, 2022 increased approximately $1.1 billion, or 25% from the six-month period ended October 1, 2021, which is relatively in line with the overall 24% increase in FRS revenue during the same period, primarily due to the drivers noted in the discussion above for the three-month period. Cost of sales in our Nextracker segment for the six-month period ended September 30, 2022 increased approximately $0.2 billion, or 25% from the six-month period ended October 1, 2021, primarily driven by the same factors noted above in the three-month periods discussion.

[0000866374-22-000074:mdna:67]
[same as prior period, unchanged from 0000866374-22-000052:mdna:65]

[0000866374-22-000074:mdna:68]
Gross profit is affected by fluctuations in cost of sales elements as outlined above and further by a number of factors, including product life cycles, unit volumes, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves

[0000866374-22-000074:mdna:69]
over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-22-000074:mdna:70]
Gross profit during the three-month period ended September 30, 2022 increased $0.1 billion to $0.6 billion, or 7.6% of net sales, from $0.5 billion, or 7.5% of net sales, during the three-month period ended October 1, 2021. Gross margin improved 10 basis points during the three-month period ended September 30, 2022 primarily due to the overall strong customer demand across various end markets which allowed for improved fixed cost absorption and benefits from prior restructuring activities, despite continued pressure on margin from component shortages, logistics constraints and the pass-through effect of inflationary cost recoveries.

[0000866374-22-000074:mdna:71]
Gross profit during the six-month period ended September 30, 2022 increased $0.2 billion to $1.1 billion, or 7.5% of net sales, from $0.9 billion, or 7.4% of net sales, during the six-month period ended October 1, 2021. Gross margin improved 10 basis points during the same period due to the same factors noted above in the three-month periods discussion.

[0000866374-22-000074:mdna:72]
[same as prior period, unchanged from 0000866374-22-000052:mdna:68]

[0000866374-22-000074:mdna:73]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, and legal and other. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-22-000074:mdna:74]
[same as prior period, unchanged from 0000866374-22-000052:mdna:70]

[0000866374-22-000074:mdna:75]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |  | September 30, 2022 |  | October 1, 2021 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 170 |  |  | 4.3 | % |  | $ | 153 |  |  | 4.5 | % |  | $ | 342 |  |  | 4.3 | % |  | $ | 290 |  |  | 4.2 | % |
| Flex Reliability Solutions | 175 |  |  | 5.3 | % |  | 126 |  |  | 5.1 | % |  | 322 |  |  | 5.1 | % |  | 271 |  |  | 5.4 | % |
| Nextracker | 43 |  |  | 9.1 | % |  | 25 |  |  | 7.4 | % |  | 73 |  |  | 8.4 | % |  | 50 |  |  | 7.4 | % |

[0000866374-22-000074:mdna:76]
FAS segment margin decreased approximately 20 basis points, to 4.3%, for the three-month period ended September 30, 2022, from 4.5% for the three-month period ended October 1, 2021. The margin decrease was driven by elevated costs due to component shortages and logistics constraints combined with certain inflation pass-through recoveries. The FAS segment margin increased approximately 10 basis point, to 4.3% for the six-month period ended September 30, 2022, from 4.2% for the six-month period ended October 1, 2021. The increase in FAS segment margin during the six-month period is primarily due to strong execution against new project ramps and product mix, partially offset by elevated costs due to component shortages and logistics constraints and the effect of certain inflation pass-through recoveries.

[0000866374-22-000074:mdna:77]
FRS segment margin increased approximately 20 basis points, to 5.3% for the three-month period ended September 30, 2022, from 5.1% for the three-month period ended October 1, 2021. The margin increase in FRS was primarily driven by higher margin from the Anord Mardix acquisition in our Industrial business, coupled with logistics constraints, partially offset by production disruptions in our Automotive and Health Solutions businesses during the three-month period ended September 30, 2022. FRS segment margin decreased approximately 30 basis points, to 5.1% for the six-month period ended September 30, 2022, from 5.4% for the six-month period ended October 1, 2021. The decrease in FRS segment margin during the six-month period was primarily driven by component shortage related production disruptions, as well as inflationary cost pressures impacting our Health Solutions and Automotive businesses.

[0000866374-22-000074:mdna:78]
Nextracker segment margin increased approximately 170 basis points, to 9.1% for the three-month period ended September 30, 2022, from 7.4% for the three-month period ended October 1, 2021. The margin increase was driven by improved pricing and better cost controls and better cost absorption with increased revenue. Nextracker segment margin increased approximately 100 basis points, to 8.4% for the six-month period ended September 30, 2022, from 7.4% for the six-month period ended October 1, 2021. The increase in Nextracker segment margin during the six-month period is due to the same factors noted in the discussion above for the three-month period.

[0000866374-22-000074:mdna:79]
[same as prior period, unchanged from 0000866374-22-000052:mdna:76]

[0000866374-22-000074:mdna:80]
Selling, general and administrative expenses (“SG&A”) was approximately $0.2 billion, or 3.2% of net sales, during the three-month period ended September 30, 2022, increasing $32 million from approximately $0.2 billion and improving 20 basis

[0000866374-22-000074:mdna:81]
points from 3.4% of net sales, during the three-month period ended October 1, 2021. SG&A was $0.5 billion, or 3.2% of net sales, during the six-month period ended September 30, 2022, increasing $72 million from $0.4 billion and improving 10 basis points from 3.3% of net sales, during the six-month period ended October 1, 2021, which reflects our enhanced cost control efforts to support higher revenue growth while keeping our SG&A expenses relatively flat.

[0000866374-22-000074:mdna:82]
[same as prior period, unchanged from 0000866374-22-000052:mdna:78]

[0000866374-22-000074:mdna:83]
Amortization of intangible assets increased to $21 million during the three-month period ended September 30, 2022, from $15 million for the three-month period ended October 1, 2021, and increased to $43 million during the six-month period ended September 30, 2022, from $30 million for the six-month period ended October 1, 2021, primarily due to amortization expense related to new intangible assets from the Anord Mardix acquisition completed in December 2021.

[0000866374-22-000074:mdna:84]
[same as prior period, unchanged from 0000866374-22-000052:mdna:80]

[0000866374-22-000074:mdna:85]
Interest and other, net was an expense of $53 million during the three-month period ended September 30, 2022 compared to income of $134 million during the three-month period ended October 1, 2021, primarily due to the absence in the three-month period ended September 30, 2022 of the $149 million gain related to a certain tax credit recorded upon approval of a "Credit Habilitation" request by the relevant Brazilian tax authorities in the three-month period ended October 1, 2021 and losses from equity in earnings recognized for certain of our non-core equity method investments, coupled with higher interest expense compared to the prior year period.

[0000866374-22-000074:mdna:86]
Interest and other, net was an expense of $93 million during the six-month period ended September 30, 2022 compared to income of $111 million during the six-month period ended October 1, 2021, due to the same drivers noted in the discussion above.

[0000866374-22-000074:mdna:87]
[same as prior period, unchanged from 0000866374-22-000052:mdna:82]

[0000866374-22-000074:mdna:88]
[same as prior period, unchanged from 0000866374-22-000052:mdna:83]

[0000866374-22-000074:mdna:89]
The consolidated effective tax rate was 13% and 14% for the three and six-month periods ended September 30, 2022, and 9% and 10% for the three and six-month periods ended October 1, 2021, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, the Netherlands and Israel. The effective tax rate for the three and six-month periods ended September 30, 2022 were higher than the effective tax rates for the three-month and six-month periods ended October 1, 2021 due to the changing jurisdictional mix of income and there were significant Brazilian indirect tax credits recorded for the three and six-month periods ended October 1, 2021 with minimal tax impact.

[0000866374-22-000074:mdna:90]
On August 16, 2022, the Inflation Reduction Act of 2022 (“IRA”) was enacted into law, which includes a new corporate minimum tax, a stock repurchase excise tax, numerous green energy credits, other tax provisions, and significantly increased enforcement resources. We are evaluating the effect the IRA will have on our consolidated financial statements.

[0000866374-22-000074:mdna:91]
[same as prior period, unchanged from 0000866374-22-000052:mdna:85]

[0000866374-22-000074:mdna:92]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of September 30, 2022, we had cash and cash equivalents of approximately $2.5 billion and bank and other borrowings of approximately $4.0 billion. As of September 30, 2022, we had a $2.5 billion revolving credit facility that is due to mature in July 2027 (the "2027 Credit Facility"), under which we had no borrowings outstanding. We also entered into a $450 million delayed draw term loan credit agreement, under which we had no borrowings outstanding as of September 30, 2022. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. Refer to note 6 to the condensed consolidated financial statement for details on the 2027 Credit Facility and the delayed draw term loan. As of September 30, 2022, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-22-000074:mdna:93]
Cash provided by operating activities was $0.1 billion during the six-month period ended September 30, 2022, primarily driven by $0.4 billion of net income for the period plus $0.3 billion of non-cash charges such as depreciation, amortization, and stock-based compensation offset by changes in net working capital as discussed below.

[0000866374-22-000074:mdna:94]
We believe net working capital ("NWC") and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital is calculated as current quarter accounts receivable, net of allowance for doubtful accounts, plus inventories and contract assets, less accounts payable. Net working capital increased $1.2 billion to $5.4 billion as of September 30, 2022, from $4.2 billion as of March 31, 2022. This increase is primarily driven by a $1.1 billion increase in inventories due to strong demand, coupled with continued component shortages and logistics constraints, clear-to build constraints and logistics challenges driving up buffer stock and inventory pricing, and a $0.6 billion increase in net receivables, offset by a $0.6 billion increase in accounts payable due to increased inventory purchases. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended September 30, 2022, increased to 17.4% from 15.4% of annualized net sales for the quarter ended March 31, 2022 due to component shortages, clear-to-build and logistics constraints. We continue to experience component shortages in the supply chain, and although we are actively managing these impacts, we expect continued working capital pressure in the near future. We expect it will take additional time to adequately drive down our inventory levels to align with the current demand environment. We are proactively working with our partners to rebalance safety and buffer stock requirements and we have an established enterprise-wide cross-functional initiative resetting our load planning. Component shortages and significantly increased logistic costs are also expected to persist at least in the near future. We are working diligently with our partners to secure needed parts and fulfill demand. In addition, to the extent possible, we have collaborated with our customers for working capital advances to offset the required investment in inventory. Advances from customers as of September 30, 2022 increased $0.6 billion to $2.0 billion from $1.4 billion as of March 31, 2022.

[0000866374-22-000074:mdna:95]
Cash used in investing activities was $0.3 billion during the six-month period ended September 30, 2022. This was primarily driven by $0.3 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Automotive, Industrial, Health Solutions, and Lifestyle businesses.

[0000866374-22-000074:mdna:96]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investor transparency. Our adjusted free cash flow for the six-month period ended September 30, 2022 and October 1, 2021 was an outflow of $0.1 billion and an inflow of $0.3 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-22-000074:mdna:97]
|  | Six-Month Periods Ended |
|  | September 30, 2022 |  | October 1, 2021 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 141 |  |  | $ | 514 |  |
| Purchases of property and equipment | (296) |  |  | (210) |  |
| Proceeds from the disposition of property and equipment | 18 |  |  | 5 |  |
| Adjusted free cash flow | $ | (137) |  |  | $ | 309 |  |

[0000866374-22-000074:mdna:98]
Cash used by financing activities was $0.3 billion during the six-month period ended September 30, 2022, which was primarily driven by $0.3 billion of cash paid for the repurchase of our ordinary shares.

[0000866374-22-000074:mdna:99]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of September 30, 2022 and March 31, 2022, approximately 30% and 34%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of

[0000866374-22-000074:mdna:100]
35

[0000866374-22-000074:mdna:101]
Singapore (approximately $1.6 billion as of March 31, 2022). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-22-000074:mdna:102]
[same as prior period, unchanged from 0000866374-22-000052:mdna:96]

[0000866374-22-000074:mdna:103]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. The cumulative payments due to suppliers participating in the programs amounted to approximately $0.4 billion and $0.8 billion for the three and six-month periods ended September 30, 2022, respectively, and $0.3 billion and $0.6 billion for the three and six-month periods ended October 1, 2021, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-22-000074:mdna:104]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to a commercial paper program, and a revolving sale and repurchase of subordinated notes established under the securitization facility, under which there were no borrowings outstanding as of September 30, 2022.

[0000866374-22-000074:mdna:105]
[same as prior period, unchanged from 0000866374-22-000052:mdna:99]

[0000866374-22-000074:mdna:106]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-22-000074:mdna:107]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 25, 2022. During the six-month period ended September 30, 2022, we paid $253 million to repurchase shares under the current and prior repurchase plans at an average price of $16.15 per share. As of September 30, 2022, shares in the aggregate amount of $977 million were available to be repurchased under the current plan.

[0000866374-22-000074:mdna:108]
[same as prior period, unchanged from 0000866374-22-000052:mdna:102]

[0000866374-22-000074:mdna:109]
[same as prior period, unchanged from 0000866374-22-000052:mdna:103]

[0000866374-22-000074:mdna:110]
In July 2022, we entered into a new $2.5 billion credit facility which matures in July 2027, replacing our previous $2.0 billion credit facility, under which we had no borrowings outstanding as of September 30, 2022.

[0000866374-22-000074:mdna:111]
In September 2022, we entered into a $450 million delayed draw term loan credit agreement, under which we had no borrowings outstanding September 30, 2022. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes.

[0000866374-22-000074:mdna:112]
Other than the changes discussed above, there were no material changes in our contractual obligations and commitments as of September 30, 2022.
