# FLEX MD&A — 0000866374-18-000003


## mdna

[0000866374-18-000003:mdna:1]
[same as prior period, unchanged from 0000866374-17-000012:mdna:1]

[0000866374-18-000003:mdna:2]
[same as prior period, unchanged from 0000866374-17-000012:mdna:2]

[0000866374-18-000003:mdna:3]
[same as prior period, unchanged from 0000866374-17-000012:mdna:3]

[0000866374-18-000003:mdna:4]
[same as prior period, unchanged from 0000866374-17-000012:mdna:4]

[0000866374-18-000003:mdna:5]
[same as prior period, unchanged from 0000866374-17-000012:mdna:5]

[0000866374-18-000003:mdna:6]
[same as prior period, unchanged from 0000866374-17-000012:mdna:6]

[0000866374-18-000003:mdna:7]
[same as prior period, unchanged from 0000866374-17-000012:mdna:7]

[0000866374-18-000003:mdna:8]
| • | High Reliability Solutions ("HRS"), which is comprised of our medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; our automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies. |

[0000866374-18-000003:mdna:9]
[same as prior period, unchanged from 0000866374-17-000012:mdna:9]

[0000866374-18-000003:mdna:10]
[same as prior period, unchanged from 0000866374-17-000012:mdna:10]

[0000866374-18-000003:mdna:11]
[same as prior period, unchanged from 0000866374-17-000012:mdna:11]

[0000866374-18-000003:mdna:12]
[same as prior period, unchanged from 0000866374-17-000012:mdna:12]

[0000866374-18-000003:mdna:13]
We believe that our continued business transformation is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services, which remain strong.

[0000866374-18-000003:mdna:14]
We are one of the world's largest providers of global supply chain solutions, with revenues of $19.0 billion for the nine-month period ended December 31, 2017 and $23.9 billion in fiscal year 2017. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-18-000003:mdna:15]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Net sales: | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
|  | (In millions) |
| China | $ | 1,996 |  |  | 30 | % |  | $ | 1,823 |  |  | 30 | % |  | $ | 5,493 |  |  | 29 | % |  | $ | 5,623 |  |  | 31 | % |
| Mexico | 1,183 |  |  | 17 | % |  | 1,129 |  |  | 17 | % |  | 3,302 |  |  | 17 | % |  | 2,998 |  |  | 17 | % |
| Brazil | 729 |  |  | 11 | % |  | 536 |  |  | 9 | % |  | 1,969 |  |  | 10 | % |  | 1,326 |  |  | 7 | % |
| U.S. | 723 |  |  | 11 | % |  | 589 |  |  | 10 | % |  | 2,157 |  |  | 12 | % |  | 2,006 |  |  | 11 | % |
| Malaysia | 507 |  |  | 7 | % |  | 585 |  |  | 10 | % |  | 1,527 |  |  | 8 | % |  | 1,698 |  |  | 10 | % |
| Other | 1,614 |  |  | 24 | % |  | 1,453 |  |  | 24 | % |  | 4,582 |  |  | 24 | % |  | 4,349 |  |  | 24 | % |
|  | $ | 6,752 |  |  |  |  |  | $ | 6,115 |  |  |  |  |  | $ | 19,030 |  |  |  |  |  | $ | 18,000 |  |  |  |  |

[0000866374-18-000003:mdna:16]
[same as prior period, unchanged from 0000866374-17-000012:mdna:18]

[0000866374-18-000003:mdna:17]
|  | As of |  | As of |
| Property and equipment, net: | December 31, 2017 |  | March 31, 2017 |
|  | (In millions) |
| China | $ | 713 |  |  | 29 | % |  | $ | 720 |  |  | 31 | % |
| Mexico | 599 |  |  | 25 | % |  | 525 |  |  | 23 | % |
| U.S. | 307 |  |  | 13 | % |  | 291 |  |  | 13 | % |
| Malaysia | 154 |  |  | 6 | % |  | 173 |  |  | 7 | % |
| Hungary | 147 |  |  | 6 | % |  | 133 |  |  | 6 | % |
| Other | 523 |  |  | 21 | % |  | 475 |  |  | 20 | % |
|  | $ | 2,443 |  |  |  |  |  | $ | 2,317 |  |  |  |  |

[0000866374-18-000003:mdna:18]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and industrial campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer electronics and industrial products for leading multinational and regional customers. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-18-000003:mdna:19]
[same as prior period, unchanged from 0000866374-17-000012:mdna:20]

[0000866374-18-000003:mdna:20]
[same as prior period, unchanged from 0000866374-17-000012:mdna:21]

[0000866374-18-000003:mdna:21]
[same as prior period, unchanged from 0000866374-17-000012:mdna:22]

[0000866374-18-000003:mdna:22]
[same as prior period, unchanged from 0000866374-17-000012:mdna:23]

[0000866374-18-000003:mdna:23]
[same as prior period, unchanged from 0000866374-17-000012:mdna:24]

[0000866374-18-000003:mdna:24]
[same as prior period, unchanged from 0000866374-17-000012:mdna:25]

[0000866374-18-000003:mdna:25]
[same as prior period, unchanged from 0000866374-17-000012:mdna:26]

[0000866374-18-000003:mdna:26]
[same as prior period, unchanged from 0000866374-17-000012:mdna:27]

[0000866374-18-000003:mdna:27]
[same as prior period, unchanged from 0000866374-17-000012:mdna:28]

[0000866374-18-000003:mdna:28]
[same as prior period, unchanged from 0000866374-17-000012:mdna:29]

[0000866374-18-000003:mdna:29]
[same as prior period, unchanged from 0000866374-17-000012:mdna:30]

[0000866374-18-000003:mdna:30]
[same as prior period, unchanged from 0000866374-17-000012:mdna:31]

[0000866374-18-000003:mdna:31]
[same as prior period, unchanged from 0000866374-17-000012:mdna:32]

[0000866374-18-000003:mdna:32]
[same as prior period, unchanged from 0000866374-17-000012:mdna:33]

[0000866374-18-000003:mdna:33]
[same as prior period, unchanged from 0000866374-17-000012:mdna:34]

[0000866374-18-000003:mdna:34]
[same as prior period, unchanged from 0000866374-17-000012:mdna:38]

[0000866374-18-000003:mdna:35]
[same as prior period, unchanged from 0000866374-17-000012:mdna:35]

[0000866374-18-000003:mdna:36]
[same as prior period, unchanged from 0000866374-17-000012:mdna:36]

[0000866374-18-000003:mdna:37]
[same as prior period, unchanged from 0000866374-17-000012:mdna:37]

[0000866374-18-000003:mdna:38]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.4 |  |  | 93.2 |  |  | 93.4 |  |  | 93.7 |  |
| Gross profit | 6.6 |  |  | 6.8 |  |  | 6.6 |  |  | 6.3 |  |
| Selling, general and administrative expenses | 3.7 |  |  | 3.8 |  |  | 4.1 |  |  | 4.0 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Interest and other, net | 0.5 |  |  | 0.4 |  |  | 0.5 |  |  | 0.4 |  |
| Other charges (income), net | 0.1 |  |  | 0.1 |  |  | (0.9 | ) |  | 0.1 |  |
| Income before income taxes | 2.0 |  |  | 2.2 |  |  | 2.6 |  |  | 1.5 |  |
| Provision for income taxes | 0.3 |  |  | 0.2 |  |  | 0.3 |  |  | 0.2 |  |
| Net income | 1.7 | % |  | 2.0 | % |  | 2.3 | % |  | 1.3 | % |

[0000866374-18-000003:mdna:39]
[same as prior period, unchanged from 0000866374-17-000012:mdna:40]

[0000866374-18-000003:mdna:40]
[same as prior period, unchanged from 0000866374-17-000012:mdna:41]

[0000866374-18-000003:mdna:41]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Segments: | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
|  | (In millions) |
| Communications & Enterprise Compute | $ | 1,979 |  |  | 29 | % |  | $ | 2,102 |  |  | 34 | % |  | $ | 5,853 |  |  | 31 | % |  | $ | 6,400 |  |  | 36 | % |
| Consumer Technologies Group | 2,057 |  |  | 30 | % |  | 1,849 |  |  | 30 | % |  | 5,324 |  |  | 28 | % |  | 4,827 |  |  | 27 | % |
| Industrial & Emerging Industries | 1,491 |  |  | 22 | % |  | 1,140 |  |  | 19 | % |  | 4,336 |  |  | 23 | % |  | 3,672 |  |  | 20 | % |
| High Reliability Solutions | 1,225 |  |  | 19 | % |  | 1,023 |  |  | 17 | % |  | 3,517 |  |  | 18 | % |  | 3,101 |  |  | 17 | % |
|  | $ | 6,752 |  |  |  |  |  | $ | 6,114 |  |  |  |  |  | $ | 19,030 |  |  |  |  |  | $ | 18,000 |  |  |  |  |

[0000866374-18-000003:mdna:42]
Net sales during the three-month period ended December 31, 2017 totaled $6.8 billion, representing an increase of approximately $0.7 billion, or 10% from $6.1 billion during the three-month period ended December 31, 2016. The overall increase in sales was driven by increases in three of our segments offset by a decline in sales in our CEC segment. Our IEI segment increased $351 million, mainly driven by our industrial, home and lifestyle business in addition to growth in our solar energy business. Our CTG segment increased $208 million, primarily because of stronger sales in our connected living and mobile devices businesses, offset by a decrease in gaming. Our HRS segment increased $201 million from higher sales in our automotive business. Sales in our CEC segment declined $123 million, largely attributable to lower sales within our telecom

[0000866374-18-000003:mdna:43]
[same as prior period, unchanged from 0000866374-17-000012:mdna:45]

[0000866374-18-000003:mdna:44]
and networking businesses, offset by increased sales in our cloud and data center business. Net sales increased $395 million to $2.7 billion in the Americas, increased $193 million to $3.0 billion in Asia, and increased $48 million to $1.1 billion in Europe

[0000866374-18-000003:mdna:45]
Net sales during the nine-month period ended December 31, 2017 totaled $19.0 billion, representing an increase of approximately $1.0 billion, or 6% from $18.0 billion during the nine-month period ended December 31, 2016. The overall increase in net sales during the nine-month period ended December 31, 2017, was driven by increases of $664 million in our IEI segment, $496 million in our CTG segment, and $416 million in our HRS segment due to the same drivers as described above. These increases were offset by a decrease of $547 million in our CEC segment as a result of lower sales within our telecom and legacy server and storage businesses, offset by increased sales in our cloud and data center business. Net sales increased $1.1 billion to $7.5 billion in the Americas, offset by decreases of $83 million to $8.3 billion in Asia and $29 million to $3.2 billion in Europe.

[0000866374-18-000003:mdna:46]
Our ten largest customers, during the three and nine-month periods ended December 31, 2017 accounted for approximately 43% and 42% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and nine-month periods ended December 31, 2017.

[0000866374-18-000003:mdna:47]
Our ten largest customers, during the three and nine-month periods ended December 31, 2016 accounted for approximately 46% and 43% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and nine-month periods ended December 31, 2016.

[0000866374-18-000003:mdna:48]
[same as prior period, unchanged from 0000866374-17-000012:mdna:48]

[0000866374-18-000003:mdna:49]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion or consolidation of manufacturing facilities including specific restructuring activities from time to time. The flexible design of our manufacturing processes allows us to build a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-18-000003:mdna:50]
Gross profit during the three-month period ended December 31, 2017 increased $30 million to $446 million, or 6.6% of net sales, from $416 million, or 6.8% of net sales, during the three-month period ended December 31, 2016 primarily due to flow through from higher sales across three of our four segments as discussed above.  The gross profit percentage decline of 20 basis points from the prior year quarter was driven primarily by lower gross profit generation by our CTG segment as it realized greater levels of costs associated with ramping a strategic customer as further explained below. Gross profit during the nine-month period ended December 31, 2017 increased $0.1 billion to $1.2 billion, or 6.6% of net sales, from $1.1 billion, or 6.3% of net sales, during the nine-month period ended December 31, 2016. The increase in gross profit for the nine-month period ended December 31, 2017 is primarily due to contribution flow through from the additional $1.0 billion in sales from the prior year to date period.  In addition, the prior year to date period gross profit included $93 million of charges related to the significant decline in prices for solar modules and slowdown in demand. This was partially offset by an elevated level of costs associated with ramping a strategic customer in our CTG segment as further explained below.

[0000866374-18-000003:mdna:51]
[same as prior period, unchanged from 0000866374-17-000012:mdna:52]

[0000866374-18-000003:mdna:52]
An operating segment’s performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges, other charges (income), net and interest and other, net. A portion of depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0000866374-18-000003:mdna:53]
[same as prior period, unchanged from 0000866374-17-000012:mdna:54]

[0000866374-18-000003:mdna:54]
[same as prior period, unchanged from 0000866374-17-000012:mdna:55]

[0000866374-18-000003:mdna:55]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
|  | (In millions) |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 50 |  |  | 2.5 | % |  | $ | 62 |  |  | 3.0 | % |  | $ | 142 |  |  | 2.4 | % |  | $ | 176 |  |  | 2.8 | % |
| Consumer Technologies Group | 39 |  |  | 1.9 | % |  | 59 |  |  | 3.2 | % |  | 87 |  |  | 1.6 | % |  | 139 |  |  | 2.9 | % |
| Industrial & Emerging Industries | 61 |  |  | 4.1 | % |  | 40 |  |  | 3.5 | % |  | 168 |  |  | 3.9 | % |  | 127 |  |  | 3.5 | % |
| High Reliability Solutions | 101 |  |  | 8.2 | % |  | 83 |  |  | 8.1 | % |  | 283 |  |  | 8.1 | % |  | 250 |  |  | 8.1 | % |
| Corporate and Other | (32 | ) |  |  |  | (21 | ) |  |  |  | (94 | ) |  |  |  | (82 | ) |  |  |
| Total segment income | 219 |  |  | 3.3 | % |  | 223 |  |  | 3.6 | % |  | 586 |  |  | 3.1 | % |  | 610 |  |  | 3.4 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 19 |  |  |  |  | 19 |  |  |  |  | 56 |  |  |  |  | 62 |  |  |  |
| Stock-based compensation | 21 |  |  |  |  | 21 |  |  |  |  | 63 |  |  |  |  | 67 |  |  |  |
| Distressed customers asset impairments (1) | — |  |  |  |  | — |  |  |  |  | 5 |  |  |  |  | 93 |  |  |  |
| Contingencies and other (2) | — |  |  |  |  | 17 |  |  |  |  | 44 |  |  |  |  | 29 |  |  |  |
| Other charges (income), net | 7 |  |  |  |  | 3 |  |  |  |  | (173 | ) |  |  |  | 15 |  |  |  |
| Interest and other, net | 31 |  |  |  |  | 23 |  |  |  |  | 86 |  |  |  |  | 72 |  |  |  |
| Income before income taxes | $ | 141 |  |  |  |  | $ | 140 |  |  |  |  | $ | 505 |  |  |  |  | $ | 272 |  |  |  |

[0000866374-18-000003:mdna:56]
[same as prior period, unchanged from 0000866374-17-000012:mdna:57]

[0000866374-18-000003:mdna:57]
During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand at the end of the second quarter of fiscal year 2017 was not fully recoverable and recorded a charge of $60 million to reduce the carrying costs to market in the nine-month period ended December 31, 2016. The Company also recognized a $16 million impairment charge for solar module equipment and $17 million primarily related to negative margin sales and other associated direct costs. The total charge of $93 million is included in cost of sales for the nine-month period ended December 31, 2016 but is excluded from segment results above.

[0000866374-18-000003:mdna:58]
(2)  During the second quarter of fiscal year 2018, the Company incurred charges in connection with the matters described in note 13 to the condensed consolidated financial statements for certain loss contingencies where it believes that losses are probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted one of our China facilities.

[0000866374-18-000003:mdna:59]
During fiscal year 2017, the Company initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its Sketch-to-Scaletm initiatives. As part of this plan, approximately $29 million was recognized in the nine-month period ended December 31, 2016. The plan was finalized and completed during fiscal year 2017.

[0000866374-18-000003:mdna:60]
CEC segment margin decreased 50 basis points, to 2.5% for the three-month period ended December 31, 2017, from 3.0% during the three-month period ended December 31, 2016. CEC segment margin decreased 40 basis points, to 2.4% for the nine-month period ended December 31, 2017, from 2.8% for the nine-month period ended December 31, 2016. The decreases in CEC's margins for both the three and nine-month periods ended December 31, 2017 were due to lower capacity utilization causing reduced overhead absorption, coupled with modest increased investments to expand its converged enterprise and cloud data center engineering capabilities.

[0000866374-18-000003:mdna:61]
[same as prior period, unchanged from 0000866374-17-000012:mdna:62]

[0000866374-18-000003:mdna:62]
CTG segment margin decreased 130 basis point to 1.9% for the three-month period ended December 31, 2017, from 3.2% during the three-month period ended December 31, 2016. CTG segment margin decreased 130 basis points, to 1.6% for the nine-month period ended December 31, 2017 from 2.9% for the nine-month period ended December 31, 2016. The decreases in CTG's margins for both the three and nine-month periods ended December 31, 2017 reflected the negative impacts from the elevated levels of costs associated with material management, labor inefficiencies and capacity refinements as we ramp up production with a strategic customer.

[0000866374-18-000003:mdna:63]
IEI segment margin increased 60 basis points, to 4.1% for the three-month period ended December 31, 2017, from 3.5% during the three-month period ended December 31, 2016. IEI segment margin increased 40 basis points, to 3.9% for the nine-month period ended December 31, 2017, from 3.5% for the nine-month period ended December 31, 2016. The increases in IEI's margins for both the three and nine-month periods ended December 31, 2017 are primarily due to revenue increases resulting in improved absorption of costs as a result of ramping multiple new programs in our industrial, home and lifestyle and energy businesses. This was partially offset by high levels of start-up costs on several new customer programs as we prepositioned resources in advance of the significant underlying ramps, as well as an impact from the underlying mix of business.

[0000866374-18-000003:mdna:64]
HRS segment margin increased 10 basis points, to 8.2% for the three-month period ended December 31, 2017, from 8.1% during the three-month period ended December 31, 2016 primarily as a result of new customers and programs ramp up coupled with solid operational management. HRS segment margin remained consistent at 8.1% for the nine-month periods ended December 31, 2017 and December 31, 2016.

[0000866374-18-000003:mdna:65]
Restructuring charges

[0000866374-18-000003:mdna:66]
On January 25, 2018, the Company announced a plan to initiate targeted restructuring activities focused on optimizing the cost base in lower growth areas and more importantly, streamlining certain corporate and segment functions. The objective of the plan is to make Flex a faster, more responsive and agile company better positioned to react to marketplace opportunities. While a detailed action plan has not been finalized, the Company expects to incur a minimum charge of $50 million during the fourth quarter of fiscal year 2018 and will substantially complete all the associated activities by the end of this fiscal year. The estimated costs are primarily related to one-time employee termination benefits and will be settled in cash.

[0000866374-18-000003:mdna:67]
[same as prior period, unchanged from 0000866374-17-000012:mdna:67]

[0000866374-18-000003:mdna:68]
Selling, general and administrative expenses (“SG&A”) was $247 million, or 3.7% of net sales, during the three-month period ended December 31, 2017, increasing $16 million from $232 million, or 3.8% of net sales, during the three-month period ended December 31, 2016. This increase was primarily due to incremental costs associated with our continued expansion of our design and engineering resources and innovation system to support our increased Sketch-to-Scaletm initiatives. SG&A was $772 million, or 4.1% of net sales, during the nine-month period ended December 31, 2017, increasing $57 million from $715 million, or 4.0% of net sales, during the nine-month period ended December 31, 2016. This increase in SG&A was also due to incremental costs associated with our continued expansion of our design and engineering resources and innovation system but also due to the recognition of certain contingencies that are probable and estimable of payout combined with incremental costs from our acquisitions.

[0000866374-18-000003:mdna:69]
[same as prior period, unchanged from 0000866374-17-000012:mdna:69]

[0000866374-18-000003:mdna:70]
Amortization of intangible assets increased $1 million during the three-month period ended December 31, 2017 to $20 million, from $19 million for the three-month period ended December 31, 2016 due to incremental amortization expense on intangible assets related to our acquisitions completed during fiscal year 2018. Amortization of intangible assets decreased by $6 million during the nine-month period ended December 31, 2017 to $56 million from $62 million during the nine-month period ended December 31, 2016, due to certain intangibles being fully amortized.

[0000866374-18-000003:mdna:71]
[same as prior period, unchanged from 0000866374-17-000012:mdna:71]

[0000866374-18-000003:mdna:72]
Interest and other, net was $31 million during the three-month period ended December 31, 2017 compared to $23 million during the three-month period ended December 31, 2016, and $86 million during the nine-month period ended December 31, 2017 compared to $72 million during the nine-month period ended December 31, 2016. The increase in interest and other, net was primarily a result of higher interest expense due to higher interest rates and a higher average borrowing level.

[0000866374-18-000003:mdna:73]
[same as prior period, unchanged from 0000866374-17-000012:mdna:73]

[0000866374-18-000003:mdna:74]
Other charges (income), net was $172 million of income during the nine-month period ended December 31, 2017 compared to $15 million of expense during the nine-month period ended December 31, 2016. The increase is primarily due to a $152 million non-cash gain as a result of the deconsolidation of our investment in Elementum, coupled with a $39 million gain recognized for the disposition of Wink during the first quarter of fiscal year 2018. Refer to note 5 and note 2 of the condensed consolidated financial statements for details of the deconsolidation and the disposition of Wink, respectively.

[0000866374-18-000003:mdna:75]
[same as prior period, unchanged from 0000866374-17-000012:mdna:76]

[0000866374-18-000003:mdna:76]
Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 13, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2017 for further discussion.

[0000866374-18-000003:mdna:77]
[same as prior period, unchanged from 0000866374-17-000012:mdna:78]

[0000866374-18-000003:mdna:78]
The consolidated effective tax rate was 16.2% and 11.3% for the three and nine-month periods ended December 31, 2017, and 7.7% and 14.4% for the three and nine-month periods ended December 31, 2016. The effective rate varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. The effective tax rate for the three-month period ended December 31, 2017 is higher than the effective tax rate for the three-month periods ended December 31, 2016, due to a larger decrease in liabilities for uncertain tax positions (primarily lapses and FX) during the three-month period ended December 31, 2016.  The effective tax rate for the nine-month period ended December 31, 2017 is lower than the nine-month period ended December 31, 2016 primarily due to the $151.6 million Elementum deconsolidation gain recognized during the quarter ended September 29, 2017 with no related tax impact.

[0000866374-18-000003:mdna:79]
Impact of the U.S. Tax Reform

[0000866374-18-000003:mdna:80]
On December 22, 2017, the U.S. President signed the Tax Cuts and Jobs Act (the “Act”) into law. Effective January 1, 2018, among other changes, the Act (a) reduces the U.S. federal corporate tax rate to 21 percent, provides for a deemed repatriation and taxation at reduced rates on historical earnings (a “transition tax”) of certain non-US subsidiaries owned by U.S. companies and establishes new mechanisms to tax such earnings going forward. Similar to other large multinational companies with complex tax structures, the Act has wide ranging implications for Flex. However, the impact on Flex's financial statements for the three and nine-month periods ended December 31, 2017 is immaterial, primarily because the Company has a full valuation allowance on deferred tax assets in the U.S., which results in there being no U.S. deferred tax assets or liabilities recorded on the balance sheet that need to be remeasured at the new 21% rate. Further, the Company expects that the new transition tax will be offset by U.S tax attributes such as net operating loss carryforwards, and thus will not result in any incremental taxes payable. The Company will continue to analyze the effects of the Act on its financial statements and operations. Any additional impacts from the enactment of the Act will be recorded as they are identified during the measurement period as provided for in Staff Accounting Bulletin 118.

[0000866374-18-000003:mdna:81]
[same as prior period, unchanged from 0000866374-17-000012:mdna:80]

[0000866374-18-000003:mdna:82]
As of December 31, 2017, we had cash and cash equivalents of approximately $1.3 billion and bank and other borrowings of approximately $2.9 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. As of December 31, 2017, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0000866374-18-000003:mdna:83]
Cash provided by operating activities was $431 million during the nine-month period ended December 31, 2017. This resulted from $448 million of net income for the period plus adjustments for $430 million, net, non-cash charges such as depreciation, amortization, and stock-based compensation. These were partially offset by a $152 million gain from the deconsolidation of Elementum, and a $39 million gain on sale of Wink, which are both included in the determination of net income. The foregoing was further offset by a $256 million net increase in our operating assets and liabilities driven primarily by significant increases in accounts receivable and inventory not fully offset by the increase in accounts payable all reflecting our increased level of operations.

[0000866374-18-000003:mdna:84]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure the Company’s liquidity. Net working capital increased $230 million to $1.8 billion as of December 31, 2017, from $1.6 billion as of March 31, 2017. This increase is primarily driven by a $329 million increase in our inventory levels from March 31, 2017, as we are carrying elevated levels to support our revenue growth and positioning for multiple large ramps. Despite the increase in net working capital position from March 31, 2017, current quarter net working capital as a percentage of annualized net sales for the quarter then ended remained relatively consistent at 6.8% as compared to 6.9% of annualized net sales for the quarter ended December 31, 2017. The Company generally operates in a net working capital targeted range between 6%-8% of annualized revenue for the quarter. Net working capital position was calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories, less accounts payable.

[0000866374-18-000003:mdna:85]
Cash used in investing activities amounted to $783 million during the nine-month period ended December 31, 2017. During the nine-month period ended December 31, 2017, we paid $214 million for the acquisition of AGM, net of cash acquired, and we also paid $56 million for a power module business, net of cash acquired. Further, we invested $389 million of net capital expenditures for property and equipment to expand capabilities and capacity in support of our automotive, medical, footwear and IEI businesses. In addition, other investing activities includes $73 million of cash outflow resulting from the deconsolidation of Elementum, and $47 million of payments for investments, net of cash received, in non-core businesses.

[0000866374-18-000003:mdna:86]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the nine-month period ended December 31, 2017 was $42 million compared to $628 million for the nine-month period ended December 31, 2016. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-18-000003:mdna:87]
|  | Nine-Month Periods Ended |
|  | December 31, 2017 |  | December 31, 2016 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 431 |  |  | $ | 1,013 |  |
| Purchases of property and equipment | (433 | ) |  | (413 | ) |
| Proceeds from the disposition of property and equipment | 44 |  |  | 28 |  |
| Free cash flow | $ | 42 |  |  | $ | 628 |  |

[0000866374-18-000003:mdna:88]
Cash used in financing activities was $173 million during the nine-month period ended December 31, 2017, which was primarily for the repurchase of our ordinary shares in the amount of $180 million and for repayments of debts of $42 million, offset by $65 million received from third party investors during fiscal year 2018, in exchange for an additional noncontrolling equity interest in Elementum prior to the deconsolidation described above.

[0000866374-18-000003:mdna:89]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of December 31, 2017 and March 31, 2017, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.2 billion as of March 31, 2017). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of

[0000866374-18-000003:mdna:90]
34

[0000866374-18-000003:mdna:91]
[same as prior period, unchanged from 0000866374-17-000012:mdna:95]

[0000866374-18-000003:mdna:92]
[same as prior period, unchanged from 0000866374-17-000012:mdna:96]

[0000866374-18-000003:mdna:93]
[same as prior period, unchanged from 0000866374-17-000012:mdna:97]

[0000866374-18-000003:mdna:94]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-18-000003:mdna:95]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 15, 2017. During the nine-month period ended December 31, 2017, we paid $180 million to repurchase shares under the current and prior repurchase plans at an average price of $16.63 per share. As of December 31, 2017, shares in the aggregate amount of $410 million were available to be repurchased under the current plan.

[0000866374-18-000003:mdna:96]
[same as prior period, unchanged from 0000866374-17-000012:mdna:100]

[0000866374-18-000003:mdna:97]
[same as prior period, unchanged from 0000866374-17-000012:mdna:101]

[0000866374-18-000003:mdna:98]
On June 30, 2017, we extended the maturity date of one of our term loan agreements from March 31, 2019 to June 30, 2022. Refer to note 6 to the condensed consolidated financial statements for additional details on this term loan.

[0000866374-18-000003:mdna:99]
[same as prior period, unchanged from 0000866374-17-000012:mdna:103]

[0000866374-18-000003:mdna:100]
[same as prior period, unchanged from 0000866374-17-000012:mdna:104]

[0000866374-18-000003:mdna:101]
[same as prior period, unchanged from 0000866374-17-000012:mdna:106]

[0000866374-18-000003:mdna:102]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of December 31, 2017 and March 31, 2017, the fair values of our deferred purchase price receivable were approximately $421 million and $507 million, respectively. As of December 31, 2017 and March 31, 2017, the outstanding balance on receivables sold for cash was $1.4 billion and $1.2 billion under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information, see note 10 to the condensed consolidated financial statements.
