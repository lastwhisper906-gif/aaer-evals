# FLEX note change history — 0000866374-17-000012 → 0000866374-18-000003


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-01-29):
[0000866374-18-000003:note_history:1]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 291 million Brazilian reals (approximately USD $88 million based on the exchange rate as of December 31, 2017). The assessments are in various stages of the review process at the administrative level. The Company has meritorious defenses and plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.
  (was, 2017-10-30, similarity 0.994):
[0000866374-17-000012:note_history:1]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 291 million Brazilian reals (approximately USD $91 million based on the exchange rate as of September 29, 2017). The assessments are in various stages of the review process at the administrative level. The Company has meritorious defenses and plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-01-29):
[0000866374-18-000003:note_history:2]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and industrial products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:
  (was, 2017-10-30, similarity 0.9993):
[0000866374-17-000012:note_history:2]
Flex Ltd., ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and industrial products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

- changed (2018-01-29):
[0000866374-18-000003:note_history:3]
| • | High Reliability Solutions ("HRS"), which is comprised of medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies. |
  (was, 2017-10-30, similarity 0.8805):
[0000866374-17-000012:note_history:3]
| • | High Reliability Solutions ("HRS"), which is comprised of medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military. |

- changed (2018-01-29):
[0000866374-18-000003:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2017 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018.
  (was, 2017-10-30, similarity 0.9702):
[0000866374-17-000012:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2017 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and six-month periods ended September 29, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018.

- changed (2018-01-29):
[0000866374-18-000003:note_history:5]
The first quarters for fiscal year 2018 and fiscal year 2017 ended on June 30, 2017, which is comprised of 91 days in the period, and July 1, 2016, which is comprised of 92 days in the period, respectively. The second quarters for fiscal year 2018 and fiscal year 2017 ended on September 29, 2017 and September 30, 2016, which are comprised of 91 days in both periods. The Company's third quarters end on December 31 of each year, which are comprised of 93 days and 92 days for fiscal years 2018 and 2017, respectively.
  (was, 2017-10-30, similarity 0.8244):
[0000866374-17-000012:note_history:5]
The first quarters for fiscal year 2018 and fiscal year 2017 ended on June 30, 2017, which is comprised of 91 days in the period, and July 1, 2016, which is comprised of 92 days in the period, respectively. The second quarters for fiscal year 2018 and fiscal year 2017 ended on September 29, 2017 and September 30, 2016, which are comprised of 91 days in both periods.

- added (2018-01-29):
[0000866374-18-000003:note_history:6]
In August 2016, the FASB issued Accounting Standard Update (ASU) No. 2016-15, "Statement of Cash Flows (Topic 2030): Classification of Certain Cash Receipts and Cash Payments." The standard is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 is consistent with our current cash flow classification. However, cash receipts on the deferred purchase price as described in Note 10 will be classified as cash flow from investing activities instead of the Company's current presentation as cash flows from operations. The Company intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2019 and retrospectively report cash flows from operating and investing activities for all periods presented. While the Company is still quantifying the impact of adoption of this standard, it does expect the standard to result in a material increase in cash flows from investing activities and corresponding reduction in cash flows from operating activities for all periods presented.

- added (2018-01-29):
[0000866374-18-000003:note_history:7]
In February 2016, the FASB issued new guidance intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach. Upon initial evaluation, the Company believes the new guidance will have a material impact on its consolidated balance sheets when adopted.

- changed (2018-01-29):
[0000866374-18-000003:note_history:8]
The Company is in the process of implementation activities in accordance with the planned effective date. These activities are focused on the review of significant customer contracts, identification and development of additional systems capabilities to enable the Company to make reasonable estimates of revenue as products are manufactured, and the design and implementation of relevant internal controls. The Company has determined that the new standard will change the timing of revenue recognition for a significant portion of its business. Under the new standard, revenue for a significant majority of the manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery). This change will also have material impacts to the Company’s balance sheet, primarily related to a reduction in finished goods and work-in-process inventories and an increase in unbilled receivables.
  (was, 2017-10-30, similarity 0.9924):
[0000866374-17-000012:note_history:8]
The Company is in the process of implementation activities in accordance with the planned effective date. These activities are focused on the review of significant customer contracts, identification and development of additional systems capabilities to enable the Company to make reasonable estimates of revenue as products are manufactured, and the design and implementation of relevant internal controls. The Company has determined that the new standard will change the timing of revenue recognition for a significant portion of its business. Under the new standard, revenue for a significant majority of the manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery). This change will also have material impacts to the Company’s balance sheet, primarily related to a reduction in finished goods and work-in-process inventories and a corresponding increase in unbilled receivables.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-01-29):
[0000866374-18-000003:note_history:9]
|  | As of December 31, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 691,875 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 489,938 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,282 |  |  | 595,979 |  |
| Other | 181,175 |  |  | 169,671 |  |
| Debt issuance costs | (14,596 | ) |  | (16,007 | ) |
| Total | $ | 2,944,674 |  |  | $ | 2,952,143 |  |
  (was, 2017-10-30, similarity 0.9927):
[0000866374-17-000012:note_history:9]
|  | As of September 29, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 496,219 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,180 |  |  | 595,979 |  |
| Other | 179,101 |  |  | 169,671 |  |
| Debt issuance costs | (15,379 | ) |  | (16,007 | ) |
| Total | $ | 2,956,121 |  |  | $ | 2,952,143 |  |

- changed (2018-01-29):
[0000866374-18-000003:note_history:10]
The weighted-average interest rates for the Company’s long-term debt were 3.7% and 3.5% as of December 31, 2017 and March 31, 2017, respectively.
  (was, 2017-10-30, similarity 0.9528):
[0000866374-17-000012:note_history:10]
The weighted-average interest rates for the Company’s long-term debt were 3.5% as of September 29, 2017 and March 31, 2017, respectively.

- changed (2018-01-29):
[0000866374-18-000003:note_history:11]
On June 30, 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature in March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualified as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the term of the 2022 Credit Facility.
  (was, 2017-10-30, similarity 0.9989):
[0000866374-17-000012:note_history:11]
On June 30, 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature on March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualified as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the term of the 2022 Credit Facility.

- changed (2018-01-29):
[0000866374-18-000003:note_history:12]
The 2022 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of December 31, 2017, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.
  (was, 2017-10-30, similarity 0.9958):
[0000866374-17-000012:note_history:12]
The 2022 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of September 29, 2017, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.

- changed (2018-01-29):
[0000866374-18-000003:note_history:13]
Repayment of the Company’s long term debt outstanding as of December 31, 2017 is as follows:
  (was, 2017-10-30, similarity 0.9714):
[0000866374-17-000012:note_history:13]
Repayment of the Company’s long term debt outstanding as of September 29, 2017 is as follows:

- changed (2018-01-29):
[0000866374-18-000003:note_history:14]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2018. |
  (was, 2017-10-30, similarity 0.957):
[0000866374-17-000012:note_history:14]
| (1) | Represents scheduled repayment for the remaining six-month period ending March 31, 2018. |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-01-29):
[0000866374-18-000003:note_history:15]
|  | As of December 31, 2017 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 516,925 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 691,875 |  |  | 693,605 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 489,938 |  |  | 491,163 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 536,515 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,282 |  |  | 643,440 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 58,021 |  |  | 58,021 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 119,786 |  |  | 119,786 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,955,902 |  |  | $ | 3,059,455 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |
  (was, 2017-10-30, similarity 0.9958):
[0000866374-17-000012:note_history:15]
|  | As of September 29, 2017 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 523,360 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,441 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 496,219 |  |  | 496,532 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 543,685 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,180 |  |  | 650,490 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 57,359 |  |  | 57,359 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 117,660 |  |  | 117,660 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,967,418 |  |  | $ | 3,089,527 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-01-29):
[0000866374-18-000003:note_history:16]
|  | As of December 31, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 691,875 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 489,938 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,282 |  |  | 595,979 |  |
| Other | 181,175 |  |  | 169,671 |  |
| Debt issuance costs | (14,596 | ) |  | (16,007 | ) |
| Total | $ | 2,944,674 |  |  | $ | 2,952,143 |  |
  (was, 2017-10-30, similarity 0.9927):
[0000866374-17-000012:note_history:16]
|  | As of September 29, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 496,219 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,180 |  |  | 595,979 |  |
| Other | 179,101 |  |  | 169,671 |  |
| Debt issuance costs | (15,379 | ) |  | (16,007 | ) |
| Total | $ | 2,956,121 |  |  | $ | 2,952,143 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-01-29):
[0000866374-18-000003:note_history:17]
Repayment of the Company’s long term debt outstanding as of December 31, 2017 is as follows:
  (was, 2017-10-30, similarity 0.9714):
[0000866374-17-000012:note_history:17]
Repayment of the Company’s long term debt outstanding as of September 29, 2017 is as follows:

- changed (2018-01-29):
[0000866374-18-000003:note_history:18]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2018. |
  (was, 2017-10-30, similarity 0.957):
[0000866374-17-000012:note_history:18]
| (1) | Represents scheduled repayment for the remaining six-month period ending March 31, 2018. |
